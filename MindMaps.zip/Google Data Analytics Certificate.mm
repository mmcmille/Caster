<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="Google Data Analytics Certificate" FOLDED="false" ID="ID_1692062770" CREATED="1706679759552" MODIFIED="1706895629656" LINK="Career%20Management.mm">
<edge DASH="SOLID"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<hook NAME="MapStyle" background="#191919" zoom="1.2" layout="OUTLINE">
    <properties show_icon_for_attributes="true" show_note_icons="true" allow_compact_layout="true" fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="oval" UNIFORM_SHAPE="true" TEXT_ALIGN="LEFT" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="24"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_238255399" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" NUMBERED="false" FORMAT="STANDARD_FORMAT" TEXT_ALIGN="LEFT" MAX_WIDTH="120 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#808080" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="AUTO" VGAP_QUANTITY="2 pt" COMMON_HGAP_QUANTITY="14 pt">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_238255399" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Arial" SIZE="9" BOLD="true" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#333333" WIDTH="3"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/html"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/html"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="11"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge STYLE="hide_edge" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#1e3360" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#203868"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<icon BUILTIN="yes"/>
<edge COLOR="#333333"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" BORDER_WIDTH="0 px" VGAP_QUANTITY="3 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="22" ITALIC="false"/>
<edge STYLE="horizontal" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font NAME="Arial" SIZE="20" BOLD="true"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font NAME="Arial" SIZE="18"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="16" BOLD="true"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FLOW">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="Course 1" FOLDED="true" ID="ID_1824224744" CREATED="1706898656569" MODIFIED="1711036677849">
<font BOLD="true"/>
<node TEXT="glossary" ID="ID_1381753668" CREATED="1706898662521" MODIFIED="1706898669758" LINK="https://1drv.ms/w/s!Av57m4NPvIjCi36BlS8o7AgbPCli?e=gm2hXL"/>
<node TEXT="Module 1" ID="ID_1353977080" CREATED="1706736455697" MODIFIED="1706736459025"/>
<node TEXT="Root Cause Analysis" FOLDED="true" ID="ID_600438593" CREATED="1706730459353" MODIFIED="1706730468571">
<node TEXT="5 Whys" FOLDED="true" ID="ID_490918593" CREATED="1706731180738" MODIFIED="1706731190712">
<node TEXT="ask questions to get to the root cause" ID="ID_113083659" CREATED="1706731191389" MODIFIED="1706731209568"/>
</node>
</node>
<node TEXT="analytical thinking" FOLDED="true" ID="ID_1479661131" CREATED="1706730130180" MODIFIED="1706730133994">
<node TEXT="Analytical thinking involves identifying and defining a problem and then solving it by using data in an organized, step-by-step manner." ID="ID_1125163059" CREATED="1706730135622" MODIFIED="1706730135622"/>
<node TEXT="visualization" FOLDED="true" ID="ID_341744444" CREATED="1706730148380" MODIFIED="1706730152602">
<node TEXT="graphical representation of information" ID="ID_1088073850" CREATED="1706732617357" MODIFIED="1706732621787"/>
</node>
<node TEXT="strategy, strategic thinking" FOLDED="true" ID="ID_1316999970" CREATED="1706730148342" MODIFIED="1706733461585">
<node TEXT="key to staying focused and on track" ID="ID_1344621275" CREATED="1706732738559" MODIFIED="1706732743169"/>
<node TEXT="helps improve the quality and usefulness of the data we collect" ID="ID_1613452425" CREATED="1706732743966" MODIFIED="1706732759569"/>
</node>
<node TEXT="problem orientation, problem-oriented" FOLDED="true" ID="ID_1520993540" CREATED="1706730160951" MODIFIED="1706732560372">
<node TEXT="use a problem oriented approach to identify, describe, and solve problems" ID="ID_1408617921" CREATED="1706732560375" MODIFIED="1706732599226"/>
</node>
<node TEXT="correlation" FOLDED="true" ID="ID_1201382347" CREATED="1706730164769" MODIFIED="1706730167748">
<node TEXT="relationship between two or more pieces of data" ID="ID_1178763017" CREATED="1706733360581" MODIFIED="1706733366767"/>
</node>
<node TEXT="big picture thinking" FOLDED="true" ID="ID_1757777407" CREATED="1706730167768" MODIFIED="1706730301786">
<node TEXT="zoom out and see possibilities and opportunities" ID="ID_1206215624" CREATED="1706732681981" MODIFIED="1706732703970"/>
</node>
<node TEXT="detail oriented thinking" FOLDED="true" ID="ID_740833551" CREATED="1706730301788" MODIFIED="1706730308980">
<node TEXT="specifics" ID="ID_715282060" CREATED="1706730413543" MODIFIED="1706730415767"/>
</node>
</node>
<node TEXT="Data Analytics Skills" FOLDED="true" ID="ID_1398994542" CREATED="1706729566157" MODIFIED="1706729581757">
<node TEXT="analytical skills" FOLDED="true" ID="ID_562314900" CREATED="1706729904442" MODIFIED="1706729908138">
<node TEXT="the qualities and characteristics associated with solving problems using facts" ID="ID_1245894028" CREATED="1706729908141" MODIFIED="1706729916571"/>
</node>
<node TEXT="curiosity" FOLDED="true" ID="ID_430571343" CREATED="1706729582923" MODIFIED="1706729585322">
<node TEXT="compels us to ask probing questions" ID="ID_338119705" CREATED="1706729748122" MODIFIED="1706729768376"/>
</node>
<node TEXT="understanding of context" FOLDED="true" ID="ID_36999379" CREATED="1706729585335" MODIFIED="1706729588721">
<node TEXT="the analytical skill that has to do with how you group things into categories" ID="ID_631046006" CREATED="1706729968549" MODIFIED="1706729998995"/>
<node TEXT="context" FOLDED="true" ID="ID_1866047410" CREATED="1706729651349" MODIFIED="1706729653930">
<node TEXT="the condition in which something exists or happens" ID="ID_1247195661" CREATED="1706729653934" MODIFIED="1706729659167"/>
</node>
</node>
<node TEXT="technical mindset" ID="ID_1170967869" CREATED="1706729588738" MODIFIED="1706729591721">
<node TEXT="the ability to break things down into smaller steps or pieces and work with them in orderly and logical way" ID="ID_1599755099" CREATED="1706729699342" MODIFIED="1706729713351"/>
</node>
<node TEXT="data design" FOLDED="true" ID="ID_804911817" CREATED="1706729591734" MODIFIED="1706729594727">
<node TEXT="how information is organized" ID="ID_1201320553" CREATED="1706729661943" MODIFIED="1706729666568"/>
</node>
<node TEXT="data strategy" FOLDED="true" ID="ID_1361167690" CREATED="1706729594740" MODIFIED="1706729597361">
<node TEXT="the management of the people, processes, and tools used in data analysis" ID="ID_1017678005" CREATED="1706729674729" MODIFIED="1706729686163"/>
<node TEXT="based on the dataset in deliverables" ID="ID_1151672857" CREATED="1706729830368" MODIFIED="1706729843573"/>
</node>
</node>
<node TEXT="data-driven decision-making" FOLDED="true" ID="ID_1092290201" CREATED="1706683843870" MODIFIED="1706683855328">
<node TEXT="using facts to guide business strategy" ID="ID_1707493616" CREATED="1706683857158" MODIFIED="1706683911903"/>
<node TEXT="limited by the quantity and quality of readily available data" FOLDED="true" ID="ID_621615919" CREATED="1706918512887" MODIFIED="1706918521329">
<node TEXT="if sufficient, this approach can far improve decision-making" ID="ID_261372763" CREATED="1706918526891" MODIFIED="1706918537892"/>
<node TEXT="if data is insufficient or biased, this can create problems for decision-makers" ID="ID_429264376" CREATED="1706918537906" MODIFIED="1706918555494"/>
</node>
<node TEXT="potential dangers of relying entirely on it" FOLDED="true" ID="ID_446812287" CREATED="1706918561990" MODIFIED="1706918588800">
<node TEXT="overreliance on historical data" ID="ID_954045637" CREATED="1706918591481" MODIFIED="1706918601683"/>
<node TEXT="tendency to ignore qualitative insights" ID="ID_726740144" CREATED="1706918601700" MODIFIED="1706918607279"/>
<node TEXT="potential biases in data collection and analysis" ID="ID_398824501" CREATED="1706918607295" MODIFIED="1706918613717"/>
</node>
<node TEXT="example" FOLDED="true" ID="ID_332563915" CREATED="1706918619439" MODIFIED="1706918623285">
<node TEXT="A/B testing is a simple example of collecting data for data-driven decision-making. For example, a website that sells widgets has an idea for a new website layout they think will result in more people buying widgets. For two weeks, half of their website visitors are directed to the old site; the other half are directed to the new site. After those two weeks, the analyst gathers the data about their website visitors and the number of widgets sold for analysis. This helps the analyst understand which website layout resulted in more widget sales. If the new website performed better in producing widget sales, then the company can confidently make the decision to use the new layout!" ID="ID_1234294485" CREATED="1706918623287" MODIFIED="1706918648914"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_433240930" CREATED="1706918498690" MODIFIED="1706918500514">
<node ID="ID_664097401" CREATED="1706732989435" MODIFIED="1706732989435" LINK="https://www.coursera.org/learn/foundations-data/lecture/gT8Bo/how-data-informs-better-decisions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/lecture/gT8Bo/how-data-informs-better-decisions">How data informs better decisions | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Steps" FOLDED="true" ID="ID_1795518620" CREATED="1706733010065" MODIFIED="1706733011971">
<node TEXT="figuring out the business need, typically problem that needs to be solved" ID="ID_616106558" CREATED="1706733012979" MODIFIED="1706733043267"/>
<node TEXT="data analyst find data, analyzes it, and uses it to uncover trends, patterns in relationships" ID="ID_394437994" CREATED="1706733045167" MODIFIED="1706733097170"/>
</node>
<node TEXT="include insights from people who are familiar with business problem" FOLDED="true" ID="ID_475870046" CREATED="1706733132730" MODIFIED="1706733140828">
<node TEXT="subject matter experts" ID="ID_777033600" CREATED="1706733142981" MODIFIED="1706733146027"/>
</node>
</node>
<node TEXT="Terms" FOLDED="true" ID="ID_124962438" CREATED="1706683615694" MODIFIED="1706683618071">
<node TEXT="data ecosystem" FOLDED="true" ID="ID_1014085498" CREATED="1706683618869" MODIFIED="1706683623679">
<node TEXT="group of elements that interact with each other in order to __ data" FOLDED="true" ID="ID_1004493523" CREATED="1706683624101" MODIFIED="1706683688287">
<node TEXT="produce" ID="ID_1813182704" CREATED="1706683658622" MODIFIED="1706683660295"/>
<node TEXT="manage" ID="ID_161574120" CREATED="1706683660622" MODIFIED="1706683663999"/>
<node TEXT="store" ID="ID_316254225" CREATED="1706683664205" MODIFIED="1706683665927"/>
<node TEXT="organize" ID="ID_1230537302" CREATED="1706683666158" MODIFIED="1706683671103"/>
<node TEXT="analyze" ID="ID_486941156" CREATED="1706683672878" MODIFIED="1706683677199"/>
<node TEXT="share" ID="ID_1342439017" CREATED="1706683677470" MODIFIED="1706683681655"/>
</node>
<node TEXT="include" FOLDED="true" ID="ID_854705494" CREATED="1706683701341" MODIFIED="1706683704079">
<node TEXT="hardware tools" ID="ID_1536037984" CREATED="1706683709453" MODIFIED="1706683714111"/>
<node TEXT="software tools" ID="ID_400523382" CREATED="1706683709453" MODIFIED="1706683724111"/>
<node TEXT="people that use them" ID="ID_874879468" CREATED="1706683724613" MODIFIED="1706683728631"/>
</node>
</node>
<node TEXT="gap analysis" FOLDED="true" ID="ID_1324875594" CREATED="1706733175706" MODIFIED="1706733179779">
<node TEXT="a method for examining and evaluating the current state of a process in order to identify opportunities for improvement in the future" ID="ID_346309715" CREATED="1706733181328" MODIFIED="1706733195570"/>
</node>
</node>
<node TEXT="Module 2" ID="ID_1630224597" CREATED="1706733836122" MODIFIED="1706733844891"/>
<node TEXT="Data Lifecycle" FOLDED="true" ID="ID_1915157300" CREATED="1706733846134" MODIFIED="1706733852262">
<node TEXT="reference" FOLDED="true" ID="ID_56032004" CREATED="1706737538383" MODIFIED="1706737540029">
<node ID="ID_1954123162" CREATED="1706737541242" MODIFIED="1706737541242" LINK="https://www.coursera.org/learn/foundations-data/supplement/DoiXy/variations-of-the-data-life-cycle"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/supplement/DoiXy/variations-of-the-data-life-cycle">Variations of the data life cycle | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Stages" FOLDED="true" ID="ID_678086482" CREATED="1706736748220" MODIFIED="1706736752420">
<node TEXT="plan" FOLDED="true" ID="ID_1962713240" CREATED="1706736760408" MODIFIED="1706736769592">
<node TEXT="happens before starting an analysis project" ID="ID_1202378775" CREATED="1706736789416" MODIFIED="1706736797020"/>
<node TEXT="business decides what kind of data it needs" ID="ID_861719134" CREATED="1706736797826" MODIFIED="1706736804794"/>
<node TEXT="how it will be managed through its lifecycle" ID="ID_1065318808" CREATED="1706736804813" MODIFIED="1706736848035"/>
<node TEXT="who will be responsible for it" ID="ID_1975607618" CREATED="1706736808799" MODIFIED="1706736821442"/>
<node TEXT="optimal outcomes" ID="ID_808036879" CREATED="1706736812404" MODIFIED="1706736816023"/>
</node>
<node TEXT="capture" FOLDED="true" ID="ID_948681697" CREATED="1706736769604" MODIFIED="1706736771794">
<node TEXT="data is collected from a variety of different sources and brought into the organization" FOLDED="true" ID="ID_1890573859" CREATED="1706736886604" MODIFIED="1706736901809">
<node TEXT="outside sources" ID="ID_1526908954" CREATED="1706736928247" MODIFIED="1706736931993"/>
<node TEXT="company &apos;s database" ID="ID_850099835" CREATED="1706736932820" MODIFIED="1706736945786"/>
</node>
</node>
<node TEXT="manage" FOLDED="true" ID="ID_289312739" CREATED="1706736771808" MODIFIED="1706736773779">
<node TEXT="how we care for our data" ID="ID_684840823" CREATED="1706737002983" MODIFIED="1706737007229"/>
<node TEXT="how and where it&apos;s stored" ID="ID_270021828" CREATED="1706737007232" MODIFIED="1706737012191"/>
<node TEXT="the tools used to keep it safe and secure" ID="ID_264897327" CREATED="1706737012204" MODIFIED="1706737018984"/>
<node TEXT="actions taken to make sure that it&apos;s maintained properly" ID="ID_570258545" CREATED="1706737019000" MODIFIED="1706737025245"/>
</node>
<node TEXT="analyze" FOLDED="true" ID="ID_1360728304" CREATED="1706736773789" MODIFIED="1706736775980">
<node TEXT="Data Analysis Process Phases (Googles)" ID="ID_757563355" CREATED="1706679780869" MODIFIED="1706737477052"/>
<node TEXT="use data" FOLDED="true" ID="ID_1391141405" CREATED="1706737041196" MODIFIED="1706737348216">
<node TEXT="to solve problems" ID="ID_1630250097" CREATED="1706737348216" MODIFIED="1706737348218"/>
<node TEXT="make great decisions" ID="ID_129412951" CREATED="1706737053991" MODIFIED="1706737058392"/>
<node TEXT="support business goals" ID="ID_555748500" CREATED="1706737058406" MODIFIED="1706737061787"/>
</node>
</node>
<node TEXT="archive" FOLDED="true" ID="ID_992187338" CREATED="1706736775995" MODIFIED="1706736777998">
<node TEXT="storing data in a place where it still available, but may not be used again" ID="ID_93816064" CREATED="1706737091210" MODIFIED="1706737110224"/>
</node>
<node TEXT="destroy" FOLDED="true" ID="ID_131358049" CREATED="1706736778012" MODIFIED="1706736780194">
<node TEXT="securely erase data" ID="ID_951618978" CREATED="1706737134016" MODIFIED="1706737148416"/>
</node>
</node>
</node>
<node TEXT="data analysis toolbox" FOLDED="true" ID="ID_1362259995" CREATED="1706736463983" MODIFIED="1706740738404">
<node TEXT="organizing, cleaning, and analyzing data" FOLDED="true" ID="ID_1634120195" CREATED="1706820327073" MODIFIED="1706820369712">
<node TEXT="small to medium datasets" FOLDED="true" ID="ID_1219168938" CREATED="1706820391475" MODIFIED="1706820399700">
<node TEXT="spreadsheets" FOLDED="true" ID="ID_1663092648" CREATED="1706736472184" MODIFIED="1706736474776">
<node TEXT="reference" FOLDED="true" ID="ID_1481753025" CREATED="1706826315296" MODIFIED="1706826317523">
<node ID="ID_1020001563" CREATED="1706826326129" MODIFIED="1706826326129" LINK="https://www.coursera.org/learn/foundations-data/supplement/tb0lx/more-spreadsheet-resources"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/supplement/tb0lx/more-spreadsheet-resources">More spreadsheet resources | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Collect, store, organize, and sort information" ID="ID_1205156794" CREATED="1706819917747" MODIFIED="1706819917747"/>
<node TEXT="Identify patterns and piece the data together in a way that works for each specific data project" ID="ID_1148354335" CREATED="1706819917747" MODIFIED="1706819917747"/>
<node TEXT="Create excellent data visualizations, like graphs and charts." ID="ID_1572145821" CREATED="1706819917748" MODIFIED="1706819917748"/>
<node TEXT="Terms" FOLDED="true" ID="ID_726869944" CREATED="1706822270145" MODIFIED="1706822272516">
<node TEXT="attribute, label, header" FOLDED="true" ID="ID_1060215625" CREATED="1706822280450" MODIFIED="1706822317288">
<node TEXT="a characteristic or quality of data used to label a column in a table" ID="ID_1691610188" CREATED="1706826533326" MODIFIED="1706826541747"/>
</node>
<node TEXT="formula" FOLDED="true" ID="ID_1425698526" CREATED="1706821148758" MODIFIED="1706821151881">
<node TEXT="set of instructions that perform a specific calculation using data in the spreadsheet" ID="ID_741491947" CREATED="1706821151886" MODIFIED="1706821160736"/>
<node TEXT="examples are add, subtract, multiply, divide" ID="ID_1663281889" CREATED="1706821162456" MODIFIED="1706821170809"/>
</node>
<node TEXT="function" FOLDED="true" ID="ID_1423334837" CREATED="1706821174335" MODIFIED="1706821177273">
<node TEXT="preset command that automatically performs of a specific process or task" ID="ID_1147225167" CREATED="1706821177275" MODIFIED="1706821196118"/>
</node>
<node TEXT="observation" FOLDED="true" ID="ID_1514973504" CREATED="1706826548123" MODIFIED="1706826552728">
<node TEXT="the attributes that describe a piece of data contained in a row of a table" ID="ID_1233390713" CREATED="1706826552737" MODIFIED="1706826560738"/>
</node>
<node TEXT="oversampling" FOLDED="true" ID="ID_716021149" CREATED="1706826565521" MODIFIED="1706826570088">
<node TEXT="the process of increasing the sample size of nondominant groups in a population this can help you better represent them and address imbalanced data sets" ID="ID_360928802" CREATED="1706826570095" MODIFIED="1706826604323"/>
</node>
<node TEXT="self-reporting" FOLDED="true" ID="ID_858630830" CREATED="1706826606119" MODIFIED="1706826623096">
<node TEXT="a data collection technique where participants provide information about themselves" ID="ID_465632778" CREATED="1706826623101" MODIFIED="1706826630327"/>
</node>
</node>
</node>
</node>
<node TEXT="large and complex data sets" FOLDED="true" ID="ID_506334691" CREATED="1706820408713" MODIFIED="1706820414502">
<node TEXT="query languages" FOLDED="true" ID="ID_425971788" CREATED="1706736476590" MODIFIED="1706736478984">
<node TEXT="Allow analysts to isolate specific information from a database(s)" ID="ID_1949979562" CREATED="1706820155530" MODIFIED="1706820155530"/>
<node TEXT="Make it easier for you to learn and understand the requests made to databases" ID="ID_362230157" CREATED="1706820155530" MODIFIED="1706820155530"/>
<node TEXT="Allow analysts to select, create, add, or download data from a database for analysis" ID="ID_1658367498" CREATED="1706820155531" MODIFIED="1706820155531"/>
</node>
</node>
</node>
<node TEXT="visualization software" FOLDED="true" ID="ID_425967911" CREATED="1706736479001" MODIFIED="1706736482417">
<node TEXT="purpose" FOLDED="true" ID="ID_1713263538" CREATED="1706823016554" MODIFIED="1706823019314">
<node TEXT="Turn complex numbers into a story that people can understand" ID="ID_1176373114" CREATED="1706820194737" MODIFIED="1706820194737"/>
<node TEXT="Help stakeholders come up with conclusions that lead to informed decisions and effective business strategies" ID="ID_167221173" CREATED="1706820194737" MODIFIED="1706820194737"/>
</node>
<node TEXT="Have multiple features" FOLDED="true" ID="ID_918118995" CREATED="1706820194738" MODIFIED="1706820194738">
<node TEXT="- Tableau&apos;s simple drag-and-drop feature lets users create interactive graphs in dashboards and worksheets" ID="ID_250393029" CREATED="1706820194738" MODIFIED="1706820208108"/>
<node TEXT="- Looker communicates directly with a database, allowing you to connect your data right to the visual tool you choose" ID="ID_1979822110" CREATED="1706820194738" MODIFIED="1706820224503"/>
</node>
<node TEXT="Steps to plan a data visualization" FOLDED="true" ID="ID_30378241" CREATED="1706823041467" MODIFIED="1706823046931">
<node TEXT="reference" FOLDED="true" ID="ID_1559420598" CREATED="1706823066277" MODIFIED="1706823069311">
<node ID="ID_1632236458" CREATED="1706823070177" MODIFIED="1706823070177" LINK="https://www.coursera.org/learn/foundations-data/supplement/xPmo7/plan-a-data-visualization"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/supplement/xPmo7/plan-a-data-visualization">Plan a data visualization | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Step 1: Explore the data for patterns" ID="ID_1673054544" CREATED="1706823074963" MODIFIED="1706823087077"/>
<node TEXT="Step 2: Plan your visuals" ID="ID_1237325323" CREATED="1706823087103" MODIFIED="1706823098909"/>
<node TEXT="Step 3: Create your visuals" FOLDED="true" ID="ID_60655244" CREATED="1706823100500" MODIFIED="1706823108723">
<node TEXT="choice of visualization is driven by:" FOLDED="true" ID="ID_534949094" CREATED="1706827085513" MODIFIED="1706827096893">
<node TEXT="size of your data" ID="ID_1363115152" CREATED="1706827096899" MODIFIED="1706827103491"/>
<node TEXT="processes you used to analyze your data" ID="ID_413471798" CREATED="1706827103509" MODIFIED="1706827113692"/>
<node TEXT="other drivers" ID="ID_1824242915" CREATED="1706827113721" MODIFIED="1706827123525"/>
</node>
</node>
</node>
</node>
<node TEXT="databases" ID="ID_340587667" CREATED="1706736474785" MODIFIED="1706736476581"/>
</node>
<node TEXT="Module 3" ID="ID_456901826" CREATED="1706895653754" MODIFIED="1706895657301"/>
<node TEXT="Terms" FOLDED="true" ID="ID_1299514192" CREATED="1706895659034" MODIFIED="1706895662859">
<node TEXT="business task" FOLDED="true" ID="ID_111508317" CREATED="1706898468800" MODIFIED="1706898472484">
<node TEXT="the question or problem data analysis resolves for a business" ID="ID_599012431" CREATED="1706898472488" MODIFIED="1706898648730"/>
</node>
<node TEXT="fairness" FOLDED="true" ID="ID_458092428" CREATED="1706895664265" MODIFIED="1706895666289">
<node TEXT="reference" FOLDED="true" ID="ID_1104712550" CREATED="1706895744482" MODIFIED="1706895747086">
<node ID="ID_999313449" CREATED="1706895748264" MODIFIED="1706895748264" LINK="https://www.coursera.org/learn/foundations-data/supplement/HYO5o/consider-fairness"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/supplement/HYO5o/consider-fairness">Consider fairness | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="ensuring your analysis doesn&apos;t create or reinforce bias" ID="ID_1421663719" CREATED="1706895666291" MODIFIED="1706895681109"/>
<node TEXT="strategies that support fair analysis" FOLDED="true" ID="ID_1377216480" CREATED="1706895695707" MODIFIED="1706896250903">
<node TEXT="consider all the available data" ID="ID_259196677" CREATED="1706895699508" MODIFIED="1706895703670"/>
<node TEXT="identify surrounding factors" ID="ID_1758827719" CREATED="1706895703686" MODIFIED="1706895724465"/>
<node TEXT="include self-reported data" FOLDED="true" ID="ID_533214377" CREATED="1706896334921" MODIFIED="1706896341292">
<node ID="ID_1558348616" TREE_ID="ID_858630830">
<node ID="ID_688580708" TREE_ID="ID_465632778"/>
</node>
<node TEXT="using self reporting methods to collect data can help avoid observer biases" ID="ID_240058255" CREATED="1706896386404" MODIFIED="1706896396901"/>
<node TEXT="separating self-reported data from other data provides important context to conclusions" ID="ID_1072975280" CREATED="1706896399796" MODIFIED="1706896409898"/>
</node>
<node TEXT="use oversampling effectively" FOLDED="true" ID="ID_182062672" CREATED="1706895724480" MODIFIED="1706895728479">
<node ID="ID_479196915" TREE_ID="ID_716021149">
<node ID="ID_1245513897" TREE_ID="ID_360928802"/>
</node>
</node>
<node TEXT="think about fairness from beginning to end" ID="ID_228783417" CREATED="1706895728494" MODIFIED="1706895742107"/>
</node>
</node>
</node>
</node>
<node TEXT="Hiring" FOLDED="true" POSITION="top_or_left" ID="ID_168065692" CREATED="1708127675162" MODIFIED="1708127678049">
<node TEXT="reference" ID="ID_1085672360" CREATED="1708128571357" MODIFIED="1708128573423">
<node ID="ID_1630412052" CREATED="1708128582231" MODIFIED="1708128582231" LINK="https://www.coursera.org/learn/process-data/home/module/5"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/process-data/home/module/5">Process Data from Dirty to Clean - Optional: Add data to your resume - Week 5 | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="application process" FOLDED="true" ID="ID_670461502" CREATED="1708127823208" MODIFIED="1708127832953">
<node ID="ID_1461064822" CREATED="1708127834622" MODIFIED="1708127834622" LINK="https://www.coursera.org/learn/process-data/lecture/afo66/the-data-analyst-job-application"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/process-data/lecture/afo66/the-data-analyst-job-application">The data analyst job-application | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="resume" ID="ID_584096024" CREATED="1708127927710" MODIFIED="1708127930230">
<node TEXT="unique" ID="ID_1644443148" CREATED="1708128092257" MODIFIED="1708128094860"/>
<node TEXT="one page" ID="ID_1529783798" CREATED="1708127985597" MODIFIED="1708127988639"/>
<node TEXT="PAR problem -action -result" ID="ID_1115838985" CREATED="1708128140896" MODIFIED="1708128151764"/>
<node ID="ID_1712505051" CREATED="1708127931231" MODIFIED="1708127931231" LINK="https://www.coursera.org/learn/process-data/quiz/1Etkg/hands-on-activity-get-started-with-your-resume/attempt"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/process-data/quiz/1Etkg/hands-on-activity-get-started-with-your-resume/attempt">Hands-On Activity: Get started with your resume | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Data Analysis Process Phases (Googles)" FOLDED="true" POSITION="top_or_left" ID="ID_447693935" CREATED="1706679780869" MODIFIED="1706737438429">
<node TEXT="Step 1: Ask" FOLDED="true" ID="ID_154272451" CREATED="1706900372167" MODIFIED="1706900372167">
<node TEXT="Deliverable" FOLDED="true" ID="ID_817830764" CREATED="1711648381229" MODIFIED="1711648387934">
<node TEXT="A clear statement of the business task" FOLDED="true" ID="ID_719578867" CREATED="1711648387943" MODIFIED="1711648416323">
<node TEXT="Case Study" FOLDED="true" ID="ID_1395773012" CREATED="1711648801788" MODIFIED="1711648816645">
<node ID="ID_1298301918" CREATED="1711648920221" MODIFIED="1711648920221" LINK="../Career/Development%20and%20Learning/Data%20Analytics/Google%20Data%20Analytics%20Certificate/Portfolio/Reading_Case-Study-1_-How-does-a-bike-share-navigate-speedy-success_.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="file:///M:/My%20Drive/My%20Google%20Docs/Career/Development%20and%20Learning/Data%20Analytics/Google%20Data%20Analytics%20Certificate/Portfolio/Reading_Case-Study-1_-How-does-a-bike-share-navigate-speedy-success_.pdf">Reading_Case-Study-1_-How-does-a-bike-share-navigate-speedy-success_.pdf</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="identify how in your members in casual writers use Cyclistic bikes differently" ID="ID_449544590" CREATED="1711648871277" MODIFIED="1711648902120"/>
</node>
</node>
</node>
<node TEXT="Ask (1)" FOLDED="true" ID="ID_845654347" CREATED="1706679784565" MODIFIED="1706736698028">
<node TEXT="Guiding questions" FOLDED="true" ID="ID_120224009" CREATED="1712602982516" MODIFIED="1712602982516">
<node TEXT="What topic are you exploring?" ID="ID_1475805102" CREATED="1712602982518" MODIFIED="1712602982518"/>
<node TEXT="What is the problem you are trying to solve?" ID="ID_11877584" CREATED="1712602982519" MODIFIED="1712602982519"/>
<node TEXT="What metrics will you use to measure your data to achieve your objective? Who are the stakeholders?" ID="ID_384502874" CREATED="1712602982520" MODIFIED="1712602982520"/>
<node TEXT="Who is your audience for this analysis and how does this affect your analysis process and presentation?" ID="ID_862811788" CREATED="1712602982520" MODIFIED="1712602982520"/>
<node TEXT="How will this data help your stakeholders make decisions?" ID="ID_1851717045" CREATED="1712602982521" MODIFIED="1712602982521"/>
</node>
<node TEXT="Key tasks" ID="ID_1955032070" CREATED="1712602982522" MODIFIED="1712602982522">
<node TEXT="It’s important to understand the problem and any questions about your case study early on so that you’re focused on your stakeholders’ needs." ID="ID_1843511968" CREATED="1712602982522" MODIFIED="1712602982522"/>
<node TEXT="Choose a case study" ID="ID_1934189448" CREATED="1712602982523" MODIFIED="1712602982523"/>
<node TEXT="Identify the problem" ID="ID_1317264722" CREATED="1712602982524" MODIFIED="1712602982524">
<node TEXT="define the problem to be solved" FOLDED="true" ID="ID_206251154" CREATED="1706737814243" MODIFIED="1706737818717">
<node TEXT="Now that I’ve identified the issues, how can I help the stakeholders resolve their questions?" ID="ID_978436307" CREATED="1706900372175" MODIFIED="1706900372175"/>
<node TEXT="It’s impossible to solve a problem if you don’t know what it is. These are some things to consider:" ID="ID_1323635698" CREATED="1706900372167" MODIFIED="1706900372167"/>
<node TEXT="look at the current state and identify how it&apos;s different from the ideal state" ID="ID_499031072" CREATED="1706737844860" MODIFIED="1706737856525"/>
<node TEXT="examples" FOLDED="true" ID="ID_1241691363" CREATED="1706737834860" MODIFIED="1706737836749">
<node TEXT="business challenge" ID="ID_1360030312" CREATED="1706683175837" MODIFIED="1706683183813"/>
<node TEXT="obstacle" ID="ID_895442280" CREATED="1706737872508" MODIFIED="1706737875023"/>
<node TEXT="objective" ID="ID_847439212" CREATED="1706683184093" MODIFIED="1706683186798"/>
<node TEXT="question" ID="ID_1268932517" CREATED="1706683187125" MODIFIED="1706683189534"/>
</node>
<node TEXT="Six Problem Types" FOLDED="true" ID="ID_1422008398" CREATED="1706905725144" MODIFIED="1706905743103">
<node TEXT="making predictions" FOLDED="true" ID="ID_447903228" CREATED="1706905743105" MODIFIED="1706905747301">
<node TEXT="example" FOLDED="true" ID="ID_1157706572" CREATED="1706905809720" MODIFIED="1706905812335">
<node TEXT="best advertising method to bring in new customers" ID="ID_1893313488" CREATED="1706905812337" MODIFIED="1706905825140"/>
</node>
</node>
<node TEXT="categorizing things" FOLDED="true" ID="ID_1084197488" CREATED="1706905747315" MODIFIED="1706905750504">
<node TEXT="example" FOLDED="true" ID="ID_1306831751" CREATED="1706905828896" MODIFIED="1706905830724">
<node TEXT="company &apos;s goal to improve customer satisfaction." FOLDED="true" ID="ID_1840382186" CREATED="1706905830726" MODIFIED="1706905889127">
<node TEXT="analysts might classify customer service calls based on certain keywords or scores" ID="ID_1108662660" CREATED="1706905889129" MODIFIED="1706905901350"/>
</node>
</node>
</node>
<node TEXT="spotting something unusual" FOLDED="true" ID="ID_420671094" CREATED="1706905750519" MODIFIED="1706905754909">
<node TEXT="example" FOLDED="true" ID="ID_53927243" CREATED="1706905903095" MODIFIED="1706905905502">
<node TEXT="company that sells smart watches that help people monitor their health" ID="ID_1331159241" CREATED="1706905905505" MODIFIED="1706905952730"/>
</node>
</node>
<node TEXT="identifying themes" FOLDED="true" ID="ID_1039116799" CREATED="1706905754925" MODIFIED="1706905757898">
<node TEXT="example" FOLDED="true" ID="ID_1108531039" CREATED="1706905970320" MODIFIED="1706905972142">
<node TEXT="takes categorizing things a step further by grouping them into broader themes" ID="ID_996611659" CREATED="1706905972146" MODIFIED="1706906094505"/>
</node>
</node>
<node TEXT="discovering connections" FOLDED="true" ID="ID_340799564" CREATED="1706905757912" MODIFIED="1706905760910">
<node TEXT="example" FOLDED="true" ID="ID_272407001" CREATED="1706906114902" MODIFIED="1706906152949">
<node TEXT="a third party logistics company working with another company to get shipments delivered to customers on time" FOLDED="true" ID="ID_411240820" CREATED="1706906152951" MODIFIED="1706906152952">
<node TEXT="by analyzing the wait times at shipping hubs, analysts can determine the appropriate schedule changes to increase the number of on-time deliveries." ID="ID_586169261" CREATED="1706906165699" MODIFIED="1706906241133"/>
</node>
</node>
</node>
<node TEXT="finding patterns" FOLDED="true" ID="ID_1440980590" CREATED="1706905760927" MODIFIED="1706905764134">
<node TEXT="example" FOLDED="true" ID="ID_1583170380" CREATED="1706913903081" MODIFIED="1706913905271">
<node TEXT="Minimizing downtime caused by machine failure is an example of a problem requiring analysts to find patterns in data. For example, by analyzing maintenance data, they might discover that most failures happen if regular maintenance is delayed by more than a 15-day window." ID="ID_589175808" CREATED="1706913905274" MODIFIED="1706913908897"/>
</node>
</node>
</node>
</node>
<node TEXT="Take a step back and see the whole situation in context" ID="ID_1417542545" CREATED="1706900372172" MODIFIED="1706900372172"/>
<node TEXT="Focus on the actual problem and avoid any distractions" ID="ID_1264450240" CREATED="1706900372170" MODIFIED="1706900372170"/>
<node TEXT="root cause analysis, 5 whys" ID="ID_1678506013" CREATED="1706821870568" MODIFIED="1706821877941"/>
</node>
<node TEXT="Determine key stakeholders" ID="ID_1435583140" CREATED="1712602982525" MODIFIED="1712602982525">
<node TEXT="takes the time to fully understand stakeholder expectations" FOLDED="true" ID="ID_1318818589" CREATED="1706738890135" MODIFIED="1706739262020">
<node TEXT="determine:" FOLDED="true" ID="ID_231279398" CREATED="1706739385615" MODIFIED="1706739389815">
<node TEXT="who the stakeholders are" FOLDED="true" ID="ID_1830926528" CREATED="1706738897991" MODIFIED="1706739396825">
<node TEXT="help make decisions" ID="ID_1402983131" CREATED="1706738908194" MODIFIED="1706738913775"/>
<node TEXT="influence actions and strategies" ID="ID_1041077691" CREATED="1706738916909" MODIFIED="1706738921614"/>
<node TEXT="have specific goals they want to meet" ID="ID_1817704304" CREATED="1706738921632" MODIFIED="1706738926589"/>
<node TEXT="care about the project" ID="ID_287013592" CREATED="1706738926606" MODIFIED="1706738933406"/>
</node>
<node TEXT="what they want" FOLDED="true" ID="ID_578559999" CREATED="1706739402613" MODIFIED="1706739405990">
<node TEXT="What are my stakeholders saying their problems are?" ID="ID_1492721447" CREATED="1706900372174" MODIFIED="1706900372174"/>
</node>
<node TEXT="when they want it" ID="ID_979871712" CREATED="1706739406004" MODIFIED="1706739408803"/>
<node TEXT="why they wanted" ID="ID_762941532" CREATED="1706739408818" MODIFIED="1706739411801"/>
<node TEXT="how best to communicate with them" ID="ID_74060434" CREATED="1706739411818" MODIFIED="1706739416033"/>
</node>
<node TEXT="Collaborate with stakeholders and keep an open line of communication" ID="ID_529766536" CREATED="1706900372171" MODIFIED="1706900372171"/>
</node>
</node>
<node TEXT="Explore the data and establish metrics" ID="ID_1020919547" CREATED="1712602982525" MODIFIED="1712602982525"/>
</node>
<node TEXT="decides which questions to answer in order to solve the problem" FOLDED="true" ID="ID_1539863219" CREATED="1706739288991" MODIFIED="1706739296424">
<node TEXT="Highly effective questions are SMART questions:" ID="ID_931426494" CREATED="1706907953477" MODIFIED="1706907983227">
<node TEXT="Specific" FOLDED="true" ID="ID_1562684641" CREATED="1706907983245" MODIFIED="1706907987609">
<node TEXT="simple" ID="ID_1520341655" CREATED="1706913260479" MODIFIED="1706913265468"/>
<node TEXT="significant" ID="ID_1601433341" CREATED="1706913265484" MODIFIED="1706913267651"/>
<node TEXT="focused on a single topic or a few closely related ideas" ID="ID_1460860914" CREATED="1706913267667" MODIFIED="1706913362924"/>
<node TEXT="Does it" FOLDED="true" ID="ID_1272644994" CREATED="1706908015808" MODIFIED="1706908027023">
<node TEXT="address the problem" ID="ID_596886244" CREATED="1706908027027" MODIFIED="1706908047008"/>
<node TEXT=" have context" ID="ID_1547963328" CREATED="1706908047022" MODIFIED="1706908069462"/>
</node>
<node TEXT="Will it uncover a lot of information you need" ID="ID_1077412709" CREATED="1706908071821" MODIFIED="1706908102650"/>
<node TEXT="helps us collect information is relevant to what we are investigating" ID="ID_1619762352" CREATED="1706913999488" MODIFIED="1706914019649"/>
</node>
<node TEXT="Measurable" FOLDED="true" ID="ID_700508604" CREATED="1706907987626" MODIFIED="1706907991209">
<node TEXT="can be quantified and assessed" ID="ID_1678740625" CREATED="1706914043134" MODIFIED="1706914047105"/>
<node TEXT="example" FOLDED="true" ID="ID_1354729757" CREATED="1706914047607" MODIFIED="1706914051867">
<node TEXT="how many times was our video shared on social channels the first week it was posted?" ID="ID_1786720808" CREATED="1706914051870" MODIFIED="1706914067085"/>
</node>
</node>
<node TEXT="Action oriented" FOLDED="true" ID="ID_1708553320" CREATED="1706907991224" MODIFIED="1706907995213">
<node TEXT="encourage change" ID="ID_254852103" CREATED="1706914070451" MODIFIED="1706914109337"/>
<node TEXT="help to solve problems" FOLDED="true" ID="ID_511839451" CREATED="1706914132175" MODIFIED="1706914139073">
<node TEXT="problem-solving is about seeing the current state in figuring out how to transform it into the ideal future state" ID="ID_688731927" CREATED="1706914112215" MODIFIED="1706914123185"/>
</node>
<node TEXT="example" FOLDED="true" ID="ID_43070419" CREATED="1706914144888" MODIFIED="1706914151263">
<node TEXT="what design features will make our packaging easier to recycle?" ID="ID_215133659" CREATED="1706914151265" MODIFIED="1706914159494"/>
</node>
</node>
<node TEXT="Relevant" FOLDED="true" ID="ID_1500983150" CREATED="1706907995234" MODIFIED="1706907998412">
<node TEXT="matters" ID="ID_130728819" CREATED="1706913367860" MODIFIED="1706913375456"/>
<node TEXT="are important" ID="ID_1379423181" CREATED="1706913375470" MODIFIED="1706913378284"/>
<node TEXT="have significance to the problem" ID="ID_1351200162" CREATED="1706913378296" MODIFIED="1706913389178"/>
<node TEXT="example" FOLDED="true" ID="ID_1581877512" CREATED="1706914171277" MODIFIED="1706914174049">
<node TEXT="What environmental factors changed in Durham North Carolina between 1983 and 2004 that could cause Pine Barons tree frogs to disappear  from the sandhills regions?" ID="ID_81212685" CREATED="1706914174051" MODIFIED="1706914232285"/>
</node>
</node>
<node TEXT="Time bound" FOLDED="true" ID="ID_716194923" CREATED="1706907998428" MODIFIED="1706908004231">
<node TEXT="specify the time to be studied" ID="ID_1781775605" CREATED="1706914248096" MODIFIED="1706914252879"/>
<node TEXT="limits the range of possibilities and enables the data analyst to focus on relevant data" ID="ID_1274109655" CREATED="1706914258281" MODIFIED="1706914271495"/>
</node>
<node TEXT="Example scenario" FOLDED="true" ID="ID_134796513" CREATED="1706908901883" MODIFIED="1706908932700">
<node TEXT="You are three weeks into your new job as a junior data analyst. The company you work for has just collected data on their weekend sales. Your manager asks you to perform a thorough exploration of this data. To get this project started, you must ask some questions and get some information." FOLDED="true" ID="ID_592923814" CREATED="1706908934700" MODIFIED="1706908934700">
<node TEXT="Here are a few questions you might want to ask:" FOLDED="true" ID="ID_1603153683" CREATED="1706908955072" MODIFIED="1706908955072">
<node TEXT="When is the project due?" ID="ID_1875540320" CREATED="1706908955072" MODIFIED="1706908955072"/>
<node TEXT="Are there any specific challenges to keep in mind?" ID="ID_671743517" CREATED="1706908955073" MODIFIED="1706908955073"/>
<node TEXT="Who are the major stakeholders for this project, and what do they expect this project to do for them?" ID="ID_391991083" CREATED="1706908955073" MODIFIED="1706908955073"/>
<node TEXT="Who am I presenting the results to?" ID="ID_1413784336" CREATED="1706908955074" MODIFIED="1706908955074"/>
</node>
<node TEXT="Here are some examples of questions you might ask based on the suggested topics:" FOLDED="true" ID="ID_1792790135" CREATED="1706908955075" MODIFIED="1706908955075">
<node TEXT="Objectives: What are the goals of the deep dive? What, if any, questions are expected to be answered by this deep dive?" ID="ID_449767261" CREATED="1706908955075" MODIFIED="1706908955075"/>
<node TEXT="Audience: Who are the stakeholders? Who is interested or concerned about the results of this deep dive? Who is the audience for the presentation?" ID="ID_789186975" CREATED="1706908955076" MODIFIED="1706908955076"/>
<node TEXT="Time: What is the time frame for completion? By what date does this need to be done?" ID="ID_537129280" CREATED="1706908955077" MODIFIED="1706908955077"/>
<node TEXT="Resources: What resources are available to accomplish the deep dive&apos;s goals?" ID="ID_1555513453" CREATED="1706908955077" MODIFIED="1706908955077"/>
<node TEXT="Security: Who should have access to the information?" ID="ID_758481756" CREATED="1706908955078" MODIFIED="1706908955078"/>
</node>
<node TEXT="These questions can help you focus on techniques and analyses that produce results of interest to stakeholders. They also clarify the deliverable’s due date, which is important to know so you can manage your time effectively. When you start work on a project, you need to ask questions that align with the plan and the goals and help you explore the data. The more questions you ask, the more you learn about your data, and the more powerful your insights will be." ID="ID_1328220757" CREATED="1706908955079" MODIFIED="1706908955079"/>
<node TEXT="Asking thorough and specific questions means clarifying details until you get to concrete requirements. With clear requirements and goals, it’s much easier to plan and execute a successful data analysis project and avoid time-consuming problems down the road." ID="ID_923405529" CREATED="1706908955079" MODIFIED="1706908955079"/>
</node>
</node>
</node>
<node TEXT="Things to avoid when asking questions" FOLDED="true" ID="ID_1432252588" CREATED="1706908332796" MODIFIED="1706908353271">
<node TEXT="Leading questions" ID="ID_974964069" CREATED="1706908353274" MODIFIED="1706908357249"/>
<node TEXT="Closed ended questions" ID="ID_1856509088" CREATED="1706908357264" MODIFIED="1706908366861"/>
<node TEXT="Vague questions" ID="ID_427548012" CREATED="1706908366876" MODIFIED="1706908378497"/>
</node>
</node>
</node>
<node TEXT="Ask Questions To Make Data-Driven Decisions (2)" ID="ID_305826390" CREATED="1706898776793" MODIFIED="1707162211175">
<node ID="ID_463763719" CREATED="1711036857075" MODIFIED="1711036857075" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/home/module/1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/home/module/1">Ask Questions to Make Data-Driven Decisions - Ask effective questions - Week 1 | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Learning Objectives" FOLDED="true" ID="ID_1616037787" CREATED="1706899580544" MODIFIED="1706899580544">
<node TEXT="Explain the characteristics of effective questions with reference to the SMART framework" ID="ID_359665757" CREATED="1706899580544" MODIFIED="1706899580544"/>
<node TEXT="Discuss the common types of problems addressed by a data analyst" ID="ID_1120267078" CREATED="1706899580546" MODIFIED="1706899580546"/>
<node TEXT="Explain how each step of the problem-solving roadmap contributes to common analysis scenarios" ID="ID_1947268628" CREATED="1706899580548" MODIFIED="1706899580548"/>
<node TEXT="Explain the data analysis process, making specific reference to the ask, prepare, process, analyze, share, and act phases" ID="ID_1813466622" CREATED="1706899580548" MODIFIED="1706899580548"/>
<node TEXT="Describe the key ideas associated with structured thinking including the problem domain, scope of work, and context" ID="ID_1351476811" CREATED="1706899580550" MODIFIED="1706899580550"/>
</node>
<node TEXT="Glossary" FOLDED="true" ID="ID_104439750" CREATED="1707173954947" MODIFIED="1707173957333">
<node TEXT="Action-oriented question: A question whose answers lead to change" ID="ID_797478962" CREATED="1707173958929" MODIFIED="1707173958929"/>
<node TEXT="Algorithm: A process or set of rules followed for a specific task" ID="ID_1856520033" CREATED="1707173958929" MODIFIED="1707173958929"/>
<node TEXT="AVERAGE: A spreadsheet function that returns an average of the values from a selected range" ID="ID_375116695" CREATED="1707173958930" MODIFIED="1707173958930"/>
<node TEXT="Big data: Large, complex datasets typically involving long periods of time, which enable data analysts to address far-reaching business problems" ID="ID_559080174" CREATED="1707173958931" MODIFIED="1707173958931"/>
<node TEXT="Borders: Lines that can be added around two or more cells on a spreadsheet" ID="ID_851980589" CREATED="1707173958932" MODIFIED="1707173958932"/>
<node TEXT="Cell reference: A cell or a range of cells in a worksheet typically used in formulas and functions" ID="ID_1231400395" CREATED="1707173958933" MODIFIED="1707173958933"/>
<node TEXT="Cloud: A place to keep data online, rather than a computer hard drive" ID="ID_1197360313" CREATED="1707173958933" MODIFIED="1707173958933"/>
<node TEXT="COUNT: A spreadsheet function that counts the number of cells in a range that meet a specific criteria" ID="ID_748101997" CREATED="1707173958934" MODIFIED="1707173958934"/>
<node TEXT="Dashboard: A tool that monitors live, incoming data" ID="ID_935356671" CREATED="1707173958936" MODIFIED="1707173958936"/>
<node TEXT="Data analysis process: The six phases of ask, prepare, process, analyze, share, and act whose purpose is to gain insights that drive informed decision-making" ID="ID_1336333629" CREATED="1707173958937" MODIFIED="1707173958937"/>
<node TEXT="Data-inspired decision-making: The process of exploring different data sources to find out what they have in common" ID="ID_1418940138" CREATED="1707173958937" MODIFIED="1707173958937"/>
<node TEXT="Data life cycle: The sequence of stages that data experiences, which include plan, capture, manage, analyze, archive, and destroy" ID="ID_912820753" CREATED="1707173958937" MODIFIED="1707173958937"/>
<node TEXT="Equation: A calculation that involves addition, subtraction, multiplication, or division (also called a math expression)" ID="ID_599746743" CREATED="1707173958938" MODIFIED="1707173958938"/>
<node TEXT="Fill handle: A box in the lower-right-hand corner of a selected spreadsheet cell that can be dragged through neighboring cells in order to continue an instruction" ID="ID_1141270207" CREATED="1707173958939" MODIFIED="1707173958939"/>
<node TEXT="Filtering: The process of showing only the data that meets a specified criteria while hiding the rest" ID="ID_1509675713" CREATED="1707173958940" MODIFIED="1707173958940"/>
<node TEXT="Header: The first row in a spreadsheet that labels the type of data in each column" ID="ID_1922932431" CREATED="1707173958942" MODIFIED="1707173958942"/>
<node TEXT="Leading question: A question that steers people toward a certain response" ID="ID_1351450154" CREATED="1707173958944" MODIFIED="1707173958944"/>
<node TEXT="Math expression: A calculation that involves addition, subtraction, multiplication, or division (also called an equation)" ID="ID_921618901" CREATED="1707173958945" MODIFIED="1707173958945"/>
<node TEXT="Math function: A function that is used as part of a mathematical formula" ID="ID_1164473516" CREATED="1707173958945" MODIFIED="1707173958945"/>
<node TEXT="MAX: A spreadsheet function that returns the largest numeric value from a range of cells" ID="ID_215785265" CREATED="1707173958946" MODIFIED="1707173958946"/>
<node TEXT="Measurable question: A question whose answers can be quantified and assessed" ID="ID_1152872616" CREATED="1707173958946" MODIFIED="1707173958946"/>
<node TEXT="Metric: A single, quantifiable type of data that is used for measurement" ID="ID_1604021609" CREATED="1707173958947" MODIFIED="1707173958947"/>
<node TEXT="Metric goal: A measurable goal set by a company and evaluated using metrics" ID="ID_1928343390" CREATED="1707173958948" MODIFIED="1707173958948"/>
<node TEXT="MIN: A spreadsheet function that returns the smallest numeric value from a range of cells" ID="ID_1884868415" CREATED="1707173958948" MODIFIED="1707173958948"/>
<node TEXT="Open data: Data that is available to the public" ID="ID_1938815860" CREATED="1707173958950" MODIFIED="1707173958950"/>
<node TEXT="Operator: A symbol that names the operation or calculation to be performed" ID="ID_1687066669" CREATED="1707173958951" MODIFIED="1707173958951"/>
<node TEXT="Order of operations: Using parentheses to group together spreadsheet values in order to clarify the order in which operations should be performed" ID="ID_655898677" CREATED="1707173958951" MODIFIED="1707173958951"/>
<node TEXT="Pivot chart: A chart created from the fields in a pivot table" ID="ID_1218750128" CREATED="1707173958953" MODIFIED="1707173958953"/>
<node TEXT="Pivot table: A data summarization tool used to sort, reorganize, group, count, total, or average data" ID="ID_91358665" CREATED="1707173958953" MODIFIED="1707173958953"/>
<node TEXT="Problem domain: The area of analysis that encompasses every activity affecting or affected by a problem" ID="ID_507282383" CREATED="1707173958953" MODIFIED="1707173958953"/>
<node TEXT="Problem types: The various problems that data analysts encounter, including categorizing things, discovering connections, finding patterns, identifying themes, making predictions, and spotting something unusual" ID="ID_410156147" CREATED="1707173958954" MODIFIED="1707173958954"/>
<node TEXT="Qualitative data: A subjective and explanatory measure of a quality or characteristic" FOLDED="true" ID="ID_572974285" CREATED="1707173958956" MODIFIED="1707173958956">
<node TEXT="Nominal data: A type of qualitative data that is categorized without a set order" ID="ID_741688432" CREATED="1707259637719" MODIFIED="1707259637719"/>
<node TEXT="Ordinal data: Qualitative data with a set order or scale" ID="ID_1599226023" CREATED="1707259637726" MODIFIED="1707259637726"/>
</node>
<node TEXT="Quantitative data: A specific and objective measure, such as a number, quantity, or range" FOLDED="true" ID="ID_209744112" CREATED="1707173958956" MODIFIED="1707173958956">
<node TEXT="Discrete data: Data that is counted and has a limited number of values" ID="ID_1997554382" CREATED="1707259637691" MODIFIED="1707259637691"/>
<node TEXT="Continuous data: Data that is measured and can have almost any numeric value" ID="ID_1661336324" CREATED="1707259637669" MODIFIED="1707259637669"/>
</node>
<node TEXT="Range: A collection of two or more cells in a spreadsheet" ID="ID_1120810214" CREATED="1707173958957" MODIFIED="1707173958957"/>
<node TEXT="Reframing: Restating a problem or challenge, then redirecting it toward a potential resolution" ID="ID_1932186589" CREATED="1707173958957" MODIFIED="1707173958957"/>
<node TEXT="Relevant question: A question that has significance to the problem to be solved" ID="ID_1269231942" CREATED="1707173958958" MODIFIED="1707173958958"/>
<node TEXT="Report: A static collection of data periodically given to stakeholders" ID="ID_1986987605" CREATED="1707173958958" MODIFIED="1707173958958"/>
<node TEXT="Return on investment (ROI): A formula that uses the metrics of investment and profit to evaluate the success of an investment" ID="ID_1838653230" CREATED="1707173958959" MODIFIED="1707173958959"/>
<node TEXT="Revenue: The total amount of income generated by the sale of goods or services" ID="ID_1240667104" CREATED="1707173958959" MODIFIED="1707173958959"/>
<node TEXT="Scope of work (SOW): An agreed-upon outline of the tasks to be performed during a project" ID="ID_380999545" CREATED="1707173958960" MODIFIED="1707173958960"/>
<node TEXT="Small data: Small, specific data points typically involving a short period of time, which are useful for making day-to-day decisions" ID="ID_1547994106" CREATED="1707173958962" MODIFIED="1707173958962"/>
<node TEXT="SMART methodology: A tool for determining a question’s effectiveness based on whether it is specific, measurable, action-oriented, relevant, and time-bound" ID="ID_1724826933" CREATED="1707173958962" MODIFIED="1707173958962"/>
<node TEXT="Sorting: The process of arranging data into a meaningful order to make it easier to understand, analyze, and visualize" ID="ID_1473809352" CREATED="1707173958962" MODIFIED="1707173958962"/>
<node TEXT="Specific question: A question that is simple, significant, and focused on a single topic or a few closely related ideas" ID="ID_1525638821" CREATED="1707173958964" MODIFIED="1707173958964"/>
<node TEXT="Stakeholders: people that have invested time, interest, and resources into the projects you&apos;ll be working on as a data analyst" ID="ID_1964790280" CREATED="1707174007475" MODIFIED="1707174043105"/>
<node TEXT="Structured thinking: The process of recognizing the current problem or situation, organizing available information, revealing gaps and opportunities, and identifying options" ID="ID_532594827" CREATED="1707173958964" MODIFIED="1707173958964"/>
<node TEXT="SUM: A spreadsheet function that adds the values of a selected range of cells" ID="ID_1769360701" CREATED="1707173958965" MODIFIED="1707173958965"/>
<node TEXT="Time-bound question: A question that specifies a timeframe to be studied" FOLDED="true" ID="ID_1152589010" CREATED="1707173958967" MODIFIED="1707173958967">
<node TEXT="Turnover rate: The rate at which employees voluntarily leave a company" ID="ID_1574792822" CREATED="1707173958968" MODIFIED="1707173958968"/>
</node>
<node TEXT="Unfair question: A question that makes assumptions or is difficult to answer honestly" ID="ID_33705405" CREATED="1707173958969" MODIFIED="1707173958969"/>
</node>
<node TEXT="Module 1: Ask effective questions" ID="ID_191148935" CREATED="1706898791480" MODIFIED="1706899890331"/>
<node TEXT="Module 2: Make data-driven decisions" FOLDED="true" ID="ID_699238847" CREATED="1706899905627" MODIFIED="1706899929286">
<node TEXT="data-driven decision-making" FOLDED="true" ID="ID_1705002381" CREATED="1706683843870" MODIFIED="1706683855328">
<node TEXT="using facts to guide business strategy" ID="ID_1055208674" CREATED="1706683857158" MODIFIED="1706683911903"/>
<node TEXT="limited by the quantity and quality of readily available data" FOLDED="true" ID="ID_1198577673" CREATED="1706918512887" MODIFIED="1706918521329">
<node TEXT="if sufficient, this approach can far improve decision-making" ID="ID_1046757986" CREATED="1706918526891" MODIFIED="1706918537892"/>
<node TEXT="if data is insufficient or biased, this can create problems for decision-makers" ID="ID_137860388" CREATED="1706918537906" MODIFIED="1706918555494"/>
</node>
<node TEXT="potential dangers of relying entirely on it" FOLDED="true" ID="ID_802593746" CREATED="1706918561990" MODIFIED="1706918588800">
<node TEXT="overreliance on historical data" ID="ID_1169062819" CREATED="1706918591481" MODIFIED="1706918601683"/>
<node TEXT="tendency to ignore qualitative insights" ID="ID_934982622" CREATED="1706918601700" MODIFIED="1706918607279"/>
<node TEXT="potential biases in data collection and analysis" ID="ID_306121011" CREATED="1706918607295" MODIFIED="1706918613717"/>
</node>
<node TEXT="example" FOLDED="true" ID="ID_1028109109" CREATED="1706918619439" MODIFIED="1706918623285">
<node TEXT="A/B testing is a simple example of collecting data for data-driven decision-making. For example, a website that sells widgets has an idea for a new website layout they think will result in more people buying widgets. For two weeks, half of their website visitors are directed to the old site; the other half are directed to the new site. After those two weeks, the analyst gathers the data about their website visitors and the number of widgets sold for analysis. This helps the analyst understand which website layout resulted in more widget sales. If the new website performed better in producing widget sales, then the company can confidently make the decision to use the new layout!" ID="ID_981403662" CREATED="1706918623287" MODIFIED="1706918648914"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_383565790" CREATED="1706918498690" MODIFIED="1706918500514">
<node ID="ID_1120885248" CREATED="1706732989435" MODIFIED="1706732989435" LINK="https://www.coursera.org/learn/foundations-data/lecture/gT8Bo/how-data-informs-better-decisions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/lecture/gT8Bo/how-data-informs-better-decisions">How data informs better decisions | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Steps" FOLDED="true" ID="ID_1024484734" CREATED="1706733010065" MODIFIED="1706733011971">
<node TEXT="figuring out the business need, typically problem that needs to be solved" ID="ID_710870821" CREATED="1706733012979" MODIFIED="1706733043267"/>
<node TEXT="data analyst find data, analyzes it, and uses it to uncover trends, patterns in relationships" ID="ID_71296836" CREATED="1706733045167" MODIFIED="1706733097170"/>
</node>
<node TEXT="include insights from people who are familiar with business problem" FOLDED="true" ID="ID_1111974746" CREATED="1706733132730" MODIFIED="1706733140828">
<node TEXT="subject matter experts" ID="ID_1508396592" CREATED="1706733142981" MODIFIED="1706733146027"/>
</node>
</node>
<node TEXT="compared to" FOLDED="true" ID="ID_483232017" CREATED="1706918450103" MODIFIED="1706918455116">
<node ID="ID_1860034079" CREATED="1706918459980" MODIFIED="1706918459980" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/jnT25/data-trials-and-triumphs"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/jnT25/data-trials-and-triumphs">Data trials and triumphs | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="data inspired decision-making" FOLDED="true" ID="ID_1600372553" CREATED="1706917887503" MODIFIED="1706917925285">
<node TEXT="explores different data sources to find out what they have in common" ID="ID_1059475262" CREATED="1706917925287" MODIFIED="1706917936919"/>
<node TEXT="create space for people using data to consider a broader range of ideas:" FOLDED="true" ID="ID_523939725" CREATED="1706918702512" MODIFIED="1706918717684">
<node TEXT="drawing on comparisons to related concepts" ID="ID_1138359399" CREATED="1706918717686" MODIFIED="1706918724895"/>
<node TEXT="giving weight to feelings and experiences" ID="ID_1505184184" CREATED="1706918724909" MODIFIED="1706918729481"/>
<node TEXT="considering other qualities that may be more difficult to measure" ID="ID_1936467711" CREATED="1706918729498" MODIFIED="1706918753087"/>
</node>
<node TEXT="can avoid some of the pitfalls that data-driven decisions might be prone to" ID="ID_1827215850" CREATED="1706918764321" MODIFIED="1706918777893"/>
<node TEXT="example" FOLDED="true" ID="ID_976602387" CREATED="1706918777920" MODIFIED="1706918780485">
<node TEXT="A customer support center gathers customer satisfaction data (often known as a “CSAT” score). They use a simple 1–10 score along with a qualitative description in which the customer describes their experience. The customer support center manager wants to improve customer experience, so they set a goal to improve the CSAT score. They start by analyzing the CSAT scores and reading each of the descriptions from the customers. Additionally, they interview the people working in the customer support center. From there, the manager formulates a strategy and decides what needs to improve the most in order to raise customer satisfaction scores. While the manager certainly relies on the CSAT data in the decision-making process, input of support center representatives and other qualitative information informs the approach as well." ID="ID_1781768935" CREATED="1706918780487" MODIFIED="1706918796108"/>
</node>
</node>
<node TEXT="knowledge" FOLDED="true" ID="ID_419013357" CREATED="1706918249359" MODIFIED="1706918253280">
<node TEXT="information" FOLDED="true" ID="ID_933528308" CREATED="1706918253282" MODIFIED="1706918255482">
<node TEXT="data" ID="ID_185397337" CREATED="1706918255483" MODIFIED="1706918257510"/>
</node>
</node>
<node TEXT="Tools for visualizing data" FOLDED="true" ID="ID_169562292" CREATED="1706986383431" MODIFIED="1706986393051">
<node TEXT="spreadsheets" FOLDED="true" ID="ID_580645553" CREATED="1706986393056" MODIFIED="1706986403610">
<node TEXT="static charts and graphs" ID="ID_1363172762" CREATED="1706986403612" MODIFIED="1706986426837"/>
</node>
<node TEXT="Tableau" FOLDED="true" ID="ID_1168616332" CREATED="1706986431839" MODIFIED="1706986435811">
<node FOLDED="true" ID="ID_1150468520" CREATED="1709356147521" MODIFIED="1709356147521" LINK="https://identity.idp.tableau.com/login?state=hKFo2SBueGNFaUNiUVd2Ri1BdURzSzhFZ2I1VVljaEIxV2lYY6FupWxvZ2luo3RpZNkgdVFrSklVaDFpQjhVYXRKdHBhb3RHTkFwM25WT0x2c1GjY2lk2SB3Y1M3SHdZOThxZGZnQlJFSFQ3WG9sbjdpcGM3NVUwYQ&amp;client=wcS7HwY98qdfgBREHT7Xoln7ipc75U0a&amp;protocol=oauth2&amp;scope=openid%20email%20profile&amp;response_type=code&amp;redirect_uri=https%3A%2F%2Fpublic.tableau.com%2Fpublic%2Fapis%2Fauth%2Fprovision&amp;nonce=oz59Uvtsu-4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://identity.idp.tableau.com/login?state=hKFo2SBueGNFaUNiUVd2Ri1BdURzSzhFZ2I1VVljaEIxV2lYY6FupWxvZ2luo3RpZNkgdVFrSklVaDFpQjhVYXRKdHBhb3RHTkFwM25WT0x2c1GjY2lk2SB3Y1M3SHdZOThxZGZnQlJFSFQ3WG9sbjdpcGM3NVUwYQ&amp;client=wcS7HwY98qdfgBREHT7Xoln7ipc75U0a&amp;protocol=oauth2&amp;scope=openid%20email%20profile&amp;response_type=code&amp;redirect_uri=https%3A%2F%2Fpublic.tableau.com%2Fpublic%2Fapis%2Fauth%2Fprovision&amp;nonce=oz59Uvtsu-4">Tableau - Sign In</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_323098144" CREATED="1709356150017" MODIFIED="1709356152651"/>
<node TEXT="Lucydog1*" ID="ID_253106479" CREATED="1709356153119" MODIFIED="1709356157675"/>
</node>
<node TEXT="interactive visualizations such as live dashboards" FOLDED="true" ID="ID_1332739621" CREATED="1706986435814" MODIFIED="1706986451042">
<node TEXT="dashboard" FOLDED="true" ID="ID_619073993" CREATED="1706986518015" MODIFIED="1706986520814">
<node TEXT="reference" FOLDED="true" ID="ID_1662174576" CREATED="1706987392842" MODIFIED="1706987395057">
<node ID="ID_331183193" CREATED="1706986551464" MODIFIED="1706986551464" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/Jvsne/design-compelling-dashboards"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/Jvsne/design-compelling-dashboards">Design compelling dashboards | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="single point of access for managing a businesses information" ID="ID_718295481" CREATED="1706987343773" MODIFIED="1706987362666"/>
<node TEXT="tool that monitors live, incoming data" ID="ID_457326311" CREATED="1706986520817" MODIFIED="1706987050064"/>
<node TEXT="easy access" ID="ID_1071692303" CREATED="1706988819436" MODIFIED="1706988823542"/>
<node TEXT="low maintenance" ID="ID_226117959" CREATED="1706988823892" MODIFIED="1706988829013"/>
<node TEXT="it organizes information from multiple data sets into one central location" ID="ID_1511775363" CREATED="1706986526225" MODIFIED="1706986534813"/>
<node TEXT="used to track, analyze, and visualize data in order to answer questions and solve problems" ID="ID_1415894514" CREATED="1706986534836" MODIFIED="1706987041453"/>
</node>
<node TEXT="types" FOLDED="true" ID="ID_704927741" CREATED="1706987400805" MODIFIED="1706987403630">
<node TEXT="strategic" FOLDED="true" ID="ID_473087716" CREATED="1706987403633" MODIFIED="1706987405625">
<node TEXT="focuses on long-term goals and strategies at the highest level of metrics" ID="ID_747844228" CREATED="1706987412417" MODIFIED="1706987421448"/>
</node>
<node TEXT="operational" FOLDED="true" ID="ID_1278216140" CREATED="1706987405640" MODIFIED="1706987407612">
<node TEXT="short-term performance tracking and intermediate goals" ID="ID_251783177" CREATED="1706987423418" MODIFIED="1706987429458"/>
<node TEXT="most common type of dashboard" ID="ID_1836806828" CREATED="1706988038422" MODIFIED="1706988048640"/>
</node>
<node TEXT="analytical" FOLDED="true" ID="ID_97715143" CREATED="1706987407629" MODIFIED="1706987410048">
<node TEXT="consists of the data sets in the mathematics used in these sets" ID="ID_1254119678" CREATED="1706987431037" MODIFIED="1706987442654"/>
<node TEXT="created and maintained by data science teams" ID="ID_1747199285" CREATED="1706988142053" MODIFIED="1706988150630"/>
<node TEXT="rarely shared with upper management as they can be very difficult understand" ID="ID_1066336625" CREATED="1706988150645" MODIFIED="1706988183057"/>
</node>
</node>
<node TEXT="process for creating" FOLDED="true" ID="ID_1893320076" CREATED="1706987262259" MODIFIED="1706987270284">
<node TEXT="identify the stakeholders who need to see the data and how they will use it" ID="ID_681419623" CREATED="1706987270287" MODIFIED="1706987277832"/>
<node TEXT="design the dashboard (what should be displayed)" ID="ID_853298096" CREATED="1706987277860" MODIFIED="1706987287048"/>
<node TEXT="create mockups if desired" ID="ID_1709612575" CREATED="1706987289449" MODIFIED="1706987293420"/>
<node TEXT="select the visualizations" ID="ID_1020170649" CREATED="1706987293435" MODIFIED="1706987300048"/>
<node TEXT="create filters as needed" ID="ID_1543436466" CREATED="1706987301216" MODIFIED="1706987313452"/>
</node>
<node TEXT="layout" FOLDED="true" ID="ID_1359534230" CREATED="1710352884456" MODIFIED="1710352889558">
<node TEXT="floating" FOLDED="true" ID="ID_758808822" CREATED="1710352890069" MODIFIED="1710352899500">
<node TEXT="layer items over other objects" ID="ID_1241192197" CREATED="1710352899502" MODIFIED="1710352907236"/>
</node>
<node TEXT="tiled" FOLDED="true" ID="ID_1761367350" CREATED="1710352909662" MODIFIED="1710352923870">
<node TEXT="automatically resize itself based on the overall dashboard size" ID="ID_477609382" CREATED="1710352926396" MODIFIED="1710352934143"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Terms" FOLDED="true" ID="ID_407783422" CREATED="1706921490820" MODIFIED="1706921494477">
<node TEXT="Algorithm" FOLDED="true" ID="ID_1643845149" CREATED="1706988516444" MODIFIED="1706988546617">
<node TEXT="A process or set of rules followed for a specific task" ID="ID_44454926" CREATED="1706988546617" MODIFIED="1706988546617"/>
</node>
<node TEXT="Big data" FOLDED="true" ID="ID_141452137" CREATED="1706988516444" MODIFIED="1706988546613">
<node TEXT="Large, complex datasets typically involving long periods of time, which enable data analysts to address far-reaching business problems" ID="ID_402860301" CREATED="1706988546614" MODIFIED="1706988546614"/>
</node>
<node TEXT="Dashboard" FOLDED="true" ID="ID_1171265113" CREATED="1706988516444" MODIFIED="1706988546612">
<node TEXT="A tool that monitors live, incoming data" ID="ID_430314596" CREATED="1706988546613" MODIFIED="1706988546613"/>
</node>
<node TEXT="data" FOLDED="true" ID="ID_1676117293" CREATED="1706921437988" MODIFIED="1706921439581">
<node TEXT="a collection of facts" ID="ID_295659514" CREATED="1706921440680" MODIFIED="1706921452750">
<font BOLD="false" ITALIC="true"/>
</node>
<node TEXT="can reveal important patterns, trends, and insights" ID="ID_1010071289" CREATED="1706921465820" MODIFIED="1706921475120"/>
<node TEXT="data types" FOLDED="true" ID="ID_1632713148" CREATED="1706920551709" MODIFIED="1706920559725">
<node ID="ID_836043489" CREATED="1706920664726" MODIFIED="1706920664726" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/q79uq/qualitative-and-quantitative-data-in-business"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/q79uq/qualitative-and-quantitative-data-in-business">Qualitative and quantitative data in business | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="data analysts will generally use both types of data in their work" ID="ID_1492744841" CREATED="1706921355916" MODIFIED="1706921378053"/>
<node TEXT="quantitative data" FOLDED="true" ID="ID_274812895" CREATED="1706920559727" MODIFIED="1706920563309">
<node TEXT="specific and objective measures of numerical facts" ID="ID_965763640" CREATED="1706920563312" MODIFIED="1706920575128"/>
<node TEXT="gives you the what" ID="ID_572961795" CREATED="1706921316444" MODIFIED="1706921319173"/>
<node TEXT="tools for gathering" FOLDED="true" ID="ID_1948223688" CREATED="1706920679013" MODIFIED="1706920686894">
<node TEXT="structured interviews" ID="ID_1295525007" CREATED="1706920686897" MODIFIED="1706920693484"/>
<node TEXT="surveys" ID="ID_288106407" CREATED="1706920693495" MODIFIED="1706920695682"/>
<node TEXT="polls" ID="ID_1325691235" CREATED="1706920695694" MODIFIED="1706920699526"/>
</node>
</node>
<node TEXT="qualitative data" FOLDED="true" ID="ID_1907345188" CREATED="1706920577526" MODIFIED="1706920581330">
<node TEXT="subjective or explanatory measures of qualities and characteristics are things that can be measured with numerical data" ID="ID_1204192" CREATED="1706920581332" MODIFIED="1706920595095"/>
<node TEXT="gives you the why" FOLDED="true" ID="ID_1758117750" CREATED="1706921292100" MODIFIED="1706921311845">
<node TEXT="reason or more through explanation" ID="ID_12892767" CREATED="1706921330680" MODIFIED="1706921337317"/>
</node>
<node TEXT="tools for gathering" FOLDED="true" ID="ID_1998190931" CREATED="1706920706314" MODIFIED="1706920710494">
<node TEXT="focus groups" ID="ID_1643490261" CREATED="1706920710498" MODIFIED="1706920716685"/>
<node TEXT="social media text analysis" ID="ID_167557239" CREATED="1706920716697" MODIFIED="1706920720487"/>
<node TEXT="in person interviews" ID="ID_533981578" CREATED="1706920720502" MODIFIED="1706920726532"/>
</node>
</node>
</node>
</node>
<node TEXT="Data-inspired decision-making" FOLDED="true" ID="ID_110758193" CREATED="1706988516448" MODIFIED="1706988546610">
<node TEXT="The process of exploring different data sources to find out what they have in common" ID="ID_906000226" CREATED="1706988546611" MODIFIED="1706988546611"/>
</node>
<node TEXT="Metric" FOLDED="true" ID="ID_1734706830" CREATED="1706988516448" MODIFIED="1706988546608">
<node TEXT="A single, quantifiable type of data that is used for measurement" ID="ID_305198585" CREATED="1706988546609" MODIFIED="1706988546609"/>
</node>
<node TEXT="Metric goal" FOLDED="true" ID="ID_243433696" CREATED="1706988516450" MODIFIED="1706988546606">
<node TEXT="A measurable goal set by a company and evaluated using metrics" ID="ID_1336837343" CREATED="1706988546607" MODIFIED="1706988546607"/>
</node>
<node TEXT="Pivot chart" FOLDED="true" ID="ID_526108188" CREATED="1706988516450" MODIFIED="1706988546604">
<node TEXT="A chart created from the fields in a pivot table" ID="ID_773112685" CREATED="1706988546604" MODIFIED="1706988546604"/>
</node>
<node TEXT="Pivot table" FOLDED="true" ID="ID_621697110" CREATED="1706988516452" MODIFIED="1706988546602">
<node TEXT="A data summarization tool used to sort, reorganize, group, count, total, or average data" ID="ID_1753045677" CREATED="1706988546602" MODIFIED="1706988546602"/>
</node>
<node TEXT="Problem types" FOLDED="true" ID="ID_573455679" CREATED="1706988516452" MODIFIED="1706988546600">
<node TEXT="The various problems that data analysts encounter, including categorizing things, discovering connections, finding patterns, identifying themes, making predictions, and spotting something unusual" ID="ID_1213505734" CREATED="1706988546600" MODIFIED="1706988546600"/>
</node>
<node TEXT="Qualitative data" FOLDED="true" ID="ID_1536892349" CREATED="1706988516454" MODIFIED="1706988546598">
<node TEXT="A subjective and explanatory measure of a quality or characteristic" ID="ID_1012453000" CREATED="1706988546599" MODIFIED="1706988546599"/>
</node>
<node TEXT="Quantitative data" FOLDED="true" ID="ID_77809682" CREATED="1706988516455" MODIFIED="1706988546598">
<node TEXT="A specific and objective measure, such as a number, quantity, or range" ID="ID_204756081" CREATED="1706988546598" MODIFIED="1706988546598"/>
</node>
<node TEXT="Report" FOLDED="true" ID="ID_1104885354" CREATED="1706988516457" MODIFIED="1706988546595">
<node TEXT="A static collection of data periodically given to stakeholders" ID="ID_1776497993" CREATED="1706988546596" MODIFIED="1706988546596"/>
</node>
<node TEXT="Return on investment (ROI)" FOLDED="true" ID="ID_12435592" CREATED="1706988516458" MODIFIED="1706988546593">
<node TEXT="A formula that uses the metrics of investment and profit to evaluate the success of an investment" ID="ID_235202007" CREATED="1706988546593" MODIFIED="1706988546593"/>
</node>
<node TEXT="Revenue" FOLDED="true" ID="ID_1955159902" CREATED="1706988516459" MODIFIED="1706988546592">
<node TEXT="The total amount of income generated by the sale of goods or services" ID="ID_1582593041" CREATED="1706988546592" MODIFIED="1706988546592"/>
</node>
<node TEXT="Small data" FOLDED="true" ID="ID_920202501" CREATED="1706988516460" MODIFIED="1706988546588">
<node TEXT="Small, specific data points typically involving a short period of time, which are useful for making day-to-day decisions" ID="ID_940460952" CREATED="1706988546590" MODIFIED="1706988546590"/>
</node>
</node>
<node TEXT="Mathematical thinking" ID="ID_632521575" CREATED="1706988972637" MODIFIED="1706988977397"/>
<node TEXT="Big and small data" FOLDED="true" ID="ID_1853384917" CREATED="1706989087244" MODIFIED="1706989091223">
<node TEXT="Small data" FOLDED="true" ID="ID_414053646" CREATED="1706989091227" MODIFIED="1706989095048">
<node TEXT="describes a data set made of specific metrics over a short, well-defined time period" ID="ID_887399849" CREATED="1706989095051" MODIFIED="1706989161998"/>
<node TEXT="usually organized and analyzed in spreadsheets" ID="ID_1930784176" CREATED="1706989162971" MODIFIED="1706989175216"/>
<node TEXT="usually already a manageable size for analysis" ID="ID_261854916" CREATED="1706989193825" MODIFIED="1706989199453"/>
<node TEXT="likely to be used by small and midsize businesses" ID="ID_1207472432" CREATED="1706989175230" MODIFIED="1706989184017"/>
<node TEXT="simple to collect, store, manage, sort, and visually represent" ID="ID_1291036682" CREATED="1706989184033" MODIFIED="1706989193809"/>
<node TEXT="useful when making day-to-day decisions" ID="ID_550436004" CREATED="1706994468295" MODIFIED="1706994473448"/>
</node>
<node TEXT="Big data" FOLDED="true" ID="ID_448336051" CREATED="1706989202240" MODIFIED="1706989205024">
<node TEXT="reference" FOLDED="true" ID="ID_591343767" CREATED="1706995003958" MODIFIED="1706995008361">
<node TEXT="describes large, less specific data sets that cover a long time period" ID="ID_1036756360" CREATED="1706989205027" MODIFIED="1706990226691"/>
<node TEXT="usually kept in a database and queried" ID="ID_1771059802" CREATED="1706989212830" MODIFIED="1706993723713"/>
<node TEXT="likely to be used by large organizations" ID="ID_1910042371" CREATED="1706993723744" MODIFIED="1706993729718"/>
<node TEXT="takes a lot of effort to collect, store, manage, sort, and visually represent" ID="ID_1491911506" CREATED="1706993729734" MODIFIED="1706993741317"/>
<node TEXT="usually needs to be broken into smaller pieces in order to be organized and analyzed effectively for decision-making" ID="ID_889421216" CREATED="1706993741348" MODIFIED="1706993767353"/>
</node>
<node TEXT="challenges" FOLDED="true" ID="ID_920911297" CREATED="1706995016763" MODIFIED="1706995019777">
<node TEXT="data overload, too much unimportant or relevant information" ID="ID_1664793014" CREATED="1706995019780" MODIFIED="1706995036921"/>
<node TEXT="important data can be buried with nonimportant data, which makes it harder to find and use" ID="ID_340160795" CREATED="1706995036941" MODIFIED="1706995057756"/>
<node TEXT="needed data isn&apos;t always easily accessible" ID="ID_1086885154" CREATED="1706995058955" MODIFIED="1706995067728"/>
<node TEXT="current technology tools and solutions still struggle to provide measurable and reportable data, which can lead to unfair algorithmic bias" ID="ID_1222034427" CREATED="1706995067746" MODIFIED="1706995086128"/>
<node TEXT="gaps in many big data business solutions" ID="ID_1996880581" CREATED="1706995086156" MODIFIED="1706995092357"/>
</node>
<node TEXT="benefits" FOLDED="true" ID="ID_191397046" CREATED="1706995094359" MODIFIED="1706995097525">
<node TEXT="companies identify more efficient ways of doing business" ID="ID_745593868" CREATED="1706995097528" MODIFIED="1706995173545"/>
<node TEXT="spot trends of customer buying patterns" FOLDED="true" ID="ID_1789830109" CREATED="1706995173565" MODIFIED="1706995186146">
<node TEXT="create new products and solutions" ID="ID_1163093333" CREATED="1706995186148" MODIFIED="1706995190723"/>
</node>
<node TEXT="improve understanding of current market conditions" ID="ID_590659371" CREATED="1706995190738" MODIFIED="1706995201154"/>
<node TEXT="track their online presence, feedback from customers" FOLDED="true" ID="ID_1050739858" CREATED="1706995203179" MODIFIED="1706995224959">
<node TEXT="provides information they need to improve and protect their brand" ID="ID_1024333027" CREATED="1706995224962" MODIFIED="1706995233549"/>
</node>
</node>
<node TEXT="V words for big data" FOLDED="true" ID="ID_1830808693" CREATED="1706995248757" MODIFIED="1706995262926">
<node TEXT="volume" FOLDED="true" ID="ID_1169512044" CREATED="1706995262929" MODIFIED="1706995265154">
<node TEXT="the amount of data" ID="ID_401558440" CREATED="1706995265157" MODIFIED="1706995268557"/>
</node>
<node TEXT="variety" FOLDED="true" ID="ID_1010516974" CREATED="1706995270157" MODIFIED="1706995272157">
<node TEXT="the different kinds of data" ID="ID_1796606079" CREATED="1706995272159" MODIFIED="1706995275756"/>
</node>
<node TEXT="velocity" FOLDED="true" ID="ID_1452416614" CREATED="1706995277554" MODIFIED="1706995279774">
<node TEXT="how fast the data can be processed" ID="ID_1441135056" CREATED="1706995279777" MODIFIED="1706995284747"/>
</node>
<node TEXT="veracity" FOLDED="true" ID="ID_1239458606" CREATED="1706995286530" MODIFIED="1706995290563">
<node TEXT="the quality and reliability of the data" ID="ID_1727820652" CREATED="1706995290566" MODIFIED="1706995296352"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Module 3: Spreadsheet magic" FOLDED="true" ID="ID_1527964423" CREATED="1706899929302" MODIFIED="1706900013626">
<node TEXT="resolving spreadsheet errors" FOLDED="true" ID="ID_1143252442" CREATED="1707081025992" MODIFIED="1707081032706">
<node TEXT="https://docs.google.com/spreadsheets/d/1IziOivcTp1O5xwWVEmG1RihXLdkCfKOmzFccN_hf5B0/edit?usp=sharing" ID="ID_380130485" CREATED="1707081033727" MODIFIED="1707081033727" LINK="https://docs.google.com/spreadsheets/d/1IziOivcTp1O5xwWVEmG1RihXLdkCfKOmzFccN_hf5B0/edit?usp=sharing"/>
</node>
<node TEXT="Problem Domain:" FOLDED="true" ID="ID_545757643" CREATED="1707155100659" MODIFIED="1707155171891">
<node ID="ID_676946152" CREATED="1707155174659" MODIFIED="1707155174659"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      the specific area of analysis that encompasses every activity affecting or affected by the problem
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="structured thinking" FOLDED="true" ID="ID_1267049216" CREATED="1707155288875" MODIFIED="1707155294462">
<node TEXT="the process of" FOLDED="true" ID="ID_507689984" CREATED="1707155294466" MODIFIED="1707155417532">
<node TEXT="recognizing the current problem or situation" ID="ID_252807005" CREATED="1707155417533" MODIFIED="1707155417534"/>
<node TEXT="organizing available information" ID="ID_1481413585" CREATED="1707155367152" MODIFIED="1707155367152"/>
<node TEXT="revealing gaps and opportunities" ID="ID_1218231748" CREATED="1707155367153" MODIFIED="1707155367153"/>
<node TEXT="identifying the options" ID="ID_1744803761" CREATED="1707155367154" MODIFIED="1707155429804"/>
</node>
</node>
<node TEXT="scope of work (SOW)" FOLDED="true" ID="ID_648333676" CREATED="1707155770445" MODIFIED="1707155784659">
<node TEXT="an agreed-upon outline of the work you&apos;re going to perform on a project" FOLDED="true" ID="ID_1677808917" CREATED="1707155784663" MODIFIED="1707155792124">
<node TEXT="At a minimum, any SOW should answer all the relevant questions below. Note that these areas may differ depending on the project. But at their core, the SOW document should always serve the same purpose by containing information that is specific, relevant, and accurate. If something changes in the project, your SOW should reflect those changes." ID="ID_242024503" CREATED="1707157344065" MODIFIED="1707157362875"/>
</node>
<node TEXT="scope" FOLDED="true" ID="ID_956070844" CREATED="1707157402985" MODIFIED="1707157406061">
<node TEXT="everything that you are expected to complete or accomplish, defined to a level of detail that doesn&apos;t leave any ambiguity or confusion about whether a given task or item is part of the project are not" ID="ID_1801025818" CREATED="1707157406063" MODIFIED="1707157428288"/>
<node TEXT="use quantitative statements whenever possible" ID="ID_913855874" CREATED="1707157468493" MODIFIED="1707157474088"/>
</node>
<node TEXT="includes" FOLDED="true" ID="ID_1592581688" CREATED="1707155802394" MODIFIED="1707155805236">
<node TEXT="deliverables" FOLDED="true" ID="ID_585859191" CREATED="1707156782082" MODIFIED="1707156785427">
<node TEXT="What work is being done, and what things are being created as a result of this project? When the project is complete, what are you expected to deliver to the stakeholders? Be specific here. Will you collect data for this project? How much, or for how long?" FOLDED="true" ID="ID_1668174494" CREATED="1707157221273" MODIFIED="1707157221273">
<node TEXT="Avoid vague statements. For example, “fixing traffic problems” doesn’t specify the scope. This could mean anything from filling in a few potholes to building a new overpass. Be specific! Use numbers and aim for hard, measurable goals and objectives. For example: “Identify top 10 issues with traffic patterns within the city limits, and identify the top 3 solutions that are most cost-effective for reducing traffic congestion.”" ID="ID_108588194" CREATED="1707157264852" MODIFIED="1707157264852"/>
</node>
<node TEXT="goals" ID="ID_1856054011" CREATED="1707156934052" MODIFIED="1707156935641"/>
<node TEXT="work details" ID="ID_291994995" CREATED="1707155805240" MODIFIED="1707155809030"/>
</node>
<node TEXT="milestones" FOLDED="true" ID="ID_128265793" CREATED="1707156787249" MODIFIED="1707156789828">
<node TEXT="This is closely related to your timeline. What are the major milestones for progress in your project? How do you know when a given part of the project is considered complete?" FOLDED="true" ID="ID_1507221698" CREATED="1707157283466" MODIFIED="1707157283466">
<node TEXT="Milestones can be identified by you, by stakeholders, or by other team members such as the Project Manager. Smaller examples might include incremental steps in a larger project like “Collect and process 50% of required data (100 survey responses)”, but may also be larger examples like ”complete initial data analysis report” or “deliver completed dashboard visualizations and analysis reports to stakeholders”." ID="ID_1549400695" CREATED="1707157292647" MODIFIED="1707157292647"/>
</node>
</node>
<node TEXT="timeline" FOLDED="true" ID="ID_1270627561" CREATED="1707156785443" MODIFIED="1707156787233">
<node TEXT="Your timeline will be closely tied to the milestones you create for your project. The timeline is a way of mapping expectations for how long each step of the process should take. The timeline should be specific enough to help all involved decide if a project is on schedule. When will the deliverables be completed? How long do you expect the project will take to complete? If all goes as planned, how long do you expect each component of the project will take? When can we expect to reach each milestone?" ID="ID_196197143" CREATED="1707157310647" MODIFIED="1707157310647"/>
<node TEXT="schedules" ID="ID_1854389655" CREATED="1707155809043" MODIFIED="1707155811227"/>
</node>
<node TEXT="reports" FOLDED="true" ID="ID_322522891" CREATED="1707155811239" MODIFIED="1707155817531">
<node TEXT="Good SOWs also set boundaries for how and when you’ll give status updates to stakeholders. How will you communicate progress with stakeholders and sponsors, and how often? Will progress be reported weekly? Monthly? When milestones are completed? What information will status reports contain?" ID="ID_1330848191" CREATED="1707157333649" MODIFIED="1707157333649"/>
<node TEXT="feedback" ID="ID_347707582" CREATED="1707156957289" MODIFIED="1707156962274"/>
</node>
</node>
<node TEXT="for a data analyst, will also include" FOLDED="true" ID="ID_911390123" CREATED="1707155830130" MODIFIED="1707155853049">
<node TEXT="data preparation" ID="ID_1429537220" CREATED="1707155854035" MODIFIED="1707155866239"/>
<node TEXT="validation" ID="ID_737971947" CREATED="1707155866250" MODIFIED="1707155874625"/>
<node TEXT="analysis" FOLDED="true" ID="ID_498550215" CREATED="1707155874637" MODIFIED="1707155877446">
<node TEXT="quantitative and qualitative view sets" ID="ID_1468459160" CREATED="1707155877449" MODIFIED="1707155883045"/>
</node>
<node TEXT="initial results" ID="ID_887603554" CREATED="1707155884702" MODIFIED="1707155893028"/>
<node TEXT="visuals" ID="ID_1054428158" CREATED="1707155893041" MODIFIED="1707155897688"/>
</node>
</node>
<node TEXT="context" FOLDED="true" ID="ID_1135011568" CREATED="1707161810405" MODIFIED="1707161814029">
<node TEXT="the condition and circumstances that surround and give meaning to the data" ID="ID_1666891912" CREATED="1707161814031" MODIFIED="1707161828234"/>
<node TEXT="important because it helps make disorganized data accessible and understood" ID="ID_1732466490" CREATED="1707161830264" MODIFIED="1707161840634"/>
<node TEXT="data has little value if not paired with context" ID="ID_1055319760" CREATED="1707161841317" MODIFIED="1707161847440"/>
<node TEXT="to contextualize data, define it by identifying:" FOLDED="true" ID="ID_452183880" CREATED="1707161906276" MODIFIED="1707161934920">
<node TEXT="Who: The person or organization that created, collected, and/or funded the data collection" ID="ID_1206010216" CREATED="1707161959250" MODIFIED="1707161959250"/>
<node TEXT="What: The things in the world that data could have an impact on" ID="ID_1416924532" CREATED="1707161959250" MODIFIED="1707161959250"/>
<node TEXT="Where: The origin of the data" ID="ID_1344063974" CREATED="1707161959251" MODIFIED="1707161959251"/>
<node TEXT="When: The time when the data was created or collected" ID="ID_1429109521" CREATED="1707161959252" MODIFIED="1707161959252"/>
<node TEXT="Why: The motivation behind the creation or collection" ID="ID_1869767324" CREATED="1707161959252" MODIFIED="1707161959252"/>
<node TEXT="How: The method used to create or collect it" ID="ID_1389589506" CREATED="1707161959252" MODIFIED="1707161959252"/>
</node>
<node TEXT="During organization, the context is important for your naming conventions, how you choose to show relationships between variables, and what you choose to keep or leave out. And finally, when you present, it is important to include contextual information so that your stakeholders understand your analysis." ID="ID_833763024" CREATED="1707162009157" MODIFIED="1707162011591"/>
</node>
</node>
<node TEXT="Module 4: Always remember the stakeholder " FOLDED="true" ID="ID_1887214099" CREATED="1706900020118" MODIFIED="1706900052013">
<node TEXT="Glossary" FOLDED="true" ID="ID_984929479" CREATED="1707257868038" MODIFIED="1707257871641">
<node TEXT="Cloud: A place to keep data online, rather than a computer hard drive" ID="ID_1080593093" CREATED="1707257891464" MODIFIED="1707257891464"/>
<node TEXT="Reframing: Restating a problem or challenge, then redirecting it toward a potential resolution" ID="ID_1886039062" CREATED="1707257891464" MODIFIED="1707257891464"/>
<node TEXT="Turnover rate: The rate at which employees voluntarily leave a company" ID="ID_1689359448" CREATED="1707257891465" MODIFIED="1707257891465"/>
</node>
<node TEXT="Balancing team and stakeholder needs" FOLDED="true" ID="ID_924414419" CREATED="1707177947697" MODIFIED="1707177952746">
<node TEXT="Working effectively with stakeholders" FOLDED="true" ID="ID_867324624" CREATED="1707173602804" MODIFIED="1707177005339">
<node TEXT="reference" FOLDED="true" ID="ID_1139612181" CREATED="1707177789456" MODIFIED="1707177792218">
<node ID="ID_1131619970" CREATED="1707177794524" MODIFIED="1707177794524" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/2MAkf/working-with-stakeholders"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/2MAkf/working-with-stakeholders">Working with stakeholders | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_377019532" TREE_ID="ID_1964790280"/>
<node TEXT="focus on stakeholder expectations" FOLDED="true" ID="ID_1648816259" CREATED="1707177005341" MODIFIED="1707177005342">
<node TEXT="Why" FOLDED="true" ID="ID_148761262" CREATED="1707175076771" MODIFIED="1707175080468">
<node TEXT="will help you understand the goal of a project" FOLDED="true" ID="ID_1713442958" CREATED="1707174323044" MODIFIED="1707174330893">
<node TEXT="make sure your work aligns with their own needs" ID="ID_1908679328" CREATED="1707174070172" MODIFIED="1707174081238"/>
</node>
<node TEXT="communicate more effectively across your team" ID="ID_349436602" CREATED="1707174330908" MODIFIED="1707174335105"/>
<node TEXT="build trust in your work" ID="ID_537175681" CREATED="1707174335119" MODIFIED="1707174338989"/>
</node>
</node>
<node TEXT="broad groups" FOLDED="true" ID="ID_1336333591" CREATED="1707174309083" MODIFIED="1707175094113">
<node TEXT="executive team" FOLDED="true" ID="ID_1639081455" CREATED="1707175094117" MODIFIED="1707176351891">
<node TEXT="includes" FOLDED="true" ID="ID_1328072079" CREATED="1707176529106" MODIFIED="1707176532712">
<node TEXT="VPs" ID="ID_1948995310" CREATED="1707176532717" MODIFIED="1707176539811"/>
<node TEXT="chief marketing officer" ID="ID_1821844962" CREATED="1707176540034" MODIFIED="1707176547312"/>
<node TEXT="senior-level professionals who helped plan and direct the company &apos;s work" ID="ID_549522776" CREATED="1707176547324" MODIFIED="1707176556204"/>
</node>
<node TEXT="function" FOLDED="true" ID="ID_197726958" CREATED="1707176433338" MODIFIED="1707176675715">
<node TEXT="provide strategic and operational leadership" ID="ID_500915395" CREATED="1707176351893" MODIFIED="1707176358291"/>
<node TEXT="set goals" ID="ID_806842299" CREATED="1707176358306" MODIFIED="1707176381602"/>
<node TEXT="develop strategy" ID="ID_1075128038" CREATED="1707176381603" MODIFIED="1707176381603"/>
<node TEXT="make sure that strategy is executed effectively" ID="ID_483461773" CREATED="1707176364917" MODIFIED="1707176373131"/>
</node>
<node TEXT="communication" FOLDED="true" ID="ID_1489667327" CREATED="1707176441242" MODIFIED="1707176447910">
<node TEXT="looking for the executive summary" ID="ID_1793080394" CREATED="1707176447912" MODIFIED="1707176461147"/>
<node TEXT="lead presentations with answers to their questions" FOLDED="true" ID="ID_148563084" CREATED="1707176461970" MODIFIED="1707176469923">
<node TEXT="keep the more detailed information in presentation appendix or your project documentation" ID="ID_1831384393" CREATED="1707176474766" MODIFIED="1707176485259"/>
</node>
</node>
</node>
<node TEXT="customer facing team" FOLDED="true" ID="ID_933124177" CREATED="1707176501609" MODIFIED="1707176508514">
<node TEXT="includes" FOLDED="true" ID="ID_424273607" CREATED="1707176508518" MODIFIED="1707176514106">
<node TEXT="anyone in the organization who has some level of interaction with customers and potential customers" ID="ID_837276197" CREATED="1707176514108" MODIFIED="1707176522312"/>
</node>
<node TEXT="function" FOLDED="true" ID="ID_798780700" CREATED="1707176646746" MODIFIED="1707176654929">
<node TEXT="compile information" ID="ID_1140159596" CREATED="1707176654932" MODIFIED="1707176659086"/>
<node TEXT="set expectations" ID="ID_1787522667" CREATED="1707176659102" MODIFIED="1707176661695"/>
<node TEXT="communicate customer feedback to other parts of the internal organization" ID="ID_1958338390" CREATED="1707176661708" MODIFIED="1707176668143"/>
</node>
<node TEXT="communication" FOLDED="true" ID="ID_1019991762" CREATED="1707176693562" MODIFIED="1707176723499">
<node TEXT="have their own objectives and may come to you with specific asks" ID="ID_1533543263" CREATED="1707176741306" MODIFIED="1707176775868"/>
<node TEXT="let the data tell the story and not be swayed by asks for your stakeholders to find certain patterns that might not exist" ID="ID_1414617583" CREATED="1707176723502" MODIFIED="1707176739324"/>
</node>
</node>
<node TEXT="data science team" FOLDED="true" ID="ID_1044794244" CREATED="1707176783754" MODIFIED="1707176787299">
<node TEXT="includes" FOLDED="true" ID="ID_1980286658" CREATED="1707176906578" MODIFIED="1707176918715">
<node TEXT="png_13561061847330007614.png" ID="ID_1061631106" CREATED="1707176921015" MODIFIED="1707176921015">
<hook URI="Google%20Data%20Analytics%20Certificate_files/png_13561061847330007614.png" SIZE="0.18181819" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="collaboration" FOLDED="true" ID="ID_1119054690" CREATED="1707176787301" MODIFIED="1707176843730">
<node TEXT="share findings" ID="ID_781280663" CREATED="1707176886865" MODIFIED="1707176896133"/>
<node TEXT="find new angles of the data to explore" ID="ID_351566678" CREATED="1707176843733" MODIFIED="1707176849932"/>
</node>
</node>
</node>
<node TEXT="communicating across groups" FOLDED="true" ID="ID_1733325342" CREATED="1707177026642" MODIFIED="1707177051925">
<node TEXT="discuss goals" FOLDED="true" ID="ID_1093984160" CREATED="1707177051928" MODIFIED="1707177055302">
<node TEXT="ask about the kinds of results a stakeholder wants" ID="ID_281745551" CREATED="1707177093300" MODIFIED="1707177100195"/>
</node>
<node TEXT="feel empowered to no" FOLDED="true" ID="ID_1539528591" CREATED="1707177055317" MODIFIED="1707177059518">
<node TEXT="don&apos;t be afraid to push back when you need to" ID="ID_453906358" CREATED="1707177132312" MODIFIED="1707177170516"/>
</node>
<node TEXT="plan for the unexpected" FOLDED="true" ID="ID_1570157886" CREATED="1707177059525" MODIFIED="1707177063890">
<node TEXT="before starting a project, make a list of potential roadblocks" ID="ID_62435177" CREATED="1707177194265" MODIFIED="1707177204603"/>
<node TEXT="when discussing project expectation and timelines, give yourself some extra time for problem solving at each stage of the process" ID="ID_1355489617" CREATED="1707177205457" MODIFIED="1707177226146"/>
</node>
<node TEXT="know your project" FOLDED="true" ID="ID_1964201211" CREATED="1707177063902" MODIFIED="1707177067100">
<node TEXT="keep track of your discussions" ID="ID_1420721200" CREATED="1707177229901" MODIFIED="1707177234291"/>
<node TEXT="be ready to answer questions" ID="ID_849906483" CREATED="1707177237313" MODIFIED="1707177241218"/>
<node TEXT="know how your project connect to the rest the company" ID="ID_410026641" CREATED="1707177242481" MODIFIED="1707177246939"/>
<node TEXT="understand why you are doing an analysis" ID="ID_306440167" CREATED="1707177251809" MODIFIED="1707177256683"/>
</node>
<node TEXT="start with words individuals" FOLDED="true" ID="ID_557153483" CREATED="1707177067113" MODIFIED="1707177071308">
<node TEXT="start with a description and a quick visual what you are trying to convey" ID="ID_1048417082" CREATED="1707177258935" MODIFIED="1707177276059"/>
<node TEXT="work with stakeholders to make changes and improvements from there" ID="ID_1637595288" CREATED="1707177279433" MODIFIED="1707177307483"/>
</node>
<node TEXT="communicate often" FOLDED="true" ID="ID_1779960298" CREATED="1707177071320" MODIFIED="1707177076512">
<node TEXT="share notes about project milestones, setbacks, and changes" ID="ID_1303282391" CREATED="1707177311841" MODIFIED="1707177323146"/>
<node TEXT="use a change log" FOLDED="true" ID="ID_1802120431" CREATED="1707177330313" MODIFIED="1707177359571">
<node TEXT="file containing a chronologically ordered list of modifications made to a project" ID="ID_1395874058" CREATED="1707177342508" MODIFIED="1707177352147"/>
</node>
</node>
</node>
</node>
<node TEXT="staying focused on the objective" FOLDED="true" ID="ID_93162982" CREATED="1707177426049" MODIFIED="1707177435910">
<node TEXT="reference" FOLDED="true" ID="ID_109914228" CREATED="1707177769113" MODIFIED="1707177771533">
<node ID="ID_741919754" CREATED="1707177764423" MODIFIED="1707177764423" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/QJ5qG/focus-on-what-matters"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/QJ5qG/focus-on-what-matters">Focus on what matters | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="1. Who are the primary and secondary stakeholders?" ID="ID_1028086170" CREATED="1707177435912" MODIFIED="1707177509912"/>
<node TEXT="2. Who is managing the data?" ID="ID_1435928790" CREATED="1707177511309" MODIFIED="1707177520296"/>
<node TEXT="3. Where can you go for help?" ID="ID_786083582" CREATED="1707177520308" MODIFIED="1707177534762"/>
</node>
</node>
<node TEXT="Clear communication is key" FOLDED="true" ID="ID_253895091" CREATED="1707177908745" MODIFIED="1707177921602">
<node TEXT="reference" FOLDED="true" ID="ID_1709549143" CREATED="1707178255502" MODIFIED="1707178258143">
<node ID="ID_326903890" CREATED="1707178259120" MODIFIED="1707178259120" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/hfa0L/clear-communication-is-key"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/hfa0L/clear-communication-is-key">Clear communication is key | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="before you communicate, think about" FOLDED="true" ID="ID_1618359692" CREATED="1707178028513" MODIFIED="1707178036902">
<node TEXT="Who your audience is" ID="ID_356286611" CREATED="1707178036904" MODIFIED="1707178676230"/>
<node TEXT="What they already know" ID="ID_1242048938" CREATED="1707178041708" MODIFIED="1707178676230"/>
<node TEXT="What they need to know" ID="ID_350221069" CREATED="1707178044104" MODIFIED="1707178676230"/>
<node TEXT="How you can communicate that effectively to them" ID="ID_1970107671" CREATED="1707178046307" MODIFIED="1707178676230"/>
</node>
<node TEXT="tips for effective communication" FOLDED="true" ID="ID_1439505747" CREATED="1707178319985" MODIFIED="1712100144522">
<node TEXT="ask questions when you&apos;re not sure of something" ID="ID_688758620" CREATED="1707178324744" MODIFIED="1707178349326"/>
<node TEXT="use etiquette" ID="ID_1093113803" CREATED="1707178349339" MODIFIED="1707178362325"/>
<node TEXT="e-mails" FOLDED="true" ID="ID_741174794" CREATED="1707178362339" MODIFIED="1707178445902">
<node TEXT="complete sentences with proper spelling and punctuation" ID="ID_956207783" CREATED="1707178445904" MODIFIED="1707178457501"/>
<node TEXT="tone" ID="ID_296961273" CREATED="1707178457520" MODIFIED="1707178466900"/>
<node TEXT="not too long" ID="ID_1399048207" CREATED="1707178466912" MODIFIED="1707178473300"/>
<node TEXT="get to the point" ID="ID_1343564936" CREATED="1707178473311" MODIFIED="1707178542602"/>
<node TEXT="respond within 24-48h" ID="ID_229963456" CREATED="1707178543176" MODIFIED="1707178629537"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1126263740" CREATED="1707178644855" MODIFIED="1707178647538">
<node ID="ID_810053863" CREATED="1707178648736" MODIFIED="1707178648736" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/VCh1T/tips-for-effective-communication"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/VCh1T/tips-for-effective-communication">Tips for effective communication | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="navigate expectations and set realistic project goals" FOLDED="true" ID="ID_346553908" CREATED="1707249049548" MODIFIED="1707249068718">
<node TEXT="reference" FOLDED="true" ID="ID_390407263" CREATED="1707249717947" MODIFIED="1707249720510">
<node ID="ID_54374167" CREATED="1707249724051" MODIFIED="1707249724051" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/haLKs/navigate-expectations-and-realistic-project-goals"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/haLKs/navigate-expectations-and-realistic-project-goals">Navigate expectations and realistic project goals | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="answer really questions so you and your team can set a reasonable and realistic timeline for the project" ID="ID_1333091891" CREATED="1707249088733" MODIFIED="1707249704121"/>
</node>
<node TEXT="how to communicate with stakeholders" FOLDED="true" ID="ID_260560694" CREATED="1707249815154" MODIFIED="1707249821914">
<node TEXT="give expectations on turnaround" ID="ID_473997202" CREATED="1707249821918" MODIFIED="1707249830506"/>
<node TEXT="make sure that the data tells you the stories" ID="ID_304945713" CREATED="1707249830520" MODIFIED="1707249866118"/>
<node TEXT="communicate theory and progress" ID="ID_1119995018" CREATED="1707249908935" MODIFIED="1707249931719"/>
</node>
<node TEXT="the data trade-off: speed versus accuracy" FOLDED="true" ID="ID_190199973" CREATED="1707249987320" MODIFIED="1707250011739">
<node TEXT="reframe question" ID="ID_1185801220" CREATED="1707250022557" MODIFIED="1707250143513"/>
<node TEXT="outline the" FOLDED="true" ID="ID_726844876" CREATED="1707250143528" MODIFIED="1707250165756">
<node TEXT="problem" ID="ID_1623014977" CREATED="1707250165757" MODIFIED="1707250165759"/>
<node TEXT="challenges" ID="ID_815570033" CREATED="1707250146722" MODIFIED="1707250149919"/>
<node TEXT="potential solutions" ID="ID_983247677" CREATED="1707250149936" MODIFIED="1707250153107"/>
<node TEXT="timeframe" ID="ID_564259109" CREATED="1707250153120" MODIFIED="1707250160945"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_792404786" CREATED="1707250013714" MODIFIED="1707250016309">
<node ID="ID_643340533" CREATED="1707250020128" MODIFIED="1707250020128" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/RP0iH/the-data-tradeoff-speed-versus-accuracy"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/RP0iH/the-data-tradeoff-speed-versus-accuracy">The data tradeoff: Speed versus accuracy | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Limitations of data" FOLDED="true" ID="ID_663259245" CREATED="1707250311310" MODIFIED="1707250316105">
<node TEXT="reference" FOLDED="true" ID="ID_116692819" CREATED="1707250316108" MODIFIED="1707250318149">
<node ID="ID_884058422" CREATED="1707250322137" MODIFIED="1707250322137" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/gqKDr/limitations-of-data"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/gqKDr/limitations-of-data">Limitations of data | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="incomplete or nonexistent data" ID="ID_1335532207" CREATED="1707250362907" MODIFIED="1707250370306"/>
<node TEXT="don&apos;t miss misaligned data" ID="ID_732775910" CREATED="1707250370325" MODIFIED="1707250374706"/>
<node TEXT="deal with dirty data" FOLDED="true" ID="ID_1318004179" CREATED="1707250374724" MODIFIED="1707250399310">
<node TEXT="data that contains errors" ID="ID_595488649" CREATED="1707250399313" MODIFIED="1707250410146"/>
<node TEXT="data cleaning" FOLDED="true" ID="ID_299590548" CREATED="1707250416311" MODIFIED="1707250419510">
<node TEXT="process of fixing removing incorrect, corrupted, incorrectly formatted, duplicate, or incomplete data within a data set" ID="ID_1580724373" CREATED="1707250467719" MODIFIED="1707250487941"/>
</node>
</node>
<node TEXT="tell a clear story" FOLDED="true" ID="ID_47748920" CREATED="1707250493724" MODIFIED="1707250504110">
<node TEXT="best practices" FOLDED="true" ID="ID_284855825" CREATED="1707250504113" MODIFIED="1707250510105">
<node TEXT="compare the same types of data" ID="ID_782851343" CREATED="1707250510108" MODIFIED="1707250514702"/>
<node TEXT="visualize with care" ID="ID_1173134296" CREATED="1707250514716" MODIFIED="1707250518106"/>
<node TEXT="leave out needless graphs" ID="ID_1276173387" CREATED="1707250518122" MODIFIED="1707250521899"/>
<node TEXT="test for statistical significance" ID="ID_1009979330" CREATED="1707250521910" MODIFIED="1707250529697"/>
<node TEXT="pay attention to sample size" ID="ID_557111531" CREATED="1707250529710" MODIFIED="1707250533519"/>
</node>
</node>
<node TEXT="be the judge" FOLDED="true" ID="ID_1257211002" CREATED="1707250544144" MODIFIED="1707250558510">
<node TEXT="take the necessary steps to make sure that your data is complete and consistent" ID="ID_1247533683" CREATED="1707250558513" MODIFIED="1707250571113"/>
<node TEXT="clean the data before you begin your analysis" ID="ID_1929447077" CREATED="1707250571116" MODIFIED="1707250578147"/>
</node>
</node>
<node TEXT="Think about your process and outcome" FOLDED="true" ID="ID_36911947" CREATED="1707250698316" MODIFIED="1707250706319">
<node TEXT="questions" FOLDED="true" ID="ID_668005864" CREATED="1707250706321" MODIFIED="1707250720107">
<node TEXT="does your analysis answer the question" ID="ID_1782834779" CREATED="1707250720110" MODIFIED="1707250724924"/>
<node TEXT="are there other angles you haven&apos;t considered" ID="ID_712392018" CREATED="1707250724940" MODIFIED="1707250729108"/>
<node TEXT="can you answer any questions that asked about your data and analysis" ID="ID_1273608575" CREATED="1707250729124" MODIFIED="1707250736309"/>
<node TEXT="how detailed should you be when sharing your results" FOLDED="true" ID="ID_1207633479" CREATED="1707250736325" MODIFIED="1707250742512">
<node TEXT="would a high-level analysis be okay" ID="ID_445432588" CREATED="1707250746311" MODIFIED="1707250751113"/>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1767447326" CREATED="1707250790538" MODIFIED="1707250792730">
<node ID="ID_1775448836" CREATED="1707250793793" MODIFIED="1707250793793" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/gPuXV/think-about-your-process-and-outcome"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/gPuXV/think-about-your-process-and-outcome">Think about your process and outcome | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Amazing teamwork" FOLDED="true" ID="ID_1500563399" CREATED="1707251589517" MODIFIED="1707251597707">
<node TEXT="meeting best practices" FOLDED="true" ID="ID_348099677" CREATED="1707251597709" MODIFIED="1707251604302">
<node TEXT="reference" FOLDED="true" ID="ID_562597133" CREATED="1707251604304" MODIFIED="1707251607137">
<node ID="ID_94182819" CREATED="1707251611133" MODIFIED="1707251611133" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/G8ECS/meeting-best-practices"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/G8ECS/meeting-best-practices">Meeting best practices | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="benefits" FOLDED="true" ID="ID_1298182365" CREATED="1707251737113" MODIFIED="1707251739314">
<node TEXT="make it possible for you and your team members or stakeholders to discuss how a project is going" ID="ID_1916851800" CREATED="1707251626719" MODIFIED="1707251654711"/>
<node TEXT="can build trust and team spirit" ID="ID_1387860826" CREATED="1707251656530" MODIFIED="1707251663119"/>
<node TEXT="give you a chance to connect with people you are working with beyond e-mails" ID="ID_270573589" CREATED="1707251663133" MODIFIED="1707251671301"/>
<node TEXT="knowing who you&apos;re working with can give you abettors perspective on where your work fits in the larger project" ID="ID_513899149" CREATED="1707251671330" MODIFIED="1707251706110"/>
<node TEXT="make it easier to coordinate team goals" FOLDED="true" ID="ID_722180523" CREATED="1707251706142" MODIFIED="1707251711113">
<node TEXT="makes it easier to reach your objectives" ID="ID_636471850" CREATED="1707251711115" MODIFIED="1707251717532"/>
</node>
</node>
<node TEXT="best practices" FOLDED="true" ID="ID_601230475" CREATED="1707251752504" MODIFIED="1707251776979">
<node TEXT="come prepared" FOLDED="true" ID="ID_291796184" CREATED="1707251776982" MODIFIED="1707251782511">
<node TEXT="if you are leading the meeting, come early and set up before the meeting starts" ID="ID_1108611646" CREATED="1707251959927" MODIFIED="1707252007143"/>
<node TEXT="bring what you need" ID="ID_409734925" CREATED="1707251797718" MODIFIED="1707251801319"/>
<node TEXT="read the meeting agenda ahead of time" ID="ID_204649898" CREATED="1707251801337" MODIFIED="1707251816904"/>
<node TEXT="prepare notes and presentations" ID="ID_752663938" CREATED="1707251816921" MODIFIED="1707251821301"/>
<node TEXT="be ready to answer questions" ID="ID_212265181" CREATED="1707251821315" MODIFIED="1707251828340"/>
</node>
<node TEXT="be on time" FOLDED="true" ID="ID_971109166" CREATED="1707251782524" MODIFIED="1707251864129">
<node TEXT="respect your team members time" ID="ID_1438558692" CREATED="1707251937510" MODIFIED="1707251955727"/>
</node>
<node TEXT="pay attention" FOLDED="true" ID="ID_1734009916" CREATED="1707251784513" MODIFIED="1707251786513">
<node TEXT="stay focused and attentive" ID="ID_1585426367" CREATED="1707252015303" MODIFIED="1707252020126"/>
</node>
<node TEXT="ask questions" FOLDED="true" ID="ID_35980506" CREATED="1707251786526" MODIFIED="1707251791143">
<node TEXT="when you need clarification" ID="ID_736832198" CREATED="1707252032919" MODIFIED="1707252036902"/>
<node TEXT="if you think there may be a problem with the project plan" ID="ID_125976291" CREATED="1707252036919" MODIFIED="1707252045909"/>
<node TEXT="follow-up with group afterwards to get an answer" ID="ID_1680667007" CREATED="1707252045935" MODIFIED="1707252052913"/>
</node>
<node TEXT="try to engage with all your attendees" FOLDED="true" ID="ID_347911361" CREATED="1707252081944" MODIFIED="1707252128525">
<node TEXT="don&apos;t dominate the conversation" ID="ID_1221439021" CREATED="1707252129917" MODIFIED="1707252176115"/>
</node>
<node TEXT="take notes even when you&apos;re leading the meeting" ID="ID_247134757" CREATED="1707252090928" MODIFIED="1707252099508"/>
<node TEXT="every meeting should focus on making a clear decision and include the person needed to make that decision" FOLDED="true" ID="ID_1372917967" CREATED="1707251866335" MODIFIED="1707251887911">
<node TEXT="if there needs to be a meeting in order to make a decision, schedule it immediately" FOLDED="true" ID="ID_485578659" CREATED="1707251887914" MODIFIED="1707251901097">
<node TEXT="don&apos;t let progress tall by waiting until next week&apos;s meeting" ID="ID_714492680" CREATED="1707251901101" MODIFIED="1707251909706"/>
</node>
</node>
<node TEXT="try to keep the number of people at your meeting under 10 if possible" ID="ID_503606560" CREATED="1707251911940" MODIFIED="1707251927309"/>
</node>
</node>
<node TEXT="Lead great meetings" FOLDED="true" ID="ID_574200467" CREATED="1707252344724" MODIFIED="1707252348710">
<node TEXT="reference" FOLDED="true" ID="ID_129836141" CREATED="1707252348712" MODIFIED="1707252350340">
<node ID="ID_71474924" CREATED="1707252354013" MODIFIED="1707252354013" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/4H8Ic/lead-great-meetings"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/supplement/4H8Ic/lead-great-meetings">Lead great meetings | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Before the meeting" FOLDED="true" ID="ID_1010808963" CREATED="1707252358309" MODIFIED="1707252368306">
<node TEXT="identify your objective" FOLDED="true" ID="ID_299631570" CREATED="1707252368309" MODIFIED="1707252373911">
<node TEXT="establish" FOLDED="true" ID="ID_1722909690" CREATED="1707252373913" MODIFIED="1707252380706">
<node TEXT="purpose" ID="ID_1859632771" CREATED="1707252380708" MODIFIED="1707252382934"/>
<node TEXT="goals" ID="ID_879633630" CREATED="1707252385306" MODIFIED="1707252387513"/>
<node TEXT="desired outcomes" ID="ID_70939766" CREATED="1707252387526" MODIFIED="1707252391111"/>
<node TEXT="questions or requests that need to be addressed" ID="ID_1421363240" CREATED="1707252391134" MODIFIED="1707252397561"/>
</node>
</node>
<node TEXT="acknowledge participants and keep them involved" ID="ID_1885277931" CREATED="1707252402932" MODIFIED="1707252435565"/>
<node TEXT="organize the data to be presented" ID="ID_1214808292" CREATED="1707252436720" MODIFIED="1707252441892"/>
<node TEXT="prepare and distribute an agenda" ID="ID_1810584529" CREATED="1707252441904" MODIFIED="1707252446703"/>
</node>
<node TEXT="Crafting a compelling agenda" FOLDED="true" ID="ID_970542235" CREATED="1707252457901" MODIFIED="1707252463523">
<node TEXT="include" FOLDED="true" ID="ID_1123419791" CREATED="1707252482133" MODIFIED="1707252484715">
<node TEXT="meeting start and end time" ID="ID_727130260" CREATED="1707252484718" MODIFIED="1707252489698"/>
<node TEXT="location" ID="ID_451770014" CREATED="1707252489713" MODIFIED="1707252492905"/>
<node TEXT="objectives" ID="ID_198380538" CREATED="1707252492913" MODIFIED="1707252494899"/>
<node TEXT="questions" ID="ID_1001355318" CREATED="1707252539711" MODIFIED="1707252550122"/>
<node TEXT="next steps" ID="ID_581609296" CREATED="1707252552726" MODIFIED="1707252555937"/>
<node TEXT="background material or data the participants should review beforehand" ID="ID_1799449671" CREATED="1707252494908" MODIFIED="1707252504911"/>
</node>
</node>
<node TEXT="share agenda ahead of time" ID="ID_666167342" CREATED="1707252573923" MODIFIED="1707252584344"/>
<node TEXT="during the meeting" FOLDED="true" ID="ID_47243028" CREATED="1707252585536" MODIFIED="1707252594296">
<node TEXT="as a leader of the meeting, it&apos;s your job to guide the data discussion" ID="ID_797552767" CREATED="1707252598918" MODIFIED="1707252629542"/>
<node TEXT="follow these steps to avoid distractions:" FOLDED="true" ID="ID_784694378" CREATED="1707252630543" MODIFIED="1707252638170">
<node TEXT="make introductions (if necessary) and review key messages" ID="ID_1274185785" CREATED="1707252639911" MODIFIED="1707252658501"/>
<node TEXT="present the data" ID="ID_1315348061" CREATED="1707252658519" MODIFIED="1707252661312"/>
<node TEXT="discuss observations, interpretations, and implications of the data" ID="ID_392488906" CREATED="1707252661329" MODIFIED="1707252668709"/>
<node TEXT="take notes during the meeting" ID="ID_1741866901" CREATED="1707252668734" MODIFIED="1707252672313"/>
<node TEXT="determine and summarize next steps for the group" ID="ID_1899528171" CREATED="1707252672325" MODIFIED="1707252680934"/>
</node>
</node>
<node TEXT="after the meeting" FOLDED="true" ID="ID_1107108802" CREATED="1707252684943" MODIFIED="1707252692708">
<node TEXT="prepare and distribute a brief recap of the meeting with next steps that were agreed upon in the meeting" FOLDED="true" ID="ID_1467284005" CREATED="1707252692710" MODIFIED="1707252706904">
<node TEXT="distribute any notes or data" ID="ID_1482422557" CREATED="1707252769115" MODIFIED="1707252774101"/>
<node TEXT="confirm next steps and timeline for additional actions" ID="ID_1384790010" CREATED="1707252774112" MODIFIED="1707252780696"/>
<node TEXT="ask for feedback from the team" FOLDED="true" ID="ID_882445355" CREATED="1707252706906" MODIFIED="1707252716335">
<node TEXT="effective way to figure out if you missed anything in your recap" ID="ID_1512149937" CREATED="1707252789899" MODIFIED="1707252797125"/>
</node>
</node>
</node>
</node>
<node TEXT="From conflict to collaboration" FOLDED="true" ID="ID_380508278" CREATED="1707252851135" MODIFIED="1707252866318">
<node TEXT="reference" FOLDED="true" ID="ID_868351675" CREATED="1707252857108" MODIFIED="1707252860940">
<node ID="ID_1351461740" CREATED="1707252870788" MODIFIED="1707252870788" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/lb4DS/from-conflict-to-collaboration"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/lecture/lb4DS/from-conflict-to-collaboration">From conflict to collaboration | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="conflicts arise from" FOLDED="true" ID="ID_1217392594" CREATED="1707252905923" MODIFIED="1707253019333">
<node TEXT="most common" FOLDED="true" ID="ID_157482058" CREATED="1707252969737" MODIFIED="1707252972154">
<node TEXT="mismatched expectations" ID="ID_172939693" CREATED="1707252920515" MODIFIED="1707252949903"/>
<node TEXT="miscommunications" ID="ID_1365504795" CREATED="1707252949913" MODIFIED="1707252968366"/>
</node>
<node TEXT="different work styles" ID="ID_764529003" CREATED="1707253033937" MODIFIED="1707253038911"/>
<node TEXT="stress from approaching deadline" ID="ID_504535201" CREATED="1707253043304" MODIFIED="1707253047742"/>
</node>
<node TEXT="discussion is key to resolving conflicts" FOLDED="true" ID="ID_1931492176" CREATED="1707253061719" MODIFIED="1707253101713">
<node TEXT="try to understand the context of the request" FOLDED="true" ID="ID_1591866581" CREATED="1707253101717" MODIFIED="1707253109307">
<node TEXT="ask" FOLDED="true" ID="ID_463765242" CREATED="1707253109310" MODIFIED="1707253111917">
<node TEXT="what their end goal" ID="ID_1889377115" CREATED="1707253111919" MODIFIED="1707253158236"/>
<node TEXT="what story they&apos;re trying to tell" ID="ID_1244186473" CREATED="1707253115121" MODIFIED="1707253119106"/>
<node TEXT="what the big pictures" ID="ID_1391605612" CREATED="1707253119117" MODIFIED="1707253122736"/>
</node>
</node>
</node>
<node TEXT="tense moments can actually be opportunities to reevaluate a project or maybe even improve things" ID="ID_1401657191" CREATED="1707252892554" MODIFIED="1707252901723"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Step 2: Prepare" FOLDED="true" ID="ID_136384459" CREATED="1706900372176" MODIFIED="1706900372176">
<node TEXT="Deliverable" ID="ID_333521476" CREATED="1711648951668" MODIFIED="1711648955522">
<node TEXT="A description of all data sources used" ID="ID_1780849260" CREATED="1711648955524" MODIFIED="1711648971719">
<node TEXT="last twelve months of Cyclistic trip data" ID="ID_451433000" CREATED="1711648986924" MODIFIED="1711649052300" LINK="https://divvy-tripdata.s3.amazonaws.com/index.html"/>
<node TEXT="C:\Users\micha\Downloads\Case Study" ID="ID_1770419392" CREATED="1711649424948" MODIFIED="1711649432980" LINK="file:/C:/Users/micha/Downloads/Case%20Study"/>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1758830307" CREATED="1707842888368" MODIFIED="1707842891146">
<node ID="ID_121055839" CREATED="1707842892133" MODIFIED="1707842892133" LINK="https://marketsplash.com/tutorials/flow/how-to-apply-flow-in-data-analysis/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://marketsplash.com/tutorials/flow/how-to-apply-flow-in-data-analysis/">How To Apply Flow In Data Analysis: A Step-By-Step Approach</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Prepare (2)" FOLDED="true" ID="ID_1467197272" CREATED="1706679786970" MODIFIED="1706736703017">
<node TEXT="Guiding questions" ID="ID_1648087535" CREATED="1712603296547" MODIFIED="1712603317220">
<font BOLD="true"/>
<node TEXT="Where is your data located?" ID="ID_500873866" CREATED="1712603296547" MODIFIED="1712603296547">
<node TEXT="identify and locate data you can use to answer your questions" FOLDED="true" ID="ID_183419581" CREATED="1706739457312" MODIFIED="1706739465636">
<node TEXT="You will decide what data you need to collect in order to answer your questions and how to organize it so that it is useful. You might use your business task to decide:" FOLDED="true" ID="ID_1666681426" CREATED="1706900372176" MODIFIED="1706900372176">
<node TEXT="What metrics to measure" ID="ID_393967239" CREATED="1706900372176" MODIFIED="1706900372176"/>
<node TEXT="Locate data in your database" ID="ID_32728354" CREATED="1706900372177" MODIFIED="1706900372177"/>
<node TEXT="Create security measures to protect that data" ID="ID_945278190" CREATED="1706900372178" MODIFIED="1706900372178"/>
</node>
<node TEXT="Questions to ask yourself in this step:" ID="ID_1747472054" CREATED="1706900372178" MODIFIED="1706900372178">
<node TEXT="What do I need to figure out how to solve this problem?" ID="ID_1659698736" CREATED="1706900372179" MODIFIED="1706900372179"/>
<node TEXT="What research do I need to do?" ID="ID_1733628543" CREATED="1706900372179" MODIFIED="1706900372179"/>
</node>
</node>
<node TEXT="collection" ID="ID_1990463447" CREATED="1706683196420" MODIFIED="1706683199110">
<node TEXT="Pulling data from other data sources" FOLDED="true" ID="ID_1739570997" CREATED="1708126878517" MODIFIED="1708126881755">
<node TEXT="reference" FOLDED="true" ID="ID_1725852608" CREATED="1708126898017" MODIFIED="1708126900172">
<node ID="ID_813692989" CREATED="1708126905275" MODIFIED="1708126905275"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/Process%20Data%20From%20Dirty%20To%20Clean%20(4)/M4%20Verify%20and%20report%20on%20cleaning%20results.one#Advanced functions for speedy data cleaning&amp;section-id={45AAA2D8-FEDD-4A4C-A511-D6568CA746DA}&amp;page-id={693D87B3-9BCD-4EDF-A650-924C4F0CA664}&amp;end">Advanced functions for speedy data cleaning</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%28Process%20Data%20From%20Dirty%20To%20Clean%20%284%5C%29%2FM4%20Verify%20and%20report%20on%20cleaning%20results.one%7C45AAA2D8-FEDD-4A4C-A511-D6568CA746DA%2FAdvanced%20functions%20for%20speedy%20data%20cleaning%7C693D87B3-9BCD-4EDF-A650-924C4F0CA664%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="spreadsheet" FOLDED="true" ID="ID_1074639024" CREATED="1708126907364" MODIFIED="1708126912852">
<node TEXT="IMPORTRANGE" ID="ID_820616914" CREATED="1708126916873" MODIFIED="1708126921512"/>
<node TEXT="QUERY" ID="ID_1448505764" CREATED="1708126922255" MODIFIED="1708126927065"/>
</node>
</node>
<node TEXT="Filtering data" FOLDED="true" ID="ID_104775824" CREATED="1708126973969" MODIFIED="1708126977808">
<node TEXT="spreadsheet" FOLDED="true" ID="ID_1049306978" CREATED="1708126980534" MODIFIED="1708126984839">
<node TEXT="FILTER" ID="ID_192652535" CREATED="1708126985641" MODIFIED="1708126989347"/>
</node>
</node>
</node>
</node>
<node TEXT="How is the data organized?" ID="ID_804032126" CREATED="1712603296548" MODIFIED="1712603296548"/>
<node TEXT="Are there issues with bias or credibility in this data? Does your data ROCCC?" ID="ID_1416932677" CREATED="1712603296550" MODIFIED="1712603296550"/>
<node TEXT="How are you addressing licensing, privacy, security, and accessibility?" ID="ID_1119107450" CREATED="1712603296551" MODIFIED="1712603296551"/>
<node TEXT="How did you verify the data’s integrity?" ID="ID_679848486" CREATED="1712603296553" MODIFIED="1712603296553"/>
<node TEXT="How does it help you answer your question?" ID="ID_1919217346" CREATED="1712603296553" MODIFIED="1712603296553"/>
<node TEXT="Are there any problems with the data?" ID="ID_1774426071" CREATED="1712603296553" MODIFIED="1712603296553"/>
</node>
<node TEXT="Key tasks" ID="ID_887613856" CREATED="1712603296555" MODIFIED="1712603314636">
<font BOLD="true"/>
<node TEXT="The prepare phase ensures that you have all of the data you need for your analysis and that you have credible, useful data." ID="ID_928161051" CREATED="1712603296555" MODIFIED="1712603296555"/>
<node TEXT="Collect data and store it appropriately" ID="ID_268651731" CREATED="1712603296556" MODIFIED="1712603296556"/>
<node TEXT="Identify how it’s organized" ID="ID_1949411443" CREATED="1712603296557" MODIFIED="1712603296557"/>
<node TEXT="Sort and filter the data" ID="ID_1891208922" CREATED="1712603296558" MODIFIED="1712603296558"/>
<node TEXT="Determine the credibility of the data" ID="ID_1909991820" CREATED="1712603296559" MODIFIED="1712603296559"/>
</node>
</node>
<node TEXT="Prepare Data For Exploration (Course 3)" ID="ID_1226166888" CREATED="1707259526643" MODIFIED="1707259543434">
<node POSITION="bottom_or_right" ID="ID_204050644" CREATED="1707502202843" MODIFIED="1707502202843" LINK="https://www.coursera.org/learn/data-preparation/home/module/3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/home/module/3">Prepare Data for Exploration - Database essentials - Week 3 | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="What you will learn:" FOLDED="true" POSITION="bottom_or_right" ID="ID_812905763" CREATED="1707261143453" MODIFIED="1707261143453">
<node TEXT="How data is generated" ID="ID_1215884506" CREATED="1707261143453" MODIFIED="1707261143453"/>
<node TEXT="Features of different data types, fields, and values" ID="ID_446305119" CREATED="1707261143456" MODIFIED="1707261143456"/>
<node TEXT="Database structures" ID="ID_929249754" CREATED="1707261143457" MODIFIED="1707261143457"/>
<node TEXT="The function of metadata in data analytics" ID="ID_1238055723" CREATED="1707261143457" MODIFIED="1707261143457"/>
<node TEXT="Structured Query Language (SQL) functions" ID="ID_1241817178" CREATED="1707261143457" MODIFIED="1707261143457"/>
</node>
<node TEXT="Skill sets you will build:" FOLDED="true" POSITION="bottom_or_right" ID="ID_1208763973" CREATED="1707261143458" MODIFIED="1707261143458">
<node TEXT="Ensuring ethical data analysis practices" ID="ID_1988268356" CREATED="1707261143458" MODIFIED="1707261143458"/>
<node TEXT="Addressing issues of bias and credibility" ID="ID_1208828416" CREATED="1707261143459" MODIFIED="1707261143459"/>
<node TEXT="Accessing databases and importing data" ID="ID_548662422" CREATED="1707261143460" MODIFIED="1707261143460"/>
<node TEXT="Writing simple queries" ID="ID_1278608851" CREATED="1707261143460" MODIFIED="1707261143460"/>
<node TEXT="Organizing and protecting data" ID="ID_415084900" CREATED="1707261143460" MODIFIED="1707261143460"/>
<node TEXT="Connecting with the data community (optional)" ID="ID_410479467" CREATED="1707261143462" MODIFIED="1707261143462"/>
</node>
<node TEXT="Glossary" FOLDED="true" POSITION="top_or_left" ID="ID_15164529" CREATED="1707259545636" MODIFIED="1707327653264">
<font BOLD="true"/>
<node TEXT="Access control: Features such as password protection, user permissions, and encryption that are used to protect a spreadsheet" ID="ID_1015814811" CREATED="1707259637654" MODIFIED="1707259637654"/>
<node TEXT="Action-oriented question: A question whose answers lead to change" ID="ID_23708513" CREATED="1707259637655" MODIFIED="1707259637655"/>
<node ID="ID_144895854" CREATED="1707259637656" MODIFIED="1707503818365"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Administrative metadata: Metadata that indicates the technical <b><u>source</u></b>&#xa0;of a digital asset
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Agenda: A list of scheduled appointments" ID="ID_592492166" CREATED="1707259637656" MODIFIED="1707259637656"/>
<node TEXT="Algorithm: A process or set of rules followed for a specific task" ID="ID_1731914921" CREATED="1707259637657" MODIFIED="1707259637657"/>
<node TEXT="Analytical skills: Qualities and characteristics associated with using facts to solve problems" ID="ID_1954984414" CREATED="1707259637658" MODIFIED="1707259637658"/>
<node TEXT="Analytical thinking: The process of identifying and defining a problem, then solving it by using data in an organized, step-by-step manner" ID="ID_1898464273" CREATED="1707259637658" MODIFIED="1707259637658"/>
<node TEXT="Attribute: A characteristic or quality of data used to label a column in a table" ID="ID_1040761729" CREATED="1707259637659" MODIFIED="1707259637659"/>
<node TEXT="Audio file: Digitized audio storage usually in an MP3, AAC, or other compressed format" ID="ID_1010478166" CREATED="1707259637660" MODIFIED="1707259637660"/>
<node TEXT="AVERAGE: A spreadsheet function that returns an average of the values from a selected range" ID="ID_302990548" CREATED="1707259637660" MODIFIED="1707259637660"/>
<node TEXT="Bad data source: A data source that is not reliable, original, comprehensive, current, and cited (ROCCC)" ID="ID_1583857680" CREATED="1707259637661" MODIFIED="1707259637661"/>
<node TEXT="Bias: A conscious or subconscious preference in favor of or against a person, group of people, or thing" FOLDED="true" ID="ID_1942992287" CREATED="1707259637661" MODIFIED="1707259637661">
<node TEXT="Data bias: When a preference in favor of or against a person, group of people, or thing systematically skews data analysis results in a certain direction" FOLDED="true" ID="ID_269556576" CREATED="1707259637677" MODIFIED="1707259637677">
<node TEXT="makes data unreliable" FOLDED="true" ID="ID_53704619" CREATED="1707346999643" MODIFIED="1707347003873">
<node TEXT="collect" ID="ID_1618415127" CREATED="1707347673810" MODIFIED="1707347679985"/>
<node TEXT="analyze" ID="ID_1734873539" CREATED="1707347679998" MODIFIED="1707347682995"/>
</node>
<node TEXT="can be due to" FOLDED="true" ID="ID_255441033" CREATED="1707347049803" MODIFIED="1707347054426">
<node TEXT="Sampling bias: Overrepresenting or underrepresenting certain members of a population as a result of working with a sample that is not representative of the population as a whole" FOLDED="true" ID="ID_1078916976" CREATED="1707259637744" MODIFIED="1707259637744">
<node TEXT="avoid through" FOLDED="true" ID="ID_1987022791" CREATED="1707347061611" MODIFIED="1707347067993">
<node TEXT="Unbiased sampling: When the sample of the population being measured is representative of the population as a whole" ID="ID_1982617196" CREATED="1707259637762" MODIFIED="1707259637762"/>
</node>
</node>
<node TEXT="Observer bias: The tendency for different people to observe things differently (also called experimenter or research bias)" ID="ID_1762378411" CREATED="1707259637723" MODIFIED="1707350676417"/>
<node TEXT="Interpretation bias: The tendency to interpret ambiguous situations in a positive or negative way" ID="ID_1592205280" CREATED="1707347472983" MODIFIED="1707347476997"/>
<node TEXT="Confirmation bias: The tendency to search for or interpret information in a way that confirms pre-existing beliefs" ID="ID_841935630" CREATED="1707259637666" MODIFIED="1707259637666"/>
</node>
</node>
</node>
<node TEXT="Big data: Large, complex datasets typically involving long periods of time, which enable data analysts to address far-reaching business problems" ID="ID_1868425677" CREATED="1707259637662" MODIFIED="1707259637662"/>
<node TEXT="Boolean data: A data type with only two possible values, usually true or false" ID="ID_1548680933" CREATED="1707259637663" MODIFIED="1707259637663"/>
<node TEXT="Borders: Lines that can be added around two or more cells on a spreadsheet" ID="ID_1668756226" CREATED="1707259637663" MODIFIED="1707259637663"/>
<node TEXT="Business task: The question or problem data analysis resolves for a business" ID="ID_613801795" CREATED="1707259637664" MODIFIED="1707259637664"/>
<node TEXT="Cell reference: A cell or a range of cells in a worksheet typically used in formulas and functions" ID="ID_636633321" CREATED="1707259637665" MODIFIED="1707259637665"/>
<node TEXT="Cloud: A place to keep data online, rather than a computer hard drive" ID="ID_1346880949" CREATED="1707259637665" MODIFIED="1707259637665"/>
<node TEXT="Confirmation bias: The tendency to search for or interpret information in a way that confirms pre-existing beliefs" ID="ID_501068829" CREATED="1707259637666" MODIFIED="1707259637666"/>
<node TEXT="Consent: The aspect of data ethics that presumes an individual’s right to know how and why their personal data will be used before agreeing to provide it" ID="ID_1931788622" CREATED="1707259637666" MODIFIED="1707259637666"/>
<node TEXT="Context: The condition in which something exists or happens" ID="ID_1418949043" CREATED="1707259637667" MODIFIED="1707259637667"/>
<node ID="ID_31222012" TREE_ID="ID_1661336324"/>
<node TEXT="Cookie: A small file stored on a computer that contains information about its users" ID="ID_474362719" CREATED="1707259637670" MODIFIED="1707259637670"/>
<node TEXT="COUNT: A spreadsheet function that counts the number of cells in a range that meet a specified criteria" ID="ID_1262131247" CREATED="1707259637670" MODIFIED="1707259637670"/>
<node TEXT="CSV (comma-separated values) file: A delimited text file that uses a comma to separate values" ID="ID_422508630" CREATED="1707259637671" MODIFIED="1707259637671"/>
<node TEXT="Currency: The aspect of data ethics that presumes individuals should be aware of financial transactions resulting from the use of their personal data and the scale of those transactions" ID="ID_1800381979" CREATED="1707259637672" MODIFIED="1707259637672"/>
<node TEXT="Dashboard: A tool that monitors live, incoming data" ID="ID_959253583" CREATED="1707259637673" MODIFIED="1707259637673"/>
<node TEXT="Data: A collection of facts" ID="ID_72494718" CREATED="1707259637673" MODIFIED="1707259637673"/>
</node>
<node TEXT="Data analysis: The collection, transformation, and organization of data in order to draw conclusions, make predictions, and drive informed decision-making" FOLDED="true" ID="ID_1203092975" CREATED="1707259637674" MODIFIED="1707259637674">
<node TEXT="Data analysis process: The six phases of ask, prepare, process, analyze, share, and act whose purpose is to gain insights that drive informed decision-making" ID="ID_279294554" CREATED="1707259637674" MODIFIED="1707259637674"/>
<node TEXT="Data analyst: Someone who collects, transforms, and organizes data in order to draw conclusions, make predictions, and drive informed decision-making" ID="ID_1125649431" CREATED="1707259637675" MODIFIED="1707259637675"/>
<node TEXT="Data analytics: The science of data" ID="ID_1009085309" CREATED="1707259637675" MODIFIED="1707259637675"/>
<node TEXT="Data anonymization: The process of protecting people&apos;s private or sensitive data by eliminating identifying information" ID="ID_1493678840" CREATED="1707259637677" MODIFIED="1707259637677"/>
<node ID="ID_1382884821" TREE_ID="ID_269556576">
<node ID="ID_1027725583" TREE_ID="ID_53704619">
<node ID="ID_1034027157" TREE_ID="ID_1618415127"/>
<node ID="ID_89986630" TREE_ID="ID_1734873539"/>
</node>
<node ID="ID_650389163" TREE_ID="ID_255441033">
<node ID="ID_50477305" TREE_ID="ID_1078916976">
<node ID="ID_1183310647" TREE_ID="ID_1987022791">
<node ID="ID_163253149" TREE_ID="ID_1982617196"/>
</node>
</node>
<node ID="ID_1267471096" TREE_ID="ID_1762378411"/>
<node ID="ID_1019886312" TREE_ID="ID_1592205280"/>
<node ID="ID_65001929" TREE_ID="ID_841935630"/>
</node>
</node>
<node TEXT="Data design: How information is organized" ID="ID_1491564020" CREATED="1707259637678" MODIFIED="1707259637678"/>
<node TEXT="Data-driven decision-making: Using facts to guide business strategy" ID="ID_302163132" CREATED="1707259637679" MODIFIED="1707259637679"/>
<node TEXT="Data ecosystem: The various elements that interact with one another in order to produce, manage, store, organize, analyze, and share data" ID="ID_1853861278" CREATED="1707259637679" MODIFIED="1707259637679"/>
<node TEXT="Data element: A piece of information in a dataset" ID="ID_216337648" CREATED="1707259637679" MODIFIED="1707259637679"/>
<node TEXT="Data ethics: Well-founded standards of right and wrong that dictate how data is collected, shared, and used" FOLDED="true" ID="ID_1736844826" CREATED="1707259637680" MODIFIED="1707259637680">
<node TEXT="components" FOLDED="true" ID="ID_1452753566" CREATED="1707408773758" MODIFIED="1707408776747">
<node TEXT="Ownership: The aspect of data ethics that presumes individuals own the raw data they provide and have primary control over its usage, processing, and sharing" ID="ID_1713865785" CREATED="1707259637727" MODIFIED="1707259637727"/>
<node TEXT="Transaction transparency: The aspect of data ethics that presumes all data-processing activities and algorithms should be explainable and understood by the individual who provides the data" ID="ID_802245375" CREATED="1707259637760" MODIFIED="1707259637760"/>
<node ID="ID_225140648" TREE_ID="ID_1931788622"/>
<node ID="ID_404817012" TREE_ID="ID_1800381979"/>
<node TEXT="Data privacy: Preserving a data subject’s information any time a data transaction occurs" FOLDED="true" ID="ID_419482793" CREATED="1707259637684" MODIFIED="1707259637684">
<node TEXT="also known as information privacy, data protection" ID="ID_1680497406" CREATED="1707351996193" MODIFIED="1707352083211"/>
<node TEXT="includes" FOLDED="true" ID="ID_639283588" CREATED="1707416229083" MODIFIED="1707416231778">
<node TEXT="protection from unauthorized access to our private data" ID="ID_1619709240" CREATED="1707352006194" MODIFIED="1707352011973"/>
<node TEXT="freedom from inappropriate use of our data" ID="ID_629003240" CREATED="1707352011991" MODIFIED="1707416563044"/>
<node TEXT="the right to inspect, update, or correct our data" ID="ID_1665415490" CREATED="1707352015605" MODIFIED="1707352033411"/>
<node TEXT="ability to give consent to use our data" ID="ID_680492399" CREATED="1707352033427" MODIFIED="1707352051992"/>
<node TEXT="legal right to access the data" ID="ID_1138697458" CREATED="1707352037998" MODIFIED="1707416209308"/>
</node>
</node>
<node TEXT="Openness: The aspect of data ethics that promotes the free access, usage, and sharing of data" FOLDED="true" ID="ID_425117334" CREATED="1707259637725" MODIFIED="1707259637725">
<node TEXT="open data" FOLDED="true" ID="ID_1455481654" CREATED="1707408465973" MODIFIED="1707408471376">
<node TEXT="requirements" FOLDED="true" ID="ID_1058903015" CREATED="1707408623159" MODIFIED="1707408642140">
<node TEXT="Be available and accessible to the public as a complete dataset" ID="ID_1392816653" CREATED="1707408643585" MODIFIED="1707408643585"/>
<node TEXT="Be provided under terms that allow it to be reused and redistributed" ID="ID_432697076" CREATED="1707408643585" MODIFIED="1707408643585"/>
<node TEXT="Allow universal participation so that anyone can use, reuse, and redistribute the data" ID="ID_683729779" CREATED="1707408643587" MODIFIED="1707408643587"/>
</node>
<node TEXT="benefits" FOLDED="true" ID="ID_1055940120" CREATED="1707408471378" MODIFIED="1707408474742">
<node TEXT="credible databases can be used more widely" FOLDED="true" ID="ID_49787354" CREATED="1707408477150" MODIFIED="1707408487741">
<node TEXT="can be leveraged, shared, and combined with other data" ID="ID_1698246656" CREATED="1707408670141" MODIFIED="1707408684959"/>
</node>
<node TEXT="can impact scientific collaboration, research advances, analytical capacity, and decision-making" ID="ID_487512308" CREATED="1707408698172" MODIFIED="1707408721362"/>
</node>
<node TEXT="requires" FOLDED="true" ID="ID_1486176753" CREATED="1707408558955" MODIFIED="1707408561958">
<node TEXT="Data interoperability: The ability to integrate data from multiple sources and a key factor leading to the successful use of open data among companies and governments" ID="ID_825713552" CREATED="1707259637681" MODIFIED="1707259637681"/>
</node>
</node>
</node>
</node>
<node TEXT="Steps for ethical use" FOLDED="true" ID="ID_1371190613" CREATED="1707408793751" MODIFIED="1707408799550">
<node TEXT="self reflect and understand what you are doing and the impact has" FOLDED="true" ID="ID_249823704" CREATED="1707408800946" MODIFIED="1707408849564">
<node TEXT="consider those represented by the data set and those not represented by the data set" ID="ID_1062278394" CREATED="1707408849565" MODIFIED="1707408859768"/>
<node TEXT="consider the various harms and risks associated with the work you&apos;re doing" ID="ID_570688057" CREATED="1707408860982" MODIFIED="1707408875374"/>
<node TEXT="how you present your data set, portray the results" ID="ID_1802340540" CREATED="1707408916153" MODIFIED="1707408933566"/>
</node>
</node>
</node>
<node TEXT="Data governance: A process for ensuring the formal management of a company’s data assets" ID="ID_1111028046" CREATED="1707259637680" MODIFIED="1707259637680"/>
<node TEXT="Data-inspired decision-making: Exploring different data sources to find out what they have in common" ID="ID_744567163" CREATED="1707259637681" MODIFIED="1707259637681"/>
<node ID="ID_78815916" TREE_ID="ID_825713552"/>
<node TEXT="Data life cycle: The sequence of stages that data experiences, which include plan, capture, manage, analyze, archive, and destroy" ID="ID_957666536" CREATED="1707259637682" MODIFIED="1707259637682"/>
<node TEXT="Data model: A tool for organizing data elements and how they relate to one another" FOLDED="true" ID="ID_1336425361" CREATED="1707259637682" MODIFIED="1707259637682">
<node TEXT="data elements: pieces of information" ID="ID_1168499084" CREATED="1707265626442" MODIFIED="1707265644064"/>
<node TEXT="help to keep data consistent" ID="ID_1289588120" CREATED="1707265646045" MODIFIED="1707265676127"/>
<node TEXT="visual representation or map of how data is organized and structured" FOLDED="true" ID="ID_1181564039" CREATED="1707267358253" MODIFIED="1707267377374">
<node TEXT="like a blueprint of a house" ID="ID_1136046139" CREATED="1707266269230" MODIFIED="1707266346902"/>
</node>
</node>
<node ID="ID_1709638479" TREE_ID="ID_419482793">
<node ID="ID_94287384" TREE_ID="ID_1680497406"/>
<node ID="ID_1699119441" TREE_ID="ID_639283588">
<node ID="ID_797477595" TREE_ID="ID_1619709240"/>
<node ID="ID_1865056733" TREE_ID="ID_629003240"/>
<node ID="ID_1030865274" TREE_ID="ID_1665415490"/>
<node ID="ID_1435613177" TREE_ID="ID_680492399"/>
<node ID="ID_1854873866" TREE_ID="ID_1138697458"/>
</node>
</node>
<node TEXT="Data science: A field of study that uses raw data to create new ways of modeling and understanding the unknown" ID="ID_1779188337" CREATED="1707259637685" MODIFIED="1707259637685"/>
<node TEXT="Data security: Protecting data from unauthorized access or corruption by adopting safety measures" FOLDED="true" ID="ID_1383805875" CREATED="1707259637685" MODIFIED="1707259637685">
<node ID="ID_638887578" TREE_ID="ID_1015814811"/>
<node TEXT="spreadsheets" FOLDED="true" ID="ID_878528236" CREATED="1707762984268" MODIFIED="1707762987829">
<node TEXT="protect your spreadsheets or part of your spreadsheets from being edited" ID="ID_1003419657" CREATED="1707762987834" MODIFIED="1707763020666"/>
</node>
</node>
<node TEXT="Data strategy: The management of the people, processes, and tools used in data analysis" ID="ID_639562831" CREATED="1707259637686" MODIFIED="1707259637686"/>
<node TEXT="Data type: An attribute that describes a piece of data based on its values, its programming language, or the operations it can perform" FOLDED="true" ID="ID_560184425" CREATED="1707259637687" MODIFIED="1707259637687">
<node TEXT="spreadsheet datatypes" FOLDED="true" ID="ID_1085541761" CREATED="1707327450328" MODIFIED="1707327548742">
<node TEXT="String data type: A sequence of characters and punctuation that contains textual information (also called text data type)" ID="ID_327832251" CREATED="1707259637753" MODIFIED="1707259637753"/>
<node TEXT="Text data type: A sequence of characters and punctuation that contains textual information (also called string data type)" ID="ID_292300196" CREATED="1707259637758" MODIFIED="1707259637758"/>
<node TEXT="number" ID="ID_192050474" CREATED="1707327548744" MODIFIED="1707327553129"/>
<node TEXT="text or string" ID="ID_222111409" CREATED="1707327553144" MODIFIED="1707327569750"/>
<node TEXT="Boolean" ID="ID_349554283" CREATED="1707327556349" MODIFIED="1707327562771"/>
</node>
</node>
<node TEXT="Data visualization: The graphical representation of data" ID="ID_484670680" CREATED="1707259637687" MODIFIED="1707259637687"/>
<node TEXT="Database: A collection of data stored in a computer system" ID="ID_1284381903" CREATED="1707259637688" MODIFIED="1707259637688"/>
<node TEXT="Dataset: A collection of data that can be manipulated or analyzed as one unit" ID="ID_564522622" CREATED="1707259637688" MODIFIED="1707259637688"/>
<node ID="ID_675868817" CREATED="1707259637689" MODIFIED="1707503856148"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Descriptive metadata: Metadata that <u>describes </u>a piece of data and can be used to <u>identify</u>&#xa0;it at a later point in time
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Digital photo: An electronic or computer-based image usually in BMP or JPG format" ID="ID_626238598" CREATED="1707259637690" MODIFIED="1707259637690"/>
<node ID="ID_561794472" TREE_ID="ID_1997554382"/>
<node TEXT="Equation: A calculation that involves addition, subtraction, multiplication, or division (also called a math expression)" ID="ID_1387279190" CREATED="1707259637693" MODIFIED="1707259637693"/>
<node TEXT="Ethics: Well-founded standards of right and wrong that prescribe what humans ought to do, usually in terms of rights, obligations, benefits to society, fairness, or specific virtues" ID="ID_1798994963" CREATED="1707259637694" MODIFIED="1707259637694"/>
<node TEXT="Experimenter bias: The tendency for different people to observe things differently (Refer to Observer bias)" ID="ID_596756661" CREATED="1707259637694" MODIFIED="1707259637694"/>
<node TEXT="External data: Data that lives and is generated outside of an organization" ID="ID_1797301652" CREATED="1707259637695" MODIFIED="1707259637695"/>
<node TEXT="Fairness: A quality of data analysis that does not create or reinforce bias" ID="ID_1280195795" CREATED="1707259637696" MODIFIED="1707259637696"/>
<node TEXT="Field: A single piece of information from a row or column of a spreadsheet; in a data table, typically a column in the table" ID="ID_144613071" CREATED="1707259637696" MODIFIED="1707259637696"/>
<node TEXT="Fill handle: A box in the lower-right-hand corner of a selected spreadsheet cell that can be dragged through neighboring cells in order to continue an instruction" ID="ID_1345045321" CREATED="1707259637697" MODIFIED="1707259637697"/>
<node TEXT="Filtering: The process of showing only the data that meets a specified criteria while hiding the rest" ID="ID_742303107" CREATED="1707259637698" MODIFIED="1707259637698"/>
<node TEXT="First-party data: Data collected by an individual or group using their own resources" FOLDED="true" ID="ID_1079928394" CREATED="1707259637698" MODIFIED="1707259637698">
<node TEXT="preferred method" ID="ID_345894129" CREATED="1707261665617" MODIFIED="1707261668490"/>
</node>
<node TEXT="Foreign key: A field within a database table that is a primary key in another table (Refer to primary key)" ID="ID_64500578" CREATED="1707259637699" MODIFIED="1707259637699"/>
<node TEXT="Formula: A set of instructions used to perform a calculation using the data in a spreadsheet" ID="ID_1384575707" CREATED="1707259637700" MODIFIED="1707259637700"/>
<node TEXT="FROM: The section of a query that indicates where the selected data comes from" ID="ID_1052783296" CREATED="1707259637701" MODIFIED="1707259637701"/>
<node TEXT="Function: A preset command that automatically performs a specified process or task using the data in a spreadsheet" ID="ID_1148665720" CREATED="1707259637702" MODIFIED="1707259637702"/>
<node TEXT="Gap analysis: A method for examining and evaluating the current state of a process in order to identify opportunities for improvement in the future" ID="ID_1474300339" CREATED="1707259637703" MODIFIED="1707259637703"/>
<node TEXT="General Data Protection Regulation of the European Union (GDPR): Policy-making body in the European Union created to help protect people and their data" ID="ID_1715626534" CREATED="1707259637704" MODIFIED="1707259637704"/>
<node TEXT="Geolocation: The geographical location of a person or device by means of digital information" ID="ID_707488610" CREATED="1707259637705" MODIFIED="1707259637705"/>
<node TEXT="Good data source: A data source that is reliable, original, comprehensive, current, and cited (ROCCC)" ID="ID_648414547" CREATED="1707259637706" MODIFIED="1707259637706"/>
<node TEXT="Header: The first row in a spreadsheet that labels the type of data in each column" ID="ID_605225687" CREATED="1707259637707" MODIFIED="1707259637707"/>
<node TEXT="Internal data: Data that lives within a company’s own systems" ID="ID_284379409" CREATED="1707259637708" MODIFIED="1707259637708"/>
<node TEXT="Interpretation bias: The tendency to interpret ambiguous situations in a positive or negative way" ID="ID_98794251" CREATED="1707259637708" MODIFIED="1707259637708"/>
<node TEXT="Leading question: A question that steers people toward a certain response" ID="ID_567630917" CREATED="1707259637711" MODIFIED="1707259637711"/>
<node TEXT="Long data: A dataset in which each row is one time point per subject, so each subject has data in multiple rows" FOLDED="true" ID="ID_1190646486" CREATED="1707259637711" MODIFIED="1707259637711">
<node TEXT="benefits" FOLDED="true" ID="ID_1424498196" CREATED="1707331362362" MODIFIED="1707331415161">
<node TEXT="great for storing and organizing data when there&apos;s multiple variables for each subject each time point that we want to observe" ID="ID_879659318" CREATED="1707331427136" MODIFIED="1707331508332"/>
<node TEXT="store and analyze all data using fewer columns" ID="ID_761830950" CREATED="1707331517763" MODIFIED="1707331527916"/>
<node TEXT="if we had a new variable, only need one more column" ID="ID_958059518" CREATED="1707331527929" MODIFIED="1707331568725"/>
</node>
<node TEXT="preferred when" FOLDED="true" ID="ID_798612372" CREATED="1707332113357" MODIFIED="1707332116528">
<node TEXT="storing a lot of variables about each subject" ID="ID_797357583" CREATED="1707332116530" MODIFIED="1707332122913"/>
<node TEXT="performing advanced statistical analysis or graphing" ID="ID_1848197391" CREATED="1707332122929" MODIFIED="1707332128732"/>
</node>
</node>
<node TEXT="Math expression: A calculation that involves addition, subtraction, multiplication, or division (also called an equation)" ID="ID_186411897" CREATED="1707259637712" MODIFIED="1707259637712"/>
<node TEXT="Math function: A function that is used as part of a mathematical formula" ID="ID_1505948045" CREATED="1707259637712" MODIFIED="1707259637712"/>
<node TEXT="MAX: A spreadsheet function that returns the largest numeric value from a range of cells" ID="ID_1034865342" CREATED="1707259637713" MODIFIED="1707259637713"/>
<node TEXT="Measurable question: A question whose answers can be quantified and assessed" ID="ID_1275239576" CREATED="1707259637714" MODIFIED="1707259637714"/>
<node TEXT="Mentor: Someone who shares knowledge, skills, and experience to help another grow both professionally and personally" ID="ID_226815566" CREATED="1707259637714" MODIFIED="1707259637714"/>
<node TEXT="Metadata: Data about data" FOLDED="true" ID="ID_1400367438" CREATED="1707259637715" MODIFIED="1707259637715">
<node TEXT="used to understand this about data " FOLDED="true" ID="ID_104817018" CREATED="1707504134456" MODIFIED="1707504195194">
<node TEXT="content" ID="ID_1655297318" CREATED="1707504140711" MODIFIED="1707504144297"/>
<node TEXT="context" ID="ID_1348210739" CREATED="1707504144305" MODIFIED="1707504146903"/>
<node TEXT="how it structured" ID="ID_631431541" CREATED="1707504146911" MODIFIED="1707504150249"/>
</node>
<node TEXT="types" FOLDED="true" ID="ID_1154229933" CREATED="1707503913711" MODIFIED="1707503915946">
<node ID="ID_867134954" TREE_ID="ID_675868817"/>
<node ID="ID_207126650" CREATED="1707259637753" MODIFIED="1707503848160"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Structural metadata: Metadata that indicates how a piece of data is <b><u>organized</u></b>&#xa0;and whether it is part of one or more than one data collection
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1455266305" TREE_ID="ID_144895854"/>
</node>
<node TEXT="type of information" FOLDED="true" ID="ID_1350587479" CREATED="1707504019739" MODIFIED="1707504038334">
<node TEXT="File or document type: What type of file or document are you examining?" ID="ID_1462849197" CREATED="1707504059354" MODIFIED="1707504059354"/>
<node TEXT="Date, time, and creator: When was it created? Who created it? When was it last modified?" ID="ID_1337306009" CREATED="1707504059354" MODIFIED="1707504059354"/>
<node TEXT="Title and description: What is the name of the item you are examining? What type of content does it contain?" ID="ID_309079556" CREATED="1707504059356" MODIFIED="1707504059356"/>
<node TEXT="Geolocation: If you’re examining a photo, where was it taken?" ID="ID_1278475512" CREATED="1707504059359" MODIFIED="1707504059359"/>
<node TEXT="Tags and categories: What is the general overview of the item that you have? Is it indexed or described in a specific way?" ID="ID_986423180" CREATED="1707504059360" MODIFIED="1707504059360"/>
<node TEXT="Who last modified it and when: Were any changes made to the file? If yes, when were the most recent modifications made?" ID="ID_1531336" CREATED="1707504059361" MODIFIED="1707504059361"/>
<node TEXT="Who can access or update it: If you’re examining a dataset, is it public? Are special permissions needed to customize or modify it?" ID="ID_1103129924" CREATED="1707504059364" MODIFIED="1707504059364"/>
</node>
<node TEXT="benefits" FOLDED="true" ID="ID_1992639856" CREATED="1707504231464" MODIFIED="1707504236710">
<node TEXT="reliability" FOLDED="true" ID="ID_959683850" CREATED="1707504236712" MODIFIED="1707504240507">
<node TEXT="Metadata helps data analysts confirm their data is reliable by making sure it is:" FOLDED="true" ID="ID_538973023" CREATED="1707504313956" MODIFIED="1707504313956">
<node TEXT="Accurate" ID="ID_259530355" CREATED="1707504313956" MODIFIED="1707504313956"/>
<node TEXT="Precise" ID="ID_99852485" CREATED="1707504313959" MODIFIED="1707504313959"/>
<node TEXT="Relevant" ID="ID_459754551" CREATED="1707504313960" MODIFIED="1707504313960"/>
<node TEXT="Timely" ID="ID_1695734697" CREATED="1707504313961" MODIFIED="1707504313961"/>
</node>
</node>
<node TEXT="consistency" FOLDED="true" ID="ID_1075654590" CREATED="1707504240516" MODIFIED="1707504298609">
<node TEXT="When data is uniform, it is:" FOLDED="true" ID="ID_134243731" CREATED="1707504356335" MODIFIED="1707504356335">
<node TEXT="Organized: Data analysts can easily find tables and files, monitor the creation and alteration of assets, and store metadata." ID="ID_364974895" CREATED="1707504356335" MODIFIED="1707504356335"/>
<node TEXT="Classified: Data analysts can categorize data when it follows a consistent format, which is beneficial in cleaning and processing data." ID="ID_199517457" CREATED="1707504356336" MODIFIED="1707504356336"/>
<node TEXT="Stored: Consistent and uniform data can be efficiently stored in various data repositories. This streamlines storage management tasks such as managing a database." ID="ID_618461348" CREATED="1707504356339" MODIFIED="1707504356339"/>
<node TEXT="Accessed: Users, applications, and systems can efficiently locate and use data." ID="ID_1201566032" CREATED="1707504356342" MODIFIED="1707504356342"/>
</node>
</node>
</node>
<node TEXT="Metadata repositories: specialized databases specifically created to store and manage metadata" FOLDED="true" ID="ID_975848248" CREATED="1707504391326" MODIFIED="1707504411534">
<node TEXT="describe where the metadata came from and store the data in an accessible form with a common structure" ID="ID_602333147" CREATED="1707504417716" MODIFIED="1707504441910"/>
<node TEXT="bring together multiple sources for data analysis by describing the state and location of the data, the structure of the tables inside the data, and who accessed the user logs" ID="ID_1451216921" CREATED="1707504441917" MODIFIED="1707504489947"/>
</node>
</node>
<node TEXT="Metadata repository: A database created to store metadata" ID="ID_1810290756" CREATED="1707259637716" MODIFIED="1707259637716"/>
<node TEXT="Metric: A single, quantifiable type of data that is used for measurement" ID="ID_1883885560" CREATED="1707259637716" MODIFIED="1707259637716"/>
<node TEXT="Metric goal: A measurable goal set by a company and evaluated using metrics" ID="ID_1563459499" CREATED="1707259637717" MODIFIED="1707259637717"/>
<node TEXT="MIN: A spreadsheet function that returns the smallest numeric value from a range of cells" ID="ID_1806125294" CREATED="1707259637717" MODIFIED="1707259637717"/>
<node TEXT="Naming conventions: Consistent guidelines that describe the content, creation date, and version of a file in its name" ID="ID_1095666889" CREATED="1707259637718" MODIFIED="1707259637718"/>
<node TEXT="Networking: Building relationships by meeting people both in person and online" ID="ID_155994666" CREATED="1707259637719" MODIFIED="1707259637719"/>
<node ID="ID_1086750560" TREE_ID="ID_741688432"/>
<node TEXT="Normalized database: A database in which only related data is stored in each table" ID="ID_834540186" CREATED="1707259637720" MODIFIED="1707259637720"/>
<node TEXT="Notebook: An interactive, editable programming environment for creating data reports and showcasing data skills" ID="ID_25656326" CREATED="1707259637721" MODIFIED="1707259637721"/>
<node TEXT="Observation: The attributes that describe a piece of data contained in a row of a table" ID="ID_902783119" CREATED="1707259637722" MODIFIED="1707259637722"/>
<node TEXT="Observer bias: The tendency for different people to observe things differently (also called experimenter bias)" ID="ID_1162592130" CREATED="1707259637723" MODIFIED="1707259637723"/>
<node TEXT="Open data: Data that is available to the public" ID="ID_710312168" CREATED="1707259637724" MODIFIED="1707259637724"/>
<node ID="ID_668436682" TREE_ID="ID_425117334">
<node ID="ID_593672509" TREE_ID="ID_1455481654">
<node ID="ID_618159597" TREE_ID="ID_1058903015">
<node ID="ID_640203363" TREE_ID="ID_1392816653"/>
<node ID="ID_1100612809" TREE_ID="ID_432697076"/>
<node ID="ID_1213119277" TREE_ID="ID_683729779"/>
</node>
<node ID="ID_1808157542" TREE_ID="ID_1055940120">
<node ID="ID_672041030" TREE_ID="ID_49787354">
<node ID="ID_89622509" TREE_ID="ID_1698246656"/>
</node>
<node ID="ID_28645033" TREE_ID="ID_487512308"/>
</node>
<node ID="ID_1403270761" TREE_ID="ID_1486176753">
<node ID="ID_323444974" TREE_ID="ID_825713552"/>
</node>
</node>
</node>
<node TEXT="Operator: A symbol that names the operation or calculation to be performed" ID="ID_1393108469" CREATED="1707259637725" MODIFIED="1707259637725"/>
<node TEXT="Order of operations: Using parentheses to group together spreadsheet values in order to clarify the order in which operations should be performed" ID="ID_343959532" CREATED="1707259637726" MODIFIED="1707259637726"/>
<node ID="ID_1463789772" TREE_ID="ID_1599226023"/>
<node ID="ID_929887335" TREE_ID="ID_1713865785"/>
<node TEXT="Pivot chart: A chart created from the fields in a pivot table" ID="ID_401214769" CREATED="1707259637728" MODIFIED="1707259637728"/>
<node TEXT="Pivot table: A data summarization tool used to sort, reorganize, group, count, total, or average data" ID="ID_275511090" CREATED="1707259637729" MODIFIED="1707259637729"/>
<node TEXT="Pixel: In digital imaging, a small area of illumination on a display screen that, when combined with other adjacent areas, forms a digital image" ID="ID_181559345" CREATED="1707259637729" MODIFIED="1707259637729"/>
<node TEXT="Population: In data analytics, all possible data values in a dataset" ID="ID_1615926867" CREATED="1707259637730" MODIFIED="1707259637730"/>
<node TEXT="Primary key: An identifier in a database that references a column in which each value is unique (Refer to foreign key)" FOLDED="true" ID="ID_775266484" CREATED="1707259637730" MODIFIED="1707259637730">
<node TEXT="some tables don&apos;t require a primary key" ID="ID_610105264" CREATED="1707503232248" MODIFIED="1707503239462"/>
</node>
<node TEXT="Problem domain: The area of analysis that encompasses every activity affecting or affected by a problem" ID="ID_1164292065" CREATED="1707259637731" MODIFIED="1707259637731"/>
<node TEXT="Problem types: The various problems that data analysts encounter, including categorizing things, discovering connections, finding patterns, identifying themes, making predictions, and spotting something unusual" ID="ID_1046771015" CREATED="1707259637731" MODIFIED="1707259637731"/>
<node TEXT="Qualitative data: A subjective and explanatory measure of a quality or characteristic" ID="ID_191198704" CREATED="1707259637734" MODIFIED="1707259637734"/>
<node TEXT="Quantitative data: A specific and objective measure, such as a number, quantity, or range" ID="ID_1593041193" CREATED="1707259637735" MODIFIED="1707259637735"/>
<node TEXT="Query: A request for data or information from a database" ID="ID_211150205" CREATED="1707259637735" MODIFIED="1707259637735"/>
<node TEXT="Query language: A computer programming language used to communicate with a database" ID="ID_1542087638" CREATED="1707259637736" MODIFIED="1707259637736"/>
<node TEXT="Range: A collection of two or more cells in a spreadsheet" ID="ID_1481969728" CREATED="1707259637737" MODIFIED="1707259637737"/>
<node TEXT="Record: A collection of related data in a data table, usually synonymous with row" ID="ID_690150679" CREATED="1707259637738" MODIFIED="1707259637738"/>
<node TEXT="Redundancy: When the same piece of data is stored in two or more places" ID="ID_689737817" CREATED="1707259637738" MODIFIED="1707259637738"/>
<node TEXT="Reframing: The process of restating a problem or challenge, then redirecting it toward a potential resolution" ID="ID_515207793" CREATED="1707259637739" MODIFIED="1707259637739"/>
<node TEXT="Relational database: A database that contains a series of tables that can be connected to form relationships" ID="ID_1626671566" CREATED="1707259637739" MODIFIED="1707259637739"/>
<node TEXT="Relevant question: A question that has significance to the problem to be solved" ID="ID_1755813413" CREATED="1707259637739" MODIFIED="1707259637739"/>
<node TEXT="Report: A static collection of data periodically given to stakeholders" ID="ID_1036151852" CREATED="1707259637741" MODIFIED="1707259637741"/>
<node TEXT="Return on investment (ROI): A formula that uses the metrics of investment and profit to evaluate the success of an investment" ID="ID_1240352299" CREATED="1707259637742" MODIFIED="1707259637742"/>
<node TEXT="Revenue: The total amount of income generated by the sale of goods or services" ID="ID_1446508676" CREATED="1707259637742" MODIFIED="1707259637742"/>
<node TEXT="Root cause: The reason why a problem occurs" ID="ID_1808172918" CREATED="1707259637742" MODIFIED="1707259637742"/>
<node TEXT="Sample: In data analytics, a segment of a population that is representative of the entire population" ID="ID_1690284276" CREATED="1707259637744" MODIFIED="1707259637744"/>
<node ID="ID_1765082087" TREE_ID="ID_1078916976">
<node ID="ID_1375393288" TREE_ID="ID_1987022791">
<node ID="ID_351334173" TREE_ID="ID_1982617196"/>
</node>
</node>
<node TEXT="Schema: A way of describing how something, such as data, is organized" ID="ID_1897417018" CREATED="1707259637744" MODIFIED="1707259637744"/>
<node TEXT="Scope of work (SOW): An agreed-upon outline of the tasks to be performed during a project" ID="ID_1871974292" CREATED="1707259637745" MODIFIED="1707259637745"/>
<node TEXT="Second-party data: Data collected by a group directly from its audience and then sold" ID="ID_27505954" CREATED="1707259637746" MODIFIED="1707259637746"/>
<node TEXT="SELECT: The section of a query that indicates the subset of a dataset" ID="ID_1482479915" CREATED="1707259637746" MODIFIED="1707259637746"/>
<node TEXT="Small data: Small, specific data points typically involving a short period of time, which are useful for making day-to-day decisions" ID="ID_744941880" CREATED="1707259637748" MODIFIED="1707259637748"/>
<node TEXT="SMART methodology: A tool for determining a question’s effectiveness based on whether it is specific, measurable, action-oriented, relevant, and time-bound" ID="ID_844287307" CREATED="1707259637748" MODIFIED="1707259637748"/>
<node TEXT="Social media: Websites and applications through which users create and share content or participate in social networking" ID="ID_1750170748" CREATED="1707259637748" MODIFIED="1707259637748"/>
<node TEXT="Sorting: The process of arranging data into a meaningful order to make it easier to understand, analyze, and visualize" ID="ID_623681594" CREATED="1707259637749" MODIFIED="1707259637749"/>
<node TEXT="Specific question: A question that is simple, significant, and focused on a single topic or a few closely related ideas" ID="ID_98044072" CREATED="1707259637750" MODIFIED="1707259637750"/>
<node TEXT="Sponsor: A professional advocate who is committed to moving forward the career of another" ID="ID_936030494" CREATED="1707259637750" MODIFIED="1707259637750"/>
<node TEXT="Spreadsheet: A digital worksheet" ID="ID_485366436" CREATED="1707259637751" MODIFIED="1707259637751"/>
<node TEXT="SQL: (Refer to Structured Query Language)" ID="ID_408157908" CREATED="1707259637751" MODIFIED="1707259637751"/>
<node TEXT="Stakeholders: People who invest time and resources into a project and are interested in its outcome" ID="ID_1682226606" CREATED="1707259637751" MODIFIED="1707259637751"/>
<node ID="ID_1380250360" TREE_ID="ID_327832251"/>
<node ID="ID_581356573" TREE_ID="ID_207126650"/>
<node TEXT="Structured data: Data organized in a certain format such as rows and columns" FOLDED="true" ID="ID_817091187" CREATED="1707259637754" MODIFIED="1707259637754">
<node TEXT="characteristics" FOLDED="true" ID="ID_905307665" CREATED="1707265787334" MODIFIED="1707265797668">
<node TEXT="define datatypes" ID="ID_1955441327" CREATED="1707265797670" MODIFIED="1707265803022"/>
<node TEXT="most often quantitative data" ID="ID_128302317" CREATED="1707265803038" MODIFIED="1707265807621"/>
<node TEXT="easy to" FOLDED="true" ID="ID_1943701917" CREATED="1707265807640" MODIFIED="1707265810637">
<node TEXT="organize" ID="ID_1477234090" CREATED="1707265810652" MODIFIED="1707265813240"/>
<node TEXT="search" ID="ID_1271679259" CREATED="1707265813257" MODIFIED="1707265820640"/>
<node TEXT="analyze" ID="ID_1968356537" CREATED="1707265820656" MODIFIED="1707265823434"/>
</node>
</node>
<node TEXT="stored in" FOLDED="true" ID="ID_1496921695" CREATED="1707265827598" MODIFIED="1707265876031">
<node TEXT="table" ID="ID_50723928" CREATED="1707263454255" MODIFIED="1707263462422"/>
<node TEXT="spreadsheet" ID="ID_1880684194" CREATED="1707263462437" MODIFIED="1707263466627"/>
<node TEXT="relational database" ID="ID_157704053" CREATED="1707263466642" MODIFIED="1707263470062"/>
<node ID="ID_65121841" CREATED="1707265884857" MODIFIED="1707265884857"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      data warehouses
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="works nicely within a data model" FOLDED="true" ID="ID_1929096770" CREATED="1707265528957" MODIFIED="1707265539735">
<node ID="ID_749808144" TREE_ID="ID_1336425361">
<node ID="ID_1129182437" TREE_ID="ID_1168499084"/>
<node ID="ID_747384435" TREE_ID="ID_1289588120"/>
<node ID="ID_516872060" TREE_ID="ID_1181564039">
<node ID="ID_1563645265" TREE_ID="ID_1136046139"/>
</node>
</node>
</node>
</node>
<node TEXT="Structured Query Language: A computer programming language used to communicate with a database" ID="ID_1194131181" CREATED="1707259637755" MODIFIED="1707259637755"/>
<node TEXT="Structured thinking: The process of recognizing the current problem or situation, organizing available information, revealing gaps and opportunities, and identifying options" ID="ID_554425341" CREATED="1707259637756" MODIFIED="1707259637756"/>
<node TEXT="SUM: A spreadsheet function that adds the values of a selected range of cells" ID="ID_1322136704" CREATED="1707259637756" MODIFIED="1707259637756"/>
<node TEXT="Technical mindset: The ability to break things down into smaller steps or pieces and work with them in an orderly and logical way" ID="ID_1255079526" CREATED="1707259637758" MODIFIED="1707259637758"/>
<node ID="ID_428603952" TREE_ID="ID_292300196"/>
<node TEXT="Third-party data: Data provided from outside sources who didn’t collect it directly" FOLDED="true" ID="ID_414037554" CREATED="1707259637759" MODIFIED="1707259637759">
<node TEXT="not as reliable" ID="ID_1140946322" CREATED="1707262250635" MODIFIED="1707262253866"/>
<node TEXT="ticket for" FOLDED="true" ID="ID_1192376729" CREATED="1707262257650" MODIFIED="1707262260845">
<node TEXT="accuracy" ID="ID_111275438" CREATED="1707262260846" MODIFIED="1707262263225"/>
<node TEXT="bias" ID="ID_860923761" CREATED="1707262263233" MODIFIED="1707262265432"/>
<node TEXT="credibility" ID="ID_1393403193" CREATED="1707262265451" MODIFIED="1707262271647"/>
</node>
</node>
<node TEXT="Time-bound question: A question that specifies a timeframe to be studied" ID="ID_173163004" CREATED="1707259637760" MODIFIED="1707259637760"/>
<node ID="ID_1065386615" TREE_ID="ID_802245375"/>
<node TEXT="Turnover rate: The rate at which employees voluntarily leave a company" ID="ID_1952607334" CREATED="1707259637761" MODIFIED="1707259637761"/>
<node ID="ID_15922137" TREE_ID="ID_1982617196"/>
<node TEXT="Unfair question: A question that makes assumptions or is difficult to answer honestly" ID="ID_1654669645" CREATED="1707259637762" MODIFIED="1707259637762"/>
<node TEXT="United States Census Bureau: An agency in the U.S. Department of Commerce that serves as the nation’s leading provider of quality data about its people and economy" ID="ID_1858544538" CREATED="1707259637763" MODIFIED="1707259637763"/>
<node TEXT="Unstructured data: Data that is not organized in any easily identifiable manner" FOLDED="true" ID="ID_1646534972" CREATED="1707259637764" MODIFIED="1707259637764">
<node TEXT="characteristics" FOLDED="true" ID="ID_1494628602" CREATED="1707265906758" MODIFIED="1707265910255">
<node TEXT="varied datatypes" ID="ID_1443629112" CREATED="1707265910257" MODIFIED="1707265918222"/>
<node TEXT="most often qualitative data" ID="ID_1124614683" CREATED="1707265918236" MODIFIED="1707265922838"/>
<node TEXT="difficult to search" ID="ID_1883556701" CREATED="1707265922853" MODIFIED="1707265926031"/>
<node TEXT="provides more freedom for analysis" ID="ID_890955138" CREATED="1707265926047" MODIFIED="1707265931623"/>
<node TEXT="stored in" FOLDED="true" ID="ID_519901327" CREATED="1707265931637" MODIFIED="1707265936463">
<node TEXT="data lakes" ID="ID_358465287" CREATED="1707265937141" MODIFIED="1707265943575"/>
<node TEXT="data warehouses" ID="ID_27371128" CREATED="1707265944278" MODIFIED="1707265947735"/>
<node TEXT="NoSQL databases" ID="ID_1894227213" CREATED="1707265948429" MODIFIED="1707265953927"/>
</node>
<node TEXT="can&apos;t be put into rows and columns" ID="ID_954082360" CREATED="1707265960534" MODIFIED="1707265973327"/>
</node>
<node TEXT="examples" FOLDED="true" ID="ID_901589497" CREATED="1707265444429" MODIFIED="1707265447637">
<node TEXT="audiophiles" ID="ID_1974569756" CREATED="1707265447638" MODIFIED="1707265451021"/>
<node TEXT="video files" ID="ID_1102427609" CREATED="1707265451036" MODIFIED="1707265453027"/>
<node TEXT="e-mails" ID="ID_875841496" CREATED="1707265453037" MODIFIED="1707265455039"/>
<node TEXT="photos" ID="ID_1373267741" CREATED="1707265455055" MODIFIED="1707265457028"/>
<node TEXT="social media" FOLDED="true" ID="ID_724037549" CREATED="1707265457041" MODIFIED="1707265459460">
<node TEXT="comments" ID="ID_1920915762" CREATED="1707265981454" MODIFIED="1707265984919"/>
</node>
<node TEXT="log files" ID="ID_336806259" CREATED="1707265988734" MODIFIED="1707265991166"/>
<node TEXT="text messages" ID="ID_217438721" CREATED="1707265993846" MODIFIED="1707265996143"/>
</node>
</node>
<node TEXT="Video file: A collection of images, audio files, and other data usually encoded in a compressed format such as MP4, MV4, MOV, AVI, or FLV" ID="ID_500588608" CREATED="1707259637765" MODIFIED="1707259637765"/>
<node TEXT="Visualization: (Refer to data visualization)" ID="ID_1578662227" CREATED="1707259637765" MODIFIED="1707259637765"/>
<node TEXT="WHERE: The section of a query that specifies criteria that the requested data must meet" ID="ID_1429450644" CREATED="1707259637766" MODIFIED="1707259637766"/>
<node TEXT="Wide data: A dataset in which every data subject has a single row with multiple columns to hold the values of various attributes of the subject" FOLDED="true" ID="ID_215867909" CREATED="1707259637767" MODIFIED="1707259637767">
<node TEXT="benefits" FOLDED="true" ID="ID_1542861629" CREATED="1707328314353" MODIFIED="1707328317140">
<node TEXT="easily identify and quickly compare different columns" ID="ID_1083926711" CREATED="1707328317143" MODIFIED="1707328324344"/>
<node TEXT="compare at different points in time" ID="ID_582455795" CREATED="1707331379930" MODIFIED="1707331391983"/>
</node>
<node TEXT="preferred when" FOLDED="true" ID="ID_993481016" CREATED="1707332090565" MODIFIED="1707332096338">
<node TEXT="creating tables and charts with a few variables about each subject" ID="ID_1018528693" CREATED="1707332096340" MODIFIED="1707332103112"/>
<node TEXT="comparing straightforward line graphs" ID="ID_1692675627" CREATED="1707332103130" MODIFIED="1707332107756"/>
</node>
</node>
<node TEXT="World Health Organization: An organization whose primary role is to direct and coordinate international health within the United Nations system" ID="ID_827749033" CREATED="1707259637768" MODIFIED="1707259637768"/>
</node>
<node TEXT="Datatypes and structures M1" POSITION="top_or_left" ID="ID_1485610515" CREATED="1707259750834" MODIFIED="1708126736746">
<node TEXT="Data exploration" FOLDED="true" ID="ID_1806597178" CREATED="1707259760227" MODIFIED="1707260432038">
<node TEXT="Collect data" FOLDED="true" ID="ID_595938083" CREATED="1707261213836" MODIFIED="1707261216490">
<node TEXT="How data is collected" FOLDED="true" ID="ID_562169828" CREATED="1707261371865" MODIFIED="1707261377245">
<node TEXT="Interviews" ID="ID_127208709" CREATED="1707261378433" MODIFIED="1707261384252"/>
<node TEXT="Observations" ID="ID_1708296809" CREATED="1707261398704" MODIFIED="1707261402443"/>
<node TEXT="Forms" ID="ID_216557702" CREATED="1707261402453" MODIFIED="1707261429250"/>
<node TEXT="Questionnaires" ID="ID_211490403" CREATED="1707261410836" MODIFIED="1707261429251"/>
<node TEXT="Surveys" ID="ID_492864336" CREATED="1707261413045" MODIFIED="1707261429251"/>
<node TEXT="Knowing how data has been generated can help add context to the data" ID="ID_41784483" CREATED="1707261464489" MODIFIED="1707261483036"/>
<node TEXT="Knowing how to collect it can make the data analysis process more efficient" ID="ID_212021726" CREATED="1707261484626" MODIFIED="1707261494052"/>
</node>
<node TEXT="Determine what data to collect" FOLDED="true" ID="ID_1868034809" CREATED="1707261581408" MODIFIED="1707261587354">
<node TEXT="Data collection considerations" FOLDED="true" ID="ID_794671015" CREATED="1707262304873" MODIFIED="1707262318794">
<node TEXT="How the data will be collected" FOLDED="true" ID="ID_218293849" CREATED="1707262320434" MODIFIED="1707262326230">
<node TEXT="choose data sources" FOLDED="true" ID="ID_959725352" CREATED="1707262326246" MODIFIED="1707262330020">
<node TEXT="data sources" FOLDED="true" ID="ID_338074501" CREATED="1707261610489" MODIFIED="1707261614439">
<node ID="ID_1611483032" TREE_ID="ID_1079928394">
<node ID="ID_371113787" TREE_ID="ID_345894129"/>
</node>
<node ID="ID_1976193032" TREE_ID="ID_27505954"/>
<node ID="ID_1351166654" TREE_ID="ID_414037554">
<node ID="ID_1594346356" TREE_ID="ID_1140946322"/>
<node ID="ID_845534434" TREE_ID="ID_1192376729">
<node ID="ID_273455991" TREE_ID="ID_111275438"/>
<node ID="ID_1543510231" TREE_ID="ID_860923761"/>
<node ID="ID_1212209322" TREE_ID="ID_1393403193"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="decide what data to use" FOLDED="true" ID="ID_705039942" CREATED="1707262330033" MODIFIED="1707262333433">
<node TEXT="choose the data that can help you find answers and solve problems" ID="ID_889293280" CREATED="1707262370440" MODIFIED="1707262379625"/>
<node TEXT="don&apos;t get distracted by other data" ID="ID_1679161093" CREATED="1707262379641" MODIFIED="1707262384664"/>
</node>
<node TEXT="how much data to collect" FOLDED="true" ID="ID_324431759" CREATED="1707262407462" MODIFIED="1707262437864">
<node TEXT="data sample" FOLDED="true" ID="ID_1986155948" CREATED="1707262439644" MODIFIED="1707262450047">
<node TEXT="" ID="ID_1095573951" CREATED="1707262450049" MODIFIED="1707262450049"/>
</node>
</node>
<node TEXT="select the right data type" ID="ID_1300644043" CREATED="1707262456066" MODIFIED="1707262469288"/>
<node TEXT="determine the timeframe" ID="ID_1962776517" CREATED="1707262478659" MODIFIED="1707262509073"/>
</node>
</node>
</node>
<node TEXT="Differentiate data formats and structures" FOLDED="true" ID="ID_960307591" CREATED="1707262856344" MODIFIED="1707262862522">
<node TEXT="reference" FOLDED="true" ID="ID_607067923" CREATED="1707263659040" MODIFIED="1707263662438">
<node ID="ID_70512107" CREATED="1707263663502" MODIFIED="1707263663502" LINK="https://www.coursera.org/learn/data-preparation/supplement/mBSNa/data-formats-in-practice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/supplement/mBSNa/data-formats-in-practice">Data formats in practice | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1968031222" CREATED="1707266014900" MODIFIED="1707266014900" LINK="https://www.coursera.org/learn/data-preparation/supplement/tkt9D/the-effects-of-different-structures"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/supplement/tkt9D/the-effects-of-different-structures">The effects of different structures | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1926966890" TREE_ID="ID_572974285">
<node ID="ID_151924227" TREE_ID="ID_741688432"/>
<node ID="ID_1722395584" TREE_ID="ID_1599226023"/>
</node>
<node ID="ID_286087187" TREE_ID="ID_209744112">
<node ID="ID_1547605300" TREE_ID="ID_1997554382"/>
<node ID="ID_1033078443" TREE_ID="ID_1661336324"/>
</node>
<node ID="ID_739078533" TREE_ID="ID_284379409"/>
<node ID="ID_1572764793" TREE_ID="ID_1797301652"/>
<node ID="ID_865201784" TREE_ID="ID_817091187">
<node ID="ID_824773996" TREE_ID="ID_905307665">
<node ID="ID_204086746" TREE_ID="ID_1955441327"/>
<node ID="ID_1134046367" TREE_ID="ID_128302317"/>
<node ID="ID_365425818" TREE_ID="ID_1943701917">
<node ID="ID_1324909101" TREE_ID="ID_1477234090"/>
<node ID="ID_1834176750" TREE_ID="ID_1271679259"/>
<node ID="ID_952311953" TREE_ID="ID_1968356537"/>
</node>
</node>
<node ID="ID_1923745975" TREE_ID="ID_1496921695">
<node ID="ID_655425570" TREE_ID="ID_50723928"/>
<node ID="ID_1686827784" TREE_ID="ID_1880684194"/>
<node ID="ID_390869983" TREE_ID="ID_157704053"/>
<node ID="ID_932397090" TREE_ID="ID_65121841"/>
</node>
<node ID="ID_384044585" TREE_ID="ID_1929096770">
<node ID="ID_626830836" TREE_ID="ID_1336425361">
<node ID="ID_799178575" TREE_ID="ID_1168499084"/>
<node ID="ID_1652913170" TREE_ID="ID_1289588120"/>
<node ID="ID_1724634697" TREE_ID="ID_1181564039">
<node ID="ID_693949634" TREE_ID="ID_1136046139"/>
</node>
</node>
</node>
</node>
<node ID="ID_1450229462" TREE_ID="ID_1646534972">
<node ID="ID_430631130" TREE_ID="ID_1494628602">
<node ID="ID_1031441142" TREE_ID="ID_1443629112"/>
<node ID="ID_1753290374" TREE_ID="ID_1124614683"/>
<node ID="ID_1399724141" TREE_ID="ID_1883556701"/>
<node ID="ID_1860502880" TREE_ID="ID_890955138"/>
<node ID="ID_634217446" TREE_ID="ID_519901327">
<node ID="ID_477358374" TREE_ID="ID_358465287"/>
<node ID="ID_969259661" TREE_ID="ID_27371128"/>
<node ID="ID_514241745" TREE_ID="ID_1894227213"/>
</node>
<node ID="ID_1234756678" TREE_ID="ID_954082360"/>
</node>
<node ID="ID_1853588375" TREE_ID="ID_901589497">
<node ID="ID_1284646572" TREE_ID="ID_1974569756"/>
<node ID="ID_624043890" TREE_ID="ID_1102427609"/>
<node ID="ID_1426984272" TREE_ID="ID_875841496"/>
<node ID="ID_308974125" TREE_ID="ID_1373267741"/>
<node ID="ID_227578807" TREE_ID="ID_724037549">
<node ID="ID_943760534" TREE_ID="ID_1920915762"/>
</node>
<node ID="ID_1946931101" TREE_ID="ID_336806259"/>
<node ID="ID_995065403" TREE_ID="ID_217438721"/>
</node>
</node>
</node>
<node TEXT="Data modeling levels and techniques" FOLDED="true" ID="ID_1681986848" CREATED="1707266170222" MODIFIED="1707266179269">
<node TEXT="reference" FOLDED="true" ID="ID_101779391" CREATED="1707266185646" MODIFIED="1707266187862">
<node ID="ID_1590169981" CREATED="1707266192076" MODIFIED="1707266192076" LINK="https://www.coursera.org/learn/data-preparation/supplement/vtp7L/data-modeling-levels-and-techniques"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/supplement/vtp7L/data-modeling-levels-and-techniques">Data modeling levels and techniques | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Data modeling: the process of creating diagrams the visually represent how data is organized and structured" FOLDED="true" ID="ID_717415653" CREATED="1707266213750" MODIFIED="1707266239645">
<node ID="ID_894631883" TREE_ID="ID_1336425361">
<node ID="ID_1481498648" TREE_ID="ID_1168499084"/>
<node ID="ID_1073354468" TREE_ID="ID_1289588120"/>
<node ID="ID_505180181" TREE_ID="ID_1181564039">
<node ID="ID_535372425" TREE_ID="ID_1136046139"/>
</node>
</node>
<node TEXT="can help you explore the high-level details of your data and how it is related across the organization &apos;s information systems" ID="ID_727718271" CREATED="1707267046964" MODIFIED="1707267059806"/>
<node TEXT="Levels of data modeling" FOLDED="true" ID="ID_1386423421" CREATED="1707266358693" MODIFIED="1707266365443">
<node TEXT="Conceptual data modeling" FOLDED="true" ID="ID_968654131" CREATED="1707266365444" MODIFIED="1707266858259">
<node TEXT="high-level view of the data structure" FOLDED="true" ID="ID_1018842547" CREATED="1707266379032" MODIFIED="1707266383846">
<node TEXT="doesn&apos;t contain technical details" ID="ID_81290848" CREATED="1707266415069" MODIFIED="1707266420095"/>
<node TEXT="how data interacts across an organization" ID="ID_545293898" CREATED="1707266386046" MODIFIED="1707266390774"/>
<node TEXT="example" FOLDED="true" ID="ID_222775456" CREATED="1707266394669" MODIFIED="1707266399048">
<node TEXT="used to define the business requirements for a new database" ID="ID_1787746184" CREATED="1707266399049" MODIFIED="1707266404766"/>
</node>
</node>
</node>
<node TEXT="Logical data modeling" FOLDED="true" ID="ID_1292994205" CREATED="1707266369840" MODIFIED="1707266865482">
<node TEXT="focuses on the technical details of a database such as" FOLDED="true" ID="ID_424833444" CREATED="1707266732254" MODIFIED="1707266742639">
<node TEXT="relationships" ID="ID_477252408" CREATED="1707266742641" MODIFIED="1707266745230"/>
<node TEXT="attributes" ID="ID_1438983867" CREATED="1707266745243" MODIFIED="1707266747237"/>
<node TEXT="entities" ID="ID_1792133176" CREATED="1707266747249" MODIFIED="1707266750247"/>
</node>
<node TEXT="defines how individual records are uniquely identified in a database" ID="ID_556948029" CREATED="1707266752258" MODIFIED="1707266776848"/>
<node TEXT="doesn&apos;t spell out actual names of database tables" ID="ID_1452331400" CREATED="1707266779050" MODIFIED="1707266789071"/>
</node>
<node TEXT="Physical data modeling" FOLDED="true" ID="ID_1178956692" CREATED="1707266372244" MODIFIED="1707266870881">
<node TEXT="depicts how a database operates" ID="ID_569497247" CREATED="1707266792628" MODIFIED="1707266796823"/>
<node TEXT="defines all entities and attributes used" FOLDED="true" ID="ID_1246852382" CREATED="1707266796840" MODIFIED="1707266804433">
<node TEXT="includes" FOLDED="true" ID="ID_630896652" CREATED="1707266804436" MODIFIED="1707266808036">
<node TEXT="table names" ID="ID_1968579286" CREATED="1707266808039" MODIFIED="1707266810820"/>
<node TEXT="column names" ID="ID_380534023" CREATED="1707266810837" MODIFIED="1707266812824"/>
<node TEXT="datatypes" ID="ID_823013105" CREATED="1707266812837" MODIFIED="1707266818632"/>
</node>
</node>
</node>
</node>
<node TEXT="Data modeling techniques" FOLDED="true" ID="ID_1412893608" CREATED="1707266882678" MODIFIED="1707266892634">
<node TEXT="common methods" FOLDED="true" ID="ID_294013343" CREATED="1707266892636" MODIFIED="1707266903431">
<node TEXT="Entity Relationship Diagram (ERD)" FOLDED="true" ID="ID_457800541" CREATED="1707266903432" MODIFIED="1707266913623">
<node TEXT="visual way to understand the relationship between entities in the data model" ID="ID_507128081" CREATED="1707266933261" MODIFIED="1707266941436"/>
</node>
<node TEXT="Unified Modeling Language (UML)" FOLDED="true" ID="ID_987422930" CREATED="1707266913641" MODIFIED="1707266928880">
<node TEXT="very detailed diagrams describe the structure of the system by showing the systems:" FOLDED="true" ID="ID_655011151" CREATED="1707266947044" MODIFIED="1707266969640">
<node TEXT="entities" ID="ID_870666291" CREATED="1707266969642" MODIFIED="1707266973021"/>
<node TEXT="attributes" ID="ID_1632914843" CREATED="1707266973036" MODIFIED="1707266974647"/>
<node TEXT="operations" ID="ID_1707012528" CREATED="1707266974662" MODIFIED="1707266977020"/>
<node TEXT="their relationships" ID="ID_719198669" CREATED="1707266977037" MODIFIED="1707266983640"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Explore datatypes, fields, and values" FOLDED="true" ID="ID_635784550" CREATED="1707327437565" MODIFIED="1707327450326">
<node ID="ID_1096330470" TREE_ID="ID_560184425">
<node ID="ID_1570322400" TREE_ID="ID_1085541761">
<node ID="ID_1813299020" TREE_ID="ID_327832251"/>
<node ID="ID_935778213" TREE_ID="ID_292300196"/>
<node ID="ID_1785203711" TREE_ID="ID_192050474"/>
<node ID="ID_157599192" TREE_ID="ID_222111409"/>
<node ID="ID_923318967" TREE_ID="ID_349554283"/>
</node>
</node>
<node TEXT="Boolean Logic" FOLDED="true" ID="ID_631560567" CREATED="1707327881526" MODIFIED="1707327886349">
<node TEXT="reference" FOLDED="true" ID="ID_660036120" CREATED="1707327893346" MODIFIED="1707327895928">
<node ID="ID_1566555597" CREATED="1707327897039" MODIFIED="1707327897039" LINK="https://www.coursera.org/learn/data-preparation/supplement/GgZMN/use-boolean-logic"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/supplement/GgZMN/use-boolean-logic">Use Boolean logic | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Data table components" FOLDED="true" ID="ID_1588774620" CREATED="1707327917140" MODIFIED="1707327922351">
<node TEXT="reference" FOLDED="true" ID="ID_1741500837" CREATED="1707327928542" MODIFIED="1707327930963">
<node ID="ID_1216010497" CREATED="1707327931753" MODIFIED="1707327931753" LINK="https://www.coursera.org/learn/data-preparation/lecture/nHw8B/data-table-components"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/lecture/nHw8B/data-table-components">Data table components | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Rows = Records" ID="ID_1449030332" CREATED="1707327966566" MODIFIED="1707327985524"/>
<node TEXT="Columns = Fields" ID="ID_739597395" CREATED="1707327985971" MODIFIED="1707327993986"/>
</node>
<node TEXT="Transforming data" FOLDED="true" ID="ID_781150299" CREATED="1707331594148" MODIFIED="1707331597730">
<node TEXT="shape" FOLDED="true" ID="ID_904494012" CREATED="1707331606724" MODIFIED="1707331609121">
<node ID="ID_1918960183" TREE_ID="ID_215867909">
<node ID="ID_111539241" TREE_ID="ID_1542861629">
<node ID="ID_1778298315" TREE_ID="ID_1083926711"/>
<node ID="ID_1873836034" TREE_ID="ID_582455795"/>
</node>
<node ID="ID_1220941220" TREE_ID="ID_993481016">
<node ID="ID_668619549" TREE_ID="ID_1018528693"/>
<node ID="ID_1565684891" TREE_ID="ID_1692675627"/>
</node>
</node>
<node ID="ID_804265916" TREE_ID="ID_1190646486">
<node ID="ID_4062923" TREE_ID="ID_1424498196">
<node ID="ID_1235216104" TREE_ID="ID_879659318"/>
<node ID="ID_66678169" TREE_ID="ID_761830950"/>
<node ID="ID_375357113" TREE_ID="ID_958059518"/>
</node>
<node ID="ID_1854928381" TREE_ID="ID_798612372">
<node ID="ID_1501113667" TREE_ID="ID_797357583"/>
<node ID="ID_939135341" TREE_ID="ID_1848197391"/>
</node>
</node>
</node>
<node TEXT="Data transformation:" FOLDED="true" ID="ID_1169397687" CREATED="1707331633933" MODIFIED="1707331923135">
<node TEXT="process of changing data" FOLDED="true" ID="ID_1132406434" CREATED="1707331887354" MODIFIED="1707331917166">
<node TEXT="format" ID="ID_1624220140" CREATED="1707331816136" MODIFIED="1707331819520"/>
<node TEXT="structure" ID="ID_363983864" CREATED="1707331819533" MODIFIED="1707331821514"/>
<node TEXT="values" ID="ID_841900490" CREATED="1707331821527" MODIFIED="1707331824363"/>
</node>
<node TEXT="Data transformation usually involves:" FOLDED="true" ID="ID_901625844" CREATED="1707331859573" MODIFIED="1707331859573">
<node TEXT="Adding, copying, or replicating data" ID="ID_347774547" CREATED="1707331859573" MODIFIED="1707331859573"/>
<node TEXT="Deleting fields or records" ID="ID_1904062087" CREATED="1707331859574" MODIFIED="1707331859574"/>
<node TEXT="Standardizing the names of variables" ID="ID_555475498" CREATED="1707331859574" MODIFIED="1707331859574"/>
<node TEXT="Renaming, moving, or combining columns in a database" ID="ID_1988733417" CREATED="1707331859574" MODIFIED="1707331859574"/>
<node TEXT="Joining one set of data with another" ID="ID_914923992" CREATED="1707331859575" MODIFIED="1707331859575"/>
<node TEXT="Saving a file in a different format. For example, saving a spreadsheet as a comma separated values (.csv) file." ID="ID_171530180" CREATED="1707331859575" MODIFIED="1707331859575"/>
</node>
<node TEXT="Goals" FOLDED="true" ID="ID_1215680842" CREATED="1707331934127" MODIFIED="1707332073826">
<font BOLD="true"/>
<node TEXT="Data organization: better organized data is easier to use" FOLDED="true" ID="ID_658523538" CREATED="1707331971961" MODIFIED="1707331971961">
<node TEXT="long to wide" ID="ID_1371265934" CREATED="1707332032172" MODIFIED="1707332036337"/>
</node>
<node TEXT="Data compatibility: different applications or systems can then use the same data" ID="ID_187211757" CREATED="1707331971961" MODIFIED="1707331971961"/>
<node TEXT="Data migration: data with matching formats can be moved from one system to another" ID="ID_1449301379" CREATED="1707331971961" MODIFIED="1707331971961"/>
<node TEXT="Data merging: data with the same organization can be merged together" ID="ID_752417611" CREATED="1707331971962" MODIFIED="1707331971962"/>
<node TEXT="Data enhancement: data can be displayed with more detailed fields" ID="ID_830062344" CREATED="1707331971962" MODIFIED="1707331971962"/>
<node TEXT="Data comparison: apples-to-apples comparisons of the data can then be made" ID="ID_1372482138" CREATED="1707331971962" MODIFIED="1707331971962"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Data responsibility M2" FOLDED="true" POSITION="top_or_left" ID="ID_91544661" CREATED="1707344604004" MODIFIED="1708126733167">
<node TEXT="reference" FOLDED="true" ID="ID_1895813762" CREATED="1707344611820" MODIFIED="1707344615285">
<node ID="ID_1766210777" CREATED="1707344616694" MODIFIED="1707344616694" LINK="https://www.coursera.org/learn/data-preparation/lecture/qALoI/introduction-to-bias-credibility-privacy-and-ethics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/lecture/qALoI/introduction-to-bias-credibility-privacy-and-ethics">Introduction to bias, credibility, privacy, and ethics | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="unbiased and objective data" FOLDED="true" ID="ID_946025556" CREATED="1707345903216" MODIFIED="1707350760814">
<node ID="ID_6505303" TREE_ID="ID_1942992287">
<node ID="ID_1546224111" TREE_ID="ID_269556576">
<node ID="ID_1492781057" TREE_ID="ID_53704619">
<node ID="ID_1841387954" TREE_ID="ID_1618415127"/>
<node ID="ID_1755362512" TREE_ID="ID_1734873539"/>
</node>
<node ID="ID_1655654588" TREE_ID="ID_255441033">
<node ID="ID_1431009101" TREE_ID="ID_1078916976">
<node ID="ID_834907625" TREE_ID="ID_1987022791">
<node ID="ID_460022298" TREE_ID="ID_1982617196"/>
</node>
</node>
<node ID="ID_910725587" TREE_ID="ID_1762378411"/>
<node ID="ID_6574467" TREE_ID="ID_1592205280"/>
<node ID="ID_230571229" TREE_ID="ID_841935630"/>
</node>
</node>
</node>
</node>
<node TEXT="Achieve data credibility" FOLDED="true" ID="ID_51659652" CREATED="1707350765782" MODIFIED="1707350770617">
<node TEXT="identifying good data sources" FOLDED="true" ID="ID_1938477592" CREATED="1707350833780" MODIFIED="1707350843984">
<node TEXT="Reliable" FOLDED="true" ID="ID_1061862030" CREATED="1707350843987" MODIFIED="1707350853586">
<node TEXT="accurate , complete , unbiased" ID="ID_176368482" CREATED="1707350853588" MODIFIED="1707350863383"/>
</node>
<node TEXT=" original" ID="ID_146730355" CREATED="1707350865014" MODIFIED="1707350929391"/>
<node TEXT="comprehensive" ID="ID_1454034826" CREATED="1707350929406" MODIFIED="1707350952180"/>
<node TEXT="current" ID="ID_1947757559" CREATED="1707350952192" MODIFIED="1707350955985"/>
<node TEXT="cited" FOLDED="true" ID="ID_1094014214" CREATED="1707350955996" MODIFIED="1707350966795">
<node TEXT="Who created the data set?" ID="ID_1126590564" CREATED="1707351298824" MODIFIED="1707351313386"/>
<node TEXT="Is it part of a credible organization?" ID="ID_1638903766" CREATED="1707351313398" MODIFIED="1707351320780"/>
<node TEXT="When was the data last refreshed?" ID="ID_243981561" CREATED="1707351320798" MODIFIED="1707351329192"/>
</node>
</node>
<node TEXT="bad data" FOLDED="true" ID="ID_757852235" CREATED="1707351035196" MODIFIED="1707351038406">
<node TEXT="not reliable" FOLDED="true" ID="ID_1207914946" CREATED="1707351038408" MODIFIED="1707351069415">
<node TEXT="inaccurate, incomplete, biased" ID="ID_309020164" CREATED="1707351069417" MODIFIED="1707351076814"/>
</node>
<node TEXT="not original" ID="ID_1244620227" CREATED="1707351096580" MODIFIED="1707351101791"/>
<node TEXT="not comprehensive" FOLDED="true" ID="ID_1672225514" CREATED="1707351106792" MODIFIED="1707351110797">
<node TEXT="missing important information" ID="ID_866972657" CREATED="1707351110799" MODIFIED="1707351115631"/>
<node TEXT="contain human error" ID="ID_1370724541" CREATED="1707351116618" MODIFIED="1707351119614"/>
</node>
<node TEXT="not current" FOLDED="true" ID="ID_1948263492" CREATED="1707351122794" MODIFIED="1707351125978">
<node TEXT="out of date" ID="ID_894936664" CREATED="1707351125980" MODIFIED="1707351128833"/>
</node>
<node TEXT="not cited" ID="ID_1991520458" CREATED="1707351140583" MODIFIED="1707351143599"/>
</node>
</node>
<node TEXT="Data ethics and privacy" FOLDED="true" ID="ID_878825197" CREATED="1707351402586" MODIFIED="1707351407216">
<node ID="ID_1594176271" TREE_ID="ID_1798994963"/>
<node ID="ID_137037195" TREE_ID="ID_1736844826">
<node ID="ID_411732784" TREE_ID="ID_1452753566">
<node ID="ID_641457514" TREE_ID="ID_1713865785"/>
<node ID="ID_517996009" TREE_ID="ID_802245375"/>
<node ID="ID_1528803784" TREE_ID="ID_1931788622"/>
<node ID="ID_1111921533" TREE_ID="ID_1800381979"/>
<node ID="ID_154856172" TREE_ID="ID_419482793">
<node ID="ID_1576406534" TREE_ID="ID_1680497406"/>
<node ID="ID_710726190" TREE_ID="ID_639283588">
<node ID="ID_950297152" TREE_ID="ID_1619709240"/>
<node ID="ID_996374555" TREE_ID="ID_629003240"/>
<node ID="ID_1103088399" TREE_ID="ID_1665415490"/>
<node ID="ID_663641958" TREE_ID="ID_680492399"/>
<node ID="ID_1466791436" TREE_ID="ID_1138697458"/>
</node>
</node>
<node ID="ID_726453370" TREE_ID="ID_425117334">
<node ID="ID_381321560" TREE_ID="ID_1455481654">
<node ID="ID_1894288823" TREE_ID="ID_1058903015">
<node ID="ID_371387660" TREE_ID="ID_1392816653"/>
<node ID="ID_1406952045" TREE_ID="ID_432697076"/>
<node ID="ID_1362502334" TREE_ID="ID_683729779"/>
</node>
<node ID="ID_904807359" TREE_ID="ID_1055940120">
<node ID="ID_1951693818" TREE_ID="ID_49787354">
<node ID="ID_693105091" TREE_ID="ID_1698246656"/>
</node>
<node ID="ID_524242017" TREE_ID="ID_487512308"/>
</node>
<node ID="ID_277009953" TREE_ID="ID_1486176753">
<node ID="ID_67950915" TREE_ID="ID_825713552"/>
</node>
</node>
</node>
</node>
<node ID="ID_306020722" TREE_ID="ID_1371190613">
<node ID="ID_1404114610" TREE_ID="ID_249823704">
<node ID="ID_1880954932" TREE_ID="ID_1062278394"/>
<node ID="ID_267267802" TREE_ID="ID_570688057"/>
<node ID="ID_1855805172" TREE_ID="ID_1802340540"/>
</node>
</node>
</node>
<node TEXT="Data anonymization: The process of protecting people&apos;s private or sensitive data by eliminating identifying information" FOLDED="true" ID="ID_126302367" CREATED="1707259637677" MODIFIED="1707259637677">
<node TEXT="personally identifiable information (PII): information that can be used by itself or with other data to track a person &apos;s identity" ID="ID_1252893614" CREATED="1707407596345" MODIFIED="1707407631573"/>
<node TEXT="de-identification" FOLDED="true" ID="ID_1869574415" CREATED="1707407748575" MODIFIED="1707407755945">
<node TEXT="process used to wipe data clean of all personally identifying information" ID="ID_1315976205" CREATED="1707407755947" MODIFIED="1707407777998"/>
</node>
<node TEXT="involves _ PII" FOLDED="true" ID="ID_1300145875" CREATED="1707407642563" MODIFIED="1707407673575">
<node TEXT="blanking" ID="ID_1343513529" CREATED="1707407646159" MODIFIED="1707407649134"/>
<node TEXT="hashing" ID="ID_1697034411" CREATED="1707407649147" MODIFIED="1707407651349"/>
<node TEXT="masking" ID="ID_935520528" CREATED="1707407651362" MODIFIED="1707407655176"/>
</node>
<node TEXT="sensitive types of data" FOLDED="true" ID="ID_830245469" CREATED="1707407724751" MODIFIED="1707407732951">
<node TEXT="healthcare" ID="ID_1509586127" CREATED="1707407732953" MODIFIED="1707407736941"/>
<node TEXT="financial" ID="ID_1407794147" CREATED="1707407736943" MODIFIED="1707407739586"/>
</node>
<node TEXT="often anonymized" FOLDED="true" ID="ID_170844865" CREATED="1707407929544" MODIFIED="1707407941581">
<node TEXT="Telephone numbers" ID="ID_46823863" CREATED="1707407942983" MODIFIED="1707407942983"/>
<node TEXT="Names" ID="ID_1681931274" CREATED="1707407942983" MODIFIED="1707407942983"/>
<node TEXT="License plates and license numbers" ID="ID_1155098505" CREATED="1707407942984" MODIFIED="1707407942984"/>
<node TEXT="Social security numbers" ID="ID_1238876574" CREATED="1707407942984" MODIFIED="1707407942984"/>
<node TEXT="IP addresses" ID="ID_1152628540" CREATED="1707407942984" MODIFIED="1707407942984"/>
<node TEXT="Medical records" ID="ID_189555464" CREATED="1707407942984" MODIFIED="1707407942984"/>
<node TEXT="Email addresses" ID="ID_644064662" CREATED="1707407942986" MODIFIED="1707407942986"/>
<node TEXT="Photographs" ID="ID_696921716" CREATED="1707407942986" MODIFIED="1707407942986"/>
<node TEXT="Account numbers" ID="ID_980679976" CREATED="1707407942986" MODIFIED="1707407942986"/>
</node>
</node>
</node>
<node TEXT="Understand open data" ID="ID_1458604179" CREATED="1707408274379" MODIFIED="1707408280149"/>
</node>
<node TEXT="Database essentials M3" FOLDED="true" POSITION="top_or_left" ID="ID_644780975" CREATED="1707416644626" MODIFIED="1708126755838">
<node TEXT="Work with databases" FOLDED="true" ID="ID_1960160800" CREATED="1707416650550" MODIFIED="1707416692361">
<node TEXT="Relational database: A database that contains a series of tables that can be connected to form relationships" FOLDED="true" ID="ID_1946106506" CREATED="1707259637739" MODIFIED="1707259637739">
<node TEXT="keys" FOLDED="true" ID="ID_676106404" CREATED="1707503109230" MODIFIED="1707503112050">
<node TEXT="reference" FOLDED="true" ID="ID_1605163706" CREATED="1707503317056" MODIFIED="1707503318675">
<node ID="ID_1242518228" CREATED="1707503313715" MODIFIED="1707503313715" LINK="https://www.coursera.org/learn/data-preparation/supplement/uXqEX/maximize-databases-in-data-analytics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/supplement/uXqEX/maximize-databases-in-data-analytics">Maximize databases in data analytics | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1970273400" TREE_ID="ID_775266484">
<node ID="ID_1833630784" TREE_ID="ID_610105264"/>
</node>
<node ID="ID_999487931" TREE_ID="ID_64500578"/>
<node TEXT="Composite key: primary key constructed using multiple columns of a table" ID="ID_437094865" CREATED="1707503179490" MODIFIED="1707503227853"/>
</node>
<node TEXT="Normalization: process of organizing data in a relational database" FOLDED="true" ID="ID_1783651628" CREATED="1707503017451" MODIFIED="1707503030449">
<node TEXT="example" FOLDED="true" ID="ID_1982950717" CREATED="1707503040638" MODIFIED="1707503042492">
<node TEXT="creating tables and establishing relationships between those tables" ID="ID_350717699" CREATED="1707503030452" MODIFIED="1707503039665"/>
</node>
<node TEXT="applied to" FOLDED="true" ID="ID_1401735982" CREATED="1707503053677" MODIFIED="1707503060640">
<node TEXT="illuminate data redundancy" ID="ID_1116936467" CREATED="1707503060643" MODIFIED="1707503064242"/>
<node TEXT="increase data integrity" ID="ID_1035313120" CREATED="1707503064249" MODIFIED="1707503068042"/>
<node TEXT="reduce complexity in a database" ID="ID_1779755663" CREATED="1707503068050" MODIFIED="1707503072669"/>
</node>
</node>
</node>
<node ID="ID_117071543" TREE_ID="ID_1400367438">
<node ID="ID_1065250382" TREE_ID="ID_104817018">
<node ID="ID_733353376" TREE_ID="ID_1655297318"/>
<node ID="ID_684591013" TREE_ID="ID_1348210739"/>
<node ID="ID_1678995223" TREE_ID="ID_631431541"/>
</node>
<node ID="ID_675457716" TREE_ID="ID_1154229933">
<node ID="ID_1829669126" TREE_ID="ID_675868817"/>
<node ID="ID_1069535953" TREE_ID="ID_207126650"/>
<node ID="ID_1839283477" TREE_ID="ID_144895854"/>
</node>
<node ID="ID_1593081073" TREE_ID="ID_1350587479">
<node ID="ID_1793427531" TREE_ID="ID_1462849197"/>
<node ID="ID_1276119783" TREE_ID="ID_1337306009"/>
<node ID="ID_1858761550" TREE_ID="ID_309079556"/>
<node ID="ID_1596259319" TREE_ID="ID_1278475512"/>
<node ID="ID_1322373706" TREE_ID="ID_986423180"/>
<node ID="ID_225663614" TREE_ID="ID_1531336"/>
<node ID="ID_1100122908" TREE_ID="ID_1103129924"/>
</node>
<node ID="ID_401597911" TREE_ID="ID_1992639856">
<node ID="ID_1506164867" TREE_ID="ID_959683850">
<node ID="ID_989470932" TREE_ID="ID_538973023">
<node ID="ID_137812680" TREE_ID="ID_259530355"/>
<node ID="ID_1476748201" TREE_ID="ID_99852485"/>
<node ID="ID_1955895781" TREE_ID="ID_459754551"/>
<node ID="ID_37465726" TREE_ID="ID_1695734697"/>
</node>
</node>
<node ID="ID_1226627948" TREE_ID="ID_1075654590">
<node ID="ID_553975195" TREE_ID="ID_134243731">
<node ID="ID_1999232016" TREE_ID="ID_364974895"/>
<node ID="ID_1419783936" TREE_ID="ID_199517457"/>
<node ID="ID_1145983505" TREE_ID="ID_618461348"/>
<node ID="ID_1995629741" TREE_ID="ID_1201566032"/>
</node>
</node>
</node>
<node ID="ID_1008948155" TREE_ID="ID_975848248">
<node ID="ID_433354371" TREE_ID="ID_602333147"/>
<node ID="ID_1755381357" TREE_ID="ID_1451216921"/>
</node>
</node>
<node ID="ID_1184836936" TREE_ID="ID_1111028046"/>
</node>
<node TEXT="Manage data with metadata" ID="ID_1160184175" CREATED="1707508385034" MODIFIED="1707508391526"/>
<node TEXT="Access different data sources" FOLDED="true" ID="ID_1743813989" CREATED="1707508391535" MODIFIED="1707508395909">
<node TEXT="see one note" ID="ID_935956808" CREATED="1707508395910" MODIFIED="1707508399603"/>
</node>
<node TEXT="sort and filter data" FOLDED="true" ID="ID_983096259" CREATED="1707508401149" MODIFIED="1707508409179">
<node ID="ID_243916195" TREE_ID="ID_1473809352"/>
<node TEXT="Data cleaning" FOLDED="true" ID="ID_1060038138" CREATED="1707509223864" MODIFIED="1707509233376">
<node TEXT="corrects or removes incorrect, missing, and faulty data." ID="ID_602559264" CREATED="1707509233377" MODIFIED="1707509241945"/>
<node TEXT="Cleaning data is of critical importance because an analysis based on dirty data can lead to wrong conclusions and bad decisions. The cleaner your data, the better your results." ID="ID_378265164" CREATED="1707509241946" MODIFIED="1707509241947"/>
</node>
</node>
<node TEXT="compare and contrast spreadsheets and databases" ID="ID_500065029" CREATED="1707516047923" MODIFIED="1707516065122">
<node TEXT="reference" ID="ID_1027397699" CREATED="1707516076891" MODIFIED="1707516078925">
<node ID="ID_1647337850" CREATED="1707516081954" MODIFIED="1707516081954" LINK="https://spreadsheetplanet.com/database-vs-spreadsheet/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://spreadsheetplanet.com/database-vs-spreadsheet/">Database vs Spreadsheet - A Simple Comparison</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Large data sets in SQL" FOLDED="true" ID="ID_1237214962" CREATED="1707518214461" MODIFIED="1707518224940">
<node ID="ID_207160373" CREATED="1707518254033" MODIFIED="1707518254033" LINK="https://console.cloud.google.com/projectselector2/bigquery?pli=1&amp;supportedpurview=project"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://console.cloud.google.com/projectselector2/bigquery?pli=1&amp;supportedpurview=project">BigQuery Studio – BigQuery – Google Cloud console</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Organize and protect data M4" FOLDED="true" POSITION="top_or_left" ID="ID_725189495" CREATED="1707755704479" MODIFIED="1708126800891">
<node TEXT="Best practices in organizing data" ID="ID_777453336" CREATED="1707755708534" MODIFIED="1707755763930">
<node TEXT="Naming conventions" FOLDED="true" ID="ID_200119276" CREATED="1707755763932" MODIFIED="1707755767311">
<node TEXT="decide on file naming conventions as a team or company early in a project" ID="ID_58765882" CREATED="1707756314064" MODIFIED="1707756327699"/>
<node TEXT="align your projects file names with your teams or companies existing file naming conventions" ID="ID_929684894" CREATED="1707756333084" MODIFIED="1707756354913"/>
<node TEXT="ensure that file names are" FOLDED="true" ID="ID_614683187" CREATED="1707756376335" MODIFIED="1707756434507">
<node TEXT="meaningful" ID="ID_1596919016" CREATED="1707756378817" MODIFIED="1707756380866"/>
<node TEXT="consistent" ID="ID_1785478690" CREATED="1707756380881" MODIFIED="1707756382642"/>
<node TEXT="easy-to-read" ID="ID_1988304999" CREATED="1707756382658" MODIFIED="1707756385600"/>
</node>
<node TEXT="should include" FOLDED="true" ID="ID_1035452605" CREATED="1707756388587" MODIFIED="1707756391670">
<node TEXT="project name" ID="ID_1582350573" CREATED="1707756391673" MODIFIED="1707756395031"/>
<node TEXT="file creation date" ID="ID_24432886" CREATED="1707756395034" MODIFIED="1707756399472"/>
<node TEXT="revision version" ID="ID_271059946" CREATED="1707756399487" MODIFIED="1707756402268"/>
<node TEXT="consistent style in order" ID="ID_349813619" CREATED="1707756402280" MODIFIED="1707756406220"/>
</node>
<node TEXT="file naming conventions should act as quick reference to identify what is in the file" ID="ID_1831156292" CREATED="1707756488113" MODIFIED="1707756557245"/>
<node TEXT="" ID="ID_1663942820" CREATED="1707756504969" MODIFIED="1707756504969"/>
</node>
<node TEXT="Foldering" FOLDED="true" ID="ID_67563060" CREATED="1707755769270" MODIFIED="1707755777019">
<node TEXT="create folders and subfolders in a logical hierarchy to ensure related files are stored together and can be found easily later" ID="ID_1502678754" CREATED="1707756572608" MODIFIED="1707756599071"/>
<node TEXT="store completed files separately from in progress files" ID="ID_1372489736" CREATED="1707756651861" MODIFIED="1707756651861"/>
<node TEXT="archive older files in a separate folder" ID="ID_1537064494" CREATED="1707756610389" MODIFIED="1707756617705"/>
</node>
<node TEXT="Develop metadata practices" ID="ID_1905066448" CREATED="1707755821905" MODIFIED="1707755826882"/>
</node>
<node TEXT="Secure data" FOLDED="true" ID="ID_297456948" CREATED="1707762932140" MODIFIED="1707762936056">
<node ID="ID_1131256297" TREE_ID="ID_1383805875">
<node ID="ID_1154582437" TREE_ID="ID_1015814811"/>
<node ID="ID_59009089" TREE_ID="ID_878528236">
<node ID="ID_430694140" TREE_ID="ID_1003419657"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Step 3: Process" FOLDED="true" ID="ID_377601565" CREATED="1706900372181" MODIFIED="1706900372181">
<node TEXT="Roadmap" FOLDED="true" ID="ID_1357949773" CREATED="1712603525690" MODIFIED="1712603528467">
<node TEXT="Guiding questions" ID="ID_727074233" CREATED="1712603530105" MODIFIED="1712603530105">
<node TEXT="What tools are you choosing and why?" ID="ID_645569657" CREATED="1712603530105" MODIFIED="1712603530105"/>
<node TEXT="Have you ensured your data’s integrity?" ID="ID_1248799184" CREATED="1712603530109" MODIFIED="1712603530109"/>
<node TEXT="What steps have you taken to ensure that your data is clean?" ID="ID_1690447717" CREATED="1712603530110" MODIFIED="1712603530110"/>
<node TEXT="How can you verify that your data is clean and ready to analyze?" ID="ID_297715511" CREATED="1712603530112" MODIFIED="1712603530112"/>
<node TEXT="Have you documented your cleaning process so you can review and share those results?" ID="ID_968202093" CREATED="1712603530113" MODIFIED="1712603530113"/>
</node>
<node TEXT="Key tasks" FOLDED="true" ID="ID_913184494" CREATED="1712603530115" MODIFIED="1712603530115">
<node TEXT="Now that you know your data is credible and relevant to your problem, you’ll need to clean it so that your analysis will be error-free." ID="ID_599201562" CREATED="1712603530116" MODIFIED="1712603530116"/>
<node TEXT="Check the data for errors" ID="ID_1702819201" CREATED="1712603530117" MODIFIED="1712603530117"/>
<node TEXT="Transform the data into the right type" ID="ID_1607509750" CREATED="1712603530119" MODIFIED="1712603530119"/>
<node TEXT="Document the cleaning process" ID="ID_1735314263" CREATED="1712603530119" MODIFIED="1712603530119"/>
<node TEXT="Choose your tools" ID="ID_1522383558" CREATED="1712603530120" MODIFIED="1712603530120"/>
</node>
</node>
<node TEXT="Deliverable" FOLDED="true" ID="ID_1152829134" CREATED="1711649169620" MODIFIED="1711649173139">
<node TEXT="Data cleaning / manipulation log" ID="ID_1901296113" CREATED="1711649209140" MODIFIED="1711649235500">
<node TEXT="Change log" ID="ID_787548004" CREATED="1711649292610" MODIFIED="1711649296093">
<node TEXT="bicycle case study" ID="ID_484393520" CREATED="1711650232826" MODIFIED="1711650241097">
<node TEXT="import each csv to a spreadsheet" ID="ID_207380337" CREATED="1711650241099" MODIFIED="1711650260883"/>
<node TEXT="combine all spreadsheets into one file" ID="ID_219168626" CREATED="1711650261409" MODIFIED="1711650269700"/>
<node TEXT="add ride_length column" ID="ID_643791313" CREATED="1711650272282" MODIFIED="1711650288115"/>
</node>
</node>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_573011692" CREATED="1707783222749" MODIFIED="1707783224643">
<node FOLDED="true" ID="ID_1446439673" CREATED="1707783228930" MODIFIED="1711649161732" LINK="https://www.coursera.org/learn/process-data/home/module/1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/process-data/home/module/1">Process Data from Dirty to Clean (Course 4)</a>
  </body>
</html>
</richcontent>
<node TEXT="Glossary" FOLDED="true" ID="ID_1331114566" CREATED="1707783110641" MODIFIED="1707783118484">
<node TEXT="A/B testing: The process of testing two variations of the same web page to determine which page is more successful at attracting user traffic and generating revenue" ID="ID_1651551014" CREATED="1707783168576" MODIFIED="1707783168576"/>
<node TEXT="Accuracy: The degree to which data conforms to the actual entity being measured or described" ID="ID_491612029" CREATED="1707783168578" MODIFIED="1707783168578"/>
<node TEXT="CASE: A SQL statement that returns records that meet conditions by including an if/then statement in a query" ID="ID_119276582" CREATED="1707783168581" MODIFIED="1707783168581"/>
<node TEXT="CAST: A SQL function that converts data from one datatype to another" ID="ID_207389084" CREATED="1707783168581" MODIFIED="1707783168581"/>
<node TEXT="Changelog: A file containing a chronologically ordered list of modifications made to a project" FOLDED="true" ID="ID_538186939" CREATED="1707783168582" MODIFIED="1707783168582">
<node TEXT="best practices" ID="ID_1385603236" CREATED="1708123835252" MODIFIED="1708123837833">
<node TEXT="reference" ID="ID_1275890998" CREATED="1708123840530" MODIFIED="1708123842844">
<node ID="ID_1089098364" CREATED="1708123843901" MODIFIED="1708123843901" LINK="https://co-pilot.dev/changelog"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://co-pilot.dev/changelog">Changelog best practices</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="spreadsheets" FOLDED="true" ID="ID_1609426364" CREATED="1708122958794" MODIFIED="1708122962044">
<node TEXT="For each file: Version History" ID="ID_1807907279" CREATED="1708122962049" MODIFIED="1708123032819"/>
<node TEXT="For each cell: R-Click .. show edit history" ID="ID_1617082698" CREATED="1708123000182" MODIFIED="1708123025685"/>
</node>
<node TEXT="SQL" FOLDED="true" ID="ID_122485447" CREATED="1708122996015" MODIFIED="1708122998515">
<node TEXT="add comments" FOLDED="true" ID="ID_1906462808" CREATED="1708123061980" MODIFIED="1708123070243">
<node TEXT="used to update change log" ID="ID_177554811" CREATED="1708123072357" MODIFIED="1708123076570"/>
</node>
<node TEXT="BigQuery" FOLDED="true" ID="ID_1458035128" CREATED="1708123078722" MODIFIED="1708123082958">
<node TEXT="Query history" ID="ID_1684806486" CREATED="1708123092924" MODIFIED="1708123127633"/>
</node>
</node>
</node>
<node TEXT="Clean data: Data that is complete, correct, and relevant to the problem being solved" ID="ID_1067536447" CREATED="1707783168582" MODIFIED="1707783168582"/>
<node TEXT="COALESCE: A SQL function that returns non-null values in a list" ID="ID_738410378" CREATED="1707783168582" MODIFIED="1707783168582"/>
<node TEXT="Compatibility: How well two or more datasets are able to work together" ID="ID_517815657" CREATED="1707783168583" MODIFIED="1707783168583"/>
<node TEXT="Completeness: The degree to which data contains all desired components or measures" ID="ID_1998324207" CREATED="1707783168585" MODIFIED="1707783168585"/>
<node TEXT="CONCAT: A SQL function that adds strings together to create new text strings that can be used as unique keys" ID="ID_1461171174" CREATED="1707783168585" MODIFIED="1707783168585"/>
<node TEXT="CONCATENATE: A spreadsheet function that joins together two or more text strings" ID="ID_1638572637" CREATED="1707783168586" MODIFIED="1707783168586"/>
<node TEXT="Conditional formatting: A spreadsheet tool that changes how cells appear when values meet specific conditions" ID="ID_1330249773" CREATED="1707783168586" MODIFIED="1707783168586"/>
<node TEXT="Confidence interval:  A range of values that conveys how likely a statistical estimate reflects the population" ID="ID_1799508183" CREATED="1707783168586" MODIFIED="1707783168586"/>
<node TEXT="Confidence level: The probability that a sample size accurately reflects the greater population" FOLDED="true" ID="ID_443942674" CREATED="1707783168587" MODIFIED="1707783168587">
<node TEXT="typically 90% - 95%" ID="ID_563164319" CREATED="1707853198873" MODIFIED="1707853214073"/>
</node>
<node TEXT="Consistency: The degree to which data is repeatable from different points of entry or collection" FOLDED="true" ID="ID_349453258" CREATED="1707783168588" MODIFIED="1707783168588">
<node TEXT="consistency: the degree to which a set of measures is equivalent across systems" ID="ID_256537799" CREATED="1707855722843" MODIFIED="1707855765127"/>
</node>
<node TEXT="COUNTA: A spreadsheet function that counts the total number of values within a specified range" ID="ID_1989771187" CREATED="1707783168589" MODIFIED="1707783168589"/>
<node TEXT="COUNTIF: A spreadsheet function that returns the number of cells in a range that match a specified value" ID="ID_1894108710" CREATED="1707783168589" MODIFIED="1707783168589"/>
<node TEXT="Cross-field validation: A process that ensures certain conditions for multiple data fields are satisfied" ID="ID_668973783" CREATED="1707783168590" MODIFIED="1707783168590"/>
<node TEXT="Data constraints: The criteria that determine whether a piece of a data is clean and valid" FOLDED="true" ID="ID_405610905" CREATED="1707783168592" MODIFIED="1707783168592">
<node ID="ID_1815392054" CREATED="1711411084132" MODIFIED="1711411084132"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/4%20Process%20Data%20From%20Dirty%20To%20Clean%20(4)/M1%20Data%20integrity.one#More%20about%20data%20integrity%20and%20compliance&amp;section-id={6C876674-9CB5-4534-A5BA-4C154234F2DC}&amp;page-id={32BFA016-876D-448C-8942-FD6C29BF0CE4}&amp;object-id={7C4928C5-1712-42BB-B172-3375D1C185FD}&amp;53">Reference: Data constraints and examples</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%284%20Process%20Data%20From%20Dirty%20To%20Clean%20%284%5C%29%2FM1%20Data%20integrity.one%7C6C876674-9CB5-4534-A5BA-4C154234F2DC%2FMore%20about%20data%20integrity%20and%20compliance%7C32BFA016-876D-448C-8942-FD6C29BF0CE4%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
<node TEXT="Uniformity: The degree to which the data is specified using the same unit of measure." ID="ID_1478508080" CREATED="1711410818605" MODIFIED="1711410829932"/>
</node>
<node TEXT="Data engineer: A professional who transforms data into a useful format for analysis and gives it a reliable infrastructure" ID="ID_1434781837" CREATED="1707783168592" MODIFIED="1707783168592"/>
<node TEXT="Data ethics: Well-founded standards of right and wrong that dictate how data is collected, shared, and used" ID="ID_1323636688" CREATED="1707783168592" MODIFIED="1707783168592"/>
<node TEXT="Data governance: A process for ensuring the formal management of a company’s data assets" ID="ID_243549913" CREATED="1707783168593" MODIFIED="1707783168593"/>
<node TEXT="Data integrity: The accuracy, completeness, consistency, and trustworthiness of data throughout its life cycle" FOLDED="true" ID="ID_42715043" CREATED="1707783168594" MODIFIED="1707783168594">
<node TEXT="components" FOLDED="true" ID="ID_858180194" CREATED="1707855609234" MODIFIED="1711411387767">
<font BOLD="true"/>
<node ID="ID_1376238390" TREE_ID="ID_491612029"/>
<node TEXT="completeness: the degree to which all required measures are known" ID="ID_1677043912" CREATED="1707855652446" MODIFIED="1707855674392"/>
<node TEXT="validity: measures conform to define business rules or constraints" FOLDED="true" ID="ID_1458236733" CREATED="1707855683871" MODIFIED="1707855720627">
<node ID="ID_1455664207" TREE_ID="ID_405610905">
<node ID="ID_161898286" TREE_ID="ID_1815392054"/>
<node ID="ID_667115253" TREE_ID="ID_1478508080"/>
</node>
</node>
<node ID="ID_912759815" TREE_ID="ID_349453258">
<node ID="ID_1085906387" TREE_ID="ID_256537799"/>
</node>
</node>
<node TEXT="when data integrity is low" FOLDED="true" ID="ID_260572795" CREATED="1707785072438" MODIFIED="1707785085337">
<node TEXT="can lead to incorrect decisions" ID="ID_737176377" CREATED="1707785085340" MODIFIED="1707785123292"/>
<node TEXT="one missing piece might make all of your data useless" ID="ID_1898769033" CREATED="1707785126785" MODIFIED="1707785136246"/>
</node>
<node TEXT="threats to integrity" FOLDED="true" ID="ID_1597237988" CREATED="1707785275767" MODIFIED="1707785289615">
<node TEXT="reference" FOLDED="true" ID="ID_5184847" CREATED="1711411370625" MODIFIED="1711411377128">
<node ID="ID_1533481180" CREATED="1707785656160" MODIFIED="1707785656160"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/Process%20Data%20From%20Dirty%20To%20Clean%20(4)/M1%20Data%20integrity.one#More%20about%20data%20integrity%20and%20compliance&amp;section-id={6C876674-9CB5-4534-A5BA-4C154234F2DC}&amp;page-id={32BFA016-876D-448C-8942-FD6C29BF0CE4}&amp;end">More about data integrity and compliance</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%28Process%20Data%20From%20Dirty%20To%20Clean%20%284%5C%29%2FM1%20Data%20integrity.one%7C6C876674-9CB5-4534-A5BA-4C154234F2DC%2FMore%20about%20data%20integrity%20and%20compliance%7C32BFA016-876D-448C-8942-FD6C29BF0CE4%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Data replication: The process of storing data in multiple locations" FOLDED="true" ID="ID_1292323261" CREATED="1707783168597" MODIFIED="1707783168597">
<node TEXT="chance the data might be out of sync" FOLDED="true" ID="ID_1175731104" CREATED="1707785165401" MODIFIED="1707785172647">
<node TEXT="lacks integrity because different people might not be using the same data, which can cause inconsistencies" ID="ID_1156772091" CREATED="1707785188022" MODIFIED="1707785218200"/>
</node>
</node>
<node TEXT="Data transfer: The process of copying data from a storage device to computer memory or from one computer to another" FOLDED="true" ID="ID_878552647" CREATED="1707783168598" MODIFIED="1707783168598">
<node TEXT="if transfer is interrupted, you might end up with an incomplete data set" ID="ID_76752709" CREATED="1707785248860" MODIFIED="1707785259311"/>
</node>
<node TEXT="Data manipulation: The process of changing data to make it more organized and easier to read" FOLDED="true" ID="ID_992780680" CREATED="1707783168595" MODIFIED="1707783168595">
<node TEXT="errors during the process can compromise" ID="ID_644135065" CREATED="1707785316040" MODIFIED="1707785330271"/>
</node>
<node TEXT="other factors" FOLDED="true" ID="ID_8869777" CREATED="1707785333811" MODIFIED="1707785348681">
<node TEXT="human error" ID="ID_850106030" CREATED="1707785348683" MODIFIED="1707785350985"/>
<node TEXT="viruses" ID="ID_1824282956" CREATED="1707785351000" MODIFIED="1707785353182"/>
<node TEXT="malware" ID="ID_516364670" CREATED="1707785353195" MODIFIED="1707785355788"/>
<node TEXT="hacking" ID="ID_404258111" CREATED="1707785355802" MODIFIED="1707785357809"/>
<node TEXT="system failures" ID="ID_1774978610" CREATED="1707785357827" MODIFIED="1707785362057"/>
</node>
</node>
</node>
<node TEXT="Data manipulation: The process of changing data to make it more organized and easier to read" ID="ID_53508363" CREATED="1707783168595" MODIFIED="1707783168595"/>
<node TEXT="Data mapping: The process of matching fields from one data source to another" ID="ID_31315437" CREATED="1707783168596" MODIFIED="1707783168596"/>
<node TEXT="Data merging: The process of combining two or more datasets into a single dataset" ID="ID_1624005265" CREATED="1707783168596" MODIFIED="1707783168596"/>
<node TEXT="Data range: Numerical values that fall between predefined maximum and minimum values" ID="ID_763316349" CREATED="1707783168597" MODIFIED="1707783168597"/>
<node TEXT="Data replication: The process of storing data in multiple locations" FOLDED="true" ID="ID_490433198" CREATED="1707783168597" MODIFIED="1707783168597">
<node TEXT="chance the data might be out of sync" FOLDED="true" ID="ID_594750381" CREATED="1707785165401" MODIFIED="1707785172647">
<node TEXT="lacks integrity because different people might not be using the same data, which can cause inconsistencies" ID="ID_17341279" CREATED="1707785188022" MODIFIED="1707785218200"/>
</node>
</node>
<node TEXT="Data transfer: The process of copying data from a storage device to computer memory or from one computer to another" FOLDED="true" ID="ID_1780473549" CREATED="1707783168598" MODIFIED="1707783168598">
<node TEXT="if transfer is interrupted, you might end up with an incomplete data set" ID="ID_577293133" CREATED="1707785248860" MODIFIED="1707785259311"/>
</node>
<node TEXT="Data validation: A tool for checking the accuracy and quality of data" ID="ID_486756537" CREATED="1707783168598" MODIFIED="1707783168598"/>
<node TEXT="Data warehousing specialist: A professional who develops processes and procedures to effectively store and organize data" ID="ID_1904177673" CREATED="1707783168600" MODIFIED="1707783168600"/>
<node TEXT="DATEDIF: A spreadsheet function that calculates the number of days, months, or years between two dates" ID="ID_441634888" CREATED="1707783168600" MODIFIED="1707783168600"/>
<node TEXT="Delimiter: A character that indicates the beginning or end of a data item" ID="ID_1899965941" CREATED="1707783168601" MODIFIED="1707783168601"/>
<node TEXT="Dirty data: Data that is incomplete, incorrect, or irrelevant to the problem to be solved" FOLDED="true" ID="ID_402811030" CREATED="1707783168602" MODIFIED="1707783168602">
<node TEXT="Types" FOLDED="true" ID="ID_187417961" CREATED="1707855085713" MODIFIED="1707855089511">
<node TEXT="reference" FOLDED="true" ID="ID_1808891131" CREATED="1707855190333" MODIFIED="1707855193323">
<node ID="ID_263530768" CREATED="1707855203914" MODIFIED="1707855203914"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/Process%20Data%20From%20Dirty%20To%20Clean%20(4)/M2%20Clean%20data%20for%20more%20accurate%20insights.one#What%20is%20dirty%20data&amp;section-id={47374673-D1D8-4296-973F-D91577678545}&amp;page-id={393654D7-80A5-4B7D-B389-88D3ADED90DC}&amp;end">What is dirty data?</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%28Process%20Data%20From%20Dirty%20To%20Clean%20%284%5C%29%2FM2%20Clean%20data%20for%20more%20accurate%20insights.one%7C47374673-D1D8-4296-973F-D91577678545%2FWhat%20is%20dirty%20data%3F%7C393654D7-80A5-4B7D-B389-88D3ADED90DC%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Duplicate data: Any record that inadvertently shares data with another record" FOLDED="true" ID="ID_219427301" CREATED="1707783168603" MODIFIED="1707783168603">
<node TEXT="• Duplicates: Did you remove duplicates in spreadsheets using the Remove Duplicates function or DISTINCT in SQL?" ID="ID_1734543185" CREATED="1708116327167" MODIFIED="1708116327167"/>
</node>
<node TEXT="Outdated data: Any data that has been superseded by newer and more accurate information" ID="ID_1993090584" CREATED="1707783168618" MODIFIED="1711489138204">
<font BOLD="false"/>
</node>
<node TEXT="Incomplete data: Data that is missing important fields" FOLDED="true" ID="ID_1602371485" CREATED="1707783168609" MODIFIED="1707783168609">
<node TEXT="Handle missing data" FOLDED="true" ID="ID_177644687" CREATED="1708108100671" MODIFIED="1708108100671">
<node TEXT="can you find the missing data?" ID="ID_286663522" CREATED="1711412558346" MODIFIED="1711412576346"/>
</node>
<node TEXT="• Truncated data: Did you check for truncated or missing data that needs correction?" ID="ID_1738474985" CREATED="1708116327172" MODIFIED="1708116327172"/>
<node TEXT="Possible Solution" FOLDED="true" ID="ID_646244203" CREATED="1711411989014" MODIFIED="1711411996051">
<node TEXT="combinine two or more data sets to make information more complete" ID="ID_915629476" CREATED="1706739041407" MODIFIED="1711145062424"/>
</node>
<node TEXT="Remove records with needed missing data (blank cells or NULL)" FOLDED="true" ID="ID_751881105" CREATED="1711145129914" MODIFIED="1711412053613">
<node TEXT="• Null data: Did you search for NULLs using conditional formatting and filters?" ID="ID_146854108" CREATED="1708116327162" MODIFIED="1708116327162"/>
</node>
</node>
<node TEXT="Inconsistent data: Data that uses different formats to represent the same thing" FOLDED="true" ID="ID_1503929441" CREATED="1707783168610" MODIFIED="1707783168610">
<node TEXT="• Mismatched data types: Did you check that numeric, date, and string data are typecast correctly?" FOLDED="true" ID="ID_587353198" CREATED="1708116327168" MODIFIED="1708116327168">
<node TEXT="Do type conversion" ID="ID_1713263948" CREATED="1708108100671" MODIFIED="1708108100671"/>
</node>
<node TEXT="• Messy (inconsistent) strings: Did you make sure that all of your strings are consistent and meaningful?" ID="ID_1880428980" CREATED="1708116327169" MODIFIED="1708116327169"/>
<node TEXT="• Messy (inconsistent) date formats: Did you format the dates consistently throughout your dataset?" ID="ID_228934765" CREATED="1708116327170" MODIFIED="1708116327170"/>
</node>
<node TEXT="Incorrect/inaccurate data: Data that is complete but inaccurate" FOLDED="true" ID="ID_1893014631" CREATED="1707783168610" MODIFIED="1707783168610">
<node TEXT="Fix structural errors" FOLDED="true" ID="ID_42018302" CREATED="1708108100670" MODIFIED="1708108100670">
<node TEXT="• Sources of errors: Did you use the right tools and functions to find the source of the errors in your dataset?" ID="ID_163686019" CREATED="1708116327162" MODIFIED="1708116327162"/>
</node>
<node TEXT="• Misspelled words: Did you locate all misspellings?" ID="ID_647526496" CREATED="1708116327164" MODIFIED="1708116327164"/>
<node TEXT="• Mistyped numbers: Did you double-check that your numeric data has been entered correctly?" ID="ID_800763280" CREATED="1708116327165" MODIFIED="1708116327165"/>
<node TEXT="• Extra spaces and characters: Did you remove any extra spaces or characters using the TRIM function?" ID="ID_296654317" CREATED="1708116327167" MODIFIED="1708116327167"/>
</node>
</node>
</node>
<node TEXT="DISTINCT: A keyword that is added to a SQL SELECT statement to retrieve only non-duplicate entries" ID="ID_1220588811" CREATED="1707783168602" MODIFIED="1707783168602"/>
<node ID="ID_455990851" TREE_ID="ID_219427301">
<node ID="ID_228661032" TREE_ID="ID_1734543185"/>
</node>
<node TEXT="Estimated response rate: The average number of people who typically complete a survey" ID="ID_1255998735" CREATED="1707783168604" MODIFIED="1707783168604"/>
<node TEXT="Field length: A tool for determining how many characters can be keyed into a spreadsheet field" ID="ID_807270518" CREATED="1707783168605" MODIFIED="1707783168605"/>
<node TEXT="Find and replace: A tool that finds a specified search term and replaces it with something else" ID="ID_741326193" CREATED="1707783168606" MODIFIED="1707783168606"/>
<node TEXT="Float: A number that contains a decimal" ID="ID_1981242580" CREATED="1707783168607" MODIFIED="1707783168607"/>
<node TEXT="Hypothesis testing: A process to determine if a survey or experiment has meaningful results" ID="ID_1952949380" CREATED="1707783168608" MODIFIED="1707783168608"/>
<node ID="ID_626915661" TREE_ID="ID_1602371485">
<node ID="ID_1487393142" TREE_ID="ID_177644687">
<node ID="ID_1338130343" TREE_ID="ID_286663522"/>
</node>
<node ID="ID_383465517" TREE_ID="ID_1738474985"/>
<node ID="ID_1066984253" TREE_ID="ID_646244203">
<node ID="ID_989554379" TREE_ID="ID_915629476"/>
</node>
<node ID="ID_1334927164" TREE_ID="ID_751881105">
<node ID="ID_260197453" TREE_ID="ID_146854108"/>
</node>
</node>
<node ID="ID_586797709" TREE_ID="ID_1503929441">
<node ID="ID_1714228426" TREE_ID="ID_587353198">
<node ID="ID_1136310721" TREE_ID="ID_1713263948"/>
</node>
<node ID="ID_826869395" TREE_ID="ID_1880428980"/>
<node ID="ID_1931581014" TREE_ID="ID_228934765"/>
</node>
<node ID="ID_1139164804" TREE_ID="ID_1893014631">
<node ID="ID_1054113261" TREE_ID="ID_42018302">
<node ID="ID_697378507" TREE_ID="ID_163686019"/>
</node>
<node ID="ID_28531596" TREE_ID="ID_647526496"/>
<node ID="ID_539207852" TREE_ID="ID_800763280"/>
<node ID="ID_767769580" TREE_ID="ID_296654317"/>
</node>
<node TEXT="LEFT: A function that returns a set number of characters from the left side of a text string" ID="ID_1062599561" CREATED="1707783168612" MODIFIED="1707783168612"/>
<node TEXT="LEN: A function that returns the length of a text string by counting the number of characters it contains" ID="ID_368658092" CREATED="1707783168612" MODIFIED="1707783168612"/>
<node TEXT="Length: The number of characters in a text string" ID="ID_1004212890" CREATED="1707783168614" MODIFIED="1707783168614"/>
<node TEXT="Mandatory: A data value that cannot be left blank or empty" ID="ID_85550358" CREATED="1707783168615" MODIFIED="1707783168615"/>
<node TEXT="Margin of error: The maximum amount that the sample results are expected to differ from those of the actual population" FOLDED="true" ID="ID_508817228" CREATED="1707783168615" MODIFIED="1707783168615">
<node TEXT="calculating" FOLDED="true" ID="ID_1477383797" CREATED="1707853229834" MODIFIED="1707853232832">
<node TEXT="confidence level" ID="ID_358858634" CREATED="1707853232834" MODIFIED="1707853251214"/>
<node TEXT="population size" ID="ID_1464759949" CREATED="1707853251231" MODIFIED="1707853257385"/>
<node TEXT="sample size" ID="ID_577669868" CREATED="1707853257401" MODIFIED="1707853266382"/>
</node>
</node>
<node TEXT="Merger: An agreement that unites two organizations into a single new one" ID="ID_174267921" CREATED="1707783168616" MODIFIED="1707783168616"/>
<node TEXT="MID: A function that returns a segment from the middle of a text string" ID="ID_260158708" CREATED="1707783168616" MODIFIED="1707783168616"/>
<node TEXT="Null: An indication that a value does not exist in a dataset" ID="ID_1029835752" CREATED="1707783168617" MODIFIED="1707783168617"/>
<node ID="ID_647410030" TREE_ID="ID_1993090584"/>
<node TEXT="Random sampling: A way of selecting a sample from a population so that every possible type of the sample has an equal chance of being chosen" ID="ID_1410437015" CREATED="1707783168620" MODIFIED="1707783168620"/>
<node TEXT="Regular expression (RegEx): A rule that says the values in a table must match a prescribed pattern" ID="ID_237460433" CREATED="1707783168620" MODIFIED="1707783168620"/>
<node TEXT="Remove duplicates: A spreadsheet tool that automatically searches for and eliminates duplicate entries from a spreadsheet" ID="ID_1739043662" CREATED="1707783168621" MODIFIED="1707783168621"/>
<node TEXT="RIGHT: A function that returns a set number of characters from the right side of a text string" ID="ID_1622424734" CREATED="1707783168622" MODIFIED="1707783168622"/>
<node TEXT="Soft skills: Nontechnical traits and behaviors that relate to how people work" ID="ID_1493464996" CREATED="1707783168623" MODIFIED="1707783168623"/>
<node TEXT="Split: A spreadsheet function that divides text around a specified character and puts each fragment into a new, separate cell" ID="ID_392894587" CREATED="1707783168623" MODIFIED="1707783168623"/>
<node TEXT="Statistical power: The probability that a test of significance will recognize an effect that is present" ID="ID_434764449" CREATED="1707783168623" MODIFIED="1707783168623"/>
<node TEXT="Statistical significance: The probability that sample results are not due to random chance" ID="ID_209986937" CREATED="1707783168625" MODIFIED="1707783168625"/>
<node TEXT="SUBSTR: A SQL function that extracts a substring from a string variable" ID="ID_516953900" CREATED="1707783168626" MODIFIED="1707783168626"/>
<node TEXT="Substring: A subset of a text string" ID="ID_355727972" CREATED="1707783168626" MODIFIED="1707783168626"/>
<node TEXT="Syntax: The predetermined structure of a language that includes all required words, symbols, and punctuation, as well as their proper placement" ID="ID_73289032" CREATED="1707783168626" MODIFIED="1707783168626"/>
<node TEXT="Text string: A group of characters within a cell, most often composed of letters" ID="ID_1886191893" CREATED="1707783168627" MODIFIED="1707783168627"/>
<node TEXT="Transferable skills: Skills and qualities that can transfer from one job or industry to another" ID="ID_1776174605" CREATED="1707783168628" MODIFIED="1707783168628"/>
<node TEXT="TRIM: A function that removes leading, trailing, and repeated spaces in data" ID="ID_1177756757" CREATED="1707783168628" MODIFIED="1707783168628"/>
<node TEXT="Typecasting: Converting data from one type to another" ID="ID_1126662319" CREATED="1707783168629" MODIFIED="1707783168629"/>
<node TEXT="Unique: A value that can’t have a duplicate" ID="ID_1227174872" CREATED="1707783168629" MODIFIED="1707783168629"/>
<node TEXT="Validity: The degree to which data conforms to constraints when it is input, collected, or created" ID="ID_42631577" CREATED="1707783168631" MODIFIED="1707783168631"/>
<node TEXT="Verification: A process to confirm that a data-cleaning effort was well executed and the resulting data is accurate and reliable" ID="ID_1434157483" CREATED="1707783168632" MODIFIED="1707783168632"/>
<node TEXT="VLOOKUP: A spreadsheet function that vertically searches for a certain value in a column to return a corresponding piece of information" ID="ID_1424748288" CREATED="1707783168632" MODIFIED="1707783168632"/>
</node>
</node>
<node ID="ID_1108480513" CREATED="1707783107792" MODIFIED="1707783107792"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/Process%20Data%20From%20Dirty%20To%20Clean%20(4)/">Process Data From Dirty To Clean (4)</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%28Process%20Data%20From%20Dirty%20To%20Clean%20%284%5C%29%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="understand the data" FOLDED="true" ID="ID_507279294" CREATED="1707851955444" MODIFIED="1707851959985">
<node TEXT="When opening a new dataset for the first time, the initial step is to understand its structure and contents. This involves examining the columns, data types, and any metadata available. I would check for missing values, duplicates, and outliers to gauge the data&apos;s cleanliness and quality. Understanding the context of the dataset is crucial, so I would review any documentation or metadata provided to grasp its purpose and origin." ID="ID_1204794639" CREATED="1707784779121" MODIFIED="1707784779121"/>
<node TEXT="Once I have a grasp of the dataset, I would consider various analyses and visualizations that could provide insights into the data. This might involve summarizing key statistics, identifying trends, or visualizing relationships between variables. Applying techniques learned in data analysis courses, such as data cleaning, normalization, and exploratory data analysis, can help uncover patterns and anomalies within the dataset. Additionally, considering ethical considerations and privacy concerns is essential, ensuring that any analysis or manipulation respects the confidentiality and integrity of the data and its subjects." ID="ID_692182623" CREATED="1707784779121" MODIFIED="1707784779121"/>
</node>
<node TEXT="Precleaning / preprocessing" FOLDED="true" ID="ID_566141524" CREATED="1707851881279" MODIFIED="1707852150733">
<node TEXT="reference" FOLDED="true" ID="ID_395727532" CREATED="1707851997115" MODIFIED="1707851999152">
<node ID="ID_979617857" CREATED="1707784652715" MODIFIED="1707784652715" LINK="https://www.blog.trainindata.com/mastering-data-preprocessing-techniques/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.blog.trainindata.com/mastering-data-preprocessing-techniques/">Mastering data preprocessing: Techniques and best practices - Train in Data Blog</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1380769940" CREATED="1707852000608" MODIFIED="1707852000608"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/Process%20Data%20From%20Dirty%20To%20Clean%20(4)/M1%20Data%20integrity.one#Self-Reflection%20Pre-cleaning%20activities&amp;section-id={6C876674-9CB5-4534-A5BA-4C154234F2DC}&amp;page-id={71535341-9FEB-46AB-8CDD-61CB3C8C387A}&amp;end">Self-Reflection: Pre-cleaning activities</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%28Process%20Data%20From%20Dirty%20To%20Clean%20%284%5C%29%2FM1%20Data%20integrity.one%7C6C876674-9CB5-4534-A5BA-4C154234F2DC%2FSelf-Reflection%3A%20Pre-cleaning%20activities%7C71535341-9FEB-46AB-8CDD-61CB3C8C387A%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Data is aligned to business objectives" FOLDED="true" ID="ID_1791773403" CREATED="1711410348472" MODIFIED="1711410365138">
<icon BUILTIN="unchecked"/>
<node TEXT="data is relevant and can help you solve a business problem or determine a course of action to achieve a given business objective." ID="ID_1459225171" CREATED="1711410408253" MODIFIED="1711410408253"/>
</node>
<node TEXT="Review data integrity" FOLDED="true" ID="ID_1724045798" CREATED="1707851892612" MODIFIED="1707851900296">
<node TEXT="Data meets integrity and analysis objectives" FOLDED="true" ID="ID_931742972" CREATED="1707785017553" MODIFIED="1711411312580">
<node TEXT="Checklist" FOLDED="true" ID="ID_1638647605" CREATED="1707785710296" MODIFIED="1707785728267">
<node TEXT="Ensure Data integrity/quality" FOLDED="true" ID="ID_886047348" CREATED="1707785431736" MODIFIED="1711411274404">
<icon BUILTIN="unchecked"/>
<font BOLD="true"/>
<node ID="ID_1396867072" TREE_ID="ID_42715043">
<node ID="ID_1062621259" TREE_ID="ID_858180194">
<node ID="ID_281791121" CONTENT_ID="ID_491612029"/>
<node ID="ID_388274562" TREE_ID="ID_1677043912"/>
<node ID="ID_458836224" TREE_ID="ID_1458236733">
<node ID="ID_343174758" CONTENT_ID="ID_405610905">
<node ID="ID_931727212" CONTENT_ID="ID_1815392054"/>
<node ID="ID_846092798" CONTENT_ID="ID_1478508080"/>
</node>
</node>
<node ID="ID_1567991055" CONTENT_ID="ID_349453258">
<node ID="ID_1536837465" CONTENT_ID="ID_256537799"/>
</node>
</node>
<node ID="ID_906518877" TREE_ID="ID_260572795">
<node ID="ID_43741480" TREE_ID="ID_737176377"/>
<node ID="ID_296819781" TREE_ID="ID_1898769033"/>
</node>
<node ID="ID_886242625" TREE_ID="ID_1597237988">
<node ID="ID_512784879" TREE_ID="ID_5184847">
<node ID="ID_1212222427" TREE_ID="ID_1533481180"/>
</node>
<node ID="ID_669447858" TREE_ID="ID_1292323261">
<node ID="ID_239378894" TREE_ID="ID_1175731104">
<node ID="ID_602973095" TREE_ID="ID_1156772091"/>
</node>
</node>
<node ID="ID_1509969387" TREE_ID="ID_878552647">
<node ID="ID_217522813" TREE_ID="ID_76752709"/>
</node>
<node ID="ID_1491782148" TREE_ID="ID_992780680">
<node ID="ID_1862074202" TREE_ID="ID_644135065"/>
</node>
<node ID="ID_1963500594" TREE_ID="ID_8869777">
<node ID="ID_1183598568" TREE_ID="ID_850106030"/>
<node ID="ID_834199093" TREE_ID="ID_1824282956"/>
<node ID="ID_626147750" TREE_ID="ID_516364670"/>
<node ID="ID_1434986998" TREE_ID="ID_404258111"/>
<node ID="ID_1187860804" TREE_ID="ID_1774978610"/>
</node>
</node>
</node>
<node TEXT="data reliability" FOLDED="true" ID="ID_352814169" CREATED="1707853017573" MODIFIED="1707853045902">
<node ID="ID_498290540" TREE_ID="ID_1952949380"/>
<node TEXT="sample size" ID="ID_474504894" CREATED="1707853028494" MODIFIED="1707853032304"/>
<node ID="ID_1142847273" TREE_ID="ID_443942674">
<node ID="ID_305436037" TREE_ID="ID_563164319"/>
</node>
<node ID="ID_571511096" TREE_ID="ID_508817228">
<node ID="ID_904493651" TREE_ID="ID_1477383797">
<node ID="ID_80741969" TREE_ID="ID_358858634"/>
<node ID="ID_569533695" TREE_ID="ID_1464759949"/>
<node ID="ID_1923419335" TREE_ID="ID_577669868"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Address insufficient data" FOLDED="true" ID="ID_1575165531" CREATED="1707851902465" MODIFIED="1707851923428">
<node TEXT="Insufficient data" FOLDED="true" ID="ID_123988007" CREATED="1707842164292" MODIFIED="1707842167470">
<node TEXT="no data" FOLDED="true" ID="ID_529942024" CREATED="1707842992605" MODIFIED="1707842998616">
<node TEXT="possible solutions" FOLDED="true" ID="ID_1729605169" CREATED="1707843004412" MODIFIED="1707843013308">
<node TEXT="if time permits" FOLDED="true" ID="ID_1236817882" CREATED="1707843045869" MODIFIED="1707843049365">
<node TEXT="gather data on a small scale, perform preliminary analysis, request additional time complete the analysis after you&apos;ve collected more data" ID="ID_1729421627" CREATED="1707843013309" MODIFIED="1707843043595"/>
</node>
<node TEXT="if there isn&apos;t time" FOLDED="true" ID="ID_279316364" CREATED="1707843051562" MODIFIED="1707843057963">
<node TEXT="perform the analysis using proxy data from other data set" FOLDED="true" ID="ID_1736173145" CREATED="1707843057964" MODIFIED="1707843067131">
<node TEXT="most common workaround" ID="ID_804443095" CREATED="1707843067132" MODIFIED="1707843070396"/>
</node>
</node>
</node>
</node>
<node TEXT="too little data" FOLDED="true" ID="ID_1845055801" CREATED="1707843076364" MODIFIED="1707843081303">
<node TEXT="possible solutions" FOLDED="true" ID="ID_388124274" CREATED="1707843081305" MODIFIED="1707843084795">
<node TEXT="do the analysis using proxy data along with actual data" ID="ID_400756812" CREATED="1707843084796" MODIFIED="1707843092089"/>
<node TEXT="adjuster analysis to align with the data you already have" ID="ID_1376538244" CREATED="1707843093128" MODIFIED="1707843098938"/>
</node>
</node>
<node TEXT="wrong data, including data with errors" FOLDED="true" ID="ID_17742182" CREATED="1707843101866" MODIFIED="1707843110554">
<node TEXT="possible solutions" FOLDED="true" ID="ID_21752131" CREATED="1707843110556" MODIFIED="1707843113962">
<node TEXT="if requirements were misunderstood" FOLDED="true" ID="ID_742991225" CREATED="1707843113964" MODIFIED="1707843125076">
<node TEXT="communicate the requirements again" ID="ID_148967941" CREATED="1707843125078" MODIFIED="1707843130322"/>
</node>
<node TEXT="identify errors in the data and correct them at the source" ID="ID_1620794207" CREATED="1707843131654" MODIFIED="1707843248903"/>
</node>
</node>
<node TEXT="data from only one source" ID="ID_1975071897" CREATED="1707842179126" MODIFIED="1707842182702"/>
<node TEXT="data that keeps updating" FOLDED="true" ID="ID_1583791755" CREATED="1707842184052" MODIFIED="1707842188122">
<node TEXT="still incoming and may not be complete" ID="ID_1298202904" CREATED="1707842205704" MODIFIED="1707842211271"/>
</node>
<node TEXT="outdated data" ID="ID_506903821" CREATED="1707842227926" MODIFIED="1707842233573"/>
<node TEXT="geographically limited data" ID="ID_1466940835" CREATED="1707842245528" MODIFIED="1707842250105"/>
<node TEXT="small sample size" ID="ID_842711970" CREATED="1707851145129" MODIFIED="1707851148426"/>
<node TEXT="ways to address in sufficient data" FOLDED="true" ID="ID_1402145622" CREATED="1707842268297" MODIFIED="1707842277893">
<node TEXT="identify trends with the available data" ID="ID_1971342907" CREATED="1707842277895" MODIFIED="1707842284240"/>
<node TEXT="wait for more data if time allows" ID="ID_141027521" CREATED="1707842284256" MODIFIED="1707842288066"/>
<node TEXT="talk with stakeholders and adjust your objective" ID="ID_1892661923" CREATED="1707842288078" MODIFIED="1707842299513"/>
<node TEXT="look for a new data set" ID="ID_1365308431" CREATED="1707842307888" MODIFIED="1707842311543"/>
</node>
</node>
</node>
</node>
<node TEXT="Data Cleaning" FOLDED="true" ID="ID_217605844" CREATED="1706683210716" MODIFIED="1711145021977">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_1327348633" CREATED="1708108108773" MODIFIED="1708108111352">
<node ID="ID_1610087409" CREATED="1711144919794" MODIFIED="1711144919794" LINK="https://towardsdatascience.com/the-ultimate-guide-to-data-cleaning-3969843991d4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://towardsdatascience.com/the-ultimate-guide-to-data-cleaning-3969843991d4">The Ultimate Guide to Data Cleaning | by Omar Elgabry | Towards Data Science</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_976095236" CREATED="1708108119585" MODIFIED="1708108119585" LINK="https://acho.io/blogs/the-ultimate-guide-to-data-cleaning-in-sql"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://acho.io/blogs/the-ultimate-guide-to-data-cleaning-in-sql">The Ultimate Guide to Data Cleaning in SQL | Acho</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="document the cleaning process" ID="ID_914228472" CREATED="1708122594784" MODIFIED="1711411729756">
<icon BUILTIN="unchecked"/>
<node TEXT="Documentation: The process of tracking changes, additions, deletions, and errors involved in your data cleaning effort" ID="ID_252777167" CREATED="1708122646407" MODIFIED="1708122687042"/>
<node TEXT="Changelog: A file containing a chronologically ordered list of modifications made to a project" FOLDED="true" ID="ID_605935437" CREATED="1707783168582" MODIFIED="1707783168582">
<node TEXT="best practices" FOLDED="true" ID="ID_352891455" CREATED="1708123835252" MODIFIED="1708123837833">
<node TEXT="reference" FOLDED="true" ID="ID_133699910" CREATED="1708123840530" MODIFIED="1708123842844">
<node ID="ID_1701376357" CREATED="1708123843901" MODIFIED="1708123843901" LINK="https://co-pilot.dev/changelog"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://co-pilot.dev/changelog">Changelog best practices</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="spreadsheets" FOLDED="true" ID="ID_1357279275" CREATED="1708122958794" MODIFIED="1708122962044">
<node TEXT="For each file: Version History" ID="ID_93194026" CREATED="1708122962049" MODIFIED="1708123032819"/>
<node TEXT="For each cell: R-Click .. show edit history" ID="ID_72634776" CREATED="1708123000182" MODIFIED="1708123025685"/>
</node>
<node TEXT="SQL" FOLDED="true" ID="ID_974547457" CREATED="1708122996015" MODIFIED="1708122998515">
<node TEXT="add comments" FOLDED="true" ID="ID_1915059358" CREATED="1708123061980" MODIFIED="1708123070243">
<node TEXT="used to update change log" ID="ID_1324476873" CREATED="1708123072357" MODIFIED="1708123076570"/>
</node>
<node TEXT="BigQuery" FOLDED="true" ID="ID_269249715" CREATED="1708123078722" MODIFIED="1708123082958">
<node TEXT="Query history" ID="ID_729753707" CREATED="1708123092924" MODIFIED="1708123127633"/>
</node>
</node>
</node>
<node TEXT="purpose" FOLDED="true" ID="ID_62519260" CREATED="1708122742668" MODIFIED="1708122745215">
<node TEXT="recover data cleaning errors" ID="ID_1134796418" CREATED="1708122745217" MODIFIED="1708122755625"/>
<node TEXT="inform other users of changes" ID="ID_611912266" CREATED="1708122794753" MODIFIED="1708122799138"/>
<node TEXT="determine quality of data" ID="ID_1872607840" CREATED="1708122787902" MODIFIED="1708122810105"/>
<node TEXT="can function as a cheat sheet when working with a similar dataset or addressing similar errors" ID="ID_12417828" CREATED="1708124187705" MODIFIED="1708124209682"/>
<node TEXT="builds credibility" ID="ID_1707847110" CREATED="1708124274565" MODIFIED="1708124302611"/>
</node>
</node>
<node TEXT="make a copy" ID="ID_22772991" CREATED="1708122768937" MODIFIED="1708122773498"/>
<node TEXT="Address dirty data" FOLDED="true" ID="ID_271358794" CREATED="1711411864520" MODIFIED="1711412545616">
<font BOLD="true"/>
<node ID="ID_1942875641" TREE_ID="ID_402811030">
<node ID="ID_112804985" TREE_ID="ID_187417961">
<node ID="ID_1336907451" TREE_ID="ID_1808891131">
<node ID="ID_778757102" TREE_ID="ID_263530768"/>
</node>
<node ID="ID_64983324" CONTENT_ID="ID_219427301">
<node ID="ID_951135730" CONTENT_ID="ID_1734543185"/>
</node>
<node ID="ID_708785279" CONTENT_ID="ID_1993090584"/>
<node ID="ID_1373097076" CONTENT_ID="ID_1602371485">
<node ID="ID_297156380" CONTENT_ID="ID_177644687">
<node ID="ID_606021451" CONTENT_ID="ID_286663522"/>
</node>
<node ID="ID_1352134996" CONTENT_ID="ID_1738474985"/>
<node ID="ID_1024040478" CONTENT_ID="ID_646244203">
<node ID="ID_512387425" CONTENT_ID="ID_915629476"/>
</node>
<node ID="ID_1793407967" CONTENT_ID="ID_751881105">
<node ID="ID_1244945685" CONTENT_ID="ID_146854108"/>
</node>
</node>
<node ID="ID_242431692" CONTENT_ID="ID_1503929441">
<node ID="ID_1274780058" CONTENT_ID="ID_587353198">
<node ID="ID_803179202" CONTENT_ID="ID_1713263948"/>
</node>
<node ID="ID_1077414557" CONTENT_ID="ID_1880428980"/>
<node ID="ID_1868948104" CONTENT_ID="ID_228934765"/>
</node>
<node ID="ID_1282001819" CONTENT_ID="ID_1893014631">
<node ID="ID_919546843" CONTENT_ID="ID_42018302">
<node ID="ID_182132114" CONTENT_ID="ID_163686019"/>
</node>
<node ID="ID_172575427" CONTENT_ID="ID_647526496"/>
<node ID="ID_114146385" CONTENT_ID="ID_800763280"/>
<node ID="ID_736459676" CONTENT_ID="ID_296654317"/>
</node>
</node>
</node>
<node TEXT="• Misleading variable labels (columns): Did you name your columns meaningfully?" ID="ID_1661394219" CREATED="1708116327171" MODIFIED="1708116327171"/>
</node>
<node TEXT="Checklist" FOLDED="true" ID="ID_748366270" CREATED="1708012951747" MODIFIED="1708012959599">
<node TEXT="Remove" ID="ID_396628866" CREATED="1708108100669" MODIFIED="1711145128824"/>
<node TEXT="• Business Logic: Did you check that the data makes sense given your knowledge of the business?" ID="ID_692752851" CREATED="1708116327174" MODIFIED="1708116327174"/>
<node TEXT="Deal with outliers" FOLDED="true" ID="ID_1194867586" CREATED="1708108100673" MODIFIED="1708108100673">
<node TEXT="removing outliers" FOLDED="true" ID="ID_1393337681" CREATED="1706739058021" MODIFIED="1711144967399">
<node TEXT="can skew the information" ID="ID_935136604" CREATED="1706739062389" MODIFIED="1706739069028"/>
</node>
</node>
<node TEXT="Standardize/Normalize data" ID="ID_1594274217" CREATED="1708108100674" MODIFIED="1708108100674"/>
<node TEXT="Validate data" ID="ID_1116033142" CREATED="1708108100674" MODIFIED="1708108100674"/>
<node TEXT="transforming it into a more useful format" ID="ID_823328666" CREATED="1706739031902" MODIFIED="1706739041389"/>
<node TEXT="check data to make sure it&apos;s complete and correct" ID="ID_1164317373" CREATED="1706739088285" MODIFIED="1706739106037"/>
<node TEXT="data integrity" ID="ID_1137246300" CREATED="1706683222621" MODIFIED="1706683226359"/>
</node>
<node TEXT="SQL" FOLDED="true" ID="ID_633354026" CREATED="1708107855021" MODIFIED="1708107858392">
<node TEXT="reference" FOLDED="true" ID="ID_1969862567" CREATED="1708107870123" MODIFIED="1708107874161">
<node TEXT="M:\My Drive\My Google Docs\Google Data Analytics Certificate\Data Cleaning\Data-Prep-with-SQL-Pugsley-KDnuggets.pdf" FOLDED="true" ID="ID_935920174" CREATED="1708107875191" MODIFIED="1708107882839" LINK="file:/M:/My%20Drive/My%20Google%20Docs/Google%20Data%20Analytics%20Certificate/Data%20Cleaning/Data-Prep-with-SQL-Pugsley-KDnuggets.pdf">
<node ID="ID_61440809" CREATED="1708107916407" MODIFIED="1708107916407" LINK="https://www.kdnuggets.com/2021/05/data-preparation-sql-cheat-sheet.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.kdnuggets.com/2021/05/data-preparation-sql-cheat-sheet.html">Data Preparation with SQL Cheatsheet - KDnuggets</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Questions to ask yourself in this step:" FOLDED="true" ID="ID_1385037081" CREATED="1706900372184" MODIFIED="1706900372184">
<node TEXT="What data errors or inaccuracies might get in my way of getting the best possible answer to the problem I am trying to solve?" ID="ID_1824602599" CREATED="1706900372184" MODIFIED="1706900372184"/>
<node TEXT="How can I clean my data so the information I have is more consistent?" ID="ID_1105343848" CREATED="1706900372185" MODIFIED="1706900372185"/>
</node>
</node>
<node TEXT="verifying" FOLDED="true" ID="ID_40702888" CREATED="1708115053222" MODIFIED="1708115059413">
<node ID="ID_19443711" TREE_ID="ID_1434157483"/>
<node TEXT="involves manually cleaning data to compare your expectations with what&apos;s actually present" ID="ID_193008799" CREATED="1708115381626" MODIFIED="1708115392487"/>
<node TEXT="Why it&apos;s important" FOLDED="true" ID="ID_213452725" CREATED="1708115148434" MODIFIED="1708115201677">
<node TEXT="any insights you gain from analysis can&apos;t be trusted for decision-making" ID="ID_582508539" CREATED="1708115152850" MODIFIED="1708115161030"/>
<node TEXT="risk misrepresenting populations or damaging the outcome of a product that you are actually trying to improve" ID="ID_1455538620" CREATED="1708115161047" MODIFIED="1708115171074"/>
</node>
<node TEXT="Steps" FOLDED="true" ID="ID_774226473" CREATED="1708115400099" MODIFIED="1708115402642">
<node TEXT="recheck the daily cleaning effort" FOLDED="true" ID="ID_160680480" CREATED="1708116551137" MODIFIED="1708116559227">
<node TEXT="review the dirty data and try to identify any common problems" FOLDED="true" ID="ID_122250970" CREATED="1708115402645" MODIFIED="1708115410634">
<node TEXT="lots of nulls" ID="ID_1831326179" CREATED="1708115410638" MODIFIED="1708115421428"/>
</node>
</node>
<node TEXT="manually fix errors" ID="ID_117858513" CREATED="1708116559248" MODIFIED="1708116569037"/>
<node TEXT="considerable whether the data is credible and appropriate for the project" FOLDED="true" ID="ID_1927950073" CREATED="1708116578563" MODIFIED="1708116586660">
<node TEXT="big picture view of your project to confirm you&apos;re actually focusing on the business problem that you need to solve in the overall goals and to make sure that your data is actually capable of solving that problem in achieving those goals" FOLDED="true" ID="ID_1930551006" CREATED="1708115429634" MODIFIED="1708115474867">
<node TEXT="consider the business problem you are trying to solve with the data" ID="ID_978031873" CREATED="1708115504448" MODIFIED="1708115516031"/>
<node TEXT="consider the goal" ID="ID_1531638668" CREATED="1708115516046" MODIFIED="1708115549043"/>
<node TEXT="consider the data" FOLDED="true" ID="ID_1882103371" CREATED="1708115549061" MODIFIED="1708115555677">
<node TEXT="will it help your company achieve that goal" ID="ID_1860458576" CREATED="1708115557083" MODIFIED="1708115615044"/>
<node TEXT="is it capable of solving the problem in meeting the project objectives" ID="ID_1840594192" CREATED="1708115615062" MODIFIED="1708115626641"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="reporting on the integrity of your clean data, and get feedback" FOLDED="true" ID="ID_1662707889" CREATED="1708115060617" MODIFIED="1708124413126">
<node TEXT="why" FOLDED="true" ID="ID_174587382" CREATED="1708115228466" MODIFIED="1708115231028">
<node TEXT="shows your team that you&apos;re being 100%  transparent about your data cleaning" ID="ID_1404634125" CREATED="1708115291846" MODIFIED="1708115311863"/>
<node TEXT="shows stakeholders" FOLDED="true" ID="ID_230360293" CREATED="1708115231031" MODIFIED="1708115255640">
<node TEXT="that you&apos;re accountable" ID="ID_1235446907" CREATED="1708115255643" MODIFIED="1708115260821"/>
<node TEXT="build trust with your team" ID="ID_1896330042" CREATED="1708115260841" MODIFIED="1708115264027"/>
<node TEXT="make sure you&apos;re on the same page on important project details" ID="ID_1433621927" CREATED="1708115264047" MODIFIED="1708115271061"/>
</node>
<node TEXT="daily cleaning process can reveal insights that are helpful to business" FOLDED="true" ID="ID_1187604460" CREATED="1708124358047" MODIFIED="1708124370966">
<node TEXT="transform data collection processes" ID="ID_982311492" CREATED="1708124372244" MODIFIED="1708124377753"/>
<node TEXT="reducing errors and inefficiencies, can lead to increase profitability" ID="ID_1053577268" CREATED="1708124429469" MODIFIED="1708124482664"/>
</node>
</node>
</node>
</node>
<node TEXT="Step 4: Analyze" ID="ID_182925168" CREATED="1706900372187" MODIFIED="1706900372187">
<node TEXT="Deliverable" FOLDED="true" ID="ID_965621952" CREATED="1711649456298" MODIFIED="1711649459364">
<node TEXT="summary of analysis" ID="ID_1258805950" CREATED="1711649469994" MODIFIED="1711649473564">
<node TEXT="bike case study" ID="ID_1599967854" CREATED="1711649473906" MODIFIED="1711649480717">
<node ID="ID_255021160" CREATED="1711649535136" MODIFIED="1711649535136"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      members versus nonmembers
    </p>
  </body>
</html>
</richcontent>
<node TEXT="average trip duration" ID="ID_1461769398" CREATED="1711649544906" MODIFIED="1711649552526"/>
<node TEXT="histograms of trip duration," ID="ID_828299949" CREATED="1711649481746" MODIFIED="1711649533132"/>
<node TEXT="% returned to home location" ID="ID_380631588" CREATED="1711938638620" MODIFIED="1711938652136"/>
<node TEXT="distance" ID="ID_764365221" CREATED="1711938652560" MODIFIED="1711938658227"/>
</node>
</node>
</node>
</node>
<node TEXT="Roadmap" ID="ID_1176413167" CREATED="1712603564535" MODIFIED="1712603566610">
<node TEXT="Guiding questions" FOLDED="true" ID="ID_1315571574" CREATED="1712603568917" MODIFIED="1712603578444">
<font BOLD="true"/>
<node TEXT="How should you organize your data to perform analysis on it?" ID="ID_1340560935" CREATED="1712603568917" MODIFIED="1712603568917"/>
<node TEXT="Has your data been properly formatted?" ID="ID_1270557382" CREATED="1712603568919" MODIFIED="1712603568919"/>
<node TEXT="What surprises did you discover in the data?" ID="ID_273462074" CREATED="1712603568921" MODIFIED="1712603568921"/>
<node TEXT="What trends or relationships have you found in the data?" ID="ID_1229079984" CREATED="1712603568923" MODIFIED="1712603568923"/>
<node TEXT="How do these insights answer your question or solve the problem?" ID="ID_219691158" CREATED="1712603568925" MODIFIED="1712603568925"/>
</node>
<node TEXT="Key tasks" FOLDED="true" ID="ID_738523809" CREATED="1712603568927" MODIFIED="1712603586627">
<font BOLD="true"/>
<node TEXT="Now you’ll really put your data to work to uncover new insights and discover potential solutions to your problem!" ID="ID_1715896824" CREATED="1712603568928" MODIFIED="1712603568928"/>
<node TEXT="Aggregate your data so it’s useful and accessible" ID="ID_482319993" CREATED="1712603568929" MODIFIED="1712603568929"/>
<node TEXT="Organize and format your data" ID="ID_152386565" CREATED="1712603568930" MODIFIED="1712603568930"/>
<node TEXT="Perform calculations" ID="ID_237738325" CREATED="1712603568931" MODIFIED="1712603568931"/>
<node TEXT="Identify trends and relationships" ID="ID_59963977" CREATED="1712603568931" MODIFIED="1712603568931"/>
</node>
</node>
<node TEXT="Organize data for more effective analysis (Course 5)" FOLDED="true" ID="ID_1305283136" CREATED="1708210958051" MODIFIED="1708210972802">
<node TEXT="reference" ID="ID_811599973" CREATED="1708210979782" MODIFIED="1708210981801">
<node ID="ID_283325419" CREATED="1708446566829" MODIFIED="1708446566829" LINK="https://www.coursera.org/learn/analyze-data/home/module/1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/analyze-data/home/module/1">Analyze Data to Answer Questions - Organize data for more effective analysis - Week 1 | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_456595198" CREATED="1708211498725" MODIFIED="1708211498725"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h1 class="western">
      <font size="3" style="font-size: 12pt">Module 1: Organizing data to begin analysis</font>
    </h1>
  </body>
</html>
</richcontent>
<node TEXT="You will want to think analytically about your data. At this stage, you might sort and format your data to make it easier to:" ID="ID_422579036" CREATED="1706900372188" MODIFIED="1706900372188">
<node TEXT="Perform calculations" ID="ID_38966536" CREATED="1706900372189" MODIFIED="1706900372189"/>
<node TEXT="Combine data from multiple sources" ID="ID_462998439" CREATED="1706900372189" MODIFIED="1706900372189"/>
<node TEXT="Create tables with your results" ID="ID_1006292735" CREATED="1706900372190" MODIFIED="1706900372190"/>
</node>
<node TEXT="Questions to ask yourself in this step:" FOLDED="true" ID="ID_1012841828" CREATED="1706900372190" MODIFIED="1706900372190">
<node TEXT="What story is my data telling me?" ID="ID_285957691" CREATED="1706900372191" MODIFIED="1706900372191"/>
<node TEXT="How will my data help me solve this problem?" ID="ID_1154923367" CREATED="1706900372191" MODIFIED="1706900372191"/>
<node TEXT="Who needs my company’s product or service? What type of person is most likely to use it?" ID="ID_417287585" CREATED="1706900372192" MODIFIED="1706900372192"/>
</node>
<node ID="ID_1794559087" CREATED="1708211498725" MODIFIED="1708211498725"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Citations</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1844244825" CREATED="1708211498726" MODIFIED="1708211498726" LINK="https://www.coursera.org/learn/analyze-data/supplement/6xPhu/sorting-and-filtering-in-sheets-and-excel"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/6xPhu/sorting-and-filtering-in-sheets-and-excel" target="_blank"><font size="3" style="font-size: 12pt">Sorting and filtering in Sheets and Excel</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1629395597" CREATED="1708211498726" MODIFIED="1708211498726" LINK="https://www.youtube.com/watch?v=2dO4SDHKoPE"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Colonial Intermediate Unit 20. (2017, February 10). </font><em><font size="3" style="font-size: 12pt">Tech tip # 13 - Google Sheets - Sorting multiple columns</font></em><font size="3" style="font-size: 12pt">&#xa0;[Video]. YouTube. <a href="https://www.youtube.com/watch?v=2dO4SDHKoPE" target="_blank">https://www.youtube.com/watch?v=2dO4SDHKoPE</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_825798950" CREATED="1708211498727" MODIFIED="1708211498727" LINK="https://www.youtube.com/watch?v=Ep5q1cUhQas"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">GCFLearnFree.org. (2016, February 8). </font><em><font size="3" style="font-size: 12pt">Excel: Sorting data</font></em><font size="3" style="font-size: 12pt">&#xa0;&#xa0;[Video]. YouTube. <a href="https://www.youtube.com/watch?v=Ep5q1cUhQas" target="_blank">https://www.youtube.com/watch?v=Ep5q1cUhQas</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1711460885" CREATED="1708211498727" MODIFIED="1708211498727" LINK="https://support.google.com/docs/answer/3093197?hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">FILTER function</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/3093197?hl=en" target="_blank">https://support.google.com/docs/answer/3093197?hl=en</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_587319786" CREATED="1708211498728" MODIFIED="1708211498728" LINK="https://support.google.com/docs/answer/3093150?hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">SORT function</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/3093150?hl=en" target="_blank">https://support.google.com/docs/answer/3093150?hl=en</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_822163431" CREATED="1708211498729" MODIFIED="1708211498729" LINK="https://support.google.com/docs/answer/3540681?co=GENIE.Platform%3DDesktop&amp;hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Sort &amp; filter your data</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/3540681?co=GENIE.Platform%3DDesktop&amp;hl=en" target="_blank">https://support.google.com/docs/answer/3540681?co=GENIE.Platform%3DDesktop&amp;hl=en</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_718806343" CREATED="1708211498729" MODIFIED="1708211498729" LINK="https://www.youtube.com/watch?v=VcRBHXBMKBU"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google [Google Workspace]. (2019, December 10). </font><em><font size="3" style="font-size: 12pt">Sort &amp; filter data in Google Sheets</font></em><font size="3" style="font-size: 12pt">&#xa0;[Video]. YouTube. <a href="https://www.youtube.com/watch?v=VcRBHXBMKBU" target="_blank">https://www.youtube.com/watch?v=VcRBHXBMKBU</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_675741806" CREATED="1708211498729" MODIFIED="1708211498729" LINK="https://support.microsoft.com/en-us/office/filter-function-f4f7cb66-82eb-4767-8f7c-4877ad80c759"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">FILTER function</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/filter-function-f4f7cb66-82eb-4767-8f7c-4877ad80c759" target="_blank">https://support.microsoft.com/en-us/office/filter-function-f4f7cb66-82eb-4767-8f7c-4877ad80c759</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1773881259" CREATED="1708211498730" MODIFIED="1708211498730" LINK="https://support.microsoft.com/en-us/office/sort-data-in-a-range-or-table-62d0b95d-2a90-4610-a6ae-2e545c4a4654"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.).</font><em><font size="3" style="font-size: 12pt">&#xa0;Sort data in a range or table</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/sort-data-in-a-range-or-table-62d0b95d-2a90-4610-a6ae-2e545c4a4654" target="_blank">https://support.microsoft.com/en-us/office/sort-data-in-a-range-or-table-62d0b95d-2a90-4610-a6ae-2e545c4a4654</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1077086545" CREATED="1708211498730" MODIFIED="1708211498730" LINK="https://support.microsoft.com/en-us/office/video-sort-data-in-a-range-or-table-ffb9fcb0-b9cb-48bf-a15c-8bec9fd3a472#ID0EAABAAA=Transcript"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Sort data in a range or table </font></em><font size="3" style="font-size: 12pt">[Video]. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/video-sort-data-in-a-range-or-table-ffb9fcb0-b9cb-48bf-a15c-8bec9fd3a472#ID0EAABAAA=Transcript" target="_blank">https://support.microsoft.com/en-us/office/video-sort-data-in-a-range-or-table-ffb9fcb0-b9cb-48bf-a15c-8bec9fd3a472#ID0EAABAAA=Transcript</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1516312622" CREATED="1708211498731" MODIFIED="1708211498731" LINK="https://support.microsoft.com/en-us/office/sort-function-22f63bd0-ccc8-492f-953d-c20e8e44b86c"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">SORT function</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/sort-function-22f63bd0-ccc8-492f-953d-c20e8e44b86c" target="_blank">https://support.microsoft.com/en-us/office/sort-function-22f63bd0-ccc8-492f-953d-c20e8e44b86c</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_710444704" CREATED="1708211498731" MODIFIED="1708211498731" LINK="https://support.microsoft.com/en-us/office/sortby-function-cd2d7a62-1b93-435c-b561-d6a35134f28f"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">SORTBY function</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/sortby-function-cd2d7a62-1b93-435c-b561-d6a35134f28f" target="_blank">https://support.microsoft.com/en-us/office/sortby-function-cd2d7a62-1b93-435c-b561-d6a35134f28f</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_194650315" CREATED="1708211498731" MODIFIED="1708211498731" LINK="https://www.coursera.org/learn/analyze-data/quiz/iAg3O/hands-on-activity-sql-sorting-queries"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/iAg3O/hands-on-activity-sql-sorting-queries" target="_blank"><font size="3" style="font-size: 12pt">Optional Refresher: Using BigQuery</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1313556809" CREATED="1708211498732" MODIFIED="1708211498732" LINK="https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">About BigQuery sandbox</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox" target="_blank">https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_559029001" CREATED="1708211498732" MODIFIED="1708211498732" LINK="https://cloud.google.com/bigquery/docs"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">BigQuery documentation</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs" target="_blank">https://cloud.google.com/bigquery/docs</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_467394122" CREATED="1708211498732" MODIFIED="1708211498732"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h1 class="western">
      <font size="3" style="font-size: 12pt">Module 2: Formatting and adjusting data</font>
    </h1>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1004303" CREATED="1708211498735" MODIFIED="1708211498735"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Resources</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_135995411" CREATED="1708211498735" MODIFIED="1708211498735" LINK="https://www.coursera.org/learn/analyze-data/supplement/2Ulho/step-by-step-strings-in-spreadsheets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/2Ulho/step-by-step-strings-in-spreadsheets" target="_blank"><font size="3" style="font-size: 12pt">Step-by-Step: Strings in spreadsheets</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1235604806" CREATED="1708211498736" MODIFIED="1708211498736" LINK="https://support.microsoft.com/en-us/office/excel-video-training-9bc05390-e94c-46af-a5b3-d7c22f6990bb"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://support.microsoft.com/en-us/office/excel-video-training-9bc05390-e94c-46af-a5b3-d7c22f6990bb" target="_blank"><font size="3" style="font-size: 12pt">Microsoft Excel for Windows Training</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1323802646" CREATED="1708211498736" MODIFIED="1708211498736" LINK="https://www.coursera.org/learn/analyze-data/quiz/Opk0B/self-reflection-stack-overflow"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/Opk0B/self-reflection-stack-overflow" target="_blank"><font size="3" style="font-size: 12pt">Activity: Self-Reflection: Stack Overflow</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1781438914" CREATED="1708211498736" MODIFIED="1708211498736" LINK="https://stackoverflow.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://stackoverflow.com/" target="_blank"><font size="3" style="font-size: 12pt">Stack Overflow</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1857140674" CREATED="1708211498737" MODIFIED="1708211498737" LINK="https://stackoverflow.com/tags"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://stackoverflow.com/tags" target="_blank"><font size="3" style="font-size: 12pt">Stack overflow list of existing tags</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1811273882" CREATED="1708211498737" MODIFIED="1708211498737" LINK="https://stackoverflow.com/help/searching"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://stackoverflow.com/help/searching" target="_blank">Instructions on how to search</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_985369832" CREATED="1708211498737" MODIFIED="1708211498737" LINK="https://stackoverflow.com/search"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://stackoverflow.com/search" target="_blank"><font size="3" style="font-size: 12pt">Search types and search syntax</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_157796019" CREATED="1708211498738" MODIFIED="1708211498738"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Citations</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1135261757" CREATED="1708211498738" MODIFIED="1708211498738" LINK="https://www.coursera.org/learn/analyze-data/supplement/H7GTe/converting-data-in-spreadsheets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/H7GTe/converting-data-in-spreadsheets" target="_blank"><font size="3" style="font-size: 12pt">Converting data in spreadsheets</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1625710965" CREATED="1708211498738" MODIFIED="1708211498738" LINK="https://www.ablebits.com/office-addins-blog/2018/07/18/excel-convert-text-to-number/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Cheusheva, S. (2020, October 9). </font><em><font size="3" style="font-size: 12pt">How to convert text to number in Excel</font></em><font size="3" style="font-size: 12pt">. Ablebits.com. <a href="https://www.ablebits.com/office-addins-blog/2018/07/18/excel-convert-text-to-number/" target="_blank">https://www.ablebits.com/office-addins-blog/2018/07/18/excel-convert-text-to-number/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1074707670" CREATED="1708211498739" MODIFIED="1708211498739" LINK="https://www.ablebits.com/office-addins-blog/2018/07/18/excel-convert-text-to-number/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Cheusheva, S. (2021, March 6). </font><em><font size="3" style="font-size: 12pt">How to convert text to date and number to date in Excel</font></em><font size="3" style="font-size: 12pt">. Ablebits.com. <a href="https://www.ablebits.com/office-addins-blog/2018/07/18/excel-convert-text-to-number/" target="_blank">https://www.ablebits.com/office-addins-blog/2018/07/18/excel-convert-text-to-number/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1482955365" CREATED="1708211498739" MODIFIED="1708211498739" LINK="https://support.google.com/docs/answer/3094284?hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">TO_PERCENT</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/3094284?hl=en" target="_blank">https://support.google.com/docs/answer/3094284?hl=en</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1751530426" CREATED="1708211498740" MODIFIED="1708211498740" LINK="https://support.google.com/docs/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google Docs Editors Help. <a href="https://support.google.com/docs/" target="_blank">https://support.google.com/docs/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1198259391" CREATED="1708211498740" MODIFIED="1708211498740" LINK="https://support.microsoft.com/en-us/office/combine-text-from-two-or-more-cells-into-one-cell-81ba0946-ce78-42ed-b3c3-21340eb164a6"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Combine text from two or more cells into one cell</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/combine-text-from-two-or-more-cells-into-one-cell-81ba0946-ce78-42ed-b3c3-21340eb164a6" target="_blank">https://support.microsoft.com/en-us/office/combine-text-from-two-or-more-cells-into-one-cell-81ba0946-ce78-42ed-b3c3-21340eb164a6</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_379418928" CREATED="1708211498740" MODIFIED="1708211498740" LINK="https://support.microsoft.com/en-us/office/format-numbers-as-percentages-de49167b-d603-4450-bcaa-31fba6c7b6b4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Format numbers as percentages</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/format-numbers-as-percentages-de49167b-d603-4450-bcaa-31fba6c7b6b4" target="_blank">https://support.microsoft.com/en-us/office/format-numbers-as-percentages-de49167b-d603-4450-bcaa-31fba6c7b6b4</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1749615370" CREATED="1708211498740" MODIFIED="1708211498740" LINK="https://support.microsoft.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft Support. <a href="https://support.microsoft.com/" target="_blank">https://support.microsoft.com/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1219134582" CREATED="1708211498740" MODIFIED="1708211498740" LINK="https://www.ablebits.com/office-addins-blog/google-sheets-change-date-format/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Sharashova, N. (2021, November 22). </font><em><font size="3" style="font-size: 12pt">How to change Google Sheets date format and convert dates to numbers and text</font></em><font size="3" style="font-size: 12pt">. Ablebits.Com. <a href="https://www.ablebits.com/office-addins-blog/google-sheets-change-date-format/" target="_blank">https://www.ablebits.com/office-addins-blog/google-sheets-change-date-format/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_773982772" CREATED="1708211498741" MODIFIED="1708211498741" LINK="https://productivityspot.com/convert-text-to-numbers-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Sunit. (n.d.). </font><em><font size="3" style="font-size: 12pt">How to convert text to numbers in Google Sheets</font></em><font size="3" style="font-size: 12pt">. Productivity Spot. <a href="https://productivityspot.com/convert-text-to-numbers-google-sheets/" target="_blank">https://productivityspot.com/convert-text-to-numbers-google-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1326065011" CREATED="1708211498741" MODIFIED="1708211498741" LINK="https://www.techrepublic.com/article/how-to-split-or-combine-text-cells-with-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Wolber, A. (2020, May 18). </font><em><font size="3" style="font-size: 12pt">How to split or combine text cells with Google Sheets</font></em><font size="3" style="font-size: 12pt">. TechRepublic. <a href="https://www.techrepublic.com/article/how-to-split-or-combine-text-cells-with-google-sheets/" target="_blank">https://www.techrepublic.com/article/how-to-split-or-combine-text-cells-with-google-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1780523937" CREATED="1708211498741" MODIFIED="1708211498741" LINK="https://www.coursera.org/learn/analyze-data/supplement/H7GTe/converting-data-in-spreadsheets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/H7GTe/converting-data-in-spreadsheets" target="_blank"><font size="3" style="font-size: 12pt">Converting data in spreadsheets</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_657802631" CREATED="1708211498743" MODIFIED="1708211498743" LINK="https://www.ablebits.com/office-addins-blog/2015/03/26/excel-convert-text-date/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Cheusheva, S. (2021, March 29). </font><em><font size="3" style="font-size: 12pt">How to convert text to date and number to date in Excel</font></em><font size="3" style="font-size: 12pt">. Ablebits.com. <a href="https://www.ablebits.com/office-addins-blog/2015/03/26/excel-convert-text-date/" target="_blank">https://www.ablebits.com/office-addins-blog/2015/03/26/excel-convert-text-date/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1297359313" CREATED="1708211498743" MODIFIED="1708211498743" LINK="https://www.coursera.org/learn/analyze-data/supplement/H7GTe/converting-data-in-spreadsheets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/H7GTe/converting-data-in-spreadsheets" target="_blank"><font size="3" style="font-size: 12pt">Converting data in spreadsheets</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1617118288" CREATED="1708211498743" MODIFIED="1708211498743" LINK="https://cloud.google.com/bigquery/docs/reference/standard-sql/conversion_rules"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Conversion rules</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/reference/standard-sql/conversion_rules" target="_blank">https://cloud.google.com/bigquery/docs/reference/standard-sql/conversion_rules</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_18836404" CREATED="1708211498744" MODIFIED="1708211498744" LINK="https://docs.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql?view=sql-server-ver15"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">CAST and CONVERT (Transact-SQL)</font></em><font size="3" style="font-size: 12pt">. Microsoft Docs. <a href="https://docs.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql?view=sql-server-ver15" target="_blank">https://docs.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql?view=sql-server-ver15</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_119985724" CREATED="1708211498744" MODIFIED="1708211498744" LINK="https://dev.mysql.com/doc/refman/8.0/en/cast-functions.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">MySQL. (n.d.). </font><em><font size="3" style="font-size: 12pt">Cast functions and operators</font></em><font size="3" style="font-size: 12pt">. MySQL 8.0 Reference Manual. <a href="https://dev.mysql.com/doc/refman/8.0/en/cast-functions.html" target="_blank">https://dev.mysql.com/doc/refman/8.0/en/cast-functions.html</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_296867882" CREATED="1708211498744" MODIFIED="1708211498744" LINK="https://www.rudderstack.com/guides/how-to-sql-type-casting/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">RudderStack. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL type casting: How to get started?</font></em><font size="3" style="font-size: 12pt">&#xa0; <a href="https://www.rudderstack.com/guides/how-to-sql-type-casting/" target="_blank">https://www.rudderstack.com/guides/how-to-sql-type-casting/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_329382636" CREATED="1708211498745" MODIFIED="1708211498745" LINK="https://www.coursera.org/learn/analyze-data/supplement/HqeNj/transforming-data-in-sql"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/HqeNj/transforming-data-in-sql" target="_blank"><font size="3" style="font-size: 12pt">Transforming data in SQL</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_553293473" CREATED="1708211498745" MODIFIED="1708211498745" LINK="https://cloud.google.com/bigquery/docs/reference/standard-sql/conversion_rules"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Conversion rules</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/reference/standard-sql/conversion_rules" target="_blank">https://cloud.google.com/bigquery/docs/reference/standard-sql/conversion_rules</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_310568113" CREATED="1708211498745" MODIFIED="1708211498745" LINK="https://docs.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql?view=sql-server-ver15"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">CAST and CONVERT (Transact-SQL)</font></em><font size="3" style="font-size: 12pt">. Microsoft Docs. <a href="https://docs.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql?view=sql-server-ver15" target="_blank">https://docs.microsoft.com/en-us/sql/t-sql/functions/cast-and-convert-transact-sql?view=sql-server-ver15</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1806375700" CREATED="1708211498746" MODIFIED="1708211498746" LINK="https://dev.mysql.com/doc/refman/8.0/en/cast-functions.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">MySQL. (n.d.). </font><em><font size="3" style="font-size: 12pt">Cast functions and operators</font></em><font size="3" style="font-size: 12pt">. MySQL 8.0 Reference Manual. <a href="https://dev.mysql.com/doc/refman/8.0/en/cast-functions.html" target="_blank">https://dev.mysql.com/doc/refman/8.0/en/cast-functions.html</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1558586463" CREATED="1708211498746" MODIFIED="1708211498746" LINK="https://www.rudderstack.com/guides/how-to-sql-type-casting/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">RudderStack. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL type casting: How to get started?</font></em><font size="3" style="font-size: 12pt">&#xa0; <a href="https://www.rudderstack.com/guides/how-to-sql-type-casting/" target="_blank">https://www.rudderstack.com/guides/how-to-sql-type-casting/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1130307150" CREATED="1708211498746" MODIFIED="1708211498746" LINK="https://www.coursera.org/learn/analyze-data/supplement/oitMs/manipulating-strings-in-sql"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/oitMs/manipulating-strings-in-sql" target="_blank"><font size="3" style="font-size: 12pt">Manipulating strings in SQL</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_37121013" CREATED="1708211498746" MODIFIED="1708211498746" LINK="https://www.w3schools.com/sql/sql_ref_keywords.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL keywords reference</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/sql_ref_keywords.asp" target="_blank">https://www.w3schools.com/sql/sql_ref_keywords.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_24115087" CREATED="1708211498747" MODIFIED="1708211498747" LINK="https://www.w3schools.com/sql/func_sqlserver_concat.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL Server CONCAT() function</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/func_sqlserver_concat.asp" target="_blank">https://www.w3schools.com/sql/func_sqlserver_concat.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_254468408" CREATED="1708211498747" MODIFIED="1708211498747" LINK="https://www.w3schools.com/sql/func_sqlserver_concat_with_plus.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL Server Concat With +</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/func_sqlserver_concat_with_plus.asp" target="_blank">https://www.w3schools.com/sql/func_sqlserver_concat_with_plus.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1351798487" CREATED="1708211498747" MODIFIED="1708211498747" LINK="https://www.w3schools.com/sql/func_sqlserver_concat_ws.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL Server CONCAT_WS() function</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/func_sqlserver_concat_ws.asp" target="_blank">https://www.w3schools.com/sql/func_sqlserver_concat_ws.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_470697729" CREATED="1708211498749" MODIFIED="1708211498749" LINK="https://www.w3schools.com/sql/sql_ref_sqlserver.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL Server functions</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/sql_ref_sqlserver.asp" target="_blank">https://www.w3schools.com/sql/sql_ref_sqlserver.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1404074445" CREATED="1708211498749" MODIFIED="1708211498749" LINK="https://www.coursera.org/learn/analyze-data/supplement/6Vp5U/advanced-spreadsheet-tips-and-tricks"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/6Vp5U/advanced-spreadsheet-tips-and-tricks" target="_blank"><font size="3" style="font-size: 12pt">Advanced spreadsheet tips and tricks</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_484627903" CREATED="1708211498749" MODIFIED="1708211498749" LINK="https://learntocodewith.me/posts/excel-skills/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Bradford, L. (2021, February 24). 11 advanced Excel skills that will make you look like a spreadsheet pro. Learn to Code With Me. <a href="https://learntocodewith.me/posts/excel-skills/" target="_blank">https://learntocodewith.me/posts/excel-skills/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_713592925" CREATED="1708211498750" MODIFIED="1708211498750" LINK="https://www.benlcollins.com/spreadsheets/google-sheets-formulas-techniques/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Collins, B. (n.d.). </font><em><font size="3" style="font-size: 12pt">18 Google Sheets formulas tips &amp; techniques you should know</font></em><font size="3" style="font-size: 12pt">. BenCollins. <a href="https://www.benlcollins.com/spreadsheets/google-sheets-formulas-techniques/" target="_blank">https://www.benlcollins.com/spreadsheets/google-sheets-formulas-techniques/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1770927725" CREATED="1708211498750" MODIFIED="1708211498750" LINK="https://support.google.com/docs/table/25273"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Google Sheets function list</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/table/25273" target="_blank">https://support.google.com/docs/table/25273</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1306035257" CREATED="1708211498750" MODIFIED="1708211498750" LINK="https://support.google.com/docs/answer/181110"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Keyboard shortcuts for Google Sheets</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/181110" target="_blank">https://support.google.com/docs/answer/181110</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_403928889" CREATED="1708211498751" MODIFIED="1708211498751" LINK="https://exceljet.net/keyboard-shortcuts"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">222 Excel shortcuts for Windows and Mac</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/keyboard-shortcuts" target="_blank">https://exceljet.net/keyboard-shortcuts</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1045845336" CREATED="1708211498751" MODIFIED="1708211498751" LINK="https://exceljet.net/formulas"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">500 Excel formula examples</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/formulas" target="_blank">https://exceljet.net/formulas</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1688440215" CREATED="1708211498751" MODIFIED="1708211498751" LINK="https://exceljet.net/excel-functions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">Excel function list</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/excel-functions" target="_blank">https://exceljet.net/excel-functions</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_424250795" CREATED="1708211498751" MODIFIED="1708211498751" LINK="https://support.microsoft.com/en-us/office/keyboard-shortcuts-in-excel-1798d9d5-842a-42b8-9c99-9b7213f0040f?ui=en-US&amp;rs=en-US&amp;ad=US"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Keyboard shortcuts in Excel</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/keyboard-shortcuts-in-excel-1798d9d5-842a-42b8-9c99-9b7213f0040f?ui=en-US&amp;rs=en-US&amp;ad=US" target="_blank">https://support.microsoft.com/en-us/office/keyboard-shortcuts-in-excel-1798d9d5-842a-42b8-9c99-9b7213f0040f?ui=en-US&amp;rs=en-US&amp;ad=US</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1756819706" CREATED="1708211498752" MODIFIED="1708211498752" LINK="https://www.slideshare.net/markjhonoxillo/advanced-spreadsheet-skills"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Oxillo, M. J. (2017, December 14). </font><em><font size="3" style="font-size: 12pt">Advanced spreadsheet skills - Empowerment technologies</font></em><font size="3" style="font-size: 12pt">. Slideshare. <a href="https://www.slideshare.net/markjhonoxillo/advanced-spreadsheet-skills" target="_blank">https://www.slideshare.net/markjhonoxillo/advanced-spreadsheet-skills</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_387843601" CREATED="1708211498752" MODIFIED="1708211498752" LINK="https://automate.io/blog/google-spreadsheet-formulas/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Sharma, A. (2020, May 29). </font><em><font size="3" style="font-size: 12pt">20 Google Sheets formulas you must know! </font></em><font size="3" style="font-size: 12pt">Automate.Io Blog. <a href="https://automate.io/blog/google-spreadsheet-formulas/" target="_blank">https://automate.io/blog/google-spreadsheet-formulas/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_725891663" CREATED="1708211498752" MODIFIED="1708211498752" LINK="https://www.coursera.org/learn/analyze-data/quiz/Opk0B/self-reflection-stack-overflow"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/Opk0B/self-reflection-stack-overflow" target="_blank"><font size="3" style="font-size: 12pt">Self-Reflection: Stack Overflow</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_985467988" CREATED="1708211498753" MODIFIED="1708211498753" LINK="https://stackoverflow.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Stack Overflow. <a href="https://stackoverflow.com/" target="_blank">https://stackoverflow.com/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1031861533" CREATED="1708211498753" MODIFIED="1708211498753" LINK="https://stackoverflow.com/questions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Stack Overflow. (n.d.). </font><em><font size="3" style="font-size: 12pt">All questions</font></em><font size="3" style="font-size: 12pt">. <a href="https://stackoverflow.com/questions" target="_blank">https://stackoverflow.com/questions</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_754904596" CREATED="1708211498754" MODIFIED="1708211498754" LINK="https://stackoverflow.com/help/searching"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Stack Overflow. (n.d.). </font><em><font size="3" style="font-size: 12pt">How do I search? </font></em><a href="https://stackoverflow.com/help/searching" target="_blank"><font size="3" style="font-size: 12pt">https://stackoverflow.com/help/searching</font></a>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_2575501" CREATED="1708211498754" MODIFIED="1708211498754" LINK="https://stackoverflow.com/search?s=7a24a462-5529-4777-87b0-ec8e7b3b1ea7"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Stack Overflow. (n.d.). </font><em><font size="3" style="font-size: 12pt">Search</font></em><font size="3" style="font-size: 12pt">. <a href="https://stackoverflow.com/search?s=7a24a462-5529-4777-87b0-ec8e7b3b1ea7" target="_blank">https://stackoverflow.com/search?s=7a24a462-5529-4777-87b0-ec8e7b3b1ea7</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1913640387" CREATED="1708211498754" MODIFIED="1708211498754" LINK="https://stackoverflow.com/tags"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Stack Overflow. (n.d.). </font><em><font size="3" style="font-size: 12pt">Tags</font></em><font size="3" style="font-size: 12pt">. <a href="https://stackoverflow.com/tags" target="_blank">https://stackoverflow.com/tags</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1821796319" CREATED="1708211498755" MODIFIED="1708211498755"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h1 class="western">
      <font size="3" style="font-size: 12pt">Module 3: Aggregating data for analysis</font>
    </h1>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_176145509" CREATED="1708211498757" MODIFIED="1708211498757"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Resources</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_640338582" CREATED="1708211498757" MODIFIED="1708211498757" LINK="https://www.coursera.org/learn/analyze-data/supplement/SNmqP/vlookup-core-concepts"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/SNmqP/vlookup-core-concepts" target="_blank"><font size="3" style="font-size: 12pt">VLOOKUP core concepts</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1923176346" CREATED="1708211498757" MODIFIED="1708211498757" LINK="https://support.microsoft.com/en-us/office/vlookup-function-0bbc8083-26fe-4963-8ab8-93a18ad188a1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://support.microsoft.com/en-us/office/vlookup-function-0bbc8083-26fe-4963-8ab8-93a18ad188a1" target="_blank">How to use VLOOKUP in Excel</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_408710989" CREATED="1708211498758" MODIFIED="1708211498758" LINK="https://www.youtube.com/watch?v=d3BYVQ6xIE4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://www.youtube.com/watch?v=d3BYVQ6xIE4" target="_blank">VLOOKUP in Excel tutorial</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_742970962" CREATED="1708211498758" MODIFIED="1708211498758" LINK="https://exceljet.net/things-you-should-know-about-vlookup"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://exceljet.net/things-you-should-know-about-vlookup" target="_blank">23 things you should know about VLOOKUP in Excel</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1363520467" CREATED="1708211498758" MODIFIED="1708211498758" LINK="https://edu.gcfglobal.org/en/excel-tips/how-to-use-excels-vlookup-function/1/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://edu.gcfglobal.org/en/excel-tips/how-to-use-excels-vlookup-function/1/" target="_blank">How to use Excel's VLOOKUP function</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_929156708" CREATED="1708211498759" MODIFIED="1708211498759" LINK="https://infoinspired.com/sheets-vs-excel-formula/vlookup-formula-in-excel-and-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://infoinspired.com/sheets-vs-excel-formula/vlookup-formula-in-excel-and-google-sheets/" target="_blank">VLOOKUP in Excel vs Google Sheets</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_244906332" CREATED="1708211498759" MODIFIED="1708211498759" LINK="https://www.coursera.org/learn/analyze-data/quiz/kCl1b/hands-on-activity-use-vlookup-to-perform-a-task"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/kCl1b/hands-on-activity-use-vlookup-to-perform-a-task" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Use VLOOKUP to perform a task</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_397064469" CREATED="1708211498759" MODIFIED="1708211498759" LINK="https://support.microsoft.com/en-us/office/create-a-pivottable-to-analyze-worksheet-data-a9a84538-bfe9-40a9-a8e9-f99134456576"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://support.microsoft.com/en-us/office/create-a-pivottable-to-analyze-worksheet-data-a9a84538-bfe9-40a9-a8e9-f99134456576" target="_blank"><font size="3" style="font-size: 12pt">Manually create a pivot table in Excel</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1972374904" CREATED="1708211498759" MODIFIED="1708211498759" LINK="https://www.coursera.org/learn/analyze-data/quiz/vnDR2/hands-on-activity-queries-for-joins"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/vnDR2/hands-on-activity-queries-for-joins" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Queries for JOINS</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_21925440" CREATED="1708211498760" MODIFIED="1708211498760" LINK="https://cloud.google.com/bigquery/docs/sandbox"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://cloud.google.com/bigquery/docs/sandbox" target="_blank"><font size="3" style="font-size: 12pt">BigQuery Sandbox</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_469024932" CREATED="1708211498760" MODIFIED="1708211498760" LINK="https://www.coursera.org/learn/analyze-data/supplement/HuXCc/upload-the-warehouse-dataset-to-bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/HuXCc/upload-the-warehouse-dataset-to-bigquery" target="_blank"><font size="3" style="font-size: 12pt">Upload the warehouse dataset to BigQuery</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_63431797" CREATED="1708211498760" MODIFIED="1708211498760" LINK="https://console.cloud.google.com/bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://console.cloud.google.com/bigquery" target="_blank"><font size="3" style="font-size: 12pt">BigQuery console</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_704068968" CREATED="1708211498760" MODIFIED="1708211498760" LINK="https://www.coursera.org/learn/analyze-data/assignment-submission/wIOtj/hands-on-activity-use-subqueries"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/assignment-submission/wIOtj/hands-on-activity-use-subqueries" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Use subqueries</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1809854437" CREATED="1708211498761" MODIFIED="1708211498761" LINK="https://console.cloud.google.com/bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://console.cloud.google.com/bigquery" target="_blank"><font size="3" style="font-size: 12pt">BigQuery Console</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_733769232" CREATED="1708211498761" MODIFIED="1708211498761" LINK="https://www.coursera.org/learn/analyze-data/supplement/SthVU/sql-functions-and-subqueries-a-functional-friendship"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/SthVU/sql-functions-and-subqueries-a-functional-friendship" target="_blank"><font size="3" style="font-size: 12pt">SQL functions and subqueries: A functional friendship</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1784405672" CREATED="1708211498761" MODIFIED="1708211498761" LINK="http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_having.asp.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_having.asp.html" target="_blank">W3School’s HAVING overview</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_621304489" CREATED="1708211498762" MODIFIED="1708211498762" LINK="https://www.w3schools.com/sql/sql_case.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://www.w3schools.com/sql/sql_case.asp" target="_blank">W3School’s CASE overview</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_862154430" CREATED="1708211498762" MODIFIED="1708211498762" LINK="https://www.w3schools.com/sql/func_mysql_if.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://www.w3schools.com/sql/func_mysql_if.asp" target="_blank">W3School’s IF overview</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_336142187" CREATED="1708211498763" MODIFIED="1708211498763" LINK="http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_func_count.asp.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_func_count.asp.html" target="_blank"><font size="3" style="font-size: 12pt">W3School’s COUNT overview</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1231379598" CREATED="1708211498763" MODIFIED="1708211498763" LINK="https://www.w3resource.com/sql/subqueries/understanding-sql-subqueries.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://www.w3resource.com/sql/subqueries/understanding-sql-subqueries.php" target="_blank">SQL subqueries</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1983204270" CREATED="1708211498764" MODIFIED="1708211498764" LINK="https://mode.com/sql-tutorial/sql-sub-queries/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://mode.com/sql-tutorial/sql-sub-queries/" target="_blank"><font size="3" style="font-size: 12pt">Writing subqueries in SQL</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_235222645" CREATED="1708211498764" MODIFIED="1708211498764"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Citations</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1669886415" CREATED="1708211498765" MODIFIED="1708211498765" LINK="https://www.coursera.org/learn/analyze-data/supplement/SNmqP/vlookup-core-concepts"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/SNmqP/vlookup-core-concepts" target="_blank"><font size="3" style="font-size: 12pt">VLOOKUP core concepts</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1504719104" CREATED="1708211498765" MODIFIED="1708211498765" LINK="https://www.youtube.com/watch?v=d3BYVQ6xIE4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Excel Campus - John. (2019, August 15). </font><em><font size="3" style="font-size: 12pt">VLOOKUP tutorial for Excel - Everything you need to know</font></em><font size="3" style="font-size: 12pt">&#xa0;[Video]. YouTube. <a href="https://www.youtube.com/watch?v=d3BYVQ6xIE4" target="_blank">https://www.youtube.com/watch?v=d3BYVQ6xIE4</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_819098108" CREATED="1708211498765" MODIFIED="1708211498765" LINK="https://exceljet.net/things-you-should-know-about-vlookup"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">23 things you should know about VLOOKUP</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/things-you-should-know-about-vlookup" target="_blank">https://exceljet.net/things-you-should-know-about-vlookup</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_765566558" CREATED="1708211498766" MODIFIED="1708211498766" LINK="https://edu.gcfglobal.org/en/excel-tips/how-to-use-excels-vlookup-function/1/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">GCFGlobal. (n.d.). </font><em><font size="3" style="font-size: 12pt">Excel tips: How to use Excel’s VLOOKUP function</font></em><font size="3" style="font-size: 12pt">. GCFGlobal.Org. <a href="https://edu.gcfglobal.org/en/excel-tips/how-to-use-excels-vlookup-function/1/" target="_blank">https://edu.gcfglobal.org/en/excel-tips/how-to-use-excels-vlookup-function/1/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1339733121" CREATED="1708211498766" MODIFIED="1708211498766" LINK="https://support.microsoft.com/en-us/office/vlookup-function-0bbc8083-26fe-4963-8ab8-93a18ad188a1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">VLOOKUP function</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/vlookup-function-0bbc8083-26fe-4963-8ab8-93a18ad188a1" target="_blank">https://support.microsoft.com/en-us/office/vlookup-function-0bbc8083-26fe-4963-8ab8-93a18ad188a1</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_236729754" CREATED="1708211498766" MODIFIED="1708211498766" LINK="https://infoinspired.com/sheets-vs-excel-formula/vlookup-formula-in-excel-and-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Prashanth. (n.d.). </font><em><font size="3" style="font-size: 12pt">Comparison of Vlookup formula in Excel and Google Sheets</font></em><font size="3" style="font-size: 12pt">. InfoInspired. <a href="https://infoinspired.com/sheets-vs-excel-formula/vlookup-formula-in-excel-and-google-sheets/" target="_blank">https://infoinspired.com/sheets-vs-excel-formula/vlookup-formula-in-excel-and-google-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_54389251" CREATED="1708211498767" MODIFIED="1708211498767" LINK="https://www.coursera.org/learn/analyze-data/quiz/kCl1b/hands-on-activity-using-vlookup"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/kCl1b/hands-on-activity-using-vlookup" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Using VLOOKUP</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1818393636" CREATED="1708211498767" MODIFIED="1708211498767" LINK="https://support.microsoft.com/en-us/office/create-a-pivottable-to-analyze-worksheet-data-a9a84538-bfe9-40a9-a8e9-f99134456576"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Create a PivotTable to analyze worksheet data</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/create-a-pivottable-to-analyze-worksheet-data-a9a84538-bfe9-40a9-a8e9-f99134456576" target="_blank">https://support.microsoft.com/en-us/office/create-a-pivottable-to-analyze-worksheet-data-a9a84538-bfe9-40a9-a8e9-f99134456576</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_507936541" CREATED="1708211498767" MODIFIED="1708211498767" LINK="https://www.coursera.org/learn/analyze-data/supplement/qURXP/secret-identities-the-importance-of-aliases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/qURXP/secret-identities-the-importance-of-aliases" target="_blank"><font size="3" style="font-size: 12pt">Secret identities: The importance of aliases</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_536298142" CREATED="1708211498768" MODIFIED="1708211498768" LINK="https://www.w3schools.com/sql/sql_alias.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL aliases</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/sql_alias.asp" target="_blank">https://www.w3schools.com/sql/sql_alias.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_765356260" CREATED="1708211498768" MODIFIED="1708211498768" LINK="https://documentation.sas.com/doc/en/pgmsascdc/9.4_3.5/sqlproc/p0aymxwsvbt5wcn1lncugwjtf758.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">SAS Help Center. (n.d.). </font><em><font size="3" style="font-size: 12pt">Using column aliases</font></em><font size="3" style="font-size: 12pt">. <a href="https://documentation.sas.com/doc/en/pgmsascdc/9.4_3.5/sqlproc/p0aymxwsvbt5wcn1lncugwjtf758.htm" target="_blank">https://documentation.sas.com/doc/en/pgmsascdc/9.4_3.5/sqlproc/p0aymxwsvbt5wcn1lncugwjtf758.htm</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_710860644" CREATED="1708211498769" MODIFIED="1708211498769" LINK="https://www.sqltutorial.org/sql-alias/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">SQL Tutorial. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL alias: Make your query shorter and more understandable</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.sqltutorial.org/sql-alias/" target="_blank">https://www.sqltutorial.org/sql-alias/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1678710187" CREATED="1708211498769" MODIFIED="1708211498769" LINK="https://www.coursera.org/learn/analyze-data/supplement/DBOi7/using-joins-effectively"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/DBOi7/using-joins-effectively" target="_blank"><font size="3" style="font-size: 12pt">Using JOINs effectively</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1103599722" CREATED="1708211498770" MODIFIED="1708211498770" LINK="https://www.dofactory.com/sql/join"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Dofactory. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL JOIN</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.dofactory.com/sql/join" target="_blank">https://www.dofactory.com/sql/join</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1500042763" CREATED="1708211498771" MODIFIED="1708211498771" LINK="https://www.essentialsql.com/sql-joins/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Essential SQL. (2021, November 18). </font><em><font size="3" style="font-size: 12pt">SQL Joins – The ultimate guide</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.essentialsql.com/sql-joins/" target="_blank">https://www.essentialsql.com/sql-joins/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1351457305" CREATED="1708211498771" MODIFIED="1708211498771" LINK="https://towardsdatascience.com/sql-join-8212e3eb9fde"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Macaraeg, R. (2019, July 30). </font><em><font size="3" style="font-size: 12pt">SQL JOINs: Bringing data together one join at a time</font></em><font size="3" style="font-size: 12pt">. Towards Data Science. <a href="https://towardsdatascience.com/sql-join-8212e3eb9fde" target="_blank">https://towardsdatascience.com/sql-join-8212e3eb9fde</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_851270622" CREATED="1708211498772" MODIFIED="1708211498772" LINK="https://dataschool.com/how-to-teach-people-sql/sql-join-types-explained-visually/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Miller, T. (2021, August 9). </font><em><font size="3" style="font-size: 12pt">SQL Join types explained in visuals</font></em><font size="3" style="font-size: 12pt">. The Data School. <a href="https://dataschool.com/how-to-teach-people-sql/sql-join-types-explained-visually/" target="_blank">https://dataschool.com/how-to-teach-people-sql/sql-join-types-explained-visually/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_33419785" CREATED="1708211498772" MODIFIED="1708211498772" LINK="https://www.w3schools.com/sql/sql_join.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL Joins</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/sql_join.asp" target="_blank">https://www.w3schools.com/sql/sql_join.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1450794843" CREATED="1708211498773" MODIFIED="1708211498773" LINK="https://www.coursera.org/learn/analyze-data/quiz/vnDR2/hands-on-activity-queries-for-joins"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/vnDR2/hands-on-activity-queries-for-joins" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Queries for JOINS</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1598591618" CREATED="1708211498773" MODIFIED="1708211498773" LINK="https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">About BigQuery sandbox</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox" target="_blank">https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_972209746" CREATED="1708211498774" MODIFIED="1708211498774" LINK="https://www.coursera.org/learn/analyze-data/supplement/SthVU/sql-functions-and-subqueries-a-functional-friendship"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/SthVU/sql-functions-and-subqueries-a-functional-friendship" target="_blank"><font size="3" style="font-size: 12pt">SQL functions and subqueries: A functional friendship</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1970365942" CREATED="1708211498775" MODIFIED="1708211498775" LINK="https://mode.com/sql-tutorial/sql-sub-queries/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Mode. (n.d.). </font><em><font size="3" style="font-size: 12pt">Writing subqueries in SQL</font></em><font size="3" style="font-size: 12pt">. <a href="https://mode.com/sql-tutorial/sql-sub-queries/" target="_blank">https://mode.com/sql-tutorial/sql-sub-queries/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1094717730" CREATED="1708211498775" MODIFIED="1708211498775" LINK="https://www.w3schools.com/sql/func_mysql_if.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">MySQL IF() function</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/func_mysql_if.asp" target="_blank">https://www.w3schools.com/sql/func_mysql_if.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1458517348" CREATED="1708211498775" MODIFIED="1708211498775" LINK="https://www.w3schools.com/sql/sql_case.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL CASE statement</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="https://www.w3schools.com/sql/sql_case.asp" target="_blank">https://www.w3schools.com/sql/sql_case.asp</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_194520474" CREATED="1708211498776" MODIFIED="1708211498776" LINK="http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_having.asp.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Refsnes Data. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL HAVING clause</font></em><font size="3" style="font-size: 12pt">. W3Schools SQL Tutorial. <a href="http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_having.asp.html" target="_blank">http://www-db.deis.unibo.it/courses/TW/DOCS/w3schools/sql/sql_having.asp.html</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1844292833" CREATED="1708211498776" MODIFIED="1708211498776" LINK="https://www.w3resource.com/sql/subqueries/understanding-sql-subqueries.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">w3resource. (2021, October 14). </font><em><font size="3" style="font-size: 12pt">SQL subqueries</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.w3resource.com/sql/subqueries/understanding-sql-subqueries.php" target="_blank">https://www.w3resource.com/sql/subqueries/understanding-sql-subqueries.php</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_721312686" CREATED="1708211498777" MODIFIED="1708211498777"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h1 class="western">
      <font size="3" style="font-size: 12pt">Module 4: Performing data calculations</font>
    </h1>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1482707431" CREATED="1708211498780" MODIFIED="1708211498780"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Resources</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1308154107" CREATED="1708211498781" MODIFIED="1708211498781" LINK="https://www.coursera.org/learn/analyze-data/supplement/s9khi/functions-with-multiple-conditions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/s9khi/functions-with-multiple-conditions" target="_blank"><font size="3" style="font-size: 12pt">Functions with multiple conditions</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1018074960" CREATED="1708211498781" MODIFIED="1708211498781" LINK="https://exceljet.net/excel-functions/excel-ifs-function"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://exceljet.net/excel-functions/excel-ifs-function" target="_blank">How to use the Excel IFS function</a>&#xa0;&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_654651933" CREATED="1708211498782" MODIFIED="1708211498782" LINK="https://exceljet.net/formula/vlookup-with-multiple-criteria"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://exceljet.net/formula/vlookup-with-multiple-criteria" target="_blank">VLOOKUP in Excel with multiple criteria</a>&#xa0;&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_175299529" CREATED="1708211498782" MODIFIED="1708211498782" LINK="https://exceljet.net/formula/index-and-match-with-multiple-criteria"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://exceljet.net/formula/index-and-match-with-multiple-criteria" target="_blank">INDEX and MATCH in Excel with multiple criteria</a>&#xa0;&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1965501194" CREATED="1708211498783" MODIFIED="1708211498783" LINK="https://support.microsoft.com/en-us/office/using-if-with-and-or-and-not-functions-d895f58c-b36c-419e-b1f2-5c193a236d97"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://support.microsoft.com/en-us/office/using-if-with-and-or-and-not-functions-d895f58c-b36c-419e-b1f2-5c193a236d97" target="_blank"><font size="3" style="font-size: 12pt">Using IF with AND, OR, and NOT functions in Excel</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_908708785" CREATED="1708211498783" MODIFIED="1708211498783" LINK="https://www.coursera.org/learn/analyze-data/supplement/Y6c0d/upload-the-avocado-dataset-to-bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/Y6c0d/upload-the-avocado-dataset-to-bigquery" target="_blank"><font size="3" style="font-size: 12pt">Upload the avocado dataset to BigQuery</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1649194363" CREATED="1708211498784" MODIFIED="1708211498784" LINK="https://www.kaggle.com/neuromusic/avocado-prices"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://www.kaggle.com/neuromusic/avocado-prices" target="_blank"><font size="3" style="font-size: 12pt">Avocado Prices&#xa0;</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1081257630" CREATED="1708211498784" MODIFIED="1708211498784" LINK="https://www.kaggle.com/neuromusic"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><font size="3" style="font-size: 12pt"><a href="https://www.kaggle.com/neuromusic" target="_blank">Justin Kiggins</a>&#xa0;</font></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1586347573" CREATED="1708211498784" MODIFIED="1708211498784" LINK="https://opendatacommons.org/licenses/odbl/1-0/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://opendatacommons.org/licenses/odbl/1-0/" target="_blank"><font size="3" style="font-size: 12pt">Open Data Commons</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1168620241" CREATED="1708211498784" MODIFIED="1708211498784" LINK="https://www.coursera.org/learn/analyze-data/quiz/IEXum/hands-on-activity-calculations-with-sql"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/IEXum/hands-on-activity-calculations-with-sql" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Calculations in SQL</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1594916657" CREATED="1708211498785" MODIFIED="1708211498785" LINK="https://console.cloud.google.com/bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://console.cloud.google.com/bigquery" target="_blank"><font size="3" style="font-size: 12pt">BigQuery console</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1029254294" CREATED="1708211498785" MODIFIED="1708211498785" LINK="https://www.coursera.org/learn/analyze-data/quiz/Ac9jc/hands-on-activity-create-temporary-tables"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/Ac9jc/hands-on-activity-create-temporary-tables" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Create temporary tables</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_605608744" CREATED="1708211498786" MODIFIED="1708211498786" LINK="https://console.cloud.google.com/bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <em><a href="https://console.cloud.google.com/bigquery" target="_blank"><font size="3" style="font-size: 12pt">BigQuery console</font></a></em>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1073199689" CREATED="1708211498786" MODIFIED="1708211498786"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      <font size="3" style="font-size: 12pt">Citations</font>
    </h2>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1205689631" CREATED="1708211498786" MODIFIED="1708211498786" LINK="https://www.coursera.org/learn/analyze-data/supplement/s9khi/functions-with-multiple-conditions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/s9khi/functions-with-multiple-conditions" target="_blank"><font size="3" style="font-size: 12pt">Functions with multiple conditions</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1108125163" CREATED="1708211498786" MODIFIED="1708211498786" LINK="https://exceljet.net/excel-functions/excel-ifs-function"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">Excel IFS function</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/excel-functions/excel-ifs-function" target="_blank">https://exceljet.net/excel-functions/excel-ifs-function</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1898783015" CREATED="1708211498788" MODIFIED="1708211498788" LINK="https://exceljet.net/formula/index-and-match-with-multiple-criteria"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">INDEX and MATCH with multiple criteria</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/formula/index-and-match-with-multiple-criteria" target="_blank">https://exceljet.net/formula/index-and-match-with-multiple-criteria</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_857648097" CREATED="1708211498788" MODIFIED="1708211498788" LINK="https://exceljet.net/formula/vlookup-with-multiple-criteria"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">VLOOKUP with multiple criteria</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/formula/vlookup-with-multiple-criteria" target="_blank">https://exceljet.net/formula/vlookup-with-multiple-criteria</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_59905857" CREATED="1708211498789" MODIFIED="1708211498789" LINK="https://support.microsoft.com/en-us/office/using-if-with-and-or-and-not-functions-d895f58c-b36c-419e-b1f2-5c193a236d97"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Using IF with AND, OR and NOT functions</font></em><font size="3" style="font-size: 12pt">. Microsoft Support.<a href="https://support.microsoft.com/en-us/office/using-if-with-and-or-and-not-functions-d895f58c-b36c-419e-b1f2-5c193a236d97" target="_blank">https://support.microsoft.com/en-us/office/using-if-with-and-or-and-not-functions-d895f58c-b36c-419e-b1f2-5c193a236d97</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_286347548" CREATED="1708211498789" MODIFIED="1708211498789" LINK="https://www.coursera.org/learn/analyze-data/supplement/qRo2l/using-pivot-tables-in-analysis"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/qRo2l/using-pivot-tables-in-analysis" target="_blank"><font size="3" style="font-size: 12pt">Using pivot tables in analysis</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_640233289" CREATED="1708211498789" MODIFIED="1708211498789" LINK="https://www.benlcollins.com/spreadsheets/pivot-tables-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Collins, B. (n.d.). </font><em><font size="3" style="font-size: 12pt">Pivot tables in Google Sheets: A beginner’s guide</font></em><font size="3" style="font-size: 12pt">. BenCollins. <a href="https://www.benlcollins.com/spreadsheets/pivot-tables-google-sheets/" target="_blank">https://www.benlcollins.com/spreadsheets/pivot-tables-google-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_81766043" CREATED="1708211498790" MODIFIED="1708211498790" LINK="https://exceljet.net/lessons/how-to-sort-a-pivot-table-by-value"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">How to sort a pivot table by value</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/lessons/how-to-sort-a-pivot-table-by-value" target="_blank">https://exceljet.net/lessons/how-to-sort-a-pivot-table-by-value</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_618764291" CREATED="1708211498790" MODIFIED="1708211498790" LINK="https://exceljet.net/pivot-table/pivot-table-calculated-field-example"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Exceljet. (n.d.). </font><em><font size="3" style="font-size: 12pt">Pivot table calculated field example</font></em><font size="3" style="font-size: 12pt">. <a href="https://exceljet.net/pivot-table/pivot-table-calculated-field-example" target="_blank">https://exceljet.net/pivot-table/pivot-table-calculated-field-example</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1767859386" CREATED="1708211498790" MODIFIED="1708211498790" LINK="https://support.google.com/a/users/answer/9308944#group_data_in_a_pivot_table"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Create and edit pivot tables</font></em><font size="3" style="font-size: 12pt">. Google Workspace Learning Center. <a href="https://support.google.com/a/users/answer/9308944#group_data_in_a_pivot_table" target="_blank">https://support.google.com/a/users/answer/9308944#group_data_in_a_pivot_table</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1928469371" CREATED="1708211498791" MODIFIED="1708211498791" LINK="https://support.google.com/docs/answer/1272900"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Create &amp; use pivot tables</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/1272900" target="_blank">https://support.google.com/docs/answer/1272900</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1699638920" CREATED="1708211498791" MODIFIED="1708211498791" LINK="https://support.google.com/docs/answer/7572895"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Customize a pivot table</font></em><font size="3" style="font-size: 12pt">. Docs Editors Help. <a href="https://support.google.com/docs/answer/7572895" target="_blank">https://support.google.com/docs/answer/7572895</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1398132752" CREATED="1708211498791" MODIFIED="1708211498791" LINK="https://powerspreadsheets.com/pivottable-calculated-fields/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Gomez, J. A. (n.d.). </font><em><font size="3" style="font-size: 12pt">Excel pivot table calculated fields: Step-by-step tutorial</font></em><font size="3" style="font-size: 12pt">. Power Spreadsheets. <a href="https://powerspreadsheets.com/pivottable-calculated-fields/" target="_blank">https://powerspreadsheets.com/pivottable-calculated-fields/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1994703823" CREATED="1708211498792" MODIFIED="1708211498792" LINK="https://medium.com/actiondesk/pivot-table-ascending-descending-order-in-google-sheets-and-excel-1-minute-ultimate-beginners-8f9f4c560492"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Lehuger, S. (2020, February 21). </font><em><font size="3" style="font-size: 12pt">Pivot table ascending descending order in Google Sheets and Excel: 1-Minute ultimate beginner’s guide</font></em><font size="3" style="font-size: 12pt">. Medium. <a href="https://medium.com/actiondesk/pivot-table-ascending-descending-order-in-google-sheets-and-excel-1-minute-ultimate-beginners-8f9f4c560492" target="_blank">https://medium.com/actiondesk/pivot-table-ascending-descending-order-in-google-sheets-and-excel-1-minute-ultimate-beginners-8f9f4c560492</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_482940829" CREATED="1708211498792" MODIFIED="1708211498792" LINK="https://support.microsoft.com/en-us/office/calculate-values-in-a-pivottable-11f41417-da80-435c-a5c6-b0185e59da77"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Calculate values in a PivotTable</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/calculate-values-in-a-pivottable-11f41417-da80-435c-a5c6-b0185e59da77" target="_blank">https://support.microsoft.com/en-us/office/calculate-values-in-a-pivottable-11f41417-da80-435c-a5c6-b0185e59da77</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_880496711" CREATED="1708211498792" MODIFIED="1708211498792" LINK="https://support.microsoft.com/en-us/office/design-the-layout-and-format-of-a-pivottable-a9600265-95bf-4900-868e-641133c05a80"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Design the layout and format of a PivotTable</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/design-the-layout-and-format-of-a-pivottable-a9600265-95bf-4900-868e-641133c05a80" target="_blank">https://support.microsoft.com/en-us/office/design-the-layout-and-format-of-a-pivottable-a9600265-95bf-4900-868e-641133c05a80</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_488883529" CREATED="1708211498793" MODIFIED="1708211498793" LINK="https://support.microsoft.com/en-us/office/filter-data-in-a-pivottable-cc1ed287-3a97-4e95-b377-ddfafe79fa8f"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Filter data in a PivotTable</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/filter-data-in-a-pivottable-cc1ed287-3a97-4e95-b377-ddfafe79fa8f" target="_blank">https://support.microsoft.com/en-us/office/filter-data-in-a-pivottable-cc1ed287-3a97-4e95-b377-ddfafe79fa8f</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1381287659" CREATED="1708211498793" MODIFIED="1708211498793" LINK="https://support.microsoft.com/en-us/office/sort-data-in-a-pivottable-or-pivotchart-e41f7107-b92d-44ef-861f-24430830450a"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Microsoft. (n.d.). </font><em><font size="3" style="font-size: 12pt">Sort data in a PivotTable or PivotChart</font></em><font size="3" style="font-size: 12pt">. Microsoft Support. <a href="https://support.microsoft.com/en-us/office/sort-data-in-a-pivottable-or-pivotchart-e41f7107-b92d-44ef-861f-24430830450a" target="_blank">https://support.microsoft.com/en-us/office/sort-data-in-a-pivottable-or-pivotchart-e41f7107-b92d-44ef-861f-24430830450a</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_429590218" CREATED="1708211498794" MODIFIED="1708211498794" LINK="https://www.dummies.com/article/technology/software/microsoft-products/excel/how-to-filter-excel-pivot-table-data-152376"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Nelson, S. L., &amp; Nelson, E. C. (2016, March 26). </font><em><font size="3" style="font-size: 12pt">How to filter Excel pivot table data</font></em><font size="3" style="font-size: 12pt">. For Dummies. <a href="https://www.dummies.com/article/technology/software/microsoft-products/excel/how-to-filter-excel-pivot-table-data-152376" target="_blank">https://www.dummies.com/article/technology/software/microsoft-products/excel/how-to-filter-excel-pivot-table-data-152376</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_660889298" CREATED="1708211498794" MODIFIED="1708211498794" LINK="https://infoinspired.com/google-docs/spreadsheet/all-about-calculated-field-in-pivot-table-in-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Prashanth. (n.d.). </font><em><font size="3" style="font-size: 12pt">All about calculated field in pivot table in Google Sheets</font></em><font size="3" style="font-size: 12pt">. InfoInspired. <a href="https://infoinspired.com/google-docs/spreadsheet/all-about-calculated-field-in-pivot-table-in-google-sheets/" target="_blank">https://infoinspired.com/google-docs/spreadsheet/all-about-calculated-field-in-pivot-table-in-google-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1296518092" CREATED="1708211498795" MODIFIED="1708211498795" LINK="https://infoinspired.com/google-docs/spreadsheet/filter-multiple-values-in-pivot-table-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Prashanth. (n.d.). </font><em><font size="3" style="font-size: 12pt">Filter multiple values in pivot table in Google Sheets</font></em><font size="3" style="font-size: 12pt">. InfoInspired. <a href="https://infoinspired.com/google-docs/spreadsheet/filter-multiple-values-in-pivot-table-sheets/" target="_blank">https://infoinspired.com/google-docs/spreadsheet/filter-multiple-values-in-pivot-table-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1040508085" CREATED="1708211498795" MODIFIED="1708211498795" LINK="https://infoinspired.com/google-docs/spreadsheet/pivot-table-columns-in-custom-order-in-google-sheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Prashanth. (n.d.). </font><em><font size="3" style="font-size: 12pt">How to sort pivot table columns in the custom order in Google Sheets</font></em><font size="3" style="font-size: 12pt">. InfoInspired. <a href="https://infoinspired.com/google-docs/spreadsheet/pivot-table-columns-in-custom-order-in-google-sheets/" target="_blank">https://infoinspired.com/google-docs/spreadsheet/pivot-table-columns-in-custom-order-in-google-sheets/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_863800488" CREATED="1708211498796" MODIFIED="1708211498796" LINK="https://www.tutorialspoint.com/excel_pivot_tables/excel_pivot_tables_sorting_data.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Tutorials Point. (n.d.). </font><em><font size="3" style="font-size: 12pt">Excel pivot tables - Sorting data</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.tutorialspoint.com/excel_pivot_tables/excel_pivot_tables_sorting_data.htm" target="_blank">https://www.tutorialspoint.com/excel_pivot_tables/excel_pivot_tables_sorting_data.htm</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1722589254" CREATED="1708211498796" MODIFIED="1708211498796" LINK="https://www.coursera.org/learn/analyze-data/supplement/7Khvl/optional-upload-the-avocado-dataset-to-bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/7Khvl/optional-upload-the-avocado-dataset-to-bigquery" target="_blank"><font size="3" style="font-size: 12pt">Optional: Upload the avocado dataset to BigQuery</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1045484969" CREATED="1708211498797" MODIFIED="1708211498797" LINK="https://cloud.google.com/bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">BigQuery</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery" target="_blank">https://cloud.google.com/bigquery</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1087635758" CREATED="1708211498797" MODIFIED="1708211498797" LINK="https://cloud.google.com/bigquery/docs/loading-data"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Introduction to loading data</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/loading-data" target="_blank">https://cloud.google.com/bigquery/docs/loading-data</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_817478986" CREATED="1708211498797" MODIFIED="1708211498797" LINK="https://www.kaggle.com/neuromusic"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Justin Kiggins. (n.d.). </font><em><font size="3" style="font-size: 12pt">Home </font></em><font size="3" style="font-size: 12pt">[Kaggle profile]. Kaggle. <a href="https://www.kaggle.com/neuromusic" target="_blank">https://www.kaggle.com/neuromusic</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1236870666" CREATED="1708211498798" MODIFIED="1708211498798" LINK="https://www.kaggle.com/neuromusic/avocado-prices"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Kiggins, J. (2018). </font><em><font size="3" style="font-size: 12pt">Avocado prices </font></em><font size="3" style="font-size: 12pt">[Dataset]. Kaggle. <a href="https://www.kaggle.com/neuromusic/avocado-prices" target="_blank">https://www.kaggle.com/neuromusic/avocado-prices</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1968187419" CREATED="1708211498798" MODIFIED="1708211498798" LINK="https://opendatacommons.org/licenses/odbl/1-0/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Open Data Commons. <a href="https://opendatacommons.org/licenses/odbl/1-0/" target="_blank">https://opendatacommons.org/licenses/odbl/1-0/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_888615364" CREATED="1708211498799" MODIFIED="1708211498799" LINK="https://www.coursera.org/learn/analyze-data/quiz/IEXum/hands-on-activity-calculations-in-sql"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/IEXum/hands-on-activity-calculations-in-sql" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Calculations in SQL</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1578140690" CREATED="1708211498799" MODIFIED="1708211498799" LINK="https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">About BigQuery sandbox</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox" target="_blank">https://cloud.google.com/bigquery/docs/quickstarts/quickstart-cloud-console#about-bigquery-sandbox</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_772527295" CREATED="1708211498799" MODIFIED="1708211498799" LINK="https://www.coursera.org/learn/analyze-data/discussionPrompt/BaNil/calculations-and-queries"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/discussionPrompt/BaNil/calculations-and-queries" target="_blank"><font size="3" style="font-size: 12pt">Calculations and queries</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_659187369" CREATED="1708211498799" MODIFIED="1708211498799" LINK="https://www.kaggle.com/datasets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Kaggle. (n.d.). </font><em><font size="3" style="font-size: 12pt">Datasets</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.kaggle.com/datasets" target="_blank">https://www.kaggle.com/datasets</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1209519569" CREATED="1708211498800" MODIFIED="1708211498800" LINK="https://www.coursera.org/learn/analyze-data/quiz/Ac9jc/hands-on-activity-create-temporary-tables"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/quiz/Ac9jc/hands-on-activity-create-temporary-tables" target="_blank"><font size="3" style="font-size: 12pt">Hands-On Activity: Create temporary tables</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1500865262" CREATED="1708211498800" MODIFIED="1708211498800" LINK="https://console.cloud.google.com/bigquery"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">BigQuery Google Cloud Platform.<a href="https://console.cloud.google.com/bigquery" target="_blank">https://console.cloud.google.com/bigquery</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_190240481" CREATED="1708211498800" MODIFIED="1708211498800" LINK="https://www.coursera.org/learn/analyze-data/supplement/oGADZ/working-with-temporary-tables"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.coursera.org/learn/analyze-data/supplement/oGADZ/working-with-temporary-tables" target="_blank"><font size="3" style="font-size: 12pt">Working with temporary tables</font></a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1408587540" CREATED="1708211498801" MODIFIED="1708211498801" LINK="https://www.red-gate.com/hub/product-learning/sql-prompt/choosing-table-variables-temporary-tables"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Factor, P. (2018, May 11). </font><em><font size="3" style="font-size: 12pt">Choosing between table variables and temporary tables (ST011, ST012)</font></em><font size="3" style="font-size: 12pt">. Redgate. <a href="https://www.red-gate.com/hub/product-learning/sql-prompt/choosing-table-variables-temporary-tables" target="_blank">https://www.red-gate.com/hub/product-learning/sql-prompt/choosing-table-variables-temporary-tables</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1158077229" CREATED="1708211498801" MODIFIED="1708211498801" LINK="https://cloud.google.com/bigquery/docs/reference/standard-sql/data-definition-language#temporary_tables"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Google. (n.d.). </font><em><font size="3" style="font-size: 12pt">Data definition language (DDL) statements in standard SQL</font></em><font size="3" style="font-size: 12pt">. Google Cloud. <a href="https://cloud.google.com/bigquery/docs/reference/standard-sql/data-definition-language#temporary_tables" target="_blank">https://cloud.google.com/bigquery/docs/reference/standard-sql/data-definition-language#temporary_tables</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1159750505" CREATED="1708211498802" MODIFIED="1708211498802" LINK="https://www.pascallandau.com/bigquery-snippets/use-temporary-tables-with-named-subquery/?utm_source=blog&amp;utm_medium=rss&amp;utm_campaign=development-feed"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Landau, P. (2020, May 29). </font><em><font size="3" style="font-size: 12pt">BigQuery: Use “temporary tables” via WITH (named subqueries)</font></em><font size="3" style="font-size: 12pt">. Pascallandau.Com. <a href="https://www.pascallandau.com/bigquery-snippets/use-temporary-tables-with-named-subquery/?utm_source=blog&amp;utm_medium=rss&amp;utm_campaign=development-feed" target="_blank">https://www.pascallandau.com/bigquery-snippets/use-temporary-tables-with-named-subquery/?utm_source=blog&amp;utm_medium=rss&amp;utm_campaign=development-feed</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_493539245" CREATED="1708211498802" MODIFIED="1708211498802" LINK="https://codingsight.com/introduction-to-temporary-tables-in-sql-server/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">Richardson, B. (2017, June 26). </font><em><font size="3" style="font-size: 12pt">Introduction to temporary tables in SQL Server</font></em><font size="3" style="font-size: 12pt">. {coding}Sight. <a href="https://codingsight.com/introduction-to-temporary-tables-in-sql-server/" target="_blank">https://codingsight.com/introduction-to-temporary-tables-in-sql-server/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1029097851" CREATED="1708211498802" MODIFIED="1708211498802" LINK="https://www.sqlservertutorial.net/sql-server-basics/sql-server-temporary-tables/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <font size="3" style="font-size: 12pt">SQLServerTutorial.net. (n.d.). </font><em><font size="3" style="font-size: 12pt">SQL Server temporary tables</font></em><font size="3" style="font-size: 12pt">. <a href="https://www.sqlservertutorial.net/sql-server-basics/sql-server-temporary-tables/" target="_blank">https://www.sqlservertutorial.net/sql-server-basics/sql-server-temporary-tables/</a></font>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Analyze (4)" FOLDED="true" ID="ID_907350963" CREATED="1706679802138" MODIFIED="1706736711058">
<node TEXT="analysis: process used to make sense of the data collected" ID="ID_830006083" CREATED="1708211822009" MODIFIED="1708211861194">
<node TEXT="goal" ID="ID_1529293750" CREATED="1708211861196" MODIFIED="1708211865793">
<node TEXT="identify trends and relationships within the data so that you can accurately answer the question you&apos;re asking" ID="ID_1462705401" CREATED="1708211865795" MODIFIED="1708211894810"/>
</node>
<node ID="ID_1822837985" TREE_ID="ID_1203092975">
<node ID="ID_562815957" TREE_ID="ID_279294554"/>
<node ID="ID_1310364287" TREE_ID="ID_1125649431"/>
<node ID="ID_1620067012" TREE_ID="ID_1009085309"/>
<node ID="ID_1023503523" TREE_ID="ID_1493678840"/>
<node ID="ID_703542414" TREE_ID="ID_269556576">
<node ID="ID_227304448" TREE_ID="ID_53704619">
<node ID="ID_531259444" TREE_ID="ID_1618415127"/>
<node ID="ID_865901564" TREE_ID="ID_1734873539"/>
</node>
<node ID="ID_528195480" TREE_ID="ID_255441033">
<node ID="ID_1102844598" TREE_ID="ID_1078916976">
<node ID="ID_1647872132" TREE_ID="ID_1987022791">
<node ID="ID_363787081" TREE_ID="ID_1982617196"/>
</node>
</node>
<node ID="ID_1513511684" TREE_ID="ID_1762378411"/>
<node ID="ID_73017657" TREE_ID="ID_1592205280"/>
<node ID="ID_196438759" TREE_ID="ID_841935630"/>
</node>
</node>
<node ID="ID_701178332" TREE_ID="ID_1491564020"/>
<node ID="ID_1377678471" TREE_ID="ID_302163132"/>
<node ID="ID_339937281" TREE_ID="ID_1853861278"/>
<node ID="ID_1234402930" TREE_ID="ID_216337648"/>
<node ID="ID_517771876" TREE_ID="ID_1736844826">
<node ID="ID_1610049256" TREE_ID="ID_1452753566">
<node ID="ID_1803410536" TREE_ID="ID_1713865785"/>
<node ID="ID_743298439" TREE_ID="ID_802245375"/>
<node ID="ID_897034516" TREE_ID="ID_1931788622"/>
<node ID="ID_1096515841" TREE_ID="ID_1800381979"/>
<node ID="ID_1023024476" TREE_ID="ID_419482793">
<node ID="ID_1582699048" TREE_ID="ID_1680497406"/>
<node ID="ID_1686738292" TREE_ID="ID_639283588">
<node ID="ID_33682607" TREE_ID="ID_1619709240"/>
<node ID="ID_655565788" TREE_ID="ID_629003240"/>
<node ID="ID_694044823" TREE_ID="ID_1665415490"/>
<node ID="ID_1944909609" TREE_ID="ID_680492399"/>
<node ID="ID_625543211" TREE_ID="ID_1138697458"/>
</node>
</node>
<node ID="ID_478081133" TREE_ID="ID_425117334">
<node ID="ID_819004483" TREE_ID="ID_1455481654">
<node ID="ID_269832931" TREE_ID="ID_1058903015">
<node ID="ID_1242405164" TREE_ID="ID_1392816653"/>
<node ID="ID_192533214" TREE_ID="ID_432697076"/>
<node ID="ID_656582042" TREE_ID="ID_683729779"/>
</node>
<node ID="ID_262156837" TREE_ID="ID_1055940120">
<node ID="ID_1921095543" TREE_ID="ID_49787354">
<node ID="ID_1368568421" TREE_ID="ID_1698246656"/>
</node>
<node ID="ID_144316822" TREE_ID="ID_487512308"/>
</node>
<node ID="ID_379859314" TREE_ID="ID_1486176753">
<node ID="ID_1349771613" TREE_ID="ID_825713552"/>
</node>
</node>
</node>
</node>
<node ID="ID_1458637769" TREE_ID="ID_1371190613">
<node ID="ID_1945008534" TREE_ID="ID_249823704">
<node ID="ID_1030904431" TREE_ID="ID_1062278394"/>
<node ID="ID_129991857" TREE_ID="ID_570688057"/>
<node ID="ID_1883805828" TREE_ID="ID_1802340540"/>
</node>
</node>
</node>
<node ID="ID_1814573797" TREE_ID="ID_1111028046"/>
<node ID="ID_1456068166" TREE_ID="ID_744567163"/>
<node ID="ID_1178050741" TREE_ID="ID_825713552"/>
<node ID="ID_1380305330" TREE_ID="ID_957666536"/>
<node ID="ID_1011475126" TREE_ID="ID_1336425361">
<node ID="ID_1088282841" TREE_ID="ID_1168499084"/>
<node ID="ID_1141319826" TREE_ID="ID_1289588120"/>
<node ID="ID_687453761" TREE_ID="ID_1181564039">
<node ID="ID_1256062201" TREE_ID="ID_1136046139"/>
</node>
</node>
<node ID="ID_545089203" TREE_ID="ID_419482793">
<node ID="ID_1337054636" TREE_ID="ID_1680497406"/>
<node ID="ID_573513494" TREE_ID="ID_639283588">
<node ID="ID_1844526429" TREE_ID="ID_1619709240"/>
<node ID="ID_1042026564" TREE_ID="ID_629003240"/>
<node ID="ID_1531146491" TREE_ID="ID_1665415490"/>
<node ID="ID_55326609" TREE_ID="ID_680492399"/>
<node ID="ID_1344456303" TREE_ID="ID_1138697458"/>
</node>
</node>
<node ID="ID_1416824489" TREE_ID="ID_1779188337"/>
<node ID="ID_1543142315" TREE_ID="ID_1383805875">
<node ID="ID_1463863405" TREE_ID="ID_1015814811"/>
<node ID="ID_548211617" TREE_ID="ID_878528236">
<node ID="ID_582203820" TREE_ID="ID_1003419657"/>
</node>
</node>
<node ID="ID_656709984" TREE_ID="ID_639562831"/>
<node ID="ID_1820351145" TREE_ID="ID_560184425">
<node ID="ID_1632912721" TREE_ID="ID_1085541761">
<node ID="ID_1441270138" TREE_ID="ID_327832251"/>
<node ID="ID_27147517" TREE_ID="ID_292300196"/>
<node ID="ID_433341831" TREE_ID="ID_192050474"/>
<node ID="ID_306459547" TREE_ID="ID_222111409"/>
<node ID="ID_543562092" TREE_ID="ID_349554283"/>
</node>
</node>
<node ID="ID_556013584" TREE_ID="ID_484670680"/>
<node ID="ID_433674929" TREE_ID="ID_1284381903"/>
<node ID="ID_982578392" TREE_ID="ID_564522622"/>
<node ID="ID_500514305" TREE_ID="ID_675868817"/>
<node ID="ID_1733023450" TREE_ID="ID_626238598"/>
<node ID="ID_621867639" TREE_ID="ID_1997554382"/>
<node ID="ID_1532266936" TREE_ID="ID_1387279190"/>
<node ID="ID_795252717" TREE_ID="ID_1798994963"/>
<node ID="ID_294146814" TREE_ID="ID_596756661"/>
<node ID="ID_1239890483" TREE_ID="ID_1797301652"/>
<node ID="ID_1394753784" TREE_ID="ID_1280195795"/>
<node ID="ID_574295626" TREE_ID="ID_144613071"/>
<node ID="ID_863372996" TREE_ID="ID_1345045321"/>
<node ID="ID_588039886" TREE_ID="ID_742303107"/>
<node ID="ID_1201857727" TREE_ID="ID_1079928394">
<node ID="ID_1385789933" TREE_ID="ID_345894129"/>
</node>
<node ID="ID_1802447627" TREE_ID="ID_64500578"/>
<node ID="ID_1293913435" TREE_ID="ID_1384575707"/>
<node ID="ID_1061168027" TREE_ID="ID_1052783296"/>
<node ID="ID_749925332" TREE_ID="ID_1148665720"/>
<node ID="ID_1102285257" TREE_ID="ID_1474300339"/>
<node ID="ID_1962902497" TREE_ID="ID_1715626534"/>
<node ID="ID_846417683" TREE_ID="ID_707488610"/>
<node ID="ID_207640763" TREE_ID="ID_648414547"/>
<node ID="ID_384216896" TREE_ID="ID_605225687"/>
<node ID="ID_40717366" TREE_ID="ID_284379409"/>
<node ID="ID_1127426536" TREE_ID="ID_98794251"/>
<node ID="ID_1738748877" TREE_ID="ID_567630917"/>
<node ID="ID_1206371264" TREE_ID="ID_1190646486">
<node ID="ID_987065094" TREE_ID="ID_1424498196">
<node ID="ID_314449901" TREE_ID="ID_879659318"/>
<node ID="ID_216359544" TREE_ID="ID_761830950"/>
<node ID="ID_1552985331" TREE_ID="ID_958059518"/>
</node>
<node ID="ID_1849287040" TREE_ID="ID_798612372">
<node ID="ID_689300313" TREE_ID="ID_797357583"/>
<node ID="ID_1285623432" TREE_ID="ID_1848197391"/>
</node>
</node>
<node ID="ID_59407318" TREE_ID="ID_186411897"/>
<node ID="ID_1861680292" TREE_ID="ID_1505948045"/>
<node ID="ID_1878418007" TREE_ID="ID_1034865342"/>
<node ID="ID_1173367455" TREE_ID="ID_1275239576"/>
<node ID="ID_1732773412" TREE_ID="ID_226815566"/>
<node ID="ID_456568252" TREE_ID="ID_1400367438">
<node ID="ID_22295499" TREE_ID="ID_104817018">
<node ID="ID_817475918" TREE_ID="ID_1655297318"/>
<node ID="ID_1943485037" TREE_ID="ID_1348210739"/>
<node ID="ID_1371193830" TREE_ID="ID_631431541"/>
</node>
<node ID="ID_832606429" TREE_ID="ID_1154229933">
<node ID="ID_1888986094" TREE_ID="ID_675868817"/>
<node ID="ID_1230682365" TREE_ID="ID_207126650"/>
<node ID="ID_281740530" TREE_ID="ID_144895854"/>
</node>
<node ID="ID_1451689706" TREE_ID="ID_1350587479">
<node ID="ID_1659404229" TREE_ID="ID_1462849197"/>
<node ID="ID_1314477310" TREE_ID="ID_1337306009"/>
<node ID="ID_1440623649" TREE_ID="ID_309079556"/>
<node ID="ID_270486576" TREE_ID="ID_1278475512"/>
<node ID="ID_1790911380" TREE_ID="ID_986423180"/>
<node ID="ID_707073455" TREE_ID="ID_1531336"/>
<node ID="ID_1572719405" TREE_ID="ID_1103129924"/>
</node>
<node ID="ID_479076717" TREE_ID="ID_1992639856">
<node ID="ID_1215808862" TREE_ID="ID_959683850">
<node ID="ID_768630030" TREE_ID="ID_538973023">
<node ID="ID_415684620" TREE_ID="ID_259530355"/>
<node ID="ID_875862815" TREE_ID="ID_99852485"/>
<node ID="ID_1969542140" TREE_ID="ID_459754551"/>
<node ID="ID_215785471" TREE_ID="ID_1695734697"/>
</node>
</node>
<node ID="ID_1135345870" TREE_ID="ID_1075654590">
<node ID="ID_25663673" TREE_ID="ID_134243731">
<node ID="ID_1507051162" TREE_ID="ID_364974895"/>
<node ID="ID_1624280490" TREE_ID="ID_199517457"/>
<node ID="ID_1338666552" TREE_ID="ID_618461348"/>
<node ID="ID_203255452" TREE_ID="ID_1201566032"/>
</node>
</node>
</node>
<node ID="ID_806535675" TREE_ID="ID_975848248">
<node ID="ID_1049748156" TREE_ID="ID_602333147"/>
<node ID="ID_831220823" TREE_ID="ID_1451216921"/>
</node>
</node>
<node ID="ID_1373757798" TREE_ID="ID_1810290756"/>
<node ID="ID_1441310743" TREE_ID="ID_1883885560"/>
<node ID="ID_1594936408" TREE_ID="ID_1563459499"/>
<node ID="ID_1743580956" TREE_ID="ID_1806125294"/>
<node ID="ID_370682953" TREE_ID="ID_1095666889"/>
<node ID="ID_546979632" TREE_ID="ID_155994666"/>
<node ID="ID_711927186" TREE_ID="ID_741688432"/>
<node ID="ID_1583714462" TREE_ID="ID_834540186"/>
<node ID="ID_727558263" TREE_ID="ID_25656326"/>
<node ID="ID_686973795" TREE_ID="ID_902783119"/>
<node ID="ID_1243890532" TREE_ID="ID_1162592130"/>
<node ID="ID_481396199" TREE_ID="ID_710312168"/>
<node ID="ID_1713221883" TREE_ID="ID_425117334">
<node ID="ID_832697181" TREE_ID="ID_1455481654">
<node ID="ID_1848223732" TREE_ID="ID_1058903015">
<node ID="ID_412107922" TREE_ID="ID_1392816653"/>
<node ID="ID_1721035668" TREE_ID="ID_432697076"/>
<node ID="ID_1161480921" TREE_ID="ID_683729779"/>
</node>
<node ID="ID_1948953379" TREE_ID="ID_1055940120">
<node ID="ID_1130548277" TREE_ID="ID_49787354">
<node ID="ID_852777632" TREE_ID="ID_1698246656"/>
</node>
<node ID="ID_1736451329" TREE_ID="ID_487512308"/>
</node>
<node ID="ID_1987754203" TREE_ID="ID_1486176753">
<node ID="ID_440327483" TREE_ID="ID_825713552"/>
</node>
</node>
</node>
<node ID="ID_1311409236" TREE_ID="ID_1393108469"/>
<node ID="ID_355313811" TREE_ID="ID_343959532"/>
<node ID="ID_538241257" TREE_ID="ID_1599226023"/>
<node ID="ID_193025437" TREE_ID="ID_1713865785"/>
<node ID="ID_750210" TREE_ID="ID_401214769"/>
<node ID="ID_153309425" TREE_ID="ID_275511090"/>
<node ID="ID_71772627" TREE_ID="ID_181559345"/>
<node ID="ID_1795351712" TREE_ID="ID_1615926867"/>
<node ID="ID_1117323005" TREE_ID="ID_775266484">
<node ID="ID_1682998874" TREE_ID="ID_610105264"/>
</node>
<node ID="ID_591779187" TREE_ID="ID_1164292065"/>
<node ID="ID_83660265" TREE_ID="ID_1046771015"/>
<node ID="ID_1183075621" TREE_ID="ID_191198704"/>
<node ID="ID_522115503" TREE_ID="ID_1593041193"/>
<node ID="ID_1814425234" TREE_ID="ID_211150205"/>
<node ID="ID_518275076" TREE_ID="ID_1542087638"/>
<node ID="ID_1792610833" TREE_ID="ID_1481969728"/>
<node ID="ID_546142803" TREE_ID="ID_690150679"/>
<node ID="ID_1741643296" TREE_ID="ID_689737817"/>
<node ID="ID_554369570" TREE_ID="ID_515207793"/>
<node ID="ID_243070295" TREE_ID="ID_1626671566"/>
<node ID="ID_1218111531" TREE_ID="ID_1755813413"/>
<node ID="ID_1942194701" TREE_ID="ID_1036151852"/>
<node ID="ID_631966432" TREE_ID="ID_1240352299"/>
<node ID="ID_1195897978" TREE_ID="ID_1446508676"/>
<node ID="ID_1622180805" TREE_ID="ID_1808172918"/>
<node ID="ID_515915718" TREE_ID="ID_1690284276"/>
<node ID="ID_1030173250" TREE_ID="ID_1078916976">
<node ID="ID_1941918449" TREE_ID="ID_1987022791">
<node ID="ID_287030933" TREE_ID="ID_1982617196"/>
</node>
</node>
<node ID="ID_1200393295" TREE_ID="ID_1897417018"/>
<node ID="ID_1520586942" TREE_ID="ID_1871974292"/>
<node ID="ID_793460944" TREE_ID="ID_27505954"/>
<node ID="ID_542821721" TREE_ID="ID_1482479915"/>
<node ID="ID_1732033529" TREE_ID="ID_744941880"/>
<node ID="ID_330055029" TREE_ID="ID_844287307"/>
<node ID="ID_500695573" TREE_ID="ID_1750170748"/>
<node ID="ID_1413406366" TREE_ID="ID_623681594"/>
<node ID="ID_630479809" TREE_ID="ID_98044072"/>
<node ID="ID_682311036" TREE_ID="ID_936030494"/>
<node ID="ID_1708523666" TREE_ID="ID_485366436"/>
<node ID="ID_1673787229" TREE_ID="ID_408157908"/>
<node ID="ID_595637829" TREE_ID="ID_1682226606"/>
<node ID="ID_1216599641" TREE_ID="ID_327832251"/>
<node ID="ID_723047026" TREE_ID="ID_207126650"/>
<node ID="ID_1528739773" TREE_ID="ID_817091187">
<node ID="ID_311682659" TREE_ID="ID_905307665">
<node ID="ID_1424889226" TREE_ID="ID_1955441327"/>
<node ID="ID_1087102825" TREE_ID="ID_128302317"/>
<node ID="ID_1543662076" TREE_ID="ID_1943701917">
<node ID="ID_948975984" TREE_ID="ID_1477234090"/>
<node ID="ID_758378108" TREE_ID="ID_1271679259"/>
<node ID="ID_1024801554" TREE_ID="ID_1968356537"/>
</node>
</node>
<node ID="ID_723121703" TREE_ID="ID_1496921695">
<node ID="ID_31426154" TREE_ID="ID_50723928"/>
<node ID="ID_582201223" TREE_ID="ID_1880684194"/>
<node ID="ID_1761305787" TREE_ID="ID_157704053"/>
<node ID="ID_466554471" TREE_ID="ID_65121841"/>
</node>
<node ID="ID_48016054" TREE_ID="ID_1929096770">
<node ID="ID_1513801046" TREE_ID="ID_1336425361">
<node ID="ID_1082198722" TREE_ID="ID_1168499084"/>
<node ID="ID_1396989351" TREE_ID="ID_1289588120"/>
<node ID="ID_1445535570" TREE_ID="ID_1181564039">
<node ID="ID_1174263471" TREE_ID="ID_1136046139"/>
</node>
</node>
</node>
</node>
<node ID="ID_1119535392" TREE_ID="ID_1194131181"/>
<node ID="ID_1482848839" TREE_ID="ID_554425341"/>
<node ID="ID_1045237187" TREE_ID="ID_1322136704"/>
<node ID="ID_459477443" TREE_ID="ID_1255079526"/>
<node ID="ID_714701743" TREE_ID="ID_292300196"/>
<node ID="ID_604167367" TREE_ID="ID_414037554">
<node ID="ID_868810386" TREE_ID="ID_1140946322"/>
<node ID="ID_1588391364" TREE_ID="ID_1192376729">
<node ID="ID_1050581868" TREE_ID="ID_111275438"/>
<node ID="ID_443370412" TREE_ID="ID_860923761"/>
<node ID="ID_1641703678" TREE_ID="ID_1393403193"/>
</node>
</node>
<node ID="ID_221137271" TREE_ID="ID_173163004"/>
<node ID="ID_1339194530" TREE_ID="ID_802245375"/>
<node ID="ID_1220483393" TREE_ID="ID_1952607334"/>
<node ID="ID_846537847" TREE_ID="ID_1982617196"/>
<node ID="ID_360629340" TREE_ID="ID_1654669645"/>
<node ID="ID_45637902" TREE_ID="ID_1858544538"/>
<node ID="ID_409299463" TREE_ID="ID_1646534972">
<node ID="ID_1784603927" TREE_ID="ID_1494628602">
<node ID="ID_1097587139" TREE_ID="ID_1443629112"/>
<node ID="ID_1549264597" TREE_ID="ID_1124614683"/>
<node ID="ID_1304891113" TREE_ID="ID_1883556701"/>
<node ID="ID_1149197099" TREE_ID="ID_890955138"/>
<node ID="ID_872643146" TREE_ID="ID_519901327">
<node ID="ID_175624826" TREE_ID="ID_358465287"/>
<node ID="ID_859874830" TREE_ID="ID_27371128"/>
<node ID="ID_463380663" TREE_ID="ID_1894227213"/>
</node>
<node ID="ID_375393200" TREE_ID="ID_954082360"/>
</node>
<node ID="ID_1517731543" TREE_ID="ID_901589497">
<node ID="ID_16160882" TREE_ID="ID_1974569756"/>
<node ID="ID_842324164" TREE_ID="ID_1102427609"/>
<node ID="ID_80886333" TREE_ID="ID_875841496"/>
<node ID="ID_251172184" TREE_ID="ID_1373267741"/>
<node ID="ID_70735919" TREE_ID="ID_724037549">
<node ID="ID_1375509359" TREE_ID="ID_1920915762"/>
</node>
<node ID="ID_1901434888" TREE_ID="ID_336806259"/>
<node ID="ID_1724446815" TREE_ID="ID_217438721"/>
</node>
</node>
<node ID="ID_1863477623" TREE_ID="ID_500588608"/>
<node ID="ID_471356240" TREE_ID="ID_1578662227"/>
<node ID="ID_1881629934" TREE_ID="ID_1429450644"/>
<node ID="ID_1359661461" TREE_ID="ID_215867909">
<node ID="ID_1420332519" TREE_ID="ID_1542861629">
<node ID="ID_713809296" TREE_ID="ID_1083926711"/>
<node ID="ID_803729770" TREE_ID="ID_582455795"/>
</node>
<node ID="ID_1019006594" TREE_ID="ID_993481016">
<node ID="ID_1237240451" TREE_ID="ID_1018528693"/>
<node ID="ID_1297694260" TREE_ID="ID_1692675627"/>
</node>
</node>
<node ID="ID_1283665949" TREE_ID="ID_827749033"/>
</node>
</node>
<node TEXT="phases" ID="ID_1092139123" CREATED="1708211934725" MODIFIED="1708211947805">
<node TEXT="organize data" ID="ID_1401560774" CREATED="1708211947809" MODIFIED="1708211951793">
<node TEXT="why it&apos;s important" ID="ID_1522668316" CREATED="1708212495248" MODIFIED="1708212499409">
<node TEXT="how your data is classified and structured impact your findings" ID="ID_1229654575" CREATED="1708212499411" MODIFIED="1708212508035"/>
<node TEXT="you&apos;ll be able to capture or collect information you need" ID="ID_1678232615" CREATED="1708212514631" MODIFIED="1708212625400"/>
</node>
</node>
<node TEXT="format and adjust data" FOLDED="true" ID="ID_219202751" CREATED="1708211953388" MODIFIED="1708211963960">
<node TEXT="streamlines things and saves you time" ID="ID_1034527417" CREATED="1708212091396" MODIFIED="1708212109641"/>
<node TEXT="merge or split data sets" ID="ID_331691315" CREATED="1708446940994" MODIFIED="1708446955530">
<node TEXT="sheets" ID="ID_1695557505" CREATED="1708624835285" MODIFIED="1708624922882">
<node TEXT="&apos;=VLOOKUP(search_key, range, index, [is_sorted])" ID="ID_752938273" CREATED="1708624843499" MODIFIED="1708624901415"/>
</node>
</node>
<node TEXT="sort and filter data" FOLDED="true" ID="ID_1953544051" CREATED="1708212306587" MODIFIED="1708212323997">
<node TEXT="SQL" FOLDED="true" ID="ID_305147498" CREATED="1708369310618" MODIFIED="1708369313420">
<node TEXT="WHERE" FOLDED="true" ID="ID_357983221" CREATED="1708369314600" MODIFIED="1708369317419">
<node TEXT="filters" ID="ID_1879668137" CREATED="1708446276431" MODIFIED="1708446278906"/>
</node>
<node TEXT="ORDER BY" FOLDED="true" ID="ID_465048176" CREATED="1708446279926" MODIFIED="1708446283665">
<node TEXT="sorts" ID="ID_1254023767" CREATED="1708446283981" MODIFIED="1708446286137"/>
</node>
</node>
<node TEXT="spreadsheet" FOLDED="true" ID="ID_1399084045" CREATED="1708369304196" MODIFIED="1708369309033">
<node TEXT="sort sheet" FOLDED="true" ID="ID_603973325" CREATED="1708371601623" MODIFIED="1708371606211">
<node TEXT="search entire sheet by selected column" ID="ID_108990706" CREATED="1708371606215" MODIFIED="1708371617442"/>
</node>
<node TEXT="sort range" FOLDED="true" ID="ID_1450233754" CREATED="1708371620447" MODIFIED="1708371623629">
<node TEXT="sort selected range by customized criteria" ID="ID_1963718444" CREATED="1708371627988" MODIFIED="1708371640829"/>
</node>
<node TEXT="SORT function" FOLDED="true" ID="ID_1415559929" CREATED="1708369386811" MODIFIED="1708369390633">
<node ID="ID_5050298" CREATED="1708369395868" MODIFIED="1708369395868" LINK="https://www.coursera.org/learn/analyze-data/supplement/fyqMb/step-by-step-use-the-sort-function-in-spreadsheets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/analyze-data/supplement/fyqMb/step-by-step-use-the-sort-function-in-spreadsheets">Step-by-step: Use the SORT function in spreadsheets | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1998634073" CREATED="1708371344532" MODIFIED="1708371344532" LINK="https://support.google.com/docs/answer/3093197?hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.google.com/docs/answer/3093197?hl=en">FILTER function - Google Docs Editors Help</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Change types" ID="ID_300990007" CREATED="1708549051782" MODIFIED="1708549057594">
<node TEXT="spreadsheet" ID="ID_1979492289" CREATED="1708549373488" MODIFIED="1708549385385">
<node TEXT="create a drop-down list" ID="ID_1836591710" CREATED="1708621786767" MODIFIED="1708621791689">
<node TEXT="data validation" ID="ID_1754818061" CREATED="1708622022850" MODIFIED="1708622025463"/>
</node>
<node TEXT="convert units" ID="ID_789094277" CREATED="1708549389453" MODIFIED="1708549392997">
<node TEXT="text to number" ID="ID_413623655" CREATED="1708628304878" MODIFIED="1708628313131">
<node TEXT="&apos;=VALUE(&quot;123&quot;)" ID="ID_1068049846" CREATED="1708628389897" MODIFIED="1708628416652"/>
</node>
<node TEXT="&apos;=CONVERT(value, start_unit, end_unit)" ID="ID_828952573" CREATED="1708549536016" MODIFIED="1708549536016"/>
<node ID="ID_464564775" CREATED="1708549437463" MODIFIED="1708549437463" LINK="https://simplifysheets.com/functions/convert"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://simplifysheets.com/functions/convert">CONVERT Function – Google Sheets | Simplify Sheets</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="" ID="ID_1117139279" CREATED="1708628209521" MODIFIED="1708628209521"/>
</node>
<node TEXT="strings" ID="ID_384798531" CREATED="1708563141807" MODIFIED="1708563146423">
<node TEXT="LEN" ID="ID_541222521" CREATED="1708563151032" MODIFIED="1708563157414"/>
<node TEXT="LEFT(A2,2)" ID="ID_609667400" CREATED="1708563158248" MODIFIED="1708621986463">
<node ID="ID_1403887980" CREATED="1708621973328" MODIFIED="1708621973328" LINK="https://support.google.com/docs/answer/3094079?hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.google.com/docs/answer/3094079?hl=en">LEFT - Google Docs Editors Help</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="RIGHT" ID="ID_1317907744" CREATED="1708563165411" MODIFIED="1708563168349"/>
<node TEXT="FIND" ID="ID_1020207198" CREATED="1708563168367" MODIFIED="1708563171207">
<node ID="ID_1447566703" CREATED="1708563227473" MODIFIED="1708563227473" LINK="https://support.microsoft.com/en-us/office/find-findb-functions-c7912941-af2a-4bdf-a553-d0d89b0a0628"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.microsoft.com/en-us/office/find-findb-functions-c7912941-af2a-4bdf-a553-d0d89b0a0628">FIND, FINDB functions - Microsoft Support</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="string to numbers" ID="ID_7444852" CREATED="1708549059152" MODIFIED="1708549067909"/>
</node>
</node>
</node>
<node TEXT="get input from others" FOLDED="true" ID="ID_260186170" CREATED="1708211963977" MODIFIED="1708211967959">
<node TEXT="helpful when analyzing information and making decisions" ID="ID_1862295743" CREATED="1708212115000" MODIFIED="1708212124019"/>
<node TEXT="seek out others perspectives early" ID="ID_68545689" CREATED="1708212144811" MODIFIED="1708212199257"/>
</node>
<node TEXT="transform data by observing relationships between data points and making calculations" ID="ID_742367107" CREATED="1708211967977" MODIFIED="1708212206429"/>
</node>
<node TEXT="turn data into actionable information" ID="ID_1586441013" CREATED="1706739520841" MODIFIED="1706739527032"/>
<node TEXT="data exploration" ID="ID_286224889" CREATED="1706683228181" MODIFIED="1706683234302"/>
<node TEXT="visualization" ID="ID_984300173" CREATED="1706683234573" MODIFIED="1706683238238"/>
<node TEXT="analysis" ID="ID_1350592431" CREATED="1706683238541" MODIFIED="1706683241166"/>
</node>
<node TEXT="Glossary" FOLDED="true" ID="ID_1702832227" CREATED="1708210983229" MODIFIED="1708210985807">
<node TEXT="Absolute reference: A reference within a function that is locked so that rows and columns won’t change if the function is copied" ID="ID_215132286" CREATED="1708211045873" MODIFIED="1708211045873"/>
<node TEXT="Aggregation: The process of collecting or gathering many separate pieces into a whole" ID="ID_1796206433" CREATED="1708211045873" MODIFIED="1708211045873"/>
<node TEXT="Aliasing: Temporarily naming a table or column in a query to make it easier to read and write" ID="ID_1241037358" CREATED="1708211045878" MODIFIED="1708211045878"/>
<node TEXT="Array: A collection of values in spreadsheet cells" ID="ID_1019488318" CREATED="1708211045878" MODIFIED="1708211045878"/>
<node TEXT="Calculated field: A new field within a pivot table that carries out certain calculations based on the values of other fields" ID="ID_669974463" CREATED="1708211045880" MODIFIED="1708211045880"/>
<node TEXT="COUNT DISTINCT: A SQL function that only returns the distinct values in a specified range" ID="ID_1540933275" CREATED="1708211045880" MODIFIED="1708211045880"/>
<node TEXT="Data aggregation: The process of gathering data from multiple sources and combining it into a single, summarized collection" ID="ID_1320067032" CREATED="1708211045881" MODIFIED="1708211045881"/>
<node TEXT="Data security: Protecting data from unauthorized access or corruption by adopting safety measures" ID="ID_1913030468" CREATED="1708211045882" MODIFIED="1708211045882"/>
<node TEXT="Data validation process: The process of checking and rechecking the quality of data so that it is complete, accurate, secure and consistent" ID="ID_590149068" CREATED="1708211045882" MODIFIED="1708211045882"/>
<node TEXT="GROUP BY: A SQL clause that groups rows that have the same values from a table into summary rows" ID="ID_939827383" CREATED="1708211045885" MODIFIED="1708211045885"/>
<node TEXT="INNER JOIN : A SQL function that returns records with matching values in both tables" ID="ID_1609903549" CREATED="1708211045887" MODIFIED="1708211045887"/>
<node TEXT="JOIN: A SQL function that is used to combine rows from two or more tables based on a related column" ID="ID_124383165" CREATED="1708211045889" MODIFIED="1708211045889"/>
<node TEXT="LEFT JOIN: A SQL function that will return all the records from the left table and only the matching records from the right table" ID="ID_82631584" CREATED="1708211045891" MODIFIED="1708211045891"/>
<node TEXT="LIMIT: A SQL clause that specifies the maximum number of records returned in a query" ID="ID_651816728" CREATED="1708211045892" MODIFIED="1708211045892"/>
<node TEXT="MATCH: A spreadsheet function used to locate the position of a specific lookup value" ID="ID_381279494" CREATED="1708211045894" MODIFIED="1708211045894"/>
<node TEXT="Modulo: An operator (%) that returns the remainder when one number is divided by another" ID="ID_212674050" CREATED="1708211045894" MODIFIED="1708211045894"/>
<node TEXT="ORDER BY: A SQL clause that sorts results returned in a query" ID="ID_1539717583" CREATED="1708211045896" MODIFIED="1708211045896"/>
<node TEXT="OUTER JOIN: A SQL function that combines RIGHT and LEFT JOIN to return all matching records in both tables" ID="ID_499908109" CREATED="1708211045897" MODIFIED="1708211045897"/>
<node TEXT="Profit margin: A percentage that indicates how many cents of profit has been generated for each dollar of sale" ID="ID_1109578404" CREATED="1708211045899" MODIFIED="1708211045899"/>
<node TEXT="RIGHT JOIN: A SQL function that will return all records from the right table and only the matching records from the left." ID="ID_539783025" CREATED="1708211045900" MODIFIED="1708211045900"/>
<node TEXT="ROUND: A SQL function that returns a number rounded to a certain number of decimal places" ID="ID_1904378090" CREATED="1708211045901" MODIFIED="1708211045901"/>
<node TEXT="Subquery: A SQL query that is nested inside a larger query" ID="ID_1613891204" CREATED="1708211045902" MODIFIED="1708211045902"/>
<node TEXT="Summary table: A table used to summarize statistical information about data" ID="ID_382749980" CREATED="1708211045904" MODIFIED="1708211045904"/>
<node TEXT="SUMPRODUCT: A function that multiplies arrays and returns the sum of those products" ID="ID_84263930" CREATED="1708211045904" MODIFIED="1708211045904"/>
<node TEXT="Temporary table: A database table that is created and exists temporarily on a database server" ID="ID_871598295" CREATED="1708211045905" MODIFIED="1708211045905"/>
<node TEXT="Underscores: Lines used to underline words and connect text characters" ID="ID_737861398" CREATED="1708211045906" MODIFIED="1708211045906"/>
<node TEXT="VALUE: A spreadsheet function that converts a text string that represents a number to a numeric value" ID="ID_566922783" CREATED="1708211045907" MODIFIED="1708211045907"/>
</node>
</node>
</node>
<node TEXT="Step 5: Share" FOLDED="true" ID="ID_1589886195" CREATED="1706900372193" MODIFIED="1706900372193">
<node TEXT="Roadmap" ID="ID_643947180" CREATED="1712603606427" MODIFIED="1712603610651">
<node TEXT="Guiding questions" FOLDED="true" ID="ID_1081916915" CREATED="1712603615921" MODIFIED="1712603615921">
<node TEXT="What story does your data tell?" ID="ID_619220511" CREATED="1712603615921" MODIFIED="1712603615921"/>
<node TEXT="How do your findings relate to your original question?" ID="ID_787765735" CREATED="1712603615924" MODIFIED="1712603615924"/>
<node TEXT="Who is your audience? What is the best way to communicate with them?" ID="ID_450223914" CREATED="1712603615928" MODIFIED="1712603615928"/>
<node TEXT="Can data visualization help you share your findings?" ID="ID_842318700" CREATED="1712603615929" MODIFIED="1712603615929"/>
<node TEXT="Is your presentation accessible to your audience?" ID="ID_1569399310" CREATED="1712603615931" MODIFIED="1712603615931"/>
</node>
<node TEXT="Key tasks" FOLDED="true" ID="ID_1702737193" CREATED="1712603615931" MODIFIED="1712603615931">
<node TEXT="During the share phase, you’ll tell a story using data and communicate your findings." ID="ID_1564474452" CREATED="1712603615932" MODIFIED="1712603615932"/>
<node TEXT="Determine the best way to share your findings" ID="ID_732781555" CREATED="1712603615932" MODIFIED="1712603615932"/>
<node TEXT="Create effective data visualizations" ID="ID_713612006" CREATED="1712603615933" MODIFIED="1712603615933"/>
<node TEXT="Present your findings" ID="ID_1183728625" CREATED="1712603615934" MODIFIED="1712603615934"/>
<node TEXT="Ensure your work is accessible to your audience" ID="ID_136872960" CREATED="1712603615934" MODIFIED="1712603615934"/>
</node>
</node>
<node TEXT="summarizing results" FOLDED="true" ID="ID_77594119" CREATED="1706900997590" MODIFIED="1706901001648">
<node TEXT="Everyone shares their results differently so be sure to summarize your results with clear and enticing visuals of your analysis using data via tools like graphs or dashboards. This is your chance to show the stakeholders you have solved their problem and how you got there. Sharing will certainly help your team:" FOLDED="true" ID="ID_580503637" CREATED="1706900372194" MODIFIED="1706900372194">
<node TEXT="Make better decisions" ID="ID_117138593" CREATED="1706900372195" MODIFIED="1706900372195"/>
<node TEXT="Make more informed decisions" ID="ID_1978266418" CREATED="1706900372196" MODIFIED="1706900372196"/>
<node TEXT="Lead to stronger outcomes" ID="ID_1101864733" CREATED="1706900372197" MODIFIED="1706900372197"/>
<node TEXT="Successfully communicate your findings" ID="ID_93942090" CREATED="1706900372197" MODIFIED="1706900372197"/>
</node>
<node TEXT="Questions to ask yourself in this step:" ID="ID_500014850" CREATED="1706900372197" MODIFIED="1706900372197">
<node TEXT="How can I make what I present to the stakeholders engaging and easy to understand?" ID="ID_1343589672" CREATED="1706900372199" MODIFIED="1706900372199"/>
<node TEXT="What would help me understand this if I were the listener?" ID="ID_935226681" CREATED="1706900372199" MODIFIED="1706900372199"/>
</node>
</node>
<node TEXT="communicating and interpreting results" ID="ID_27562187" CREATED="1706683243045" MODIFIED="1706683257439"/>
<node TEXT="Tools" ID="ID_1804749922" CREATED="1709356118892" MODIFIED="1709356123424"/>
<node TEXT="Share Data Through The Art Of Visualization (6)" ID="ID_1739188624" CREATED="1709241925806" MODIFIED="1709241960806">
<node TEXT="glossary" FOLDED="true" ID="ID_165555028" CREATED="1709323028079" MODIFIED="1709323030873">
<node TEXT="Alternative text: Text that provides an alternative to non-text content, such as images and videos" ID="ID_927882837" CREATED="1709323032339" MODIFIED="1709323032339"/>
<node TEXT="Annotation: Text that briefly explains data or helps focus the audience on a particular aspect of the data in a visualization" ID="ID_1903813626" CREATED="1709323032339" MODIFIED="1709323032339"/>
<node TEXT="Area chart: A data visualization that uses individual data points for a changing variable connected by a continuous line with a filled in area underneath" ID="ID_174302025" CREATED="1709323032341" MODIFIED="1709323032341"/>
<node TEXT="AVERAGEIF: A spreadsheet function that returns the average of all cell values from a given range that meet a specified condition" ID="ID_479269819" CREATED="1709323032342" MODIFIED="1709323032342"/>
<node TEXT="Balance: The design principle of creating aesthetic appeal and clarity in a data visualization by evenly distributing visual elements" ID="ID_357381844" CREATED="1709323032343" MODIFIED="1709323032343"/>
<node TEXT="Bar graph: A data visualization that uses size to contrast and compare two or more values" ID="ID_229010445" CREATED="1709323032343" MODIFIED="1709323032343"/>
<node TEXT="Box plot: A data visualization that displays the distribution of values along an x-axis" ID="ID_138574964" CREATED="1709323032344" MODIFIED="1709323032344"/>
<node TEXT="Bubble chart: A data visualization that displays individual data points as bubbles,  comparing numeric values by their relative size" ID="ID_755215283" CREATED="1709323032345" MODIFIED="1709323032345"/>
<node TEXT="Bullet graph: A data visualization that displays data as a horizontal bar chart moving toward a desired value" ID="ID_157997513" CREATED="1709323032345" MODIFIED="1709323032345"/>
<node TEXT="Calculus: A branch of mathematics that involves the study of rates of change and the changes between values that are related by a function" ID="ID_1628396256" CREATED="1709323032347" MODIFIED="1709323032347"/>
<node TEXT="Causation: When an action directly leads to an outcome, such as a cause-effect relationship" ID="ID_1762375969" CREATED="1709323032347" MODIFIED="1709323032347"/>
<node TEXT="Channel: A visual aspect or variable that represents characteristics of the data in a visualization" ID="ID_369824688" CREATED="1709323032349" MODIFIED="1709323032349"/>
<node TEXT="Chart: A graphical representation of data from a worksheet" ID="ID_1792141125" CREATED="1709323032350" MODIFIED="1709323032350"/>
<node TEXT="Circle view: A data visualization that shows comparative strength in data" ID="ID_1736125927" CREATED="1709323032350" MODIFIED="1709323032350"/>
<node TEXT="Cluster: A collection of data points on a data visualization with similar values" ID="ID_1190664198" CREATED="1709323032351" MODIFIED="1709323032351"/>
<node TEXT="Column chart: A data visualization that uses individual data points for a changing variable, represented as vertical columns" ID="ID_898936495" CREATED="1709323032351" MODIFIED="1709323032351"/>
<node TEXT="Combo chart: A data visualization that combines more than one visualization type" ID="ID_226645012" CREATED="1709323032352" MODIFIED="1709323032352"/>
<node TEXT="CONVERT: A SQL function that changes the unit of measurement of a value in data" ID="ID_1997678564" CREATED="1709323032352" MODIFIED="1709323032352"/>
<node TEXT="Correlation: The measure of the degree to which two variables change in relationship to each other" ID="ID_1335231111" CREATED="1709323032353" MODIFIED="1709323032353"/>
<node TEXT="CREATE TABLE: A SQL clause that adds a temporary table to a database that can be used by multiple people" ID="ID_1720950248" CREATED="1709323032354" MODIFIED="1709323032354"/>
<node TEXT="Dashboard: A tool that organizes information from multiple data sets into one central location for tracking, analysis, and simple visualization through tables, charts and graphs" FOLDED="true" ID="ID_79241099" CREATED="1710283486884" MODIFIED="1710283519303">
<node TEXT="constantly monitor live data" ID="ID_126196483" CREATED="1710283559068" MODIFIED="1710283564680"/>
<node TEXT="when to use" FOLDED="true" ID="ID_1597927815" CREATED="1710347558297" MODIFIED="1710347562510">
<node TEXT="information is updated frequently" ID="ID_620381142" CREATED="1710347569265" MODIFIED="1710347574540"/>
</node>
</node>
<node TEXT="Data composition: The process of combining the individual parts in a visualization and displaying them together as a whole" FOLDED="true" ID="ID_1951664597" CREATED="1709323032355" MODIFIED="1709323032355">
<node TEXT="example charts" FOLDED="true" ID="ID_44007883" CREATED="1709330266283" MODIFIED="1709330270103">
<node TEXT="stack bars" ID="ID_1559391352" CREATED="1709330271937" MODIFIED="1709330275285"/>
<node TEXT="doughnuts" ID="ID_1140920702" CREATED="1709330275297" MODIFIED="1709330278480"/>
<node TEXT="stacked areas" ID="ID_1531672838" CREATED="1709330278493" MODIFIED="1709330281695"/>
<node TEXT="pie chart" ID="ID_1489666270" CREATED="1709330281708" MODIFIED="1709330315127"/>
<node TEXT="tree maps" ID="ID_1877555662" CREATED="1709330284296" MODIFIED="1709330289097"/>
</node>
</node>
<node TEXT="Data storytelling: Communicating the meaning of a dataset with visuals and a narrative that are customized for an audience" ID="ID_1379404230" CREATED="1709323032355" MODIFIED="1709323032355"/>
<node TEXT="Decision tree: A tool that helps analysts make decisions about critical features of a visualization" ID="ID_747089775" CREATED="1709323032356" MODIFIED="1709323032356"/>
<node TEXT="Density map: A data visualization that represents concentrations, with color representing the number or frequency of data points in a given area on a map" ID="ID_574616515" CREATED="1709323032357" MODIFIED="1709323032357"/>
<node TEXT="Design thinking: A process used to solve complex problems in a user-centric way" ID="ID_976152291" CREATED="1709323032357" MODIFIED="1709323032357"/>
<node TEXT="Distribution graph: A data visualization that displays the frequency of various outcomes in a sample" ID="ID_1021399972" CREATED="1709323032358" MODIFIED="1709323032358"/>
<node TEXT="Diverging color palette: A color theme that displays two ranges of data values using two different hues, with color intensity representing the magnitude of the values" ID="ID_513942502" CREATED="1709323032359" MODIFIED="1709323032359"/>
<node TEXT="Donut chart: A data visualization where segments of a ring represent data values adding up to a whole" ID="ID_1301341017" CREATED="1709323032359" MODIFIED="1709323032359"/>
<node TEXT="DROP TABLE: A SQL clause that removes a temporary table from a database" ID="ID_795760271" CREATED="1709323032359" MODIFIED="1709323032359"/>
<node TEXT="Dynamic visualizations: Data visualizations that are interactive or change over time" ID="ID_1315418791" CREATED="1709323032360" MODIFIED="1709323032360"/>
<node TEXT="Emphasis: The design principle of arranging visual elements to focus the audience’s attention on important information in a data visualization" ID="ID_950613764" CREATED="1709323032361" MODIFIED="1709323032361"/>
<node TEXT="Engagement: Capturing and holding someone’s interest and attention during a data presentation" ID="ID_468934523" CREATED="1709323032362" MODIFIED="1709323032362"/>
<node TEXT="Filled map: A data visualization that colors areas in a map based on measurements or dimensions" ID="ID_1626847726" CREATED="1709323032364" MODIFIED="1709323032364"/>
<node TEXT="Framework: The context a presentation needs to create logical connections that tie back to the business task and metrics" ID="ID_1151663988" CREATED="1709323032365" MODIFIED="1709323032365"/>
<node TEXT="Gantt chart: A data visualization that displays the duration of events or activities on a timeline" ID="ID_507449219" CREATED="1709323032366" MODIFIED="1709323032366"/>
<node TEXT="Gauge chart: A data visualization that shows a single result within a progressive range of values" ID="ID_22766769" CREATED="1709323032366" MODIFIED="1709323032366"/>
<node TEXT="HAVING: A SQL clause that adds a filter to a query instead of the underlying table that can only be used with aggregate functions" ID="ID_1271267414" CREATED="1709323032368" MODIFIED="1709323032368"/>
<node TEXT="Headline: Text at the top of a visualization that communicates the data being presented" ID="ID_1983831617" CREATED="1709323032368" MODIFIED="1709323032368"/>
<node TEXT="Heat map: A data visualization that uses color contrast to compare categories in a dataset" ID="ID_1350064989" CREATED="1709323032369" MODIFIED="1709323032369"/>
<node TEXT="Highlight table: A data visualization that uses conditional formatting and color on a table" ID="ID_432477455" CREATED="1709323032370" MODIFIED="1709323032370"/>
<node TEXT="Histogram: A data visualization that shows how often data values fall into certain ranges" ID="ID_1936118533" CREATED="1709323032370" MODIFIED="1709323032370"/>
<node TEXT="Inner query: A SQL subquery that is inside of another SQL statement" ID="ID_1042397588" CREATED="1709323032371" MODIFIED="1709323032371"/>
<node TEXT="Label: Text in a visualization that identifies a value or describes a scale" ID="ID_1620439831" CREATED="1709323032373" MODIFIED="1709323032373"/>
<node TEXT="Legend: A tool that identifies the meaning of various elements in a data visualization" ID="ID_1103665269" CREATED="1709323032374" MODIFIED="1709323032374"/>
<node TEXT="Line graph: A data visualization that uses one or more lines to display shifts or changes in data over time" ID="ID_156165552" CREATED="1709323032374" MODIFIED="1709323032374"/>
<node TEXT="Live data: Data that is automatically updated" ID="ID_1539039289" CREATED="1709323032375" MODIFIED="1709323032375"/>
<node TEXT="Map: A data visualization that organizes data geographically" ID="ID_897772584" CREATED="1709323032376" MODIFIED="1709323032376"/>
<node TEXT="Mark: A visual object in a data visualization such as a point, line, or shape" ID="ID_52689283" CREATED="1709323032377" MODIFIED="1709323032377"/>
<node TEXT="MAXIFS: A spreadsheet function that returns the maximum value from a given range that meets a specified condition" ID="ID_69816549" CREATED="1709323032378" MODIFIED="1709323032378"/>
<node TEXT="McCandless Method: A method for presenting data visualizations that moves from general to specific information" ID="ID_1749209865" CREATED="1709323032378" MODIFIED="1709323032378"/>
<node TEXT="MINIFS: A spreadsheet function that returns the minimum value from a given range that meets a specified condition" ID="ID_805943454" CREATED="1709323032379" MODIFIED="1709323032379"/>
<node TEXT="Movement: The design principle of arranging visual elements to guide the audience’s eyes from one part of a data visualization to another" ID="ID_1647958459" CREATED="1709323032380" MODIFIED="1709323032380"/>
<node TEXT="Narrative: (Refer to story)" ID="ID_570126563" CREATED="1709323032381" MODIFIED="1709323032381"/>
<node TEXT="Outer query: A SQL statement containing a subquery" ID="ID_1221393019" CREATED="1709323032383" MODIFIED="1709323032383"/>
<node TEXT="Packed bubble chart: A data visualization that displays data in clustered circles" ID="ID_728415842" CREATED="1709323032384" MODIFIED="1709323032384"/>
<node TEXT="Pattern: The design principle of using similar visual elements to demonstrate trends and relationships in a data visualization" ID="ID_780365616" CREATED="1709323032384" MODIFIED="1709323032384"/>
<node TEXT="Pie chart: A data visualization that uses segments of a circle to represent the proportions of each data category compared to the whole" ID="ID_638060626" CREATED="1709323032385" MODIFIED="1709323032385"/>
<node TEXT="Pre-attentive attributes: The elements of a data visualization that an audience recognizes automatically without conscious effort" ID="ID_188811240" CREATED="1709323032386" MODIFIED="1709323032386"/>
<node TEXT="Proportion: The design principle of using the relative size and arrangement of visual elements to demonstrate information in a data visualization" ID="ID_1080263191" CREATED="1709323032386" MODIFIED="1709323032386"/>
<node TEXT="R: A programming language used for statistical analysis, visualization, and other data analysis" ID="ID_1889410896" CREATED="1709323032388" MODIFIED="1709323032388"/>
<node TEXT="Ranking: A system to position values of a dataset within a scale of achievement or status" ID="ID_970802101" CREATED="1709323032388" MODIFIED="1709323032388"/>
<node TEXT="Relativity: The process of considering observations in relation or proportion to something else" ID="ID_1348349258" CREATED="1709323032389" MODIFIED="1709323032389"/>
<node TEXT="Repetition: The design principle of repeating visual elements to demonstrate meaning in a data visualization" ID="ID_1351825750" CREATED="1709323032389" MODIFIED="1709323032389"/>
<node TEXT="Rhythm: The design principle of creating movement and flow in a data visualization to engage an audience" ID="ID_1121771473" CREATED="1709323032390" MODIFIED="1709323032390"/>
<node TEXT="Scatterplot: A data visualization that represents relationships between different variables with individual data points without a connecting line" ID="ID_1920494055" CREATED="1709323032391" MODIFIED="1709323032391"/>
<node TEXT="SELECT INTO: A SQL clause that copies data from one table into a temporary table without adding the new table to the database" ID="ID_1383954731" CREATED="1709323032392" MODIFIED="1709323032392"/>
<node TEXT="Spotlightling: Scanning through data to quickly identify the most important insights" FOLDED="true" ID="ID_1776741095" CREATED="1709323032394" MODIFIED="1709323032394">
<node TEXT="write each insight from your analysis on a piece of paper" ID="ID_477920391" CREATED="1710282178872" MODIFIED="1710282206478"/>
<node TEXT="look for broad universal ideas and messages" ID="ID_1360657273" CREATED="1710282207888" MODIFIED="1710282251270"/>
<node TEXT="find ideas or concepts that keep popping up again and again or numbers and words that are repeated often" ID="ID_288556203" CREATED="1710282251293" MODIFIED="1710282264093"/>
<node TEXT="highlight these items and group them together on your whiteboard" ID="ID_111863345" CREATED="1710282265500" MODIFIED="1710282391532"/>
</node>
<node TEXT="Sort range: A spreadsheet menu function that sorts a specified range and preserves the cells outside the range" ID="ID_995567328" CREATED="1709323032392" MODIFIED="1709323032392"/>
<node TEXT="Sort sheet: A spreadsheet menu function that sorts all data by the ranking of a specific sorted column and keeps data together across rows" ID="ID_658575626" CREATED="1709323032394" MODIFIED="1709323032394"/>
<node TEXT="Static data: Data that doesn’t change once it has been recorded" ID="ID_848511771" CREATED="1709323032396" MODIFIED="1709323032396"/>
<node TEXT="Static visualization: A data visualization that does not change over time unless it is edited" ID="ID_1660957123" CREATED="1709323032397" MODIFIED="1709323032397"/>
<node TEXT="Statistics: The study of how to collect, analyze, summarize, and present data" ID="ID_325769418" CREATED="1709323032398" MODIFIED="1709323032398"/>
<node TEXT="Story: The narrative of a data presentation that makes it meaningful and interesting" ID="ID_1935554965" CREATED="1709323032398" MODIFIED="1709323032398"/>
<node TEXT="Subtitle: Text that supports a headline by adding context and description" ID="ID_264332266" CREATED="1709323032399" MODIFIED="1709323032399"/>
<node TEXT="Symbol map: A data visualization that displays a mark over a given longitude and latitude" ID="ID_1813186996" CREATED="1709323032400" MODIFIED="1709323032400"/>
<node TEXT="Tableau: A business intelligence and analytics platform that helps people visualize, understand, and make decisions with data" ID="ID_1828268454" CREATED="1709323032401" MODIFIED="1709323032401"/>
<node TEXT="Unity: The design principle of using visual elements that complement each other to create aesthetic appeal and clarity in a data visualization" ID="ID_937375240" CREATED="1709323032402" MODIFIED="1709323032402"/>
<node TEXT="Variety: The design principle of using different kinds of visual elements in a data visualization to engage an audience" ID="ID_424349533" CREATED="1709323032403" MODIFIED="1709323032403"/>
<node TEXT="Visual form: The appearance of a data visualization that gives it structure and aesthetic appeal" ID="ID_1379475671" CREATED="1709323032404" MODIFIED="1709323032404"/>
<node TEXT="WITH: A SQL clause that creates a temporary table that can be queried multiple times" ID="ID_656467329" CREATED="1709323032406" MODIFIED="1709323032406"/>
<node TEXT="X-axis: The horizontal line of a graph usually placed at the bottom, which is often used to represent time scales and discrete categories" ID="ID_1871065225" CREATED="1709323032408" MODIFIED="1709323032408"/>
<node TEXT="Y-axis: The vertical line of a graph usually placed to the left, which is often used to represent frequencies and other numerical variables" ID="ID_54835842" CREATED="1709323032409" MODIFIED="1709323032409"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_842876294" CREATED="1709323022263" MODIFIED="1709323025702">
<node ID="ID_256855294" CREATED="1709323123529" MODIFIED="1709323123529" LINK="https://www.coursera.org/learn/visualize-data/resources/7obSI"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/visualize-data/resources/7obSI">Share Data Through the Art of Visualization - Home - Week week | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="successful visualization" FOLDED="true" ID="ID_883099533" CREATED="1709241936402" MODIFIED="1709241941050">
<node TEXT="png_7431072067061221446.png" ID="ID_879706703" CREATED="1709241944066" MODIFIED="1709241944066">
<hook URI="Google%20Data%20Analytics%20Certificate_files/png_7431072067061221446.png" SIZE="0.23510972" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Visualize data (1)" FOLDED="true" ID="ID_1115015974" CREATED="1709318098367" MODIFIED="1709318125101">
<node TEXT="Understand data visualization" FOLDED="true" ID="ID_945854355" CREATED="1709320780068" MODIFIED="1709320785917">
<node TEXT="The steps of the Design Thinking process are:" FOLDED="true" ID="ID_504811851" CREATED="1709322358142" MODIFIED="1709322358142">
<node TEXT="• Empathize: Think about the emotions and needs of the target audience." ID="ID_853787666" CREATED="1709322358142" MODIFIED="1709322358142"/>
<node TEXT="• Define: Understand the audience’s needs, problems, and insights." ID="ID_721229015" CREATED="1709322358144" MODIFIED="1709322358144"/>
<node TEXT="• Ideate: Use your findings from the previous phases to begin to create data visualizations." ID="ID_1043192295" CREATED="1709322358146" MODIFIED="1709322358146"/>
<node TEXT="• Prototype: Start putting it all together. In this case, you can put your findings into  a presentation or dashboard." ID="ID_1115076944" CREATED="1709322358147" MODIFIED="1709322358147"/>
<node TEXT="• Test: Check that your prototype is effective. In this case, you can show your visualizations to team members before the presentation." ID="ID_1113112391" CREATED="1709322358148" MODIFIED="1709322358148"/>
</node>
</node>
<node TEXT="Design data visualizations" FOLDED="true" ID="ID_1877299097" CREATED="1709320773508" MODIFIED="1709320778934">
<node TEXT="reference" FOLDED="true" ID="ID_259419200" CREATED="1710264879594" MODIFIED="1710264881603">
<node ID="ID_1069724591" CREATED="1709330416332" MODIFIED="1709330416332" LINK="https://www.kdnuggets.com/2021/02/telling-great-data-story-visualization-decision-tree.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.kdnuggets.com/2021/02/telling-great-data-story-visualization-decision-tree.html">Telling a Great Data Story: A Visualization Decision Tree - KDnuggets</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="identify appropriate visualization" FOLDED="true" ID="ID_1485058080" CREATED="1710264701519" MODIFIED="1710264724309">
<node TEXT="understand what kind of data you&apos;re presenting" FOLDED="true" ID="ID_282262776" CREATED="1710264704821" MODIFIED="1710264732411">
<node TEXT="frequency" ID="ID_206454985" CREATED="1710264748483" MODIFIED="1710264752571"/>
<node TEXT="changes over time" ID="ID_972884078" CREATED="1710264752589" MODIFIED="1710264755973"/>
<node TEXT="categorical comparisons" ID="ID_1317459737" CREATED="1710264755988" MODIFIED="1710264760775"/>
<node TEXT="others ." ID="ID_983542075" CREATED="1710264760790" MODIFIED="1710264767421"/>
</node>
</node>
<node TEXT="determine what your audience needs to see to understand your analysis" ID="ID_1378439362" CREATED="1710264717322" MODIFIED="1710264796017"/>
<node TEXT="find which graph or chart style fits your goal" ID="ID_26178032" CREATED="1710264815982" MODIFIED="1710264821371"/>
<node TEXT="utilize the visual design guidelines to create an accessible and aesthetically pleasing data visualization" FOLDED="true" ID="ID_640583821" CREATED="1710264821390" MODIFIED="1710264840207">
<node ID="ID_329405631" CREATED="1710264912665" MODIFIED="1710264912665"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: normal; font-family: unset"><font face="unset">Five-second rule:</font></strong>&#xa0;A data visualization should be <strong style="font-weight: normal; font-family: unset"><font face="unset">clear, effective, and convincing</font></strong>&#xa0;enough to be absorbed in five seconds or less.</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_246054203" CREATED="1710264912668" MODIFIED="1710264912668"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: normal; font-family: unset"><font face="unset">Color contrast:</font></strong>&#xa0;Graphs and charts should use a <strong style="font-weight: normal; font-family: unset"><font face="unset">diverging color palette</font></strong>&#xa0;to show contrast between elements.</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="diverging color palette: displays two ranges of values using color intensity to show the magnitude of the number and the actual color (hue) to show which range the numbers are from" ID="ID_1780011048" CREATED="1710266366583" MODIFIED="1710266481283"/>
</node>
<node ID="ID_1824309356" CREATED="1710264912675" MODIFIED="1710264912675"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: normal; font-family: unset"><font face="unset">Conventions and expectations:</font></strong>&#xa0;Visuals and their organization should align with<strong style="font-weight: normal; font-family: unset"><font face="unset">&#xa0;audience expectations </font></strong>and <strong style="font-weight: normal; font-family: unset"><font face="unset">cultural conventions</font></strong>. For example, if the majority of your audience associates green with a positive concept and red with a negative one, your visualization should reflect this.</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1335324955" CREATED="1710264912679" MODIFIED="1710264912679"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: normal; font-family: unset"><font face="unset">Minimal labels:</font></strong>&#xa0;Titles, axes, and annotations should use as <strong style="font-weight: normal; font-family: unset"><font face="unset">few labels</font></strong>&#xa0;as it takes to make sense. Having too many labels makes your graph or chart too busy. It takes up too much space and prevents the labels from being shown clearly.</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_911897698" CREATED="1710264912685" MODIFIED="1710264963913" LINK="https://www.coursera.org/learn/visualize-data/supplement/IcuWb/dac6m1l4r2-designing-a-chart-in-60-minutes"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
      <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
        For a refresher, you can refer back to the readings from this section. Check out<a target="_blank" href="https://www.coursera.org/learn/visualize-data/supplement/IcuWb/dac6m1l4r2-designing-a-chart-in-60-minutes" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>&#xa0;Designing a chart in 60 minutes</u></font></a>,<a target="_blank" href="https://www.coursera.org/learn/visualize-data/supplement/j9Wdl/dac6m1l4-the-wonderful-world-of-visualizations" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>&#xa0;The wonderful world of visualizations</u></font></a>, and<a target="_blank" href="https://www.coursera.org/learn/visualize-data/supplement/bDdpK/dac6m2l2r3-visualizations-in-spreadsheets" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>&#xa0;Visualizations in spreadsheets and Tableau</u></font></a>.
      </p>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Data composition: The process of combining the individual parts in a visualization and displaying them together as a whole" FOLDED="true" ID="ID_1209331102" CREATED="1709323032355" MODIFIED="1709323032355">
<node TEXT="example charts" FOLDED="true" ID="ID_457607286" CREATED="1709330266283" MODIFIED="1709330270103">
<node TEXT="stack bars" ID="ID_351065441" CREATED="1709330271937" MODIFIED="1709330275285"/>
<node TEXT="doughnuts" ID="ID_856870219" CREATED="1709330275297" MODIFIED="1709330278480"/>
<node TEXT="stacked areas" ID="ID_897836528" CREATED="1709330278493" MODIFIED="1709330281695"/>
<node TEXT="pie chart" ID="ID_640293800" CREATED="1709330281708" MODIFIED="1709330315127"/>
<node TEXT="tree maps" ID="ID_358922334" CREATED="1709330284296" MODIFIED="1709330289097"/>
</node>
</node>
<node TEXT="Visualization considerations" FOLDED="true" ID="ID_1993831965" CREATED="1709320761477" MODIFIED="1709320768866">
<node TEXT="Components" FOLDED="true" ID="ID_1004869708" CREATED="1709322863070" MODIFIED="1709322866275">
<node ID="ID_1168925258" CREATED="1709322888478" MODIFIED="1709322888478"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/6%20Share%20Data%20Through%20The%20Art%20Of%20Visualization/M1%20Visualize%20data.one#Pro tips for highlighting key information&amp;section-id={782CF559-7A93-41AB-91B2-0C5111FC8DA7}&amp;page-id={3F4DD5BE-9969-4C32-B2D8-205EB8743751}&amp;end">Pro tips for highlighting key information</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%286%20Share%20Data%20Through%20The%20Art%20Of%20Visualization%2FM1%20Visualize%20data.one%7C782CF559-7A93-41AB-91B2-0C5111FC8DA7%2FPro%20tips%20for%20highlighting%20key%20information%7C3F4DD5BE-9969-4C32-B2D8-205EB8743751%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
<node TEXT="headlines" ID="ID_1202765480" CREATED="1709322866277" MODIFIED="1709322869656"/>
<node TEXT="subtitles" ID="ID_93508789" CREATED="1709322869670" MODIFIED="1709322872258"/>
<node TEXT="labels" ID="ID_1729897144" CREATED="1709322872274" MODIFIED="1709322874858"/>
<node TEXT="annotations" ID="ID_890816511" CREATED="1709322874872" MODIFIED="1709322878478"/>
</node>
<node TEXT="Accessibility" FOLDED="true" ID="ID_618395215" CREATED="1709318373554" MODIFIED="1709318377790">
<node TEXT="making sure that you are creating data visualizations that anyone can interact with" ID="ID_568346627" CREATED="1709318381153" MODIFIED="1709318399285"/>
<node TEXT="Ways to make data visualizations accessible" FOLDED="true" ID="ID_1302347657" CREATED="1709318195130" MODIFIED="1709318201150">
<node TEXT="labeling" ID="ID_209576593" CREATED="1709318201151" MODIFIED="1709318204340"/>
<node TEXT="text alternatives" ID="ID_379216559" CREATED="1709318204352" MODIFIED="1709318207132"/>
<node TEXT="textbased format" ID="ID_1930646391" CREATED="1709318207146" MODIFIED="1709318210933"/>
<node TEXT="distinguishing" ID="ID_1030288571" CREATED="1709318210947" MODIFIED="1709318222353"/>
<node TEXT="simplify" FOLDED="true" ID="ID_368284525" CREATED="1709318213358" MODIFIED="1709318216184">
<node TEXT="overly complicated visualizations turnoff the audience" ID="ID_1517691419" CREATED="1709318237127" MODIFIED="1709318250784"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Create data visualizations with Tableau (2)" FOLDED="true" ID="ID_231499698" CREATED="1709318126352" MODIFIED="1709318165166">
<node ID="ID_1593996617" TREE_ID="ID_1168616332">
<node ID="ID_1105385321" TREE_ID="ID_1150468520">
<node ID="ID_38294288" TREE_ID="ID_323098144"/>
<node ID="ID_592946066" TREE_ID="ID_253106479"/>
</node>
<node ID="ID_444803631" TREE_ID="ID_1332739621">
<node ID="ID_246119242" TREE_ID="ID_619073993">
<node ID="ID_581971061" TREE_ID="ID_1662174576">
<node ID="ID_1211977100" TREE_ID="ID_331183193"/>
<node ID="ID_755055840" TREE_ID="ID_718295481"/>
<node ID="ID_1526096406" TREE_ID="ID_457326311"/>
<node ID="ID_1748266724" TREE_ID="ID_1071692303"/>
<node ID="ID_1561253461" TREE_ID="ID_226117959"/>
<node ID="ID_175513709" TREE_ID="ID_1511775363"/>
<node ID="ID_1528033536" TREE_ID="ID_1415894514"/>
</node>
<node ID="ID_580364731" TREE_ID="ID_704927741">
<node ID="ID_1946325695" TREE_ID="ID_473087716">
<node ID="ID_63048920" TREE_ID="ID_747844228"/>
</node>
<node ID="ID_1022616652" TREE_ID="ID_1278216140">
<node ID="ID_863022618" TREE_ID="ID_251783177"/>
<node ID="ID_1323047335" TREE_ID="ID_1836806828"/>
</node>
<node ID="ID_977393568" TREE_ID="ID_97715143">
<node ID="ID_1253473805" TREE_ID="ID_1254119678"/>
<node ID="ID_215335810" TREE_ID="ID_1747199285"/>
<node ID="ID_688653703" TREE_ID="ID_1066336625"/>
</node>
</node>
<node ID="ID_1171622634" TREE_ID="ID_1893320076">
<node ID="ID_1308794633" TREE_ID="ID_681419623"/>
<node ID="ID_1136151560" TREE_ID="ID_853298096"/>
<node ID="ID_263781673" TREE_ID="ID_1709612575"/>
<node ID="ID_782304590" TREE_ID="ID_1020170649"/>
<node ID="ID_1892764600" TREE_ID="ID_1543436466"/>
</node>
<node ID="ID_1361794422" TREE_ID="ID_1359534230">
<node ID="ID_1524272187" TREE_ID="ID_758808822">
<node ID="ID_1764891261" TREE_ID="ID_1241192197"/>
</node>
<node ID="ID_1108852333" TREE_ID="ID_1761367350">
<node ID="ID_1163562287" TREE_ID="ID_477609382"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Craft data stories (3)" FOLDED="true" ID="ID_255018549" CREATED="1709318149573" MODIFIED="1709318159946">
<node TEXT="3 data storytelling steps" FOLDED="true" ID="ID_312655724" CREATED="1710277081408" MODIFIED="1710277091218">
<node TEXT="engage your audience" FOLDED="true" ID="ID_10025285" CREATED="1710277094213" MODIFIED="1710277097598">
<node ID="ID_1946498018" TREE_ID="ID_468934523"/>
<node TEXT="know your audience" FOLDED="true" ID="ID_1106927004" CREATED="1710281962474" MODIFIED="1710281966900">
<node TEXT="understand" FOLDED="true" ID="ID_1697827013" CREATED="1710281972111" MODIFIED="1710282546343">
<node TEXT="their point of view" ID="ID_993577685" CREATED="1710282546343" MODIFIED="1710282546345"/>
<node TEXT="how your data project might affect them" ID="ID_553471080" CREATED="1710281976889" MODIFIED="1710281982486"/>
<node TEXT="what internal stakeholders want from the project" ID="ID_983127739" CREATED="1710282554073" MODIFIED="1710282563290"/>
</node>
<node TEXT="questions" FOLDED="true" ID="ID_540412897" CREATED="1710281984094" MODIFIED="1710281986471">
<node TEXT="what role does this audience play?" ID="ID_1104861966" CREATED="1710281986474" MODIFIED="1710281999859"/>
<node TEXT="what is a stake in the project?" ID="ID_1329017173" CREATED="1710281999879" MODIFIED="1710282004265"/>
<node TEXT="what do they hope to get from the data insights I deliver?" ID="ID_112155977" CREATED="1710282004287" MODIFIED="1710282010883"/>
</node>
</node>
<node TEXT="seek to capture the audiences attention on an intellectual and emotional level" FOLDED="true" ID="ID_616145655" CREATED="1710282633672" MODIFIED="1710282649276">
<node TEXT="make eye contact" ID="ID_13019564" CREATED="1710436912761" MODIFIED="1710436917139"/>
<node TEXT="reduce nervous habits" ID="ID_626909820" CREATED="1710436917158" MODIFIED="1710436920939"/>
<node TEXT="pause intentionally" ID="ID_1237130040" CREATED="1710436920954" MODIFIED="1710436923612"/>
</node>
<node TEXT="keep in mind" FOLDED="true" ID="ID_914697214" CREATED="1710436153821" MODIFIED="1710436166766">
<node TEXT="your audience won&apos;t always get the steps you took to reach conclusion" ID="ID_363141840" CREATED="1710436166768" MODIFIED="1710436195236"/>
</node>
</node>
<node TEXT="create compelling visuals" FOLDED="true" ID="ID_1363335616" CREATED="1710277097615" MODIFIED="1710277100600">
<node TEXT="visuals should be clear and able to stand on their own" ID="ID_1122735421" CREATED="1710282584678" MODIFIED="1710282591685"/>
<node TEXT="show the story of your data, not just tell it" FOLDED="true" ID="ID_1729493926" CREATED="1710277274609" MODIFIED="1710277280849">
<node TEXT="take your audience on a journey of how the data changed over time" ID="ID_1830614412" CREATED="1710277318426" MODIFIED="1710277329632"/>
<node TEXT="or highlight the meaning behind the numbers at a glance" ID="ID_982800784" CREATED="1710277299037" MODIFIED="1710282690302"/>
</node>
<node TEXT="incorporate some interactive layer data so the curious can explore" ID="ID_1427266818" CREATED="1710282748704" MODIFIED="1710282758482"/>
<node TEXT="static data" FOLDED="true" ID="ID_1302914494" CREATED="1710347780652" MODIFIED="1710347785207">
<node TEXT="involves providing screenshots or snapshots in presentations or building dashboards using snapshots of data. There are pros and cons to static data." ID="ID_400429582" CREATED="1710348104752" MODIFIED="1710348104752"/>
<node TEXT="PROS" FOLDED="true" ID="ID_508102190" CREATED="1710348104752" MODIFIED="1710348104752">
<node TEXT="• Can tightly control a point-in-time narrative of the data and insight" ID="ID_1532476846" CREATED="1710348104754" MODIFIED="1710348104754"/>
<node TEXT="• Allows for complex analysis to be explained in-depth to a larger audience" ID="ID_1479971833" CREATED="1710348104755" MODIFIED="1710348104755"/>
</node>
<node TEXT="CONS" FOLDED="true" ID="ID_1689936144" CREATED="1710348104756" MODIFIED="1710348104756">
<node TEXT="• Insight immediately begins to lose value and continues to do so the longer the data remains in a static state" ID="ID_1056194245" CREATED="1710348104757" MODIFIED="1710348104757"/>
<node TEXT="• Snapshots can&apos;t keep up with the pace of data change" ID="ID_656363677" CREATED="1710348104758" MODIFIED="1710348104758"/>
</node>
</node>
<node TEXT="live data" FOLDED="true" ID="ID_187388907" CREATED="1710347786898" MODIFIED="1710347789398">
<node TEXT="means that you can build dashboards, reports, and views connected to automatically updated data." ID="ID_429823461" CREATED="1710348131136" MODIFIED="1710348131136"/>
<node TEXT="pros" FOLDED="true" ID="ID_408697026" CREATED="1710347734121" MODIFIED="1710347736419">
<node TEXT="• Dashboards can be built to be more dynamic and scalable" ID="ID_1903734810" CREATED="1710347742539" MODIFIED="1710347742539"/>
<node TEXT="• Gives the most up-to-date data to the people who need it at the time when they need it" ID="ID_275625875" CREATED="1710347742539" MODIFIED="1710347742539"/>
<node TEXT="• Allows for up-to-date curated views into data with the ability to build a scalable “single source of truth” for various use cases" ID="ID_671934373" CREATED="1710347742540" MODIFIED="1710347742540"/>
<node TEXT="• Allows for immediate action to be taken on data that changes frequently" ID="ID_643819577" CREATED="1710347742544" MODIFIED="1710347742544"/>
<node TEXT="• Alleviates time/resources spent on processes for every analysis" ID="ID_1131411693" CREATED="1710347742546" MODIFIED="1710347742546"/>
</node>
<node TEXT="cons" FOLDED="true" ID="ID_321124846" CREATED="1710347580615" MODIFIED="1710347762499">
<node TEXT="• Can take engineering resources to keep pipelines live and scalable, which may be outside the scope of some companies&apos; data resource allocation" ID="ID_344618924" CREATED="1710347763943" MODIFIED="1710347763943"/>
<node TEXT="• Without the ability to interpret data, you can lose control of the narrative, which can cause data chaos (i.e. teams coming to conflicting conclusions based on the same data)" ID="ID_1787691677" CREATED="1710347763943" MODIFIED="1710347763943"/>
<node TEXT="• Can potentially cause a lack of trust if the data isn’t handled properly" ID="ID_754358846" CREATED="1710347763948" MODIFIED="1710347763948"/>
</node>
<node ID="ID_364465658" TREE_ID="ID_79241099">
<node ID="ID_759544637" TREE_ID="ID_126196483"/>
<node ID="ID_568321072" TREE_ID="ID_1597927815">
<node ID="ID_682611432" TREE_ID="ID_620381142"/>
</node>
</node>
</node>
</node>
<node TEXT="tell the story in an interesting narrative" FOLDED="true" ID="ID_933573578" CREATED="1710277100620" MODIFIED="1710282453683">
<node TEXT="develop narrative" FOLDED="true" ID="ID_243609713" CREATED="1710358953526" MODIFIED="1710358958513">
<node TEXT="choose primary message" FOLDED="true" ID="ID_1480192509" CREATED="1710282061497" MODIFIED="1710282066313">
<node TEXT="pinpoint only the most useful pieces of data" FOLDED="true" ID="ID_1185044824" CREATED="1710282072295" MODIFIED="1710282123717">
<node TEXT="Spotlightling: Scanning through data to quickly identify the most important insights" FOLDED="true" ID="ID_1737423982" CREATED="1709323032394" MODIFIED="1709323032394">
<node TEXT="write each insight from your analysis on a piece of paper" ID="ID_1588845449" CREATED="1710282178872" MODIFIED="1710282206478"/>
<node TEXT="look for broad universal ideas and messages" ID="ID_249406413" CREATED="1710282207888" MODIFIED="1710282251270"/>
<node TEXT="find ideas or concepts that keep popping up again and again or numbers and words that are repeated often" ID="ID_1149576940" CREATED="1710282251293" MODIFIED="1710282264093"/>
<node TEXT="highlight these items and group them together on your whiteboard" ID="ID_525195023" CREATED="1710282265500" MODIFIED="1710282391532"/>
</node>
<node TEXT="eliminate less important details" ID="ID_250660128" CREATED="1710282127269" MODIFIED="1710282131674"/>
</node>
</node>
<node TEXT="clearly articulate recurring themes and data points" ID="ID_686406710" CREATED="1710282769692" MODIFIED="1710282779878"/>
<node TEXT="provide recommendations at the end" ID="ID_849757783" CREATED="1710282504281" MODIFIED="1710282519924"/>
<node TEXT="narrative elements" FOLDED="true" ID="ID_452043430" CREATED="1710357690100" MODIFIED="1710357694902">
<node TEXT="Characters" FOLDED="true" ID="ID_1469650358" CREATED="1710357696801" MODIFIED="1710357696801">
<node TEXT="The characters are the people affected by your story. This could be your stakeholders, customers, clients, and others. When adding information about your characters to your story, you have a great opportunity to include a personal account and bring more human context to the facts that the data has revealed—think about why they care." ID="ID_1969606499" CREATED="1710357696801" MODIFIED="1710357696801"/>
</node>
<node TEXT="Setting" FOLDED="true" ID="ID_513267659" CREATED="1710357696801" MODIFIED="1710357696801">
<node TEXT="describes what&apos;s going on, how often it&apos;s happening, what tasks are involved, and other background information about the data project that describes the current situation." ID="ID_1367792251" CREATED="1710357696802" MODIFIED="1710357696802"/>
</node>
<node TEXT="Plot" FOLDED="true" ID="ID_1576429604" CREATED="1710357696802" MODIFIED="1710357696802">
<node TEXT="sometimes called the conflict, is what creates tension in the current situation. This could be a challenge from a competitor, an inefficient process that needs to be fixed, or a new opportunity that the company just can&apos;t pass up. This complication of the current situation should reveal the problem your analysis is solving and compel the characters to act." ID="ID_1831322263" CREATED="1710357696803" MODIFIED="1710357696803"/>
</node>
<node TEXT="Big reveal" FOLDED="true" ID="ID_1947387836" CREATED="1710357696803" MODIFIED="1710357705353">
<node TEXT="how the data has shown that you can solve the problem the characters are facing by becoming more competitive, improving a process, inventing a new system, or whatever the ultimate goal of your data project may be." ID="ID_438552293" CREATED="1710357696803" MODIFIED="1710357696803"/>
</node>
<node TEXT="&quot;aha moment,&quot;" FOLDED="true" ID="ID_862102673" CREATED="1710357696803" MODIFIED="1710357696803">
<node TEXT="Finally, your &quot;aha moment&quot; is when you share your recommendations and explain why you think they&apos;ll help your company be successful." ID="ID_1455024730" CREATED="1710357696804" MODIFIED="1710357696804"/>
</node>
</node>
<node TEXT="pair your narrative with interesting visuals" ID="ID_1245215373" CREATED="1710357696804" MODIFIED="1710357696804"/>
<node TEXT="Checklist" FOLDED="true" ID="ID_1979986768" CREATED="1710359044613" MODIFIED="1710359047720">
<node TEXT="Include a good title and subtitle that describe what you’re about to present?" ID="ID_1228755251" CREATED="1710359048768" MODIFIED="1710359048768"/>
<node TEXT="Include the date of your presentation or the date when your slideshow was last updated?" ID="ID_58603263" CREATED="1710359048768" MODIFIED="1710359048768"/>
<node TEXT="Use a font size that lets the audience easily read your slides?" ID="ID_695147781" CREATED="1710359048772" MODIFIED="1710359048772"/>
<node TEXT="Showcase what business metrics you used?" ID="ID_14658296" CREATED="1710359048773" MODIFIED="1710359048773"/>
<node TEXT="Include effective visuals (like charts and graphs)?" ID="ID_870301164" CREATED="1710359048774" MODIFIED="1710359048774"/>
</node>
</node>
<node TEXT="present narrative" FOLDED="true" ID="ID_1761849534" CREATED="1710358965819" MODIFIED="1710358970301">
<node TEXT="Checklist" FOLDED="true" ID="ID_1618818712" CREATED="1710358997992" MODIFIED="1710359004389">
<node TEXT="Use an attention-grabbing opening?" ID="ID_781215376" CREATED="1710358989986" MODIFIED="1710358989986"/>
<node TEXT="Start with broad ideas and later talk about specific details?" ID="ID_1147703949" CREATED="1710358989987" MODIFIED="1710358989987"/>
<node TEXT="Speak in short sentences?" ID="ID_632983899" CREATED="1710358989988" MODIFIED="1710358989988"/>
<node TEXT="Pause for five seconds after showing a data visualization?" ID="ID_943009828" CREATED="1710358989989" MODIFIED="1710358989989"/>
<node TEXT="Pause intentionally at certain points?" ID="ID_549689295" CREATED="1710358989990" MODIFIED="1710358989990"/>
<node TEXT="Keep the pitch of your voice level?" ID="ID_1868074545" CREATED="1710358989991" MODIFIED="1710358989991"/>
<node TEXT="Stand still and move with purpose?" ID="ID_1821205785" CREATED="1710358989992" MODIFIED="1710358989992"/>
<node TEXT="Maintain good posture?" ID="ID_1012868542" CREATED="1710358989992" MODIFIED="1710358989992"/>
<node TEXT="Look at your audience (or camera) while speaking?" ID="ID_1652745052" CREATED="1710358989993" MODIFIED="1710358989993"/>
<node TEXT="Keep your message concise?" ID="ID_1827909149" CREATED="1710358989994" MODIFIED="1710358989994"/>
<node TEXT="End by explaining why the data analysis matters?" ID="ID_820972440" CREATED="1710358989995" MODIFIED="1710358989995"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Develop presentations and slideshows (4)" FOLDED="true" ID="ID_1358628456" CREATED="1709318169773" MODIFIED="1709318186577">
<node TEXT="The art and science of presentations" FOLDED="true" ID="ID_834981114" CREATED="1710361725353" MODIFIED="1710361734550">
<node TEXT="Present with a framework" FOLDED="true" ID="ID_440258185" CREATED="1710361734555" MODIFIED="1710361738972">
<node TEXT="purpose" FOLDED="true" ID="ID_1918730760" CREATED="1710361825576" MODIFIED="1710361827589">
<node TEXT="helps your audience understand the most important takeaways" ID="ID_1571493010" CREATED="1710361778826" MODIFIED="1710361786982"/>
<node TEXT="helps to create logical connections that tie back to the business task and metrics" ID="ID_301290088" CREATED="1710361793387" MODIFIED="1710361802174"/>
</node>
<node TEXT="framework" FOLDED="true" ID="ID_175071364" CREATED="1710361842775" MODIFIED="1710361845734">
<node TEXT="present your data in the context of the business task" FOLDED="true" ID="ID_995489384" CREATED="1710361906378" MODIFIED="1710361916349">
<node TEXT="Business task: The question or problem data analysis resolves for a business" ID="ID_620571890" CREATED="1707259637664" MODIFIED="1707259637664"/>
<node TEXT="starts with your understanding of the business task" ID="ID_508835946" CREATED="1710361845737" MODIFIED="1710361852392"/>
<node TEXT="makes your presentation more informative" ID="ID_1700167905" CREATED="1710361916353" MODIFIED="1710361920148"/>
<node TEXT="helps you empower your audience with knowledge" ID="ID_449048187" CREATED="1710361920171" MODIFIED="1710361925373"/>
</node>
<node TEXT="outline and connect with your business metrics by showcasing what business metrics you use" FOLDED="true" ID="ID_1544213045" CREATED="1710362084164" MODIFIED="1710362099751">
<node TEXT="helps your audience understand the impact your findings will have" ID="ID_554947638" CREATED="1710362099754" MODIFIED="1710362110157"/>
</node>
</node>
</node>
<node TEXT="Weave data into your presentation" FOLDED="true" ID="ID_768907578" CREATED="1710362260824" MODIFIED="1710362266892">
<node TEXT="help your audience understand what data was available during data collection" FOLDED="true" ID="ID_1368755596" CREATED="1710362272343" MODIFIED="1710362346361">
<node TEXT="helps audience understand what data they are actually looking at and what questions they can expected to answer" ID="ID_1132280811" CREATED="1710362364505" MODIFIED="1710362375391"/>
<node TEXT="let them know if any new relevant data has come up, or if you discover that you need different data" ID="ID_1976003310" CREATED="1710362306795" MODIFIED="1710362320547"/>
</node>
<node TEXT="establish the initial hypothesis early in the presentation to create context" FOLDED="true" ID="ID_1982827122" CREATED="1710362398451" MODIFIED="1710362438274">
<node TEXT="initial theory you&apos;re trying to prove or disprove a data" ID="ID_939638960" CREATED="1710362404624" MODIFIED="1710362414874"/>
</node>
<node TEXT="explain the solutions to your business tasks using examples and visualizations" ID="ID_1207768322" CREATED="1710362442274" MODIFIED="1710362476550"/>
<node TEXT="present your visualizations effectively" FOLDED="true" ID="ID_1326823189" CREATED="1710362491919" MODIFIED="1710362498175">
<node TEXT="McCandless method" FOLDED="true" ID="ID_697005476" CREATED="1710362499944" MODIFIED="1710362506538">
<node TEXT="1. Introduce the graphic by name" ID="ID_1432036579" CREATED="1710435133445" MODIFIED="1710435133445"/>
<node TEXT="2. Answer obvious questions before they’re asked" FOLDED="true" ID="ID_653116334" CREATED="1710435133445" MODIFIED="1710435133445">
<node TEXT="start with high-level information and work your way into the lowest level of detail." ID="ID_745297042" CREATED="1710362574743" MODIFIED="1710362630694"/>
</node>
<node TEXT="3. State the insight of your graphic" FOLDED="true" ID="ID_1149302369" CREATED="1710435133448" MODIFIED="1710435133448">
<node TEXT="get everyone on the same page before you move into the supporting details" ID="ID_741876133" CREATED="1710362672955" MODIFIED="1710362686342"/>
<node TEXT="write in some key takeaways" ID="ID_881249848" CREATED="1710362686382" MODIFIED="1710362700408"/>
</node>
<node TEXT="4. Call out data to support that insight" ID="ID_1292821408" CREATED="1710435133449" MODIFIED="1710435133449"/>
<node TEXT="5. Tell your audience why it matters" FOLDED="true" ID="ID_894587936" CREATED="1710435133451" MODIFIED="1710435133451">
<node TEXT="present the possible business impact of the solution and clear action stakeholders can take" ID="ID_834493413" CREATED="1710362752968" MODIFIED="1710362762987"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Presentation skills and practices" ID="ID_52561153" CREATED="1710441485152" MODIFIED="1710441495349"/>
<node TEXT="Data caveats and limitations" FOLDED="true" ID="ID_578028563" CREATED="1710441495366" MODIFIED="1710444863787">
<node TEXT="Anticipate the question" FOLDED="true" ID="ID_1581153532" CREATED="1710443564235" MODIFIED="1710443567950">
<node TEXT="Understand your stakeholder expectations" ID="ID_1842778814" CREATED="1710443571547" MODIFIED="1710443577266"/>
<node TEXT="Make sure you have a clear understanding of the objective and what the stakeholders wanted" FOLDED="true" ID="ID_759263963" CREATED="1710443585958" MODIFIED="1710443593560">
<node TEXT="if you misunderstood your stakeholders expectations or the project objectives, you won&apos;t be able to correctly answer their questions" ID="ID_1371851812" CREATED="1710443604945" MODIFIED="1710443625952"/>
</node>
<node TEXT="Do a test run, colleague test" FOLDED="true" ID="ID_502366336" CREATED="1710443657373" MODIFIED="1710443734359">
<node TEXT="show the presentation to coworkers who are unfamiliar with the subject matter in order to get their feedback" ID="ID_974603366" CREATED="1710443735149" MODIFIED="1710443745556"/>
</node>
<node TEXT="Be prepared to consider any limitations of your data by:" FOLDED="true" ID="ID_331249351" CREATED="1710443663382" MODIFIED="1710443669960">
<node TEXT="critically analyzing the correlations" ID="ID_284894735" CREATED="1710443669962" MODIFIED="1710443674540"/>
<node TEXT="looking at the context" ID="ID_915171966" CREATED="1710443674561" MODIFIED="1710443677148"/>
<node TEXT="understanding the strengths and weaknesses of the tools" ID="ID_293687438" CREATED="1710443677165" MODIFIED="1710443681577"/>
</node>
<node TEXT="transcript Anticipate the question" FOLDED="true" ID="ID_195066774" CREATED="1710441506556" MODIFIED="1710443562001">
<node ID="ID_1106183157" CREATED="1710442284546" MODIFIED="1710442284546"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          So let's talk about how you can be sure you're prepared for a Q &amp;amp; A
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1675650822" CREATED="1710442284547" MODIFIED="1710442284547"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          For starters, knowing the questions ahead of time can make a big difference
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1813549043" CREATED="1710442284565" MODIFIED="1710442284565"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You don't have to be a mind reader, but there's a few things you can do to prepare that'll help
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_570748564" CREATED="1710442284569" MODIFIED="1710442284569"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          For this example, we'll go back to the presentation we created about health and happiness around the world
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1212183271" CREATED="1710442284573" MODIFIED="1710442284573"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We put together these slides, clean them up a bit, and now we're getting ready for the actual presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_584853560" CREATED="1710442284577" MODIFIED="1710442284577"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Let's go over some ways we can anticipate possible questions before our Q &amp;amp; A to give us more time to think about the answers
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_564140707" CREATED="1710442284581" MODIFIED="1710442284581"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Understanding your stakeholder's expectations will help you predict the questions they might ask
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_146447483" CREATED="1710442284584" MODIFIED="1710442284584"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          As we previously discussed, it's important to set stakeholder expectations early in the project
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_909443415" CREATED="1710442284586" MODIFIED="1710442284586"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Keep their expectations in mind while you're planning presentations and Q &amp;amp; A sessions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1735865606" CREATED="1710442284590" MODIFIED="1710442284590"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Make sure you have a clear understanding of the objective and what the stakeholders wanted when they asked you to take on this project
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_123951198" CREATED="1710442284595" MODIFIED="1710442284595"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          For this project, our stakeholders were interested in what factors contributed to a happier life around the world
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_196329379" CREATED="1710442284596" MODIFIED="1710442284596"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Our objective was to identify if there were geographic, demographic, and/or economic factors that contributed to a happier life
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_517250369" CREATED="1710442284599" MODIFIED="1710442284599"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Knowing that, we can start thinking about the potential questions about that objective they might have
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_580080380" CREATED="1710442284601" MODIFIED="1710442284601"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          At the end of the day, if you misunderstood your stakeholders' expectations or the project objectives, you won't be able to correctly anticipate or answer their questions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1505861314" CREATED="1710442284603" MODIFIED="1710442284603"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Think about these things early and often when planning for a Q &amp;amp; A
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1735549227" CREATED="1710442284607" MODIFIED="1710442284607"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Once you feel confident that you fully understand your stakeholders' expectations and the project goals, you can start identifying possible questions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_558656763" CREATED="1710442284610" MODIFIED="1710442396776"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          A great way to identify audience questions is to do a test run of your presentation &quot;colleague test&quot;
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1572022624" CREATED="1710442284616" MODIFIED="1710442284616"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          &quot; Show your presentation or your data viz to a colleague who has no previous knowledge of your work, and see what questions they ask you
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_31802666" CREATED="1710442284618" MODIFIED="1710442284618"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          They might have the same questions your real audience does
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_814657119" CREATED="1710442284621" MODIFIED="1710442284621"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We talked about feedback as a gift, so don't be afraid to seek it out and ask colleagues for their opinions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1945661680" CREATED="1710442284630" MODIFIED="1710442284630"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Let's say we ran through our presentation with a colleague, we showed them our data visualizations, then asked them what questions they had
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1028411056" CREATED="1710442284634" MODIFIED="1710442284634"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          They tell us they weren't sure how we were measuring health and happiness with our data in this slide
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_851409982" CREATED="1710442284638" MODIFIED="1710442284638"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We can absolutely work that information into our presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_773153205" CREATED="1710442284642" MODIFIED="1710442284642"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Sometimes the questions asked during our colleague tests help us revise our presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1433657130" CREATED="1710442284647" MODIFIED="1710442284647"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Other times, they help us anticipate questions that might come up during the presentation, even if we didn't originally want to build that information into the presentation itself
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1722717425" CREATED="1710442284648" MODIFIED="1710442284648"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          It helps to be prepared to go into detail about your process, but only if someone asks
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1392924159" CREATED="1710442284651" MODIFIED="1710442284651"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Either way, their feedback can help take your presentation to the next level
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_144384017" CREATED="1710442284654" MODIFIED="1710442284654"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Next, it's helpful to start with zero assumptions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1738117604" CREATED="1710442284657" MODIFIED="1710442284657"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Don't assume that your audience is already familiar with jargon, acronyms, past events, or other necessary background information
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1031562203" CREATED="1710442284659" MODIFIED="1710442284659"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Try to explain these things in the presentation, and be ready to explain them further if asked
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1418917578" CREATED="1710442284661" MODIFIED="1710442284661"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          When we showed our presentation to our colleague, we accidentally assumed that they already knew how health and happiness were measured and left that out of our original presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_560974264" CREATED="1710442284665" MODIFIED="1710442284665"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Now, let's look at our second data viz
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1133181503" CREATED="1710442284669" MODIFIED="1710442284669"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          This graph is showing the relationship between health, wealth, and happiness, but includes GDP to measure the economy
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_850560511" CREATED="1710442284671" MODIFIED="1710442284671"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We don't want to assume that our audience knows what that means, so during the presentation, we'll want to include a definition of GDP
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1157842052" CREATED="1710442284675" MODIFIED="1710442284675"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          In our speaker notes, we've added gross domestic product: total monetary or market value of all the finished goods and services produced within a country's borders in a specific period of time
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_116460529" CREATED="1710442284678" MODIFIED="1710442284678"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We'll fully explain what GDP means as soon as this graphic comes up; that way, no one in our audience is confused by that acronym
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_379269044" CREATED="1710442284681" MODIFIED="1710442284681"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          It helps to work with your team to anticipate questions and draft responses
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_831226660" CREATED="1710442284684" MODIFIED="1710442284684"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Together, you'll be able to include their perspectives and coordinate answers so that everyone on your team is prepared and ready to share their unique insights with stakeholders
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_96283116" CREATED="1710442284686" MODIFIED="1710442284686"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          The team working on the world happiness project with you probably have a lot of great insights about the data, like how it was gathered or what it might be missing
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_198583363" CREATED="1710442284689" MODIFIED="1710442284689"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Touch base with them so you don't miss out on their perspective
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_661632152" CREATED="1710442284692" MODIFIED="1710442284692"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Finally, be prepared to consider and describe to your stakeholders any limitations in your data
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1168420769" CREATED="1710442284694" MODIFIED="1710442284694"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You can do this by critically analyzing the patterns you've discovered in your data for integrity
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_638917398" CREATED="1710442284697" MODIFIED="1710442284697"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          For example, could the correlations found be explained as coincidence? On top of that, use your understanding of the strengths and weaknesses of the tools you use in your analysis to pinpoint any limitations they may have introduced
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_236314057" CREATED="1710442284699" MODIFIED="1710442284699"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          While you probably don't have the power to predict the future, you can come pretty close to predicting stakeholder and audience questions by doing a few key things
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_183347198" CREATED="1710442284701" MODIFIED="1710442284701"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Remember to focus on stakeholder expectations and project goals, identify possible questions with your team, review your presentation with zero assumptions, and consider the limitations of your data
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_240132298" CREATED="1710442284704" MODIFIED="1710442284704"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Sometimes, though, your audience might raise objections to the data before and after your presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Handle objections" FOLDED="true" ID="ID_1878045975" CREATED="1710442736483" MODIFIED="1710442741144">
<node TEXT="Types of objections" FOLDED="true" ID="ID_1592855111" CREATED="1710442741147" MODIFIED="1710442746543">
<node TEXT="About the data" FOLDED="true" ID="ID_1218840396" CREATED="1710442746545" MODIFIED="1710442750137">
<node TEXT="Where you got the data" ID="ID_37536679" CREATED="1710442773208" MODIFIED="1710442783392"/>
<node TEXT="what systems it came from" ID="ID_684088573" CREATED="1710442786780" MODIFIED="1710442791738"/>
<node TEXT="what transformations happen to it" ID="ID_123773727" CREATED="1710442791757" MODIFIED="1710442795148"/>
<node TEXT="how fresh and accurate as the data" ID="ID_1926286391" CREATED="1710442795173" MODIFIED="1710442798956"/>
</node>
<node TEXT="about your analysis" FOLDED="true" ID="ID_988656532" CREATED="1710442750153" MODIFIED="1710442756777">
<node TEXT="is your analysis reproducible" ID="ID_1961901292" CREATED="1710442809978" MODIFIED="1710442818158"/>
<node TEXT="who did you get feedback from" ID="ID_688841843" CREATED="1710442828975" MODIFIED="1710442832982"/>
</node>
<node TEXT="about your findings" FOLDED="true" ID="ID_742347703" CREATED="1710442763151" MODIFIED="1710442766556">
<node TEXT="do these findings exist in previous time periods" ID="ID_50526097" CREATED="1710442845952" MODIFIED="1710442850944"/>
<node TEXT="did you control for the differences in your data" ID="ID_1602384188" CREATED="1710442850964" MODIFIED="1710442855365"/>
</node>
</node>
<node TEXT="Responding to possible objections" FOLDED="true" ID="ID_362560757" CREATED="1710442867190" MODIFIED="1710442871347">
<node TEXT="acknowledge that those objections are valid" ID="ID_266685233" CREATED="1710442916575" MODIFIED="1710443860591"/>
<node TEXT="follow-up with details" FOLDED="true" ID="ID_674184641" CREATED="1710443892146" MODIFIED="1710443896176">
<node TEXT="explain why your analysis might be different than expected" ID="ID_1424667207" CREATED="1710442880760" MODIFIED="1710442910581"/>
<node TEXT="communicate any assumptions" ID="ID_1724241309" CREATED="1710442871349" MODIFIED="1710442880741"/>
</node>
<node TEXT="take steps to investigate further" ID="ID_429217613" CREATED="1710443857383" MODIFIED="1710443857386"/>
</node>
<node TEXT="transcript Handle objections" FOLDED="true" ID="ID_980466862" CREATED="1710442511710" MODIFIED="1710442735403">
<node ID="ID_1160427997" CREATED="1710442942977" MODIFIED="1710442942977" LINK="https://www.coursera.org/learn/visualize-data/lecture/BxgQQ/handle-objections"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/visualize-data/lecture/BxgQQ/handle-objections">Handle objections | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_418463223" CREATED="1710442700629" MODIFIED="1710442700629"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          In this video, we'll talk about how you can handle objections about the data you're presenting
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_193977997" CREATED="1710442700629" MODIFIED="1710442700629"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Stakeholders might raise objections during or after your presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1135540016" CREATED="1710442700632" MODIFIED="1710442700632"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Usually, these objections are about the data, your analysis, or your findings
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1655532852" CREATED="1710442700634" MODIFIED="1710442700634"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We'll start by discussing what questions these objections are asking and then talk about how to respond
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1319966765" CREATED="1710442700637" MODIFIED="1710442700637"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Objections about the data could mean a few different things
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_560730231" CREATED="1710442700640" MODIFIED="1710442700640"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Sometimes, stakeholders might be asking where you got the data and what systems that came from, or they might want to know what transformations happened to it before you worked with it, or how fresh and accurate your data is
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1869143687" CREATED="1710442700644" MODIFIED="1710442700644"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You can include all this information in the beginning of your presentation to set up the data context
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1663115028" CREATED="1710442700646" MODIFIED="1710442700646"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You can add a more detailed breakdown in your appendix in case there are more questions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1155551852" CREATED="1710442700648" MODIFIED="1710442700648"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          When we're talking about cleaning data, you learned keeping a detailed log of data transformations is useful
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_419921987" CREATED="1710442700650" MODIFIED="1710442700650"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          That log can help you answer the questions we're talking about here, and if you keep it in your presentation's appendix, it'll be easy to reference if any of your stakeholders want more detail during a Q &amp; A
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_284047637" CREATED="1710442700653" MODIFIED="1710442700653"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Now, your audience might also have questions or objections about your analysis
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_741082907" CREATED="1710442700655" MODIFIED="1710442700655"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          They might want to know if your analysis is reproducible, so it helps to keep a change log documenting the steps you took
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_685704341" CREATED="1710442700658" MODIFIED="1710442700658"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          This way, someone else could follow along and reproduce your process
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1549702694" CREATED="1710442700661" MODIFIED="1710442700661"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You can even create a slide in the appendix section of your presentation explaining these steps, if you think it will be necessary
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1002135664" CREATED="1710442700664" MODIFIED="1710442700664"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          And it can be useful to keep a clean version of your script if you're working with a programming language like SQL or R, which we'll learn all about later
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1989918928" CREATED="1710442700666" MODIFIED="1710442700666"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Also, be prepared to answer questions like, &quot;Who did you get feedback from during this process?&quot; This is especially important when your analysis reveals insights that are the opposite of your audience's gut feelings about the data
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1663017717" CREATED="1710442700668" MODIFIED="1710442700668"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Making sure to include lots of perspectives throughout your analysis process will help you back up your findings during your presentation
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1761356886" CREATED="1710442700670" MODIFIED="1710442700670"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Finally, you might be faced with objections to the findings themselves
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_624743680" CREATED="1710442700674" MODIFIED="1710442700674"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          A lot of the time these will be questions like, &quot;Do these findings exist in previous time periods, or did you control for the differences in your data?&quot; Your audience wants to be sure that your final results accounted for any possible inconsistencies and that they're accurate and useful
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1739238154" CREATED="1710442700679" MODIFIED="1710442700679"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Now that you know some of the possible kinds of objections your audience might raise, let's talk about how you can think about responding
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1253610610" CREATED="1710442700683" MODIFIED="1710442700683"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          First, it can be useful to communicate any assumptions about the data, your analysis, or your findings that might help answer their questions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1813265131" CREATED="1710442700685" MODIFIED="1710442700685"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          For example, did your team clean and format your data before analysis? Telling your audience that can clear up any doubts they might have
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_49248563" CREATED="1710442700687" MODIFIED="1710442700687"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Second, explain why your analysis might be different than expected
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_11059536" CREATED="1710442700689" MODIFIED="1710442700689"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Walk your audience through the variables that change the outcomes to help them understand how you got there
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_518660067" CREATED="1710442700692" MODIFIED="1710442700692"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          And third, some objections have merit, especially if they bring up something you hadn't thought of before
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1685522006" CREATED="1710442700693" MODIFIED="1710442700693"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          If that's true, you can acknowledge that those objections are valid and take steps to investigate further
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1714920490" CREATED="1710442700696" MODIFIED="1710442700696"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Following up with more details afterwards is great, too
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1566442657" CREATED="1710442700698" MODIFIED="1710442700698"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          And now you know some of the basic objections you might run into
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_749479232" CREATED="1710442700699" MODIFIED="1710442700699"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Understanding that your audience might have questions about your data, your analysis, or your findings can help you prepare responses ahead of time, and walking your audience through any assumptions about the data or unexpected results are great approaches to responding
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Listen, respond, and include" FOLDED="true" ID="ID_713117763" CREATED="1710444866199" MODIFIED="1710444873392">
<node FOLDED="true" ID="ID_1907231728" CREATED="1710444876235" MODIFIED="1710444876235" LINK="https://www.coursera.org/learn/visualize-data/lecture/pA1FW/q-a-best-practices"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/visualize-data/lecture/pA1FW/q-a-best-practices">Q&amp;A best practices | Coursera</a>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_723306226" CREATED="1710445060814" MODIFIED="1710445534739"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          listen to the whole question
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node ID="ID_1754812954" CREATED="1710445060816" MODIFIED="1710445060816"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          I know this sounds like a given, but it can be really tempting to start thinking about your answer before the person you're talking to has even finished asking their question
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1642382669" CREATED="1710445060820" MODIFIED="1710445060820"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          On slide 11 of our presentation, we outline our conclusions
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_2684849" CREATED="1710445060822" MODIFIED="1710445060822"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          After explaining these conclusions, one of our stakeholders asks, &quot;How was happiness measured for this project?&quot; It's important to listen to the whole question and wait to respond until they're done talking
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1918786517" CREATED="1710445060824" MODIFIED="1710445534741"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Take a moment to repeat the question
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node ID="ID_496831250" CREATED="1710445060827" MODIFIED="1710445060827"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Repeating the question is helpful for a few different reasons
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_550197925" CREATED="1710445060830" MODIFIED="1710445060830"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          For one, it helps you make sure that you're understanding the question
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_44051626" CREATED="1710445060832" MODIFIED="1710445060832"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Second, it gives the person asking it a chance to correct you if you're not
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1975591771" CREATED="1710445060834" MODIFIED="1710445060834"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Anyone who couldn't hear the question will still know what's being asked
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1290140221" CREATED="1710445060836" MODIFIED="1710445060836"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Plus, it gives you a moment to get your thoughts together
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1734842540" CREATED="1710445060839" MODIFIED="1710445060839"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          After listening to the question and repeating it to make sure you understand, you can explain that participants in different countries were given a survey that asked them to rate their happiness, and just like that, your audience has a better understanding of the project because you took the time to listen carefully
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_663500655" CREATED="1710445060840" MODIFIED="1710445060840"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Now that they know about the survey, they're interested in knowing more
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1356026317" CREATED="1710445060843" MODIFIED="1710445060843"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          At this point, we can go into more detail about that data
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_344493907" CREATED="1710445060845" MODIFIED="1710445060845"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We have a slide built in here called the appendix
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_971282870" CREATED="1710445060848" MODIFIED="1710445060848"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          This is a great place to keep extra information that might not be necessary for our presentation but could be useful for answering questions afterwards
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1875040159" CREATED="1710445060851" MODIFIED="1710445060851"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          This is also a great place for us to have more detailed information about the survey data so we can reference it more easily
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_600101499" CREATED="1710445060853" MODIFIED="1710445534743"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          make sure you understand the context questions are being asked in
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node ID="ID_1097882509" CREATED="1710445060855" MODIFIED="1710445060855"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Think about who is your audience and what kinds of concerns or backgrounds they might have
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1542697484" CREATED="1710445060860" MODIFIED="1710445060860"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Remember the project goals and your stakeholders' interests in them, and try to keep your answers relevant to that specific context, just like you made sure your presentation itself was relevant to your stakeholders
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node TEXT="example" FOLDED="true" ID="ID_1160341855" CREATED="1710445250560" MODIFIED="1710445252127">
<node FOLDED="true" ID="ID_609786693" CREATED="1710445060861" MODIFIED="1710445060861"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We have this slide with data about life expectancy as a metric for health
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_537051096" CREATED="1710445060863" MODIFIED="1710445060863"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          If you're presenting to a group of stakeholders who are in the healthcare industry, they're probably going to be more interested in the medical data and the relationship between overall health and happiness
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_383239201" CREATED="1710445060865" MODIFIED="1710445060865"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Knowing this, you can tailor your answers to focus on their interests so that the presentation is relevant and useful to them
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_67242456" CREATED="1710445060869" MODIFIED="1710445534744"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          When answering, try to involve the whole audience
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node ID="ID_333108959" CREATED="1710445060871" MODIFIED="1710445060871"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You aren't just having a one-on-one conversation with the person that's asked the question; you're presenting to a group of people who might also have the same question or need to know what that answer is
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_66517954" CREATED="1710445060873" MODIFIED="1710445060873"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          It's important to not accidentally exclude other audience members
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node TEXT="if the audience is losing interest" FOLDED="true" ID="ID_1441361618" CREATED="1710446609394" MODIFIED="1710446615560">
<node TEXT="redirect to a new question" ID="ID_615390418" CREATED="1710446615564" MODIFIED="1710446620152"/>
<node TEXT="ask a question to your audience to reengage them" ID="ID_1702534749" CREATED="1710446620168" MODIFIED="1710446625393"/>
</node>
<node FOLDED="true" ID="ID_981410392" CREATED="1710445060876" MODIFIED="1710445060876"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You can also include other voices
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_427861049" CREATED="1710445060878" MODIFIED="1710445060878"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          If there's someone in your audience or team that might have insight, ask them for their thoughts
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1844237321" CREATED="1710445060880" MODIFIED="1710445534745"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Keep your responses short and to the point
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node FOLDED="true" ID="ID_1167706592" CREATED="1710445060882" MODIFIED="1710445060882"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Start with a headline response that gives your stakeholders the basic answer
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1941408589" CREATED="1710445060884" MODIFIED="1710445060884"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Then if they have more questions, you can go into more detail
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_660899191" CREATED="1710445060886" MODIFIED="1710445060886"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          This can be difficult as a data analyst
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_943784139" CREATED="1710445060888" MODIFIED="1710445060888"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          You have all the background information and want to share your hard work, but you don't want to lose your audience with a long and potentially confusing answer
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_88043045" CREATED="1710445060890" MODIFIED="1710445060890"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Stay focused on the question itself
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_623909188" CREATED="1710445060893" MODIFIED="1710445060893"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          This is why listening to the whole question is so important
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1399704144" CREATED="1710445060896" MODIFIED="1710445060896"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          It keeps the focus on that specific question
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_308906363" CREATED="1710445060897" MODIFIED="1710445060897"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Answer the question as directly as possible using the fewest words you can
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_661254513" CREATED="1710445060899" MODIFIED="1710445060899"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          From there, you can expand on your answer or add color, contexts, and detail as needed
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_55062692" CREATED="1710445060901" MODIFIED="1710445060901"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Like when one of our stakeholders asked how the data measuring happiness was gathered
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_1268753009" CREATED="1710445060903" MODIFIED="1710445060903"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          We started by telling them that a survey was used to measure an individual's happiness, and only when they are interested in hearing more about the survey did we go into more detail
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1209457298" CREATED="1710445060907" MODIFIED="1710445060907"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          Remember, you don't have to answer every question on the spot
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_448806912" CREATED="1710445060909" MODIFIED="1710446653381"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          If it is a tough question that will require additional analysis or research,
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node ID="ID_341258140" CREATED="1710446653383" MODIFIED="1710446668594"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          let your audience know that you'll get back to them
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_201252387" CREATED="1710446668596" MODIFIED="1710446673609"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          remember to follow up in a timely manner
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node ID="ID_220040581" CREATED="1710445060911" MODIFIED="1710445060911"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table cellspacing="0" border="0">
      <tr>
        <td height="21" align="left">
          These tips will make it easier to answer questions and make you seem prepared and professional
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1183659899" CREATED="1710445813831" MODIFIED="1710445813831" LINK="https://www.coursera.org/learn/visualize-data/discussionPrompt/byLQe/ask-for-feedback"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/visualize-data/discussionPrompt/byLQe/ask-for-feedback">Ask for feedback | Coursera</a>
  </body>
</html>
</richcontent>
<node TEXT="During a presentation, you should pay special attention to the needs of your audience. In a data analysis setting, your audience will likely include your stakeholders or supervisors. They have a vested interest in the work you’ve done, so it is important to communicate your findings to them as clearly as possible." ID="ID_609120937" CREATED="1710445831044" MODIFIED="1710445831044"/>
<node TEXT="At the end of a presentation, you’ll typically be asked to hold a question and answer (Q&amp;A) session. During the Q&amp;A, your audience can ask you for clarification about what you’ve presented or provide advice about how to proceed." ID="ID_1997074190" CREATED="1710445831045" MODIFIED="1710445831045"/>
<node TEXT="In some cases, you might find that stakeholders don’t know how best to ask a question. Imagine a scenario in which a stakeholder is confused about what you’ve discussed, but is having trouble figuring out how to ask their question in a group setting. With this scenario in mind, consider the following questions:" ID="ID_1787454785" CREATED="1710445831047" MODIFIED="1710445831047"/>
<node TEXT="• What are some other ways you can receive feedback from your audience and stakeholders?" FOLDED="true" ID="ID_850309856" CREATED="1710445831049" MODIFIED="1710445831049">
<node TEXT="• Gauging their attention" ID="ID_1253217601" CREATED="1710445831050" MODIFIED="1710445831050"/>
<node TEXT="looking at their expressions" ID="ID_391243609" CREATED="1710445842555" MODIFIED="1710445852889"/>
<node TEXT="being open for questions after each slide" ID="ID_1105370247" CREATED="1710445842599" MODIFIED="1710445869146"/>
</node>
<node TEXT="• How can you be as inclusive as possible? How can you make your audience feel comfortable asking you for clarification?" ID="ID_1930577804" CREATED="1710445831050" MODIFIED="1710445831050"/>
<node TEXT="What creative methods can you use to engage your audience?" ID="ID_258965788" CREATED="1710445831052" MODIFIED="1710445831052"/>
</node>
<node TEXT="" ID="ID_531236625" CREATED="1710445947766" MODIFIED="1710445947766"/>
<node FOLDED="true" ID="ID_1421615727" CREATED="1710445953389" MODIFIED="1710445953389" LINK="https://www.coursera.org/learn/visualize-data/lecture/uSisr/connor-becoming-an-expert-data-translator"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/visualize-data/lecture/uSisr/connor-becoming-an-expert-data-translator">Connor: Becoming an expert data translator | Coursera</a>
  </body>
</html>
</richcontent>
<node TEXT="presenting data is the most important aspect of being a data analyst" ID="ID_1652815779" CREATED="1710445956953" MODIFIED="1710445985202"/>
<node TEXT="important aspects of presentation" FOLDED="true" ID="ID_1608259914" CREATED="1710445986564" MODIFIED="1710445992955">
<node TEXT="define your purpose" ID="ID_833532169" CREATED="1710445992956" MODIFIED="1710446001153"/>
<node TEXT="keep it concise" ID="ID_445612309" CREATED="1710446001168" MODIFIED="1710446006956"/>
<node TEXT="have some logical flow to your presentation" ID="ID_1325228753" CREATED="1710446006973" MODIFIED="1710446027604"/>
<node TEXT="make your presentation visually compelling" ID="ID_1535297496" CREATED="1710446043581" MODIFIED="1710446049400"/>
<node TEXT="how easy is it to understand?" ID="ID_1869930437" CREATED="1710446063159" MODIFIED="1710446076166"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Step 6: Act" FOLDED="true" ID="ID_1367868967" CREATED="1706900372202" MODIFIED="1706900372202">
<node TEXT="Roadmap" FOLDED="true" ID="ID_336005691" CREATED="1712603651461" MODIFIED="1712603654244">
<node TEXT="Guiding questions" ID="ID_1349935181" CREATED="1712603655713" MODIFIED="1712603655713">
<node TEXT="What is your final conclusion based on your analysis?" ID="ID_1988128187" CREATED="1712603655713" MODIFIED="1712603655713"/>
<node TEXT="How can you apply your insights?" ID="ID_454785177" CREATED="1712603655716" MODIFIED="1712603655716"/>
<node TEXT="Are there any next steps you or your stakeholders can take based on your findings?" ID="ID_1069605286" CREATED="1712603655717" MODIFIED="1712603655717"/>
<node TEXT="Is there additional data you could use to expand on your findings?" ID="ID_1847436477" CREATED="1712603655718" MODIFIED="1712603655718"/>
<node TEXT="How can you feature your case study in your portfolio?" ID="ID_335193257" CREATED="1712603655719" MODIFIED="1712603655719"/>
</node>
<node TEXT="Key tasks" ID="ID_739822692" CREATED="1712603655721" MODIFIED="1712603655721">
<node TEXT="After this, your case study will be complete. But you can use these steps again to help guide you through your analysis process." ID="ID_1664139607" CREATED="1712603655721" MODIFIED="1712603655721"/>
<node TEXT="Share next steps with your stakeholders" ID="ID_1187015572" CREATED="1712603655722" MODIFIED="1712603655722"/>
<node TEXT="Determine if more data could give you new insights" ID="ID_1330554667" CREATED="1712603655722" MODIFIED="1712603655722"/>
<node TEXT="Upload to your portfolio" ID="ID_1692013277" CREATED="1712603655724" MODIFIED="1712603655724"/>
</node>
</node>
<node TEXT="Act (6)" FOLDED="true" ID="ID_892937695" CREATED="1706679836557" MODIFIED="1706736722613">
<node TEXT="putting insights to work to solve a problem" ID="ID_1267031722" CREATED="1706683260493" MODIFIED="1706683275886"/>
</node>
<node TEXT="Now it’s time to act on your data. You will take everything you have learned from your data analysis and put it to use. This could mean providing your stakeholders with recommendations based on your findings so they can make data-driven decisions." ID="ID_1782485030" CREATED="1706900372203" MODIFIED="1706900372203"/>
<node TEXT="Questions to ask yourself in this step:" ID="ID_1742283069" CREATED="1706900372203" MODIFIED="1706900372203"/>
<node TEXT="How can I use the feedback I received during the share phase (step 5) to actually meet the stakeholder’s needs and expectations?" ID="ID_1925752114" CREATED="1706900372205" MODIFIED="1706900372205"/>
<node TEXT="These six steps can help you to break the data analysis process into smaller, manageable parts, which is called structured thinking. This process involves four basic activities:" FOLDED="true" ID="ID_1711080494" CREATED="1706900372206" MODIFIED="1706900372206">
<node TEXT="Recognizing the current problem or situation" ID="ID_1240927824" CREATED="1706900372207" MODIFIED="1706900372207"/>
<node TEXT="Organizing available information" ID="ID_797548930" CREATED="1706900372208" MODIFIED="1706900372208"/>
<node TEXT="Revealing gaps and opportunities" ID="ID_1917890819" CREATED="1706900372208" MODIFIED="1706900372208"/>
<node TEXT="Identifying your options" ID="ID_902943207" CREATED="1706900372209" MODIFIED="1706900372209"/>
</node>
</node>
<node FOLDED="true" ID="ID_229178485" CREATED="1710459382797" MODIFIED="1710459396771" LINK="https://www.coursera.org/learn/data-analysis-r/home/module/1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-analysis-r/home/module/1">Data Analysis with R Programming</a>
  </body>
</html>
</richcontent>
<node TEXT="Glossary" FOLDED="true" ID="ID_1270131475" CREATED="1710459400699" MODIFIED="1710459404688">
<node TEXT="A/B testing: The process of testing two variations of the same web page to determine which page is more successful at attracting user traffic and generating revenue" ID="ID_485166209" CREATED="1710460169140" MODIFIED="1710460169140"/>
<node TEXT="Absolute reference: A reference within a function that is locked so that rows and columns won’t change if the function is copied" ID="ID_228306176" CREATED="1710460169140" MODIFIED="1710460169140"/>
<node TEXT="Access control: Features such as password protection, user permissions, and encryption that are used to protect a spreadsheet" ID="ID_118024218" CREATED="1710460169142" MODIFIED="1710460169142"/>
<node TEXT="Accuracy: The degree to which data conforms to the actual entity being measured or described" ID="ID_1456595258" CREATED="1710460169143" MODIFIED="1710460169143"/>
<node TEXT="Action-oriented question: A question whose answers lead to change" ID="ID_591905775" CREATED="1710460169144" MODIFIED="1710460169144"/>
<node TEXT="Administrative metadata: Metadata that indicates the technical source of a digital asset" ID="ID_1669130915" CREATED="1710460169144" MODIFIED="1710460169144"/>
<node TEXT="Agenda: A list of scheduled appointments" ID="ID_27862001" CREATED="1710460169145" MODIFIED="1710460169145"/>
<node TEXT="Aggregation: The process of collecting or gathering many separate pieces into a whole" ID="ID_849065258" CREATED="1710460169146" MODIFIED="1710460169146"/>
<node TEXT="Algorithm: A process or set of rules followed for a specific task" ID="ID_1196730617" CREATED="1710460169146" MODIFIED="1710460169146"/>
<node TEXT="Aliasing: Temporarily naming a table or column in a query to make it easier to read and write" ID="ID_1158120445" CREATED="1710460169147" MODIFIED="1710460169147"/>
<node TEXT="Alternative text: Text that provides an alternative to non-text content, such as images and videos" ID="ID_1454197824" CREATED="1710460169147" MODIFIED="1710460169147"/>
<node TEXT="Analytical skills: Qualities and characteristics associated with using facts to solve problems" ID="ID_1648232510" CREATED="1710460169148" MODIFIED="1710460169148"/>
<node TEXT="Analytical thinking: The process of identifying and defining a problem, then solving it by using data in an organized, step-by-step manner" ID="ID_398329444" CREATED="1710460169149" MODIFIED="1710460169149"/>
<node TEXT="Annotation: Text that briefly explains data or helps focus the audience on a particular aspect of the data in a visualization" ID="ID_1937735446" CREATED="1710460169149" MODIFIED="1710460169149"/>
<node TEXT="Area chart: A data visualization that uses individual data points for a changing variable connected by a continuous line with a filled in area underneath" ID="ID_1054862847" CREATED="1710460169150" MODIFIED="1710460169150"/>
<node TEXT="Array: A collection of values in spreadsheet cells" ID="ID_896439830" CREATED="1710460169152" MODIFIED="1710460169152"/>
<node TEXT="Attribute: A characteristic or quality of data used to label a column in a table" ID="ID_1413076503" CREATED="1710460169152" MODIFIED="1710460169152"/>
<node TEXT="Audio file: Digitized audio storage usually in an MP3, AAC, or other compressed format" ID="ID_1177799393" CREATED="1710460169153" MODIFIED="1710460169153"/>
<node TEXT="AVERAGE: A spreadsheet function that returns an average of the values from a selected range" ID="ID_880028638" CREATED="1710460169153" MODIFIED="1710460169153"/>
<node TEXT="AVERAGEIF: A spreadsheet function that returns the average of all cell values from a given range that meet a specified condition" ID="ID_845046738" CREATED="1710460169154" MODIFIED="1710460169154"/>
<node TEXT="Bad data source: A data source that is not reliable, original, comprehensive, current, and cited (ROCCC)" ID="ID_249688668" CREATED="1710460169154" MODIFIED="1710460169154"/>
<node TEXT="Balance: The design principle of creating aesthetic appeal and clarity in a data visualization by evenly distributing visual elements" ID="ID_1319560210" CREATED="1710460169156" MODIFIED="1710460169156"/>
<node TEXT="Bar graph: A data visualization that uses size to contrast and compare two or more values" ID="ID_514648647" CREATED="1710460169157" MODIFIED="1710460169157"/>
<node TEXT="Bias: A conscious or subconscious preference in favor of or against a person, group of people, or thing" ID="ID_1023912281" CREATED="1710460169157" MODIFIED="1710460169157"/>
<node TEXT="Big data: Large, complex datasets typically involving long periods of time, which enable data analysts to address far-reaching business problems" ID="ID_677301377" CREATED="1710460169158" MODIFIED="1710460169158"/>
<node TEXT="Boolean data: A data type with only two possible values, usually true or false" ID="ID_1431701786" CREATED="1710460169159" MODIFIED="1710460169159"/>
<node TEXT="Borders: Lines that can be added around two or more cells on a spreadsheet" ID="ID_1623337263" CREATED="1710460169160" MODIFIED="1710460169160"/>
<node TEXT="Box plot: A data visualization that displays the distribution of values along an x-axis" ID="ID_1745637823" CREATED="1710460169161" MODIFIED="1710460169161"/>
<node TEXT="Bubble chart: A data visualization that displays individual data points as bubbles, comparing numeric values by their relative size" ID="ID_236017839" CREATED="1710460169161" MODIFIED="1710460169161"/>
<node TEXT="Bullet graph: A data visualization that displays data as a horizontal bar chart moving toward a desired value" ID="ID_230001014" CREATED="1710460169162" MODIFIED="1710460169162"/>
<node TEXT="Business metric: A standard of measurement used to solve a business task" ID="ID_1159713719" CREATED="1710460169163" MODIFIED="1710460169163"/>
<node TEXT="Business task: The question or problem data analysis resolves for a business" ID="ID_634994765" CREATED="1710460169164" MODIFIED="1710460169164"/>
<node TEXT="Calculated field: A new field within a pivot table that carries out certain calculations based on the values of other fields" ID="ID_1442628902" CREATED="1710460169165" MODIFIED="1710460169165"/>
<node TEXT="Calculus: A branch of mathematics that involves the study of rates of change and the changes between values that are related by a function" ID="ID_347361673" CREATED="1710460169166" MODIFIED="1710460169166"/>
<node TEXT="CASE: A SQL statement that returns records that meet conditions by including an if/then statement in a query" ID="ID_1392618171" CREATED="1710460169167" MODIFIED="1710460169167"/>
<node TEXT="CAST: A SQL function that converts data from one datatype to another" ID="ID_1738087725" CREATED="1710460169167" MODIFIED="1710460169167"/>
<node TEXT="Causation: When an action directly leads to an outcome, such as a cause-effect relationship" ID="ID_1067940095" CREATED="1710460169168" MODIFIED="1710460169168"/>
<node TEXT="Cell reference: A cell or a range of cells in a worksheet typically used in formulas and functions" ID="ID_1042074091" CREATED="1710460169169" MODIFIED="1710460169169"/>
<node TEXT="Changelog: A file containing a chronologically ordered list of modifications made to a project" ID="ID_1855429823" CREATED="1710460169169" MODIFIED="1710460169169"/>
<node TEXT="Channel: A visual aspect or variable that represents characteristics of the data in a visualization" ID="ID_832601387" CREATED="1710460169170" MODIFIED="1710460169170"/>
<node TEXT="Chart: A graphical representation of data from a worksheet" ID="ID_589442686" CREATED="1710460169172" MODIFIED="1710460169172"/>
<node TEXT="Circle view: A data visualization that shows comparative strength in data" ID="ID_1704965784" CREATED="1710460169172" MODIFIED="1710460169172"/>
<node TEXT="Clean data: Data that is complete, correct, and relevant to the problem being solved" ID="ID_333022067" CREATED="1710460169172" MODIFIED="1710460169172"/>
<node TEXT="Cloud: A place to keep data online, rather than a computer hard drive" ID="ID_388846897" CREATED="1710460169173" MODIFIED="1710460169173"/>
<node TEXT="Cluster: A collection of data points on a data visualization with similar values" ID="ID_1800979415" CREATED="1710460169173" MODIFIED="1710460169173"/>
<node TEXT="COALESCE: A SQL function that returns non-null values in a list" ID="ID_1302553992" CREATED="1710460169174" MODIFIED="1710460169174"/>
<node TEXT="Coding: The process of writing instructions to a computer in the syntax of a specific programming language" ID="ID_1519671106" CREATED="1710460169174" MODIFIED="1710460169174"/>
<node TEXT="Column chart: A data visualization that uses individual data points for a changing variable, represented as vertical columns" ID="ID_1995643758" CREATED="1710460169175" MODIFIED="1710460169175"/>
<node TEXT="Combo chart: A data visualization that combines more than one visualization type" ID="ID_1111496212" CREATED="1710460169175" MODIFIED="1710460169175"/>
<node TEXT="Compatibility: How well two or more datasets are able to work together" ID="ID_1707666669" CREATED="1710460169176" MODIFIED="1710460169176"/>
<node TEXT="Completeness: The degree to which data contains all desired components or measures" ID="ID_1552271879" CREATED="1710460169177" MODIFIED="1710460169177"/>
<node TEXT="Computer programming: The process of giving instructions to a computer in order to perform an action or set of actions" ID="ID_972001570" CREATED="1710460169177" MODIFIED="1710460169177"/>
<node TEXT="CONCAT: A SQL function that adds strings together to create new text strings that can be used as unique keys" ID="ID_821258254" CREATED="1710460169178" MODIFIED="1710460169178"/>
<node TEXT="CONCATENATE: A spreadsheet function that joins together two or more text strings" ID="ID_332714760" CREATED="1710460169179" MODIFIED="1710460169179"/>
<node TEXT="Conditional formatting: A spreadsheet tool that changes how cells appear when values meet specific conditions" ID="ID_271686367" CREATED="1710460169180" MODIFIED="1710460169180"/>
<node TEXT="Confidence interval: A range of values that conveys how likely a statistical estimate reflects the population" ID="ID_187047689" CREATED="1710460169180" MODIFIED="1710460169180"/>
<node TEXT="Confidence level: The probability that a sample size accurately reflects the greater population" ID="ID_1295644568" CREATED="1710460169182" MODIFIED="1710460169182"/>
<node TEXT="Confirmation bias: The tendency to search for or interpret information in a way that confirms pre-existing beliefs" ID="ID_283384232" CREATED="1710460169183" MODIFIED="1710460169183"/>
<node TEXT="Consent: The aspect of data ethics that presumes an individual’s right to know how and why their personal data will be used before agreeing to provide it" ID="ID_20911385" CREATED="1710460169185" MODIFIED="1710460169185"/>
<node TEXT="Consistency: The degree to which data is repeatable from different points of entry or collection" ID="ID_982797921" CREATED="1710460169185" MODIFIED="1710460169185"/>
<node TEXT="Context: The condition in which something exists or happens" ID="ID_1100317372" CREATED="1710460169186" MODIFIED="1710460169186"/>
<node TEXT="Continuous data: Data that is measured and can have almost any numeric value" ID="ID_274877514" CREATED="1710460169187" MODIFIED="1710460169187"/>
<node TEXT="CONVERT: A SQL function that changes the unit of measurement of a value in data" ID="ID_1325702941" CREATED="1710460169188" MODIFIED="1710460169188"/>
<node TEXT="Cookie: A small file stored on a computer that contains information about its users" ID="ID_731162533" CREATED="1710460169188" MODIFIED="1710460169188"/>
<node TEXT="Correlation: The measure of the degree to which two variables change in relationship to each other" ID="ID_1882965886" CREATED="1710460169189" MODIFIED="1710460169189"/>
<node TEXT="COUNT: A spreadsheet function that counts the number of cells within a range that meet a specified condition" ID="ID_879552410" CREATED="1710460169190" MODIFIED="1710460169190"/>
<node TEXT="COUNTA: A spreadsheet function that counts the total number of values within a range that meet specified criteria" ID="ID_472900987" CREATED="1710460169191" MODIFIED="1710460169191"/>
<node TEXT="COUNTIF: A spreadsheet function that returns the number of cells in a range that match a specified value" ID="ID_1994432097" CREATED="1710460169191" MODIFIED="1710460169191"/>
<node TEXT="COUNT DISTINCT: A SQL function that only returns the distinct values in a specified range" ID="ID_458386825" CREATED="1710460169193" MODIFIED="1710460169193"/>
<node TEXT="CREATE TABLE: A SQL clause that adds a temporary table to a database that can be used by multiple people" ID="ID_919240873" CREATED="1710460169193" MODIFIED="1710460169193"/>
<node TEXT="Cross-field validation: A process that ensures certain conditions for multiple data fields are satisfied" ID="ID_585569109" CREATED="1710460169194" MODIFIED="1710460169194"/>
<node TEXT="CSS (Cascading Style Sheets): A programming language used for web page design that controls graphic elements and page presentation" ID="ID_394691767" CREATED="1710460169195" MODIFIED="1710460169195"/>
<node TEXT="CSV (comma-separated values) file: A delimited text file that uses a comma to separate values" ID="ID_611755131" CREATED="1710460169196" MODIFIED="1710460169196"/>
<node TEXT="Currency: The aspect of data ethics that presumes individuals should be aware of financial transactions resulting from the use of their personal data and the scale of those transactions" ID="ID_1713779712" CREATED="1710460169197" MODIFIED="1710460169197"/>
<node TEXT="Dashboard: A tool that monitors live, incoming data" ID="ID_1531718963" CREATED="1710460169197" MODIFIED="1710460169197"/>
<node TEXT="Dashboard filter: A tool for showing only the data that meets a specific criteria while hiding the rest" ID="ID_999994929" CREATED="1710460169198" MODIFIED="1710460169198"/>
<node TEXT="Data: A collection of facts" ID="ID_40807145" CREATED="1710460169199" MODIFIED="1710460169199"/>
<node TEXT="Data aggregation: The process of gathering data from multiple sources and combining it into a single, summarized collection" ID="ID_680953815" CREATED="1710460169200" MODIFIED="1710460169200"/>
<node TEXT="Data analysis: The collection, transformation, and organization of data in order to draw conclusions, make predictions, and drive informed decision-making" ID="ID_1912194796" CREATED="1710460169200" MODIFIED="1710460169200"/>
<node TEXT="Data analysis process: The six phases of ask, prepare, process, analyze, share, and act whose purpose is to gain insights that drive informed decision-making" ID="ID_1956359176" CREATED="1710460169201" MODIFIED="1710460169201"/>
<node TEXT="Data analyst: Someone who collects, transforms, and organizes data in order to draw conclusions, make predictions, and drive informed decision-making" ID="ID_629395090" CREATED="1710460169202" MODIFIED="1710460169202"/>
<node TEXT="Data analytics: The science of data" ID="ID_169979300" CREATED="1710460169203" MODIFIED="1710460169203"/>
<node TEXT="Data anonymization: The process of protecting people&apos;s private or sensitive data by eliminating identifying information" ID="ID_1082489433" CREATED="1710460169204" MODIFIED="1710460169204"/>
<node TEXT="Data bias: When a preference in favor of or against a person, group of people, or thing systematically skews data analysis results in a certain direction" ID="ID_79098797" CREATED="1710460169204" MODIFIED="1710460169204"/>
<node TEXT="Data blending: A Tableau method that combines data from multiple data sources" ID="ID_771400052" CREATED="1710460169206" MODIFIED="1710460169206"/>
<node TEXT="Data composition: The process of combining the individual parts in a visualization and displaying them together as a whole" ID="ID_445011802" CREATED="1710460169207" MODIFIED="1710460169207"/>
<node TEXT="Data constraints: The criteria that determine whether a piece of a data is clean and valid" ID="ID_1638250957" CREATED="1710460169207" MODIFIED="1710460169207"/>
<node TEXT="Data design: How information is organized" ID="ID_1906065168" CREATED="1710460169208" MODIFIED="1710460169208"/>
<node TEXT="Data-driven decision-making: Using facts to guide business strategy" ID="ID_671417691" CREATED="1710460169209" MODIFIED="1710460169209"/>
<node TEXT="Data ecosystem: The various elements that interact with one another in order to produce, manage, store, organize, analyze, and share data" ID="ID_370844940" CREATED="1710460169209" MODIFIED="1710460169209"/>
<node TEXT="Data element: A piece of information in a dataset" ID="ID_106815376" CREATED="1710460169210" MODIFIED="1710460169210"/>
<node TEXT="Data engineer: A professional who transforms data into a useful format for analysis and gives it a reliable infrastructure" ID="ID_1330655607" CREATED="1710460169211" MODIFIED="1710460169211"/>
<node TEXT="Data ethics: Well-founded standards of right and wrong that dictate how data is collected, shared, and used" ID="ID_1997248529" CREATED="1710460169211" MODIFIED="1710460169211"/>
<node TEXT="Data governance: A process for ensuring the formal management of a company’s data assets" ID="ID_1172637174" CREATED="1710460169212" MODIFIED="1710460169212"/>
<node TEXT="Data-inspired decision-making: Exploring different data sources to find out what they have in common" ID="ID_1350063004" CREATED="1710460169212" MODIFIED="1710460169212"/>
<node TEXT="Data integrity: The accuracy, completeness, consistency, and trustworthiness of data throughout its life cycle" ID="ID_395021231" CREATED="1710460169213" MODIFIED="1710460169213"/>
<node TEXT="Data interoperability: The ability to integrate data from multiple sources and a key factor leading to the successful use of open data among companies and governments" ID="ID_620785835" CREATED="1710460169214" MODIFIED="1710460169214"/>
<node TEXT="Data life cycle: The sequence of stages that data experiences, which include plan, capture, manage, analyze, archive, and destroy" ID="ID_1210010883" CREATED="1710460169215" MODIFIED="1710460169215"/>
<node TEXT="Data manipulation: The process of changing data to make it more organized and easier to read" ID="ID_446370545" CREATED="1710460169216" MODIFIED="1710460169216"/>
<node TEXT="Data mapping: The process of matching fields from one data source to another" ID="ID_520857949" CREATED="1710460169216" MODIFIED="1710460169216"/>
<node TEXT="Data merging: The process of combining two or more datasets into a single dataset" ID="ID_1238640495" CREATED="1710460169217" MODIFIED="1710460169217"/>
<node TEXT="Data model: A tool for organizing data elements and how they relate to one another" ID="ID_1719943538" CREATED="1710460169217" MODIFIED="1710460169217"/>
<node TEXT="Data privacy: Preserving a data subject’s information any time a data transaction occurs" ID="ID_1854092144" CREATED="1710460169218" MODIFIED="1710460169218"/>
<node TEXT="Data range: Numerical values that fall between predefined maximum and minimum values" ID="ID_1004574764" CREATED="1710460169219" MODIFIED="1710460169219"/>
<node TEXT="Data replication: The process of storing data in multiple locations" ID="ID_1118796732" CREATED="1710460169219" MODIFIED="1710460169219"/>
<node TEXT="Data science: A field of study that uses raw data to create new ways of modeling and understanding the unknown" ID="ID_1229471849" CREATED="1710460169220" MODIFIED="1710460169220"/>
<node TEXT="Data security: Protecting data from unauthorized access or corruption by adopting safety measures" ID="ID_1038230864" CREATED="1710460169220" MODIFIED="1710460169220"/>
<node TEXT="Data storytelling: Communicating the meaning of a dataset with visuals and a narrative that are customized for an audience" ID="ID_832979503" CREATED="1710460169221" MODIFIED="1710460169221"/>
<node TEXT="Data strategy: The management of the people, processes, and tools used in data analysis" ID="ID_276336026" CREATED="1710460169222" MODIFIED="1710460169222"/>
<node TEXT="Data transfer: The process of copying data from a storage device to computer memory or from one computer to another" ID="ID_367058210" CREATED="1710460169222" MODIFIED="1710460169222"/>
<node TEXT="Data type: An attribute that describes a piece of data based on its values, its programming language, or the operations it can perform" ID="ID_895359436" CREATED="1710460169223" MODIFIED="1710460169223"/>
<node TEXT="Data validation: A tool for checking the accuracy and quality of data" ID="ID_680406984" CREATED="1710460169225" MODIFIED="1710460169225"/>
<node TEXT="Data validation process: The process of checking and rechecking the quality of data so that it is complete, accurate, secure and consistent" ID="ID_287065921" CREATED="1710460169225" MODIFIED="1710460169225"/>
<node TEXT="Data visualization: The graphical representation of data" ID="ID_1018491241" CREATED="1710460169226" MODIFIED="1710460169226"/>
<node TEXT="Data warehousing specialist: A professional who develops processes and procedures to effectively store and organize data" ID="ID_704358490" CREATED="1710460169227" MODIFIED="1710460169227"/>
<node TEXT="Database: A collection of data stored in a computer system" ID="ID_1139629912" CREATED="1710460169227" MODIFIED="1710460169227"/>
<node TEXT="Dataset: A collection of data that can be manipulated or analyzed as one unit" ID="ID_1895891872" CREATED="1710460169228" MODIFIED="1710460169228"/>
<node TEXT="DATEDIF: A spreadsheet function that calculates the number of days, months, or years between two dates" ID="ID_610925442" CREATED="1710460169228" MODIFIED="1710460169228"/>
<node TEXT="Decision tree: A tool that helps analysts make decisions about critical features of a visualization" ID="ID_1313471426" CREATED="1710460169229" MODIFIED="1710460169229"/>
<node TEXT="Delimiter: A character that indicates the beginning or end of a data item" ID="ID_1507088102" CREATED="1710460169230" MODIFIED="1710460169230"/>
<node TEXT="Density map: A data visualization that represents concentrations, with color representing the number or frequency of data points in a given area on a map" ID="ID_1415876567" CREATED="1710460169230" MODIFIED="1710460169230"/>
<node TEXT="Descriptive metadata: Metadata that describes a piece of data and can be used to identify it at a later point in time" ID="ID_151100097" CREATED="1710460169232" MODIFIED="1710460169232"/>
<node TEXT="Design thinking: A process used to solve complex problems in a user-centric way" ID="ID_985789458" CREATED="1710460169233" MODIFIED="1710460169233"/>
<node TEXT="Digital photo: An electronic or computer-based image usually in BMP or JPG format" ID="ID_1863806933" CREATED="1710460169234" MODIFIED="1710460169234"/>
<node TEXT="Dirty data: Data that is incomplete, incorrect, or irrelevant to the problem to be solved" ID="ID_898434043" CREATED="1710460169235" MODIFIED="1710460169235"/>
<node TEXT="Discrete data: Data that is counted and has a limited number of values" ID="ID_926740013" CREATED="1710460169236" MODIFIED="1710460169236"/>
<node TEXT="DISTINCT: A keyword that is added to a SQL SELECT statement to retrieve only non-duplicate entries" ID="ID_606131519" CREATED="1710460169237" MODIFIED="1710460169237"/>
<node TEXT="Distribution graph: A data visualization that displays the frequency of various outcomes in a sample" ID="ID_297839664" CREATED="1710460169237" MODIFIED="1710460169237"/>
<node TEXT="Diverging color palette: A color theme that displays two ranges of data values using two different hues, with color intensity representing the magnitude of the values" ID="ID_1628999005" CREATED="1710460169239" MODIFIED="1710460169239"/>
<node TEXT="Donut chart: A data visualization where segments of a ring represent data values adding up to a whole" ID="ID_1060076551" CREATED="1710460169240" MODIFIED="1710460169240"/>
<node TEXT="DROP TABLE: A SQL clause that removes a temporary table from a database" ID="ID_390376348" CREATED="1710460169240" MODIFIED="1710460169240"/>
<node TEXT="Duplicate data: Any record that inadvertently shares data with another record" ID="ID_1624506951" CREATED="1710460169241" MODIFIED="1710460169241"/>
<node TEXT="Dynamic visualizations: Data visualizations that are interactive or change over time" ID="ID_1199058190" CREATED="1710460169241" MODIFIED="1710460169241"/>
<node TEXT="Emphasis: The design principle of arranging visual elements to focus the audience’s attention on important information in a data visualization" ID="ID_1713646470" CREATED="1710460169242" MODIFIED="1710460169242"/>
<node TEXT="Engagement: Capturing and holding someone’s interest and attention during a data presentation" ID="ID_823282024" CREATED="1710460169242" MODIFIED="1710460169242"/>
<node TEXT="Equation: A calculation that involves addition, subtraction, multiplication, or division (also called a math expression)" ID="ID_476330272" CREATED="1710460169243" MODIFIED="1710460169243"/>
<node TEXT="Estimated response rate: The average number of people who typically complete a survey" ID="ID_587945377" CREATED="1710460169244" MODIFIED="1710460169244"/>
<node TEXT="Ethics: Well-founded standards of right and wrong that prescribe what humans ought to do, usually in terms of rights, obligations, benefits to society, fairness, or specific virtues" ID="ID_1100783883" CREATED="1710460169244" MODIFIED="1710460169244"/>
<node TEXT="External data: Data that lives, and is generated, outside of an organization" ID="ID_1089873024" CREATED="1710460169246" MODIFIED="1710460169246"/>
<node TEXT="Fairness: A quality of data analysis that does not create or reinforce bias" ID="ID_1505179972" CREATED="1710460169246" MODIFIED="1710460169246"/>
<node TEXT="Field: A single piece of information from a row or column of a spreadsheet; in a data table, typically a column in the table" ID="ID_1919143212" CREATED="1710460169247" MODIFIED="1710460169247"/>
<node TEXT="Field length: A tool for determining how many characters can be keyed into a spreadsheet field" ID="ID_1495155958" CREATED="1710460169247" MODIFIED="1710460169247"/>
<node TEXT="Fill handle: A box in the lower-right-hand corner of a selected spreadsheet cell that can be dragged through neighboring cells in order to continue an instruction" ID="ID_1045437748" CREATED="1710460169248" MODIFIED="1710460169248"/>
<node TEXT="Filled map: A data visualization that colors areas in a map based on measurements or dimensions" ID="ID_1013080099" CREATED="1710460169249" MODIFIED="1710460169249"/>
<node TEXT="Filtering: The process of showing only the data that meets a specified criteria while hiding the rest" ID="ID_234777962" CREATED="1710460169249" MODIFIED="1710460169249"/>
<node TEXT="Find and replace: A tool that finds a specified search term and replaces it with something else" ID="ID_1568383030" CREATED="1710460169251" MODIFIED="1710460169251"/>
<node TEXT="First-party data: Data collected by an individual or group using their own resources" ID="ID_1616404516" CREATED="1710460169252" MODIFIED="1710460169252"/>
<node TEXT="Float: A number that contains a decimal" ID="ID_1622710795" CREATED="1710460169253" MODIFIED="1710460169253"/>
<node TEXT="Foreign key: A field within a database table that is a primary key in another table (Refer to primary key)" ID="ID_1300936110" CREATED="1710460169253" MODIFIED="1710460169253"/>
<node TEXT="Formula: A set of instructions used to perform a calculation using the data in a spreadsheet" ID="ID_850450253" CREATED="1710460169254" MODIFIED="1710460169254"/>
<node TEXT="Framework: The context a presentation needs to create logical connections that tie back to the business task and metrics" ID="ID_1654895843" CREATED="1710460169254" MODIFIED="1710460169254"/>
<node TEXT="FROM: The section of a query that indicates from which table(s) to extract the data" ID="ID_1344535656" CREATED="1710460169255" MODIFIED="1710460169255"/>
<node TEXT="Function: A preset command that automatically performs a specified process or task using the data in a spreadsheet" ID="ID_828485483" CREATED="1710460169256" MODIFIED="1710460169256"/>
<node TEXT="Gantt chart: A data visualization that displays the duration of events or activities on a timeline" ID="ID_1393190540" CREATED="1710460169257" MODIFIED="1710460169257"/>
<node TEXT="Gap analysis: A method for examining and evaluating the current state of a process in order to identify opportunities for improvement in the future" ID="ID_1030119622" CREATED="1710460169257" MODIFIED="1710460169257"/>
<node TEXT="Gauge chart: A data visualization that shows a single result within a progressive range of values" ID="ID_1101123754" CREATED="1710460169258" MODIFIED="1710460169258"/>
<node TEXT="General Data Protection Regulation of the European Union (GDPR): Policy-making body in the European Union created to help protect people and their data" ID="ID_516573237" CREATED="1710460169259" MODIFIED="1710460169259"/>
<node TEXT="Geolocation: The geographical location of a person or device by means of digital information" ID="ID_1483387808" CREATED="1710460169260" MODIFIED="1710460169260"/>
<node TEXT="Good data source: A data source that is reliable, original, comprehensive, current, and cited (ROCCC)" ID="ID_680833493" CREATED="1710460169261" MODIFIED="1710460169261"/>
<node TEXT="GROUP BY: A SQL clause that groups rows that have the same values from a table into summary rows" ID="ID_296507104" CREATED="1710460169261" MODIFIED="1710460169261"/>
<node TEXT="HAVING: A SQL clause that adds a filter to a query instead of the underlying table that can only be used with aggregate functions" ID="ID_661661246" CREATED="1710460169263" MODIFIED="1710460169263"/>
<node TEXT="Header: The first row in a spreadsheet that labels the type of data in each column" ID="ID_520904615" CREATED="1710460169264" MODIFIED="1710460169264"/>
<node TEXT="Headline: Text at the top of a visualization that communicates the data being presented" ID="ID_1954973271" CREATED="1710460169264" MODIFIED="1710460169264"/>
<node TEXT="Heat map: A data visualization that uses color contrast to compare categories in a dataset" ID="ID_262525622" CREATED="1710460169264" MODIFIED="1710460169264"/>
<node TEXT="Highlight table: A data visualization that uses conditional formatting and color on a table" ID="ID_1732353092" CREATED="1710460169266" MODIFIED="1710460169266"/>
<node TEXT="Histogram: A data visualization that shows how often data values fall into certain ranges" ID="ID_1925111763" CREATED="1710460169267" MODIFIED="1710460169267"/>
<node TEXT="HTML5: A programming language that provides structure for web pages and connects to hosting platforms" ID="ID_1953519742" CREATED="1710460169267" MODIFIED="1710460169267"/>
<node TEXT="Hypothesis: A theory that one might try to prove or disprove with data" ID="ID_554871148" CREATED="1710460169268" MODIFIED="1710460169268"/>
<node TEXT="Hypothesis testing: A process to determine if a survey or experiment has meaningful results" ID="ID_1373301099" CREATED="1710460169268" MODIFIED="1710460169268"/>
<node TEXT="IDE (Integrated Development Environment): A software application that brings together all the tools a data analyst may want to use in a single place" ID="ID_650697716" CREATED="1710460169269" MODIFIED="1710460169269"/>
<node TEXT="Incomplete data: Data that is missing important fields" ID="ID_1193944526" CREATED="1710460169270" MODIFIED="1710460169270"/>
<node TEXT="Inconsistent data: Data that uses different formats to represent the same thing" ID="ID_215749890" CREATED="1710460169271" MODIFIED="1710460169271"/>
<node TEXT="Incorrect/inaccurate data: Data that is complete but inaccurate" ID="ID_1244155394" CREATED="1710460169271" MODIFIED="1710460169271"/>
<node TEXT="INNER JOIN : A SQL function that returns records with matching values in both tables" ID="ID_1214684653" CREATED="1710460169272" MODIFIED="1710460169272"/>
<node TEXT="Inner query: A SQL subquery that is inside of another SQL statement" ID="ID_848673757" CREATED="1710460169272" MODIFIED="1710460169272"/>
<node TEXT="Internal data: Data that lives within a company’s own systems" ID="ID_1802763890" CREATED="1710460169273" MODIFIED="1710460169273"/>
<node TEXT="Interpretation bias: The tendency to interpret ambiguous situations in a positive or negative way" ID="ID_1397111390" CREATED="1710460169273" MODIFIED="1710460169273"/>
<node TEXT="Java: A programming language widely used to create enterprise web applications that can run on multiple clients" ID="ID_735640513" CREATED="1710460169274" MODIFIED="1710460169274"/>
<node TEXT="JOIN: A SQL function that is used to combine rows from two or more tables based on a related column" ID="ID_243291515" CREATED="1710460169274" MODIFIED="1710460169274"/>
<node TEXT="Label: Text in a visualization that identifies a value or describes a scale" ID="ID_330682173" CREATED="1710460169276" MODIFIED="1710460169276"/>
<node TEXT="Leading question: A question that steers people toward a certain response" ID="ID_1229533670" CREATED="1710460169276" MODIFIED="1710460169276"/>
<node TEXT="LEFT: A function that returns a set number of characters from the left side of a text string" ID="ID_1029709439" CREATED="1710460169277" MODIFIED="1710460169277"/>
<node TEXT="LEFT JOIN: A SQL function that will return all the records from the left table and only the matching records from the right table" ID="ID_133406787" CREATED="1710460169277" MODIFIED="1710460169277"/>
<node TEXT="Legend: A tool that identifies the meaning of various elements in a data visualization" ID="ID_479706056" CREATED="1710460169278" MODIFIED="1710460169278"/>
<node TEXT="LEN: A function that returns the length of a text string by counting the number of characters it contains" ID="ID_906310908" CREATED="1710460169278" MODIFIED="1710460169278"/>
<node TEXT="Length: The number of characters in a text string" ID="ID_1022110529" CREATED="1710460169279" MODIFIED="1710460169279"/>
<node TEXT="LIMIT: A SQL clause that specifies the maximum number of records returned in a query" ID="ID_1820413043" CREATED="1710460169280" MODIFIED="1710460169280"/>
<node TEXT="Line graph: A data visualization that uses one or more lines to display shifts or changes in data over time" ID="ID_1040364405" CREATED="1710460169280" MODIFIED="1710460169280"/>
<node TEXT="Live data: Data that is automatically updated" ID="ID_548254453" CREATED="1710460169281" MODIFIED="1710460169281"/>
<node TEXT="Long data: A dataset in which each row is one time point per subject, so each subject has data in multiple rows" ID="ID_924182171" CREATED="1710460169282" MODIFIED="1710460169282"/>
<node TEXT="Mandatory: A data value that cannot be left blank or empty" ID="ID_403771509" CREATED="1710460169283" MODIFIED="1710460169283"/>
<node TEXT="Map: A data visualization that organizes data geographically" ID="ID_401596006" CREATED="1710460169284" MODIFIED="1710460169284"/>
<node TEXT="Margin of error: The maximum amount that sample results are expected to differ from those of the actual population" ID="ID_1742789933" CREATED="1710460169284" MODIFIED="1710460169284"/>
<node TEXT="Mark: A visual object in a data visualization such as a point, line, or shape" ID="ID_1956059912" CREATED="1710460169285" MODIFIED="1710460169285"/>
<node TEXT="MATCH: A spreadsheet function used to locate the position of a specific lookup value" ID="ID_677442911" CREATED="1710460169286" MODIFIED="1710460169286"/>
<node TEXT="Math expression: A calculation that involves addition, subtraction, multiplication, or division (also called an equation)" ID="ID_275231964" CREATED="1710460169286" MODIFIED="1710460169286"/>
<node TEXT="Math function: A function that is used as part of a mathematical formula" ID="ID_767968088" CREATED="1710460169287" MODIFIED="1710460169287"/>
<node TEXT="MAX: A function that returns the largest numeric value from a range of cells" ID="ID_1321680399" CREATED="1710460169288" MODIFIED="1710460169288"/>
<node TEXT="MAXIFS: A spreadsheet function that returns the maximum value from a given range that meets a specified condition" ID="ID_1918039498" CREATED="1710460169289" MODIFIED="1710460169289"/>
<node TEXT="McCandless Method: A method for presenting data visualizations that moves from general to specific information" ID="ID_749948608" CREATED="1710460169289" MODIFIED="1710460169289"/>
<node TEXT="Measurable question: A question whose answers can be quantified and assessed" ID="ID_1728634381" CREATED="1710460169290" MODIFIED="1710460169290"/>
<node TEXT="Mental model: A data analyst’s thought process and approach to a problem" ID="ID_865319926" CREATED="1710460169291" MODIFIED="1710460169291"/>
<node TEXT="Mentor: Someone who shares knowledge, skills, and experience to help another grow both professionally and personally" ID="ID_50385875" CREATED="1710460169292" MODIFIED="1710460169292"/>
<node TEXT="Merger: An agreement that unites two organizations into a single new one" ID="ID_588276932" CREATED="1710460169292" MODIFIED="1710460169292"/>
<node TEXT="Metadata: Data about data" ID="ID_1774544577" CREATED="1710460169293" MODIFIED="1710460169293"/>
<node TEXT="Metadata repository: A database created to store metadata" ID="ID_1208697277" CREATED="1710460169294" MODIFIED="1710460169294"/>
<node TEXT="Metric: A single, quantifiable type of data that is used for measurement" ID="ID_981578116" CREATED="1710460169295" MODIFIED="1710460169295"/>
<node TEXT="Metric goal: A measurable goal set by a company and evaluated using metrics" ID="ID_1035467901" CREATED="1710460169296" MODIFIED="1710460169296"/>
<node TEXT="MID: A function that returns a segment from the middle of a text string" ID="ID_513292195" CREATED="1710460169296" MODIFIED="1710460169296"/>
<node TEXT="MIN: A spreadsheet function that returns the smallest numeric value from a range of cells" ID="ID_1924799243" CREATED="1710460169297" MODIFIED="1710460169297"/>
<node TEXT="MINIFS: A spreadsheet function that returns the minimum value from a given range that meets a specified condition" ID="ID_1777741454" CREATED="1710460169298" MODIFIED="1710460169298"/>
<node TEXT="Modulo: An operator (%) that returns the remainder when one number is divided by another" ID="ID_73815057" CREATED="1710460169299" MODIFIED="1710460169299"/>
<node TEXT="Movement: The design principle of arranging visual elements to guide the audience’s eyes from one part of a data visualization to another" ID="ID_1113338479" CREATED="1710460169300" MODIFIED="1710460169300"/>
<node TEXT="Naming conventions: Consistent guidelines that describe the content, creation date, and version of a file in its name" ID="ID_968191846" CREATED="1710460169301" MODIFIED="1710460169301"/>
<node TEXT="Narrative: (Refer to story)" ID="ID_385314743" CREATED="1710460169301" MODIFIED="1710460169301"/>
<node TEXT="Networking: Building relationships by meeting people both in person and online" ID="ID_308771176" CREATED="1710460169302" MODIFIED="1710460169302"/>
<node TEXT="Nominal data: A type of qualitative data that is categorized without a set order" ID="ID_1174728541" CREATED="1710460169303" MODIFIED="1710460169303"/>
<node TEXT="Normalized database: A database in which only related data is stored in each table" ID="ID_66563809" CREATED="1710460169304" MODIFIED="1710460169304"/>
<node TEXT="Notebook: An interactive, editable programming environment for creating data reports and showcasing data skills" ID="ID_368907255" CREATED="1710460169304" MODIFIED="1710460169304"/>
<node TEXT="Null: An indication that a value does not exist in a dataset" ID="ID_1537533092" CREATED="1710460169305" MODIFIED="1710460169305"/>
<node TEXT="Observation: The attributes that describe a piece of data contained in a row of a table" ID="ID_553376231" CREATED="1710460169306" MODIFIED="1710460169306"/>
<node TEXT="Observer bias: The tendency for different people to observe things differently (also called experimenter bias)" ID="ID_616599722" CREATED="1710460169306" MODIFIED="1710460169306"/>
<node TEXT="Observer bias: The tendency for different people to observe things differently (also called experimenter bias)" ID="ID_1228882000" CREATED="1710460169307" MODIFIED="1710460169307"/>
<node TEXT="Open data: Data that is available to the public" ID="ID_1164972192" CREATED="1710460169308" MODIFIED="1710460169308"/>
<node TEXT="Open-source: Code that is freely available and may be modified and shared by the people who use it" ID="ID_20061460" CREATED="1710460169308" MODIFIED="1710460169308"/>
<node TEXT="Openness: The aspect of data ethics that promotes the free access, usage, and sharing of data" ID="ID_1028624505" CREATED="1710460169309" MODIFIED="1710460169309"/>
<node TEXT="Operator: A symbol that names the operation or calculation to be performed" ID="ID_1339764947" CREATED="1710460169310" MODIFIED="1710460169310"/>
<node TEXT="ORDER BY: A SQL clause that sorts results returned in a query" ID="ID_73290145" CREATED="1710460169310" MODIFIED="1710460169310"/>
<node TEXT="Order of operations: Using parentheses to group together spreadsheet values in order to clarify the order in which operations should be performed" ID="ID_104246843" CREATED="1710460169311" MODIFIED="1710460169311"/>
<node TEXT="Ordinal data: Qualitative data with a set order or scale" ID="ID_67507847" CREATED="1710460169311" MODIFIED="1710460169311"/>
<node TEXT="Outdated data: Any data that has been superseded by newer and more accurate information" ID="ID_183887747" CREATED="1710460169312" MODIFIED="1710460169312"/>
<node TEXT="OUTER JOIN: A SQL function that combines RIGHT and LEFT JOIN to return all matching records in both tables" ID="ID_742338640" CREATED="1710460169315" MODIFIED="1710460169315"/>
<node TEXT="Outer query: A SQL statement containing a subquery" ID="ID_483538819" CREATED="1710460169321" MODIFIED="1710460169321"/>
<node TEXT="Ownership: The aspect of data ethics that presumes individuals own the raw data they provide and have primary control over its usage, processing, and sharing" ID="ID_1548188406" CREATED="1710460169323" MODIFIED="1710460169323"/>
<node TEXT="Packed bubble chart: A data visualization that displays data in clustered circles" ID="ID_1633658552" CREATED="1710460169323" MODIFIED="1710460169323"/>
<node TEXT="Pattern: The design principle of using similar visual elements to demonstrate trends and relationships in a data visualization" ID="ID_1452970668" CREATED="1710460169324" MODIFIED="1710460169324"/>
<node TEXT="PHP (Hypertext Preprocessor): A programming language for web application development" ID="ID_157073299" CREATED="1710460169325" MODIFIED="1710460169325"/>
<node TEXT="Pie chart: A data visualization that uses segments of a circle to represent the proportions of each data category compared to the whole" ID="ID_286816358" CREATED="1710460169328" MODIFIED="1710460169328"/>
<node TEXT="Pivot chart: A chart created from the fields in a pivot table" ID="ID_287378936" CREATED="1710460169329" MODIFIED="1710460169329"/>
<node TEXT="Pivot table: A data summarization tool used to sort, reorganize, group, count, total, or average data" ID="ID_544519791" CREATED="1710460169329" MODIFIED="1710460169329"/>
<node TEXT="Pixel: In digital imaging, a small area of illumination on a display screen that, when combined with other adjacent areas, forms a digital image" ID="ID_1508908981" CREATED="1710460169330" MODIFIED="1710460169330"/>
<node TEXT="Population: In data analytics, all possible data values in a dataset" ID="ID_1032983782" CREATED="1710460169331" MODIFIED="1710460169331"/>
<node TEXT="Portfolio: A collection of materials that can be shared with potential employers" ID="ID_359201924" CREATED="1710460169331" MODIFIED="1710460169331"/>
<node TEXT="Pre-attentive attributes: The elements of a data visualization that an audience recognizes automatically without conscious effort" ID="ID_1931794436" CREATED="1710460169332" MODIFIED="1710460169332"/>
<node TEXT="Primary key: An identifier in a database that references a column in which each value is unique (Refer to foreign key)" ID="ID_181579631" CREATED="1710460169333" MODIFIED="1710460169333"/>
<node TEXT="Problem domain: The area of analysis that encompasses every activity affecting or affected by a problem" ID="ID_1105919918" CREATED="1710460169333" MODIFIED="1710460169333"/>
<node TEXT="Problem types: The various problems that data analysts encounter, including categorizing things, discovering connections, finding patterns, identifying themes, making predictions, and spotting something unusual" ID="ID_759463699" CREATED="1710460169334" MODIFIED="1710460169334"/>
<node TEXT="Profit margin: A percentage that indicates how many cents of profit has been generated for each dollar of sale" ID="ID_967303869" CREATED="1710460169336" MODIFIED="1710460169336"/>
<node TEXT="Programming language: A system of words and symbols used to write instructions that computers follow" ID="ID_1982697504" CREATED="1710460169337" MODIFIED="1710460169337"/>
<node TEXT="Proportion: The design principle of using the relative size and arrangement of visual elements to demonstrate information in a data visualization" ID="ID_142985111" CREATED="1710460169337" MODIFIED="1710460169337"/>
<node TEXT="Python: A general-purpose programming language" ID="ID_538293801" CREATED="1710460169338" MODIFIED="1710460169338"/>
<node TEXT="Qualitative data: A subjective and explanatory measure of a quality or characteristic" ID="ID_778143696" CREATED="1710460169339" MODIFIED="1710460169339"/>
<node TEXT="Quantitative data: A specific and objective measure, such as a number, quantity, or range" ID="ID_17891412" CREATED="1710460169339" MODIFIED="1710460169339"/>
<node TEXT="Query: A request for data or information from a database" ID="ID_1530062242" CREATED="1710460169340" MODIFIED="1710460169340"/>
<node TEXT="Query language: A computer programming language used to communicate with a database" ID="ID_986284609" CREATED="1710460169341" MODIFIED="1710460169341"/>
<node TEXT="R: A programming language used for statistical analysis, visualization, and other data analysis" ID="ID_106711090" CREATED="1710460169341" MODIFIED="1710460169341"/>
<node TEXT="Random sampling: A way of selecting a sample from a population so that every possible type of the sample has an equal chance of being chosen" ID="ID_653368574" CREATED="1710460169342" MODIFIED="1710460169342"/>
<node TEXT="Range: A collection of two or more cells in a spreadsheet" ID="ID_1033346738" CREATED="1710460169343" MODIFIED="1710460169343"/>
<node TEXT="Ranking: A system to position values of a dataset within a scale of achievement or status" ID="ID_679708822" CREATED="1710460169345" MODIFIED="1710460169345"/>
<node TEXT="Record: A collection of related data in a data table, usually synonymous with row" ID="ID_1426913950" CREATED="1710460169346" MODIFIED="1710460169346"/>
<node TEXT="Redundancy: When the same piece of data is stored in two or more places" ID="ID_1680227412" CREATED="1710460169347" MODIFIED="1710460169347"/>
<node TEXT="Reframing: The process of restating a problem or challenge, then redirecting it toward a potential resolution" ID="ID_610012762" CREATED="1710460169348" MODIFIED="1710460169348"/>
<node TEXT="Regular expression (RegEx): A rule that says the values in a table must match a prescribed pattern" ID="ID_1686731406" CREATED="1710460169348" MODIFIED="1710460169348"/>
<node TEXT="Relational database: A database that contains a series of tables that can be connected to form relationships" ID="ID_828469172" CREATED="1710460169349" MODIFIED="1710460169349"/>
<node TEXT="Relativity: The process of considering observations in relation or proportion to something else" ID="ID_1878154311" CREATED="1710460169350" MODIFIED="1710460169350"/>
<node TEXT="Relevant question: A question that has significance to the problem to be solved" ID="ID_794152145" CREATED="1710460169351" MODIFIED="1710460169351"/>
<node TEXT="Remove duplicates: A spreadsheet tool that automatically searches for and eliminates duplicate entries from a spreadsheet" ID="ID_647702980" CREATED="1710460169352" MODIFIED="1710460169352"/>
<node TEXT="Repetition: The design principle of repeating visual elements to demonstrate meaning in a data visualization" ID="ID_511309375" CREATED="1710460169352" MODIFIED="1710460169352"/>
<node TEXT="Report: A static collection of data periodically given to stakeholders" ID="ID_690929310" CREATED="1710460169353" MODIFIED="1710460169353"/>
<node TEXT="Return on investment (ROI): A formula that uses the metrics of investment and profit to evaluate the success of an investment" ID="ID_1569309186" CREATED="1710460169354" MODIFIED="1710460169354"/>
<node TEXT="Revenue: The total amount of income generated by the sale of goods or services" ID="ID_1542689456" CREATED="1710460169354" MODIFIED="1710460169354"/>
<node TEXT="Rhythm: The design principle of creating movement and flow in a data visualization to engage an audience" ID="ID_1097310607" CREATED="1710460169355" MODIFIED="1710460169355"/>
<node TEXT="RIGHT: A function that returns a set number of characters from the right side of a text string" ID="ID_1239510190" CREATED="1710460169356" MODIFIED="1710460169356"/>
<node TEXT="RIGHT JOIN: A SQL function that will return all records from the right table and only the matching records from the left" ID="ID_1404491712" CREATED="1710460169356" MODIFIED="1710460169356"/>
<node TEXT="Root cause: The reason why a problem occurs" ID="ID_1854384117" CREATED="1710460169357" MODIFIED="1710460169357"/>
<node TEXT="ROUND: A SQL function that returns a number rounded to a certain number of decimal places." ID="ID_902124549" CREATED="1710460169358" MODIFIED="1710460169358"/>
<node TEXT="Ruby: An object-oriented programming language for web application development" ID="ID_1471151288" CREATED="1710460169359" MODIFIED="1710460169359"/>
<node TEXT="Sample: In data analytics, a segment of a population that is representative of the entire population" ID="ID_1648647447" CREATED="1710460169360" MODIFIED="1710460169360"/>
<node TEXT="Sampling bias: Overrepresenting or underrepresenting certain members of a population as a result of working with a sample that is not representative of the population as a whole" ID="ID_609896520" CREATED="1710460169361" MODIFIED="1710460169361"/>
<node TEXT="Scatterplot: A data visualization that represents relationships between different variables with individual data points without a connecting line" ID="ID_857714605" CREATED="1710460169361" MODIFIED="1710460169361"/>
<node TEXT="Schema: A way of describing how something, such as data, is organized" ID="ID_1152029407" CREATED="1710460169362" MODIFIED="1710460169362"/>
<node TEXT="Scope of work (SOW): An agreed-upon outline of the tasks to be performed during a project" ID="ID_285871294" CREATED="1710460169363" MODIFIED="1710460169363"/>
<node TEXT="Second-party data: Data collected by a group directly from its audience and then sold" ID="ID_646539512" CREATED="1710460169363" MODIFIED="1710460169363"/>
<node TEXT="SELECT: The section of a query that indicates from which column(s) to extract the data" ID="ID_1157639941" CREATED="1710460169364" MODIFIED="1710460169364"/>
<node TEXT="SELECT INTO: A SQL clause that copies data from one table into a temporary table without adding the new table to the database" ID="ID_1394325444" CREATED="1710460169364" MODIFIED="1710460169364"/>
<node TEXT="Small data: Small, specific data points typically involving a short period of time, which are useful for making day-to-day decisions" ID="ID_999606440" CREATED="1710460169365" MODIFIED="1710460169365"/>
<node TEXT="SMART methodology: A tool for determining a question’s effectiveness based on whether it is specific, measurable, action-oriented, relevant, and time-bound" ID="ID_1370431261" CREATED="1710460169366" MODIFIED="1710460169366"/>
<node TEXT="Social media: Websites and applications through which users create and share content or participate in social networking" ID="ID_288475100" CREATED="1710460169366" MODIFIED="1710460169366"/>
<node TEXT="Soft skills: Nontechnical traits and behaviors that relate to how people work" ID="ID_1332788928" CREATED="1710460169367" MODIFIED="1710460169367"/>
<node TEXT="Sort range: A spreadsheet menu function that sorts a specified range and preserves the cells outside the range" ID="ID_241843385" CREATED="1710460169368" MODIFIED="1710460169368"/>
<node TEXT="Sort sheet: A spreadsheet menu function that sorts all data by the ranking of a specific sorted column and keeps data together across rows" ID="ID_670159201" CREATED="1710460169368" MODIFIED="1710460169368"/>
<node TEXT="Sorting: The process of arranging data into a meaningful order to make it easier to understand, analyze, and visualize" ID="ID_127507030" CREATED="1710460169369" MODIFIED="1710460169369"/>
<node TEXT="Specific question: A question that is simple, significant, and focused on a single topic or a few closely related ideas" ID="ID_781194685" CREATED="1710460169370" MODIFIED="1710460169370"/>
<node TEXT="SPLIT: A spreadsheet function that divides text around a specified character and puts each fragment into a new, separate cell" ID="ID_645839510" CREATED="1710460169371" MODIFIED="1710460169371"/>
<node TEXT="Sponsor: A professional advocate who is committed to moving forward the career of another" ID="ID_1531542630" CREATED="1710460169371" MODIFIED="1710460169371"/>
<node TEXT="Spotlightling: Scanning through data to quickly identify the most important insights" ID="ID_682522802" CREATED="1710460169372" MODIFIED="1710460169372"/>
<node TEXT="Spreadsheet: A digital worksheet" ID="ID_1253294229" CREATED="1710460169373" MODIFIED="1710460169373"/>
<node TEXT="SQL: (Refer to Structured Query Language)" ID="ID_951358419" CREATED="1710460169374" MODIFIED="1710460169374"/>
<node TEXT="Stakeholders: People who invest time and resources into a project and are interested in its outcome" ID="ID_1769004880" CREATED="1710460169374" MODIFIED="1710460169374"/>
<node TEXT="Static data: Data that doesn’t change once it has been recorded" ID="ID_780772025" CREATED="1710460169376" MODIFIED="1710460169376"/>
<node TEXT="Static visualization: A data visualization that does not change over time unless it is edited" ID="ID_1625996756" CREATED="1710460169376" MODIFIED="1710460169376"/>
<node TEXT="Statistical power: The probability that a test of significance will recognize an effect that is present" ID="ID_972401150" CREATED="1710460169376" MODIFIED="1710460169376"/>
<node TEXT="Statistical significance: The probability that sample results are not due to random chance" ID="ID_1819000462" CREATED="1710460169377" MODIFIED="1710460169377"/>
<node TEXT="Statistics: The study of how to collect, analyze, summarize, and present data" ID="ID_8304334" CREATED="1710460169378" MODIFIED="1710460169378"/>
<node TEXT="Story: The narrative of a data presentation that makes it meaningful and interesting" ID="ID_1008649573" CREATED="1710460169378" MODIFIED="1710460169378"/>
<node TEXT="String data type: A sequence of characters and punctuation that contains textual information (also called text data type)" ID="ID_1805363255" CREATED="1710460169379" MODIFIED="1710460169379"/>
<node TEXT="Structural metadata: Metadata that indicates how a piece of data is organized and whether it is part of one or more than one data collection" ID="ID_471417806" CREATED="1710460169380" MODIFIED="1710460169380"/>
<node TEXT="Structured data: Data organized in a certain format such as rows and columns" ID="ID_1613824679" CREATED="1710460169380" MODIFIED="1710460169380"/>
<node TEXT="Structured Query Language: A computer programming language used to communicate with a database" ID="ID_1395196335" CREATED="1710460169381" MODIFIED="1710460169381"/>
<node TEXT="Structured thinking: The process of recognizing the current problem or situation, organizing available information, revealing gaps and opportunities, and identifying options" ID="ID_570202197" CREATED="1710460169382" MODIFIED="1710460169382"/>
<node TEXT="Subquery: A SQL query that is nested inside a larger query" ID="ID_850598441" CREATED="1710460169382" MODIFIED="1710460169382"/>
<node TEXT="SUBSTR: A SQL function that extracts a substring from a string variable" ID="ID_1238035204" CREATED="1710460169383" MODIFIED="1710460169383"/>
<node TEXT="Substring: A subset of a text string" ID="ID_1408784491" CREATED="1710460169383" MODIFIED="1710460169383"/>
<node TEXT="Subtitle: Text that supports a headline by adding context and description" ID="ID_283629582" CREATED="1710460169384" MODIFIED="1710460169384"/>
<node TEXT="SUM: A spreadsheet function that adds the values of a selected range of cells" ID="ID_1771435750" CREATED="1710460169384" MODIFIED="1710460169384"/>
<node TEXT="SUMIF: A spreadsheet function that adds numeric data based on one condition" ID="ID_836255850" CREATED="1710460169384" MODIFIED="1710460169384"/>
<node TEXT="Summary table: A table used to summarize statistical information about data" ID="ID_416829240" CREATED="1710460169385" MODIFIED="1710460169385"/>
<node TEXT="SUMPRODUCT: A function that multiplies arrays and returns the sum of those products" ID="ID_771527698" CREATED="1710460169386" MODIFIED="1710460169386"/>
<node TEXT="Swift: A programming language for macOS, iOS, watchOS, and tvOS" ID="ID_390655149" CREATED="1710460169387" MODIFIED="1710460169387"/>
<node TEXT="Symbol map: A data visualization that displays a mark over a given longitude and latitude" ID="ID_820012151" CREATED="1710460169388" MODIFIED="1710460169388"/>
<node TEXT="Syntax: The predetermined structure of a language that includes all required words, symbols, and punctuation, as well as their proper placement" ID="ID_185061064" CREATED="1710460169388" MODIFIED="1710460169388"/>
<node TEXT="Tableau: A business intelligence and analytics platform that helps people visualize, understand, and make decisions with data" ID="ID_1000231509" CREATED="1710460169389" MODIFIED="1710460169389"/>
<node TEXT="Technical mindset: The ability to break things down into smaller steps or pieces and work with them in an orderly and logical way" ID="ID_1579787834" CREATED="1710460169389" MODIFIED="1710460169389"/>
<node TEXT="Temporary table: A database table that is created and exists temporarily on a database server" ID="ID_1074594187" CREATED="1710460169391" MODIFIED="1710460169391"/>
<node TEXT="Text data type: A sequence of characters and punctuation that contains textual information (also called string data type)" ID="ID_554398545" CREATED="1710460169393" MODIFIED="1710460169393"/>
<node TEXT="Text string: A group of characters within a cell, most often composed of letters" ID="ID_916466822" CREATED="1710460169393" MODIFIED="1710460169393"/>
<node TEXT="Third-party data: Data provided from outside sources who didn’t collect it directly" ID="ID_228472793" CREATED="1710460169394" MODIFIED="1710460169394"/>
<node TEXT="Time-bound question: A question that specifies a timeframe to be studied" ID="ID_925095876" CREATED="1710460169394" MODIFIED="1710460169394"/>
<node TEXT="Transaction transparency: The aspect of data ethics that presumes all data-processing activities and algorithms should be explainable and understood by the individual who provides the data" ID="ID_479132151" CREATED="1710460169396" MODIFIED="1710460169396"/>
<node TEXT="Transferable skills: Skills and qualities that can transfer from one job or industry to another" ID="ID_1754980959" CREATED="1710460169396" MODIFIED="1710460169396"/>
<node TEXT="TRIM: A function that removes leading, trailing, and repeated spaces in data" ID="ID_452420119" CREATED="1710460169396" MODIFIED="1710460169396"/>
<node TEXT="Turnover rate: The rate at which employees voluntarily leave a company" ID="ID_1506398608" CREATED="1710460169397" MODIFIED="1710460169397"/>
<node TEXT="Typecasting: Converting data from one type to another" ID="ID_1579932008" CREATED="1710460169398" MODIFIED="1710460169398"/>
<node TEXT="Unbiased sampling: When the sample of the population being measured is representative of the population as a whole" ID="ID_1103870104" CREATED="1710460169398" MODIFIED="1710460169398"/>
<node TEXT="Underscores: Lines used to underline words and connect text characters" ID="ID_1269512894" CREATED="1710460169399" MODIFIED="1710460169399"/>
<node TEXT="Unfair question: A question that makes assumptions or is difficult to answer honestly" ID="ID_1441728962" CREATED="1710460169399" MODIFIED="1710460169399"/>
<node TEXT="Unique: A value that can’t have a duplicate" ID="ID_818750541" CREATED="1710460169400" MODIFIED="1710460169400"/>
<node TEXT="United States Census Bureau: An agency in the U.S. Department of Commerce that serves as the nation’s leading provider of quality data about its people and economy" ID="ID_481244001" CREATED="1710460169401" MODIFIED="1710460169401"/>
<node TEXT="Unity: The design principle of using visual elements that complement each other to create aesthetic appeal and clarity in a data visualization" ID="ID_903400446" CREATED="1710460169401" MODIFIED="1710460169401"/>
<node TEXT="Unstructured data: Data that is not organized in any easily identifiable manner" ID="ID_782647641" CREATED="1710460169402" MODIFIED="1710460169402"/>
<node TEXT="Validity: The degree to which data conforms to constraints when it is input, collected, or created" ID="ID_293836755" CREATED="1710460169402" MODIFIED="1710460169402"/>
<node TEXT="VALUE: A spreadsheet function that converts a text string that represents a number to a numeric value" ID="ID_141872870" CREATED="1710460169403" MODIFIED="1710460169403"/>
<node TEXT="Variety: The design principle of using different kinds of visual elements in a data visualization to engage an audience" ID="ID_707173446" CREATED="1710460169404" MODIFIED="1710460169404"/>
<node TEXT="Verification: A process to confirm that a data-cleaning effort was well executed and the resulting data is accurate and reliable" ID="ID_1321527643" CREATED="1710460169404" MODIFIED="1710460169404"/>
<node TEXT="Video file: A collection of images, audio files, and other data usually encoded in a compressed format such as MP4, MV4, MOV, AVI, or FLV" ID="ID_1503785833" CREATED="1710460169406" MODIFIED="1710460169406"/>
<node TEXT="Visual form: The appearance of a data visualization that gives it structure and aesthetic appeal" ID="ID_1706456393" CREATED="1710460169406" MODIFIED="1710460169406"/>
<node TEXT="Visualization: (Refer to Data visualization)" ID="ID_137478737" CREATED="1710460169407" MODIFIED="1710460169407"/>
<node TEXT="VLOOKUP: A spreadsheet function that vertically searches for a certain value in a column to return a corresponding piece of information" ID="ID_686801995" CREATED="1710460169408" MODIFIED="1710460169408"/>
<node TEXT="WHERE: The section of a query that specifies criteria that the requested data must meet" ID="ID_886266711" CREATED="1710460169408" MODIFIED="1710460169408"/>
<node TEXT="Wide data: A dataset in which every data subject has a single row with multiple columns to hold the values of various attributes of the subject" ID="ID_1178721611" CREATED="1710460169409" MODIFIED="1710460169409"/>
<node TEXT="WITH: A SQL clause that creates a temporary table that can be queried multiple times" ID="ID_987086769" CREATED="1710460169410" MODIFIED="1710460169410"/>
<node TEXT="World Health Organization: An organization whose primary role is to direct and coordinate international health within the United Nations system" ID="ID_1806265789" CREATED="1710460169410" MODIFIED="1710460169410"/>
<node TEXT="X-axis: The horizontal line of a graph usually placed at the bottom, which is often used to represent time scales and discrete categories" ID="ID_106289914" CREATED="1710460169411" MODIFIED="1710460169411"/>
<node TEXT="Y-axis: The vertical line of a graph usually placed to the left, which is often used to represent frequencies and other numerical variables" ID="ID_141973737" CREATED="1710460169412" MODIFIED="1710460169412"/>
</node>
<node TEXT="Programming and data analytics (M1)" ID="ID_1456665292" CREATED="1710460308812" MODIFIED="1710460375902">
<node TEXT="Programming as a data analyst" FOLDED="true" ID="ID_1146497918" CREATED="1710460323086" MODIFIED="1710460337892">
<node TEXT="programming helps you:" ID="ID_1992617070" CREATED="1710460337893" MODIFIED="1710460404882">
<node TEXT="clarify the steps of your analysis" ID="ID_1194014760" CREATED="1710460404884" MODIFIED="1710460425913">
<node TEXT="Programming languages have specific rules and guidelines for giving instructions to the computer. When you&apos;re telling a computer what to do, your instructions have to be very clear. There can&apos;t be any inconsistency in the way you write code. If there is, the code won&apos;t work. Translating your thoughts into code forces you to figure out exactly how to write each step of your analysis and how all the steps fit together. It gives your analysis a level of precision that makes it really powerful." ID="ID_87571998" CREATED="1710460534390" MODIFIED="1710460534390"/>
</node>
<node TEXT="saves time" ID="ID_1175450413" CREATED="1710460408498" MODIFIED="1710460430679">
<node TEXT="For example, take the process of cleaning and transforming your data. With one line of code, you can create a separate dataset without any missing values. With another line, you can apply multiple filters on your data. This lets you spend less time preparing your data and more time on the analysis itself." ID="ID_973891326" CREATED="1710460565163" MODIFIED="1710460565163"/>
</node>
<node TEXT="reproduce and share your work" ID="ID_315850936" CREATED="1710460430694" MODIFIED="1710460435089">
<node TEXT="Data analysis is most useful when you can reproduce your work and share it with other people. They can double-check it and help you solve problems. Code automatically stores all of the steps of your analysis so you can reproduce, and share your work at anytime in the future, weeks, months, or even years later." ID="ID_411699781" CREATED="1710460594344" MODIFIED="1710460621526">
<node TEXT="Here&apos;s an example." ID="ID_1855345088" CREATED="1710460621528" MODIFIED="1710460621529">
<node TEXT="Let&apos;s say you&apos;re working on a project. You&apos;ve collected and cleaned your data and started your analysis, but the results don&apos;t add up. You suspect a mistake was made in the process. You&apos;d like to discuss the issue with a teammate and get their feedback. If you used a spreadsheet, you both might have to redo the entire analysis to discover the error. There&apos;s no easy way to record and reproduce your steps in a spreadsheet, but if you use a programming language, all your work can be reproduced and shared in a moment, from loading the data, to creating visualizations, to reporting the results. Plus, you can easily update your analysis and fix any errors simply by changing the code." ID="ID_131007562" CREATED="1710460616743" MODIFIED="1710460616744"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Introduction to R" FOLDED="true" ID="ID_1305752040" CREATED="1710461110701" MODIFIED="1710461116128">
<node TEXT="So what is R?" FOLDED="true" ID="ID_570913118" CREATED="1710461120756" MODIFIED="1710461126730">
<node TEXT="R is a programming language frequently used for statistical analysis, visualization and other data analysis" ID="ID_851048368" CREATED="1710461126737" MODIFIED="1710461126748"/>
<node TEXT="Later on, you&apos;ll take a tour of Rstudio, which is a popular software environment for the R language" ID="ID_1788535814" CREATED="1710461120756" MODIFIED="1710461120756"/>
</node>
<node TEXT="In this video, we&apos;ll discuss R&apos;s main features and functions and its advantages for data analysis" ID="ID_1416251046" CREATED="1710461120757" MODIFIED="1710461120757"/>
<node TEXT="R history" FOLDED="true" ID="ID_972267353" CREATED="1710461120758" MODIFIED="1710461495999">
<node TEXT="R is based on another programming language named S" FOLDED="true" ID="ID_1796785433" CREATED="1710461120759" MODIFIED="1710461120759">
<node TEXT="In the 1970s, John Chambers created S for internal use at Bell Labs, a famous scientific research facility" ID="ID_1532675876" CREATED="1710461120759" MODIFIED="1710461120759"/>
<node TEXT="In the 1990s, Ross Oaxaca and Robert Gentleman developed R at the University of Auckland, New Zealand" FOLDED="true" ID="ID_484846483" CREATED="1710461120759" MODIFIED="1710461120759">
<node TEXT="The title R refers to the first names of its two authors and plays on a single- letter title of its predecessor S" ID="ID_1393980600" CREATED="1710461120760" MODIFIED="1710461120760"/>
</node>
</node>
<node TEXT="Since then, R has become a preferred programming language of scientists, statisticians and data analysts around the world" ID="ID_1579942761" CREATED="1710461120761" MODIFIED="1710461120761"/>
</node>
<node TEXT="There&apos;s lots of reasons why people who work with data love R" FOLDED="true" ID="ID_496418131" CREATED="1710461120762" MODIFIED="1710461120762">
<node TEXT="R is accessible, data-centric, open-source and has an active community of users" FOLDED="true" ID="ID_1361605985" CREATED="1710461120763" MODIFIED="1710461120763">
<node TEXT="First R is an accessible language for beginners" FOLDED="true" ID="ID_1448498828" CREATED="1710461120763" MODIFIED="1710461120763">
<node TEXT="Lots of people without a traditional programming language learn R" ID="ID_441416799" CREATED="1710461120763" MODIFIED="1710461120763"/>
</node>
<node TEXT="R really appeals to anyone who wants to solve problems that involve data" FOLDED="true" ID="ID_845360030" CREATED="1710461120765" MODIFIED="1710461120765">
<node TEXT="And that&apos;s one of the things that&apos;s so great about R" ID="ID_460515427" CREATED="1710461120765" MODIFIED="1710461120765"/>
<node TEXT="It&apos;s all about data" ID="ID_1634417712" CREATED="1710461120766" MODIFIED="1710461120766"/>
<node TEXT="R is what&apos;s known as a data-centric programming language" FOLDED="true" ID="ID_1989106098" CREATED="1710461120766" MODIFIED="1710461120766">
<node TEXT="It&apos;s specifically designed to make data analysis easier, more efficient and more powerful" ID="ID_1853538166" CREATED="1710461120768" MODIFIED="1710461120768"/>
</node>
</node>
</node>
<node TEXT="Another awesome thing about R is that it&apos;s open source" FOLDED="true" ID="ID_1643926572" CREATED="1710461120768" MODIFIED="1710461120768">
<node TEXT="Open source means that the code is freely available and may be modified and shared by the people who use it" FOLDED="true" ID="ID_1678718811" CREATED="1710461120769" MODIFIED="1710461120769">
<node TEXT="Let&apos;s pause for a moment and unpack how amazing this is" FOLDED="true" ID="ID_1889047738" CREATED="1710461120770" MODIFIED="1710461120770">
<node TEXT="First anyone can use R for free" ID="ID_873594474" CREATED="1710461120770" MODIFIED="1710461120770"/>
</node>
<node TEXT="Second, anyone can modify the code, fix bugs and improve it" FOLDED="true" ID="ID_1464576957" CREATED="1710461120771" MODIFIED="1710461120771">
<node TEXT="In fact, over the years, lots of excellent programmers have made improvements and fixes to the R code" ID="ID_1977496341" CREATED="1710461120771" MODIFIED="1710461120771"/>
<node TEXT="For example, anyone who knows the R language can create what&apos;s called an add-on package" FOLDED="true" ID="ID_356853794" CREATED="1710461120772" MODIFIED="1710461120772">
<node TEXT="For now, just know that literally thousands of R packages exist, and they were all built by people who wanted to solve specific problems" ID="ID_681222037" CREATED="1710461120773" MODIFIED="1710461120773"/>
<node TEXT="A lot of these packages are super useful for data analysts" ID="ID_1046202354" CREATED="1710461120773" MODIFIED="1710461120773"/>
<node TEXT="As an R user, you now enjoy the benefit of the shared knowledge" ID="ID_1238117923" CREATED="1710461120774" MODIFIED="1710461120774"/>
</node>
</node>
</node>
</node>
<node TEXT="And let me just add, the R community is the best" FOLDED="true" ID="ID_789518505" CREATED="1710461120774" MODIFIED="1710461120774">
<node TEXT="This vibrant, diverse and accessible community is so supportive of new learners" ID="ID_1662090960" CREATED="1710461120775" MODIFIED="1710461120775"/>
<node TEXT="You can go online anytime to find answers to all your R questions" FOLDED="true" ID="ID_355326486" CREATED="1710461120775" MODIFIED="1710461120775">
<node TEXT="Check out websites like R for Data Science Online Learning Community and RStudio Community" ID="ID_1342320889" CREATED="1710461120776" MODIFIED="1710461120776"/>
<node TEXT="On top of that, R users are all over Twitter and other social media" ID="ID_1633341657" CREATED="1710461120776" MODIFIED="1710461120776"/>
<node TEXT="You&apos;ll discover tons of resources for professional networking, mentoring and learning" ID="ID_802184883" CREATED="1710461120777" MODIFIED="1710461120777"/>
</node>
</node>
</node>
<node TEXT="Now that we know more about the general benefits of R, let&apos;s talk about some specific situations when you might use it for data analysis" FOLDED="true" ID="ID_1774790585" CREATED="1710461120777" MODIFIED="1710461120777">
<node TEXT="Here&apos;s three scenarios: reproducing your analysis, processing lots of data, and creating data visualizations" FOLDED="true" ID="ID_1863280129" CREATED="1710461120778" MODIFIED="1710461120778">
<node TEXT="First R can save and reproduce every step of your analysis" FOLDED="true" ID="ID_234493023" CREATED="1710461120778" MODIFIED="1710461120778">
<node TEXT="Earlier, we discussed how data analysis is most useful when you can easily reproduce your work and share it with others" ID="ID_1997438205" CREATED="1710461120779" MODIFIED="1710461120779"/>
<node TEXT="In R, reproducing your analysis is as easy as pressing a button on your keyboard" ID="ID_1286557648" CREATED="1710461120779" MODIFIED="1710461120779"/>
<node TEXT="Your code stores it forever" ID="ID_287493047" CREATED="1710461120780" MODIFIED="1710461120780"/>
<node TEXT="And you can share it with anyone at any time" ID="ID_1525550776" CREATED="1710461120781" MODIFIED="1710461120781"/>
</node>
</node>
<node TEXT="Processing lots of data is also something R does really well, just like SQL" FOLDED="true" ID="ID_2182674" CREATED="1710461120782" MODIFIED="1710461120782">
<node TEXT="As you learned earlier spreadsheets organize projects in sheets or tabs" ID="ID_1719784259" CREATED="1710461120783" MODIFIED="1710461120783"/>
<node TEXT="If you&apos;ve ever had to deal with spreadsheet files that have tons of sheets or lots of data in each sheet, you know that things can start to move very slowly" ID="ID_496361047" CREATED="1710461120783" MODIFIED="1710461120783"/>
<node TEXT="Working with too much data in a spreadsheet can even cause crashes" ID="ID_273696082" CREATED="1710461120783" MODIFIED="1710461120783"/>
<node TEXT="R can handle large amounts of data much more quickly and efficiently" ID="ID_651064195" CREATED="1710461120784" MODIFIED="1710461120784"/>
</node>
<node TEXT="Finally R can create powerful visuals and has state-of-the-art graphic capabilities" FOLDED="true" ID="ID_1131591183" CREATED="1710461120785" MODIFIED="1710461120785">
<node TEXT="As you&apos;ve seen in this program, tools like spreadsheets and Tableau offer lots of options for visualizing your data" ID="ID_1766214492" CREATED="1710461120785" MODIFIED="1710461120785"/>
<node TEXT="With only a small bit of code, you can create histograms, scatter plots, line plots and so much more" ID="ID_1228446838" CREATED="1710461120786" MODIFIED="1710461120786"/>
<node TEXT="If you work with more advanced packages, you can make some seriously impressive data visualizations" ID="ID_1515393758" CREATED="1710461120787" MODIFIED="1710461120787"/>
</node>
</node>
<node TEXT="Learning R is a huge benefit to anyone interested in becoming a data analyst" FOLDED="true" ID="ID_1964117342" CREATED="1710461120788" MODIFIED="1710461120788">
<node TEXT="As I mentioned earlier, knowledge of R will help you stand out as a job candidate" ID="ID_1895901942" CREATED="1710461120788" MODIFIED="1710461120788"/>
<node TEXT="And as you keep moving forward, R will help you find solutions for more complex data problems" ID="ID_215314260" CREATED="1710461120789" MODIFIED="1710461120789"/>
<node TEXT="You can keep learning about R throughout your career as a data analyst" ID="ID_415409081" CREATED="1710461120790" MODIFIED="1710461120790"/>
</node>
<node TEXT="Most analysts who work with the R language use the RStudio environment to interact with R, and not the basic interface" ID="ID_221821327" CREATED="1710461120792" MODIFIED="1710461120792"/>
</node>
</node>
<node TEXT="Understand basic programming concepts (M2)" FOLDED="true" ID="ID_1065299690" CREATED="1710522084800" MODIFIED="1710522097802">
<node TEXT="Programming fundamentals" POSITION="bottom_or_right" ID="ID_1888219736" CREATED="1710522099984" MODIFIED="1710522272573">
<node TEXT="reference" FOLDED="true" ID="ID_179854770" CREATED="1710535207777" MODIFIED="1710535211608">
<node TEXT="M:\My Drive\My Google Docs\Career\Development and Learning\Data Analytics\R\Lesson3_Sandbox.Rmd" ID="ID_290664325" CREATED="1710535213006" MODIFIED="1710535213006"/>
</node>
<node TEXT="The basic concepts of R" FOLDED="true" ID="ID_611054735" CREATED="1710522272578" MODIFIED="1710522278571">
<node TEXT="reference" FOLDED="true" ID="ID_1883895975" CREATED="1710542610832" MODIFIED="1710542612779">
<node ID="ID_997191322" CREATED="1710542614321" MODIFIED="1710542614321" LINK="https://www.w3schools.com/r/default.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.w3schools.com/r/default.asp">R Tutorial</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="packages" FOLDED="true" ID="ID_344903979" CREATED="1710526314704" MODIFIED="1710526317085">
<node TEXT="tidyverse" FOLDED="true" ID="ID_188888397" CREATED="1710526318110" MODIFIED="1710526332314">
<node TEXT="info" FOLDED="true" ID="ID_451317011" CREATED="1710540379452" MODIFIED="1710540382483">
<node TEXT="collection of packages with a common design philosophy for data manipulation, exploration, and visualization" ID="ID_1259941512" CREATED="1710538611236" MODIFIED="1710538627066"/>
<node TEXT="key part of programming for most R users" ID="ID_159788742" CREATED="1710538672686" MODIFIED="1710538685441"/>
</node>
<node TEXT="core packages" FOLDED="true" ID="ID_662406392" CREATED="1710540391038" MODIFIED="1710540425467">
<node TEXT="ggplot2" FOLDED="true" ID="ID_76058832" CREATED="1710540427727" MODIFIED="1710540911798">
<font BOLD="true"/>
<node TEXT="creative ready data viz by applying different visual properties to the data tables" ID="ID_811775323" CREATED="1710540557049" MODIFIED="1710540577329"/>
</node>
<node TEXT="tidyr" FOLDED="true" ID="ID_365027217" CREATED="1710540442100" MODIFIED="1710540911797">
<font BOLD="true"/>
<node TEXT="data cleaning to make tidy data" ID="ID_1223551657" CREATED="1710540586280" MODIFIED="1710540600049"/>
</node>
<node TEXT="readr" FOLDED="true" ID="ID_1297447050" CREATED="1710540442100" MODIFIED="1710540911797">
<font BOLD="true"/>
<node TEXT="importing data" ID="ID_997350462" CREATED="1710540607247" MODIFIED="1710540620623"/>
<node TEXT="read_csv" ID="ID_1847910840" CREATED="1710540622545" MODIFIED="1710540627068"/>
</node>
<node TEXT="dplyr" FOLDED="true" ID="ID_1164984796" CREATED="1710540442102" MODIFIED="1710540911794">
<font BOLD="true"/>
<node TEXT="offers a consistent set of functions that help you complete some common data manipulation tasks" ID="ID_991171174" CREATED="1710540653023" MODIFIED="1710540687897"/>
<node TEXT="select()" FOLDED="true" ID="ID_971210227" CREATED="1710545660647" MODIFIED="1710545669222">
<node TEXT="select and optionally rename variables in a data frame" ID="ID_347635406" CREATED="1710545670680" MODIFIED="1710545697878"/>
</node>
</node>
<node TEXT="stringr" FOLDED="true" ID="ID_274091930" CREATED="1710540442104" MODIFIED="1710540518881">
<node TEXT="functions that make it easier to work with strings" ID="ID_1585507784" CREATED="1710540967828" MODIFIED="1710540973869"/>
</node>
<node TEXT="forcats" FOLDED="true" ID="ID_1025134812" CREATED="1710540514468" MODIFIED="1710540514469">
<node TEXT="provides tools that solve common problems with factors" FOLDED="true" ID="ID_847778598" CREATED="1710540979040" MODIFIED="1710540985873">
<node TEXT="factor: store categorical data in R where the data values are limited and usually based on a finite group" ID="ID_1839732595" CREATED="1710540987644" MODIFIED="1710541022063"/>
</node>
</node>
<node TEXT="purrr" FOLDED="true" ID="ID_131107889" CREATED="1710540442103" MODIFIED="1710540442103">
<node TEXT="works with functions and vectors helping make your code easier to write and more expressive" ID="ID_282771674" CREATED="1710540932235" MODIFIED="1710540959496"/>
</node>
<node TEXT="tibble" FOLDED="true" ID="ID_354699389" CREATED="1710540442103" MODIFIED="1710540442103">
<node TEXT="data frames" ID="ID_1390815838" CREATED="1710540925241" MODIFIED="1710540928439"/>
</node>
<node TEXT="lubridate" FOLDED="true" ID="ID_1869900748" CREATED="1710526333052" MODIFIED="1710526339910">
<node TEXT="date and time" ID="ID_1019964446" CREATED="1710542650984" MODIFIED="1710542656897"/>
</node>
</node>
</node>
<node TEXT="show currently installed" FOLDED="true" ID="ID_1876799851" CREATED="1710540243466" MODIFIED="1710540266666">
<node TEXT="installed.packages()" ID="ID_251753345" CREATED="1710540249026" MODIFIED="1710540253036"/>
</node>
<node TEXT="installing and updating" FOLDED="true" ID="ID_1248881426" CREATED="1710538911427" MODIFIED="1710539028569">
<node TEXT="install.packages(&quot;package_name&quot;)" FOLDED="true" ID="ID_412284443" CREATED="1710538917198" MODIFIED="1710539124217">
<node TEXT="updates as well" ID="ID_757437229" CREATED="1710539032391" MODIFIED="1710539035688"/>
</node>
<node TEXT="update.packages()  #updates all packages" ID="ID_1717035664" CREATED="1710538965882" MODIFIED="1710539045077"/>
</node>
<node TEXT="loading" FOLDED="true" ID="ID_1156507357" CREATED="1710539075114" MODIFIED="1710539080031">
<node TEXT="library(package_name)" ID="ID_536094995" CREATED="1710539080033" MODIFIED="1710539099044"/>
</node>
<node TEXT="referencing files" FOLDED="true" ID="ID_645568222" CREATED="1710793417242" MODIFIED="1710793421908">
<node TEXT="here" ID="ID_923516914" CREATED="1710793421911" MODIFIED="1710793425346"/>
</node>
<node TEXT="cleaning" FOLDED="true" ID="ID_1916444006" CREATED="1710709242686" MODIFIED="1710709246436">
<node TEXT="skimr" ID="ID_69559995" CREATED="1710709246438" MODIFIED="1710709251885"/>
<node TEXT="janitor" ID="ID_781555057" CREATED="1710709252213" MODIFIED="1710709254704"/>
</node>
</node>
<node TEXT="documentation" FOLDED="true" ID="ID_1685666490" CREATED="1710539253467" MODIFIED="1710539256837">
<node TEXT="vignette" FOLDED="true" ID="ID_1938008168" CREATED="1710539256838" MODIFIED="1710539260436">
<node TEXT="browseVignettes(“packagename”)" ID="ID_1991540805" CREATED="1710539279496" MODIFIED="1710539279496"/>
</node>
</node>
<node TEXT="environment" FOLDED="true" ID="ID_1098871724" CREATED="1710642873707" MODIFIED="1710642875796">
<node TEXT="rm(list=ls()) #clear environment" ID="ID_626287286" CREATED="1710642876845" MODIFIED="1710642882891"/>
</node>
<node TEXT="functions" FOLDED="true" ID="ID_859981256" CREATED="1710522278576" MODIFIED="1710522280976">
<node TEXT="a body of reusable code used to perform specific tasks" ID="ID_478981104" CREATED="1710522315224" MODIFIED="1710522328616"/>
<node TEXT="argument" FOLDED="true" ID="ID_1621985007" CREATED="1710522341194" MODIFIED="1710522344363">
<node TEXT="" ID="ID_428567350" CREATED="1710522344368" MODIFIED="1710522344368"/>
</node>
</node>
<node TEXT="comments" FOLDED="true" ID="ID_557906599" CREATED="1710522280992" MODIFIED="1710522282763">
<node TEXT="# Comment" ID="ID_1246823318" CREATED="1710522525164" MODIFIED="1710522545395"/>
</node>
<node TEXT="variables" FOLDED="true" ID="ID_1315068963" CREATED="1710522282778" MODIFIED="1710522284578">
<node TEXT="a representation of a value that can be stored for later use during programming" ID="ID_984236182" CREATED="1710522437366" MODIFIED="1710522447983"/>
<node TEXT="a.k.a. objects" ID="ID_1427854235" CREATED="1710522450594" MODIFIED="1710522454999"/>
<node TEXT="a variable name should start with the letter and can also contain numbers and underscores" FOLDED="true" ID="ID_1396940158" CREATED="1710522476183" MODIFIED="1710522486593">
<node TEXT="case-sensitive" ID="ID_454700835" CREATED="1710522495616" MODIFIED="1710522499375"/>
<node TEXT="use all lowercase" ID="ID_726079661" CREATED="1710522500398" MODIFIED="1710522512216"/>
</node>
<node TEXT="assignment operators" FOLDED="true" ID="ID_840595394" CREATED="1710522568423" MODIFIED="1710522573200">
<node TEXT="&lt;-" ID="ID_1876002685" CREATED="1710522573203" MODIFIED="1710522596597"/>
</node>
</node>
<node TEXT="operators" FOLDED="true" ID="ID_1529293573" CREATED="1710532572985" MODIFIED="1710532577789">
<node TEXT="symbol that identifies the type of operation or calculation be performed in a formula" ID="ID_1929166247" CREATED="1710532584801" MODIFIED="1710532599693"/>
<node TEXT="logical" FOLDED="true" ID="ID_147373039" CREATED="1710532577790" MODIFIED="1710532582386">
<node TEXT="return logical datatypes such as TRUE or FALSE" ID="ID_1191929534" CREATED="1710532604981" MODIFIED="1710532622995"/>
<node TEXT="types" FOLDED="true" ID="ID_109281999" CREATED="1710532629188" MODIFIED="1710532632175">
<node TEXT="AND &amp; or &amp;&amp; " ID="ID_1557509035" CREATED="1710532632176" MODIFIED="1710532654398"/>
<node TEXT="OR | or ||" ID="ID_577399705" CREATED="1710532655586" MODIFIED="1710532667042"/>
<node TEXT="NOT !" ID="ID_1886583893" CREATED="1710532668603" MODIFIED="1710532675629"/>
</node>
</node>
<node TEXT="~ # defines the relationship between dependent variable and independent variables in a statistical model formula" FOLDED="true" ID="ID_224329533" CREATED="1710885320831" MODIFIED="1710885356026">
<node TEXT="Tilde operator is used to define the relationship between dependent variable and independent variables in a statistical model formula. The variable on the left-hand side of tilde operator is the dependent variable and the variable(s) on the right-hand side of tilde operator is/are called the independent variable(s). So, tilde operator helps to define that dependent variable depends on the independent variable(s) that are on the right-hand side of tilde operator. (retrieved from tutorialspoint.com)" ID="ID_989064510" CREATED="1710885357631" MODIFIED="1710885357631"/>
</node>
</node>
<node TEXT="conditional statements" FOLDED="true" ID="ID_1479656532" CREATED="1710532734986" MODIFIED="1710532739785">
<node TEXT="declaration that if a certain condition holds, then a certain event must take place" ID="ID_1279787421" CREATED="1710532739788" MODIFIED="1710532755019"/>
<node TEXT="if()" FOLDED="true" ID="ID_753241371" CREATED="1710532755992" MODIFIED="1710532760219">
<node TEXT="example" FOLDED="true" ID="ID_171067082" CREATED="1710532823384" MODIFIED="1710532826795">
<node TEXT="if (condition) {" FOLDED="true" ID="ID_596811497" CREATED="1710532828247" MODIFIED="1710532828247">
<node TEXT="expr" ID="ID_1088694387" CREATED="1710532828247" MODIFIED="1710532828247"/>
</node>
<node TEXT="}" ID="ID_1933117354" CREATED="1710532828247" MODIFIED="1710532828247"/>
<node TEXT="For example, let’s create a variable x equal to 4." ID="ID_1102371349" CREATED="1710532828248" MODIFIED="1710532828248"/>
<node TEXT="x &lt;- 4" ID="ID_357819683" CREATED="1710532828248" MODIFIED="1710532828248"/>
<node TEXT="Next, let’s create a conditional statement: if x is greater than 0, then R will print out the string “x is a positive number&quot;." ID="ID_1996342933" CREATED="1710532828248" MODIFIED="1710532828248"/>
<node TEXT="if (x &gt; 0) {" FOLDED="true" ID="ID_1887904385" CREATED="1710532828249" MODIFIED="1710532828249">
<node TEXT="print(&quot;x is a positive number&quot;)" ID="ID_585112512" CREATED="1710532828250" MODIFIED="1710532828250"/>
</node>
<node TEXT="}" ID="ID_981211142" CREATED="1710532828250" MODIFIED="1710532828250"/>
<node TEXT="Since x = 4, the condition is true (4 &gt; 0). Therefore, when you run the code, R prints out the string “x is a positive number&quot;." ID="ID_1170337041" CREATED="1710532828250" MODIFIED="1710532828250"/>
<node TEXT="[1] &quot;x is a positive number&quot;" ID="ID_1451381244" CREATED="1710532828250" MODIFIED="1710532828250"/>
</node>
</node>
<node TEXT="else()" FOLDED="true" ID="ID_102652323" CREATED="1710532761418" MODIFIED="1710532777182">
<node TEXT="example" FOLDED="true" ID="ID_629865702" CREATED="1710532855183" MODIFIED="1710532857988">
<node TEXT="if (condition) {" FOLDED="true" ID="ID_1337778765" CREATED="1710532859672" MODIFIED="1710532859672">
<node TEXT="expr1" ID="ID_777562915" CREATED="1710532859672" MODIFIED="1710532859672"/>
</node>
<node TEXT="} else {" FOLDED="true" ID="ID_363681913" CREATED="1710532859672" MODIFIED="1710532859672">
<node TEXT="expr2" ID="ID_562324568" CREATED="1710532859673" MODIFIED="1710532859673"/>
</node>
<node TEXT="}" ID="ID_961451120" CREATED="1710532859673" MODIFIED="1710532859673"/>
</node>
</node>
<node TEXT="else if()" FOLDED="true" ID="ID_1023031107" CREATED="1710532777192" MODIFIED="1710532790821">
<node TEXT="example" FOLDED="true" ID="ID_1311980833" CREATED="1710532883378" MODIFIED="1710532885390">
<node TEXT="if (condition1) {" FOLDED="true" ID="ID_61192159" CREATED="1710532887042" MODIFIED="1710532887042">
<node TEXT="expr1" ID="ID_1570283596" CREATED="1710532887042" MODIFIED="1710532887042"/>
</node>
<node TEXT="} else if (condition2) {" FOLDED="true" ID="ID_1314702787" CREATED="1710532887042" MODIFIED="1710532887042">
<node TEXT="expr2" ID="ID_500542406" CREATED="1710532887042" MODIFIED="1710532887042"/>
</node>
<node TEXT="} else {" FOLDED="true" ID="ID_1213260834" CREATED="1710532887042" MODIFIED="1710532887042">
<node TEXT="expr3" ID="ID_1218494638" CREATED="1710532887044" MODIFIED="1710532887044"/>
</node>
<node TEXT="}" ID="ID_1230299421" CREATED="1710532887044" MODIFIED="1710532887044"/>
</node>
</node>
</node>
<node TEXT="data types" FOLDED="true" ID="ID_1674488378" CREATED="1710522284593" MODIFIED="1710526373007">
<node TEXT="integer" ID="ID_1962173245" CREATED="1710526388416" MODIFIED="1710526393958"/>
<node TEXT="string" ID="ID_1990210934" CREATED="1710526393967" MODIFIED="1710526397157"/>
<node TEXT="date and time" FOLDED="true" ID="ID_1417453245" CREATED="1710526397169" MODIFIED="1710526401195">
<node TEXT="types" FOLDED="true" ID="ID_104376393" CREATED="1710526514213" MODIFIED="1710526515964">
<node TEXT="date (&quot;2016-08-16&quot;)" ID="ID_1325120380" CREATED="1710526428221" MODIFIED="1710526473056"/>
<node TEXT="time within a day (“20:11:59 UTC&quot;)" ID="ID_103317236" CREATED="1710526428221" MODIFIED="1710526468905"/>
<node TEXT="date-time. This is a date plus a time (&quot;2018-03-31 18:15:48 UTC&quot;)" ID="ID_1190347300" CREATED="1710526428221" MODIFIED="1710526463955"/>
</node>
<node TEXT="creating" FOLDED="true" ID="ID_1796166608" CREATED="1710526519595" MODIFIED="1710526522063">
<node TEXT="from string" FOLDED="true" ID="ID_517573568" CREATED="1710526523121" MODIFIED="1710526528391">
<node TEXT="to date" FOLDED="true" ID="ID_1779367359" CREATED="1710526711838" MODIFIED="1710526714226">
<node TEXT="ymd(&quot;2021-01-20&quot;)" ID="ID_492878227" CREATED="1710526578419" MODIFIED="1710526578419"/>
<node TEXT="mdy(&quot;January 20th, 2021&quot;)" ID="ID_1850844040" CREATED="1710526625414" MODIFIED="1710526625414"/>
<node TEXT="ymd(20210120)" ID="ID_1052672767" CREATED="1710526672413" MODIFIED="1710526672413"/>
<node TEXT="dmy(&quot;20-Jan-2021&quot;)" ID="ID_164616138" CREATED="1710526661818" MODIFIED="1710526661818"/>
<node TEXT="First, identify the order in which the year, month, and day appear in your dates." ID="ID_140599225" CREATED="1710526578419" MODIFIED="1710526586193"/>
<node TEXT="Then, arrange the letters y, m, and d in the same order. That gives you the name of the lubridate function that will parse your date. For example, for the date 2021-01-20, you use the order ymd:" ID="ID_1476443730" CREATED="1710526586194" MODIFIED="1710526586195"/>
</node>
<node TEXT="to date-time" FOLDED="true" ID="ID_998037237" CREATED="1710526720099" MODIFIED="1710526729836">
<node TEXT="ymd_hms(&quot;2021-01-20 20:11:59&quot;)" FOLDED="true" ID="ID_1634234254" CREATED="1710526741422" MODIFIED="1710526741422">
<node TEXT="#&gt; [1] &quot;2021-01-20 20:11:59 UTC&quot;" ID="ID_967504683" CREATED="1710526741422" MODIFIED="1710526741422"/>
</node>
<node TEXT="mdy_hm(&quot;01/20/2021 08:01&quot;)" ID="ID_612384512" CREATED="1710526741423" MODIFIED="1710526741423"/>
<node TEXT="add an underscore and one or more of the letters h, m, and s (hours, minutes, seconds) to the name of the function:" ID="ID_1257393082" CREATED="1710526769003" MODIFIED="1710526769003"/>
</node>
</node>
<node TEXT="date from date-time" FOLDED="true" ID="ID_1663492688" CREATED="1710526825081" MODIFIED="1710526840858">
<node TEXT="as_date(date_time)" ID="ID_166342034" CREATED="1710526842651" MODIFIED="1710526870152"/>
<node TEXT="as_date(now())" ID="ID_299310163" CREATED="1710526854601" MODIFIED="1710526854601"/>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_388229414" CREATED="1710526927887" MODIFIED="1710526930348">
<node ID="ID_618338521" CREATED="1710526987579" MODIFIED="1710526987579"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/7%20Data%20Analysis%20With%20R%20Programming/M1%20Programming%20and%20data%20analytics.one#Dates and times in R&amp;section-id={D7CB5240-2167-4B3C-B605-7134AA36AA4B}&amp;page-id={06C026B0-4679-4C25-B10D-5A70295F4533}&amp;end">Dates and times in R</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%287%20Data%20Analysis%20With%20R%20Programming%2FM1%20Programming%20and%20data%20analytics.one%7CD7CB5240-2167-4B3C-B605-7134AA36AA4B%2FDates%20and%20times%20in%20R%7C06C026B0-4679-4C25-B10D-5A70295F4533%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="data structures" FOLDED="true" ID="ID_208365175" CREATED="1710523604576" MODIFIED="1710643192893">
<node TEXT="format for organizing and storing data" ID="ID_1495537685" CREATED="1710523608563" MODIFIED="1710523624576"/>
<node TEXT="types" FOLDED="true" ID="ID_1064655655" CREATED="1710523626771" MODIFIED="1710523635567">
<node TEXT="vectors" FOLDED="true" ID="ID_1212059801" CREATED="1710522286566" MODIFIED="1710522288574">
<node TEXT="a group of data elements of the same type stored in a sequence" ID="ID_1505443696" CREATED="1710522682440" MODIFIED="1710522689216"/>
<node TEXT="types" FOLDED="true" ID="ID_1150407368" CREATED="1710523665802" MODIFIED="1710523671372">
<node TEXT="atomic vectors" FOLDED="true" ID="ID_465647779" CREATED="1710523671374" MODIFIED="1710523674756">
<node TEXT="creating" FOLDED="true" ID="ID_1969093351" CREATED="1710524605405" MODIFIED="1710524607798">
<node TEXT="c(a, b, c)  # combine function" FOLDED="true" ID="ID_163475007" CREATED="1710522695408" MODIFIED="1710523818918">
<node TEXT="integers" FOLDED="true" ID="ID_694924697" CREATED="1710523837786" MODIFIED="1710523848804">
<node TEXT="c(1L, 5L, 15L) # &quot;L&quot; follows each integer" ID="ID_1346776331" CREATED="1710523857620" MODIFIED="1710523873217"/>
</node>
<node TEXT="characters" FOLDED="true" ID="ID_715594242" CREATED="1710523903124" MODIFIED="1710523913365">
<node TEXT="c(“Sara” , “Lisa” , “Anna”) #quotes" ID="ID_1208054176" CREATED="1710523918222" MODIFIED="1710523927935"/>
</node>
<node TEXT="logicals" FOLDED="true" ID="ID_1424818463" CREATED="1710523932756" MODIFIED="1710523939436">
<node TEXT="c(TRUE, FALSE, TRUE)" ID="ID_1465588353" CREATED="1710523962639" MODIFIED="1710523962639"/>
</node>
</node>
</node>
<node TEXT="naming" FOLDED="true" ID="ID_1230989093" CREATED="1710524216999" MODIFIED="1710524220376">
<node TEXT="names(x)" ID="ID_1324590960" CREATED="1710524220378" MODIFIED="1710524286089"/>
<node TEXT="example" FOLDED="true" ID="ID_748204988" CREATED="1710524286729" MODIFIED="1710524288847">
<node TEXT="You can use the names() function to assign a different name to each element of the vector." ID="ID_128761883" CREATED="1710524290638" MODIFIED="1710524290638"/>
<node TEXT="x &lt;- c(1, 3, 5)" ID="ID_1934978054" CREATED="1710524290637" MODIFIED="1710524290637"/>
<node TEXT="names(x) &lt;- c(&quot;a&quot;, &quot;b&quot;, &quot;c&quot;)" ID="ID_1115845010" CREATED="1710524290638" MODIFIED="1710524290638"/>
<node TEXT="Now, when you run the code, R shows that the first element of the vector is named a, the second b, and the third c." ID="ID_720417733" CREATED="1710524290639" MODIFIED="1710524290639"/>
<node TEXT="x" ID="ID_329519848" CREATED="1710524290639" MODIFIED="1710524290639"/>
<node TEXT="#&gt; a b c" ID="ID_1987744228" CREATED="1710524290640" MODIFIED="1710524290640"/>
<node TEXT="#&gt; 1 3 5" ID="ID_1740819974" CREATED="1710524290640" MODIFIED="1710524290640"/>
</node>
</node>
<node TEXT="types" FOLDED="true" ID="ID_582779395" CREATED="1710523711117" MODIFIED="1710523715983">
<node TEXT="Type        Description         Example" ID="ID_941901413" CREATED="1710523731828" MODIFIED="1710523731828"/>
<node TEXT="Logical         True/False         TRUE" ID="ID_564030849" CREATED="1710523731828" MODIFIED="1710523731828"/>
<node TEXT="Integer         Positive and negative whole values        3" ID="ID_1532887186" CREATED="1710523731829" MODIFIED="1710523731829"/>
<node TEXT="Double         Decimal values         101.175" ID="ID_1691133273" CREATED="1710523731830" MODIFIED="1710523731830"/>
<node TEXT="Character         String/character values        “Coding”" ID="ID_1074573671" CREATED="1710523731831" MODIFIED="1710523731831"/>
</node>
<node TEXT="hierarchy" FOLDED="true" ID="ID_1785283978" CREATED="1710523785125" MODIFIED="1710523787177">
<node TEXT="png_7285841889901238485.png" ID="ID_325844559" CREATED="1710523791064" MODIFIED="1710523791064">
<hook URI="Google%20Data%20Analytics%20Certificate_files/png_7285841889901238485.png" SIZE="0.57361376" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="determining structure or key properties" FOLDED="true" ID="ID_854901187" CREATED="1710523990806" MODIFIED="1710524723964">
<node TEXT="typeof(vector) #type" FOLDED="true" ID="ID_539988683" CREATED="1710524016360" MODIFIED="1710524067775">
<node TEXT="check if a vector is a specific type by using an is function:" FOLDED="true" ID="ID_1317025162" CREATED="1710524138630" MODIFIED="1710524145812">
<node TEXT="is.logical()" ID="ID_828482704" CREATED="1710524145813" MODIFIED="1710524157101"/>
<node TEXT="is.character()" ID="ID_221572606" CREATED="1710524157104" MODIFIED="1710524157104"/>
<node TEXT="is.integer()" ID="ID_1830602623" CREATED="1710524157103" MODIFIED="1710524157103"/>
<node TEXT="is.double()" ID="ID_787822818" CREATED="1710524157103" MODIFIED="1710524157103"/>
<node TEXT="is.logical()" ID="ID_715852870" CREATED="1710524157098" MODIFIED="1710524157098"/>
</node>
</node>
<node TEXT="length  #length" FOLDED="true" ID="ID_919850235" CREATED="1710524002395" MODIFIED="1710524084704">
<node TEXT="number of elements it contains" ID="ID_860863830" CREATED="1710524055155" MODIFIED="1710524089697"/>
</node>
</node>
</node>
<node TEXT="lists" FOLDED="true" ID="ID_547877937" CREATED="1710523674766" MODIFIED="1710523677388">
<node TEXT="elements can be of any type—like dates, data frames, vectors, matrices, and more. Lists can even contain other lists." ID="ID_1009154343" CREATED="1710524575943" MODIFIED="1710524596303"/>
<node TEXT="creating" FOLDED="true" ID="ID_1926840104" CREATED="1710524612269" MODIFIED="1710524615565">
<node TEXT="list(&quot;a&quot;, 1L, 1.5, TRUE)" ID="ID_67827334" CREATED="1710524615567" MODIFIED="1710524645986"/>
<node TEXT="list(list(list(1 , 3, 5)))" ID="ID_1902875717" CREATED="1710524657173" MODIFIED="1710524659969"/>
</node>
<node TEXT="naming" FOLDED="true" ID="ID_388165132" CREATED="1710524860946" MODIFIED="1710524863770">
<node TEXT="name the elements of a list when you first create it with the list() function:" FOLDED="true" ID="ID_723857444" CREATED="1710524863772" MODIFIED="1710524907799">
<node ID="ID_1968148425" CREATED="1710524912189" MODIFIED="1710524912189"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      list('Chicago' = 1, 'New York' = 2, 'Los Angeles' = 3)
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="determining structure" FOLDED="true" ID="ID_1984450947" CREATED="1710524712585" MODIFIED="1710524716603">
<node TEXT="str(list)" FOLDED="true" ID="ID_1742931218" CREATED="1710524728769" MODIFIED="1710524743617">
<node TEXT="example" FOLDED="true" ID="ID_1285303542" CREATED="1710524795027" MODIFIED="1710524842870">
<node TEXT="We run the function, then R tells us that the list contains four elements, and that the elements consist of four different types: character (chr), integer (int), number (num), and logical (logi)." ID="ID_602037755" CREATED="1710524795028" MODIFIED="1710524795028"/>
<node TEXT="str(list(&quot;a&quot;, 1L, 1.5, TRUE))" FOLDED="true" ID="ID_596100379" CREATED="1710524795027" MODIFIED="1710524795027">
<node TEXT="#&gt; List of 4" ID="ID_778853174" CREATED="1710524795028" MODIFIED="1710524795028"/>
<node TEXT="#&gt;  $ : chr &quot;a&quot;" ID="ID_1415269300" CREATED="1710524795030" MODIFIED="1710524795030"/>
<node TEXT="#&gt;  $ : int 1" ID="ID_1746057066" CREATED="1710524795030" MODIFIED="1710524795030"/>
<node TEXT="#&gt;  $ : num 1.5" ID="ID_1286430467" CREATED="1710524795030" MODIFIED="1710524795030"/>
<node TEXT="#&gt;  $ : logi TRUE" ID="ID_181873801" CREATED="1710524795030" MODIFIED="1710524795030"/>
</node>
<node TEXT="Let’s use the str() function to discover the structure of our second example.  First, let’s assign the list to the variable z to make it easier to input in the str() function." ID="ID_811889361" CREATED="1710524795030" MODIFIED="1710524795030"/>
<node TEXT="z &lt;- list(list(list(1 , 3, 5)))" ID="ID_1005392792" CREATED="1710524795031" MODIFIED="1710524795031"/>
<node TEXT="str(z)" FOLDED="true" ID="ID_1178316878" CREATED="1710524795032" MODIFIED="1710524795032">
<node TEXT="#&gt; List of 1" ID="ID_1646407291" CREATED="1710524795032" MODIFIED="1710524795032"/>
<node TEXT="#&gt;  $ :List of 1" ID="ID_696479027" CREATED="1710524795032" MODIFIED="1710524795032"/>
<node TEXT="#&gt;   ..$ :List of 3" ID="ID_1906093967" CREATED="1710524795033" MODIFIED="1710524795033"/>
<node TEXT="#&gt;   .. ..$ : num 1" ID="ID_1329155978" CREATED="1710524795033" MODIFIED="1710524795033"/>
<node TEXT="#&gt;   .. ..$ : num 3" ID="ID_888872839" CREATED="1710524795033" MODIFIED="1710524795033"/>
<node TEXT="#&gt;   .. ..$ : num 5" ID="ID_1622992521" CREATED="1710524795033" MODIFIED="1710524795033"/>
</node>
</node>
<node TEXT="The indentation of the $ symbols reflect the nested structure of this list. Here, there are three levels (so there is a list within a list within a list)." ID="ID_733983960" CREATED="1710524795034" MODIFIED="1710524795034"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="factors" FOLDED="true" ID="ID_187122986" CREATED="1710541152003" MODIFIED="1710541156118">
<node ID="ID_1790723408" TREE_ID="ID_1839732595"/>
<node TEXT="creating" FOLDED="true" ID="ID_1001647912" CREATED="1710541162422" MODIFIED="1710541169236">
<node TEXT="factor(vector)" ID="ID_1053197707" CREATED="1710541170376" MODIFIED="1710541182069"/>
</node>
</node>
<node TEXT="data frames" FOLDED="true" ID="ID_743047587" CREATED="1710523635570" MODIFIED="1710523650757">
<node TEXT="reference" FOLDED="true" ID="ID_159022680" CREATED="1710642029467" MODIFIED="1710642035283">
<node TEXT="a collection of columns" FOLDED="true" ID="ID_1787552513" CREATED="1710636149905" MODIFIED="1710636156547">
<node TEXT="like a spreadsheet or SQL table" ID="ID_181466734" CREATED="1710636157477" MODIFIED="1710636162711"/>
</node>
<node TEXT="columns should be named" FOLDED="true" ID="ID_410094790" CREATED="1710636194727" MODIFIED="1710636207700">
<node TEXT="using an empty column name can create problems later on" ID="ID_1018881048" CREATED="1710636207702" MODIFIED="1710636217936"/>
</node>
<node TEXT="data stored can be many different types" FOLDED="true" ID="ID_158815132" CREATED="1710636229143" MODIFIED="1710636234699">
<node TEXT="numeric" ID="ID_894605309" CREATED="1710636234701" MODIFIED="1710636237102"/>
<node TEXT="factor" ID="ID_572563112" CREATED="1710636237117" MODIFIED="1710636239288"/>
<node TEXT="character" ID="ID_1553978025" CREATED="1710636239303" MODIFIED="1710636242102"/>
</node>
<node TEXT="each column should contain the same number of data items" ID="ID_1407617749" CREATED="1710636248139" MODIFIED="1710636254727"/>
<node TEXT="Tidy data standards" FOLDED="true" ID="ID_720965918" CREATED="1710636411351" MODIFIED="1710636416097">
<node TEXT="variables are organized into columns" ID="ID_1700736899" CREATED="1710636416099" MODIFIED="1710636422277"/>
<node TEXT="observations are organized into rows" ID="ID_1300772060" CREATED="1710636422295" MODIFIED="1710636501690"/>
<node ID="ID_998879688" CREATED="1710636504302" MODIFIED="1710636504302"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      each value must have its own cell
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="creating" FOLDED="true" ID="ID_1568247350" CREATED="1710642040812" MODIFIED="1710642044061">
<node TEXT="data.frame(vector_1, vector_2, ...)" ID="ID_1242326563" CREATED="1710642044063" MODIFIED="1710642095052"/>
</node>
<node TEXT="referencing" FOLDED="true" ID="ID_1209768293" CREATED="1710820461509" MODIFIED="1710820464566">
<node TEXT="df$column_name" ID="ID_1502100726" CREATED="1710820469506" MODIFIED="1710820574175"/>
<node TEXT="df[,&quot;column_name &quot;] # my column name" ID="ID_1977425020" CREATED="1710820492051" MODIFIED="1710820555141"/>
<node TEXT="df[,1] # by index" ID="ID_1980087670" CREATED="1710820512352" MODIFIED="1710820548634"/>
</node>
<node TEXT="selecting" FOLDED="true" ID="ID_422653942" CREATED="1710642192741" MODIFIED="1710818988729">
<node TEXT="select(data_frame, columns )" ID="ID_1267175674" CREATED="1710701756505" MODIFIED="1710794368768">
<node TEXT="penguins %&gt;%" ID="ID_1288391987" CREATED="1710795195824" MODIFIED="1710795195824">
<node TEXT="select(-species) # all columns except for species" ID="ID_1979978310" CREATED="1710795195824" MODIFIED="1710795215549"/>
</node>
</node>
</node>
<node TEXT="cleaning" FOLDED="true" ID="ID_411686197" CREATED="1710820940473" MODIFIED="1710820942836">
<node TEXT="column names" FOLDED="true" ID="ID_1668582117" CREATED="1710820241074" MODIFIED="1710820243701">
<node TEXT="rename(new_column_name = old_column_name)" ID="ID_1972274005" CREATED="1710795275768" MODIFIED="1710795299648"/>
<node TEXT="rename_with(data_frame, toupper)" FOLDED="true" ID="ID_551728548" CREATED="1710795336044" MODIFIED="1710795384969">
<node TEXT="tolower" ID="ID_141426142" CREATED="1710795385867" MODIFIED="1710795389857"/>
</node>
<node TEXT="clean names(data_frame) # Resulting names are unique and consist only of the _ character, numbers, and letters. Capitalization preferences can be specified using the case parameter." ID="ID_157624049" CREATED="1710795393993" MODIFIED="1710821120095"/>
</node>
<node TEXT="df &lt;- drop_na(df) # drop rows containing missing values (NA) from a data frame" ID="ID_575055365" CREATED="1710820956194" MODIFIED="1710874122909"/>
</node>
<node TEXT="transform" FOLDED="true" ID="ID_929847397" CREATED="1710818962551" MODIFIED="1710818966227">
<node TEXT="add or edit variables" FOLDED="true" ID="ID_23228609" CREATED="1710820260542" MODIFIED="1710820265008">
<node TEXT="mutate(data_frame, new_variable = ...)" FOLDED="true" ID="ID_1195092729" CREATED="1710642195374" MODIFIED="1710642333347">
<node TEXT="mutate(people, age_in_20 = age + 20)" ID="ID_343163784" CREATED="1710642286766" MODIFIED="1710642286766"/>
</node>
</node>
<node TEXT="separate(employee, name, into=c(&apos;first_name&apos;, &apos;last_name&apos;), sep=&apos; &apos;)" ID="ID_1436820860" CREATED="1710819241139" MODIFIED="1710819241139"/>
<node TEXT="unite(variable1and2, c(variable_one, variable_two))" ID="ID_1486442297" CREATED="1710818135096" MODIFIED="1710818203268"/>
<node TEXT="wide &lt;-&gt; long" FOLDED="true" ID="ID_121727630" CREATED="1710819933303" MODIFIED="1710819947409">
<node TEXT="pivot_longer()" ID="ID_517920200" CREATED="1710819952065" MODIFIED="1710819957410"/>
<node TEXT="pivot_wider()" ID="ID_1184184827" CREATED="1710819958295" MODIFIED="1710820237826"/>
</node>
</node>
<node TEXT="organize" FOLDED="true" ID="ID_88258724" CREATED="1710820742881" MODIFIED="1710820746416">
<node TEXT="filter(df, df$var==&quot;City Hotel&quot;)" ID="ID_1133763616" CREATED="1710820817097" MODIFIED="1710865021667">
<node TEXT="data %&gt;%    filter(variable1 == &quot;DS&quot;) %&gt;%   ggplot(aes(x = weight, y = variable2, colour = variable1)) +   geom_point(alpha = 0.3,  position = position_jitter()) + stat_smooth(method = &quot;lm&quot;)" ID="ID_1839365489" CREATED="1710886509432" MODIFIED="1710886509432"/>
</node>
<node TEXT="sorting" FOLDED="true" ID="ID_1504001065" CREATED="1710798896322" MODIFIED="1710798900426">
<node TEXT="data_frame %&gt;% arrange(variable)" FOLDED="true" ID="ID_278843560" CREATED="1710798900429" MODIFIED="1710798972757">
<node TEXT="arrange(-variable) # descending order" FOLDED="true" ID="ID_1680882807" CREATED="1710798945041" MODIFIED="1710798958647">
<node TEXT="arrange(desc(variable)) # descending order" ID="ID_1209497459" CREATED="1710798945041" MODIFIED="1710864772365"/>
</node>
</node>
</node>
<node TEXT="group by" FOLDED="true" ID="ID_1842408487" CREATED="1710799029777" MODIFIED="1710799046682">
<node TEXT="penguins %&gt;%" FOLDED="true" ID="ID_1034171980" CREATED="1710799173514" MODIFIED="1710799173514">
<node TEXT="group_by(island) %&gt;%" ID="ID_82385066" CREATED="1710799173514" MODIFIED="1710799173514"/>
<node TEXT="drop_na() %&gt;%" ID="ID_1764111612" CREATED="1710799173514" MODIFIED="1710799173514"/>
<node TEXT="summarise(mean_bill_length_mm = mean(bill_length_mm))" ID="ID_1283345923" CREATED="1710799173514" MODIFIED="1710799173514"/>
</node>
</node>
</node>
<node TEXT="summary statistics" FOLDED="true" ID="ID_225648516" CREATED="1710865651028" MODIFIED="1710865654584">
<node TEXT="summarise(mean_bill_length_mm = mean(bill_length_mm))" ID="ID_1060061623" CREATED="1710799173514" MODIFIED="1710799173514">
<node TEXT="mean(), max(), min(), sd(), cor(x,y)" ID="ID_649649685" CREATED="1710864833556" MODIFIED="1710865629226"/>
</node>
</node>
<node TEXT="splitting and combining" ID="ID_629737431" CREATED="1710818120284" MODIFIED="1710818133598"/>
<node TEXT="tibbles" FOLDED="true" ID="ID_1006530556" CREATED="1710636266889" MODIFIED="1710636273840">
<node TEXT="reference" FOLDED="true" ID="ID_1416094483" CREATED="1710642924075" MODIFIED="1710642928786">
<node TEXT="pull only the first 10 rows of a dataset" ID="ID_20893200" CREATED="1710642613985" MODIFIED="1710642667299"/>
<node TEXT="never change the datatypes of the inputs" ID="ID_820547091" CREATED="1710636274898" MODIFIED="1710636293101"/>
<node TEXT="never change the name of your variables" ID="ID_976063705" CREATED="1710636293122" MODIFIED="1710636297099"/>
<node TEXT="never create row names" ID="ID_1814884644" CREATED="1710636297123" MODIFIED="1710636300685"/>
<node TEXT="make printing easier" FOLDED="true" ID="ID_1691913868" CREATED="1710636300700" MODIFIED="1710636339104">
<node TEXT="automatically set to pull up only the first 10 Rose" ID="ID_1538697615" CREATED="1710636339105" MODIFIED="1710636355507"/>
</node>
</node>
<node TEXT="creating" FOLDED="true" ID="ID_682272108" CREATED="1710642933116" MODIFIED="1710642935879">
<node TEXT="as_tibble(data_frame)" ID="ID_1531934194" CREATED="1710642935880" MODIFIED="1710642959902"/>
</node>
</node>
</node>
<node TEXT="matrices" ID="ID_1866691617" CREATED="1710523650768" MODIFIED="1710523653757"/>
<node TEXT="arrays" ID="ID_1740285117" CREATED="1710523653769" MODIFIED="1710523656956"/>
<node TEXT="addressing bias" FOLDED="true" ID="ID_613859465" CREATED="1710864105364" MODIFIED="1710864166468">
<node TEXT="bias() # shows standard bias (average difference between sample and population, default) between two vectors or data frames" ID="ID_173597487" CREATED="1710864166471" MODIFIED="1710864263739"/>
<node TEXT="sample() # allows you to take a random sample of elements from a data set" ID="ID_206746505" CREATED="1710864172173" MODIFIED="1710864326700"/>
</node>
</node>
<node TEXT="data sets" FOLDED="true" ID="ID_850399448" CREATED="1710543871066" MODIFIED="1710544062277">
<node TEXT="built-in" FOLDED="true" ID="ID_1222723371" CREATED="1710643207270" MODIFIED="1710643209440">
<node TEXT="load" FOLDED="true" ID="ID_1876302061" CREATED="1710544064609" MODIFIED="1710544066660">
<node TEXT="data(&quot;dataset&quot;)" ID="ID_623309023" CREATED="1710543874712" MODIFIED="1710543885445"/>
<node TEXT="data() # see what data sets are in package &apos;datasets&apos;" ID="ID_251051257" CREATED="1710543886645" MODIFIED="1710543950425"/>
</node>
</node>
<node TEXT="importing" FOLDED="true" ID="ID_241021731" CREATED="1710643227788" MODIFIED="1710643229832">
<node TEXT="reference" FOLDED="true" ID="ID_1875264383" CREATED="1710644064682" MODIFIED="1710644066815">
<node ID="ID_973419992" CREATED="1710644103958" MODIFIED="1710644103958" LINK="https://r4ds.hadley.nz/data-import.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://r4ds.hadley.nz/data-import.html">R for Data Science (2e) - 7&#xa0;&#xa0;Data import</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="csvs, etc" FOLDED="true" ID="ID_977431257" CREATED="1710643754021" MODIFIED="1710643758525">
<node TEXT="readr package" FOLDED="true" ID="ID_1248652352" CREATED="1710643453975" MODIFIED="1710643499367">
<node TEXT="sample" FOLDED="true" ID="ID_120518448" CREATED="1710643506141" MODIFIED="1710643508772">
<node TEXT="readr_example() #show sample files" ID="ID_1418068001" CREATED="1710643525354" MODIFIED="1710643593342"/>
<node TEXT="read_csv(readr_example(&quot;mtcars.csv&quot;))" ID="ID_507971547" CREATED="1710643663796" MODIFIED="1710643663796"/>
</node>
</node>
</node>
<node TEXT="spreadsheets" FOLDED="true" ID="ID_1083118341" CREATED="1710643764463" MODIFIED="1710643776261">
<node TEXT="library(readxl) # readxl package" FOLDED="true" ID="ID_197921607" CREATED="1710643776263" MODIFIED="1710643812529">
<node TEXT="sample" FOLDED="true" ID="ID_1790609642" CREATED="1710643881214" MODIFIED="1710643884614">
<node TEXT="read_excel(readxl_example(&quot;type-me.xlsx&quot;))" ID="ID_1301802243" CREATED="1710643886196" MODIFIED="1710643886196"/>
</node>
<node TEXT="list names of sheets" FOLDED="true" ID="ID_84800185" CREATED="1710643916622" MODIFIED="1710643933074">
<node TEXT="excel_sheets(readxl_example(&quot;type-me.xlsx&quot;))" ID="ID_8879168" CREATED="1710643946983" MODIFIED="1710643946983"/>
</node>
<node TEXT="specific sheet" FOLDED="true" ID="ID_218485504" CREATED="1710643871427" MODIFIED="1710643994992">
<node TEXT="read_excel(readxl_example(&quot;type-me.xlsx&quot;), sheet = &quot;numeric_coercion&quot;)" ID="ID_427574918" CREATED="1710644001169" MODIFIED="1710644001169"/>
</node>
</node>
</node>
</node>
<node TEXT="view(dataset)" ID="ID_1246919687" CREATED="1710544072190" MODIFIED="1710544104403"/>
</node>
<node TEXT="summary functions" FOLDED="true" ID="ID_1695598059" CREATED="1710641672920" MODIFIED="1710641676216">
<node TEXT="skim_without_charts()" ID="ID_433345019" CREATED="1710793987770" MODIFIED="1710794011135"/>
<node TEXT="colnames(bookings_df)" ID="ID_810154921" CREATED="1710701625762" MODIFIED="1710701625762"/>
<node TEXT="head()" ID="ID_1819756700" CREATED="1710641678526" MODIFIED="1710641682879"/>
<node TEXT="tail()" ID="ID_1172974063" CREATED="1710643350363" MODIFIED="1710643352428"/>
<node TEXT="glimpse()" ID="ID_1770906634" CREATED="1710641683578" MODIFIED="1710641688726"/>
<node TEXT="str()" ID="ID_67778830" CREATED="1710641690518" MODIFIED="1710641695358"/>
<node TEXT="spec()" ID="ID_673690618" CREATED="1710643703951" MODIFIED="1710643706592"/>
</node>
</node>
<node TEXT="pipes" FOLDED="true" ID="ID_695677209" CREATED="1710522288588" MODIFIED="1710522290606">
<node TEXT="reference" FOLDED="true" ID="ID_1126541532" CREATED="1710542879499" MODIFIED="1710542881652">
<node ID="ID_584493890" CREATED="1710542882485" MODIFIED="1710542882485" LINK="https://www.datacamp.com/tutorial/pipe-r-tutorial"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.datacamp.com/tutorial/pipe-r-tutorial">Pipes in R Tutorial For Beginners | Discover %&gt;% with magrittr | DataCamp</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="a tool in R for expressing a sequence of multiple operations" FOLDED="true" ID="ID_1923000551" CREATED="1710522774906" MODIFIED="1710522786849">
<node TEXT="takes the output of one statement and makes it the input of the next" ID="ID_1968643247" CREATED="1710543127832" MODIFIED="1710543141650"/>
<node TEXT="nested: describes code that performs a particular function and is contained within code that performs a broader function" ID="ID_942343955" CREATED="1710543143042" MODIFIED="1710543255867"/>
<node TEXT="&quot;and then&quot;" FOLDED="true" ID="ID_1003064434" CREATED="1710543269035" MODIFIED="1710543274899">
<node TEXT="example" FOLDED="true" ID="ID_745129705" CREATED="1710543295670" MODIFIED="1710543298626">
<node TEXT="call up data (and then)" ID="ID_1314690993" CREATED="1710543298629" MODIFIED="1710543310679"/>
<node TEXT="group the data (and then)" ID="ID_231095994" CREATED="1710543312030" MODIFIED="1710543320027"/>
<node TEXT="summarize the group data using a mean function" ID="ID_1770782504" CREATED="1710543320044" MODIFIED="1710543326259"/>
</node>
</node>
</node>
</node>
<node TEXT="represented with %&gt;%" FOLDED="true" ID="ID_1071375582" CREATED="1710522787809" MODIFIED="1710522809891">
<node TEXT="or |&gt;" ID="ID_1492563177" CREATED="1710645502491" MODIFIED="1710645510319"/>
</node>
<node TEXT="add the pipe operator at the end of each line of the piped operation except the last one" ID="ID_145218815" CREATED="1710544701499" MODIFIED="1710544850034"/>
<node TEXT="check your code after you&apos;ve programmed your pipe" FOLDED="true" ID="ID_837700504" CREATED="1710544723636" MODIFIED="1710544729470">
<node TEXT="automatically indents" ID="ID_550120548" CREATED="1710544739631" MODIFIED="1710544744070"/>
<node TEXT="revisit piped operations to check for parts of your code to fix" ID="ID_1763715338" CREATED="1710544746239" MODIFIED="1710544772452"/>
</node>
</node>
<node TEXT="visualizations" ID="ID_330535100" CREATED="1710867924482" MODIFIED="1710867927459">
<node TEXT="packages" ID="ID_152105572" CREATED="1710868094506" MODIFIED="1710868096408">
<node TEXT="ggplot2" ID="ID_1028055662" CREATED="1710867979008" MODIFIED="1710868213541">
<font BOLD="true"/>
<node TEXT="reference" ID="ID_729774840" CREATED="1710872692415" MODIFIED="1710872694958">
<node ID="ID_367592487" CREATED="1710872696124" MODIFIED="1710872696124" LINK="https://ggplot2.tidyverse.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://ggplot2.tidyverse.org/">Create Elegant Data Visualisations Using the Grammar of Graphics • ggplot2</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="about" ID="ID_1819308541" CREATED="1710868396190" MODIFIED="1710868397869">
<node TEXT="create different types of plots" FOLDED="true" ID="ID_1924137311" CREATED="1710868299527" MODIFIED="1710868303284">
<node TEXT="scatterplots" ID="ID_1871982462" CREATED="1710868303286" MODIFIED="1710868306317"/>
<node TEXT="bar charts" ID="ID_1571873086" CREATED="1710868306332" MODIFIED="1710868313533"/>
<node TEXT="line diagrams" ID="ID_150850229" CREATED="1710868313545" MODIFIED="1710868316539"/>
</node>
<node TEXT="customize the look and feel of plots" ID="ID_1184235507" CREATED="1710868318323" MODIFIED="1710868323088"/>
<node TEXT="create high-quality visuals" ID="ID_777284161" CREATED="1710868323109" MODIFIED="1710868326687"/>
<node TEXT="combined data manipulation and visualization" ID="ID_1555017980" CREATED="1710868326705" MODIFIED="1710868332311"/>
</node>
<node TEXT="how to" FOLDED="true" ID="ID_1916573864" CREATED="1710873336228" MODIFIED="1710873338466">
<node TEXT="start with the GG plot function and choose a dataset to work with" ID="ID_1823446269" CREATED="1710873340322" MODIFIED="1710873348901"/>
<node TEXT="add geom_ function to display your data" ID="ID_290730858" CREATED="1710873348920" MODIFIED="1710873373548"/>
<node TEXT="map the variables you want to plot in the arguments of the aes() function " ID="ID_182506530" CREATED="1710873374135" MODIFIED="1710873399044"/>
</node>
<node TEXT="example" FOLDED="true" ID="ID_443921154" CREATED="1710872594349" MODIFIED="1710872596827">
<node FOLDED="true" ID="ID_347360030" CREATED="1710872599184" MODIFIED="1710873103709"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <b>ggplot</b>(data = penguins) + <b>geom_point</b>(mapping = <b>aes</b>(x = flipper_length_mm, y = body_mass_g))
    </p>
  </body>
</html>
</richcontent>
<node TEXT="geom_point # add points" ID="ID_1838756100" CREATED="1710873154366" MODIFIED="1710873183859"/>
<node TEXT="mapping = aes # aesthetics" ID="ID_866845998" CREATED="1710873185050" MODIFIED="1710873194124"/>
<node TEXT="ggplot(data = penguins, mapping = aes(x = flipper_length_mm, y = body_mass_g)) +  geom_point()" ID="ID_718498233" CREATED="1710872650189" MODIFIED="1710872650189"/>
<node TEXT="+ # add a layer" ID="ID_1745310138" CREATED="1710873108380" MODIFIED="1710873117261"/>
</node>
</node>
<node TEXT="components" ID="ID_830876997" CREATED="1710868406470" MODIFIED="1710868409189">
<node TEXT="aesthetic" FOLDED="true" ID="ID_1961528390" CREATED="1710868409193" MODIFIED="1710868412427">
<node TEXT="visual property of an object in your plot" FOLDED="true" ID="ID_523695143" CREATED="1710868417680" MODIFIED="1710868458131">
<node TEXT="size" ID="ID_1770309137" CREATED="1710878037093" MODIFIED="1710878039940"/>
<node TEXT="shape" ID="ID_1409830543" CREATED="1710878039950" MODIFIED="1710878042130"/>
<node TEXT="color" ID="ID_36778437" CREATED="1710878042146" MODIFIED="1710878044531"/>
<node TEXT="alpha" ID="ID_1049412443" CREATED="1710878044543" MODIFIED="1710878048083"/>
</node>
<node TEXT="mapping" FOLDED="true" ID="ID_1451831418" CREATED="1710873227483" MODIFIED="1710873230699">
<node TEXT="matching up a specific variable in your dataset with a specific aesthetic" ID="ID_1802838503" CREATED="1710873230700" MODIFIED="1710873236944"/>
<node TEXT="example" FOLDED="true" ID="ID_1169875194" CREATED="1710873254699" MODIFIED="1710873275694">
<node TEXT="variable to x or y axis" ID="ID_1314407460" CREATED="1710873277381" MODIFIED="1710873277381"/>
<node TEXT="variable to color" ID="ID_1804923137" CREATED="1710873278494" MODIFIED="1710873284325"/>
</node>
</node>
<node TEXT="example" FOLDED="true" ID="ID_414182508" CREATED="1710878162181" MODIFIED="1710878165106">
<node TEXT="ggplot(data = penguins) + geom_point(mapping = aes(x = flipper_length_mm , y = body_mass_g, alpha =species),color = &quot;purple&quot;)" FOLDED="true" ID="ID_616691373" CREATED="1710878166557" MODIFIED="1710878166557">
<node TEXT="alpha mapped to species, color is applied to all points, since it&apos;s on the outside of the aes()" ID="ID_1795013984" CREATED="1710878169158" MODIFIED="1710878202054"/>
</node>
</node>
</node>
<node TEXT="Geoms" ID="ID_489175128" CREATED="1710868428726" MODIFIED="1710868431293">
<node TEXT="geometrical object used to represent your data" ID="ID_1125699042" CREATED="1710868480330" MODIFIED="1710878329213">
<node TEXT="geom_points" FOLDED="true" ID="ID_610485191" CREATED="1710868487384" MODIFIED="1710878351174">
<node TEXT="relationship between two quantitative variables" ID="ID_658177681" CREATED="1710868500568" MODIFIED="1710868506764"/>
</node>
<node TEXT="geom_jitter" ID="ID_1013538692" CREATED="1710878753370" MODIFIED="1710878757728"/>
<node TEXT="geom_bars" ID="ID_1832254708" CREATED="1710868490489" MODIFIED="1710878355542">
<node TEXT="bar charts" ID="ID_1748116158" CREATED="1710878367681" MODIFIED="1710878369872"/>
<node TEXT="counts are y axis (default)" ID="ID_1770634902" CREATED="1710878874783" MODIFIED="1710878887790"/>
<node TEXT="example" ID="ID_1781038641" CREATED="1710957822085" MODIFIED="1710957827121">
<node TEXT="ggplot(data = hotel_bookings) +" ID="ID_1545784605" CREATED="1710957840307" MODIFIED="1710957840307"/>
<node TEXT="geom_bar(mapping = aes(x = distribution_channel)) +" ID="ID_216228698" CREATED="1710957840307" MODIFIED="1710957840307"/>
<node TEXT="facet_wrap(~deposit_type)" ID="ID_1090121940" CREATED="1710957840308" MODIFIED="1710957840308"/>
</node>
</node>
<node TEXT="geom_lines" ID="ID_20899390" CREATED="1710868492435" MODIFIED="1710878358993"/>
<node TEXT="geom_smooth" FOLDED="true" ID="ID_858221917" CREATED="1710878459141" MODIFIED="1710878463094">
<node TEXT="smooth trend line that fits the data" ID="ID_868485817" CREATED="1710878466245" MODIFIED="1710888438396"/>
</node>
</node>
</node>
<node TEXT="Facets" ID="ID_608252445" CREATED="1710868431784" MODIFIED="1710868434126">
<node TEXT="let you display smaller groups, subsets, of your data" ID="ID_1426539680" CREATED="1710868512106" MODIFIED="1710868521380">
<node TEXT="create separate paths for variables" ID="ID_771025576" CREATED="1710868522057" MODIFIED="1710868526702"/>
<node TEXT="facet_wrap" ID="ID_762902839" CREATED="1710885111707" MODIFIED="1710885160901">
<node TEXT="facet your plot by a single variable" ID="ID_332104645" CREATED="1710885166685" MODIFIED="1710885173018">
<node TEXT="compare data trends across a variable" ID="ID_1515170902" CREATED="1710888503563" MODIFIED="1710888517734"/>
</node>
<node TEXT="example" ID="ID_965531284" CREATED="1710885284375" MODIFIED="1710885286874">
<node TEXT="ggplot(data = penguins) +" ID="ID_1411256627" CREATED="1710885288624" MODIFIED="1710885288624">
<node TEXT="geom_point(mapping = aes(x = flipper_length_mm , y = body_mass_g),color = &quot;purple&quot;) +" ID="ID_147806926" CREATED="1710885288624" MODIFIED="1710885288624"/>
<node TEXT="facet_wrap(~species)" ID="ID_1386573968" CREATED="1710885288624" MODIFIED="1710885288624"/>
</node>
</node>
</node>
<node TEXT="facet_grid" FOLDED="true" ID="ID_1350742595" CREATED="1710885619537" MODIFIED="1710885624370">
<node TEXT="split the plot into facets vertically by the values of the first variable and horizontally by the values of the second variable." ID="ID_614527314" CREATED="1710885639634" MODIFIED="1710885639634"/>
<node TEXT="example" FOLDED="true" ID="ID_391503123" CREATED="1710885653741" MODIFIED="1710885655659">
<node TEXT="ggplot(data = penguins) +" FOLDED="true" ID="ID_250596939" CREATED="1710885715039" MODIFIED="1710885715039">
<node TEXT="geom_point(mapping = aes(x = flipper_length_mm , y = body_mass_g, color = species )) +" ID="ID_1784489182" CREATED="1710885715039" MODIFIED="1710885715039"/>
<node TEXT="facet_grid(sex~species)" ID="ID_870965442" CREATED="1710885715039" MODIFIED="1710885715039"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Labels and annotations" ID="ID_244301541" CREATED="1710868434572" MODIFIED="1710868438202">
<node TEXT="about" FOLDED="true" ID="ID_28370161" CREATED="1710888825456" MODIFIED="1710888827216">
<node TEXT="helps explain the plots purpose or highlight important data" ID="ID_754488615" CREATED="1710888800270" MODIFIED="1710888806206"/>
<node TEXT="annotate" FOLDED="true" ID="ID_1252180998" CREATED="1710888760485" MODIFIED="1710888768362">
<node TEXT="to add notes to a document or diagram to explain or comment upon it" ID="ID_907697347" CREATED="1710888768365" MODIFIED="1710888784770"/>
</node>
<node TEXT="let you customize your plots" FOLDED="true" ID="ID_1420369060" CREATED="1710868527870" MODIFIED="1710868532349">
<node TEXT="titles" ID="ID_417066670" CREATED="1710868533343" MODIFIED="1710868536332"/>
<node TEXT="subtitles" ID="ID_1672830845" CREATED="1710868536598" MODIFIED="1710868538248"/>
<node TEXT="captions" ID="ID_801360097" CREATED="1710868538485" MODIFIED="1710868540551"/>
</node>
</node>
<node TEXT="+ labs() # labels" ID="ID_1754338399" CREATED="1710888856104" MODIFIED="1710889338197">
<node TEXT="captions" ID="ID_1265812515" CREATED="1710889185927" MODIFIED="1710889188098"/>
<node TEXT="title" ID="ID_1666457111" CREATED="1710889259206" MODIFIED="1710889261854"/>
<node TEXT="subtitle" ID="ID_384806068" CREATED="1710889262120" MODIFIED="1710889263882"/>
<node TEXT="captions" ID="ID_1829364010" CREATED="1710889264161" MODIFIED="1710889266274"/>
<node TEXT="example" ID="ID_1812001747" CREATED="1710889281521" MODIFIED="1710889283247">
<node TEXT="ggplot(data = penguins) +" ID="ID_1523842940" CREATED="1710889297842" MODIFIED="1710889297842">
<node TEXT="geom_point(mapping = aes(x = flipper_length_mm , y = body_mass_g, color=species)) +" ID="ID_1792203975" CREATED="1710889297843" MODIFIED="1710889297843"/>
<node TEXT="labs(title =&quot;Palmer Penguins: Body Mass vs. Flipper Length&quot;, subtitle=&quot;Sample Of Three Penguins Species&quot;, caption = &quot;Data Collected By Doctor Kristin&quot;)" ID="ID_468998607" CREATED="1710889297843" MODIFIED="1710889297843"/>
</node>
</node>
</node>
<node TEXT="+ annotate()" FOLDED="true" ID="ID_780743688" CREATED="1710889302032" MODIFIED="1710889354909">
<node TEXT="example" FOLDED="true" ID="ID_1859923084" CREATED="1710889316701" MODIFIED="1710889539830">
<node TEXT="ggplot(data = penguins) +" FOLDED="true" ID="ID_1619175854" CREATED="1710889543860" MODIFIED="1710889543860">
<node TEXT="geom_point(mapping = aes(x = flipper_length_mm , y = body_mass_g, color=species)) +" ID="ID_586444613" CREATED="1710889543860" MODIFIED="1710889543860"/>
<node TEXT="labs(title =&quot;Palmer Penguins: Body Mass vs. Flipper Length&quot;, subtitle=&quot;Sample Of Three Penguins Species&quot;, caption = &quot;Data Collected By Doctor Kristin&quot;) +" ID="ID_1187600126" CREATED="1710889543860" MODIFIED="1710889543860"/>
<node TEXT="annotate(&quot;text&quot;, x=220,y=3500, label=&quot;The Gentoos are the largest&quot;,color = &quot;purple&quot;, fontface=&quot;bold&quot;, size=4.5, angle=25)" ID="ID_503818567" CREATED="1710889543860" MODIFIED="1710889543860"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="saving" ID="ID_20434806" CREATED="1710889685966" MODIFIED="1710889687661">
<node TEXT="Export option" FOLDED="true" ID="ID_819735618" CREATED="1710889721532" MODIFIED="1710891240099">
<font BOLD="true"/>
<node TEXT="Plots .. Export" ID="ID_1240905361" CREATED="1710889803718" MODIFIED="1710889909087"/>
</node>
<node TEXT="ggsave() option" ID="ID_308679498" CREATED="1710889731800" MODIFIED="1710891240100">
<font BOLD="true"/>
</node>
<node TEXT="graphics device" FOLDED="true" ID="ID_1490686807" CREATED="1710890183201" MODIFIED="1710890186909">
<node TEXT="png()" FOLDED="true" ID="ID_166977316" CREATED="1710890190193" MODIFIED="1710890194413">
<node TEXT="png(file = &quot;exampleplot.png&quot;, bg = &quot;transparent&quot;)" ID="ID_73422328" CREATED="1710890260051" MODIFIED="1710890260051"/>
<node TEXT="plot(1:10)" ID="ID_1375832371" CREATED="1710890260051" MODIFIED="1710890260051"/>
<node TEXT="rect(1, 5, 3, 7, col = &quot;white&quot;)" ID="ID_1444228326" CREATED="1710890260053" MODIFIED="1710890260053"/>
<node TEXT="dev.off()" ID="ID_1195095761" CREATED="1710890260054" MODIFIED="1710890260054"/>
</node>
<node TEXT="pdf()" FOLDED="true" ID="ID_727177552" CREATED="1710890204354" MODIFIED="1710890285910">
<node TEXT="pdf(file = &quot;/Users/username/Desktop/example.pdf&quot;," FOLDED="true" ID="ID_713165469" CREATED="1710890282432" MODIFIED="1710890282432">
<node TEXT="width = 4," ID="ID_35068115" CREATED="1710890282432" MODIFIED="1710890282432"/>
<node TEXT="height = 4)" ID="ID_668820671" CREATED="1710890282432" MODIFIED="1710890282432"/>
</node>
<node TEXT="plot(x = 1:10," FOLDED="true" ID="ID_687817676" CREATED="1710890282432" MODIFIED="1710890282432">
<node TEXT="y = 1:10)" ID="ID_1391882554" CREATED="1710890282435" MODIFIED="1710890282435"/>
</node>
<node TEXT="abline(v = 0)" ID="ID_469817523" CREATED="1710890282435" MODIFIED="1710890282435"/>
<node TEXT="text(x = 0, y = 1, labels = &quot;Random text&quot;)" ID="ID_1450191525" CREATED="1710890282436" MODIFIED="1710890282436"/>
<node TEXT="dev.off()" ID="ID_413878213" CREATED="1710890282437" MODIFIED="1710890282437"/>
</node>
</node>
</node>
</node>
<node TEXT="Plotly" ID="ID_1626304962" CREATED="1710868105812" MODIFIED="1710868109483"/>
<node TEXT="Lattice" ID="ID_226182816" CREATED="1710868122033" MODIFIED="1710868147304"/>
<node TEXT="RGL" FOLDED="true" ID="ID_200816082" CREATED="1710868111084" MODIFIED="1710868113545">
<node TEXT="focus on 3D visuals" ID="ID_1400157150" CREATED="1710868114132" MODIFIED="1710868117906"/>
</node>
<node TEXT="Dygraphs" ID="ID_1861278132" CREATED="1710868138098" MODIFIED="1710868159504"/>
<node TEXT="Leaflet" ID="ID_1725634791" CREATED="1710868159519" MODIFIED="1710868163085"/>
<node TEXT="Highcharter" ID="ID_1408675617" CREATED="1710868163099" MODIFIED="1710868170492"/>
<node TEXT="Patchwork" ID="ID_1027918503" CREATED="1710868170507" MODIFIED="1710868174288"/>
<node TEXT="gganimate" ID="ID_1544392491" CREATED="1710868175485" MODIFIED="1710868180228"/>
<node TEXT="ggbridges" ID="ID_541179218" CREATED="1710868180615" MODIFIED="1710868184180"/>
</node>
</node>
<node TEXT="documentation and reports" ID="ID_1946851694" CREATED="1710945224490" MODIFIED="1710945229886">
<node TEXT="R Markdown" ID="ID_57816152" CREATED="1710945229895" MODIFIED="1710945235599">
<node TEXT="overview" FOLDED="true" ID="ID_176318" CREATED="1710945442874" MODIFIED="1710945445864">
<node TEXT="Markdown" ID="ID_1743539745" CREATED="1710945664695" MODIFIED="1710945672339">
<node TEXT="syntax for formatting plain text files" ID="ID_1942703586" CREATED="1710945673172" MODIFIED="1710945681269"/>
</node>
<node TEXT="R Notebook" ID="ID_3748210" CREATED="1710945746886" MODIFIED="1710945751897">
<node TEXT="lets users run your code and show the graphs and charts that visualize the code" ID="ID_1892417258" CREATED="1710945751899" MODIFIED="1710945765472"/>
</node>
<node TEXT="file format for making dynamic documents with R" ID="ID_1090183555" CREATED="1710945323492" MODIFIED="1710945330305"/>
<node TEXT="use file as a code notebook to save, organize, and document your analysis" ID="ID_1889131914" CREATED="1710945339297" MODIFIED="1710945352475"/>
<node TEXT="create a report" ID="ID_1852711498" CREATED="1710945356100" MODIFIED="1710945362953"/>
</node>
<node TEXT="install" ID="ID_1736439411" CREATED="1710945451683" MODIFIED="1710945455260"/>
<node TEXT="create document" ID="ID_355794464" CREATED="1710945455275" MODIFIED="1710945462053"/>
<node TEXT="structure and components" ID="ID_518189396" CREATED="1710945462068" MODIFIED="1710945471058">
<node TEXT="YAML header" FOLDED="true" ID="ID_183935174" CREATED="1710949070647" MODIFIED="1710949093729">
<node TEXT="---" ID="ID_1935376991" CREATED="1710949095848" MODIFIED="1710949095848"/>
<node TEXT="title: &quot;R Markdown Intro&quot;" ID="ID_1967193450" CREATED="1710949095848" MODIFIED="1710949095848"/>
<node TEXT="author: &quot;Michael McMillen&quot;" ID="ID_1508679513" CREATED="1710949095848" MODIFIED="1710949095848"/>
<node TEXT="output: html_document" ID="ID_733317057" CREATED="1710949095849" MODIFIED="1710949095849"/>
<node TEXT="date: &quot;2024-03-20&quot;" ID="ID_1814169837" CREATED="1710949095849" MODIFIED="1710949095849"/>
<node TEXT="---" ID="ID_962687479" CREATED="1710949095850" MODIFIED="1710949095850"/>
</node>
<node TEXT="Text" ID="ID_1498047878" CREATED="1710949137261" MODIFIED="1710949141445">
<node TEXT="# Headers" ID="ID_1227437961" CREATED="1710949142532" MODIFIED="1710949148705">
<node TEXT="## Smaller Header" ID="ID_1240386157" CREATED="1710949341452" MODIFIED="1710949347357"/>
</node>
<node TEXT="new paragraph (two spaces at end of sentence)" ID="ID_1298357129" CREATED="1710949164932" MODIFIED="1710949192530"/>
<node TEXT="**Bold Text**" ID="ID_47404640" CREATED="1710949175592" MODIFIED="1710949215870"/>
<node TEXT="*Italics* or _Italics_" ID="ID_1938636705" CREATED="1710949172015" MODIFIED="1710949236839"/>
<node TEXT="* Bullet 1 ..." ID="ID_252674638" CREATED="1710950233004" MODIFIED="1710950263513"/>
<node TEXT="&lt;http://link.com&gt;" ID="ID_387785312" CREATED="1710949168365" MODIFIED="1710949274171"/>
<node TEXT="Embeded link" ID="ID_1288024865" CREATED="1710950296908" MODIFIED="1710950306524">
<node TEXT="[click here](http://link.com)" ID="ID_1332903507" CREATED="1710950307492" MODIFIED="1710950598395"/>
</node>
<node TEXT="Embedded image" ID="ID_297142158" CREATED="1710950393314" MODIFIED="1710950396721">
<node TEXT="![Caption](http:image.com/image.jpg)" ID="ID_431304674" CREATED="1710950397853" MODIFIED="1710950438927"/>
</node>
<node TEXT="`r in-line code` (back ticks)" ID="ID_715879838" CREATED="1710949442205" MODIFIED="1710949755384">
<node TEXT="executed when the document is rendered" ID="ID_979487024" CREATED="1710949675372" MODIFIED="1710949685758"/>
<node TEXT="dynamically generates values or text" ID="ID_1666969753" CREATED="1710949685774" MODIFIED="1710949693982"/>
<node TEXT="example: The mean of `r mean(c(1, 2, 3))` is calculated using inline code." ID="ID_1837393285" CREATED="1710949768360" MODIFIED="1710949776982"/>
</node>
</node>
<node TEXT="code chunks (insert and edit pieces of code)" ID="ID_191108999" CREATED="1710945471074" MODIFIED="1710954068463">
<node TEXT="about" ID="ID_1234236334" CREATED="1710949698560" MODIFIED="1710949700769">
<node TEXT="separated from the main text of the document" ID="ID_198528278" CREATED="1710949700772" MODIFIED="1710949717754"/>
<node TEXT="allow for the execution of multiple lines of r code" ID="ID_43468096" CREATED="1710949717771" MODIFIED="1710949730379"/>
</node>
<node TEXT="``` {r &lt;chunk name&gt;}" ID="ID_1938817042" CREATED="1710948451975" MODIFIED="1710954438678">
<node TEXT="chunk options" ID="ID_1462428301" CREATED="1710948495329" MODIFIED="1710954531240">
<node TEXT="reference" ID="ID_865958125" CREATED="1710954533030" MODIFIED="1710954535032">
<node ID="ID_1487021796" CREATED="1710954536307" MODIFIED="1710954536307" LINK="https://yihui.org/knitr/options/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://yihui.org/knitr/options/">Options - Chunk options and package options - Yihui Xie | 谢益辉</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="default values for the document" ID="ID_818238452" CREATED="1710954587421" MODIFIED="1710954615431">
<node TEXT="```{r, setup, include=FALSE}" ID="ID_1997132644" CREATED="1710954617434" MODIFIED="1710954617434"/>
<node TEXT="knitr::opts_chunk$set(" ID="ID_354523819" CREATED="1710954617434" MODIFIED="1710954617434">
<node TEXT="comment = &apos;&apos;, fig.width = 6, fig.height = 6" ID="ID_864163575" CREATED="1710954617435" MODIFIED="1710954617435"/>
</node>
<node TEXT=")" ID="ID_1371667533" CREATED="1710954617435" MODIFIED="1710954617435"/>
<node TEXT="```" ID="ID_323309778" CREATED="1710954617436" MODIFIED="1710954617436"/>
</node>
<node TEXT="echo = FALSE" ID="ID_1103384534" CREATED="1710948500048" MODIFIED="1710948509796">
<node TEXT="prevent printing of the R code that generated the plot." ID="ID_771540027" CREATED="1710948509797" MODIFIED="1710948517936"/>
</node>
</node>
</node>
<node TEXT="code" ID="ID_1387677285" CREATED="1710949514663" MODIFIED="1710949524087"/>
<node TEXT="```" ID="ID_1841353621" CREATED="1710948466765" MODIFIED="1710949507486"/>
</node>
</node>
<node TEXT="export" ID="ID_1690575440" CREATED="1710945478475" MODIFIED="1710945481702">
<node TEXT="reference" ID="ID_1823463672" CREATED="1710955421426" MODIFIED="1710955423830">
<node ID="ID_1835454208" CREATED="1710955424246" MODIFIED="1710955424246"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/7%20Data%20Analysis%20With%20R%20Programming/M5%20Documentation%20and%20reports.one#Output formats in R Markdown&amp;section-id={172C5282-4C12-4E2A-BB3B-86F1D45F3337}&amp;page-id={29260527-C8F3-4149-BC92-8EC026386D47}&amp;end">Output formats in R Markdown</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%287%20Data%20Analysis%20With%20R%20Programming%2FM5%20Documentation%20and%20reports.one%7C172C5282-4C12-4E2A-BB3B-86F1D45F3337%2FOutput%20formats%20in%20R%20Markdown%7C29260527-C8F3-4149-BC92-8EC026386D47%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Knit" FOLDED="true" ID="ID_723832382" CREATED="1710955115007" MODIFIED="1710955119410">
<node TEXT="HTML" ID="ID_1866921740" CREATED="1710955120183" MODIFIED="1710955122616"/>
<node TEXT="PDF" ID="ID_780421443" CREATED="1710955123284" MODIFIED="1710955124739"/>
<node TEXT="Word" ID="ID_1700219462" CREATED="1710955125095" MODIFIED="1710955136205"/>
</node>
<node TEXT="can change YAML header" ID="ID_1071975491" CREATED="1710955158277" MODIFIED="1710955172993"/>
<node TEXT="create templates for repeated reports" ID="ID_1326162466" CREATED="1710955189071" MODIFIED="1710955208427">
<node TEXT="reference" ID="ID_1931978954" CREATED="1710955755208" MODIFIED="1710955757030">
<node ID="ID_1699808518" CREATED="1710955757865" MODIFIED="1710955757865"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/7%20Data%20Analysis%20With%20R%20Programming/M5%20Documentation%20and%20reports.one#Using R Markdown templates&amp;section-id={172C5282-4C12-4E2A-BB3B-86F1D45F3337}&amp;page-id={20A9D7F8-77FF-4C37-8B2B-1670E62CC95D}&amp;end">Using R Markdown templates</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%287%20Data%20Analysis%20With%20R%20Programming%2FM5%20Documentation%20and%20reports.one%7C172C5282-4C12-4E2A-BB3B-86F1D45F3337%2FUsing%20R%20Markdown%20templates%7C20A9D7F8-77FF-4C37-8B2B-1670E62CC95D%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1748569025" CREATED="1706739200792" MODIFIED="1706739203023">
<node ID="ID_576491431" CREATED="1706739205061" MODIFIED="1706739205061" LINK="https://www.coursera.org/learn/foundations-data/supplement/Yo3Cn/more-on-the-phases-of-data-analysis-and-this-program"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/foundations-data/supplement/Yo3Cn/more-on-the-phases-of-data-analysis-and-this-program">More on the phases of data analysis and this program | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Portfolio and data sources" FOLDED="true" ID="ID_759316230" CREATED="1706679845338" MODIFIED="1712603819840">
<node TEXT="location" ID="ID_149284598" CREATED="1712603785425" MODIFIED="1712603787566">
<node ID="ID_1222655717" CREATED="1712008235985" MODIFIED="1712008235985" LINK="https://www.coursera.org/learn/google-data-analytics-capstone/quiz/Ovp6u/hands-on-activity-add-your-portfolio-to-kaggle"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/google-data-analytics-capstone/quiz/Ovp6u/hands-on-activity-add-your-portfolio-to-kaggle">Hands-On Activity: Add your portfolio to Kaggle | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="data sources" FOLDED="true" ID="ID_232306688" CREATED="1707171386982" MODIFIED="1707171390119">
<node TEXT="open data" FOLDED="true" ID="ID_492318738" CREATED="1707409099156" MODIFIED="1707409102767">
<node ID="ID_605129728" CREATED="1707409104191" MODIFIED="1707409104191" LINK="https://www.data.gov/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><a target="_blank" rel="noopener nofollow noreferrer" href="https://www.data.gov/" title="U.S. government data site" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black" face="unset"><u><strong style="font-weight: 700; font-family: unset"><b>U.S. government data site</b></strong></u></font></a>: Data.gov is one of the most comprehensive data sources in the US. This resource gives users the data and tools that they need to do research, and even helps them develop web and mobile applications and design data visualizations.&#xa0;</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1890583081" CREATED="1707409104193" MODIFIED="1707409104193" LINK="https://www.census.gov/data.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><a target="_blank" rel="noopener nofollow noreferrer" href="https://www.census.gov/data.html" title="U.S. Census Bureau" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black" face="unset"><u><strong style="font-weight: 700; font-family: unset"><b>U.S. Census Bureau</b></strong></u></font></a>: This open data source offers demographic information from federal, state, and local governments, and commercial entities in the U.S. too.&#xa0;</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_576217068" CREATED="1707409104214" MODIFIED="1707409104214" LINK="https://www.opendatanetwork.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><a target="_blank" rel="noopener nofollow noreferrer" href="https://www.opendatanetwork.com/" title="Open Data Network" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black" face="unset"><u><strong style="font-weight: 700; font-family: unset"><b>Open Data Network</b></strong></u></font></a>: This data source has a really powerful search engine and advanced filters. Here, you can find data on topics like finance, public safety, infrastructure, and housing and development.</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_682480205" CREATED="1707409104222" MODIFIED="1707409104222" LINK="https://cloud.google.com/datasets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><a target="_blank" rel="noopener nofollow noreferrer" href="https://cloud.google.com/datasets" title="Google Cloud Public Datasets" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black" face="unset"><u><strong style="font-weight: 700; font-family: unset"><b>Google Cloud Public Datasets</b></strong></u></font></a>: There are a selection of public datasets available through the Google Cloud Public Dataset Program that you can find already loaded into BigQuery.&#xa0;&#xa0;</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1480190261" CREATED="1707409104227" MODIFIED="1707409104227" LINK="https://datasetsearch.research.google.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><a target="_blank" rel="noopener nofollow noreferrer" href="https://datasetsearch.research.google.com/" title="Dataset Search" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black" face="unset"><u><strong style="font-weight: 700; font-family: unset"><b>Dataset Search</b></strong></u></font></a><b><strong style="font-weight: 700; font-family: unset"><font face="unset">: </font></strong></b>The Dataset Search is a search engine designed specifically for data sets; you can use this to search for specific data sets. </span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_57043801" CREATED="1707409073234" MODIFIED="1707409073234" LINK="https://www.coursera.org/learn/data-preparation/supplement/3hAmz/resources-for-open-data"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/supplement/3hAmz/resources-for-open-data">Resources for open data | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_855794564" CREATED="1707171408318" MODIFIED="1707171408318" LINK="https://www.kaggle.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.kaggle.com/">Kaggle: Your Home for Data Science</a>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1896120969" CREATED="1707332491578" MODIFIED="1707332491578" LINK="https://www.coursera.org/learn/data-preparation/quiz/7QVuG/hands-on-activity-introduction-to-kaggle/attempt"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/quiz/7QVuG/hands-on-activity-introduction-to-kaggle/attempt">Hands-On Activity: Introduction to Kaggle | Coursera</a>
  </body>
</html>
</richcontent>
<node TEXT="I would describe these data sets as belonging to an analytical workflow that demonstrates the use of the dplyr package, using the Palmer Penguins data set." ID="ID_119436004" CREATED="1707333176555" MODIFIED="1707333176555"/>
<node TEXT="capturing interactive notebooks online can help you develop your data analysis skills because you can see how others work and also get help from the community." ID="ID_267662260" CREATED="1707333176555" MODIFIED="1707333176555"/>
</node>
<node ID="ID_322418023" CREATED="1707171390981" MODIFIED="1707171390981" LINK="https://www.kaggle.com/datasets/jjayfabor/lettuce-growth-days/discussion/462337"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.kaggle.com/datasets/jjayfabor/lettuce-growth-days/discussion/462337">Lettuce Growth Days</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="data.gov" ID="ID_530294895" CREATED="1707351168193" MODIFIED="1707351174621"/>
</node>
<node TEXT="best practices" FOLDED="true" ID="ID_610966093" CREATED="1710971156601" MODIFIED="1710971160575">
<node TEXT="personal, unique, and simple" ID="ID_870549496" CREATED="1710971160577" MODIFIED="1710971185460">
<node TEXT="shows" ID="ID_978783615" CREATED="1710971193107" MODIFIED="1710971285817">
<node TEXT="who you are" ID="ID_1771040415" CREATED="1710971195571" MODIFIED="1710971197931"/>
<node TEXT="what you&apos;re interested in" ID="ID_1548199983" CREATED="1710971198355" MODIFIED="1710971203996"/>
<node TEXT="what&apos;s important to you" ID="ID_1476658017" CREATED="1710971204009" MODIFIED="1710971208075"/>
</node>
<node TEXT="simple" ID="ID_1390284356" CREATED="1710971324019" MODIFIED="1710971327193">
<node TEXT="don&apos;t want to distract with unnecessary clutter" ID="ID_1483079317" CREATED="1710971327195" MODIFIED="1710971347019"/>
</node>
</node>
<node TEXT="make sure your portfolio is relevant and presentable" ID="ID_557313480" CREATED="1710971362390" MODIFIED="1710971370042">
<node TEXT="up-to-date" ID="ID_688732637" CREATED="1710971376585" MODIFIED="1710971379777"/>
<node TEXT="ready for an employee to see" ID="ID_1609931355" CREATED="1710971379779" MODIFIED="1710971383802"/>
<node TEXT="proud of what is displayed" ID="ID_711716213" CREATED="1710971383814" MODIFIED="1710971391210"/>
</node>
</node>
<node TEXT="Case studies" FOLDED="true" ID="ID_172118956" CREATED="1710963768412" MODIFIED="1710963897851">
<node TEXT="about" FOLDED="true" ID="ID_1969416110" CREATED="1710963898804" MODIFIED="1710963901205">
<node TEXT="common way for employers to assess job skills and gain insight into how you approach common data related challenges" ID="ID_977818938" CREATED="1710963901207" MODIFIED="1710963918220"/>
<node TEXT="typically a time limit" ID="ID_33528717" CREATED="1710963943403" MODIFIED="1710963950020"/>
<node TEXT="doesn&apos;t have to be perfect" ID="ID_16457984" CREATED="1710963951638" MODIFIED="1710963955611"/>
<node TEXT="show your thought process so the interviewers can understand how you approach the problem" ID="ID_1073361906" CREATED="1710963956252" MODIFIED="1710963991614"/>
<node TEXT="examples" ID="ID_15319186" CREATED="1710963922607" MODIFIED="1710963924648">
<node TEXT="clean and analyze a dataset" ID="ID_170932411" CREATED="1710963924652" MODIFIED="1710963928796"/>
<node TEXT="offer a proposal around how to measure the success of a project" ID="ID_2515770" CREATED="1710963928809" MODIFIED="1710963934198"/>
<node TEXT="figure out and defined metrics of success for a specific product" ID="ID_623841616" CREATED="1710963934213" MODIFIED="1710963941060"/>
</node>
</node>
<node TEXT="tips" ID="ID_1344975878" CREATED="1710970971356" MODIFIED="1710970974194">
<node TEXT="make sure your case study answers the question being asked" ID="ID_87113764" CREATED="1710970974198" MODIFIED="1710970981382">
<node TEXT="key metrics" ID="ID_803500791" CREATED="1710971029424" MODIFIED="1710971033615"/>
</node>
<node TEXT="make sure you&apos;re communicating the steps you&apos;ve taken and the assumptions you&apos;ve made" ID="ID_425280362" CREATED="1710971036996" MODIFIED="1710971053207"/>
<node TEXT="make recommendations" ID="ID_1010477185" CREATED="1710971101004" MODIFIED="1710971105595"/>
<node TEXT="process organized step-by-step" ID="ID_1820353955" CREATED="1710971107808" MODIFIED="1710971115387"/>
</node>
<node TEXT="Syngenta" FOLDED="true" ID="ID_1197841257" CREATED="1710964673000" MODIFIED="1710964678205">
<node TEXT="Data Completeness" ID="ID_557857762" CREATED="1710964679119" MODIFIED="1710964683385">
<node TEXT="Show progress on data input into spirit" ID="ID_1333552584" CREATED="1710964684361" MODIFIED="1710964717158"/>
<node TEXT="show when data is missing" ID="ID_312245500" CREATED="1710964717447" MODIFIED="1710964726080">
<node TEXT="teams falling behind in need of assistance" ID="ID_1766345254" CREATED="1710964726519" MODIFIED="1710964736136"/>
</node>
</node>
</node>
</node>
<node TEXT="employers" FOLDED="true" ID="ID_765352728" CREATED="1710970778139" MODIFIED="1710970781989">
<node TEXT="the way they think creativity" ID="ID_1168478978" CREATED="1710970781991" MODIFIED="1710970820192">
<node TEXT="being both a scientist and an artist" ID="ID_338653931" CREATED="1710970831982" MODIFIED="1710970839986"/>
<node TEXT="challenge the norms of solving a problem" ID="ID_1609997700" CREATED="1710970841409" MODIFIED="1710970849025"/>
<node TEXT="looking for the thought process" ID="ID_1349650155" CREATED="1710970861797" MODIFIED="1710970872988">
<node TEXT="explain how you think" ID="ID_843958747" CREATED="1710970872990" MODIFIED="1710970883197"/>
</node>
<node TEXT="every data point has a story to tell" ID="ID_1379578704" CREATED="1710970900987" MODIFIED="1710970906607"/>
</node>
</node>
</node>
</node>
<node TEXT="Case Study Roadmap" FOLDED="true" ID="ID_1904081426" CREATED="1711036696601" MODIFIED="1711036701798">
<node TEXT="Reading Case Study" ID="ID_87739477" CREATED="1712100480466" MODIFIED="1712100501303" LINK="file:/M:/My%20Drive/My%20Google%20Docs/Career/Development%20and%20Learning/Data%20Analytics/Google%20Data%20Analytics%20Certificate/Portfolio/Reading_Case-Study-1_-How-does-a-bike-share-navigate-speedy-success_.pdf"/>
<node TEXT="C:\Users\micha\Downloads\Case Study" ID="ID_837248415" CREATED="1712100420263" MODIFIED="1712100425339" LINK="file:/C:/Users/micha/Downloads/Case%20Study"/>
<node TEXT="Report" ID="ID_651230182" CREATED="1711045548171" MODIFIED="1711045556386"/>
</node>
<node TEXT="Tools" ID="ID_1246509782" CREATED="1711932548032" MODIFIED="1711932551542">
<node TEXT="Spreadsheet" FOLDED="true" ID="ID_1902539986" CREATED="1711932817730" MODIFIED="1711932821526">
<node TEXT="WPS Office" ID="ID_1645818139" CREATED="1711932821936" MODIFIED="1711932825372">
<node ID="ID_575657306" CREATED="1711932826821" MODIFIED="1711932826821" LINK="https://www.wps.com/academy/how-to-create-a-histogram-in-wps-spreadsheet-quick-tutorials-1877695/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.wps.com/academy/how-to-create-a-histogram-in-wps-spreadsheet-quick-tutorials-1877695/">How to Create A Histogram in WPS Spreadsheet? (Step-By-Step Guide) | WPS Office Academy</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_854306137" CREATED="1711932553553" MODIFIED="1711932553553" LINK="https://www.datapine.com/articles/data-analyst-tools-software#data-analysis-tools-definition"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.datapine.com/articles/data-analyst-tools-software#data-analysis-tools-definition">Top Data Analytics Tools - Best Software For Data Analysts</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="web scraping" FOLDED="true" ID="ID_1033130465" CREATED="1707507247636" MODIFIED="1707507251172">
<node TEXT="sheets functions" ID="ID_1928624124" CREATED="1707507884275" MODIFIED="1707507893928">
<node TEXT="IMPORTRANGE" ID="ID_1850733774" CREATED="1707507895850" MODIFIED="1707507959940">
<node ID="ID_1044154965" CREATED="1707507952545" MODIFIED="1707507952545"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/Course%203/Module%203.one#Import%20data%20dynamically&amp;section-id={8342431C-09A2-49FB-9BCB-4ED3294ADE76}&amp;page-id={B5AE31E2-C262-4DD2-91F1-5B161AA9C6FE}&amp;end">Import data dynamically </a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%28Course%203%2FModule%203.one%7C8342431C-09A2-49FB-9BCB-4ED3294ADE76%2FImport%20data%20dynamically%7CB5AE31E2-C262-4DD2-91F1-5B161AA9C6FE%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="IMPORTHTML" ID="ID_768337559" CREATED="1707507902715" MODIFIED="1707507910300"/>
<node TEXT="IMPORTDATA" ID="ID_1789468584" CREATED="1707507910308" MODIFIED="1707507917331"/>
</node>
<node ID="ID_822520475" CREATED="1707507259200" MODIFIED="1707507259200" LINK="https://www.thedataschool.co.uk/anna-prosvetova/web-scraping-made-easy-import-html-tables-or-lists-using-google-sheets-and-excel/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thedataschool.co.uk/anna-prosvetova/web-scraping-made-easy-import-html-tables-or-lists-using-google-sheets-and-excel/">The Data School - Web scraping made easy: import HTML tables or lists using Google Sheets and Excel</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="summary statistics" FOLDED="true" ID="ID_700615533" CREATED="1707162992267" MODIFIED="1707163002032">
<node TEXT="Google Sheets" ID="ID_1223219010" CREATED="1707171252358" MODIFIED="1707171257766">
<node TEXT="Data .. Column stats" ID="ID_191439682" CREATED="1707170937701" MODIFIED="1707170979150"/>
<node TEXT="Pivot Table" ID="ID_325400123" CREATED="1707170979797" MODIFIED="1707170983720">
<node TEXT="to edit after making, use pencil icon at bottom left" ID="ID_1921992007" CREATED="1707171261294" MODIFIED="1707171275144"/>
</node>
</node>
</node>
<node TEXT="Google Drive" ID="ID_1157803771" CREATED="1707162431181" MODIFIED="1707162440146" LINK="https://drive.google.com/drive/folders/1PDpLdxs5jbU7w0gD9YIOjW73x8tc4788?usp=sharing"/>
<node TEXT="current course" FOLDED="true" ID="ID_1565067167" CREATED="1706825865792" MODIFIED="1706825868427">
<node ID="ID_1404416775" CREATED="1706986243167" MODIFIED="1706986243167" LINK="https://www.coursera.org/learn/ask-questions-make-decisions/home/module/2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/ask-questions-make-decisions/home/module/2">Ask Questions to Make Data-Driven Decisions - Make data-driven decisions - Week 2 | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1248358177" CREATED="1706825860339" MODIFIED="1706825860339" LINK="https://www.coursera.org/professional-certificates/google-data-analytics#courses"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/professional-certificates/google-data-analytics#courses">Google Data Analytics Professional Certificate | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</map>
