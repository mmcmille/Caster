<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="Career Management" FOLDED="false" ID="ID_366184248" CREATED="1519234397350" MODIFIED="1556455691236" LINK="LifeMgmt.mm">
<font NAME="Nirmala UI"/>
<edge DASH="SOLID"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<hook NAME="MapStyle" background="#191919" zoom="1.001" layout="OUTLINE">
    <properties show_icon_for_attributes="true" show_note_icons="true" allow_compact_layout="true" fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="oval" UNIFORM_SHAPE="true" TEXT_ALIGN="LEFT" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="24"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_238255399" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" NUMBERED="false" FORMAT="STANDARD_FORMAT" TEXT_ALIGN="LEFT" MAX_WIDTH="120 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#808080" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="AUTO" VGAP_QUANTITY="2 pt" COMMON_HGAP_QUANTITY="14 pt">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_238255399" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Arial" SIZE="9" BOLD="true" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#333333" WIDTH="3"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/html"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/html"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="11"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.tags">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge STYLE="hide_edge" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#1e3360" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#203868"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<icon BUILTIN="yes"/>
<edge COLOR="#333333"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" BORDER_WIDTH="0 px" VGAP_QUANTITY="3 pt">
<font SIZE="22" ITALIC="false"/>
<edge STYLE="horizontal" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font NAME="Arial" SIZE="20" BOLD="true"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font NAME="Arial" SIZE="18"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#333333" WIDTH="1"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="Self Assessment" FOLDED="true" POSITION="bottom_or_right" ID="ID_617529149" CREATED="1537478315358" MODIFIED="1548432878852">
<node TEXT="Personality" FOLDED="true" ID="ID_652493966" CREATED="1537478348312" MODIFIED="1705346709241" VGAP_QUANTITY="3 pt">
<node TEXT="Type" FOLDED="true" ID="ID_468103003" CREATED="1705346549021" MODIFIED="1705346554103">
<node TEXT="INTJ - INTP" FOLDED="true" ID="ID_291748358" CREATED="1699574977987" MODIFIED="1699575741626">
<node ID="ID_1958034577" CREATED="1699575469002" MODIFIED="1699575469002" LINK="https://personalityjunkie.com/08/intj-vs-intp-type-differences/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://personalityjunkie.com/08/intj-vs-intp-type-differences/">INTJ vs. INTP: Core Differences</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1786482142" CREATED="1699575931966" MODIFIED="1699575931966" LINK="https://personalityjunkie.com/the-intj/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://personalityjunkie.com/the-intj/">INTJ Personality Type: In-Depth Profile &amp; Analysis</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="research" FOLDED="true" ID="ID_115122578" CREATED="1699574717557" MODIFIED="1699574723607">
<node ID="ID_1665824517" CREATED="1699574724534" MODIFIED="1699574724534" LINK="https://www.verywellmind.com/what-is-personality-2795416"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.verywellmind.com/what-is-personality-2795416">Personality: Definition, Theories, Traits, &amp; Types</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_146643395" CREATED="1705347010725" MODIFIED="1705347010725" LINK="https://www.verywellmind.com/anxiety-and-personality-style-1392978"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.verywellmind.com/anxiety-and-personality-style-1392978">Generalized Anxiety Disorder and Personality Style</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Type B" FOLDED="true" ID="ID_30065265" CREATED="1698175425674" MODIFIED="1698175433592">
<node TEXT="Type A" ID="ID_289488037" CREATED="1698175488436" MODIFIED="1698175490457"/>
<node ID="ID_241637032" CREATED="1698175439985" MODIFIED="1698175439985" LINK="https://www.verywellmind.com/type-b-personality-4589000"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.verywellmind.com/type-b-personality-4589000">What Does It Mean to Have a Type B Personality?</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Traits" FOLDED="true" ID="ID_1087504166" CREATED="1705346525884" MODIFIED="1705346531774">
<node TEXT="Experimental" ID="ID_1876134686" CREATED="1559540261118" MODIFIED="1559540267049"/>
<node TEXT="Organized" ID="ID_998960758" CREATED="1537479196428" MODIFIED="1537479200788"/>
<node TEXT="system oriented" ID="ID_449748298" CREATED="1666391493340" MODIFIED="1666391497433"/>
<node TEXT="Efficiency Seeking" ID="ID_1937026115" CREATED="1663819337363" MODIFIED="1663819345342"/>
<node TEXT="Analytical" FOLDED="true" ID="ID_1713347170" CREATED="1537479218908" MODIFIED="1537479223830">
<node TEXT="I want to look at the whole of my life. When I do, I start to feel overwhelmed because there are so many factors. This makes it difficult to focus. The combination of stress combined with the lack of an immediate payoff makes the endeavor seem less important in light of more immediate concerns." ID="ID_1619186140" CREATED="1548433189323" MODIFIED="1548433357673"/>
</node>
</node>
<node TEXT="Engineer type" ID="ID_15349357" CREATED="1575647254663" MODIFIED="1575647260050"/>
<node TEXT="Controlling" ID="ID_119573896" CREATED="1603295236787" MODIFIED="1705346709240"/>
</node>
<node TEXT="Skills" FOLDED="true" ID="ID_644888735" CREATED="1537478432729" MODIFIED="1696633677427"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12pt">Skills - something you learn how to do</font>
    </p>
  </body>
</html></richcontent>
<node TEXT="Most enjoy using" FOLDED="true" ID="ID_141470577" CREATED="1705345838894" MODIFIED="1705345844465">
<node TEXT="Technical" FOLDED="true" ID="ID_1903139194" CREATED="1556457322317" MODIFIED="1556457327421">
<node TEXT="Computer" FOLDED="true" ID="ID_1896169272" CREATED="1705346424228" MODIFIED="1705346427262">
<node TEXT="interfacing" ID="ID_558351179" CREATED="1705346431428" MODIFIED="1705346435672"/>
</node>
<node TEXT="Data Science" FOLDED="true" ID="ID_550322870" CREATED="1556457332201" MODIFIED="1556457337411">
<node FOLDED="true" ID="ID_70040914" CREATED="1556290855035" MODIFIED="1556290855035" LINK="https://academy.microsoft.com/en-us/professional-program/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://academy.microsoft.com/en-us/professional-program/">Microsoft Professional Program</a>
  </body>
</html>
</richcontent>
<node ID="ID_1153201780" CREATED="1556513911348" MODIFIED="1556513911348" LINK="https://www.edx.org/microsoft-professional-program-data-science"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edx.org/microsoft-professional-program-data-science">Microsoft Professional Program in Data Science | edX</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1191016587" CREATED="1556515316798" MODIFIED="1556515316798" LINK="https://www.cropscience.bayer.com/en/stories/2019/molecular-math-data-science-accelerate-innovation-plant-breeding"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.cropscience.bayer.com/en/stories/2019/molecular-math-data-science-accelerate-innovation-plant-breeding">Math and Data Science Accelerating Innovation in Plant Breeding | Bayer Crop Science - Bayer - Crop Science</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Statistics" ID="ID_894419191" CREATED="1556457337763" MODIFIED="1556457340613"/>
<node TEXT="Skills to develop" FOLDED="true" ID="ID_299981301" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Modeling" FOLDED="true" ID="ID_370315003" CREATED="1519760932907" MODIFIED="1519760932907">
<node ID="ID_1496869340" CREATED="1519772302171" MODIFIED="1519772311937">
<icon BUILTIN="xmag"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Why
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_54194312" CREATED="1519772302171" MODIFIED="1519772302171"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      APSIM
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1695202577" CREATED="1519772302187" MODIFIED="1519772302187"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      How
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_453619329" CREATED="1519772302187" MODIFIED="1519772302187"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Coursework
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_478485227" CREATED="1519772302187" MODIFIED="1519772302187"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="file:///C:\Users\u581917\OneDrive%20-%20Syngenta\Documents\!!School\AG%20525%20-%20Crop%20and%20Soil%20Modeling\Working%20with%20Dynamic%20Crop%20Models%20-%20Methods,%20Tools,%20and%20Examples%20for%20Agriculture%20and%20Environment%20Second%20Edition">Working with Dynamic Crop Models - Methods, Tools, and Examples for Agriculture and Environment Second Edition</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1072141537" CREATED="1519772302202" MODIFIED="1519772302202"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      &lt;<a href="file:///C:\Users\u581917\OneDrive%20-%20Syngenta\Documents\!!School\AG%20525%20-%20Crop%20and%20Soil%20Modeling\Working%20with%20dynamic%20models%20for%20agriculture%20-%20A%20short%20course.pdf">Working with dynamic models for agriculture - A short course.pdf</a>&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1548818528" CREATED="1519772302202" MODIFIED="1521825639795">
<icon BUILTIN="unchecked"/>
<icon BUILTIN="xmag"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Complete AGRON 525: Crop and Soil Modeling
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_652237078" CREATED="1519772302218" MODIFIED="1519772302218"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Prereq: MATH 165 or MATH 181 or equivalent; AGRON 316 or AGRON 354 or equivalent.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_504458459" CREATED="1519772302218" MODIFIED="1519772302218"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      (3-0) Cr. 3. F.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_425620168" CREATED="1519772302218" MODIFIED="1519772302218"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Understanding basic crop physiology and soil processes through the use of mathematical and statistical approaches. Structure of crop models, dynamics and relationship among components such as leaf-level photosynthesis, canopy architecture, root dynamics and soil carbon and nitrogen pools.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1057621629" CREATED="1519772302218" MODIFIED="1519772302218"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Books
    </p>
  </body>
</html>
</richcontent>
<node TEXT="crop-growth-modeling-a-review-1-11.pdf" ID="ID_1243377421" CREATED="1519772544046" MODIFIED="1519772553380" LINK="../!!School/AG%20525%20-%20Crop%20and%20Soil%20Modeling/crop-growth-modeling-a-review-1-11.pdf">
<icon BUILTIN="xmag"/>
</node>
<node ID="ID_1967412197" CREATED="1519772302234" MODIFIED="1519772302234" LINK="https://www.elsevier.com/books/working-with-dynamic-crop-models/wallach/978-0-444-52135-4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.elsevier.com/books/working-with-dynamic-crop-models/wallach/978-0-444-52135-4">Working with Dynamic Crop Models - 1st Edition</a>, Evaluation, Analysis, Parameterization, and Applications
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_167553334" CREATED="1519772302234" MODIFIED="1519772302234"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Working with Dynamic Crop Models: Evaluation, Analysis, Parameterization and Applications&#8221; edited by D. Wallach, D. Makowski, and J. W. Jones.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_877662289" CREATED="1519772302234" MODIFIED="1519772302234" LINK="https://www.amazon.com/Introduction-Mathematical-Modeling-Crop-Growth/dp/1581129998/ref=sr_1_1?ie=UTF8&amp;qid=1509655866&amp;sr=8-1&amp;keywords=Introduction+to+Mathematical+Modeling+of+Crop+Growth%3A+How+the+Equations+are+Derived+and+Assembled+into+a+Computer+Program&amp;dpID=51L5xw6VHnL&amp;preST=_SY291_BO1,204,203,200_QL40_&amp;dpSrc=srch#customerReviews"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.amazon.com/Introduction-Mathematical-Modeling-Crop-Growth/dp/1581129998/ref=sr_1_1?ie=UTF8&amp;qid=1509655866&amp;sr=8-1&amp;keywords=Introduction+to+Mathematical+Modeling+of+Crop+Growth%3A+How+the+Equations+are+Derived+and+Assembled+into+a+Computer+Program&amp;dpID=51L5xw6VHnL&amp;preST=_SY291_BO1,204,203,200_QL40_&amp;dpSrc=srch#customerReviews">Introduction to Mathematical Modeling of Crop Growth: How the Equations are Derived and Assembled into a Computer Program: Christopher Teh: 9781581129991: Amazon.com: Books</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_197542434" CREATED="1519772302249" MODIFIED="1519772302249" LINK="http://brownwalker.com/book/1581129998"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://brownwalker.com/book/1581129998">Introduction to Mathematical Modeling of Crop Growth - BrownWalker Press</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_968004584" CREATED="1519772302249" MODIFIED="1519772302249" LINK="https://books.google.com.my/books?hl=en&amp;lr=&amp;id=2Dx91MNxwr4C&amp;oi=fnd&amp;pg=PR9&amp;ots=2gV6QZFKSv&amp;sig=JvpCuFGbzkPFgIwlo6-1joM0UOw#v=onepage&amp;q&amp;f=false"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://books.google.com.my/books?hl=en&amp;lr=&amp;id=2Dx91MNxwr4C&amp;oi=fnd&amp;pg=PR9&amp;ots=2gV6QZFKSv&amp;sig=JvpCuFGbzkPFgIwlo6-1joM0UOw#v=onepage&amp;q&amp;f=false">Introduction to Mathematical Modeling of Crop Growth - Christopher Teh - Google Books</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_849792601" CREATED="1519772302265" MODIFIED="1519772302265" LINK="https://www.amazon.com/Working-Dynamic-Crop-Models-Agriculture-ebook/dp/B00H8RUCXI/ref=mt_kindle?_encoding=UTF8&amp;me=&amp;dpID=51c8pna-eCL&amp;preST=_SY445_QL70_&amp;dpSrc=detail"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.amazon.com/Working-Dynamic-Crop-Models-Agriculture-ebook/dp/B00H8RUCXI/ref=mt_kindle?_encoding=UTF8&amp;me=&amp;dpID=51c8pna-eCL&amp;preST=_SY445_QL70_&amp;dpSrc=detail">Working with Dynamic Crop Models: Methods, Tools and Examples for Agriculture and Environment 2, Daniel Wallach, David Makowski, James W. Jones, Francois Brun - Amazon.com</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_938038175" CREATED="1519772302265" MODIFIED="1519772302265" LINK="https://www.betterworldbooks.com/plant-and-crop-modelling-id-1930665059.aspx?utm_medium=onr_paidshopping&amp;utm_source=google"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.betterworldbooks.com/plant-and-crop-modelling-id-1930665059.aspx?utm_medium=onr_paidshopping&amp;utm_source=google">Plant and Crop Modelling by J. H. M. Thornley, John H. M. Thornley, Ian R. Johnson - Reviews, Description &amp; more - ISBN#9781930665057 - BetterWorldBooks.com</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_861726594" CREATED="1519772302280" MODIFIED="1519772302280"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      &lt;<a href="file:///C:\Users\u581917\OneDrive%20-%20Syngenta\Documents\!!School\AG%20525%20-%20Crop%20and%20Soil%20Modeling\Rice%20Progress%20in%20Breaking%20the%20Yield%20Ceiling.pdf">Rice Progress in Breaking the Yield Ceiling.pdf</a>&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Statistical Analysis" FOLDED="true" ID="ID_800005490" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="STAT 516: Statistical Design and Analysis of Gene Expression Experiments" FOLDED="true" ID="ID_360417422" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="(3-0) Cr. 3. S." ID="ID_1584792190" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Prereq: STAT 500; STAT 447 or STAT 542" ID="ID_904198034" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Introduction to high-throughput technologies for gene expression studies (especially RNA-sequencing technology): the role of blocking, randomization, and biological and technical replication in the design of gene expression experiments; normalization methods; methods for identifying differentially expressed genes including mixed linear model analysis, generalized linear model analysis, generalized linear mixed model analysis, quasi-likelihood methods, empirical Bayes analysis, and resampling based approaches; procedures for controlling false discovery rate for multiple testing; clustering and classification problems for gene expression data; testing gene categories; emphasis on current research topics for statistical analysis of high dimensional gene expression data." ID="ID_206832298" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
<node ID="ID_1072946645" CREATED="1539714119645" MODIFIED="1539714119645" LINK="https://www.stat.colostate.edu//statprostudents/statdistance/statcertificate-data-analysis.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.stat.colostate.edu//statprostudents/statdistance/statcertificate-data-analysis.html">Statistics Certificate in Applied Statistics and Data Analysis</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1835316455" CREATED="1539716627727" MODIFIED="1539716627727" LINK="https://www.online.colostate.edu/certificates/credit-certificates.dot"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.online.colostate.edu/certificates/credit-certificates.dot">Online Graduate Certificate Programs | Colorado State University - CSU Online</a>
  </body>
</html>
</richcontent>
<node ID="ID_151412358" CREATED="1539716914254" MODIFIED="1539716914254" LINK="https://www.online.colostate.edu/certificates/theory-applications-regression-models/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.online.colostate.edu/certificates/theory-applications-regression-models/">Online Statistics Certificate | Theory &amp; Application of Regression Models</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Data Science" FOLDED="true" ID="ID_398657371" CREATED="1539715524385" MODIFIED="1539715530865">
<node ID="ID_1050800497" CREATED="1539715532194" MODIFIED="1539715532194" LINK="https://www.quora.com/Will-EMCs-new-data-science-associate-certification-be-worth-anything-for-someone-without-a-technical-masters-degree-and-a-few-years-experience-as-a-data-analyst"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.quora.com/Will-EMCs-new-data-science-associate-certification-be-worth-anything-for-someone-without-a-technical-masters-degree-and-a-few-years-experience-as-a-data-analyst">Will EMC's new data science associate certification be worth anything for someone without a technical masters degree and a few years experience as a data analyst? - Quora</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="R" FOLDED="true" ID="ID_1705099309" CREATED="1561703332693" MODIFIED="1561703334724">
<node TEXT="Course" FOLDED="true" ID="ID_667787034" CREATED="1561734947075" MODIFIED="1561734949978">
<node ID="ID_1317610916" CREATED="1561703336135" MODIFIED="1561703336135" LINK="https://rafalab.github.io/dsbook/r-basics.html#objects"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://rafalab.github.io/dsbook/r-basics.html#objects">Chapter 3 R Basics | Introduction to Data Science</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_659011083" CREATED="1561734663600" MODIFIED="1561734663600" LINK="https://campus.datacamp.com/courses/data-science-r-basics/r-basics-a00bd4f0-d469-4d46-8447-ad7f6f601bfa?ex=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://campus.datacamp.com/courses/data-science-r-basics/r-basics-a00bd4f0-d469-4d46-8447-ad7f6f601bfa?ex=1">Using variables 1 | R</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_802569388" CREATED="1561734944937" MODIFIED="1561734944937" LINK="https://www.statmethods.net/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.statmethods.net/">Quick-R: Home Page</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_573172660" CREATED="1561735881296" MODIFIED="1561735881296" LINK="https://www.coursera.org/learn/r-programming"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/r-programming">R Programming | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_19363285" CREATED="1575477052835" MODIFIED="1575477052835" LINK="https://docs.microsoft.com/en-us/learn/certifications/exams/dp-100?wt.mc_id=learningredirect_certs-web-wwl"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.microsoft.com/en-us/learn/certifications/exams/dp-100?wt.mc_id=learningredirect_certs-web-wwl">Exam DP-100: Designing and Implementing a Data Science Solution on Azure - Learn | Microsoft Docs</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Math" FOLDED="true" ID="ID_1485138568" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Calculus" FOLDED="true" ID="ID_760524219" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Differentiation Derivatives" FOLDED="true" ID="ID_1347517496" CREATED="1519760932908" MODIFIED="1519760932908">
<node TEXT="What does 〖d/dx x〗^2=2x mean?" ID="ID_548723261" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="It means that, for the function x2, the slope or &quot;rate of change&quot; at any point is 2x." FOLDED="true" ID="ID_1943880387" CREATED="1519760932908" MODIFIED="1519760932908">
<node TEXT="Slope =  ∆y/∆x" ID="ID_559544191" CREATED="1519760932908" MODIFIED="1519760932908"/>
</node>
<node TEXT="Can also be written as f’(x) = 2x" ID="ID_1189069192" CREATED="1519760932908" MODIFIED="1519760932908"/>
</node>
</node>
<node TEXT="Differential equations" ID="ID_41189063" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="Difference equations" ID="ID_389376276" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="MATH 207: Matrices and Linear Algebra" FOLDED="true" ID="ID_1211787188" CREATED="1519760932908" MODIFIED="1519760932908">
<node ID="ID_1097400713" CREATED="1519761171255" MODIFIED="1519761220335" LINK="https://ocw.mit.edu/courses/mathematics/18-06sc-linear-algebra-fall-2011/index.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://ocw.mit.edu/courses/mathematics/18-06sc-linear-algebra-fall-2011/index.htm">Linear Algebra | Mathematics | MIT OpenCourseWare</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="(3-0) Cr. 3. F.S.SS." ID="ID_1900717788" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="Prereq: 2 semesters of calculus" ID="ID_1347642442" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="Systems of linear equations, determinants, vector spaces, linear transformations, orthogonality, least-squares methods, eigenvalues and eigenvectors. Emphasis on applications and techniques. Only one of MATH 207 and MATH 317 may be counted toward graduation." ID="ID_33318371" CREATED="1519760932908" MODIFIED="1519760932908"/>
</node>
</node>
<node TEXT="Genetics" ID="ID_1099045456" CREATED="1519760932908" MODIFIED="1519760932908"/>
</node>
<node TEXT="How to Develop" FOLDED="true" ID="ID_1145821529" CREATED="1519760932908" MODIFIED="1519760932908">
<node TEXT="School" FOLDED="true" ID="ID_558272094" CREATED="1537481956732" MODIFIED="1544630517139" LINK="#ID_1920593441">
<node TEXT="Community College" FOLDED="true" ID="ID_1920593441" CREATED="1537481962470" MODIFIED="1537481969962">
<node TEXT="Open CCC" FOLDED="true" ID="ID_640625340" CREATED="1544550982892" MODIFIED="1544550986410">
<node FOLDED="true" ID="ID_1995234737" CREATED="1544550987360" MODIFIED="1544550987360" LINK="https://www.openccc.net/uPortal/p/AccountCreation.ctf1/max/render.uP?pP_execution=e1s4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.openccc.net/uPortal/p/AccountCreation.ctf1/max/render.uP?pP_execution=e1s4">OpenCCC: Create Account</a>
  </body>
</html>
</richcontent>
<node TEXT="Your CCCID is: BCV5901" ID="ID_847444514" CREATED="1544551137779" MODIFIED="1544551137779"/>
</node>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_909362679" CREATED="1544550989187" MODIFIED="1544550992648"/>
<node TEXT="mmcmille" ID="ID_1933758607" CREATED="1544550993340" MODIFIED="1544550995360"/>
<node TEXT="Dr0w554p" ID="ID_1486097809" CREATED="1544550995932" MODIFIED="1544551029011"/>
<node TEXT="4011" OBJECT="java.lang.Long|4011" ID="ID_950103649" CREATED="1544551030294" MODIFIED="1544551031775"/>
</node>
<node ID="ID_1857595619" CREATED="1537477250155" MODIFIED="1537477250155" LINK="https://www.gavilan.edu/catalog/index.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.gavilan.edu/catalog/index.php">College Catalog 2017 - 2019- Gavilan College</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1820061369" CREATED="1537480273087" MODIFIED="1537480273087" LINK="https://cvc.edu/courses/?subject%5B%5D=mathematics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://cvc.edu/courses/?subject%5B%5D=mathematics">CVC Distance Education Catalog</a>
  </body>
</html>
</richcontent>
<node ID="ID_1009688519" CREATED="1537544127007" MODIFIED="1537544127007" LINK="https://cvc.edu/courses/?prefer_adt=1&amp;order=-relevance%2Ctitle&amp;limit=50&amp;subject%5B%5D=mathematics&amp;school%5B%5D=coastline-community-college"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://cvc.edu/courses/?prefer_adt=1&amp;order=-relevance%2Ctitle&amp;limit=50&amp;subject%5B%5D=mathematics&amp;school%5B%5D=coastline-community-college">CVC Distance Education Catalog</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Foothill College" ID="ID_923777609" CREATED="1539722217295" MODIFIED="1539722234452" LINK="https://www.foothill.edu/onlinelearning/faq.php"/>
</node>
<node TEXT="Courses" FOLDED="true" ID="ID_149656653" CREATED="1539722246134" MODIFIED="1539722249789">
<node TEXT="Calc1" FOLDED="true" ID="ID_234749522" CREATED="1537483086353" MODIFIED="1537483091351">
<node FOLDED="true" ID="ID_1129735468" CREATED="1537544873692" MODIFIED="1537544873692" LINK="http://www.coastline.edu/admissions/schedule-classes"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.coastline.edu/admissions/schedule-classes">Coastline - Class Schedule</a>
  </body>
</html>
</richcontent>
<node TEXT="Reg Begins Oct 30th" ID="ID_1212674303" CREATED="1539719344064" MODIFIED="1539719350411"/>
<node TEXT="01/28-05/25" ID="ID_983675128" CREATED="1539719145625" MODIFIED="1539719145625"/>
<node TEXT="MATH C180 - Calculus 1" ID="ID_1572471800" CREATED="1539719155710" MODIFIED="1539719155710"/>
</node>
</node>
<node TEXT="Calc2" ID="ID_1037395362" CREATED="1537483092150" MODIFIED="1537483094538"/>
<node TEXT="Calc3" ID="ID_1701690781" CREATED="1537483095119" MODIFIED="1537483096900"/>
<node TEXT="Linear algebra" ID="ID_369186069" CREATED="1537483097400" MODIFIED="1537483113587"/>
<node ID="ID_1953313416" CREATED="1556833985579" MODIFIED="1556833985579" LINK="https://www.henryharvin.com/our-courses"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.henryharvin.com/our-courses">Classroom Training &amp; Certification Courses by Best-In-Class Industry Experts | henryharvin.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Masters program" FOLDED="true" ID="ID_1726464519" CREATED="1537481971548" MODIFIED="1537481976396">
<node TEXT="Statistics" FOLDED="true" ID="ID_1294127724" CREATED="1537481978022" MODIFIED="1537481980105">
<node ID="ID_1942017410" CREATED="1537476815876" MODIFIED="1537476815876" LINK="https://www.bestmastersdegrees.com/top/affordable-online-masters-statistics-data-analytics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.bestmastersdegrees.com/top/affordable-online-masters-statistics-data-analytics">Top 30 Affordable Online Master&#8217;s in Statistics and Data Analytics Degrees 2018 - The Best Master's Degrees</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="" FOLDED="true" ID="ID_1487477969" CREATED="1548868233895" MODIFIED="1548868233895">
<node FOLDED="true" ID="ID_1836773832" CREATED="1548868242655" MODIFIED="1548868242655" LINK="https://www.online.colostate.edu/certificates/theory-applications-regression-models/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.online.colostate.edu/certificates/theory-applications-regression-models/">Online Statistics Certificate | Theory &amp; Application of Regression Models</a>
  </body>
</html>
</richcontent>
<node TEXT="1 year" ID="ID_1855939093" CREATED="1548868291378" MODIFIED="1548868294131"/>
<node TEXT="10-11 cred/795" ID="ID_1500929578" CREATED="1548868245312" MODIFIED="1548868253154"/>
<node TEXT="=795*11" ID="ID_966216802" CREATED="1548868253903" MODIFIED="1548868263099"/>
</node>
</node>
<node FOLDED="true" ID="ID_395624516" CREATED="1537482958396" MODIFIED="1537482958396" LINK="https://www.online.colostate.edu/degrees/applied-statistics/curriculum.dot"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.online.colostate.edu/degrees/applied-statistics/curriculum.dot">Curriculum - Online Master of Applied Statistics (M.A.S.) | CSU Online</a>
  </body>
</html>
</richcontent>
<node TEXT="31Credits, 795/credit" FOLDED="true" ID="ID_1611873171" CREATED="1545064285180" MODIFIED="1545064306171">
<node TEXT="=31*795" ID="ID_1143927074" CREATED="1545064307757" MODIFIED="1545064318278"/>
</node>
</node>
<node FOLDED="true" ID="ID_1966671615" CREATED="1537483334415" MODIFIED="1537483334415" LINK="https://online.stat.tamu.edu/prospective-students/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://online.stat.tamu.edu/prospective-students/">Online Masters of Statistics Degree: MS in Statistics from Texas A&amp;M | Texas A&amp;M</a>
  </body>
</html>
</richcontent>
<node TEXT="3-4 Years, high cost" ID="ID_244818924" CREATED="1545064187950" MODIFIED="1545064195325"/>
</node>
</node>
</node>
<node TEXT="PhD" FOLDED="true" ID="ID_421296449" CREATED="1520112590820" MODIFIED="1520112595990">
<node TEXT="potential to do original, independent research" ID="ID_521162123" CREATED="1520112598343" MODIFIED="1520112633126"/>
<node FOLDED="true" ID="ID_798201594" CREATED="1520121329623" MODIFIED="1520121329623" LINK="http://www.bcb.iastate.edu/program-overview"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.bcb.iastate.edu/program-overview">Program Overview | Bioinformatics &amp; Computational Biology</a>
  </body>
</html>
</richcontent>
<node TEXT="PreReqs" FOLDED="true" ID="ID_1402706045" CREATED="1534952405268" MODIFIED="1534952410143">
<node TEXT="Math 265. Calculus III. (4-0) Cr. 4. F*.S.SS.Prereq: Grade of C- or better in 166 or 166H." FOLDED="true" ID="ID_639023434" CREATED="1534952411799" MODIFIED="1534952472848">
<node TEXT="Analytic geometry and vectors, differential calculus of functions of several variables, multiple integrals, vector calculus." ID="ID_1181754088" CREATED="1534952463787" MODIFIED="1534952469099"/>
<node TEXT="MULTIVARI CALCULUS - 40071 - MATH 1C - 301&#xa;Associated Term: Spring 2018&#xa;Levels: Undergraduate&#xa;Attributes: Transferable CSU, CSU B4, GAV B4, Transferable UC, IGETC 2A" ID="ID_1341392851" CREATED="1534960898431" MODIFIED="1534960901183"/>
</node>
<node ID="ID_825936793" CREATED="1534952423706" MODIFIED="1534952423706" LINK="https://www.bcb.iastate.edu/academic-preparation"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.bcb.iastate.edu/academic-preparation">Academic Preparation | Bioinformatics &amp; Computational Biology</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_1111026277" CREATED="1537545760999" MODIFIED="1537545760999" LINK="https://chrisblattman.com/2013/06/12/when-are-you-too-old-for-a-phd/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://chrisblattman.com/2013/06/12/when-are-you-too-old-for-a-phd/">When are you too old for a PhD? - Chris Blattman</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Job experience" ID="ID_265067800" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="Projects" ID="ID_1774625491" CREATED="1519760932908" MODIFIED="1519760932908"/>
<node TEXT="edX" FOLDED="true" ID="ID_1436474102" CREATED="1525454794735" MODIFIED="1525454856888" LINK="https://courses.edx.org/dashboard#">
<node TEXT="Google+ account: mcmillen.michael.s@gmail.com" ID="ID_382529633" CREATED="1525454800414" MODIFIED="1525454816603"/>
<node ID="ID_864567686" CREATED="1539898725684" MODIFIED="1539898725684" LINK="https://repl.it/repls"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://repl.it/repls">Repl.it - Repls</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="My Portfolio" FOLDED="true" ID="ID_1662861865" CREATED="1590181395019" MODIFIED="1592330912239">
<node TEXT="Developing your portfolio" FOLDED="true" ID="ID_388298975" CREATED="1592330833438" MODIFIED="1592330855135">
<node FOLDED="true" ID="ID_1132751804" CREATED="1592331727665" MODIFIED="1592331727665" LINK="https://www.thebalancecareers.com/what-is-a-professional-portfolio-1987043"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalancecareers.com/what-is-a-professional-portfolio-1987043">The Definition of a Professional Portfolio</a>
  </body>
</html>
</richcontent>
<node TEXT="The most influential factor in conveying your value to a potential employer?" ID="ID_888376453" CREATED="1590181379596" MODIFIED="1590181393655"/>
<node TEXT="What is a portfolio? A portfolio is a set of projects on the web, typically on github, but it could also be your own website, that showcase your skill in data science." ID="ID_800959931" CREATED="1590181379596" MODIFIED="1590181379596"/>
</node>
<node ID="ID_709580971" CREATED="1592327406627" MODIFIED="1592327406627" LINK="https://careertrend.com/how-4896372-make-good-career-portfolio.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careertrend.com/how-4896372-make-good-career-portfolio.html">How to Make a Good Career Portfolio</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_394749650" CREATED="1592326365039" MODIFIED="1592326365039" LINK="https://www.wikihow.com/Create-a-Career-Portfolio"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.wikihow.com/Create-a-Career-Portfolio">How to Create a Career Portfolio (with Pictures) - wikiHow</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Here are some of the signs of a good data science portfolio:" FOLDED="true" ID="ID_1468765981" CREATED="1590181379603" MODIFIED="1590181379603">
<node TEXT="A T-shaped portfolio, with several small projects and at least one large project, demonstrating your familiarity with the entire data science process. The projects should be based as much as possible on real-world data sets and problems." ID="ID_1432058465" CREATED="1590181379613" MODIFIED="1590181379613"/>
<node TEXT="Well-documented projects: each project should clearly explain the problem, the approach and the outcome at a high level, demonstrating not just your grasp of the technical content, but your communication skills." ID="ID_1089786132" CREATED="1590181379616" MODIFIED="1590181379616"/>
<node TEXT="Clean and readable code: the code should be clear and well-commented, explaining the main steps of your approach. Get a programmer friend to review your work!" ID="ID_1287852609" CREATED="1590181379621" MODIFIED="1590181379621"/>
</node>
<node ID="ID_1440564788" CREATED="1590183797752" MODIFIED="1590183797752" LINK="https://www.dataquest.io/blog/build-a-data-science-portfolio/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.dataquest.io/blog/build-a-data-science-portfolio/">Data Science Portfolios That Will Get You the Job &#8211; Dataquest</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_125189239" CREATED="1590181359404" MODIFIED="1590181359404" LINK="https://www.quora.com/Is-a-data-science-bootcamp-worth-it-without-a-degree"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.quora.com/Is-a-data-science-bootcamp-worth-it-without-a-degree">Is a data science bootcamp worth it without a degree? - Quora</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Areas" FOLDED="true" ID="ID_1341095299" CREATED="1592330872405" MODIFIED="1592330875025">
<node TEXT="Resume" ID="ID_1627871585" CREATED="1592330952175" MODIFIED="1592330952175"/>
<node TEXT="Names of references or reference letters" ID="ID_124606392" CREATED="1592330952175" MODIFIED="1592330952175"/>
<node TEXT="Skills list" ID="ID_26061021" CREATED="1592330952175" MODIFIED="1592330952175"/>
<node TEXT="Academic transcripts" ID="ID_1649007984" CREATED="1592330952175" MODIFIED="1592330952175"/>
<node TEXT="List of accomplishments, awards and community service work" FOLDED="true" ID="ID_1891980009" CREATED="1592330952175" MODIFIED="1592330952175">
<node TEXT="A key to building a memorable portfolio is creating appropriate artifacts. An artifact, according to the Career Services Center at the University of Delaware, is any tangible item that represents your accomplishments and qualities. &lt;http://www.udel.edu/CSC/pdf/careerportfolio.pdf&gt;" ID="ID_535911380" CREATED="1592331039714" MODIFIED="1592331039714" LINK="http://www.udel.edu/CSC/pdf/careerportfolio.pdf"/>
</node>
<node TEXT="Samples and a list of published work" FOLDED="true" ID="ID_689147167" CREATED="1592330952175" MODIFIED="1592330952175">
<node TEXT="Publish CC" FOLDED="true" ID="ID_467662598" CREATED="1519772207586" MODIFIED="1519772207586">
<node TEXT="Select journal" ID="ID_1226264480" CREATED="1519772207601" MODIFIED="1519772207601"/>
<node TEXT="Get requirements" ID="ID_688386351" CREATED="1519772207601" MODIFIED="1519772207601"/>
<node TEXT="Concerns" ID="ID_712652321" CREATED="1519772207601" MODIFIED="1519772207601"/>
</node>
</node>
<node TEXT="A list of continuing education activities, such as conferences, seminars and other training." ID="ID_375466902" CREATED="1592330952175" MODIFIED="1592330952175"/>
</node>
</node>
<node TEXT="Development" FOLDED="true" ID="ID_789376480" CREATED="1592329978569" MODIFIED="1592329982058">
<node TEXT="Education" ID="ID_1407795252" CREATED="1674015159871" MODIFIED="1674015164008">
<node TEXT="Current Program" ID="ID_711722262" CREATED="1674015172039" MODIFIED="1674015189318"/>
<node TEXT="Past Programs" ID="ID_1764766625" CREATED="1674015190149" MODIFIED="1674015195385">
<node TEXT="Cal Poly" ID="ID_1923988573" CREATED="1674015195955" MODIFIED="1674015200359">
<node TEXT="California State Polytechnic University of San Luis Obispo" ID="ID_318229969" CREATED="1714086240650" MODIFIED="1714086258449"/>
<node TEXT="1 Grand Avenue" ID="ID_1149748456" CREATED="1714086134859" MODIFIED="1714086274054"/>
<node TEXT="San Luis Obispo, CA 93407" ID="ID_1060650081" CREATED="1714086274055" MODIFIED="1714086274057"/>
<node TEXT="8057561111" OBJECT="java.lang.Long|8057561111" ID="ID_1526159047" CREATED="1714086169750" MODIFIED="1714086176385"/>
<node TEXT="9/20?/2001 - 06/15/2013" ID="ID_430328911" CREATED="1674015592837" MODIFIED="1714084429906"/>
<node FOLDED="true" ID="ID_515325430" CREATED="1674015500992" MODIFIED="1674015500992" LINK="https://www.parchment.com/u/registration/22362635/institution"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.parchment.com/u/registration/22362635/institution">California Polytechnic State Univ - SLO Transcript Request | Parchment</a>
  </body>
</html>
</richcontent>
<node TEXT="Michael.S.McMillen@Outlook.com" ID="ID_318631012" CREATED="1674015538074" MODIFIED="1674015549593"/>
</node>
</node>
<node TEXT="Iowa State University" ID="ID_587333871" CREATED="1674015210269" MODIFIED="1714085534518">
<node TEXT="515-294-5836" ID="ID_1523252606" CREATED="1714085938656" MODIFIED="1714085938656"/>
<node TEXT="Office of Admissions" ID="ID_1685577010" CREATED="1714085926668" MODIFIED="1714085926668"/>
<node TEXT="100 Enrollment Services Center" ID="ID_560469532" CREATED="1714085926668" MODIFIED="1714085926668"/>
<node TEXT="2433 Union Drive" ID="ID_635526552" CREATED="1714085926669" MODIFIED="1714085926669"/>
<node TEXT="Ames, IA 50011-2042" ID="ID_398413735" CREATED="1714085926669" MODIFIED="1714085926669"/>
<node TEXT="Fall 08/25/2014 - Summer 08/04/2017" ID="ID_1687854390" CREATED="1706219904039" MODIFIED="1714085681374"/>
</node>
</node>
</node>
<node TEXT="Development Actions" FOLDED="true" ID="ID_355971828" CREATED="1592407776421" MODIFIED="1592407782638">
<node TEXT="" ID="ID_1507073009" CREATED="1592407783930" MODIFIED="1592407783930"/>
</node>
<node TEXT="strong development planning" ID="ID_63954319" CREATED="1519234503662" MODIFIED="1519234503662"/>
<node TEXT="Development" FOLDED="true" ID="ID_757066466" CREATED="1579285891628" MODIFIED="1579285895137">
<node TEXT="General Skills" FOLDED="true" ID="ID_1870830590" CREATED="1590077597585" MODIFIED="1590077615527">
<node FOLDED="true" ID="ID_1367248959" CREATED="1590077617211" MODIFIED="1590077629576" LINK="https://www.thebalancecareers.com/top-skills-employers-want-2062481"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-top: 0; margin-bottom: 0; margin-right: 0px; margin-left: 0px; padding-top: 0px; padding-bottom: 0px; padding-right: 0; padding-left: 0; list-style: none; color: rgb(34, 34, 34); font-family: Rubik, Arial, sans-serif; font-size: 17px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)">
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        <strong>Communication Skills</strong>:
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node ID="ID_352315301" CREATED="1590077629580" MODIFIED="1590077629584"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-top: 0; margin-bottom: 0; margin-right: 0px; margin-left: 0px; padding-top: 0px; padding-bottom: 0px; padding-right: 0; padding-left: 0; list-style: none; color: rgb(34, 34, 34); font-family: Rubik, Arial, sans-serif; font-size: 17px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)">
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        The ability to communicate effectively leads most lists of the top skills<span>&#160;</span><a href="https://www.thebalancecareers.com/top-skills-employers-want-2062481" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="1" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">employers seek in job candidates</font></a><span>&#160;</span>and&#8212;especially&#8212;as a key qualification<span>&#160;</span><a href="https://www.thebalancecareers.com/top-skills-employers-want-2062481" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="2" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">employers want college grads to have</font></a>. The<span>&#160;</span><a href="https://www.thebalancecareers.com/communication-skills-list-2063779" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="3" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">&#8220;Top 10&#8221; communications skills</font></a><span>&#160;</span>include competencies such as active listening, open-mindedness, and nonverbal communications.&#160;
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_837503986" CREATED="1590077617216" MODIFIED="1590077632186" LINK="https://www.bls.gov/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-top: 0; margin-bottom: 0; margin-right: 0px; margin-left: 0px; padding-top: 0px; padding-bottom: 0px; padding-right: 0; padding-left: 0; list-style: none; color: rgb(34, 34, 34); font-family: Rubik, Arial, sans-serif; font-size: 17px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)">
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        <strong>Customer Service Skills</strong>:
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node ID="ID_1908328712" CREATED="1590077632190" MODIFIED="1590077632195"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-top: 0; margin-bottom: 0; margin-right: 0px; margin-left: 0px; padding-top: 0px; padding-bottom: 0px; padding-right: 0; padding-left: 0; list-style: none; color: rgb(34, 34, 34); font-family: Rubik, Arial, sans-serif; font-size: 17px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)">
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        The U.S. is primarily now a service economy. According to the U.S.<span>&#160;</span><a href="https://www.bls.gov/" data-component="link" data-source="inlineLink" data-type="externalLink" data-ordinal="4" target="_blank" rel="noopener" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">Bureau of Labor Statistics</font></a>, in 2018, there were 2,972,600 customer services jobs. For most employees, then, it&#8217;s a safe bet that mentioning one of the<span>&#160;</span><a href="https://www.thebalancecareers.com/top-soft-skills-for-customer-service-jobs-2063746" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="5" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">&#8220;Top 10&#8221; customer services skills</font></a><span>&#160;</span>on a resume will be advantageous.<span><font color="rgb(0, 0, 238)" size="12.75px"><sup>2</sup></font></span>&#65279;
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_343691132" CREATED="1590077617280" MODIFIED="1590077633875" LINK="https://www.thebalancecareers.com/top-leadership-skills-2063782"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        <strong>Leadership Skills</strong>:
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node ID="ID_1654785811" CREATED="1590077633878" MODIFIED="1590077786112"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        Proving that you have one of the<span>&#160;</span><a href="https://www.thebalancecareers.com/top-leadership-skills-2063782" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="6" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">&#8220;Top 10&#8221; Leadership</font></a><span>&#160;</span>skills is almost always a smart strategy when compiling your resume, even if you aren&#8217;t seeking a job in management. Employers prefer candidates who are capable of showing personal initiative and motivating their teammates.
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1070301698" CREATED="1590077787957" MODIFIED="1590077787957" LINK="https://www.thebalancecareers.com/top-leadership-skills-2063782"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalancecareers.com/top-leadership-skills-2063782">Important Leadership Skills for Workplace Success</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_889413299" CREATED="1590077617299" MODIFIED="1590077637872" LINK="https://www.thebalancecareers.com/top-skills-every-professional-needs-to-have-4150386"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        <strong>Professional Skills</strong>:
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node ID="ID_610280088" CREATED="1590077637874" MODIFIED="1590077637877"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        <span>&#160;</span><a href="https://www.thebalancecareers.com/top-skills-every-professional-needs-to-have-4150386" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="7" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">Desirable professional skills</font></a><span>&#160;</span>include public speaking, teamwork, communication, time management, leadership, flexibility, and interpersonal skills. These professional aptitudes are also<span>&#160;</span><a href="https://www.thebalancecareers.com/top-skills-to-list-on-linkedin-2062321" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="8" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">good skills to mention on your LinkedIn profile</font></a>.
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1504938532" CREATED="1590077617309" MODIFIED="1590077641096" LINK="https://www.thebalancecareers.com/what-you-need-to-succeed-in-the-knowledge-economy-4172293"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        <strong>Skills for the Knowledge Economy</strong>:
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node ID="ID_1422401890" CREATED="1590077641101" MODIFIED="1590077641105"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Rubik, Arial, sans-serif; list-style-type: none">
        Professionals within the growing knowledge economy sector must be able to interpret and apply data to create product and service solutions. The<span>&#160;</span><a href="https://www.thebalancecareers.com/what-you-need-to-succeed-in-the-knowledge-economy-4172293" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="9" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">best skills for the knowledge economy</font></a><span>&#160;</span>include information communication technology (ICT) talents such as<span>&#160;</span><a href="https://www.thebalancecareers.com/business-intelligence-skills-2062364" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="10" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">business intelligence</font></a><span>&#160;</span>and&#160;<a href="https://www.thebalancecareers.com/business-storytelling-skills-with-examples-2059685" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="11" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">business storytelling</font></a>, flexibility, and lifelong learning. Employers also seek individuals with solid<span>&#160;</span><a href="https://www.thebalancecareers.com/deductive-reasoning-definition-with-examples-2063749" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="12" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">deductive</font></a><span>&#160;</span>and<span>&#160;</span><a href="https://www.thebalancecareers.com/inductive-reasoning-definition-with-examples-2059683" data-component="link" data-source="inlineLink" data-type="internalLink" data-ordinal="13" style="color: rgb(36, 111, 200); text-decoration: none"><font color="rgb(36, 111, 200)">inductive reasoning</font></a><span>&#160;</span>skills.
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Areas" FOLDED="true" ID="ID_1150584055" CREATED="1590034925761" MODIFIED="1590034928470">
<node TEXT="Digital Phenotyping" FOLDED="true" ID="ID_177606351" CREATED="1581515353055" MODIFIED="1581515361305">
<node TEXT="Leafy Phenotyping" ID="ID_1002327637" CREATED="1581515363228" MODIFIED="1581515410310" LINK="freeplane:/%20/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/My%20Google%20Docs/Administrative/MindMaps/Leafy%20Breeding.mm#ID_81609817"/>
</node>
<node TEXT="Data Science" FOLDED="true" ID="ID_1012739154" CREATED="1581515298118" MODIFIED="1581515305208">
<node ID="ID_750027620" CREATED="1581515307149" MODIFIED="1581515307149" LINK="https://docs.microsoft.com/en-us/learn/certifications/azure-data-scientist"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.microsoft.com/en-us/learn/certifications/azure-data-scientist">Microsoft Certified: Azure Data Scientist Associate - Learn | Microsoft Docs</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="YOUR VOUCHER CODE: MSCP62713F45" ID="ID_1865349575" CREATED="1581514942295" MODIFIED="1581514942295"/>
<node ID="ID_1572550088" CREATED="1579285896103" MODIFIED="1579285896103" LINK="https://image.email.microsoftemail.com/lib/fec3167172640d74/m/8/Eligible+exams+for+voucher+code.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://image.email.microsoftemail.com/lib/fec3167172640d74/m/8/Eligible+exams+for+voucher+code.pdf">Eligible+exams+for+voucher+code.pdf</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_889585658" CREATED="1590077540550" MODIFIED="1590077540550" LINK="https://www.thebalancecareers.com/list-of-the-best-skills-for-resumes-2062422"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalancecareers.com/list-of-the-best-skills-for-resumes-2062422">The Best Job Skills to List on Your Resume</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Develop a clear vision of who I will become" FOLDED="true" ID="ID_1405851178" CREATED="1529434520331" MODIFIED="1529435337864">
<node TEXT="What words describe me?" FOLDED="true" ID="ID_1062290728" CREATED="1529434571499" MODIFIED="1529434593153">
<node TEXT="Inventor" ID="ID_967872259" CREATED="1529434593622" MODIFIED="1529434614742"/>
<node TEXT="Innovator" ID="ID_1329750699" CREATED="1529434615085" MODIFIED="1529434623947"/>
<node TEXT="Tinkerer" ID="ID_1830661625" CREATED="1529434677491" MODIFIED="1529434682279"/>
<node TEXT="Disector" ID="ID_698450116" CREATED="1529434686921" MODIFIED="1529434689739"/>
<node TEXT="Analyzer" ID="ID_1152577801" CREATED="1529434690191" MODIFIED="1529434693934"/>
<node TEXT="Optimizer" ID="ID_588328979" CREATED="1529434624482" MODIFIED="1529434630615"/>
<node TEXT="System modeler" ID="ID_1948605398" CREATED="1529434657422" MODIFIED="1529434661191"/>
</node>
<node TEXT="What bothers me?" FOLDED="true" ID="ID_1993332195" CREATED="1529434996094" MODIFIED="1529435001004">
<node TEXT="My complacency and desire for comfort and leisure" ID="ID_102731774" CREATED="1529435249383" MODIFIED="1529435266656"/>
<node TEXT="My own laziness and lack of commitment to the future wellbeing of myself and my family" ID="ID_1421736039" CREATED="1529435192280" MODIFIED="1529435218646"/>
<node TEXT="Incomplete tasks" ID="ID_376988875" CREATED="1529435002679" MODIFIED="1529435019755"/>
<node TEXT="Things that don&apos;t work as they should" ID="ID_753205078" CREATED="1529435020200" MODIFIED="1529435034440"/>
<node TEXT="Too many steps for a simple goal" ID="ID_158568560" CREATED="1529435035211" MODIFIED="1529435053338"/>
<node TEXT="Being disrupted" ID="ID_1209695241" CREATED="1529435066507" MODIFIED="1529435070034"/>
<node TEXT="Incompetent people, especially in positions of influence" ID="ID_621077978" CREATED="1529435079237" MODIFIED="1529435100290"/>
<node TEXT="Lack of goal clarity" ID="ID_798503239" CREATED="1529435154873" MODIFIED="1529435165504"/>
</node>
<node TEXT="Who most inspires you?" FOLDED="true" ID="ID_590953304" CREATED="1529435429585" MODIFIED="1529435440486">
<node TEXT="Visionaries" FOLDED="true" ID="ID_311475216" CREATED="1529435496700" MODIFIED="1529435502194">
<node TEXT="People who created or altered an industry" ID="ID_65211227" CREATED="1529435503929" MODIFIED="1529435522758"/>
</node>
<node TEXT="Inventors" ID="ID_360315812" CREATED="1529963674033" MODIFIED="1529963677212"/>
<node TEXT="People with humble beginnings who became great" ID="ID_929261535" CREATED="1529963678412" MODIFIED="1529963724773"/>
</node>
<node TEXT="Why?" FOLDED="true" ID="ID_818801511" CREATED="1529435588864" MODIFIED="1529435592793">
<node TEXT="Because they were daring and commited to thier goal, and they demonstrated what could be done." ID="ID_857390099" CREATED="1529435594563" MODIFIED="1529435657165"/>
</node>
</node>
</node>
<node TEXT="Emotional Intelligence" FOLDED="true" ID="ID_1632462467" CREATED="1539723779492" MODIFIED="1539723864619">
<node TEXT="Definition" FOLDED="true" ID="ID_1688690072" CREATED="1539723791127" MODIFIED="1539723856650">
<node TEXT="the measure of an individual’s abilities to recognise and manage their emotions, and the emotions of other people, both individually and in groups." FOLDED="true" ID="ID_499656746" CREATED="1539723848073" MODIFIED="1539723848073">
<node ID="ID_1826792532" CREATED="1539724365882" MODIFIED="1539724365882" LINK="https://www.skillsyouneed.com/general/emotional-intelligence.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.skillsyouneed.com/general/emotional-intelligence.html">Emotional Intelligence | SkillsYouNeed</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Personal Skills - How we manage ourselves" FOLDED="true" ID="ID_1202464671" CREATED="1539723900638" MODIFIED="1539724005670">
<font BOLD="true"/>
<node TEXT="Self-awareness" FOLDED="true" ID="ID_451398382" CREATED="1539723907964" MODIFIED="1539723907964">
<node TEXT="the skill of being aware of and understanding your emotions as they occur and as they evolve" ID="ID_604736336" CREATED="1539724095843" MODIFIED="1539724095843"/>
<node TEXT="Emotional awareness" FOLDED="true" ID="ID_1326147396" CREATED="1539723907964" MODIFIED="1539723907964">
<node TEXT="Know what emotions they are feeling at any given time, and why;" ID="ID_1803194110" CREATED="1539724555746" MODIFIED="1539724555746"/>
<node TEXT="Understand the links between their emotions and their thoughts and actions, including what they say;" ID="ID_1303357044" CREATED="1539724555746" MODIFIED="1539724555746"/>
<node TEXT="Understand how their feelings will therefore affect their performance; and" ID="ID_1483529657" CREATED="1539724555762" MODIFIED="1539724555762"/>
<node TEXT="Be guided in how they feel by their personal values." ID="ID_1393056708" CREATED="1539724555762" MODIFIED="1539724555762"/>
<node TEXT="Read more at: https://www.skillsyouneed.com/ps/self-awareness.html" ID="ID_1590778741" CREATED="1539724555762" MODIFIED="1539724555762" LINK="https://www.skillsyouneed.com/ps/self-awareness.html"/>
</node>
<node TEXT="Accurate self-assessment" FOLDED="true" ID="ID_1357038038" CREATED="1539723907969" MODIFIED="1539723907969">
<node TEXT="understanding of your personal strengths, weaknesses, inner resources and, perhaps most importantly, your limits." FOLDED="true" ID="ID_561530031" CREATED="1539788291141" MODIFIED="1539788291141">
<node TEXT="Read more at: https://www.skillsyouneed.com/ps/self-awareness.html" ID="ID_429474836" CREATED="1539788291141" MODIFIED="1539788291141" LINK="https://www.skillsyouneed.com/ps/self-awareness.html"/>
</node>
</node>
<node TEXT="Self-confidence" FOLDED="true" ID="ID_485893225" CREATED="1539723907972" MODIFIED="1539723907972">
<node TEXT="having a strong sense of your own self-worth, and not relying on others for your valuation of yourself." ID="ID_1988287363" CREATED="1539788442707" MODIFIED="1539788442707"/>
<node TEXT="People with good self-confidence are:" FOLDED="true" ID="ID_445605705" CREATED="1539788455577" MODIFIED="1539788455577">
<node TEXT="Generally able to present themselves well, and are often described as charismatic. For more about this, see our page on What is Charisma? and Becoming Charismatic." ID="ID_206246516" CREATED="1539788455577" MODIFIED="1539788455577"/>
<node TEXT="Prepared to voice unpopular opinions, and not always ‘go with the flow’. For more about this, see our page on Assertiveness. You may also be interested in our page on Courage, an essential part of being prepared to stand out from the crowd." ID="ID_1003469329" CREATED="1539788455580" MODIFIED="1539788455580"/>
<node TEXT="Generally decisive, being able to make good decisions grounded in their own values. See our page on Effective Decision-Making for more." ID="ID_701616112" CREATED="1539788455587" MODIFIED="1539788455587"/>
<node TEXT="Read more at: https://www.skillsyouneed.com/ps/self-awareness.html" ID="ID_1636857353" CREATED="1539788455597" MODIFIED="1539788455597" LINK="https://www.skillsyouneed.com/ps/self-awareness.html"/>
</node>
</node>
</node>
<node TEXT="Self-regulation" FOLDED="true" ID="ID_1193512098" CREATED="1539723907977" MODIFIED="1539723907977">
<node TEXT="Self-control" ID="ID_854771974" CREATED="1539723907979" MODIFIED="1539723907979"/>
<node TEXT="Trustworthiness" ID="ID_1864416616" CREATED="1539723907982" MODIFIED="1539723907982"/>
<node TEXT="Conscientiousness" ID="ID_1491299188" CREATED="1539723907985" MODIFIED="1539723907985"/>
<node TEXT="Adaptability" ID="ID_1959908230" CREATED="1539723907987" MODIFIED="1539723907987"/>
<node TEXT="Innovation" ID="ID_799692025" CREATED="1539723907989" MODIFIED="1539723907989"/>
</node>
<node TEXT="Motivation" FOLDED="true" ID="ID_1233984808" CREATED="1539723907991" MODIFIED="1539723907991">
<node TEXT="Achievement drive" ID="ID_1166989297" CREATED="1539723907993" MODIFIED="1539723907993"/>
<node TEXT="Commitment" ID="ID_609974210" CREATED="1539723907995" MODIFIED="1539723907995"/>
<node TEXT="Initiative" ID="ID_1360296699" CREATED="1539723907996" MODIFIED="1539723907996"/>
<node TEXT="Optimism" ID="ID_1402805140" CREATED="1539723907998" MODIFIED="1539723907998"/>
</node>
</node>
<node TEXT="Social Skills - How we handle relationships with others" FOLDED="true" ID="ID_227330040" CREATED="1539723915590" MODIFIED="1539724003388">
<font BOLD="true"/>
<node TEXT="Empathy" FOLDED="true" ID="ID_1683248524" CREATED="1539723929574" MODIFIED="1539723929574">
<node TEXT="Understanding others" ID="ID_1460761751" CREATED="1539723929574" MODIFIED="1539723929574"/>
<node TEXT="Developing others" ID="ID_1797771430" CREATED="1539723929574" MODIFIED="1539723929574"/>
<node TEXT="Service orientation" ID="ID_1066326052" CREATED="1539723929574" MODIFIED="1539723929574"/>
<node TEXT="Leveraging diversity" ID="ID_1611118762" CREATED="1539723929574" MODIFIED="1539723929574"/>
<node TEXT="Political awareness" ID="ID_1580691492" CREATED="1539723929589" MODIFIED="1539723929589"/>
</node>
<node TEXT="Social Skills" FOLDED="true" ID="ID_686461410" CREATED="1539723929589" MODIFIED="1539723929589">
<node TEXT="Influence" ID="ID_510866678" CREATED="1539723929589" MODIFIED="1539723929589"/>
<node TEXT="Communication" ID="ID_674868467" CREATED="1539723929589" MODIFIED="1539723929589"/>
<node TEXT="Conflict management" ID="ID_1204432342" CREATED="1539723929589" MODIFIED="1539723929589"/>
<node TEXT="Leadership" ID="ID_38434772" CREATED="1539723929589" MODIFIED="1539723929589"/>
<node TEXT="Change catalyst" ID="ID_1662704704" CREATED="1539723929605" MODIFIED="1539723929605"/>
<node TEXT="Building bonds" ID="ID_78419162" CREATED="1539723929605" MODIFIED="1539723929605"/>
<node TEXT="Collaboration and cooperation" ID="ID_1425293151" CREATED="1539723929605" MODIFIED="1539723929605"/>
<node TEXT="Team capabilities" ID="ID_848893308" CREATED="1539723929605" MODIFIED="1539723929605"/>
</node>
</node>
</node>
<node ID="ID_1437499120" CREATED="1539723749507" MODIFIED="1539723749507" LINK="https://www.skillsyouneed.com/general/emotional-intelligence.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.skillsyouneed.com/general/emotional-intelligence.html">Emotional Intelligence | SkillsYouNeed</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Communication" FOLDED="true" ID="ID_1374585151" CREATED="1539721724892" MODIFIED="1539721728329">
<node TEXT="Speaking and presenting" FOLDED="true" ID="ID_262679510" CREATED="1519760932905" MODIFIED="1519760932905">
<node TEXT="◊ Complete TM CC Manual" FOLDED="true" ID="ID_1268453935" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Complete Project 9 -" FOLDED="true" ID="ID_1500624523" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Write Project 9 Speech" ID="ID_1719480301" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
</node>
<node TEXT="◊ Each speech" FOLDED="true" ID="ID_554461720" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Write by Sunday of Presentation" FOLDED="true" ID="ID_729452020" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Emotional appeal" ID="ID_1653599196" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
<node TEXT="Practice Speech 3 times, M,T,W" ID="ID_612843924" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Add notes for gestures" ID="ID_1096723510" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Practice eye contact" ID="ID_491133355" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="No more than 2 pages with 12pt Arial font for 5-7 min speech" ID="ID_744885763" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
<node TEXT="◊ Why?" FOLDED="true" ID="ID_517494816" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Because I want to be able to influence others effectively." ID="ID_1692373082" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="I want the confidence that comes with being an effective speaker." ID="ID_155027194" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
<node TEXT="◊ Vocal Variety" FOLDED="true" ID="ID_1065506029" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="1. Register - Locate your voice at your chest to gain some weight" ID="ID_1385348519" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="2. Timbre - Voices that are rich, smooth and warm" ID="ID_1079574032" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="3. Prosody - Avoid monotone, a statement sounds like a question and repeat a statement" ID="ID_898158371" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="4. Pace - Get excited by saying something really quickly; Slow down to emphasize; Silent" ID="ID_1071382795" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="5. Pitch- Ex: &quot;Where did you leave my keys?&quot; with different pitches, are different meaning" ID="ID_573106914" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="6. Volume: Excited - High Volume; Attention - Low Volume" ID="ID_127570934" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
</node>
</node>
<node TEXT="network and community building," FOLDED="true" ID="ID_1188051538" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Projecting myself clearly" FOLDED="true" ID="ID_421583475" CREATED="1541000910928" MODIFIED="1541001014561">
<node TEXT="Current role" ID="ID_1393893811" CREATED="1541000919574" MODIFIED="1541000923469"/>
<node TEXT="What I can help with" ID="ID_1037650679" CREATED="1541000979985" MODIFIED="1541000984757"/>
<node TEXT="Goals" ID="ID_1347819047" CREATED="1541000923896" MODIFIED="1541000925849"/>
<node TEXT="Interests" ID="ID_465700271" CREATED="1541000926530" MODIFIED="1541000929006"/>
</node>
<node TEXT="Grow my social network" FOLDED="true" ID="ID_381032571" CREATED="1519234503663" MODIFIED="1519234503663">
<node TEXT="Why" FOLDED="true" ID="ID_7824884" CREATED="1519234503663" MODIFIED="1519234503663">
<node TEXT="Creates opportunities" ID="ID_1759080643" CREATED="1519234503663" MODIFIED="1519234503663"/>
<node TEXT="Gives me a view of different career choices" ID="ID_1107817297" CREATED="1519234503663" MODIFIED="1519234503663"/>
<node TEXT="Helps me develop and maintain expectations for myself that others in my group have" ID="ID_1679763564" CREATED="1519234503663" MODIFIED="1519234503663"/>
<node TEXT="share ideas" ID="ID_602088166" CREATED="1519234503663" MODIFIED="1519234503663"/>
</node>
<node TEXT="How" FOLDED="true" ID="ID_721224852" CREATED="1519234503663" MODIFIED="1519234503663">
<node TEXT="Join trade orgs?" ID="ID_913448083" CREATED="1519234503663" MODIFIED="1519234503663"/>
</node>
</node>
</node>
<node TEXT="Leadership, Management" FOLDED="true" ID="ID_812744798" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Business Analysis" FOLDED="true" ID="ID_347359931" CREATED="1548967639993" MODIFIED="1548967644771">
<node ID="ID_167305151" CREATED="1548966726675" MODIFIED="1548966726675" LINK="https://www.bridging-the-gap.com/ba-stories-do-you-define-the-business-need-babok-5-1/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.bridging-the-gap.com/ba-stories-do-you-define-the-business-need-babok-5-1/">Do you define the business need?</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_845817491" CREATED="1548967651366" MODIFIED="1548967651366" LINK="https://www.dummies.com/business/business-strategy/business-analysis-for-dummies-cheat-sheet/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.dummies.com/business/business-strategy/business-analysis-for-dummies-cheat-sheet/">Business Analysis For Dummies Cheat Sheet</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_345700924" CREATED="1548968290682" MODIFIED="1548968290682" LINK="http://fernfortuniversity.com/term-papers/porter5/analysis/813-s-w-seed-company.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://fernfortuniversity.com/term-papers/porter5/analysis/813-s-w-seed-company.php">S&amp;W Seed Company Porter Five (5) Forces &amp; Industry Analysis [Strategy]</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="What is Leadership?" FOLDED="true" ID="ID_722886292" CREATED="1539722986865" MODIFIED="1539722994305">
<node TEXT="the ability to take proactive, preventative, results-producing action." ID="ID_1264273857" CREATED="1539722995546" MODIFIED="1539722995546"/>
<node TEXT="Includes:" FOLDED="true" ID="ID_732814001" CREATED="1539723009921" MODIFIED="1539723013048">
<node TEXT="understanding of when to direct, coach, support, and/or delegate to co-workers as a supervisor or team member based on the context." ID="ID_709761978" CREATED="1539722881208" MODIFIED="1539722881208"/>
</node>
</node>
<node TEXT="◊ Fulfill VP of Education role" FOLDED="true" ID="ID_300218894" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Schedule members speeches and projects" ID="ID_301021285" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Coordinate Club Schedule" FOLDED="true" ID="ID_531039743" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="You ensure that all meeting roles are properly fulfilled; for example, you wouldn’t assign a new member to be the Toastmaster of her first meeting." ID="ID_144858978" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Publish, email, or otherwise distribute the meeting schedule regularly so that all members know what’s expected and can adjust accordingly if necessary." ID="ID_412376898" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Stay current on all new developments via the Leader Letter and the announcements published on the Toastmasters website." ID="ID_1330524393" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
<node TEXT="Assist with Education Awards" FOLDED="true" ID="ID_1684854371" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Arrange meetings to help members complete education awards in a timely fashion." ID="ID_1453874947" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Explain the Toastmasters education program to members." ID="ID_1696826244" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Verify, sign, and date manual projects as members complete them, and submit award applications to World Headquarters when all of the requirements are met." ID="ID_1694529221" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Orient new members to the Toastmasters education program within two meetings of their joining the club." ID="ID_1692496679" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Educate continuing members about the various education awards they can earn, and how they can stay on track to earn them in the least possible time." ID="ID_406859765" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
<node TEXT="Plan Speech Contests" FOLDED="true" ID="ID_152334050" CREATED="1519760932906" MODIFIED="1519760932906">
<node TEXT="Read the Speech Contest Rulebook (Item 1171) thoroughly, and refer to it as necessary when planning speech contests. For another resource, read the information at www.toastmasters.org/speechcontests." ID="ID_106188412" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="Find out which speech contests the district is scheduled to host during your term" ID="ID_712794692" CREATED="1519760932906" MODIFIED="1519760932906"/>
<node TEXT="of office, and plan your club contests accordingly." ID="ID_1814940334" CREATED="1519760932906" MODIFIED="1519760932906"/>
</node>
<node TEXT="Manage Mentor Program" FOLDED="true" ID="ID_1328586701" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Assign every new member a mentor, and keep track of who is mentoring whom." ID="ID_581697647" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Give mentors the credit they deserve by signing the appropriate project in their Competent Leadership (Item 265) manual." ID="ID_1258342007" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
<node TEXT="VICE PRESIDENT EDUCATION CHECKLIST" FOLDED="true" ID="ID_1217361258" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Before Club Meetings" FOLDED="true" ID="ID_975201789" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Review the scheduled roles for the meeting five to seven days in advance." ID="ID_344548275" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Offer support to the Toastmaster of the meeting to confirm members’ role assignments and plan for substitutions if necessary." ID="ID_400434852" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Schedule education sessions selected from The Better Speaker Series (Item 269), The Successful Club Series (Item 289), and The Leadership Excellence Series (Item 310), to be delivered by you or other experienced Toastmasters in the club." ID="ID_1542711368" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Ensure a club member conducts The Successful Club Series (Item 289) programs Evaluate to Motivate (Item 292), Moments of Truth (Item 290), Mentoring (Item 296), and Finding New Members for Your Club (Item 291) at least once per year." ID="ID_178704610" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Notify the club president if any members are scheduled to earn their education awards at the upcoming meeting." ID="ID_1170998269" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
<node TEXT="Upon Arrival at Club Meetings" FOLDED="true" ID="ID_970326504" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Verify that the members assigned to meeting roles have arrived and are prepared to perform their duties." ID="ID_991121810" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Remind members with meeting roles to select an e ­ valuator for their project in Competent Leadership (Item 265)." ID="ID_437504962" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Assist the Toastmaster in filling meeting roles for absent members." ID="ID_729707706" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Greet guests by asking them if they are willing to participate in the meeting or if they’d prefer to observe." ID="ID_279075386" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="If guests agree to participate, inform the Topicsmaster that he or she can call on those guests as Table Topics speakers, and ask the club president to introduce the guests at the beginning of the meeting." ID="ID_515744115" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
<node TEXT="During Club Meetings" FOLDED="true" ID="ID_1432650555" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="Sign your initials on project completion records for speaking and leadership roles fulfilled at the meeting." ID="ID_900857788" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Ensure eligible members fill out award applications." ID="ID_541620671" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Recognize members when they earn awards." ID="ID_1777123767" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Preside over the meeting when the club president is absent." ID="ID_430250510" CREATED="1519760932907" MODIFIED="1519760932907"/>
<node TEXT="Answer member questions about the Toastmasters education program or speech contests, and agree to research questions you don’t know the answers to." ID="ID_1632765604" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
</node>
<node TEXT="Toastmasters Education Program.JPG" ID="ID_118739983" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
<node TEXT="◊ Why?" FOLDED="true" ID="ID_1144537647" CREATED="1519760932907" MODIFIED="1519760932907">
<node TEXT="I want to be able to lead others." ID="ID_914737000" CREATED="1519760932907" MODIFIED="1519760932907"/>
</node>
<node ID="ID_1813161935" CREATED="1539721590326" MODIFIED="1539721590326" LINK="https://www.bestcollegesonline.com/blog/how-to-gain-the-leadership-experience-employers-want/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.bestcollegesonline.com/blog/how-to-gain-the-leadership-experience-employers-want/">How to Gain the Leadership Experience Employers Want - BestCollegesOnline.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_722187006" CREATED="1539969574586" MODIFIED="1539969574586" LINK="https://www.skillsyouneed.com/leadership-skills.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.skillsyouneed.com/leadership-skills.html">Leadership Skills | SkillsYouNeed</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Organizational, Planning" ID="ID_258503105" CREATED="1519760932907" MODIFIED="1539721745236"/>
<node TEXT="Social" FOLDED="true" ID="ID_816949317" CREATED="1556457313168" MODIFIED="1556457320365">
<node ID="ID_1145149359" CREATED="1555458458078" MODIFIED="1555458458078" LINK="https://www.businessinsider.com/social-skills-that-will-make-you-more-likable-2017-6#skip-the-small-talk-13"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.businessinsider.com/social-skills-that-will-make-you-more-likable-2017-6#skip-the-small-talk-13">Social skills that will make you more likable - Business Insider</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Professional Network" ID="ID_374475355" CREATED="1556457561012" MODIFIED="1556457569749"/>
</node>
<node TEXT="Mult-Area" FOLDED="true" ID="ID_1090945993" CREATED="1556457385597" MODIFIED="1556457391469">
<node TEXT="School" FOLDED="true" ID="ID_450947941" CREATED="1519760932908" MODIFIED="1519760932908">
<node TEXT="® Complete PhD" FOLDED="true" ID="ID_1173650079" CREATED="1519760932909" MODIFIED="1519772719370">
<icon BUILTIN="xmag"/>
<node TEXT="Discuss with" FOLDED="true" ID="ID_459245784" CREATED="1519760932909" MODIFIED="1519760932909">
<node TEXT="Dr. Beavis" ID="ID_654325869" CREATED="1519760932909" MODIFIED="1519760932909"/>
<node TEXT=" Dr. Lubberstedt" ID="ID_232038658" CREATED="1519760932909" MODIFIED="1519760932909"/>
</node>
<node TEXT="Consider courses from other universities" FOLDED="true" ID="ID_1994956473" CREATED="1519760932909" MODIFIED="1519760932909">
<node TEXT="UC Davis" ID="ID_1760973404" CREATED="1519760932909" MODIFIED="1519760932909"/>
</node>
<node TEXT="Define my area of concentration" FOLDED="true" ID="ID_527182594" CREATED="1519760932909" MODIFIED="1519760932909">
<node TEXT="Find a particular area that creates drive." ID="ID_1355624464" CREATED="1519760932909" MODIFIED="1519760932909"/>
<node TEXT="Research which addresses a particular problem" ID="ID_1639200823" CREATED="1519760932909" MODIFIED="1519760932909"/>
<node TEXT="Can develop tools which address the problem" ID="ID_1282858972" CREATED="1519760932909" MODIFIED="1519760932909"/>
</node>
</node>
<node TEXT="® Reading" FOLDED="true" ID="ID_1165636824" CREATED="1519760932909" MODIFIED="1519760932909">
<node TEXT="Complete Concept Checks" ID="ID_1506087915" CREATED="1519760932909" MODIFIED="1519760932909"/>
<node TEXT="Highlight once complete" ID="ID_324392357" CREATED="1519760932909" MODIFIED="1519760932909"/>
<node TEXT="use flashcards for key terms" ID="ID_730508888" CREATED="1519760932909" MODIFIED="1519760932909"/>
</node>
</node>
</node>
</node>
<node TEXT="Accomplishments" FOLDED="true" ID="ID_1601871766" CREATED="1705345865262" MODIFIED="1705345868479">
<node TEXT="most proud of and can best illustrate your abilities" ID="ID_1125063338" CREATED="1705345869326" MODIFIED="1705345879303"/>
</node>
<node TEXT="Interests" FOLDED="true" ID="ID_1661067555" CREATED="1535632463543" MODIFIED="1535632467232">
<node TEXT="Most passionate about:" FOLDED="true" ID="ID_349511381" CREATED="1705345893870" MODIFIED="1705345899537">
<node TEXT="Healing The World / Optimal Society" FOLDED="true" ID="ID_1344359118" CREATED="1698869473688" MODIFIED="1704497720344">
<node TEXT="People" ID="ID_22113829" CREATED="1535632510456" MODIFIED="1535632512780"/>
<node TEXT="Social Issues" FOLDED="true" ID="ID_812378912" CREATED="1535632548005" MODIFIED="1535632553414">
<node TEXT="Keeping Children Safe" ID="ID_839206109" CREATED="1705433303580" MODIFIED="1705433312124"/>
<node TEXT="Optimally Raising Children" ID="ID_692999091" CREATED="1705433317364" MODIFIED="1705433339594"/>
</node>
<node TEXT="Health" ID="ID_1467532811" CREATED="1682888040481" MODIFIED="1682888043332"/>
<node TEXT="Environment" FOLDED="true" ID="ID_130620764" CREATED="1704497742150" MODIFIED="1704497745343">
<node TEXT="Agriculture" ID="ID_73532392" CREATED="1704497745694" MODIFIED="1704497748631"/>
</node>
</node>
<node TEXT="Technology" FOLDED="true" ID="ID_251393714" CREATED="1589836494137" MODIFIED="1589836500884">
<node TEXT="Computers" ID="ID_1507664184" CREATED="1548433977579" MODIFIED="1548433981236"/>
<node TEXT="Automation" ID="ID_741322604" CREATED="1548433981489" MODIFIED="1548433984876"/>
</node>
<node TEXT="Science" FOLDED="true" ID="ID_818102677" CREATED="1535632570217" MODIFIED="1535632572595">
<node TEXT="Research" ID="ID_1722745574" CREATED="1698869384025" MODIFIED="1698869402792"/>
<node TEXT="Knowing how natural systems work" ID="ID_1538080624" CREATED="1538163538876" MODIFIED="1538163547183"/>
</node>
</node>
<node TEXT="Engineering" FOLDED="true" ID="ID_1720585572" CREATED="1535632493960" MODIFIED="1535632504640">
<node TEXT="Designing new tools to meet a need" ID="ID_1909612511" CREATED="1538163515268" MODIFIED="1538163527031"/>
</node>
<node TEXT="Workflow Engineering" FOLDED="true" ID="ID_903368343" CREATED="1622557187234" MODIFIED="1622557204862">
<node ID="ID_1212620911" CREATED="1622557225496" MODIFIED="1622557225496" LINK="https://www.calnewport.com/blog/2016/03/29/from-productivity-to-workflow-engineering/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.calnewport.com/blog/2016/03/29/from-productivity-to-workflow-engineering/">From Productivity to Workflow Engineering - Study Hacks - Cal Newport</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1850678524" CREATED="1622558734080" MODIFIED="1622558734080" LINK="https://www.lucidchart.com/pages/tutorial/workflow-diagram#section_3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.lucidchart.com/pages/tutorial/workflow-diagram#section_3">What is a Workflow Diagram | Lucidchart</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Modeling" FOLDED="true" ID="ID_1566955167" CREATED="1535632475199" MODIFIED="1535632491501">
<node TEXT="Finding the best representation for a structure" ID="ID_1184325902" CREATED="1538163498203" MODIFIED="1538163507955"/>
</node>
<node TEXT="Problem Solving" FOLDED="true" ID="ID_1078242433" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Optimization" ID="ID_1863543364" CREATED="1548433958082" MODIFIED="1548433963331"/>
</node>
<node TEXT="Learning" FOLDED="true" ID="ID_915576429" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="What I want to learn more about" FOLDED="true" ID="ID_1216565328" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Genetics" ID="ID_137597367" CREATED="1519234503662" MODIFIED="1519234503662"/>
<node TEXT="Modeling" ID="ID_1194183046" CREATED="1519234503662" MODIFIED="1519234503662"/>
</node>
</node>
<node TEXT="Tinkering" FOLDED="true" ID="ID_433055777" CREATED="1560402634511" MODIFIED="1560402639182">
<node TEXT="experimenting" ID="ID_1018514101" CREATED="1560402664920" MODIFIED="1560402671466"/>
<node TEXT="learning how things work" ID="ID_1809274514" CREATED="1560402672710" MODIFIED="1560402684849"/>
<node TEXT="repurposing tools" ID="ID_445005912" CREATED="1560402685606" MODIFIED="1560402694369"/>
</node>
<node TEXT="Teaching 1 on 1" ID="ID_556136717" CREATED="1704497483415" MODIFIED="1704497494881"/>
<node TEXT="Assessing" FOLDED="true" ID="ID_548318059" CREATED="1519242805814" MODIFIED="1548433897931">
<icon BUILTIN="info"/>
<node ID="ID_1941929632" CREATED="1519343606529" MODIFIED="1519343606529" LINK="https://hr.berkeley.edu/development/career-development/self-assessment/interests"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hr.berkeley.edu/development/career-development/self-assessment/interests">Self-Assessment: Career Interests | Human Resources</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Strong Interest Inventory" ID="ID_1122411231" CREATED="1519343897081" MODIFIED="1519343901560">
<icon BUILTIN="unchecked"/>
</node>
</node>
</node>
<node TEXT="Flow States" ID="ID_705884600" CREATED="1699575921901" MODIFIED="1699575926353"/>
<node TEXT="Self Assessment" FOLDED="true" ID="ID_849623591" CREATED="1519343227305" MODIFIED="1548434106659">
<icon BUILTIN="info"/>
<node ID="ID_1937728518" CREATED="1603148563723" MODIFIED="1603148563723" LINK="https://www.thebalancecareers.com/identifying-your-work-values-526174"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalancecareers.com/identifying-your-work-values-526174">Why You Need to Know What Your Work Values Are</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Clarifying Values, Interests, Skills, and Abilities" ID="ID_1658184143" CREATED="1548434149717" MODIFIED="1548434175176"/>
<node FOLDED="true" ID="ID_1760679711" CREATED="1519341972573" MODIFIED="1519760968475" LINK="https://hr.berkeley.edu/development/career-development/career-management"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hr.berkeley.edu/development/career-development/career-management">Career Development: Career Management | Human Resources</a>
  </body>
</html>
</richcontent>
<node TEXT="Role Fit" FOLDED="true" ID="ID_513998721" CREATED="1519343252010" MODIFIED="1519343290812">
<icon BUILTIN="unchecked"/>
<node TEXT="What do I like about my current role?" ID="ID_255935376" CREATED="1519343278870" MODIFIED="1519343278870"/>
<node TEXT="What makes me feel unique in this organization?" ID="ID_1483272809" CREATED="1519343278870" MODIFIED="1519343278870"/>
<node TEXT="Which of my abilities, interests, and/or values does my current role allow me to express on a regular basis?" ID="ID_1377965016" CREATED="1519343278872" MODIFIED="1519343278872"/>
<node TEXT="What are the challenges of my role?" ID="ID_48525773" CREATED="1519343278874" MODIFIED="1519343278874"/>
<node TEXT="Which of my abilities, interests, and/or values would I like to be able to express more in my work?" ID="ID_1569866064" CREATED="1519343278876" MODIFIED="1519343278876"/>
<node TEXT="What occupational fields do I feel most drawn toward?" ID="ID_1895416658" CREATED="1519343278878" MODIFIED="1519343278878"/>
<node TEXT="What work environments do I enjoy the most?" ID="ID_1782422730" CREATED="1519343278879" MODIFIED="1519343278879"/>
<node TEXT="What kinds of people do I most enjoy working with?  Why do I feel this way?" ID="ID_1484273641" CREATED="1519343278881" MODIFIED="1519343278881"/>
<node TEXT="At this point, do I feel attracted to a leadership (supervisory or managerial) role?  Why?" ID="ID_1684733170" CREATED="1519343278883" MODIFIED="1519343278883"/>
<node TEXT="What steps can I take to gain clarity as I answer these questions?" ID="ID_1983792317" CREATED="1519343278884" MODIFIED="1519343278884"/>
</node>
<node TEXT="Self-Assessment is a process of clarifying your value through discovering the relationship between" FOLDED="true" ID="ID_1461295980" CREATED="1520124463336" MODIFIED="1520125769947">
<node TEXT="value" FOLDED="true" ID="ID_1702936676" CREATED="1520125957377" MODIFIED="1520125960753">
<node ID="ID_1216579124" CREATED="1520125987764" MODIFIED="1520125987764" LINK="https://hr.berkeley.edu/development/career-development/self-assessment/six-factors"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hr.berkeley.edu/development/career-development/self-assessment/six-factors">Self-Assessment: The Six Invaluable Factors | Human Resources</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="various occupations" FOLDED="true" ID="ID_142597046" CREATED="1520125769948" MODIFIED="1520125882284">
<node TEXT="your personality type" FOLDED="true" ID="ID_523299857" CREATED="1520125786229" MODIFIED="1520125806532">
<node TEXT="Myers-Briggs Type Indicator (MBTI)" ID="ID_962932740" CREATED="1520126407766" MODIFIED="1520126407766"/>
<node ID="ID_191907734" CREATED="1520126422731" MODIFIED="1520126422731" LINK="https://hr.berkeley.edu/development/career-development/self-assessment/personality-type"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hr.berkeley.edu/development/career-development/self-assessment/personality-type">Self-Assessment: Personality Type &amp; Work Style Preferences | Human Resources</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="work style" ID="ID_1820414515" CREATED="1520125806533" MODIFIED="1520125853748"/>
<node TEXT="interests" FOLDED="true" ID="ID_802372939" CREATED="1520125853749" MODIFIED="1520125863124">
<node ID="ID_1372246205" CREATED="1520126372922" MODIFIED="1520126372922" LINK="https://hr.berkeley.edu/development/career-development/self-assessment/interests"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hr.berkeley.edu/development/career-development/self-assessment/interests">Self-Assessment: Career Interests | Human Resources</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="career values" FOLDED="true" ID="ID_1624037016" CREATED="1520125863125" MODIFIED="1520125870971">
<node TEXT="Clarify my work values" FOLDED="true" ID="ID_764979466" CREATED="1524022287335" MODIFIED="1524023510150">
<icon BUILTIN="unchecked"/>
<icon BUILTIN="clanbomber"/>
<node ID="ID_1271163264" CREATED="1524022305823" MODIFIED="1524022312197" LINK="https://www.thebalance.com/identifying-your-work-values-526174">
<icon BUILTIN="info"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalance.com/identifying-your-work-values-526174">Work Values Definition - Why You Need to Know What Yours Are</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Intrinsic and extrinsic values" FOLDED="true" ID="ID_900561871" CREATED="1524022664920" MODIFIED="1524022705656">
<icon BUILTIN="info"/>
<node TEXT=" Intrinsic values have to do with the actual tasks involved in practicing a particular occupation or doing a job. They include helping others, doing challenging work, and being a leader." ID="ID_136758742" CREATED="1524022650904" MODIFIED="1524022661467"/>
<node TEXT="Extrinsic values are concerned with the by-products of an occupation or job. In other words, they refer to what you get out of your work, rather than what you put into it. High earnings, recognition, and job security are examples of extrinsic values." ID="ID_348799951" CREATED="1524022688912" MODIFIED="1524022701901"/>
</node>
</node>
<node TEXT="Complete &quot;Why&quot; Exercise" FOLDED="true" ID="ID_478074083" CREATED="1520126635779" MODIFIED="1524021905217">
<icon BUILTIN="unchecked"/>
<node TEXT="This exercise can be a useful tool in clarifying values related to work satisfaction. Jotting down answers to these questions, or perhaps sharing them with a career mentor familiar with your current work situation, is a great way of reaffirming values that are priorities for you in work." ID="ID_448885115" CREATED="1520126635779" MODIFIED="1524021879923">
<icon BUILTIN="info"/>
</node>
<node TEXT="Knowing how values are aligned with your job and the organization in which you work is often critical to understanding career-related satisfaction and motivation. A helpful framework for thinking about career values was developed by Nova (link is external). In their Values Driven Work assessment exercise, career values are clustered in four domains: Intrinsic Values, Work Environment Values, Work Content Values, and Work Relationship Values." ID="ID_1701960110" CREATED="1520126635782" MODIFIED="1524021882800">
<icon BUILTIN="info"/>
</node>
<node TEXT="What would you miss most if you left your current job? Why?" ID="ID_1319250592" CREATED="1520126635780" MODIFIED="1520126635780"/>
<node TEXT="What was your &quot;best job ever?&quot; Why?" ID="ID_557955149" CREATED="1520126635781" MODIFIED="1520126635781"/>
<node TEXT="When was a time you felt really energized in your work? Why?" ID="ID_1317004768" CREATED="1520126635781" MODIFIED="1524021949927"/>
<node TEXT="What value would you not compromise in a job? Why?" ID="ID_1988150692" CREATED="1520126635782" MODIFIED="1520126635782"/>
<node TEXT="Intrinsic Values: What motivates me to truly love my work day after day? Among a list of these values are Achievement, Giving to Community, Status, Independence, and Power." ID="ID_769206733" CREATED="1520126635782" MODIFIED="1520126635782"/>
<node TEXT="Work Environment Values: What working conditions provide an optimum environment in which I can do my best work? Work Environment Values include Learning, Benefits, Fast-Paced, Comfortable Income, Structure and many more." ID="ID_220613820" CREATED="1520126635782" MODIFIED="1520126635782"/>
<node TEXT="Work Content Values: What makes my work activities most satisfying and engaging to me? Among the 18 values in this area are values such as Problem Solving, Organizing, Public Contact, Detailed, and Creative." FOLDED="true" ID="ID_1078372811" CREATED="1520126635782" MODIFIED="1520126635782">
<node TEXT="Problem solving" ID="ID_1112022578" CREATED="1524021991334" MODIFIED="1524022001367"/>
<node TEXT="Process analysis and improvement" FOLDED="true" ID="ID_1712302142" CREATED="1524022008728" MODIFIED="1524022035226">
<node TEXT="Improving efficiency" ID="ID_1386667274" CREATED="1524022179655" MODIFIED="1524022186631"/>
<node TEXT="Reducing costs" ID="ID_908810585" CREATED="1524022187052" MODIFIED="1524022192713"/>
</node>
<node TEXT="Designing tools to better solve a problem" ID="ID_1966010278" CREATED="1524022085881" MODIFIED="1524022161617"/>
</node>
<node TEXT="Work Relationship Values: What characteristics of interaction with others in my workplace are the most important to me? Work Relationship Values include Open Communication, Diversity, Leadership, Teamwork, Competition, and Trust." ID="ID_1907017133" CREATED="1520126635782" MODIFIED="1520126635782"/>
</node>
</node>
<node TEXT="skills" ID="ID_20985580" CREATED="1520125870972" MODIFIED="1520125870973"/>
</node>
</node>
</node>
<node ID="ID_1661460107" CREATED="1603149469096" MODIFIED="1603149469096" LINK="https://www.thebalancecareers.com/free-career-aptitude-tests-2059813"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalancecareers.com/free-career-aptitude-tests-2059813">Free Career Aptitude and Career Assessment Tests</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Assessment" FOLDED="true" ID="ID_197116325" CREATED="1519760932904" MODIFIED="1556457617537">
<node TEXT="® Why" FOLDED="true" ID="ID_1006965661" CREATED="1519760932904" MODIFIED="1519760932904">
<node TEXT="Identify strengths" ID="ID_1927141169" CREATED="1519760932904" MODIFIED="1519760932904"/>
<node TEXT="Identify skills needed to meet goals" ID="ID_1462744701" CREATED="1519760932904" MODIFIED="1519760932904"/>
</node>
<node TEXT="® How" FOLDED="true" ID="ID_1723291588" CREATED="1519760932904" MODIFIED="1519760932904">
<node TEXT="Skills can be grouped into three categories:" FOLDED="true" ID="ID_181828192" CREATED="1519760932904" MODIFIED="1519760932904">
<node TEXT="Skills learned through past experience and education (knowledge-based skills)." ID="ID_122073588" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Skills you bring with you to any job (transferable or portable skills)." ID="ID_1039157607" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Personal traits, the things that make you who you are." ID="ID_494222342" CREATED="1519760932905" MODIFIED="1519760932905"/>
</node>
<node TEXT="The Assessment Tool" FOLDED="true" ID="ID_187616375" CREATED="1519760932905" MODIFIED="1519760932905">
<node TEXT="Gina divided a piece of paper into three columns and labeled them with &quot;previous experience,&quot; &quot;portable skills&quot; and &quot;personality,&quot; the three P&apos;s of marketing." FOLDED="true" ID="ID_1250815748" CREATED="1519760932905" MODIFIED="1519760932905">
<node TEXT="In the &quot;previous experience&quot; column she wrote:" FOLDED="true" ID="ID_1164009601" CREATED="1519760932905" MODIFIED="1519760932905">
<node TEXT="Marketing knowledge" ID="ID_930662609" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Communications skills" ID="ID_1072936922" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Vendor management" ID="ID_285852883" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Press and industry relations" ID="ID_399115495" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Web channel marketing" ID="ID_498966927" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Product development" ID="ID_464266228" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Computer skills" ID="ID_966677156" CREATED="1519760932905" MODIFIED="1519760932905"/>
</node>
<node TEXT="Under &quot;portable skills&quot; she wrote:" FOLDED="true" ID="ID_1015189203" CREATED="1519760932905" MODIFIED="1519760932905">
<node TEXT="Very organized" ID="ID_1134768413" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Time management" ID="ID_1809271640" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Writing skills" ID="ID_1619996638" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Communications" ID="ID_1811847696" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Customer focus" ID="ID_1239316462" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Problem solving" ID="ID_58705396" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Project management" ID="ID_440711215" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Good with budgets and numbers" ID="ID_948268422" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Good at coordinating" ID="ID_238461685" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Team leader" ID="ID_1762422345" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Excellent follow-through" ID="ID_553953358" CREATED="1519760932905" MODIFIED="1519760932905"/>
</node>
<node TEXT="In the &quot;personality column&quot; she wrote:" FOLDED="true" ID="ID_1477143888" CREATED="1519760932905" MODIFIED="1519760932905">
<node TEXT="Self-starter" ID="ID_899022012" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Independent" ID="ID_816132628" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Friendly" ID="ID_772780637" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Well-organized" ID="ID_1869763708" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Quick learner" ID="ID_1840749972" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Good judgment" ID="ID_1233912734" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Good attitude" ID="ID_1837151848" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Creative" ID="ID_1227952222" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Analytical" ID="ID_1152036071" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Flexible" ID="ID_21452194" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Good sense of humor" ID="ID_711966987" CREATED="1519760932905" MODIFIED="1519760932905"/>
<node TEXT="Goal-directed" ID="ID_1247262609" CREATED="1519760932905" MODIFIED="1519760932905"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Work Values" FOLDED="true" ID="ID_854550988" CREATED="1537478356008" MODIFIED="1603148638702">
<node TEXT="Leadership" FOLDED="true" ID="ID_644321837" CREATED="1560406239220" MODIFIED="1696633610420">
<node TEXT="Confidence in setting direction" ID="ID_137778885" CREATED="1560406269408" MODIFIED="1560406309061"/>
<node TEXT="Managing a team to meet goals" ID="ID_1874986320" CREATED="1560406309629" MODIFIED="1560406560388"/>
<node TEXT="Working from the big picture" FOLDED="true" ID="ID_314687059" CREATED="1560406627877" MODIFIED="1560406668213">
<node TEXT="Not getting caught up in the details" ID="ID_146012834" CREATED="1560406670646" MODIFIED="1560406682679"/>
</node>
</node>
<node TEXT="Purpose" ID="ID_1636571346" CREATED="1560403648581" MODIFIED="1560403653192"/>
<node TEXT="Need" FOLDED="true" ID="ID_492884695" CREATED="1592341094661" MODIFIED="1592341097053">
<node TEXT="Work harder" FOLDED="true" ID="ID_390929030" CREATED="1555457359859" MODIFIED="1555457367024">
<node TEXT="1) The law of attraction is a myth - There ain&apos;t nothing you can&apos;t have if you&apos;re willing to work hard and persevere." ID="ID_806831440" CREATED="1555457368586" MODIFIED="1555457368586"/>
<node TEXT="2) Fast - Pick up the pace, urgency, you don&apos;t have as much time as you think." ID="ID_58730075" CREATED="1555457368586" MODIFIED="1555457368586"/>
<node TEXT="3) Hard - Success is not for the weak or uncommitted. The process weeds out the weak." ID="ID_1378109890" CREATED="1555457368590" MODIFIED="1555457368590"/>
<node TEXT="4) Finish - Finish what you start and finish strong." ID="ID_783216516" CREATED="1555457368593" MODIFIED="1555457368593"/>
<node TEXT="5) Win the day - Master today, don&apos;t worry about tomorrow or your past." ID="ID_1370931465" CREATED="1555457368596" MODIFIED="1555457368596"/>
<node TEXT="6) Innovation is rewarded, execution is worship." ID="ID_940527280" CREATED="1555457368598" MODIFIED="1555457368598"/>
<node TEXT="&quot;The difference between a successful person and others is not a lack of strength, not a lack of knowledge, but rather a lack of will.&quot; Vince Lombardi" ID="ID_1973122200" CREATED="1555457368599" MODIFIED="1555457368599"/>
</node>
<node TEXT="the feeling that I am applying myself fully" ID="ID_945840896" CREATED="1539715193431" MODIFIED="1539715205431"/>
<node TEXT="what I am doing is creating value" ID="ID_1645214827" CREATED="1539715212737" MODIFIED="1539715229024"/>
<node TEXT="innovator" ID="ID_918546460" CREATED="1580567362778" MODIFIED="1580567367900"/>
<node TEXT="work/life balance," ID="ID_1611846649" CREATED="1519666374536" MODIFIED="1519666377475"/>
</node>
<node TEXT="efficiency" ID="ID_827168388" CREATED="1664731499497" MODIFIED="1664731501809"/>
<node TEXT="being recognized for technical expertise," ID="ID_507065793" CREATED="1519666272589" MODIFIED="1519666374536"/>
<node TEXT="Being highly valued by others" FOLDED="true" ID="ID_662440674" CREATED="1559540358249" MODIFIED="1559540378603">
<node TEXT="Feeling like I am helping others" ID="ID_813332951" CREATED="1560403666787" MODIFIED="1560403726046"/>
</node>
<node TEXT="Developing myself" ID="ID_315668274" CREATED="1519234503662" MODIFIED="1519234503662"/>
<node TEXT="Autonomy" ID="ID_643270224" CREATED="1560403641285" MODIFIED="1560403647281"/>
<node TEXT="Sense of empowerment" ID="ID_700882715" CREATED="1560403625830" MODIFIED="1560403638273"/>
</node>
<node TEXT="Dislikes" FOLDED="true" ID="ID_967006079" CREATED="1560403734560" MODIFIED="1560403739781">
<node TEXT="Inefficiency" ID="ID_1011773294" CREATED="1560403745895" MODIFIED="1560403760944"/>
<node TEXT="Unhealthy lifestyle" FOLDED="true" ID="ID_1406163524" CREATED="1560403761717" MODIFIED="1560403768280">
<node TEXT="sitting in front of a computer day after day" ID="ID_1688029960" CREATED="1664731532793" MODIFIED="1664731539558"/>
</node>
<node TEXT="Monotony" ID="ID_140089956" CREATED="1560403780686" MODIFIED="1560403784569"/>
<node TEXT="Lack of autonomy" ID="ID_1926182043" CREATED="1560403786071" MODIFIED="1560403803681"/>
<node TEXT="Feeling like my work is pointless" ID="ID_951475310" CREATED="1560403804247" MODIFIED="1560403824658"/>
<node TEXT="Lack of focus" ID="ID_185203987" CREATED="1560403927071" MODIFIED="1560403934331"/>
</node>
<node TEXT="Strengths" FOLDED="true" ID="ID_939260937" CREATED="1537478375427" MODIFIED="1696633683026"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="12pt">Strengths are things you’re naturally good at. If you’re good at something, you’ll find it easier. That means you’ll feel more confident and engaged, and you'll perform better.</font>
    </p>
  </body>
</html></richcontent>
<node TEXT="Identifying" FOLDED="true" ID="ID_210777169" CREATED="1592332303567" MODIFIED="1592332307577">
<node ID="ID_861607" CREATED="1592340011193" MODIFIED="1592340011193" LINK="https://www.forbes.com/sites/jacquelynsmith/2013/08/30/how-to-identify-your-workplace-strengths/#49c505e811d3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.forbes.com/sites/jacquelynsmith/2013/08/30/how-to-identify-your-workplace-strengths/#49c505e811d3">How To Identify Your Workplace Strengths</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_105517866" CREATED="1592332308793" MODIFIED="1592332308793" LINK="https://articles.bplans.com/how-to-identify-your-strengths-and-weaknesses/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://articles.bplans.com/how-to-identify-your-strengths-and-weaknesses/">How to Identify Your Strengths and Weaknesses</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_801225126" CREATED="1592330298755" MODIFIED="1592330298755" LINK="https://blogs.kent.ac.uk/kbs-employability/2016/07/09/strengths-vs-skills-whats-the-difference/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://blogs.kent.ac.uk/kbs-employability/2016/07/09/strengths-vs-skills-whats-the-difference/">Strengths vs Skills: what&#8217;s the difference? &#8211; Kent Business School Employability</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="My Strengths" FOLDED="true" ID="ID_1432362730" CREATED="1592340037310" MODIFIED="1592340042266">
<node TEXT="design" ID="ID_1115637909" CREATED="1592340143918" MODIFIED="1700331647846" LINK="#ID_1253352728"/>
<node TEXT="build" ID="ID_42708465" CREATED="1592340148210" MODIFIED="1700331659039" LINK="#ID_503897244"/>
</node>
<node TEXT="Strengths" FOLDED="true" ID="ID_391150542" CREATED="1592340032496" MODIFIED="1592340036305">
<node FOLDED="true" ID="ID_371556203" CREATED="1592340279447" MODIFIED="1592340279447" LINK="https://www.forbes.com/sites/jacquelynsmith/2013/08/30/how-to-identify-your-workplace-strengths/#49c505e811d3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.forbes.com/sites/jacquelynsmith/2013/08/30/how-to-identify-your-workplace-strengths/#49c505e811d3">How To Identify Your Workplace Strengths</a>
  </body>
</html>
</richcontent>
<node TEXT="Characteristics of the “envision” workplace strength:" FOLDED="true" ID="ID_980499568" CREATED="1592340068010" MODIFIED="1592340068010">
<node TEXT="•        Thinking strategically: The ability to see past today’s issues and focus on a longer term destination." ID="ID_1770498766" CREATED="1592340068010" MODIFIED="1592340068010"/>
<node TEXT="•        Setting a visionary destination: The ability to establish a positive future in the minds of others that doesn’t exist today." ID="ID_263045501" CREATED="1592340068010" MODIFIED="1592340068010"/>
<node TEXT="•        Thinking inventively: The ability to conceptualize a working solution that can ultimately convert into a tangible product-service offering." ID="ID_1008707996" CREATED="1592340068020" MODIFIED="1592340068020"/>
<node TEXT="•        Generating imaginative ideas: The ability to see and articulate possibilities that are not purely grounded in experience." ID="ID_1152237017" CREATED="1592340068020" MODIFIED="1592340068020"/>
<node TEXT="•        Thinking creatively: The ability to offer new thoughts on subject areas that others have not considered." ID="ID_49045900" CREATED="1592340068020" MODIFIED="1592340068020"/>
<node TEXT="•        Pioneering new ideas: The ability to create a new line of thought that has not yet been proven in practice." ID="ID_508411432" CREATED="1592340068026" MODIFIED="1592340068026"/>
<node TEXT="•        Brainstorming new ideas: The ability to work with others to co-create new ideas and new solutions." ID="ID_1433725200" CREATED="1592340068030" MODIFIED="1592340068030"/>
</node>
<node TEXT="Characteristics of the “design” workplace strength:" FOLDED="true" ID="ID_1253352728" CREATED="1592340068034" MODIFIED="1592340068034">
<node TEXT="•        Analyzing situations: The ability to conceptually break down a situation into parts and understand those parts." ID="ID_565184751" CREATED="1592340068037" MODIFIED="1592340320113">
<font BOLD="true"/>
</node>
<node TEXT="•        Defining clear policies: The ability to establish well-understood guidelines to help groups of individuals work in a unified way." ID="ID_353885287" CREATED="1592340068039" MODIFIED="1592340068039"/>
<node TEXT="•        Defining detailed objectives: The ability to create explicit goals to direct the work of individuals and the organization overall." ID="ID_1534226802" CREATED="1592340068043" MODIFIED="1592340397080">
<font BOLD="true"/>
</node>
<node TEXT="•        Planning budgets: The ability to establish and control the allocation of resources to achieve organizational goals." ID="ID_458293164" CREATED="1592340068046" MODIFIED="1592340068046"/>
<node TEXT="•        Establishing clear performance measures: The ability to create a standard mechanism to evaluate whether or not goals are achieved." ID="ID_1010548340" CREATED="1592340068048" MODIFIED="1592340068048"/>
<node TEXT="•        Judging performance objectively: The ability to independently weigh evidence and form an opinion on personal and organizational results." ID="ID_1602981969" CREATED="1592340068052" MODIFIED="1592340068052"/>
<node TEXT="•        Making decisions by the numbers: The ability to make a final choice based upon quantitative reasoning and measures." ID="ID_902374135" CREATED="1592340068056" MODIFIED="1592340068056"/>
</node>
<node TEXT="Characteristics of the “build” workplace strength:" FOLDED="true" ID="ID_503897244" CREATED="1592340068059" MODIFIED="1592340068059">
<node TEXT="•        Implement standard processes: The ability to get work done effectively, efficiently, and consistently, using a repeatable series of actions." ID="ID_861676991" CREATED="1592340068061" MODIFIED="1592340328365">
<font BOLD="true"/>
</node>
<node TEXT="•        Implement step-by-step procedures: The ability to get work done using an established set of instructions or checklists." ID="ID_1944162278" CREATED="1592340068063" MODIFIED="1592340335509">
<font BOLD="true"/>
</node>
<node TEXT="•        Implement important projects: The ability to execute a planned set of activities to achieve a significant organizational or physical change." ID="ID_871722779" CREATED="1592340068066" MODIFIED="1592340068066"/>
<node TEXT="•        Implement integrated programs: The ability to unify—and manage as a group—a series of projects to holistically achieve enterprise results." ID="ID_254084120" CREATED="1592340068069" MODIFIED="1592340068069"/>
<node TEXT="•        Implement proven methods: The ability to use well-established procedures to improve enterprise performance." ID="ID_883459371" CREATED="1592340068072" MODIFIED="1592340068072"/>
<node TEXT="•        Implement practical solutions: The ability to solve problems by applying tools and techniques that are proven to be sufficient, rather than state of the art." ID="ID_1979039013" CREATED="1592340068075" MODIFIED="1592408791731">
<font BOLD="true"/>
</node>
<node TEXT="•        Implement roles and responsibilities: The ability to systematically execute activities through the enterprise’s organizational structure." ID="ID_1039240896" CREATED="1592340068079" MODIFIED="1592340068079"/>
</node>
<node TEXT="Characteristics of the “operate” workplace strength:" FOLDED="true" ID="ID_607969310" CREATED="1592340068082" MODIFIED="1592340068082">
<node TEXT="•        Building personal relationships: The ability to productively and progressively bond with key people as individuals and groups on an emotional level." ID="ID_615195622" CREATED="1592340068085" MODIFIED="1592340068085"/>
<node TEXT="•        Working in teams: The ability to work with others in a way where you subordinate yourself as an individual to better achieve the goals of the group." ID="ID_1666275412" CREATED="1592340068087" MODIFIED="1592340068087"/>
<node TEXT="•        Coaching others: The ability to help people contribute more by facilitating their personal growth breakthroughs to achieve specific personal and organizational goals." ID="ID_690252032" CREATED="1592340068091" MODIFIED="1592340068091"/>
<node TEXT="•        Supporting others: The ability to help people achieve their goals and recover when they encounter problems." ID="ID_901661590" CREATED="1592340068095" MODIFIED="1592340068095"/>
<node TEXT="•        Relating to people: The ability to establish a kinship with others, building upon commonalities and deemphasizing or diffusing differences." ID="ID_1434013687" CREATED="1592340068098" MODIFIED="1592340068098"/>
<node TEXT="•        Communicating: The ability to transfer information verbally and non-verbally to achieve sufficient interpersonal understanding and produce actions." ID="ID_705248127" CREATED="1592340068105" MODIFIED="1592340068105"/>
<node TEXT="•        Changing spontaneously: The ability to consistently achieve better results by rapidly and successfully adapting to a dynamic environment." ID="ID_626456343" CREATED="1592340068112" MODIFIED="1592340068112"/>
</node>
</node>
</node>
<node TEXT="Talents" FOLDED="true" ID="ID_103593925" CREATED="1537478429540" MODIFIED="1537478432158">
<node TEXT="Figuring out how things work" ID="ID_353622434" CREATED="1592332468041" MODIFIED="1592332479860"/>
<node TEXT="Finding ways to improve existing processes" ID="ID_220046278" CREATED="1592332481345" MODIFIED="1592332496290"/>
</node>
</node>
<node TEXT="Weaknesses" FOLDED="true" ID="ID_1636577672" CREATED="1538163433280" MODIFIED="1589836460926">
<node ID="ID_431535922" CREATED="1696635719200" MODIFIED="1696635719200" LINK="https://www.desiringgod.org/articles/dont-waste-your-weaknesses"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.desiringgod.org/articles/dont-waste-your-weaknesses">Don’t Waste Your Weaknesses | Desiring God</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1127300578" CREATED="1696633668394" MODIFIED="1696633668394" LINK="https://proverbs31.org/read/devotions/full-post/2020/07/31/the-gift-of-our-weakness"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://proverbs31.org/read/devotions/full-post/2020/07/31/the-gift-of-our-weakness">The Gift of Our Weakness</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Skill Areas that are lacking" FOLDED="true" ID="ID_1758764011" CREATED="1610126751218" MODIFIED="1610126770400">
<node TEXT="Interpersonal" ID="ID_1505927504" CREATED="1610126771976" MODIFIED="1610126776141"/>
<node TEXT="Leadership" ID="ID_906998683" CREATED="1610126777025" MODIFIED="1610126780966"/>
<node TEXT="Project Management" ID="ID_459491387" CREATED="1610126781998" MODIFIED="1610126790754"/>
<node TEXT="Communication" ID="ID_1075063508" CREATED="1610126798797" MODIFIED="1610126802077"/>
</node>
<node TEXT="improved" FOLDED="true" ID="ID_879855527" CREATED="1696313454284" MODIFIED="1696313471781">
<node TEXT="Quitter" ID="ID_55055750" CREATED="1537479399899" MODIFIED="1537479403221"/>
<node TEXT="Easily stressed" ID="ID_1629313738" CREATED="1537479415050" MODIFIED="1537479420253"/>
<node TEXT="avoidant" ID="ID_813700729" CREATED="1537479441150" MODIFIED="1537479452213"/>
<node TEXT="lazy" ID="ID_1097669997" CREATED="1537479478656" MODIFIED="1537479486663"/>
</node>
</node>
</node>
<node TEXT="Networking" FOLDED="true" POSITION="bottom_or_right" ID="ID_1131434941" CREATED="1590035824099" MODIFIED="1590035829687">
<node TEXT="Maintain relationships" ID="ID_1203829380" CREATED="1707781257476" MODIFIED="1707781263307"/>
<node TEXT="Online Presence" FOLDED="true" ID="ID_219180227" CREATED="1707764026529" MODIFIED="1707764035314">
<node ID="ID_1677567020" CREATED="1707764036217" MODIFIED="1707764036217" LINK="https://www.coursera.org/learn/data-preparation/lecture/uaxC6/manage-your-presence-as-a-data-analyst"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/data-preparation/lecture/uaxC6/manage-your-presence-as-a-data-analyst">Manage your presence as a data analyst | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="a professional online presence can" FOLDED="true" ID="ID_1695260992" CREATED="1707764764905" MODIFIED="1707764770824">
<node TEXT="Help potential employers find you" ID="ID_1209089794" CREATED="1707764770831" MODIFIED="1707764796338"/>
<node TEXT="Make connections with other analysts" ID="ID_786772796" CREATED="1707764796354" MODIFIED="1707764800934"/>
<node TEXT="Learn and share data findings" ID="ID_1052933127" CREATED="1707764800952" MODIFIED="1707764805339"/>
<node TEXT="Participate in community events" ID="ID_274642813" CREATED="1707764805355" MODIFIED="1707764809613"/>
</node>
<node TEXT="Platforms" FOLDED="true" ID="ID_1289392711" CREATED="1707764835946" MODIFIED="1707764838774">
<node TEXT="LinkedIn" FOLDED="true" ID="ID_396147367" CREATED="1590037659134" MODIFIED="1590037663053">
<node TEXT="login" FOLDED="true" ID="ID_1874945886" CREATED="1667773430407" MODIFIED="1667773433474">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1398341401" CREATED="1548879861606" MODIFIED="1548879870393"/>
<node TEXT="dr0w$$@p" ID="ID_872379556" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node FOLDED="true" ID="ID_1450451328" CREATED="1590092420048" MODIFIED="1590092420048" LINK="https://www.linkedin.com/pulse/how-reach-out-stranger-linkedin-make-connection-kathy-caprino/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.linkedin.com/pulse/how-reach-out-stranger-linkedin-make-connection-kathy-caprino/">How to Reach Out To a Stranger On LinkedIn and Make a Connection | LinkedIn</a>
  </body>
</html>
</richcontent>
<node ID="ID_478728293" CREATED="1590092450827" MODIFIED="1590092450827"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: black; font-family: -apple-system, system-ui, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Fira Sans, Ubuntu, Oxygen, Oxygen Sans, Cantarell, Droid Sans, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Lucida Grande, Helvetica, Arial, sans-serif; font-size: 14px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: pre-wrap; word-spacing: 0px; background-color: rgb(243, 246, 248); display: inline !important; float: none"><font color="black" face="-apple-system, system-ui, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Fira Sans, Ubuntu, Oxygen, Oxygen Sans, Cantarell, Droid Sans, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Lucida Grande, Helvetica, Arial, sans-serif" size="14px">&quot;Reach out instead with a unique insight, a positive comment, a helpful offer, or a new point of view or question that will be helpful and welcomed by the new contact.&quot;</font></span>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1817898716" CREATED="1590037663747" MODIFIED="1590037663747" LINK="https://www.wordstream.com/blog/ws/2016/01/18/linkedin-connection-requests"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.wordstream.com/blog/ws/2016/01/18/linkedin-connection-requests">How to Write the Perfect LinkedIn Connection Request | WordStream</a>
  </body>
</html>
</richcontent>
<node TEXT="Polite" ID="ID_1771866529" CREATED="1590092041732" MODIFIED="1590092041732"/>
<node TEXT="Pertinent" ID="ID_1254941392" CREATED="1590092041732" MODIFIED="1590092041732"/>
<node TEXT="Personalized" ID="ID_306827902" CREATED="1590092041741" MODIFIED="1590092041741"/>
<node TEXT="Professional" ID="ID_1186734339" CREATED="1590092041745" MODIFIED="1590092041745"/>
<node TEXT="Praiseful" ID="ID_1201763440" CREATED="1590092041749" MODIFIED="1590092041749"/>
</node>
<node TEXT="Update profile" ID="ID_1501442415" CREATED="1590037665460" MODIFIED="1590038028627"/>
</node>
<node TEXT="Data" FOLDED="true" ID="ID_1625033493" CREATED="1707781937973" MODIFIED="1707781939533">
<node TEXT="Kaggle" FOLDED="true" ID="ID_564205056" CREATED="1707764995645" MODIFIED="1707765000067">
<node ID="ID_1378151098" CREATED="1707768479308" MODIFIED="1707768479308" LINK="https://medium.com/kaggle-blog/i-trained-a-model-what-is-next-d1ba1c560e26"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/kaggle-blog/i-trained-a-model-what-is-next-d1ba1c560e26">I trained a model. What is next?. This post was written by Vladimir… | by Kaggle Team | Kaggle Blog | Medium</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="KDNuggets" ID="ID_1747950097" CREATED="1707781945985" MODIFIED="1707781950810"/>
<node TEXT="GitHub" ID="ID_487864389" CREATED="1707764842834" MODIFIED="1707764846906"/>
<node TEXT="Medium" ID="ID_240645170" CREATED="1707765020550" MODIFIED="1707765024727"/>
</node>
</node>
</node>
<node TEXT="Public Meetups" FOLDED="true" ID="ID_116593506" CREATED="1707781248144" MODIFIED="1707781256093">
<node ID="ID_1354154659" CREATED="1707781908641" MODIFIED="1707781908641" LINK="https://www.meetup.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.meetup.com/">Meetup | Find Local Groups, Events, and Activities Near You</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="" ID="ID_1268756419" CREATED="1707781887759" MODIFIED="1707781887759"/>
</node>
<node TEXT="Communication" FOLDED="true" ID="ID_1678737922" CREATED="1707781539086" MODIFIED="1707781542202">
<node TEXT="Small Talk" FOLDED="true" ID="ID_1724239292" CREATED="1705263608315" MODIFIED="1705263614643">
<node ID="ID_68171328" CREATED="1705263615946" MODIFIED="1705263615946" LINK="https://www.themuse.com/advice/48-questions-thatll-make-awkward-small-talk-so-much-easier"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/48-questions-thatll-make-awkward-small-talk-so-much-easier">48 Questions That'll Make Small Talk Easier | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="reference" LOCALIZED_STYLE_REF="AutomaticLayout.level,6" FOLDED="true" ID="ID_1024115086" CREATED="1696305621672" MODIFIED="1707781292760">
<node FOLDED="true" ID="ID_1214491730" CREATED="1707781454946" MODIFIED="1707781454946" LINK="https://paminy.com/summary-your-invisible-network/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://paminy.com/summary-your-invisible-network/">Summary: Your Invisible Network: How to Create, Maintain, and Leverage the Relationships That Will Transform Your Career by Michael Urtuzuástegui Melcher - Paminy</a>
  </body>
</html>
</richcontent>
<node TEXT="Take-Aways" FOLDED="true" ID="ID_1991011350" CREATED="1696305864629" MODIFIED="1696305864629">
<node TEXT="• Your professional advancement relies on your ability to initiate and maintain relationships." ID="ID_1307784005" CREATED="1696305864629" MODIFIED="1696305864629"/>
<node TEXT="• Building, maintaining and using your relationships form the core of productive professional networking." ID="ID_1901219407" CREATED="1696305864629" MODIFIED="1696305864629"/>
<node TEXT="• Harness your relationships to connect to new people, ideas and opportunities." ID="ID_1319874287" CREATED="1696305864630" MODIFIED="1696305864630"/>
<node TEXT="• Competence is the foundation on which strong networking skills are built." ID="ID_347639607" CREATED="1696305864631" MODIFIED="1696305864631"/>
<node TEXT="• Connect regularly and meaningfully with those in your invisible network." ID="ID_1786220241" CREATED="1696305864632" MODIFIED="1696305864632"/>
<node TEXT="• Act on your curiosity, instigate interactions and try something new." ID="ID_1541094058" CREATED="1696305864632" MODIFIED="1696305864632"/>
<node TEXT="• Sharing stories of wrong turns, disappointments and doubts deepens connections." ID="ID_190032944" CREATED="1696305864632" MODIFIED="1696305864632"/>
<node TEXT="• Develop a clear understanding of what you want and how to ask for it, and persevere." ID="ID_1104285568" CREATED="1696305864633" MODIFIED="1713497556417">
<font BOLD="true"/>
</node>
<node TEXT="• Healthy relationships involve mutual giving and receiving, but not exact reciprocity." ID="ID_1910978629" CREATED="1696305864633" MODIFIED="1713497568412">
<font BOLD="true"/>
</node>
</node>
</node>
<node ID="ID_1798600753" CREATED="1713497509267" MODIFIED="1713497509267" LINK="https://lifehacker.com/how-to-make-people-think-of-you-for-opportunities-1830002444"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://lifehacker.com/how-to-make-people-think-of-you-for-opportunities-1830002444">How to Make People Think of You for Opportunities | Lifehacker</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="M:\My Drive\My Google Docs\Career\Networking\your-invisible-network-melcher-en-46041.pdf" ID="ID_84669007" CREATED="1696306029599" MODIFIED="1696306034830" LINK="file:/M:/My%20Drive/My%20Google%20Docs/Career/Networking/your-invisible-network-melcher-en-46041.pdf"/>
</node>
</node>
<node TEXT="career path" POSITION="bottom_or_right" ID="ID_153155454" CREATED="1619582980762" MODIFIED="1619582986486">
<node TEXT="Goals" FOLDED="true" ID="ID_99498491" CREATED="1519666186804" MODIFIED="1519760968469">
<node TEXT="Aligned with Self Assessment" FOLDED="true" ID="ID_19635785" CREATED="1700331579198" MODIFIED="1700331594010">
<node TEXT="Aligned with" FOLDED="true" ID="ID_360259535" CREATED="1698869215843" MODIFIED="1698869224117">
<node TEXT="talents" ID="ID_1941048405" CREATED="1698869225019" MODIFIED="1698869228651"/>
<node TEXT="personality" ID="ID_1849478518" CREATED="1698869228842" MODIFIED="1698869231609"/>
<node TEXT="values" ID="ID_1289503572" CREATED="1698869232078" MODIFIED="1698869234426"/>
</node>
<node TEXT="Reflective Questions" FOLDED="true" ID="ID_593624043" CREATED="1519243258910" MODIFIED="1519243258910">
<node TEXT="What does the position consist of daily?" ID="ID_865009655" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="What work environment feels healthy?" ID="ID_851938728" CREATED="1649304356723" MODIFIED="1649304381374"/>
<node TEXT="Who do you want to be working with?" ID="ID_1631803538" CREATED="1649304382766" MODIFIED="1649304405993"/>
<node TEXT="Who needs you the most?" ID="ID_797763664" CREATED="1649304412990" MODIFIED="1649304420003"/>
<node TEXT="What path am I willing to take?" ID="ID_1984662363" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="Who do I admire most?" ID="ID_933367259" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="How hard do I want to work?" ID="ID_482804454" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="How much responsibility do I want to have?" ID="ID_115876579" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="What field do you want to be in?" FOLDED="true" ID="ID_1333259436" CREATED="1519243258910" MODIFIED="1519243258910">
<node TEXT="Plant Breeding?" ID="ID_1007848087" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="Statistical Analysis?" ID="ID_134938909" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="Modeling / Systems Biology Integranomics" ID="ID_880180165" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="Genetics?" FOLDED="true" ID="ID_1658079568" CREATED="1519243258910" MODIFIED="1519243258910">
<node TEXT="Minor in Genetics?" ID="ID_1233838987" CREATED="1519243258910" MODIFIED="1519243258910"/>
</node>
</node>
<node TEXT="Why do you want to be in this field?" ID="ID_426353792" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="What contribution do you want to make to your field?" ID="ID_1757648223" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="Creating value vs. having value" ID="ID_1087026318" CREATED="1519243258910" MODIFIED="1519243258910"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_14472782" CREATED="1701760697984" MODIFIED="1701760702644">
<node ID="ID_629725519" CREATED="1592340920306" MODIFIED="1592340920306" LINK="https://www.wikihow.com/Decide-on-a-Career-Path"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.wikihow.com/Decide-on-a-Career-Path">How to Decide on a Career Path: 15 Steps (with Pictures) - wikiHow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="my story" ID="ID_753542275" CREATED="1619583904895" MODIFIED="1619583908322">
<node TEXT="my brand" ID="ID_1948867201" CREATED="1619583950491" MODIFIED="1619583954082"/>
<node TEXT="Work history" ID="ID_921103013" CREATED="1714080866571" MODIFIED="1714080915976" LINK="#ID_385296576"/>
</node>
<node TEXT="Next Role: ?" ID="ID_301623432" CREATED="1714080622298" MODIFIED="1714080628800">
<node TEXT="Changing roles" ID="ID_1501829714" CREATED="1592330604823" MODIFIED="1592330609345">
<node TEXT="in general you can move laterally across sites or companies, and upward within a company, but not both at the same time" ID="ID_1213120668" CREATED="1705640759259" MODIFIED="1705640830636"/>
<node TEXT="Find ideal role" FOLDED="true" ID="ID_1864943324" CREATED="1698869135903" MODIFIED="1698869142151">
<node TEXT="can pick yourself doing it happily" ID="ID_1873764837" CREATED="1705640452761" MODIFIED="1705640461600"/>
<node TEXT="research skills required" ID="ID_800730123" CREATED="1698901622629" MODIFIED="1698901627124"/>
<node TEXT="Summarize position" ID="ID_746751086" CREATED="1706245936019" MODIFIED="1706245946269"/>
</node>
<node TEXT="identify opportunities that align with your experience and education" ID="ID_683464868" CREATED="1620600081422" MODIFIED="1708465261078">
<node TEXT="Location" ID="ID_535676346" CREATED="1698868045170" MODIFIED="1698868047907">
<node TEXT="RTP" ID="ID_1520386471" CREATED="1714086734487" MODIFIED="1714086736157">
<node ID="ID_1340750877" CREATED="1714086737466" MODIFIED="1714086737466" LINK="https://www.researchtriangle.org/news/looking-for-a-job-heres-where-to-find-thousands-of-triangle-opportunities/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.researchtriangle.org/news/looking-for-a-job-heres-where-to-find-thousands-of-triangle-opportunities/">Looking for a job? Here’s where to find thousands of Triangle opportunities - Research Triangle Regional Partnership</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Nebraska" FOLDED="true" ID="ID_926932285" CREATED="1704313569084" MODIFIED="1704313572927">
<node TEXT="Omaha" FOLDED="true" ID="ID_91581408" CREATED="1698868057761" MODIFIED="1698868061056">
<node TEXT="Syngenta" FOLDED="true" ID="ID_1899923448" CREATED="1703700831514" MODIFIED="1703700835492">
<node TEXT="27m" ID="ID_1628165661" CREATED="1704828910110" MODIFIED="1704828915344"/>
<node ID="ID_205615324" CREATED="1703700837321" MODIFIED="1703700837321" LINK="https://jobs.syngenta.com/jobs"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://jobs.syngenta.com/jobs">Job results | Syngenta</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="internal" FOLDED="true" ID="ID_1937422913" CREATED="1703700840971" MODIFIED="1703700842981">
<node FOLDED="true" ID="ID_1325986064" CREATED="1519773107296" MODIFIED="1681394957325" LINK="https://www.smartrecruiters.com/app/employee-portal"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Syngenta
    </p>
  </body>
</html>
</richcontent>
<node TEXT="login" FOLDED="true" ID="ID_26887431" CREATED="1703700227154" MODIFIED="1703700231836">
<node ID="ID_1664727893" CREATED="1519773107296" MODIFIED="1519773107296"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      U581917
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Lucydog2*" ID="ID_972620460" CREATED="1661712080551" MODIFIED="1661712958779"/>
</node>
</node>
<node TEXT="Bruno" FOLDED="true" ID="ID_127224172" CREATED="1696270323369" MODIFIED="1696270325490">
<node TEXT="Former Teresa" ID="ID_1523701184" CREATED="1696270949992" MODIFIED="1696270966061"/>
<node TEXT="Tech role in mind" ID="ID_209507219" CREATED="1696270328610" MODIFIED="1696270335218"/>
<node TEXT="Market segment" ID="ID_1365708321" CREATED="1696270971539" MODIFIED="1696270990523"/>
</node>
<node TEXT="Veronica" ID="ID_1190007583" CREATED="1696271255911" MODIFIED="1696271260425"/>
<node TEXT="Breeder" FOLDED="true" ID="ID_1935893873" CREATED="1696270233352" MODIFIED="1696270235413">
<node TEXT="Mel Off next 6 weeks" FOLDED="true" ID="ID_1795542624" CREATED="1696271056568" MODIFIED="1696313514253">
<node TEXT="twr" ID="ID_277555966" CREATED="1696271064844" MODIFIED="1696271067986"/>
</node>
<node TEXT="Hiring Manager" FOLDED="true" ID="ID_1706945757" CREATED="1696270240353" MODIFIED="1696270243568">
<node TEXT="Miguel" FOLDED="true" ID="ID_759200461" CREATED="1696270236066" MODIFIED="1696270239566">
<node TEXT="Lead Global Leafy" ID="ID_1309560441" CREATED="1696271013685" MODIFIED="1696271022962"/>
</node>
</node>
</node>
<node TEXT="Seed Production" FOLDED="true" ID="ID_1711861714" CREATED="1696268610932" MODIFIED="1696268616386">
<node TEXT="Veg. Agronomist – Field Production Research" FOLDED="true" ID="ID_1417345465" CREATED="1696268624527" MODIFIED="1696268624527">
<node TEXT="Syngenta SeedsFull-time18055846" ID="ID_1307490303" CREATED="1696268624528" MODIFIED="1696268624528"/>
<node TEXT="Company Description" FOLDED="true" ID="ID_1042330744" CREATED="1696268624528" MODIFIED="1696268624528">
<node TEXT="Syngenta is a global leader in agriculture; rooted in science and dedicated to bringing plant potential to life. Each of our 28,000 employees in more than 90 countries work together to solve one of humanity’s most pressing challenges: growing more food with fewer resources. A diverse workforce and an inclusive workplace environment are enablers of our ambition to be the most collaborative and trusted team in agriculture. Our employees reflect the diversity of our customers, the markets where we operate and the communities which we serve. Join us and help shape the future of agriculture." ID="ID_301717333" CREATED="1696268624528" MODIFIED="1696268624528"/>
</node>
</node>
<node TEXT="Job Description" FOLDED="true" ID="ID_978572704" CREATED="1696268624529" MODIFIED="1696268624529">
<node TEXT="At Syngenta, we believe every employee has a role to play in safely feeding the world and taking care of our planet. To support that challenge, the NA SSV Field Production Team is currently seeking a , Veg. Agronomist – Field Production Research located in Salinas, CA" ID="ID_1050507293" CREATED="1696268624532" MODIFIED="1696268624532"/>
</node>
<node TEXT="Role Purpose" FOLDED="true" ID="ID_568701260" CREATED="1696268624532" MODIFIED="1696268624532">
<node TEXT="The incumbent will be responsible to coordinate a Veg parent characterization and agronomic improvement program for Vegetable production in North America to enable data driven decisions for product advancement, production instructions, and production planning." ID="ID_606971370" CREATED="1696268624533" MODIFIED="1696268624533"/>
<node TEXT="Delivers a key service through a team or leads complex and significant tasks and projects of regional or global scope.   Provides high scientific, technical, specialist/subject matter or product expertise and leadership for assigned species groups and region.  Facilitate and lead the cross crops vegetable seed Field Production continuous improvement plan.  Communicate and liaise with all relevant stakeholders to enable one team." ID="ID_987740645" CREATED="1696268624534" MODIFIED="1696268624534"/>
<node TEXT="Interaction is mostly with:" FOLDED="true" ID="ID_1448900564" CREATED="1696268624535" MODIFIED="1696268624535">
<node TEXT="Head of Small Seed Vegetable Production" ID="ID_657704667" CREATED="1696268624535" MODIFIED="1696268624535"/>
<node TEXT="Global Production Crop Strategist SSV–" ID="ID_453880589" CREATED="1696268624536" MODIFIED="1696268624536"/>
<node TEXT="Supply Chain Leads – Global Supply Chain Teams" ID="ID_918160817" CREATED="1696268624536" MODIFIED="1696268624536"/>
<node TEXT="Regional MoM organization" ID="ID_748478936" CREATED="1696268624536" MODIFIED="1696268624536"/>
<node TEXT="Production Admin Manager" ID="ID_1767991287" CREATED="1696268624537" MODIFIED="1696268624537"/>
<node TEXT="Regional Field Production Heads/Managers" ID="ID_446113771" CREATED="1696268624537" MODIFIED="1696268624537"/>
<node TEXT="Global Field Production managers" ID="ID_589739255" CREATED="1696268624537" MODIFIED="1696268624537"/>
<node TEXT="Regional Field Production Agronomist" ID="ID_1437855442" CREATED="1696268624537" MODIFIED="1696268624537"/>
<node TEXT="Regional Field Production Research teams" ID="ID_345581253" CREATED="1696268624538" MODIFIED="1696268624538"/>
<node TEXT="Regional QC Leads" ID="ID_1500950447" CREATED="1696268624538" MODIFIED="1696268624538"/>
<node TEXT="Regional University network" ID="ID_1074786515" CREATED="1696268624538" MODIFIED="1696268624538"/>
<node TEXT="Relevant Species Breeders and related R&amp;D personnel." ID="ID_1172400922" CREATED="1696268624538" MODIFIED="1696268624538"/>
</node>
</node>
<node TEXT="Accountabilities" FOLDED="true" ID="ID_1840268492" CREATED="1696268624540" MODIFIED="1696268624540">
<node TEXT="Take the lead in inbred characterization to provide key seed producibility data for breeders and the hybrid advancement process, analysis of supply reliability and relative cost of production." ID="ID_625542160" CREATED="1696268624540" MODIFIED="1696268624540"/>
<node TEXT="Development of production instruction and product profile for crops grown in region." ID="ID_1112972818" CREATED="1696268624540" MODIFIED="1696268624540"/>
<node TEXT="Lead and assist with experimental design and trial creation. This involves relevant ad-hoc research projects, determining seed, crop protection products entry lists, and making all necessary preparations to ensure experiment completion." ID="ID_1353547010" CREATED="1696268624541" MODIFIED="1696268624541"/>
<node TEXT="Develop and maintain communication with various functions within Syngenta, Research and Development, Biological Operations, Seeds Production, Parent Seeds, Quality Control and Marketing and Sales. This includes other relevant sectors in the seed industry and universities." ID="ID_1897190852" CREATED="1696268624541" MODIFIED="1696268624541"/>
<node TEXT="Analyze data and prepare reports/presentations for delivery to internal and external department customers. Present information through a number of formal and informal avenues. Develop two-way communication with various audiences ranging from breeders to department managers." ID="ID_201198878" CREATED="1696268624542" MODIFIED="1696268624542"/>
<node TEXT="Maintain an awareness of competitive developments and key technologies in the seed production and adjacent industries, along with external technology institutions to ensure that innovations are identified, evaluated, and implemented." ID="ID_1005898441" CREATED="1696268624542" MODIFIED="1696268624542"/>
<node TEXT="Supervise research activities of Syngenta FPR staff, this includes 3rd party personnel selection, prioritizing tasks, assigning workloads, and coordination of data collection activities." ID="ID_1599836522" CREATED="1696268624542" MODIFIED="1696268624542"/>
<node TEXT="Regular production field visits and partnering with field production staff to ensure trial data are calibrated and relevant to business, as well as visits with sales staff and customer to understand customer needs." ID="ID_678308886" CREATED="1696268624543" MODIFIED="1696268624543"/>
<node TEXT="Ensure full Health Safety &amp; Environment (HSE) compliance and promote environmentally sustain-able solutions." ID="ID_286405699" CREATED="1696268624544" MODIFIED="1696268624544"/>
<node TEXT="Personal development: Attend Company sanctioned and/or external training seminars, as agreed upon with Supervisor, for development of personal and technical skills." ID="ID_1087191282" CREATED="1696268624544" MODIFIED="1696268624544"/>
<node TEXT="Representation of Syngenta: Builds trust inside the company and in the local community showing ethical considerations and Syngenta values are reflected in company activities. Effectively pro-motes FPR and Syngenta Brand inside the company and with stakeholders and customers." ID="ID_340816536" CREATED="1696268624545" MODIFIED="1696268624545"/>
<node TEXT="Management of regional improvement projects and action plans" ID="ID_334633248" CREATED="1696268624545" MODIFIED="1696268624545"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_1998122587" CREATED="1696268624546" MODIFIED="1696268624546">
<node TEXT="Bachelors Degree required with significant relevant 5 years of experience or Master’s Degree in Agronomy, Plant Breeding, related agricultural or biological discipline." ID="ID_751104444" CREATED="1696268624546" MODIFIED="1696268624546"/>
<node TEXT="Functional knowledge of Seeds production across a range of crops desired." ID="ID_1365078892" CREATED="1696268624546" MODIFIED="1696268624546"/>
<node TEXT="Organization; planning, pro-activity and reactivity leadership, flexibility and availability." ID="ID_783356911" CREATED="1696268624548" MODIFIED="1696268624548"/>
<node TEXT="Experience in Managing Cross Functional teams." ID="ID_1882908402" CREATED="1696268624549" MODIFIED="1696268624549"/>
<node TEXT="Strong IT &amp; project management skills and experience" ID="ID_45879493" CREATED="1696268624550" MODIFIED="1696268624550"/>
<node TEXT="Must have excellent communication skills, both verbal and written" ID="ID_63843325" CREATED="1696268624550" MODIFIED="1696268624550"/>
<node TEXT="Ability to influence and change current ways of working to develop a more scientific approach in the way we describe data, design experiments, integrate, interpret, and present results." ID="ID_1420910503" CREATED="1696268624551" MODIFIED="1696268624551"/>
<node TEXT="Team working in multi-functional groups, both within FPR and externally." ID="ID_1086984129" CREATED="1696268624551" MODIFIED="1696268624551"/>
<node TEXT="Ability to coordinate activities across geographies and cultures." ID="ID_992494591" CREATED="1696268624552" MODIFIED="1696268624552"/>
<node TEXT="Experience in working across functions both within P&amp;S and outside of P&amp;S." ID="ID_628469891" CREATED="1696268624553" MODIFIED="1696268624553"/>
<node TEXT="Independent and entrepreneurial mindset, ability to set a clear vision, End-to-End thinker and at each moment understand the impact of a decision on the ultimate customer satisfaction." ID="ID_1169523396" CREATED="1696268624553" MODIFIED="1696268624553"/>
<node TEXT="Skill to analyze &amp; understand the financial impact and take ownership of processes." ID="ID_1774171077" CREATED="1696268624553" MODIFIED="1696268624553"/>
<node TEXT="Strong communication, presentation and collaboration skills" ID="ID_1222920639" CREATED="1696268624553" MODIFIED="1696268624553"/>
<node TEXT="Cross cultural awareness and ability to work in diverse teams" ID="ID_149121799" CREATED="1696268624553" MODIFIED="1696268624553"/>
<node TEXT="Strong drive to successfully complete projects" ID="ID_671330427" CREATED="1696268624555" MODIFIED="1696268624555"/>
<node TEXT="Thorough understanding of experimental design, field trial execution and statistical analysis." ID="ID_581591546" CREATED="1696268624555" MODIFIED="1696268624555"/>
<node TEXT="Cross functional and multi-cultural project management aptitude." ID="ID_1943535092" CREATED="1696268624555" MODIFIED="1696268624555"/>
<node TEXT="Ability to work with Global network and Production group." ID="ID_1961076137" CREATED="1696268624556" MODIFIED="1696268624556"/>
</node>
<node TEXT="Preferred Requirements" FOLDED="true" ID="ID_1654072894" CREATED="1696268624556" MODIFIED="1696268624556">
<node TEXT="A passion and enthusiasm for digital technology and creating value through data." ID="ID_177047993" CREATED="1696268624556" MODIFIED="1696268624556"/>
<node TEXT="Expertise in team and project management and leadership." ID="ID_1033816180" CREATED="1696268624557" MODIFIED="1696268624557"/>
<node TEXT="Statistical, data visualization and presentation expertise, database management." ID="ID_1444032397" CREATED="1696268624557" MODIFIED="1696268624557"/>
<node TEXT="Financial knowledge &amp; data analytics" ID="ID_1819451231" CREATED="1696268624558" MODIFIED="1696268624558"/>
<node TEXT="Global mindset and experience working in a multi-cultural international     environment" ID="ID_389563051" CREATED="1696268624558" MODIFIED="1696268624558"/>
<node TEXT="Good understanding of seed quality and factors that affect quality" ID="ID_1738366578" CREATED="1696268624558" MODIFIED="1696268624558"/>
<node TEXT="Being Bilingual would-be a plus" ID="ID_318908004" CREATED="1696268624559" MODIFIED="1696268624559"/>
<node TEXT="Additional Information" ID="ID_1473978572" CREATED="1696268624559" MODIFIED="1696268624559"/>
<node TEXT="Full Benefit Package (Medical, Dental &amp; Vision) that starts the same day you do" ID="ID_1127635561" CREATED="1696268624560" MODIFIED="1696268624560"/>
<node TEXT="401k plan with company match, Profit Sharing &amp; Retirement Savings Contribution" ID="ID_718596364" CREATED="1696268624560" MODIFIED="1696268624560"/>
<node TEXT="Paid Vacation, 9 Paid Holidays, Maternity and Paternity Leave, Education Assistance, Wellness Programs, Corporate Discounts among others" ID="ID_811896466" CREATED="1696268624560" MODIFIED="1696268624560"/>
<node TEXT="A culture that promotes work/life balance, celebrates diversity, and offers numerous family-oriented events throughout the year" ID="ID_372539128" CREATED="1696268624561" MODIFIED="1696268624561"/>
</node>
<node TEXT="Work Level 4B" FOLDED="true" ID="ID_1196475137" CREATED="1696268624562" MODIFIED="1696268624562">
<node TEXT="Salary Range $76,000-$95,000" ID="ID_927466497" CREATED="1696268624563" MODIFIED="1696268624563"/>
<node TEXT="Syngenta is an Equal Opportunity Employer and does not discriminate in recruitment, hiring, training, promotion or any other employment practices for reasons of race, color, religion, gender, national origin, age, sexual orientation, marital or veteran status, disability, or any other legally protected status." ID="ID_1613570011" CREATED="1696268624563" MODIFIED="1696268624563"/>
<node TEXT="Family and Medical Leave Act (FMLA) (http://www.dol.gov/whd/regs/compliance/posters/fmla.htm)" ID="ID_1601246024" CREATED="1696268624563" MODIFIED="1696268624563" LINK="http://www.dol.gov/whd/regs/compliance/posters/fmla.htm)"/>
<node TEXT="Equal Employment Opportunity Commission&apos;s (EEOC)(http://webapps.dol.gov/elaws/firststep/poster_direct.htm)" ID="ID_476913536" CREATED="1696268624565" MODIFIED="1696268624565" LINK="http://webapps.dol.gov/elaws/firststep/poster_direct.htm)"/>
<node TEXT="Employee Polygraph Protection Act (EPPA)(http://www.dol.gov/whd/regs/compliance/posters/eppa.htm)" ID="ID_1789291906" CREATED="1696268624568" MODIFIED="1696268624568" LINK="http://www.dol.gov/whd/regs/compliance/posters/eppa.htm)"/>
</node>
<node TEXT="#LI-ES1" ID="ID_603757327" CREATED="1696268624568" MODIFIED="1696268624568"/>
<node TEXT="Location" ID="ID_306843239" CREATED="1696268624569" MODIFIED="1696268624569"/>
<node TEXT="Salinas, CA, USA" ID="ID_1200098331" CREATED="1696268624569" MODIFIED="1696268624569"/>
<node TEXT="Hiring manager" ID="ID_127548635" CREATED="1696268624570" MODIFIED="1696268624570"/>
<node TEXT="Dan Brian" ID="ID_1758525979" CREATED="1696268624570" MODIFIED="1696268624570"/>
<node TEXT="Recruiter" ID="ID_799506147" CREATED="1696268624570" MODIFIED="1696268624570"/>
<node TEXT="Elyse Schubiner" ID="ID_823353306" CREATED="1696268624571" MODIFIED="1696268624571"/>
</node>
<node TEXT="breeding" FOLDED="true" ID="ID_1289694857" CREATED="1626926932381" MODIFIED="1626926949638">
<node TEXT="5/17 applied" ID="ID_1406580970" CREATED="1626926951396" MODIFIED="1626926957596"/>
<node TEXT="hired November" ID="ID_893190188" CREATED="1626926959029" MODIFIED="1626926993024"/>
</node>
<node TEXT="previous" FOLDED="true" ID="ID_1816343271" CREATED="1703701243610" MODIFIED="1703701245888">
<node TEXT="HSE Lead" FOLDED="true" ID="ID_1178123185" CREATED="1681532197118" MODIFIED="1681532204202">
<node TEXT="reference" FOLDED="true" ID="ID_1909908525" CREATED="1681532839652" MODIFIED="1681532842771">
<node ID="ID_1372896446" CREATED="1681532844418" MODIFIED="1681532844418" LINK="https://en.wikipedia.org/wiki/Environment,_health_and_safety"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://en.wikipedia.org/wiki/Environment,_health_and_safety">Environment, health and safety - Wikipedia</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="OSHA" FOLDED="true" ID="ID_967526779" CREATED="1682476939291" MODIFIED="1682476942256">
<node TEXT="Training" FOLDED="true" ID="ID_257954342" CREATED="1682477874939" MODIFIED="1682477878535">
<node TEXT="ref" FOLDED="true" ID="ID_1572062708" CREATED="1682477879043" MODIFIED="1682889560392">
<node ID="ID_323737081" CREATED="1682478032479" MODIFIED="1682478032479" LINK="https://www.osha.gov/training/outreach/training-providers"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osha.gov/training/outreach/training-providers">OSHA-Authorized Online Outreach Training Providers | Occupational Safety and Health Administration</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_85463814" CREATED="1682476943510" MODIFIED="1682476943510" LINK="https://www.osha.gov/sites/default/files/publications/osha2254.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osha.gov/sites/default/files/publications/osha2254.pdf">Training Requirements in OSHA Standards</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_792974695" CREATED="1682477369086" MODIFIED="1682477369086" LINK="https://www.osha.gov/agricultural-operations"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osha.gov/agricultural-operations">Agricultural Operations - Overview | Occupational Safety and Health Administration</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="OSHA 30 General Industry" FOLDED="true" ID="ID_1963763414" CREATED="1682477883691" MODIFIED="1682477891000">
<node ID="ID_142477974" CREATED="1682478256105" MODIFIED="1682478256105" LINK="https://www.360training.com/course/osha-30-hour-outreach-training-general-industry-free-study-guide"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.360training.com/course/osha-30-hour-outreach-training-general-industry-free-study-guide">OSHA 30-Hour General Industry Training Course Online</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="360" OBJECT="java.lang.Long|360" FOLDED="true" ID="ID_788300808" CREATED="1682481917715" MODIFIED="1682481920465">
<node ID="ID_1798506218" CREATED="1682773027521" MODIFIED="1682773027521" LINK="https://www.360training.com/student-login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.360training.com/student-login">Student Log-In | 360training.com</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="m.mcmillen" ID="ID_1074589510" CREATED="1682481921710" MODIFIED="1682481921710"/>
<node TEXT="RyXa6_Xh:cw_4WS" ID="ID_910268021" CREATED="1682481929148" MODIFIED="1682482232336"/>
<node TEXT="Qs" FOLDED="true" ID="ID_1988633968" CREATED="1682482233099" MODIFIED="1682482234001">
<node TEXT="maternal grandmother maiden name" FOLDED="true" ID="ID_205423870" CREATED="1682482234900" MODIFIED="1682482237977">
<node TEXT="Buyser" ID="ID_963411193" CREATED="1682482238724" MODIFIED="1682482241031"/>
</node>
<node TEXT="Town parents met" FOLDED="true" ID="ID_1981998745" CREATED="1682482244963" MODIFIED="1682482247576">
<node TEXT="Salinas" ID="ID_1547053845" CREATED="1682482248532" MODIFIED="1682482250386"/>
</node>
<node TEXT="Town of first job" FOLDED="true" ID="ID_1967624019" CREATED="1682482251660" MODIFIED="1682482257761">
<node TEXT="Gilroy" ID="ID_1063900201" CREATED="1682482258875" MODIFIED="1682482264880"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="skills" FOLDED="true" ID="ID_1003324541" CREATED="1681533158183" MODIFIED="1681533161808">
<node TEXT="Knowledge" ID="ID_1159787322" CREATED="1681533162603" MODIFIED="1681533169698"/>
<node TEXT="analytical skills" ID="ID_485318785" CREATED="1681533170354" MODIFIED="1681533174863"/>
<node TEXT="Problem-solving skills" ID="ID_591726081" CREATED="1681533175231" MODIFIED="1681533178673"/>
<node TEXT="Communication skills" ID="ID_518355562" CREATED="1681533182049" MODIFIED="1681533185690"/>
<node TEXT="Empathy" ID="ID_1429679281" CREATED="1681533194572" MODIFIED="1681533197295"/>
<node TEXT="Adaptability" ID="ID_990809568" CREATED="1681533218960" MODIFIED="1681533221495"/>
<node TEXT="Integrity" ID="ID_1303511388" CREATED="1681533239629" MODIFIED="1681533241922"/>
<node TEXT="Ability to lead" ID="ID_1021468874" CREATED="1681533248639" MODIFIED="1681533254451"/>
<node TEXT="Detail oriented" ID="ID_1779762940" CREATED="1681533268582" MODIFIED="1681533271528"/>
<node TEXT="Proactive" ID="ID_1496338888" CREATED="1681533283159" MODIFIED="1681533285786"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Supply Chain" FOLDED="true" ID="ID_1096518172" CREATED="1704313459190" MODIFIED="1704313463765">
<node ID="ID_842176959" CREATED="1704313470779" MODIFIED="1704313494562" LINK="https://www.viterra.us/what-we-do"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.viterra.us/what-we-do">Viterra What we do</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_595251915" CREATED="1704312148473" MODIFIED="1704312234227" LINK="https://recruiting.adp.com/srccar/public/RTI.home?c=1174715&amp;d=ExternalCareerSite%20%5brecruiting.adp.com%5d"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://recruiting.adp.com/srccar/public/RTI.home?c=1174715&amp;d=ExternalCareerSite%20%5brecruiting.adp.com%5d">Scoular Career Site - Supply Chain </a>
  </body>
</html>
</richcontent>
<node TEXT="Data" ID="ID_1340776388" CREATED="1704312161568" MODIFIED="1704312170106"/>
</node>
</node>
</node>
<node TEXT="Waterloo" FOLDED="true" ID="ID_831487678" CREATED="1704828312921" MODIFIED="1704828316532">
<node TEXT="Syngenta" FOLDED="true" ID="ID_470786098" CREATED="1704828926517" MODIFIED="1704828930950">
<node ID="ID_881798370" CREATED="1705020466553" MODIFIED="1705020466553" LINK="https://jobs.smartrecruiters.com/SyngentaGroup/743999940094514-production-technician"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://jobs.smartrecruiters.com/SyngentaGroup/743999940094514-production-technician">Syngenta Group Production Technician | SmartRecruiters</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="13m" ID="ID_1225029779" CREATED="1704828866530" MODIFIED="1704828870342"/>
</node>
</node>
<node TEXT="Fremont" FOLDED="true" ID="ID_1033889755" CREATED="1704828316962" MODIFIED="1704828319964">
<node TEXT="Syngenta 30m" ID="ID_494483413" CREATED="1704828836555" MODIFIED="1704828958961"/>
</node>
<node TEXT="Blair" FOLDED="true" ID="ID_1581519773" CREATED="1704838021718" MODIFIED="1704838027321">
<node ID="ID_670347349" CREATED="1704842150739" MODIFIED="1704842150739" LINK="https://careers.cargill.com/en/search-jobs/Blair%2C%20NE/23251/4/6252001-5073708-5081383-5064236/41x54444/-96x12502/50/2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careers.cargill.com/en/search-jobs/Blair%2C%20NE/23251/4/6252001-5073708-5081383-5064236/41x54444/-96x12502/50/2">Search our Job Opportunities at Cargill</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_170218869" CREATED="1704842019536" MODIFIED="1704842032260" LINK="https://novozymes.wd103.myworkdayjobs.com/Novozymes_Careers?locations=cf171b111ba1100782c8cacb0da80000"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://novozymes.wd103.myworkdayjobs.com/Novozymes_Careers?locations=cf171b111ba1100782c8cacb0da80000">novozymes Open positions</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="31m" ID="ID_336319619" CREATED="1704838028298" MODIFIED="1704838031930"/>
</node>
<node TEXT="Council Bluffs, IA" ID="ID_456514766" CREATED="1704843606489" MODIFIED="1704843618570"/>
<node TEXT="1H" FOLDED="true" ID="ID_639803871" CREATED="1705036957025" MODIFIED="1705036959386">
<node TEXT="Lincoln" FOLDED="true" ID="ID_1326257175" CREATED="1704311549384" MODIFIED="1704311555813">
<node TEXT="1h" ID="ID_422156800" CREATED="1704828964937" MODIFIED="1704828968751"/>
<node TEXT="Bayer Crop Science" FOLDED="true" ID="ID_1553147818" CREATED="1573835712488" MODIFIED="1573837631927">
<node TEXT="Seminis" ID="ID_1084217705" CREATED="1573837633223" MODIFIED="1573837648537"/>
</node>
</node>
<node TEXT="Syracuse" ID="ID_1679275015" CREATED="1705036961978" MODIFIED="1705036967412"/>
</node>
<node TEXT="Hastings" FOLDED="true" ID="ID_1069967202" CREATED="1704311823106" MODIFIED="1704311826242">
<node ID="ID_921999279" TREE_ID="ID_1553147818">
<node ID="ID_759469631" TREE_ID="ID_1084217705"/>
</node>
<node TEXT="Pioneer" ID="ID_992957358" CREATED="1704311831346" MODIFIED="1704311834601"/>
</node>
<node TEXT="Far" FOLDED="true" ID="ID_1559912643" CREATED="1705036876520" MODIFIED="1705036878875">
<node TEXT="seward 1h17m" ID="ID_1053974188" CREATED="1705037476945" MODIFIED="1705037491026"/>
<node TEXT="Kearney" ID="ID_28570678" CREATED="1705037435396" MODIFIED="1705037435396"/>
<node TEXT="Phillips" FOLDED="true" ID="ID_1313051824" CREATED="1704916207420" MODIFIED="1704916216415">
<node TEXT="2h18m" ID="ID_44601519" CREATED="1704916217811" MODIFIED="1704916224231"/>
</node>
<node TEXT="York" ID="ID_1466248486" CREATED="1705036881881" MODIFIED="1705036884459"/>
<node TEXT="Doniphan" ID="ID_495481155" CREATED="1705036892433" MODIFIED="1705036898283"/>
<node TEXT="Orchard" ID="ID_157253853" CREATED="1706592777168" MODIFIED="1706592779572"/>
<node TEXT="North Platte" ID="ID_1124548156" CREATED="1706593148700" MODIFIED="1706593153215"/>
</node>
<node ID="ID_1917733337" CREATED="1519773107436" MODIFIED="1519773107436" LINK="https://careers-agreliantgenetics.icims.com/jobs/intro"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://careers-agreliantgenetics.icims.com/jobs/intro">AgRelaint Genetics</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Des Moines" FOLDED="true" ID="ID_1738965801" CREATED="1704311633098" MODIFIED="1704311638147">
<node ID="ID_1688675035" TREE_ID="ID_1899923448">
<node ID="ID_1677256141" TREE_ID="ID_1628165661"/>
<node ID="ID_964395192" TREE_ID="ID_205615324"/>
<node ID="ID_1057993818" TREE_ID="ID_1937422913">
<node ID="ID_1511329367" TREE_ID="ID_1325986064">
<node ID="ID_1954559121" TREE_ID="ID_26887431">
<node ID="ID_549143181" TREE_ID="ID_1664727893"/>
<node ID="ID_995568595" TREE_ID="ID_972620460"/>
</node>
</node>
<node ID="ID_1622722121" TREE_ID="ID_127224172">
<node ID="ID_1674553685" TREE_ID="ID_1523701184"/>
<node ID="ID_460149284" TREE_ID="ID_209507219"/>
<node ID="ID_1805098759" TREE_ID="ID_1365708321"/>
</node>
<node ID="ID_1886869541" TREE_ID="ID_1190007583"/>
<node ID="ID_705515679" TREE_ID="ID_1935893873">
<node ID="ID_345862498" TREE_ID="ID_1795542624">
<node ID="ID_1468059302" TREE_ID="ID_277555966"/>
</node>
<node ID="ID_989990145" TREE_ID="ID_1706945757">
<node ID="ID_538585711" TREE_ID="ID_759200461">
<node ID="ID_1555043073" TREE_ID="ID_1309560441"/>
</node>
</node>
</node>
<node ID="ID_659477885" TREE_ID="ID_1711861714">
<node ID="ID_1234153214" TREE_ID="ID_1417345465">
<node ID="ID_156212984" TREE_ID="ID_1307490303"/>
<node ID="ID_1821210073" TREE_ID="ID_1042330744">
<node ID="ID_1909273450" TREE_ID="ID_301717333"/>
</node>
</node>
<node ID="ID_1139309803" TREE_ID="ID_978572704">
<node ID="ID_1868858426" TREE_ID="ID_1050507293"/>
</node>
<node ID="ID_420081942" TREE_ID="ID_568701260">
<node ID="ID_22230214" TREE_ID="ID_606971370"/>
<node ID="ID_257347284" TREE_ID="ID_987740645"/>
<node ID="ID_1264669772" TREE_ID="ID_1448900564">
<node ID="ID_1007867180" TREE_ID="ID_657704667"/>
<node ID="ID_169322884" TREE_ID="ID_453880589"/>
<node ID="ID_89252012" TREE_ID="ID_918160817"/>
<node ID="ID_150911345" TREE_ID="ID_748478936"/>
<node ID="ID_269611929" TREE_ID="ID_1767991287"/>
<node ID="ID_1278392455" TREE_ID="ID_446113771"/>
<node ID="ID_1517835679" TREE_ID="ID_589739255"/>
<node ID="ID_484647932" TREE_ID="ID_1437855442"/>
<node ID="ID_479113098" TREE_ID="ID_345581253"/>
<node ID="ID_1518043280" TREE_ID="ID_1500950447"/>
<node ID="ID_470179460" TREE_ID="ID_1074786515"/>
<node ID="ID_1670616288" TREE_ID="ID_1172400922"/>
</node>
</node>
<node ID="ID_1541682845" TREE_ID="ID_1840268492">
<node ID="ID_1861521122" TREE_ID="ID_625542160"/>
<node ID="ID_1988793710" TREE_ID="ID_1112972818"/>
<node ID="ID_1079133907" TREE_ID="ID_1353547010"/>
<node ID="ID_1254310849" TREE_ID="ID_1897190852"/>
<node ID="ID_1048241525" TREE_ID="ID_201198878"/>
<node ID="ID_544981090" TREE_ID="ID_1005898441"/>
<node ID="ID_1676050463" TREE_ID="ID_1599836522"/>
<node ID="ID_603582010" TREE_ID="ID_678308886"/>
<node ID="ID_44886738" TREE_ID="ID_286405699"/>
<node ID="ID_906153250" TREE_ID="ID_1087191282"/>
<node ID="ID_460551941" TREE_ID="ID_340816536"/>
<node ID="ID_14821057" TREE_ID="ID_334633248"/>
</node>
<node ID="ID_1689927057" TREE_ID="ID_1998122587">
<node ID="ID_737114152" TREE_ID="ID_751104444"/>
<node ID="ID_1404621518" TREE_ID="ID_1365078892"/>
<node ID="ID_1358931144" TREE_ID="ID_783356911"/>
<node ID="ID_1134757229" TREE_ID="ID_1882908402"/>
<node ID="ID_1803759790" TREE_ID="ID_45879493"/>
<node ID="ID_334885743" TREE_ID="ID_63843325"/>
<node ID="ID_1541416411" TREE_ID="ID_1420910503"/>
<node ID="ID_1677523969" TREE_ID="ID_1086984129"/>
<node ID="ID_111471594" TREE_ID="ID_992494591"/>
<node ID="ID_1439812056" TREE_ID="ID_628469891"/>
<node ID="ID_190644514" TREE_ID="ID_1169523396"/>
<node ID="ID_809371426" TREE_ID="ID_1774171077"/>
<node ID="ID_1967765848" TREE_ID="ID_1222920639"/>
<node ID="ID_175103704" TREE_ID="ID_149121799"/>
<node ID="ID_344525359" TREE_ID="ID_671330427"/>
<node ID="ID_1238771377" TREE_ID="ID_581591546"/>
<node ID="ID_1175917796" TREE_ID="ID_1943535092"/>
<node ID="ID_548264185" TREE_ID="ID_1961076137"/>
</node>
<node ID="ID_1662041589" TREE_ID="ID_1654072894">
<node ID="ID_1094946613" TREE_ID="ID_177047993"/>
<node ID="ID_1478184206" TREE_ID="ID_1033816180"/>
<node ID="ID_1283822692" TREE_ID="ID_1444032397"/>
<node ID="ID_479995438" TREE_ID="ID_1819451231"/>
<node ID="ID_1530689178" TREE_ID="ID_389563051"/>
<node ID="ID_1138111149" TREE_ID="ID_1738366578"/>
<node ID="ID_736419287" TREE_ID="ID_318908004"/>
<node ID="ID_399659824" TREE_ID="ID_1473978572"/>
<node ID="ID_995299551" TREE_ID="ID_1127635561"/>
<node ID="ID_1011533934" TREE_ID="ID_718596364"/>
<node ID="ID_1386421266" TREE_ID="ID_811896466"/>
<node ID="ID_860553689" TREE_ID="ID_372539128"/>
</node>
<node ID="ID_335039581" TREE_ID="ID_1196475137">
<node ID="ID_1276613561" TREE_ID="ID_927466497"/>
<node ID="ID_637498306" TREE_ID="ID_1613570011"/>
<node ID="ID_1838924252" TREE_ID="ID_1601246024"/>
<node ID="ID_1602754830" TREE_ID="ID_476913536"/>
<node ID="ID_1236703608" TREE_ID="ID_1789291906"/>
</node>
<node ID="ID_432061750" TREE_ID="ID_603757327"/>
<node ID="ID_1991009027" TREE_ID="ID_306843239"/>
<node ID="ID_1721179381" TREE_ID="ID_1200098331"/>
<node ID="ID_98300091" TREE_ID="ID_127548635"/>
<node ID="ID_1455038749" TREE_ID="ID_1758525979"/>
<node ID="ID_479080280" TREE_ID="ID_799506147"/>
<node ID="ID_941389310" TREE_ID="ID_823353306"/>
</node>
<node ID="ID_1236829289" TREE_ID="ID_1289694857">
<node ID="ID_1539819060" TREE_ID="ID_1406580970"/>
<node ID="ID_127354048" TREE_ID="ID_893190188"/>
</node>
<node ID="ID_544977278" TREE_ID="ID_1816343271">
<node ID="ID_718285240" TREE_ID="ID_1178123185">
<node ID="ID_1183485371" TREE_ID="ID_1909908525">
<node ID="ID_1268465584" TREE_ID="ID_1372896446"/>
<node ID="ID_881091000" TREE_ID="ID_967526779">
<node ID="ID_1471910443" TREE_ID="ID_257954342">
<node ID="ID_1068093523" TREE_ID="ID_1572062708">
<node ID="ID_1967449022" TREE_ID="ID_323737081"/>
<node ID="ID_1127479327" TREE_ID="ID_85463814"/>
<node ID="ID_1705086250" TREE_ID="ID_792974695"/>
</node>
<node ID="ID_779182650" TREE_ID="ID_1963763414">
<node ID="ID_765460757" TREE_ID="ID_142477974"/>
<node ID="ID_1280221908" TREE_ID="ID_788300808">
<node ID="ID_515961069" TREE_ID="ID_1798506218"/>
<node ID="ID_736833105" TREE_ID="ID_1074589510"/>
<node ID="ID_1451455417" TREE_ID="ID_910268021"/>
<node ID="ID_1638811580" TREE_ID="ID_1988633968">
<node ID="ID_1856168084" TREE_ID="ID_205423870">
<node ID="ID_1943222216" TREE_ID="ID_963411193"/>
</node>
<node ID="ID_1353487592" TREE_ID="ID_1981998745">
<node ID="ID_724031293" TREE_ID="ID_1547053845"/>
</node>
<node ID="ID_579477845" TREE_ID="ID_1967624019">
<node ID="ID_1084345448" TREE_ID="ID_1063900201"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1568481436" TREE_ID="ID_1003324541">
<node ID="ID_1886441622" TREE_ID="ID_1159787322"/>
<node ID="ID_1678594253" TREE_ID="ID_485318785"/>
<node ID="ID_999969148" TREE_ID="ID_591726081"/>
<node ID="ID_1964683565" TREE_ID="ID_518355562"/>
<node ID="ID_49443288" TREE_ID="ID_1429679281"/>
<node ID="ID_194309751" TREE_ID="ID_990809568"/>
<node ID="ID_1779021149" TREE_ID="ID_1303511388"/>
<node ID="ID_993989396" TREE_ID="ID_1021468874"/>
<node ID="ID_412462469" TREE_ID="ID_1779762940"/>
<node ID="ID_1145450393" TREE_ID="ID_1496338888"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Corteva" FOLDED="true" ID="ID_423669314" CREATED="1704310439052" MODIFIED="1704310442665">
<node ID="ID_1980694206" CREATED="1704310443580" MODIFIED="1704310443580" LINK="https://careers.corteva.com/job-search-results/?keyword=nebraska&amp;pg=2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careers.corteva.com/job-search-results/?keyword=nebraska&amp;pg=2">Job List | Corteva</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="by Field" ID="ID_186096555" CREATED="1698868050879" MODIFIED="1705262439334">
<node TEXT="Agriculture Research" FOLDED="true" ID="ID_1937201181" CREATED="1681161138435" MODIFIED="1703700189132">
<node TEXT="Seed Companies" FOLDED="true" ID="ID_1246692260" CREATED="1519773039798" MODIFIED="1519773112062">
<icon BUILTIN="password"/>
<node TEXT="blanket search" FOLDED="true" ID="ID_1208119481" CREATED="1620600229356" MODIFIED="1620600245409">
<node FOLDED="true" ID="ID_1316672462" CREATED="1519773107452" MODIFIED="1519773107452" LINK="https://www.agcareers.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.agcareers.com/">AgCareers.com - Agriculture Jobs &amp; Agriculture Careers</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_255658744" CREATED="1519773107452" MODIFIED="1519861998137"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      mcmillen.michael.s@gmail.com
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Lucydog1" ID="ID_1057910074" CREATED="1703701307731" MODIFIED="1703701311692"/>
</node>
<node ID="ID_1141626773" CREATED="1519773107436" MODIFIED="1519773107436" LINK="http://www.seedquest.com/jobs.php?from=&amp;type=job&amp;by=&amp;item_val=&amp;id_region=8&amp;type=job"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://www.seedquest.com/jobs.php?from=&amp;type=job&amp;by=&amp;item_val=&amp;id_region=8&amp;type=job">SeedQuest - Central information website for the global seed industry</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Syngenta" FOLDED="true" ID="ID_558565065" CREATED="1706652021984" MODIFIED="1706652075122">
<node ID="ID_956636870" CREATED="1706652104985" MODIFIED="1706652104985" LINK="https://www.smartr.me/home"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.smartr.me/home">Smartr</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_767830225" CREATED="1705020280949" MODIFIED="1705020280949" LINK="https://careers.smartrecruiters.com/SyngentaGroup"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careers.smartrecruiters.com/SyngentaGroup">Careers at Syngenta Group</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="HM.Clause" ID="ID_657547661" CREATED="1704326824027" MODIFIED="1704326832181"/>
<node TEXT="Limagrain" ID="ID_1934443685" CREATED="1704327337802" MODIFIED="1704327348931"/>
<node FOLDED="true" ID="ID_1672393640" CREATED="1519773107405" MODIFIED="1519773107405"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Koch
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1684610973" CREATED="1704310362366" MODIFIED="1704310362366" LINK="https://koch.avature.net/en_US/careers/SearchJobs/?731=%5B6058%5D&amp;731_format=6308&amp;listFilterMode=1&amp;jobRecordsPerPage=6&amp;"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://koch.avature.net/en_US/careers/SearchJobs/?731=%5B6058%5D&amp;731_format=6308&amp;listFilterMode=1&amp;jobRecordsPerPage=6&amp;">Job Search | Koch</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1671421722" CREATED="1519773107436" MODIFIED="1519773107436" LINK="http://www.kws.com/aw/Careers-kws/Jobs-at-KWS/Job-Portal/~fqnb"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://www.kws.com/aw/Careers-kws/Jobs-at-KWS/Job-Portal/~fqnb">KWS SAAT SE - Job Portal</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1500324365" CREATED="1519773107452" MODIFIED="1519773107452"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Vilmorin
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_68424639" CREATED="1519773107468" MODIFIED="1519773107468" LINK="https://limagrain-recrute.talent-soft.com/job/list-of-jobs.aspx?changefacet=1&amp;facet_JobRegion=1493&amp;facet_JobCountry=-1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://limagrain-recrute.talent-soft.com/job/list-of-jobs.aspx?changefacet=1&amp;facet_JobRegion=1493&amp;facet_JobCountry=-1">limagrain </a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1425105165" CREATED="1533060370368" MODIFIED="1533060388644" LINK="https://www.usajobs.gov/Search/?a=AG03"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="https://www.usajobs.gov/Search/?a=AG03">USDA ARS USAJOBS - Search</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_149870479" CREATED="1573835618470" MODIFIED="1573835618470" LINK="https://sakatavegetables.com/careers/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sakatavegetables.com/careers/">Careers &#8211; Sakata Wholesale Vegetable Seed</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Hollister" FOLDED="true" ID="ID_916605642" CREATED="1704322244517" MODIFIED="1704322253347">
<node ID="ID_475352691" CREATED="1573837184732" MODIFIED="1573837184732" LINK="https://www.enzazaden.com/careers-and-learning/search-vacancies?jobcountry=United+States"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.enzazaden.com/careers-and-learning/search-vacancies?jobcountry=United+States">Vacancies Enza Zaden</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1436383175" CREATED="1704323017189" MODIFIED="1704323017189" LINK="https://rawgarden.farm/careers/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://rawgarden.farm/careers/">Careers | Raw Garden™</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_302137073" CREATED="1573837377997" MODIFIED="1573837377997" LINK="http://unitedgenetics.com/careers/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://unitedgenetics.com/careers/">Careers | United Genetics USA</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1259248396" CREATED="1573837438949" MODIFIED="1573837438949" LINK="http://www.orsettiseeds.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.orsettiseeds.com/">Welcome to Orsetti Seeds</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Government Jobs" ID="ID_49408543" CREATED="1681160807835" MODIFIED="1703701211897" LINK="https://www.governmentjobs.com/careers/nebraska"/>
<node ID="ID_1820853220" CREATED="1681161118223" MODIFIED="1681161118223" LINK="https://your.omahachamber.org/directory/Search/agriculture-fishing-112899"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://your.omahachamber.org/directory/Search/agriculture-fishing-112899">Directory | Omaha Chamber Business Directory</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="IT" FOLDED="true" ID="ID_1073663248" CREATED="1681162458939" MODIFIED="1681162462028">
<node TEXT="Location" FOLDED="true" ID="ID_24673541" CREATED="1698868045170" MODIFIED="1698868047907">
<node TEXT="Omaha" FOLDED="true" ID="ID_509462422" CREATED="1698868057761" MODIFIED="1698868061056">
<node ID="ID_822269221" CREATED="1698868062090" MODIFIED="1698868062090" LINK="https://www.indeed.com/viewjob?jk=134802283541206c&amp;tk=1he66mn3tllrr800&amp;from=serp&amp;vjs=3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/viewjob?jk=134802283541206c&amp;tk=1he66mn3tllrr800&amp;from=serp&amp;vjs=3">Data Coordinator II, Clinical Research - Omaha, NE - Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Data" ID="ID_437769918" CREATED="1696271522239" MODIFIED="1696271523538">
<node TEXT="Data Modeler" FOLDED="true" ID="ID_427268446" CREATED="1714086894146" MODIFIED="1714086896751">
<node TEXT="Role: Data Modeler" FOLDED="true" ID="ID_1651304256" CREATED="1714086902453" MODIFIED="1714086902453">
<node TEXT="Location: Cary-NC" ID="ID_1563230653" CREATED="1714086902453" MODIFIED="1714086902453"/>
<node TEXT="Fulltime Role with TCS" ID="ID_1683529098" CREATED="1714086902455" MODIFIED="1714086902455"/>
<node TEXT="Under minimal supervision, analyze complex business requirements, translate them to data requirements and develop conceptual, logical and physical data models." ID="ID_919869631" CREATED="1714086902458" MODIFIED="1714086902458"/>
<node TEXT="Partner with development teams to ensure best design solutions for most efficient use of data." ID="ID_718549748" CREATED="1714086902458" MODIFIED="1714086902458"/>
<node TEXT="Manage plan, organize, and implement multiple and complex data and information design tasks." ID="ID_507656211" CREATED="1714086902460" MODIFIED="1714086902460"/>
<node TEXT="Help devise standards and processes, to adjust for rapidly changing technologies and environments." ID="ID_537052220" CREATED="1714086902460" MODIFIED="1714086902460"/>
<node TEXT="Skills List:" ID="ID_290971851" CREATED="1714086902461" MODIFIED="1714086902461"/>
<node TEXT="5-8 years’ work experience in database design, including at least 3 years’ experience as a Data Modeler." ID="ID_1219386050" CREATED="1714086902461" MODIFIED="1714086902461"/>
<node TEXT="EXPERT ERWin data modeling skills." ID="ID_356155306" CREATED="1714086902462" MODIFIED="1714086902462"/>
<node TEXT="Thorough mastery of logical and physical data modeling." ID="ID_1574427931" CREATED="1714086902463" MODIFIED="1714086902463"/>
<node TEXT="SQL DB technology in multiple platforms." ID="ID_821931344" CREATED="1714086902463" MODIFIED="1714086902463"/>
<node TEXT="Emerging No-SQL and Azure Cloud DB approaches and challenges – and how to model." ID="ID_994082026" CREATED="1714086902463" MODIFIED="1714086902463"/>
<node TEXT="Lead those that are not on our team to execute our standard Enterprise Data Modeling point-of-view." ID="ID_699452614" CREATED="1714086902464" MODIFIED="1714086902464"/>
<node TEXT="Very effective oral and written abilities." ID="ID_389467058" CREATED="1714086902465" MODIFIED="1714086902465"/>
<node TEXT="Excellent analytical and investigative ability." ID="ID_782030590" CREATED="1714086902465" MODIFIED="1714086902465"/>
<node TEXT="Job Type: Full-time" ID="ID_953507820" CREATED="1714086902466" MODIFIED="1714086902466"/>
<node TEXT="Pay: $98,416.63 - $110,523.25 per year" ID="ID_792723955" CREATED="1714086902466" MODIFIED="1714086902466"/>
</node>
</node>
<node ID="ID_184401246" CREATED="1703702239148" MODIFIED="1703702239148" LINK="https://www.agcareers.com/claas/data-analytics-intern-job-950339.cfm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.agcareers.com/claas/data-analytics-intern-job-950339.cfm">Data Analytics Intern Job Omaha NE | AgCareers.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_420656749" CREATED="1702061446601" MODIFIED="1702061446601" LINK="https://medium.com/@reachtoanamikasingh19/a-comprehensive-collection-of-data-analysis-cheat-sheets-for-2023-3e1f66a9a900"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/@reachtoanamikasingh19/a-comprehensive-collection-of-data-analysis-cheat-sheets-for-2023-3e1f66a9a900">A Comprehensive Collection of Data Analysis Cheat Sheets For 2023 | by Anamika Singh | Medium</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1438813813" CREATED="1696277868668" MODIFIED="1696277868668" LINK="https://www.agcareers.com/bayer/data-science-product-specialist-co-op-job-938232.cfm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.agcareers.com/bayer/data-science-product-specialist-co-op-job-938232.cfm">Data Science Product Specialist Co-op Job Residence Based CA | AgCareers.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Workflow Engineering" ID="ID_1764329860" CREATED="1696271523781" MODIFIED="1696271531545"/>
<node TEXT="Automation" ID="ID_1565478487" CREATED="1696271518913" MODIFIED="1696271521540"/>
<node ID="ID_763091526" CREATED="1681162463845" MODIFIED="1681162463845" LINK="https://recruiting2.ultipro.com/GAV1000GAVIL/JobBoard/43785dcd-0e9b-4e1d-bbc8-dbf38baa802b/?q=&amp;o=postedDateDesc&amp;f4=w6jxdCeUA12IriFwb6r0Qg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://recruiting2.ultipro.com/GAV1000GAVIL/JobBoard/43785dcd-0e9b-4e1d-bbc8-dbf38baa802b/?q=&amp;o=postedDateDesc&amp;f4=w6jxdCeUA12IriFwb6r0Qg">My Job Search</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Education" FOLDED="true" ID="ID_159422358" CREATED="1661710986151" MODIFIED="1661710993002">
<node FOLDED="true" ID="ID_589768200" CREATED="1661711018740" MODIFIED="1661711018740" LINK="https://www.edjoin.org/Home/Index"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edjoin.org/Home/Index">EDJOIN - The Nation's #1 Education Job Board</a>
  </body>
</html>
</richcontent>
<node TEXT="mmcmillen" ID="ID_1301227801" CREATED="1696444415528" MODIFIED="1696444417751"/>
<node TEXT="Lucydog1*" ID="ID_1526051276" CREATED="1696444409376" MODIFIED="1696444414455"/>
<node TEXT="Position" FOLDED="true" ID="ID_1071925066" CREATED="1696444849404" MODIFIED="1696444852536">
<node ID="ID_771842114" CREATED="1696444853793" MODIFIED="1696444853793" LINK="https://www.edjoin.org/Apps/Application3/32034456"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edjoin.org/Apps/Application3/32034456">My Employment</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Elkhorn" FOLDED="true" ID="ID_887111746" CREATED="1681144422350" MODIFIED="1681144424506">
<node ID="ID_648529349" CREATED="1704490920989" MODIFIED="1704490920989" LINK="https://jobs.boystown.org/location/nebraska-jobs/197/6252001-5073708/3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://jobs.boystown.org/location/nebraska-jobs/197/6252001-5073708/3">Search Nebraska Jobs at Boys Town</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="High Schools" FOLDED="true" ID="ID_1768895297" CREATED="1681361959474" MODIFIED="1681361965349">
<node TEXT="Credential" FOLDED="true" ID="ID_206665000" CREATED="1681364563968" MODIFIED="1681364570059">
<node ID="ID_410382155" CREATED="1681364891645" MODIFIED="1681364891645" LINK="https://www.education.ne.gov/tcert/teaching-certificates/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.education.ne.gov/tcert/teaching-certificates/">Teaching Certificates – Nebraska Department of Education</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Subject Matter" FOLDED="true" ID="ID_1198215486" CREATED="1681365207209" MODIFIED="1681365219461">
<node ID="ID_1951142374" CREATED="1681365220617" MODIFIED="1681365220617" LINK="https://www.ets.org/praxis/ne/epp/state-requirements/certification.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ets.org/praxis/ne/epp/state-requirements/certification.html">Certification</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Test 4/22" FOLDED="true" ID="ID_1491986345" CREATED="1681366007766" MODIFIED="1681366011763">
<node TEXT="results 5/5" ID="ID_1800151728" CREATED="1681366084702" MODIFIED="1681366093957"/>
</node>
<node TEXT="Biology" FOLDED="true" ID="ID_1931515550" CREATED="1681365528416" MODIFIED="1681365531253">
<node ID="ID_1420605814" CREATED="1681365532416" MODIFIED="1681365532416" LINK="https://www.ets.org/praxis/site/test-takers/resources/prep-materials.html?examId=5236"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ets.org/praxis/site/test-takers/resources/prep-materials.html?examId=5236">Praxis Test Prep Materials</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Types" FOLDED="true" ID="ID_1671767533" CREATED="1681364902442" MODIFIED="1681364905871">
<node FOLDED="true" ID="ID_61236015" CREATED="1681364571049" MODIFIED="1681364571049" LINK="https://www.education.ne.gov/tcert/teaching-certificates/teaching-alternative-permit/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.education.ne.gov/tcert/teaching-certificates/teaching-alternative-permit/">Teaching Program Alternative Permit – Nebraska Department of Education</a>
  </body>
</html>
</richcontent>
<node TEXT="The Alternative Program Teaching Permit is issued to applicants who do not meet all requirements for a regular teaching certificate and is valid for teaching only in the Nebraska school system requesting the issuance of such permit. An Alternative Program Teaching Permit expires August 31 in the second year following the year of issuance and may not be renewed." ID="ID_1206810683" CREATED="1681364653067" MODIFIED="1681364653067"/>
</node>
</node>
</node>
<node TEXT="Student Teaching" FOLDED="true" ID="ID_1378344761" CREATED="1681363841400" MODIFIED="1681363848620">
<node ID="ID_159122060" CREATED="1681364004048" MODIFIED="1681364004048" LINK="https://millard.tedk12.com/hire/ViewJob.aspx?JobID=7901"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://millard.tedk12.com/hire/ViewJob.aspx?JobID=7901">Millard Public Schools - Student Teaching/Clinical Practice Application Fall 2023</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Elkhorn" FOLDED="true" ID="ID_464934993" CREATED="1681361967700" MODIFIED="1681361985261">
<node FOLDED="true" ID="ID_1180017979" CREATED="1681362899643" MODIFIED="1681362899643" LINK="https://elkhorn.tedk12.com/hire/index.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://elkhorn.tedk12.com/hire/index.aspx">Elkhorn Public Schools - TalentEd Hire</a>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_982607829" CREATED="1681363133008" MODIFIED="1681363133008" LINK="https://elkhorn.tedk12.com/hire/ViewJob.aspx?JobID=1303"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://elkhorn.tedk12.com/hire/ViewJob.aspx?JobID=1303">Elkhorn Public Schools - 2022-2023 Middle School/High School Teacher Assistant</a>
  </body>
</html>
</richcontent>
<node TEXT="applications open Thursday April 14" ID="ID_9307938" CREATED="1681363173528" MODIFIED="1681363186629"/>
</node>
</node>
</node>
<node TEXT="nearby by distance" FOLDED="true" ID="ID_648598" CREATED="1681361985781" MODIFIED="1681361999233">
<node FOLDED="true" ID="ID_1180598560" CREATED="1681362012651" MODIFIED="1681362012651" LINK="https://www.concordiaomaha.org/index.php/about/job-openings"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.concordiaomaha.org/index.php/about/job-openings">concordiaomaha.org - Job Openings</a>
  </body>
</html>
</richcontent>
<node TEXT="3.2 mi, 9min" ID="ID_199137667" CREATED="1681362107402" MODIFIED="1681362119548"/>
<node TEXT="no openings as of 4/12" ID="ID_1110751219" CREATED="1681362641432" MODIFIED="1681362652049"/>
</node>
<node FOLDED="true" ID="ID_1940179379" CREATED="1681362171894" MODIFIED="1681362171894" LINK="https://millard.tedk12.com/hire/index.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://millard.tedk12.com/hire/index.aspx">Millard Public Schools - TalentEd Hire</a>
  </body>
</html>
</richcontent>
<node TEXT="reference" FOLDED="true" ID="ID_321012639" CREATED="1681363336782" MODIFIED="1681363342013">
<node ID="ID_1482483173" CREATED="1681363342821" MODIFIED="1681363342821" LINK="https://www.mpsomaha.org/schools"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mpsomaha.org/schools">Schools | Millard Public Schools</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_154755328" CREATED="1681362654476" MODIFIED="1681362654476" LINK="https://millard.tedk12.com/hire/ViewJob.aspx?JobID=9025"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://millard.tedk12.com/hire/ViewJob.aspx?JobID=9025">Millard Public Schools - Family and Consumer Science/Health Teacher at Millard West High School</a>
  </body>
</html>
</richcontent>
<node TEXT="15 min, 6.7 mi" ID="ID_1754557096" CREATED="1681362736312" MODIFIED="1681362754380"/>
</node>
</node>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1075476005" CREATED="1681144666665" MODIFIED="1681144668868">
<node TEXT="Douglas County" FOLDED="true" ID="ID_374416898" CREATED="1681361591968" MODIFIED="1681361594633">
<node ID="ID_50335568" CREATED="1681361596052" MODIFIED="1681361596052" LINK="https://en.wikipedia.org/wiki/Douglas_County,_Nebraska#Education"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://en.wikipedia.org/wiki/Douglas_County,_Nebraska#Education">Douglas County, Nebraska - Wikipedia</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1804286664" CREATED="1681144669885" MODIFIED="1681144669885" LINK="https://www.elkhornweb.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.elkhornweb.org/">Elkhorn Public Schools | Proud to teach today for tomorrow</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_48120933" CREATED="1681145512133" MODIFIED="1681145512133" LINK="https://elkhorn.tedk12.com/hire/index.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://elkhorn.tedk12.com/hire/index.aspx">Elkhorn Public Schools - TalentEd Hire</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="part-time" FOLDED="true" ID="ID_260708227" CREATED="1681161504805" MODIFIED="1681161509446">
<node ID="ID_744914153" CREATED="1681161511294" MODIFIED="1681161511294" LINK="https://biggarden.org/employment"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://biggarden.org/employment">Employment — The Big Garden</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Substitute" FOLDED="true" ID="ID_141150464" CREATED="1681144724391" MODIFIED="1681144726780">
<node TEXT="continually accepting applications" ID="ID_95585246" CREATED="1681144727117" MODIFIED="1681144731054"/>
</node>
</node>
</node>
<node TEXT="Hollister" FOLDED="true" ID="ID_741170777" CREATED="1681144415540" MODIFIED="1681144418098">
<node ID="ID_448385456" CREATED="1661711018740" MODIFIED="1661711018740" LINK="https://www.edjoin.org/Home/Index"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edjoin.org/Home/Index">EDJOIN - The Nation's #1 Education Job Board</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="other fields, location " FOLDED="true" ID="ID_1446318861" CREATED="1705262446256" MODIFIED="1705262456077">
<node TEXT="Omaha" FOLDED="true" ID="ID_1707998795" CREATED="1705262457162" MODIFIED="1705262469963">
<node TEXT="Phibro" FOLDED="true" ID="ID_73209785" CREATED="1705262472183" MODIFIED="1705262472183">
<node TEXT="Animal Health Corporation" ID="ID_1708717526" CREATED="1705262472183" MODIFIED="1705262472183"/>
<node TEXT="Director" FOLDED="true" ID="ID_415909754" CREATED="1705262472185" MODIFIED="1705262472185">
<node TEXT="Mel&apos;s friend" ID="ID_531333572" CREATED="1705262478526" MODIFIED="1705262485097"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Add role node using template here (Role Node progresses through process)" FOLDED="true" ID="ID_17628342" CREATED="1708465470607" MODIFIED="1712606510687">
<icon BUILTIN="unchecked"/>
<node TEXT="role progresses through process of changing role" ID="ID_792918096" CREATED="1708465494515" MODIFIED="1708466616156"/>
<node TEXT="Data Stewardship Analyst {Template}" FOLDED="true" ID="ID_1840342050" CREATED="1706245947491" MODIFIED="1712606546497" LINK="https://www.smartr.me/application-ats/a9b00ebd-c125-467f-829b-e44efcf21f21">
<icon BUILTIN="bookmark"/>
<node TEXT="Role Description and Alignment" FOLDED="true" ID="ID_166710833" CREATED="1709223710044" MODIFIED="1712606392263" LINK="https://docs.google.com/spreadsheets/d/1r6Ymo-IRmscqOtlR4C50cytq2iOsNhlJQLXjl_R0jm0/edit?usp=sharing">
<node TEXT="determine role alignment, star role if meet &gt;=60% of the requirements" FOLDED="true" ID="ID_1342913417" CREATED="1705519586468" MODIFIED="1712606665509"/>
</node>
<node TEXT="(Job application folder)" ID="ID_1721239633" CREATED="1709229770002" MODIFIED="1712606471499" LINK="file:/M:/My%20Drive/My%20Google%20Docs/Career/Job%20Applications/Syngenta/Data%20Stewardship%20Analyst"/>
</node>
<node TEXT="previous" FOLDED="true" ID="ID_1768870925" CREATED="1712606292168" MODIFIED="1712606297312">
<node TEXT="Data Analyst - Seed Operations Development Program" FOLDED="true" ID="ID_375896639" CREATED="1708466502098" MODIFIED="1708466643783">
<font ITALIC="true"/>
<node TEXT="Description Corteva Agriscience has an exciting opportunity to join our organization as a Data Analyst as part of our Seed Operations Development Program supporting our Seed Production and Supply Chain Business." ID="ID_950532593" CREATED="1708466536325" MODIFIED="1708466536325"/>
<node TEXT="In this position you will be accountable to ensure the Global Seed Production &amp; Supply Chain data analytics structure is in place to provide stakeholders with consistent, accurate and timely data insights. This would include defining, maintaining, and executing standard operating procedures for data collection and reporting across the network, along with ensuring the most effective tools are deployed and maintained. This individual will also be responsible for designing and implementing data analytics models and publishing periodic reports, allowing stakeholders to interpret patterns and trends in complex data sets that result in actionable insights, ultimately driving process and productivity improvements.?" ID="ID_336497324" CREATED="1708466536325" MODIFIED="1708466536325"/>
<node TEXT="Responsibilities - How will you help us grow?" FOLDED="true" ID="ID_1450278177" CREATED="1708466536327" MODIFIED="1708466536327">
<node TEXT="Design and support the data analytics structure (framework/processes/tools) across NA Seed Production Supply Chain, with some collaboration globally?" ID="ID_1154617997" CREATED="1708466536327" MODIFIED="1708466536327"/>
<node TEXT="Standardize digital collection methods and reporting tools for PowerBI Interfacing" ID="ID_166151071" CREATED="1708466536328" MODIFIED="1708466536328"/>
<node TEXT="Reconcile and ensure accuracy across multiple data systems and environments" ID="ID_1201756215" CREATED="1708466536329" MODIFIED="1708466536329"/>
<node TEXT="Prepare reports for stakeholders, stating trends, patterns, and predictions using relevant data" ID="ID_1580668791" CREATED="1708466536329" MODIFIED="1708466536329"/>
<node TEXT="First level analysis and interpretation of metrics and KPIs, summarizing findings and highlighting improvement opportunities?" ID="ID_1798783889" CREATED="1708466536330" MODIFIED="1708466536330"/>
<node TEXT="Serve as change management lead for the implementation and support of newly created tools" ID="ID_1538171220" CREATED="1708466536330" MODIFIED="1708466536330"/>
<node TEXT="Serve as the primary interface with IT, and other departments, to support system selection, maintenance and outages" ID="ID_942159697" CREATED="1708466536331" MODIFIED="1708466536331"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_441806377" CREATED="1708466536332" MODIFIED="1708466536332">
<node TEXT="Bachelor&apos;s Degree in Information Systems, Computer Science, or adjacent discipline, advance degree is desirable." ID="ID_1671966992" CREATED="1708466536333" MODIFIED="1708466536333"/>
<node TEXT="Technical proficiency regarding database design development, data models, techniques for data mining, and segmentation" ID="ID_1623671726" CREATED="1708466536333" MODIFIED="1708466536333"/>
<node TEXT="Proficiency in statistics and statistical packages like Excel, SP SS, SAS to be used for data set analyzing?" ID="ID_1516384785" CREATED="1708466536334" MODIFIED="1708466536334"/>
<node TEXT="Knowledge of data visualization software like PowerBI, Tableau, etc." ID="ID_1777050236" CREATED="1708466536334" MODIFIED="1708466536334"/>
<node TEXT="Verbal and Written communication skills" ID="ID_1299204205" CREATED="1708466536335" MODIFIED="1708466536335"/>
<node TEXT="Accuracy and attention to detail" ID="ID_895304705" CREATED="1708466536336" MODIFIED="1708466536336"/>
</node>
<node TEXT="Benefits - How We&apos;ll Support You: * Numerous development opportunities offered to build your skills * Be part of a company with a higher purpose and contribute to making the world a better place * Health benefits for you and your family on your first day of employment * Four weeks of paid time off and two weeks of well-being pay per year, plus paid holidays * Excellent parental leave which includes a minimum of 16 weeks for mother and father * Future planning with our competitive retirement savings plan and tuition reimbursement program * Learn more about our total rewards package here - Corteva Benefits * Check out life at Corteva! www.linkedin.com/company/corteva/life" ID="ID_1466481835" CREATED="1708466536336" MODIFIED="1708466536336"/>
<node TEXT="Are you a good match? Apply today! We seek applicants from all backgrounds to ensure we get the best, most creative talent on our team." ID="ID_1938173847" CREATED="1708466536337" MODIFIED="1708466536337"/>
</node>
<node TEXT="Data Stewardship &amp; Governance Lead" FOLDED="true" ID="ID_674713253" CREATED="1708466126717" MODIFIED="1708466645198">
<font ITALIC="true"/>
<node TEXT="YOUR KEY TASKS AND RESPONSIBILITIES" ID="ID_1343595667" CREATED="1708466126717" MODIFIED="1708466126717"/>
<node TEXT="The primary responsibilities of this role, Data Stewardship and Governance Lead, are to:" ID="ID_1194084556" CREATED="1708466126718" MODIFIED="1708466126718"/>
<node TEXT="Establish the Plant Biotech data governance framework to manage data policies, standards, and practices to achieve the required level of consistency, quality, and protection of core data assets to meet overall business needs to achieve data democratization across the organization." ID="ID_1729956714" CREATED="1708466126718" MODIFIED="1708466126718"/>
<node TEXT="Establish best practices and create processes to ensure data accuracy and access controls to monitor adherence to standards." ID="ID_1291067791" CREATED="1708466126719" MODIFIED="1708466126719"/>
<node TEXT="Track &amp; report on KPIs based on defined metrics to measure the success of implementation and adoption." ID="ID_997435128" CREATED="1708466126720" MODIFIED="1708466126720"/>
<node TEXT="Lead the implementation and adoption of Plant Biotech’s data governance framework (meta data, master data, data business glossaries, and data quality) through modifications to the organization’s culture and behavior using best practices in the data pipeline and processes, work with stakeholders to resolve data issues" ID="ID_1511779099" CREATED="1708466126720" MODIFIED="1708466126720"/>
<node TEXT="Serve as the Plant Biotech rep (primary point of contact) on data governance committees and core teams to ensure Plant Biotech data governance needs and requirements are clearly defined, communicated, and well understood and considered in alignment, prioritization, and planning" ID="ID_1763095750" CREATED="1708466126721" MODIFIED="1708466126721"/>
<node TEXT="Partner with Plant Biotech’s data scientists, engineers and architects on the development and implementation of data governance standards in experiment designs, applications for data capture, data storage (i.e., data lakes, data warehouses), and analytical processes, including deep learning and machine learning efforts" FOLDED="true" ID="ID_1451047385" CREATED="1708466126722" MODIFIED="1708466126722">
<node TEXT="Work with data engineers and modelers to streamline the flow of data to stakeholders, which includes establishing streams to generate reports and visualizations and providing easy access to self-service tools to enable analytics and the discovery of new insights. Plant Biotech’s representation on the Velocity Q&amp;A steering team will work with stakeholders to define &quot;questions and answers&quot; for the organization" ID="ID_1646678678" CREATED="1708466126723" MODIFIED="1708466126723"/>
</node>
<node TEXT="WHO YOU ARE" ID="ID_1018968596" CREATED="1708466126723" MODIFIED="1708466126723"/>
<node TEXT="Your success will be driven by your demonstration of our LIFE (Leadership Integrity Flexibility Efficiency) values. More specifically related to this position, Bayer seeks an incumbent who possesses the following:" ID="ID_34046670" CREATED="1708466126724" MODIFIED="1708466126724"/>
<node TEXT="Required Qualifications:" ID="ID_264560728" CREATED="1708466126724" MODIFIED="1708466126724"/>
<node TEXT="Bachelor or Masters degree in Information Management, Computer Science, Data Engineering, or related field 5 years’ experience" ID="ID_1146237714" CREATED="1708466126725" MODIFIED="1708466126725"/>
<node TEXT="Preferred Qualifications:" ID="ID_1720886494" CREATED="1708466126725" MODIFIED="1708466126725"/>
<node TEXT="3 years’ experience with data governance management tools (i.e., Collibra, Informatica, Tibco EBX Reltio, etc.)" ID="ID_1921048275" CREATED="1708466126726" MODIFIED="1708466126726"/>
<node TEXT="2 years’ experience with master data management, data integration, metadata governance, data analysis, or data quality to support cross functional business teams" ID="ID_887684510" CREATED="1708466126727" MODIFIED="1708466126727"/>
<node TEXT="2 years data governance policy, strategy or operations experience" ID="ID_326035791" CREATED="1708466126727" MODIFIED="1708466126727"/>
<node TEXT="Excellent organizational, oral and written communication skills" ID="ID_850549779" CREATED="1708466126729" MODIFIED="1708466126729"/>
<node TEXT="Strong understanding of the data lifecycle and how data policy/standards contribute to the overall value of data assets" ID="ID_185915676" CREATED="1708466126729" MODIFIED="1708466126729"/>
<node TEXT="Demonstrated success developing and enacting complex strategies and initiatives to significantly drive R&amp;D or IT impact and value creation." ID="ID_292892275" CREATED="1708466126729" MODIFIED="1708466126729"/>
<node TEXT="Strong communication, critical thinking, and influencing skills." ID="ID_167836521" CREATED="1708466126730" MODIFIED="1708466126730"/>
<node TEXT="Strong stakeholder management and experience managing ambiguity." ID="ID_1537445963" CREATED="1708466126731" MODIFIED="1708466126731"/>
<node TEXT="Proven track record of successfully leading and developing skilled team members in a global environment." ID="ID_1577110755" CREATED="1708466126731" MODIFIED="1708466126731"/>
<node TEXT="Employees can expect to be paid a salary between $105,000 to $158,000. Additional compensation may include a bonus or commission (if relevant).  Additional benefits include health care, vision, dental, retirement, PTO, sick leave, etc..  This salary range is merely an estimate and may vary based on an applicant’s location, market data/ranges, an applicant’s skills and prior relevant experience, certain degrees and certifications, and other relevant factors." ID="ID_1642523945" CREATED="1708466126732" MODIFIED="1708466126732"/>
<node TEXT="This posting will be available for application until at least February 19, 2024" ID="ID_1328799757" CREATED="1708466126732" MODIFIED="1708466126732"/>
</node>
</node>
</node>
<node ID="ID_1835114808" CONTENT_ID="ID_1342913417">
<node TEXT="copy job description to spreadsheet, column C" ID="ID_1935947609" CREATED="1709220653637" MODIFIED="1709220709025"/>
<node TEXT="bold accountabilities and experience that you match currently (100% match)" ID="ID_429833585" CREATED="1705640554379" MODIFIED="1705640677037"/>
<node TEXT="underline accountabilities that you can perform (stretch)" ID="ID_456500741" CREATED="1705519633709" MODIFIED="1705519665885"/>
<node TEXT="add examples from experience or education to support, to the left of the job description" ID="ID_1608932288" CREATED="1709220671262" MODIFIED="1709220727265"/>
<node TEXT="Determine percentage match" ID="ID_1663785607" CREATED="1705519610236" MODIFIED="1705640726159"/>
<node TEXT="star role if you meet 60% of the requirements" FOLDED="true" ID="ID_44404007" CREATED="1712606566419" MODIFIED="1712606620155">
<node TEXT="reference" FOLDED="true" ID="ID_486844663" CREATED="1704521645226" MODIFIED="1704521647534">
<node TEXT="In general:" FOLDED="true" ID="ID_1244445807" CREATED="1704521891536" MODIFIED="1704521891536">
<node TEXT="Not getting responses is an issue with the resume" ID="ID_753207478" CREATED="1704521891536" MODIFIED="1704521891536"/>
<node TEXT="Not getting a technical interview is an issue with soft skills" ID="ID_1936057961" CREATED="1704521891537" MODIFIED="1704521891537"/>
<node TEXT="Not passing a technical interview is an issue with technical skills" ID="ID_490129806" CREATED="1704521891537" MODIFIED="1704521891537"/>
<node TEXT="Not landing a job is a coin flip." ID="ID_702637101" CREATED="1704521891538" MODIFIED="1704521891538"/>
<node TEXT="Since you sent out 700+ resumes and only got a couple of responses, it&apos;s clearly a resume issue." ID="ID_1720230139" CREATED="1704521891539" MODIFIED="1704521891539"/>
<node TEXT="From a quick look at the resume you posted, I would say you need to de-clutter it and personalize it to the position. For example If you are sending your resume to a front-end position, they care very little about your experience in C# or your SQL skills, these should be very low on the page if at all." ID="ID_494350059" CREATED="1704521891540" MODIFIED="1704521891540"/>
<node TEXT="Usually recruiters have some software to parse the resume for keywords, when you personalize your resume, try your best to use phrasing from the job posting, it&apos;s far less likely that your matching experience will go unnoticed that way." ID="ID_654581632" CREATED="1704521891541" MODIFIED="1704521891541"/>
<node TEXT="I also believe there is a percentage thing as well, if they look for a C# dev, and you mentioned 10 languages, it will be worse than saying &quot;C# experience with knowledge of several other frameworks&quot;." ID="ID_615793288" CREATED="1704521891543" MODIFIED="1704521891543"/>
<node TEXT="At the junior level companies are less likely to look for a &quot;Jack of all trades&quot;, and would prefer someone who has some basic knowledge in the technology they use and teach them the rest on the job. (A senior should have more vast experience as they will be designing the systems and making tech decisions)." ID="ID_1173117007" CREATED="1704521891545" MODIFIED="1704521891545"/>
</node>
<node ID="ID_1984680220" CREATED="1704521648594" MODIFIED="1704521648594" LINK="https://www.reddit.com/r/recruitinghell/comments/12bsr5x/true_confessions_of_and_advice_from_a_hiring/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/recruitinghell/comments/12bsr5x/true_confessions_of_and_advice_from_a_hiring/">True confessions of and advice from a hiring manager : r/recruitinghell</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Apply to open positions, DSA: 1/26" ID="ID_415350569" CREATED="1638472391565" MODIFIED="1706629623873">
<node TEXT="edit resume" ID="ID_774014172" CREATED="1627767130797" MODIFIED="1627767135588">
<node TEXT="open position" ID="ID_1215867417" CREATED="1705018602913" MODIFIED="1705018608588"/>
<node TEXT="open resume" FOLDED="true" ID="ID_1484383266" CREATED="1705018611817" MODIFIED="1705018614114">
<node TEXT="compare to listing" ID="ID_607405167" CREATED="1696315249959" MODIFIED="1696315255671"/>
</node>
<node TEXT="address" FOLDED="true" ID="ID_936444914" CREATED="1705701988083" MODIFIED="1705701989837">
<node ID="ID_1631973997" CREATED="1705701990994" MODIFIED="1705701990994" LINK="https://www.indeed.com/career-advice/resumes-cover-letters/should-you-put-your-address-on-your-resume"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/resumes-cover-letters/should-you-put-your-address-on-your-resume">Should You Put Your Address on Your Resume? | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="alignment resume with position" ID="ID_731477076" CREATED="1705018614584" MODIFIED="1705018620563"/>
<node TEXT="general guidelines" FOLDED="true" ID="ID_399808998" CREATED="1628133882358" MODIFIED="1628133885515">
<node ID="ID_191899510" CREATED="1641257638384" MODIFIED="1641257638384" LINK="https://www.jobscan.co/blog/what-corporate-recruiters-want/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.jobscan.co/blog/what-corporate-recruiters-want/">What Do Corporate Recruiters Look For? We Asked Them - Jobscan</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Summary" FOLDED="true" ID="ID_119454338" CREATED="1705620728905" MODIFIED="1705620732979">
<node TEXT="not always necessary" ID="ID_1386748717" CREATED="1705699620091" MODIFIED="1705699623742"/>
<node TEXT="quick snapshot of experience and skills" ID="ID_166872556" CREATED="1705699598563" MODIFIED="1705699619085"/>
<node TEXT="Data" FOLDED="true" ID="ID_1776625170" CREATED="1705620735483" MODIFIED="1705620742827">
<node TEXT="Assistant Breeding Project Lead with 14 years of seed development and data management experience. Seeking to apply trialing operations and data management skills to drive improvements in seed production. Can leverage technology to simplify project management and field operations, and to maximize data quality." ID="ID_122107095" CREATED="1705620735483" MODIFIED="1705620735483"/>
</node>
</node>
<node TEXT="experience" ID="ID_385296576" CREATED="1627767143773" MODIFIED="1627767148399">
<node TEXT="reference" FOLDED="true" ID="ID_1560749072" CREATED="1705699297883" MODIFIED="1705699303579">
<node TEXT="be concrete about both your responsibilities and accomplishments" ID="ID_1555146619" CREATED="1705699291820" MODIFIED="1705699656793"/>
<node TEXT="emphasize items that are relevant to the prospective employer." ID="ID_975813532" CREATED="1705699656794" MODIFIED="1705699662422"/>
<node TEXT="choose 4-8 bullet points per position" FOLDED="true" ID="ID_1247177626" CREATED="1705699260570" MODIFIED="1705699280150">
<node TEXT="15 total" ID="ID_271863689" CREATED="1705699391779" MODIFIED="1705699400269"/>
<node TEXT="no longer than two lines each" ID="ID_1566547038" CREATED="1705699349667" MODIFIED="1705699357469"/>
</node>
<node TEXT="put periods at the end if they are full sentences" ID="ID_1718404114" CREATED="1705701321123" MODIFIED="1705701327703"/>
<node TEXT="use action verbs" FOLDED="true" ID="ID_716325797" CREATED="1706239857574" MODIFIED="1706239862218">
<node TEXT="Avoid" FOLDED="true" ID="ID_1948548531" CREATED="1706239872318" MODIFIED="1706239875569">
<node TEXT="managed" ID="ID_1859240926" CREATED="1706239876270" MODIFIED="1706239883184"/>
<node TEXT="created" ID="ID_1351423562" CREATED="1706239883196" MODIFIED="1706239886396"/>
<node TEXT="helped" ID="ID_991885451" CREATED="1706239886412" MODIFIED="1706239891995"/>
<node TEXT="assisted" ID="ID_1278707431" CREATED="1706239892011" MODIFIED="1706239894385"/>
<node TEXT="supported" ID="ID_1827400823" CREATED="1706239894400" MODIFIED="1706239897210"/>
<node TEXT="facilitated" ID="ID_742275959" CREATED="1706239897222" MODIFIED="1706239900225"/>
</node>
<node ID="ID_1991710595" CREATED="1706239867890" MODIFIED="1706239867890" LINK="https://www.cnbc.com/2023/05/02/action-verbs-to-avoid-using-on-your-resume.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.cnbc.com/2023/05/02/action-verbs-to-avoid-using-on-your-resume.html">Action verbs to avoid using on your resume, according to experts</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Data Stewardship Analyst" ID="ID_924221406" CREATED="1715611952958" MODIFIED="1715611952959" LINK="DataStewardshipAnalyst.mm">
<edge DASH="SOLID"/>
</node>
<node TEXT="Science Teacher" ID="ID_404030685" CREATED="1714080771358" MODIFIED="1714080776197">
<node TEXT="San Benito High School District" ID="ID_732089887" CREATED="1714080794234" MODIFIED="1714080798074">
<node TEXT="1220 Monterey Street" ID="ID_250932356" CREATED="1714080829947" MODIFIED="1714080829947"/>
<node TEXT="Hollister, CA 95023" ID="ID_1865519752" CREATED="1714080829947" MODIFIED="1714080829947"/>
<node TEXT="831-637-5831" ID="ID_840251987" CREATED="1714080829948" MODIFIED="1714080829948"/>
<node TEXT="Supervisor" ID="ID_1474690860" CREATED="1714082954690" MODIFIED="1714082959902">
<node TEXT="Mason Taylor" ID="ID_842003029" CREATED="1714082984331" MODIFIED="1714082990541"/>
</node>
<node TEXT="Pay:" ID="ID_1359201381" CREATED="1714082979248" MODIFIED="1714082982297">
<node TEXT="67,116 /yr" ID="ID_1440549700" CREATED="1714083108909" MODIFIED="1714083140521">
<node ID="ID_169308018" CREATED="1714083652173" MODIFIED="1714083652173" LINK="https://www.sbhsd.org/content/uploads/23-24-Certificated-Teacher-Salary-Schedules-7-1.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sbhsd.org/content/uploads/23-24-Certificated-Teacher-Salary-Schedules-7-1.pdf">23-24-Certificated-Teacher-Salary-Schedules-7-1.pdf</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_959035910" CREATED="1714080841559" MODIFIED="1714080841559" LINK="https://www.sbhsd.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sbhsd.org/">Home - San Benito High School District</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Dates" ID="ID_1343723817" CREATED="1714080777097" MODIFIED="1714080786467">
<node TEXT="8/15/2022 - 12/22/23" ID="ID_554820846" CREATED="1714082002167" MODIFIED="1714082831708"/>
</node>
<node TEXT="Why left" ID="ID_257097892" CREATED="1715467994695" MODIFIED="1715467999470">
<node TEXT="" ID="ID_1911047296" CREATED="1715468000287" MODIFIED="1715468000287"/>
</node>
</node>
<node TEXT="Assistant Breeding Project Lead, Leafy Vegetables" FOLDED="true" ID="ID_1996327839" CREATED="1628134022733" MODIFIED="1628134042961">
<node TEXT="Employer" ID="ID_1994906207" CREATED="1714083337202" MODIFIED="1714083342735">
<node TEXT="Syngenta" ID="ID_241479338" CREATED="1714083342995" MODIFIED="1714083345530">
<node TEXT="8313180914" OBJECT="java.lang.Long|8313180914" ID="ID_394948865" CREATED="1714083668913" MODIFIED="1714083760507"/>
<node TEXT="Address" ID="ID_1578975479" CREATED="1714083620226" MODIFIED="1714083622926">
<node TEXT="590A Work St" ID="ID_384392405" CREATED="1714083630737" MODIFIED="1714083702922"/>
<node TEXT="Salinas, CA 93901" ID="ID_724363972" CREATED="1714083702923" MODIFIED="1714083702923"/>
</node>
<node TEXT="Supervisor" ID="ID_1000256773" CREATED="1714083360420" MODIFIED="1714083363355">
<node TEXT="Darryn Gibson" ID="ID_822803549" CREATED="1714083529763" MODIFIED="1714083538650"/>
</node>
</node>
</node>
<node TEXT="Dates" ID="ID_1319496976" CREATED="1714082839854" MODIFIED="1714082843149">
<node TEXT="Full-time" ID="ID_849605845" CREATED="1714083828687" MODIFIED="1714083831121">
<node TEXT="11/12/2018 - 08/15/2022" ID="ID_563700283" CREATED="1714082844489" MODIFIED="1714083874508"/>
</node>
<node TEXT="Part-time" ID="ID_1198438235" CREATED="1714083821315" MODIFIED="1714083824520">
<node TEXT="08/15/2022 - 12/31/2023" ID="ID_356993568" CREATED="1714083865301" MODIFIED="1714083887082"/>
</node>
</node>
<node TEXT="Work Level 3B" ID="ID_1795868697" CREATED="1628134044260" MODIFIED="1714080744195"/>
<node TEXT="Experience" FOLDED="true" ID="ID_384231982" CREATED="1705098374021" MODIFIED="1705098380644">
<node TEXT="Breeding" ID="ID_1776236142" CREATED="1705697715851" MODIFIED="1705697719387">
<node TEXT="Evaluated, selected and advanced product for Iceberg, Romaine, and Multileaf lettuce" FOLDED="true" ID="ID_1643663524" CREATED="1705697818817" MODIFIED="1705700453922">
<node TEXT="Co-Inventor of romaine lettuce variety LUKE (participated from crossing to final product)" ID="ID_722313696" CREATED="1705697818816" MODIFIED="1705697818816"/>
</node>
<node TEXT="Assisted in designing crosses, gene stacking, population development and maintenance breeding." ID="ID_757248261" CREATED="1705697818815" MODIFIED="1705697818815"/>
<node TEXT="Facilitated line development through pedigree, DH, SSD, and backcross methods by managing field and greenhouse operations" ID="ID_255841756" CREATED="1705697818814" MODIFIED="1705700267384"/>
<node TEXT="Assisted in the development and training set for Genomic Prediction (INSV in lettuce)." ID="ID_1386508279" CREATED="1705697818809" MODIFIED="1705938602016"/>
<node TEXT="" FOLDED="true" ID="ID_184812930" CREATED="1705938523220" MODIFIED="1705938523220">
<node ID="ID_1979918107" CREATED="1705938524672" MODIFIED="1705938524672"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      GWAS,
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Assisted and participated in utilizing GARF, following the Nagoya Protocol,  and ILP for germplasm acquisition and maintenance." ID="ID_496836146" CREATED="1705697818818" MODIFIED="1705697818818"/>
<node TEXT="in progress" FOLDED="true" ID="ID_110234009" CREATED="1705698423270" MODIFIED="1705698429454">
<node TEXT="Learned and understood the Genomic prediction models (RR-BLUP, GBLUP)" ID="ID_1078043674" CREATED="1705697818809" MODIFIED="1705697818809"/>
</node>
</node>
<node TEXT="Project Management" FOLDED="true" ID="ID_1443219999" CREATED="1705618721457" MODIFIED="1705622535612">
<node TEXT="Process Improvement" FOLDED="true" ID="ID_245770862" CREATED="1706724082486" MODIFIED="1706724086769">
<node TEXT="Always work off the manual" FOLDED="true" ID="ID_1173253585" CREATED="1706724087749" MODIFIED="1706724098079">
<node TEXT="when things go wrong or mistakes are made, added to the manual and then revise the process" ID="ID_1538454469" CREATED="1706724098455" MODIFIED="1706724117719"/>
<node TEXT="Why" FOLDED="true" ID="ID_1438864331" CREATED="1706724122062" MODIFIED="1706724123928">
<node TEXT="to ensure alignment with the rest of the organization" ID="ID_437132758" CREATED="1706724414454" MODIFIED="1706724422352"/>
<node TEXT="To ensure that the job is done right" FOLDED="true" ID="ID_450350370" CREATED="1706724387224" MODIFIED="1706724393824">
<node TEXT="confidence and experience leads to mistakes" FOLDED="true" ID="ID_1548336699" CREATED="1706724518071" MODIFIED="1706724542649">
<node TEXT="you don&apos;t stop to double check" ID="ID_1634445334" CREATED="1706724543726" MODIFIED="1706724558773"/>
</node>
</node>
<node TEXT="To alleviate mental stress and the feeling that you might be forgetting something" ID="ID_894329827" CREATED="1706724443687" MODIFIED="1706724466752"/>
<node TEXT="to change the process when opportunities for improvement or problems arise" ID="ID_509313629" CREATED="1706724394327" MODIFIED="1706724413480"/>
<node TEXT="I&apos;ve always had a drive to make things more efficient and easier for everyone. when I first started in my assistant lettuce breeding job, I changed the trail fulfillment process, having seed to be pulled in inventory order rather than the order that it was in the trial. Because I change the process without consulting with the breeders I was initially reprimanded by Hallie. Afterward, I looked through the manuals and noticed that the process had originally been written to pull seed in inventory order." ID="ID_418363543" CREATED="1706724124982" MODIFIED="1706724386048"/>
</node>
</node>
</node>
<node TEXT="Developed a project management system using an integration of Planner, Excel spreadsheets, and OneNote" ID="ID_188073257" CREATED="1705618648605" MODIFIED="1705622512430"/>
<node TEXT="Improved seed production protocols which increased seed quantity, germination rate, and reduced labor costs" ID="ID_1779880353" CREATED="1705618648605" MODIFIED="1705622505902"/>
</node>
<node TEXT="Team Management" FOLDED="true" ID="ID_930254466" CREATED="1705618863721" MODIFIED="1705622527845">
<node TEXT="Trained team members on how to use SPIRIT and MINT to complete trialing and shipping tasks" ID="ID_973577972" CREATED="1705620846875" MODIFIED="1705620846875"/>
<node TEXT="Fostered the development of Technician and contract workers by training and coaching" ID="ID_198839234" CREATED="1705618867889" MODIFIED="1705622203525"/>
</node>
<node TEXT="Data Management" FOLDED="true" ID="ID_93390550" CREATED="1705618889345" MODIFIED="1705622268292">
<node TEXT="Developed data collection system and database to streamline patent data collection, storage, and analysis" ID="ID_62995893" CREATED="1705618893026" MODIFIED="1705618988893"/>
</node>
<node TEXT="Data Collection Programming" FOLDED="true" ID="ID_204764725" CREATED="1705618876697" MODIFIED="1705622239364">
<node TEXT="Automated statistical analysis and results reporting for patent applications by developing R script" ID="ID_1701050676" CREATED="1705700809547" MODIFIED="1705700934430"/>
<node TEXT="Improved data collection speed and accuracy by developing speech recognition system using Python" ID="ID_1742987782" CREATED="1705619049297" MODIFIED="1705619123435"/>
<node TEXT="Developed digital phenotyping pipeline to extract lettuce head measurements from photos using ImageJ" ID="ID_542590548" CREATED="1705618648623" MODIFIED="1705622486429"/>
</node>
<node TEXT="Operations" FOLDED="true" ID="ID_1508812676" CREATED="1705622306338" MODIFIED="1705622309235">
<node TEXT="Reduced labor costs by getting the P4 Printer working and providing ongoing training and tech support to team members" ID="ID_1836068748" CREATED="1705622322162" MODIFIED="1705622463476"/>
</node>
</node>
<node TEXT="Accomplishments" FOLDED="true" ID="ID_1848492341" CREATED="1705421811169" MODIFIED="1714080947253">
<node TEXT="• Improved seed production protocols which increased seed quantity, germination rate, and reduced labor costs" ID="ID_1739865366" CREATED="1705421831681" MODIFIED="1705421831681"/>
<node TEXT="• Developed a project management system using an integration of Planner, Excel spreadsheets, and OneNote" ID="ID_1837863067" CREATED="1705421831681" MODIFIED="1705421831681"/>
<node TEXT="• Simplified statistical analysis by automating tests and results reporting for patent applications (R script)" ID="ID_1073248097" CREATED="1705421831685" MODIFIED="1705421831685"/>
<node TEXT="• Developed digital phenotyping pipeline to extract lettuce head measurements from photos" ID="ID_1963434770" CREATED="1705421831687" MODIFIED="1705421831687"/>
</node>
</node>
<node TEXT="Research Associate" ID="ID_165133276" CREATED="1705619708754" MODIFIED="1705619716781">
<node TEXT="Employer" ID="ID_467553582" CREATED="1714084281511" MODIFIED="1714084283583">
<node TEXT="Syngenta" ID="ID_1942702063" CREATED="1714084284462" MODIFIED="1714084292156"/>
</node>
<node TEXT="Dates: 10/12/2009 - 11/12/2018" ID="ID_331353687" CREATED="1714081004445" MODIFIED="1714084239452"/>
<node TEXT="Data" FOLDED="true" ID="ID_1285285783" CREATED="1705619776154" MODIFIED="1705619786155">
<node TEXT="Managed all SPIRIT and MINT activities for the trialing project, including trial mapping, data uploading, printing from Crystal Reports, and seed receiving" ID="ID_601519184" CREATED="1705621762409" MODIFIED="1705622157031"/>
<node TEXT="Regularly provided tech support to site employees, helping with SPIRIT, MINT, and other computer issues" ID="ID_1069277931" CREATED="1705620286394" MODIFIED="1705620492797"/>
<node TEXT="Analyzed yield data over time to develop soil variability map, which helped in trial placement " ID="ID_615781982" CREATED="1705619788546" MODIFIED="1705619981732"/>
</node>
<node TEXT="Accomplishments" FOLDED="true" ID="ID_1848174886" CREATED="1714080985140" MODIFIED="1714080988294">
<node TEXT="• Managed field operations for data collection and harvesting, driving quality improvements" ID="ID_6269244" CREATED="1705619719098" MODIFIED="1705619719098"/>
<node TEXT="• Provided direction and training for third-party personnel to ensure the safe completion of field operations" ID="ID_163081740" CREATED="1705619719098" MODIFIED="1705619719098"/>
<node TEXT="• Refined stand count protocol to reduce labor costs and improve data quality" ID="ID_102202233" CREATED="1705619719100" MODIFIED="1705619719100"/>
<node TEXT="• Managed seed receiving, conditioning, and trial packing for the trialing program in Slater, IA during winter" ID="ID_959460193" CREATED="1705619719101" MODIFIED="1705619719101"/>
<node TEXT="• Established and supported trait introgression nursery for research trial seed production" ID="ID_497896247" CREATED="1705619719102" MODIFIED="1705619719102"/>
</node>
</node>
</node>
<node TEXT="Tips" FOLDED="true" ID="ID_518407474" CREATED="1627276257784" MODIFIED="1627276259972">
<node TEXT="Be sure that buzzwords and keywords for your profession are used in your resume. Your resume should include the same keywords that appear in job descriptions to increase the chances of your resume matching available positions - and of you being selected for an interview." ID="ID_139223311" CREATED="1627276283509" MODIFIED="1627276283509"/>
</node>
<node TEXT="Format" FOLDED="true" ID="ID_1590345680" CREATED="1621109933099" MODIFIED="1621109938136">
<node ID="ID_1562350894" CREATED="1621109939399" MODIFIED="1621109939399" LINK="https://www.indeed.com/career-advice/resumes-cover-letters/resume-format-guide-with-examples"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/resumes-cover-letters/resume-format-guide-with-examples">2021’s Top Resume Formats: Tips and Examples of Three Common Resumes | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="tense" FOLDED="true" ID="ID_779234056" CREATED="1696315205230" MODIFIED="1696315207856">
<node ID="ID_698545635" CREATED="1696315209036" MODIFIED="1696315209036" LINK="https://resumeworded.com/resume-past-tense-or-present-tense-key-advice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://resumeworded.com/resume-past-tense-or-present-tense-key-advice">Resume Tenses: When to Use the Past Tense vs Present Tense</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="summary" FOLDED="true" ID="ID_660791142" CREATED="1648014555296" MODIFIED="1648014558535">
<node TEXT="reference" FOLDED="true" ID="ID_794509240" CREATED="1705020126349" MODIFIED="1705020128361">
<node ID="ID_932457738" CREATED="1705020129234" MODIFIED="1705020129234" LINK="https://www.themuse.com/advice/the-resume-summary-statement-when-you-need-one-and-how-to-do-it"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/the-resume-summary-statement-when-you-need-one-and-how-to-do-it">What to Know About a Resume Summary Statement | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="pool" FOLDED="true" ID="ID_1977146143" CREATED="1648014559874" MODIFIED="1648014574785">
<node TEXT="Diverse communication and instructional skills to help individuals effectively comprehend and retain presented material. Gifted ability at capturing and holding the listener’s attention while delivering the information via different mediums." ID="ID_604226824" CREATED="1648014576871" MODIFIED="1648014576871"/>
<node TEXT="Strength to create an environment where all students are allowed to learn by providing one-on-one support when needed to help them succeed." ID="ID_1351939137" CREATED="1648014576871" MODIFIED="1648014576871"/>
<node TEXT="Dedicated Trialing Professional with 11 years of experience delivering the highest quality data. Continually improving projects by developing people, technology, and ways of working." ID="ID_566379086" CREATED="1648014576875" MODIFIED="1648014576875"/>
</node>
</node>
<node TEXT="skills" FOLDED="true" ID="ID_864227959" CREATED="1647810200489" MODIFIED="1647810202359">
<node TEXT="Breeding Trial Management and Operations" FOLDED="true" ID="ID_1229127727" CREATED="1705701350891" MODIFIED="1705701359149">
<node TEXT="Field Production" ID="ID_59755962" CREATED="1705701511027" MODIFIED="1705701519429"/>
<node TEXT="Hybrid breeding" ID="ID_6835767" CREATED="1705706854668" MODIFIED="1705706864558"/>
<node TEXT="Conventional and molecular breeding" ID="ID_1175583196" CREATED="1705701374248" MODIFIED="1705701374248"/>
<node TEXT="Markers assisted breeding." ID="ID_1547477404" CREATED="1705701374248" MODIFIED="1705701374248"/>
<node TEXT="Genomic prediction training set development" ID="ID_1614262565" CREATED="1705701374250" MODIFIED="1705701374250"/>
<node TEXT="Genomic prediction model development" ID="ID_1092667611" CREATED="1705701374250" MODIFIED="1705701374250"/>
<node TEXT="Genome wide study model development" ID="ID_1542377865" CREATED="1705701374250" MODIFIED="1705701374250"/>
<node TEXT="Team management and training" ID="ID_1012055513" CREATED="1705701374251" MODIFIED="1705701374251"/>
<node TEXT="Protocol design and implementation" FOLDED="true" ID="ID_730964244" CREATED="1705701374251" MODIFIED="1705701374251">
<node TEXT="Developing high throughput phenotyping protocols" ID="ID_1024195719" CREATED="1705701374251" MODIFIED="1705701374251"/>
</node>
<node TEXT="Data collection, management, and analysis" ID="ID_470339480" CREATED="1705702232215" MODIFIED="1705702232215"/>
<node TEXT="Seed Production" FOLDED="true" ID="ID_544617078" CREATED="1705701496763" MODIFIED="1705701501277">
<node TEXT="Seed production: field and greenhouse" ID="ID_1228038344" CREATED="1705702232215" MODIFIED="1705702232215"/>
<node TEXT="Seed receiving and conditioning" ID="ID_1790668840" CREATED="1705701374252" MODIFIED="1705701475765"/>
</node>
<node TEXT="Crop production: irrigation, fertilization, pest control, equipment operation" ID="ID_952418275" CREATED="1705701374252" MODIFIED="1705702795053"/>
<node TEXT="Combine and Planter Operation" ID="ID_413246024" CREATED="1705701374253" MODIFIED="1705701374253"/>
<node TEXT="Regulatory Stewardship (GMO seed handling)" ID="ID_753272049" CREATED="1705701374253" MODIFIED="1705701374253"/>
</node>
<node TEXT="Computer And Data Management" FOLDED="true" ID="ID_1468563172" CREATED="1705701360227" MODIFIED="1705701364501">
<node TEXT="SPIRIT" ID="ID_345911949" CREATED="1705701391628" MODIFIED="1705701391628"/>
<node TEXT="MINT" ID="ID_1174093929" CREATED="1705701391628" MODIFIED="1705701391628"/>
<node TEXT="Programming Languages:" FOLDED="true" ID="ID_1160159813" CREATED="1705701391630" MODIFIED="1705701391630">
<node TEXT="- R" ID="ID_1053207847" CREATED="1705701391631" MODIFIED="1705701391631"/>
<node TEXT="- Python" ID="ID_1204197852" CREATED="1705701391631" MODIFIED="1705701391631"/>
<node TEXT="- SQL" ID="ID_598626087" CREATED="1705701391631" MODIFIED="1705701391631"/>
<node TEXT="- ImageJ Macro language (IJM)" ID="ID_369187599" CREATED="1705701391631" MODIFIED="1705701391631"/>
</node>
<node TEXT="Microsoft 365: Teams, Planner, Power BI, Excel, VBA" ID="ID_1932735021" CREATED="1705701391631" MODIFIED="1705701391631"/>
</node>
<node TEXT="instruction skills, supervisory abilities, communication and creativity." ID="ID_869991090" CREATED="1647810204179" MODIFIED="1647810204179"/>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_178246596" CREATED="1649304543314" MODIFIED="1649304546789">
<node ID="ID_1712451452" CREATED="1648420249305" MODIFIED="1648420249305" LINK="http://thebusyeducator.com/keywords-to-include-in-a-killer-teaching-resume/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://thebusyeducator.com/keywords-to-include-in-a-killer-teaching-resume/">thebusyeducator.com/keywords-to-include-in-a-killer-teaching-resume/</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1732951845" CREATED="1627767141569" MODIFIED="1627767141569" LINK="https://www.indeed.com/career-advice/resumes-cover-letters/steps-for-building-a-resume"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/resumes-cover-letters/steps-for-building-a-resume">10 Steps for Building a Resume | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="run resume through ATS tester" FOLDED="true" ID="ID_781151590" CREATED="1706293938806" MODIFIED="1706293954220">
<node ID="ID_95996438" CREATED="1706293955457" MODIFIED="1706293955457" LINK="https://app.jobscan.co/scan/29943842"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://app.jobscan.co/scan/29943842">Jobscan</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="REREAD Resume!" ID="ID_127200649" CREATED="1706244981586" MODIFIED="1706244990844"/>
<node TEXT="Get referral from current team member on Smart Recruiter" ID="ID_1931093682" CREATED="1704732494721" MODIFIED="1705018555646"/>
<node TEXT="Get hiring manager" FOLDED="true" ID="ID_552733285" CREATED="1667769660850" MODIFIED="1667769666966">
<node ID="ID_1081160357" CREATED="1667769668642" MODIFIED="1667769668642" LINK="https://wd3.myworkday.com/syngenta/d/home.htmld"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://wd3.myworkday.com/syngenta/d/home.htmld">Home - Workday</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="organization chart" ID="ID_1699704140" CREATED="1667769691985" MODIFIED="1667769694510"/>
<node ID="ID_1273156667" CREATED="1667770088801" MODIFIED="1667770088801" LINK="https://wd3.myworkday.com/syngenta/d/inst/15$395392/216$304.htmld"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://wd3.myworkday.com/syngenta/d/inst/15$395392/216$304.htmld">View Location - Workday</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Cover Letter" FOLDED="true" ID="ID_974502751" CREATED="1620704617841" MODIFIED="1620704622085">
<node TEXT="Guide" FOLDED="true" ID="ID_421942092" CREATED="1621116578364" MODIFIED="1621116582247">
<node TEXT="Purpose" FOLDED="true" ID="ID_335829874" CREATED="1620704730791" MODIFIED="1620704734312">
<node TEXT="the cover letter is a tool to help introduce yourself in a memorable, personal way during a job application" ID="ID_990443979" CREATED="1620704782358" MODIFIED="1620704797127"/>
</node>
<node TEXT="Answers" FOLDED="true" ID="ID_382370098" CREATED="1620705065642" MODIFIED="1620705075663">
<node TEXT="How a candidate’s work experience meets job requirements." ID="ID_337258862" CREATED="1620705077646" MODIFIED="1620705077646"/>
<node TEXT="How a candidate’s skills meet job requirements." ID="ID_192472139" CREATED="1620705077646" MODIFIED="1620705077646"/>
<node TEXT="Why a candidate wants to work at the organization." ID="ID_444520929" CREATED="1620705077702" MODIFIED="1620705077702"/>
</node>
</node>
<node TEXT="Addressing" FOLDED="true" ID="ID_391919786" CREATED="1706242837976" MODIFIED="1706242849444">
<node ID="ID_1711670609" CREATED="1706242861270" MODIFIED="1706242861270" LINK="https://www.indeed.com/career-advice/resumes-cover-letters/dear-hiring-manager-on-cover-letter"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/resumes-cover-letters/dear-hiring-manager-on-cover-letter">FAQ: Should You Use &quot;Dear Hiring Manager&quot; on a Cover Letter? | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Memorable introduction" FOLDED="true" ID="ID_1205069324" CREATED="1620704954412" MODIFIED="1620706874872">
<font BOLD="true"/>
<node TEXT="Answers" FOLDED="true" ID="ID_1365009212" CREATED="1647921045425" MODIFIED="1653623974414">
<node TEXT="Why do you want to be a high school biology teacher?" FOLDED="true" ID="ID_1717646886" CREATED="1647922796942" MODIFIED="1647922805643">
<node TEXT="" ID="ID_1957435747" CREATED="1647922906857" MODIFIED="1647922906865"/>
<node TEXT="Also called science teachers, biology teachers work in middle schools or high schools, helping students learn about the origin, distribution, structure, and function of all living organisms. They create engaging lessons in the various subfields of biology, like genetics and zoology, and also handle admin tasks and supervise experiments." ID="ID_1198882736" CREATED="1647922807791" MODIFIED="1647922899727"/>
</node>
<node TEXT="Why is this position right for me?" FOLDED="true" ID="ID_93548504" CREATED="1647921464244" MODIFIED="1647921472693">
<node TEXT="I&apos;ve always had a passion for science" ID="ID_346672370" CREATED="1647921479088" MODIFIED="1647921528461"/>
<node TEXT="Transformed my life" ID="ID_1085430212" CREATED="1647921528816" MODIFIED="1647921562646"/>
<node TEXT="cultivate this passion for science in others" ID="ID_469964239" CREATED="1647921564778" MODIFIED="1647921597168"/>
</node>
<node TEXT="Why do I want to work for this specific organization?" FOLDED="true" ID="ID_1157475497" CREATED="1647921472695" MODIFIED="1647921472698">
<node TEXT="contributing to the community I live in" ID="ID_1175512109" CREATED="1647921853869" MODIFIED="1647921901645"/>
</node>
</node>
<node TEXT="Your introduction should convey authenticity and enthusiasm, and highlight the qualifications that make you a great fit for the role." ID="ID_1099248985" CREATED="1620924386586" MODIFIED="1620924386586"/>
<node TEXT="address the Hiring manager" FOLDED="true" ID="ID_774844199" CREATED="1620924745162" MODIFIED="1620924765321">
<node ID="ID_110403607" CREATED="1620924752284" MODIFIED="1620924752284" LINK="https://www.themuse.com/advice/3-totally-appropriate-ways-to-findand-impressthe-hiring-manager"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/3-totally-appropriate-ways-to-findand-impressthe-hiring-manager">How to Find Out Who the Hiring Manager Is | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Hook" FOLDED="true" ID="ID_810349020" CREATED="1620937609066" MODIFIED="1620937611587">
<node TEXT="With 11+ years of experience trialing corn and supporting the lettuce breeding project will be a strong asset to your team." ID="ID_1606382203" CREATED="1620889810182" MODIFIED="1620948330993"/>
</node>
<node TEXT="intro, personality and warmth" FOLDED="true" ID="ID_668716795" CREATED="1621113175713" MODIFIED="1621224045549">
<node ID="ID_1713632926" CREATED="1621225931896" MODIFIED="1621225931896" LINK="https://careers.workopolis.com/advice/make-cover-letter-complement-resume/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careers.workopolis.com/advice/make-cover-letter-complement-resume/">How to make your cover letter complement your resume - Workopolis Blog</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Dear Hiring Manager" FOLDED="true" ID="ID_1195297575" CREATED="1706283426629" MODIFIED="1706283430791">
<node TEXT="My name is Michael McMillen, and I am interested in applying for the Data Stewardship Analyst with Syngenta. My in-depth knowledge of breeding, trialing operations, and data management make me confident in my ability to make positive contributions to your team. I love improving breeding programs to provide the best possible data, and seeing the positive impact that data has on the seed we provide to growers. This passion has guided me since I started my career in this company 14 years ago, and I&apos;m excited at the prospect of improving the accuracy and quality of germplasm identity data in this new role." ID="ID_923022577" CREATED="1706283431807" MODIFIED="1706284245601"/>
</node>
<node TEXT="Dear Seeds Production Research Team:" FOLDED="true" ID="ID_318565079" CREATED="1621113201480" MODIFIED="1621113201480">
<node TEXT="When I picture myself working across teams, leading and shaping the corn  inbred characterization program, it fills me with excitement and a sense of pride." FOLDED="true" ID="ID_1362899856" CREATED="1621221578181" MODIFIED="1621234833266">
<node TEXT="with that energy that you get only when you&apos;re fulfilling your potential." ID="ID_1998201194" CREATED="1621223451263" MODIFIED="1621223455847"/>
</node>
<node TEXT="I love cultivating trials and programs to provide the best possible data, and seeing the positive impact that data has on the seed we develop and produce. This passion has guided me since I started my career in this company 11 years ago." ID="ID_1614872650" CREATED="1621115155023" MODIFIED="1621236478939"/>
<node TEXT="The opportunity to help harmonize the needs of development and production as a member of your team, while furthering my own development, is too great to pass up." ID="ID_1090129495" CREATED="1621235269038" MODIFIED="1621236732075"/>
</node>
</node>
</node>
<node TEXT="Body" FOLDED="true" ID="ID_1063885993" CREATED="1628453484934" MODIFIED="1628453487253">
<font BOLD="true"/>
<node TEXT="Specific, organized examples of relevant work done and problems solved" FOLDED="true" ID="ID_1742107449" CREATED="1620704954412" MODIFIED="1620706980050">
<font BOLD="true"/>
<node TEXT="Project Management" FOLDED="true" ID="ID_1791568354" CREATED="1627279114975" MODIFIED="1627279134042">
<node TEXT="Giving team members the tools they need to do their job well, and making their job as easy as possible, whatever their role." ID="ID_208184461" CREATED="1621227709329" MODIFIED="1628455164063"/>
<node TEXT="Training and managing people" FOLDED="true" ID="ID_1917248028" CREATED="1627279143486" MODIFIED="1627279154721">
<node FOLDED="true" ID="ID_1499088203" CREATED="1628743760015" MODIFIED="1628745426495"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <i>e for developing their teams expertise and capabilities in agronomy and phenotyping, continuously expanding their skillsets, allowing them to grow within their career and increase their contribution to the Trialing function as well as the company as a whole..</i>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Constant in every role I take is the drive to continually develop my team." FOLDED="true" ID="ID_978552007" CREATED="1628743809155" MODIFIED="1628745666232">
<node TEXT="In my previous position as a Research Associate for Drought Corn, I gave our seasonal employees a solid understanding of the science and use of tools behind each phenotyping task. This helped them more easily acquire skills for other breeding teams on-site." ID="ID_1945288745" CREATED="1628747353424" MODIFIED="1628749512453"/>
<node TEXT="Currently as Assistant Breeding Project Lead for Leafy Vegetables, I&apos;m coaching our technician and training her to use Spiirit, which allows her to take more responsibility for trial fulfillment." ID="ID_214993510" CREATED="1628748431875" MODIFIED="1628749292701"/>
<node TEXT="through constant feedback, and a system approach to improvement" ID="ID_156432178" CREATED="1628744603614" MODIFIED="1628744879564"/>
<node TEXT="As new techniques and tools are developed, I strive to learn and apply" ID="ID_713460372" CREATED="1628744967166" MODIFIED="1628745044856"/>
<node ID="ID_1489630893" CREATED="1628747642612" MODIFIED="1628747642612" LINK="https://www.mindtools.com/pages/article/developing-your-team.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mindtools.com/pages/article/developing-your-team.htm">Developing Your Team - Team Managment Training From MindTools.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="by working together to improve processes and providing them with new skills and tools." ID="ID_1442821693" CREATED="1628745399543" MODIFIED="1628745399543"/>
</node>
</node>
</node>
<node TEXT="Science" FOLDED="true" ID="ID_1740306084" CREATED="1628743269387" MODIFIED="1628743273202">
<node TEXT="Constant in every role I take is the drive to improve data quality to better meet the needs of our stakeholders. For instance, in my first role trialing corn and soy under managed drought conditions, one of our greatest challenges to quality data was variation in soil water holding capacity. To address this, I mapped the soil variation effect based on yield data from multiple years. Using this map I excluded field regions and adjusted blocking in trials, which greatly improved the detection of genetic differences." ID="ID_538981739" CREATED="1628743275132" MODIFIED="1628743280016"/>
</node>
<node TEXT="continuous improvements and new innovations" FOLDED="true" ID="ID_337564295" CREATED="1628455578746" MODIFIED="1628455578746">
<node TEXT="" ID="ID_962551495" CREATED="1628455594831" MODIFIED="1628455594831"/>
</node>
<node TEXT="idea pool" FOLDED="true" ID="ID_1406144397" CREATED="1620705863944" MODIFIED="1621116293933">
<node TEXT="Constant in every role I take is the drive to improve data quality to better meet the needs of our stakeholders. For instance, in my first role trialing hybrid and inbred corn under managed drought conditions, one of our greatest challenges to quality data was variation in soil water holding capacity. To address this, I mapped the soil variation effect based on yield data from multiple years. Using this map I excluded field regions and adjusted block placement in trials, which improved the detection of genetic differences." ID="ID_1305784084" CREATED="1706285181385" MODIFIED="1706285181385"/>
<node TEXT="My career began with Syngenta in 2009, trialing hybrid and inbred corn as a Research Associate on the Managed Stress Environment Team." FOLDED="true" ID="ID_485997117" CREATED="1620886634753" MODIFIED="1621116299118">
<font BOLD="false"/>
<node TEXT="This role gave me a firm foundation in trial management and data collection. My role grew to encompass data management, analysis, and reporting after the project lead left our team. I also managed our flowering date prediction model, which helped ensure that the target stress levels for each trial were reached during flowering." ID="ID_239768965" CREATED="1620890476055" MODIFIED="1620941494586">
<font BOLD="false"/>
</node>
<node TEXT="During my time supporting MSE Corn, I  gained experience in seed production by working with Operations and the Corn TID Team to establish a trait introgression nursery at our site." ID="ID_1365774378" CREATED="1620888975921" MODIFIED="1620938807471"/>
<node TEXT="Our company does a great job at putting their values in action and cultivating growth. With the personal support of my team and financial support from the Educational Assistance Program, I obtained my Masters Degree in Plant Breeding from Iowa State University in 2017, and afterward advanced to fill the role of Assistant Breeding Project Lead for the Leafy Vegetable Team." ID="ID_519839683" CREATED="1620927938424" MODIFIED="1620938751152">
<font BOLD="false"/>
</node>
</node>
<node TEXT="My current role has helped me to further develop my project management, phenotyping, and data management skills, It has also given me experience in the full range of seed development activities including inventory management, advancement, seed production, market trialing, and patenting." ID="ID_1874498676" CREATED="1620891631046" MODIFIED="1620948438166"/>
<node TEXT="Regarding patenting, I was given ownership of Distinction, Uniformity, and Stability testing, establishing trials and providing analysis to support IP protection for all lettuce varieties sold in the US. Through collaboration with the IP Team, I am refining the trialing process, reducing the number of trials and shortening the timeline necessary to submit patent and PVP applications. I have also developed an R script to automate the statistical analysis and results reporting, which significantly reduces the work required for the application process." ID="ID_1346373440" CREATED="1620706399385" MODIFIED="1620939422963"/>
<node TEXT="Shift away from subjective assessments to quantitative data. Use this as an opportunity to develop my programming and data analysis skills, working with Pablo to further develop the script" FOLDED="true" ID="ID_1426382219" CREATED="1620706718090" MODIFIED="1620708254632">
<node TEXT="Developed digital phenotyping pipeline to extract measurements from photos taken during evaluation." ID="ID_426569709" CREATED="1620888497643" MODIFIED="1620888615841"/>
</node>
<node TEXT="" ID="ID_916953529" CREATED="1620939464334" MODIFIED="1620939464334"/>
</node>
<node TEXT="First Role" FOLDED="true" ID="ID_1662167567" CREATED="1621113201482" MODIFIED="1621115706292">
<node TEXT="Constant in any role I take is a drive to improve data quality to better meet the needs of our stakeholders. For instance," FOLDED="true" ID="ID_590948218" CREATED="1621240572389" MODIFIED="1621242642175">
<node TEXT="In my first role trialing hybrid and inbred corn under managed drought conditions, one of our greatest challenges to quality data was variation in soil water holding capacity. To address this, I mapped the soil variation effect using yield data over multiple years. Using this map, I excluded regions and adjusted blocking in trials accordingly, which significantly improved the detection of genetic differences." ID="ID_1013998877" CREATED="1621239813479" MODIFIED="1621240361957"/>
<node TEXT="In my current role as Assistant Project Lead for Leafy Breeding, there is a critical need for quantitative data to enable data driven decisions and support genomic selection. I applied my programming skills to develop and test a high-throughput phenotyping pipeline, which captured lettuce head measurements from photos." ID="ID_500872869" CREATED="1621241810604" MODIFIED="1621242721278"/>
<node TEXT="" ID="ID_1864386334" CREATED="1621241228315" MODIFIED="1621241228315"/>
</node>
<node TEXT="My first role was as a Research Associate, trialing hybrid and inbred corn under managed drought conditions." ID="ID_883909765" CREATED="1621115672093" MODIFIED="1621115922657"/>
<node TEXT="This refined my skills in trial management and data collection, and gave me ample experience in training staff and refining protocols" ID="ID_679231042" CREATED="1621115672112" MODIFIED="1621220883203">
<font ITALIC="true"/>
</node>
<node TEXT="Constant improvement" ID="ID_972425650" CREATED="1621220332483" MODIFIED="1621220343628"/>
<node TEXT="My skills in data management and analysis recognized, and I was given responsibility for analysis and reporting to stakeholders after the Scientist leading our team left." ID="ID_972317691" CREATED="1621115672121" MODIFIED="1621221161166"/>
</node>
<node TEXT="Education" FOLDED="true" ID="ID_514278710" CREATED="1621113201485" MODIFIED="1621115726127">
<node TEXT="I’m grateful that our company puts their values in action and cultivates growth" ID="ID_410724312" CREATED="1621115711483" MODIFIED="1621115711483"/>
<node TEXT="With the support of my team and the Educational Assistance Program, I obtained my Masters Degree in Plant Breeding from Iowa State University, and afterward advanced to fill the role of Assistant Breeding Project Lead for the Leafy Vegetable Team" ID="ID_1803786949" CREATED="1621115711489" MODIFIED="1621115711489"/>
</node>
<node TEXT="current role" FOLDED="true" ID="ID_1070917820" CREATED="1621219338219" MODIFIED="1621219358391">
<node TEXT="I believe in designing a management system that meets the needs of the people, rather than trying to conform people to the system" FOLDED="true" ID="ID_1011817907" CREATED="1621219361142" MODIFIED="1621219430089">
<node TEXT="I&apos;m always looking to improve processes and the management system to enhance safety, reduce the chance of errors, and simplify a process to require less time." FOLDED="true" ID="ID_956557241" CREATED="1621227148080" MODIFIED="1621243825595">
<node TEXT="When establishing corn trials, I merged the stand count and thinning process, shifting to using stakes with tags to track row counts. This improved data accuracy and significantly reduced labor costs." ID="ID_282520589" CREATED="1621219752312" MODIFIED="1621243052762"/>
<node TEXT="I also delayed barrenness counts, which improved safety, accuracy, and speed." ID="ID_1043296402" CREATED="1621220185454" MODIFIED="1621222776765"/>
<node TEXT="In lettuce, I implemented a task time logging system, which allowed us to project future labor needs and examine the demands of each project and process." FOLDED="true" ID="ID_79760409" CREATED="1621219432658" MODIFIED="1621243579549">
<node TEXT="I also shifted all procedure manuals to Onenote, which allows instant access from any device, along with a checklist to track progress. This simplifies training and gives both workers and managers confidence that procedures are being followed." ID="ID_1892295756" CREATED="1621219559108" MODIFIED="1621243503285"/>
</node>
</node>
</node>
</node>
<node TEXT="Concise conclusion with a call to action" FOLDED="true" ID="ID_1710864228" CREATED="1620704954414" MODIFIED="1620704954414">
<node TEXT="example" FOLDED="true" ID="ID_1877758655" CREATED="1621116517866" MODIFIED="1621116525890">
<node TEXT="With my experience and qualifications, I believe I can [value proposition for the company] by [specific action steps]." ID="ID_1987298694" CREATED="1620937897365" MODIFIED="1620937899778"/>
</node>
<node TEXT="I would love the opportunity to discuss your goals for the program, and how I can contribute to your success. Thank you very much for your time and I look forward to hearing from you soon." ID="ID_163028059" CREATED="1621113201491" MODIFIED="1621113201491"/>
</node>
<node TEXT="Sincerely," FOLDED="true" ID="ID_1448084370" CREATED="1621113201491" MODIFIED="1621113201491">
<node TEXT="Michael McMillen" ID="ID_1552986161" CREATED="1621113201494" MODIFIED="1621113201494"/>
</node>
</node>
</node>
<node TEXT="reference materials" FOLDED="true" ID="ID_586560961" CREATED="1620705976331" MODIFIED="1620705984104">
<node TEXT="company values" ID="ID_867689732" CREATED="1620705985333" MODIFIED="1620705989861"/>
<node TEXT="Job description" ID="ID_1136399875" CREATED="1620705993118" MODIFIED="1620705995909"/>
<node ID="ID_169092525" CREATED="1620937567006" MODIFIED="1620937567006" LINK="https://www.indeed.com/career-advice/resumes-cover-letters/winning-cover-letters"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/resumes-cover-letters/winning-cover-letters">How to Write a Winning Cover Letter (With Template and Example) | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1385718417" CREATED="1619540830259" MODIFIED="1619540830259" LINK="https://www.glassdoor.com/blog/guide/how-to-write-a-cover-letter/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.glassdoor.com/blog/guide/how-to-write-a-cover-letter/">How to Write A Cover Letter | Glassdoor</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1173365011" CREATED="1619480865281" MODIFIED="1619480865281" LINK="https://resumegenius.com/blog/cover-letter-help/how-to-end-a-cover-letter"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://resumegenius.com/blog/cover-letter-help/how-to-end-a-cover-letter">How to End a Cover Letter: 12+ Proven Strategies | Resume Genius</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_532905449" CREATED="1647920887287" MODIFIED="1647920891671">
<node ID="ID_1970834072" CREATED="1647836651357" MODIFIED="1647836651357" LINK="https://resumes-for-teachers.com/career-change/cover-letters-career-change/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://resumes-for-teachers.com/career-change/cover-letters-career-change/">Five Cover Letter Tips for Changing Careers to Teaching</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1517960592" CREATED="1647921129363" MODIFIED="1647921129363" LINK="https://www.engineering.cornell.edu/sites/default/files/departments/career%20services/Cover%20Letter%20Guide%20(accessible%20for%20website).pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.engineering.cornell.edu/sites/default/files/departments/career%20services/Cover%20Letter%20Guide%20(accessible%20for%20website).pdf">Cover Letter Examples</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Follow up on application, +5-10D. DSA: 2/2" FOLDED="true" ID="ID_81232916" CREATED="1706629296025" MODIFIED="1706629808083">
<node ID="ID_1316112597" CREATED="1706722141625" MODIFIED="1706722141625" LINK="https://www.indeed.com/career-advice/career-development/follow-up-emails-subject-line"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/career-development/follow-up-emails-subject-line">23 Examples of Follow-Up Email Subject Lines | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="When" FOLDED="true" ID="ID_293065163" CREATED="1706629527531" MODIFIED="1706629537152">
<node TEXT="5-7 business days" ID="ID_1668410605" CREATED="1706629559514" MODIFIED="1706629566146"/>
<node ID="ID_1553495477" CREATED="1706631023317" MODIFIED="1706631023317" LINK="https://www.jobscan.co/blog/how-to-follow-up-on-a-job-application/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.jobscan.co/blog/how-to-follow-up-on-a-job-application/">When, Why, and How to Follow Up on a Job Application - Jobscan</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_317531321" CREATED="1706629538003" MODIFIED="1706629538003" LINK="https://www.themuse.com/advice/heres-how-long-you-should-wait-to-follow-up-at-every-point-in-the-job-search"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/heres-how-long-you-should-wait-to-follow-up-at-every-point-in-the-job-search">When to Follow Up During a Job Search | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Recruiter Interview (phone screen)" FOLDED="true" ID="ID_455236418" CREATED="1705076530007" MODIFIED="1705076628873">
<node TEXT="replying to e-mail" FOLDED="true" ID="ID_547247746" CREATED="1705102443843" MODIFIED="1705102448422">
<node ID="ID_1240981369" CREATED="1705102449643" MODIFIED="1705102449643" LINK="https://www.themuse.com/advice/3-emails-recruiters-sendand-the-responses-they-actually-want"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/3-emails-recruiters-sendand-the-responses-they-actually-want">How to Respond to Recruiter Emails | The Muse</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Time zones" FOLDED="true" ID="ID_532758952" CREATED="1709145708052" MODIFIED="1709145710719">
<node ID="ID_164740985" CREATED="1709145711943" MODIFIED="1709145711943" LINK="https://www.timeanddate.com/worldclock/usa"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.timeanddate.com/worldclock/usa">Time in the United States</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Received" FOLDED="true" ID="ID_553111977" CREATED="1709145353531" MODIFIED="1709145357832">
<node TEXT="Dear Michael, good morning and hope you are well. Thank you for your interest in opportunities with Syngenta. If still open to new opportunities, I’d like to connect with you briefly regarding your abilities and goals for a next ideal step.&#xa;&#xa;Please advise the best phone number to reach you along with a couple of dates/windows of time for us to briefly connect for ~15-20 minutes.  If outside Eastern Time, please confirm your Time Zone and I’ll coordinate back on what works best.   (I’m based in Eastern Time Zone)" ID="ID_1088795860" CREATED="1709145333865" MODIFIED="1709145351944"/>
</node>
<node TEXT="Reply" FOLDED="true" ID="ID_1311024442" CREATED="1709144774603" MODIFIED="1709145368616">
<node TEXT="Hi Michael, Thanks for reaching out. Yes, I&apos;m still open to new opportunities and I&apos;d be happy to chat. The best number to reach me would is (831)524-8552. My time zone is Pacific Time. I&apos;m available to speak Thursday or Friday from 10:30-3:30 EST. Please let me know if you need anything in the meantime." ID="ID_1606698016" CREATED="1709145369969" MODIFIED="1709146476443"/>
<node TEXT="" ID="ID_1426326170" CREATED="1709146313005" MODIFIED="1709146313005"/>
</node>
</node>
<node TEXT="Purpose" FOLDED="true" ID="ID_42024190" CREATED="1709147995120" MODIFIED="1709147997184">
<node TEXT="gauges communication skills" ID="ID_1201036379" CREATED="1705076541743" MODIFIED="1705076547831"/>
<node TEXT="be enthusiastic" ID="ID_871992729" CREATED="1705076548758" MODIFIED="1705076558160"/>
<node TEXT="sell yourself" ID="ID_1595340262" CREATED="1705076599959" MODIFIED="1705076614570"/>
</node>
<node TEXT="Phone Screen" FOLDED="true" ID="ID_93911896" CREATED="1709148000669" MODIFIED="1709148013273">
<node TEXT="bring up application and resume" ID="ID_118564820" CREATED="1709148014060" MODIFIED="1709148256827"/>
</node>
</node>
<node TEXT="Send thank you email the same day" FOLDED="true" ID="ID_32093874" CREATED="1706629851082" MODIFIED="1709232111967">
<node ID="ID_1400056955" CREATED="1709230407989" MODIFIED="1709230407989" LINK="https://www.ashleystahl.com/thank-you-note-to-recruiter/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ashleystahl.com/thank-you-note-to-recruiter/">How to Write a Thank You Note To Recruiter - The RIGHT Way</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_460492045" CREATED="1709230112951" MODIFIED="1709230112951" LINK="https://www.themuse.com/advice/your-guide-to-when-to-follow-upand-when-to-sit-tight-and-be-patient"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/your-guide-to-when-to-follow-upand-when-to-sit-tight-and-be-patient">How to Follow Up During the Job Interview Process | The Muse</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="E-mail" FOLDED="true" ID="ID_1061992855" CREATED="1709230442859" MODIFIED="1709230445943">
<node TEXT="Hi Michael," ID="ID_232346414" CREATED="1709230445946" MODIFIED="1709230452654"/>
<node TEXT="Thanks for taking the time to call this morning." ID="ID_644281070" CREATED="1709230459967" MODIFIED="1709231088504"/>
<node TEXT="It was nice to hear about your experience in research and learn more about the Data Stewardship Analyst role." ID="ID_351327066" CREATED="1709231088981" MODIFIED="1709231443532"/>
<node TEXT="Feel free to call or email me as needed." ID="ID_1590560470" CREATED="1709230640842" MODIFIED="1709231577616"/>
<node TEXT="Kind Regards," ID="ID_217406434" CREATED="1709231497184" MODIFIED="1709231635550"/>
</node>
</node>
<node TEXT="Interview Request" FOLDED="true" ID="ID_1452402830" CREATED="1709251069925" MODIFIED="1709251078909">
<node TEXT="reference" FOLDED="true" ID="ID_1594546757" CREATED="1709252264816" MODIFIED="1709252266665">
<node ID="ID_920171131" CREATED="1709252268154" MODIFIED="1709252268154" LINK="https://www.zippia.com/advice/interview-request/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.zippia.com/advice/interview-request/">How To Respond To An Interview Request (With Examples) - Zippia</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Respond as quickly as possible" ID="ID_718748841" CREATED="1709252243372" MODIFIED="1709252248167"/>
<node TEXT="Hi Eleni," FOLDED="true" ID="ID_532818905" CREATED="1709251376414" MODIFIED="1709251412424">
<node TEXT="Thanks for inviting me to interview." ID="ID_1704412411" CREATED="1709251398089" MODIFIED="1709251849717"/>
<node TEXT="The March 7th @ 12:30-1:30pm EST or March 11th @ 12-1pm EST times would both work well for me." ID="ID_1880938252" CREATED="1709251504249" MODIFIED="1709251647938"/>
<node TEXT="I look forward to meeting you and learning more about the role!" ID="ID_1797713419" CREATED="1709251648881" MODIFIED="1709251944388"/>
</node>
</node>
<node TEXT="Prepare for Interview" FOLDED="true" ID="ID_259194502" CREATED="1682871769214" MODIFIED="1709662247985">
<node ID="ID_1230757448" CREATED="1712604666913" MODIFIED="1712604666913" LINK="https://grow.google/certificates/interview-warmup/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://grow.google/certificates/interview-warmup/">Interview Warmup - Grow with Google</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1430784146" CREATED="1710102330869" MODIFIED="1710102332712">
<node ID="ID_1639402753" CREATED="1620923966828" MODIFIED="1620923966828" LINK="https://www.fastcompany.com/40460751/im-a-hiring-manager-here-are-five-questions-i-always-ask-job-candidates"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.fastcompany.com/40460751/im-a-hiring-manager-here-are-five-questions-i-always-ask-job-candidates">I’m A Hiring Manager—Here Are Five Questions I Always Ask Job Candidat</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_787846462" CREATED="1592330614305" MODIFIED="1592330614305" LINK="https://www.thebalancecareers.com/strengths-and-weaknesses-interview-questions-2061221"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thebalancecareers.com/strengths-and-weaknesses-interview-questions-2061221">How to Answer &#8220;What Are Your Strengths and Weaknesses?&quot;</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_664048017" CREATED="1704815862947" MODIFIED="1704815894534" LINK="https://www.mockquestions.com/search/Syngenta/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mockquestions.com/search/Syngenta/">MockQuestions Syngenta </a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="behavioral interview questions" FOLDED="true" ID="ID_739990262" CREATED="1710035627285" MODIFIED="1710035644469">
<node TEXT="main types" FOLDED="true" ID="ID_960652268" CREATED="1710036511574" MODIFIED="1710036513572">
<node TEXT="challenges and failures" ID="ID_1592505018" CREATED="1710035645235" MODIFIED="1710035648360"/>
<node TEXT="interpersonal dynamics" ID="ID_1494575503" CREATED="1710035648969" MODIFIED="1710035651960"/>
<node TEXT="success stories" ID="ID_1507329329" CREATED="1710035652391" MODIFIED="1710035654845"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1745275561" CREATED="1710036156636" MODIFIED="1710106598913">
<node TEXT="short" ID="ID_1090044676" CREATED="1710036300127" MODIFIED="1710036302239"/>
<node TEXT="summary sentence" FOLDED="true" ID="ID_363137310" CREATED="1710036277103" MODIFIED="1710036282374">
<node TEXT="I am a plant breeding professional" ID="ID_1432297433" CREATED="1710036160960" MODIFIED="1710036244965"/>
</node>
<node TEXT="highlights" FOLDED="true" ID="ID_1138810387" CREATED="1710036231740" MODIFIED="1710036338644">
<node TEXT="relevant to current role" ID="ID_1492988618" CREATED="1710036364699" MODIFIED="1710036373161"/>
<node TEXT="reverse chronological order" ID="ID_308553875" CREATED="1710036343850" MODIFIED="1710036347072"/>
</node>
<node TEXT="why this role" FOLDED="true" ID="ID_391660089" CREATED="1710036416464" MODIFIED="1710036419186">
<node TEXT="show your interest right away" ID="ID_163866890" CREATED="1710036483996" MODIFIED="1710036486995"/>
<node TEXT="conclude" ID="ID_758084746" CREATED="1710036421935" MODIFIED="1710036435085"/>
</node>
</node>
</node>
</node>
<node TEXT="develop story toolbox" FOLDED="true" ID="ID_1150998037" CREATED="1710035012907" MODIFIED="1710035093595">
<node TEXT="develop list of accomplishments and challenges" ID="ID_1374551660" CREATED="1710035348892" MODIFIED="1710035355877"/>
<node TEXT="create stories that capture each of those using one of these methods" FOLDED="true" ID="ID_1232469955" CREATED="1710035712178" MODIFIED="1710035738977">
<node TEXT="PAR method" FOLDED="true" ID="ID_731910677" CREATED="1710035686350" MODIFIED="1710035690034">
<node TEXT="problem" ID="ID_1176602428" CREATED="1710035690889" MODIFIED="1710035693076"/>
<node TEXT="action" ID="ID_1779576999" CREATED="1710035693439" MODIFIED="1710035695639"/>
<node TEXT="results" ID="ID_104681115" CREATED="1710035695650" MODIFIED="1710035697070"/>
</node>
<node TEXT="STAR method" FOLDED="true" ID="ID_1538371952" CREATED="1704815490564" MODIFIED="1704815496370">
<node TEXT="Situation: Set the scene and give the necessary details of your example." ID="ID_1313959370" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="Task: Describe what your responsibility was in that situation." ID="ID_1956198771" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="Action: Explain exactly what steps you took to address it." ID="ID_1071294400" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="Result: Share what outcomes your actions achieved." ID="ID_835596353" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="reference" FOLDED="true" ID="ID_1928925139" CREATED="1704815498181" MODIFIED="1704815500054">
<node ID="ID_1711714986" CREATED="1704815501836" MODIFIED="1704815501836" LINK="https://www.themuse.com/advice/star-interview-method"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/star-interview-method">How to Use the STAR Method to Ace Your Job Interview | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Review and update role alignment spreadsheet" FOLDED="true" ID="ID_794477900" CREATED="1709662298393" MODIFIED="1709662311220">
<node TEXT="add specific examples if needed" ID="ID_25444384" CREATED="1709662320002" MODIFIED="1709662333825"/>
</node>
<node TEXT="Review subject material" FOLDED="true" ID="ID_815772415" CREATED="1712605519319" MODIFIED="1712605523263">
<node TEXT="breeding" ID="ID_699734133" CREATED="1709671435778" MODIFIED="1709771583504" LINK="freeplane:/%20/M:/My%20Drive/My%20Google%20Docs/MindMaps/Leafy%20Breeding.mm#ID_659356658"/>
</node>
<node TEXT="Add to this list of questions to develop answers, with node for role if needed" FOLDED="true" ID="ID_1176001031" CREATED="1682871785634" MODIFIED="1712605065001">
<node TEXT="reference" FOLDED="true" ID="ID_1951671148" CREATED="1705178335025" MODIFIED="1705178339114">
<node TEXT="STAR method" FOLDED="true" ID="ID_648379875" CREATED="1704815490564" MODIFIED="1704815496370">
<node TEXT="Situation: Set the scene and give the necessary details of your example." ID="ID_854050245" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="Task: Describe what your responsibility was in that situation." ID="ID_1194616487" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="Action: Explain exactly what steps you took to address it." ID="ID_1336463960" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="Result: Share what outcomes your actions achieved." ID="ID_1343120197" CREATED="1704815719810" MODIFIED="1704815719810"/>
<node TEXT="reference" FOLDED="true" ID="ID_18622153" CREATED="1704815498181" MODIFIED="1704815500054">
<node ID="ID_1719198538" CREATED="1704815501836" MODIFIED="1704815501836" LINK="https://www.themuse.com/advice/star-interview-method"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/star-interview-method">How to Use the STAR Method to Ace Your Job Interview | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_1256961760" CREATED="1704815862947" MODIFIED="1704815894534" LINK="https://www.mockquestions.com/search/Syngenta/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mockquestions.com/search/Syngenta/">MockQuestions Syngenta </a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Tell me a little bit about yourself." FOLDED="true" ID="ID_1846890016" CREATED="1705176928660" MODIFIED="1705176935260">
<node TEXT="reference" FOLDED="true" ID="ID_1641573524" CREATED="1710036156636" MODIFIED="1710106598913">
<node TEXT="short" ID="ID_1180077819" CREATED="1710036300127" MODIFIED="1710036302239"/>
<node TEXT="summary sentence" FOLDED="true" ID="ID_1098526006" CREATED="1710036277103" MODIFIED="1710036282374">
<node TEXT="I am a plant breeding professional" ID="ID_1788226857" CREATED="1710036160960" MODIFIED="1710036244965"/>
</node>
<node TEXT="highlights" FOLDED="true" ID="ID_99575697" CREATED="1710036231740" MODIFIED="1710036338644">
<node TEXT="relevant to current role" ID="ID_1176680535" CREATED="1710036364699" MODIFIED="1710036373161"/>
<node TEXT="reverse chronological order" ID="ID_633524815" CREATED="1710036343850" MODIFIED="1710036347072"/>
</node>
<node TEXT="why this role" FOLDED="true" ID="ID_784448002" CREATED="1710036416464" MODIFIED="1710036419186">
<node TEXT="show your interest right away" ID="ID_1673018926" CREATED="1710036483996" MODIFIED="1710036486995"/>
<node TEXT="conclude" ID="ID_342278462" CREATED="1710036421935" MODIFIED="1710036435085"/>
</node>
</node>
<node TEXT="Worked in corn conducting yield trials and supporting seed production for the Corn R&amp;D" FOLDED="true" ID="ID_1212004348" CREATED="1705510968394" MODIFIED="1705511658896">
<node TEXT="started working in Syngenta the summer of 2009 is a field technician. That fall I moved into a research associate position with the drought field corn trialing program. Our team consisted of a Hanlin Du, a scientist who managed the operations in Gilroy, another research associate, Doug Foster, and myself. In 2011 the scientist moved on to a rice breeding company and Doug took responsibility for the project." FOLDED="true" ID="ID_54468793" CREATED="1710106683328" MODIFIED="1710107250518">
<node TEXT="while in my position with the corn team, I completed my Masters in Plant Breeding from Iowa State University in  2017." ID="ID_1998068001" CREATED="1710107293559" MODIFIED="1710107435915"/>
</node>
<node TEXT="Established greenhouse seed production nursery for R&amp;D seed" ID="ID_1402449798" CREATED="1705513955518" MODIFIED="1705513978513"/>
<node TEXT="Seed production in Kuai and PR" ID="ID_1856643940" CREATED="1705512702358" MODIFIED="1705512724242"/>
<node TEXT="Managed seed receiving, conditioning, and trial packing for the trialing program in Slater, IA during winter" ID="ID_1777820248" CREATED="1705512750582" MODIFIED="1705512750582"/>
</node>
<node TEXT="Advanced to the Breeding Project Assistant for Lettuce" FOLDED="true" ID="ID_241972235" CREATED="1705511586494" MODIFIED="1705512818561">
<node TEXT="Managed seed production for the US Lettuce program" FOLDED="true" ID="ID_734208364" CREATED="1705512819366" MODIFIED="1705512854256">
<node TEXT="Worked with Commercial" ID="ID_1677825731" CREATED="1705512856190" MODIFIED="1705512864248"/>
<node TEXT="Developed recieving system to proiritize seed cleaning" ID="ID_927940998" CREATED="1705512866670" MODIFIED="1705512897888"/>
</node>
<node TEXT="In 2018, I moved into the assistant breeding project lead role alongside Justin Goodwin, and supported the iceberg breeder, Hallie Dodson, and Mel Mekonnen, the Romaine breeder. " FOLDED="true" ID="ID_1216793010" CREATED="1710107439722" MODIFIED="1710107570250">
<node TEXT="In that role I made numerous improvements to operations that were needed because of downsizing and Justin moving on to another position." FOLDED="true" ID="ID_1006733782" CREATED="1710107571894" MODIFIED="1710107696978">
<node TEXT="Developed recieving system to proiritize seed cleaning" ID="ID_361321978" CREATED="1705512866670" MODIFIED="1705512897888"/>
</node>
</node>
</node>
<node TEXT="In the fall of 2022, I decided to pursue an opportunity in teaching science at my local high school," FOLDED="true" ID="ID_1119113489" CREATED="1710107729423" MODIFIED="1710108049133">
<node TEXT="I wanted to help my community and ideally students that didn&apos;t have the best support system." ID="ID_1737291162" CREATED="1710108053096" MODIFIED="1710108131209"/>
<node TEXT="While teaching, I supported the lettuce team with training the new assistant breeder, managing patent analysis, and providing tech support. " ID="ID_1083348771" CREATED="1710108049134" MODIFIED="1710108049136"/>
</node>
<node TEXT="at the end of 2023, I decided that teaching wasn&apos;t a good fit for me and begin improving my data analytics skill set." FOLDED="true" ID="ID_208631942" CREATED="1710107892109" MODIFIED="1710107957729">
<node TEXT="After the extra hours required for teaching and taking classes to get my credential, it was very difficult to give my wife and kids the time they needed." ID="ID_59576929" CREATED="1710108140698" MODIFIED="1710108308602"/>
<node TEXT="I enjoy developing processes and software to improve breeding programs" ID="ID_1924118266" CREATED="1710108260639" MODIFIED="1710108347482"/>
</node>
</node>
<node TEXT="What are your long-term career plans" FOLDED="true" ID="ID_544372561" CREATED="1705176623941" MODIFIED="1705176630901">
<node TEXT="data" FOLDED="true" ID="ID_543355466" CREATED="1712605117222" MODIFIED="1712605118671">
<node TEXT="move into data analytics, which better aligns with my skills and interests" FOLDED="true" ID="ID_1624146587" CREATED="1710108676536" MODIFIED="1710108703729">
<node TEXT="favorite part of working as an assistant breeding project lead was improving data management and helping with the adoption of new IT tools" ID="ID_283291955" CREATED="1709662714402" MODIFIED="1709662763394"/>
</node>
</node>
<node TEXT="lead" FOLDED="true" ID="ID_1008641599" CREATED="1712605121522" MODIFIED="1712605124156">
<node TEXT="move into a leadership role where I can have more of an impact" ID="ID_1030936681" CREATED="1705178743497" MODIFIED="1705511038804"/>
</node>
</node>
<node TEXT="why do you want to work in this position, what is it that particularly interests you" FOLDED="true" ID="ID_1444853492" CREATED="1682955555265" MODIFIED="1712604825074">
<node TEXT="I feel like it&apos;s the perfect intersection of my skills and interests" FOLDED="true" ID="ID_1993623906" CREATED="1709770774620" MODIFIED="1709770788964">
<node TEXT="I can use my plant breeding, operations, teaching, and tech experience to improve data stewardship" ID="ID_1235963376" CREATED="1709662768205" MODIFIED="1712605168307"/>
<node TEXT="Considering that I&apos;ve been with the company my whole career, I&apos;m emotionally invested in the success of Syngenta&apos;s breeding programs" ID="ID_1894930631" CREATED="1710108445591" MODIFIED="1710108506825"/>
</node>
<node TEXT="want to improve data management and operations surrounding data collection so that we can use the data for other purposes and breeders can spend less time and energy with managing data" ID="ID_1422783989" CREATED="1705178398346" MODIFIED="1709770772125"/>
</node>
<node TEXT="Why do you think you&apos;re qualified for this position?" FOLDED="true" ID="ID_72547419" CREATED="1705176790498" MODIFIED="1705176799923">
<node TEXT="Diverse set of skills in plant breeding, operations, and data analytics" ID="ID_445975843" CREATED="1709770795722" MODIFIED="1709770822320"/>
<node TEXT="great blend of technical skills and experience" FOLDED="true" ID="ID_1916013354" CREATED="1710034471499" MODIFIED="1710034478655">
<node TEXT="in addition to numerous years into seeds R&amp;D setting, I have a strong data management and tech skill set" ID="ID_452018835" CREATED="1709662911379" MODIFIED="1709663006595"/>
<node TEXT="also currently finishing up a data analytic certificate program which is helped improve my skills in SQL and R" ID="ID_265927845" CREATED="1710108529927" MODIFIED="1710108577705"/>
</node>
<node TEXT="enjoy building relationships and helping others" ID="ID_1817175283" CREATED="1710034479333" MODIFIED="1710034489465"/>
</node>
<node TEXT="What decisions did you routinely make in your last position?" FOLDED="true" ID="ID_1750197264" CREATED="1705176842541" MODIFIED="1705176849795">
<node TEXT="What materials from seed production to clean and register first" ID="ID_760123348" CREATED="1705512937070" MODIFIED="1705512957761"/>
<node TEXT="What locations to put patent trials in to" ID="ID_1481082562" CREATED="1705179727936" MODIFIED="1705179770910"/>
<node TEXT="When to schedule harvests of the seed production nursery" ID="ID_234487811" CREATED="1705188381980" MODIFIED="1705188397534"/>
<node TEXT="mapping trials to areas" FOLDED="true" ID="ID_737042757" CREATED="1705259074434" MODIFIED="1705259086335">
<node TEXT="Performed yield analysis to determine the best placement of trials based on past performance." ID="ID_639040057" CREATED="1705259585650" MODIFIED="1705259737292"/>
</node>
</node>
<node TEXT="What accomplishment you believe was the most difficult for you to achieve?" FOLDED="true" ID="ID_1436507512" CREATED="1705177155012" MODIFIED="1705177177173">
<node TEXT="changing sites right after loosing an assistant breeder while not letting anything fall through the cracks" ID="ID_1052103509" CREATED="1710108767729" MODIFIED="1710108827002"/>
<node TEXT="Manage seed production and receiving while moving sites and merging with another company" FOLDED="true" ID="ID_314392928" CREATED="1705510611861" MODIFIED="1705510658378">
<node TEXT="The site we were at was shut down and the entire operation was moved to a another site across town. At the same time Syngenta bought Progeny, and we were in the process of acquiring their germplasm and integrating it into spirit." ID="ID_446375900" CREATED="1705510691838" MODIFIED="1705510756935"/>
<node TEXT="I had to make sure that the seed cleaning equipment and infrastructure for registering was in place, as well as getting pedigree information from the acquisition and working alongside their existing operations." ID="ID_829509491" CREATED="1705510766086" MODIFIED="1705513645019"/>
<node TEXT="By working with the new site management,  we were able to move the equipment, get it set up , insecure labor for seed cleaning before the first harvest." ID="ID_1457473165" CREATED="1705513648038" MODIFIED="1705513748968"/>
</node>
<node TEXT="Data" FOLDED="true" ID="ID_617966861" CREATED="1705510903710" MODIFIED="1705510905688">
<node TEXT="the most difficult accomplishment for me to achieve was incorporating an aquired companies germplasm and trialing data into spirit. It took the combined efforts of the Breeder, a data specialist, our technician, and myself and number of hours on top of our regular responsibilities." ID="ID_1377080107" CREATED="1705177228495" MODIFIED="1705177542502"/>
</node>
</node>
<node TEXT="When have you faced an unexpected difficulty?" FOLDED="true" ID="ID_458457645" CREATED="1705177568588" MODIFIED="1705177596190">
<node TEXT="Reduced workforce for seed production" FOLDED="true" ID="ID_426802537" CREATED="1705177667972" MODIFIED="1705177686470">
<node TEXT="Our seed production nursery is located in Buttonwillow and as part of the commercial production nursery, so rely on shared labor during harvest. When I first started with the team, we were provided with as much labor as we needed to complete each harvest in one day, which was usually around twelve people. The sometimes created a conflict with the labor needs for the commercial production unit, so in more recent years we were only provided with 4 people per day for harvests. Because of this we had to change the way we scheduled harvests, with most harvest taking two days instead of one. " ID="ID_1616698490" CREATED="1705179173213" MODIFIED="1705513574948"/>
</node>
</node>
<node TEXT="How do you handle a larger than average workload?" FOLDED="true" ID="ID_1329124058" CREATED="1705176861782" MODIFIED="1705176868115">
<node TEXT="Stay organized and prioritize" ID="ID_1947974400" CREATED="1705178881888" MODIFIED="1705178890135"/>
<node TEXT="Use planner as a Kanban board" ID="ID_1733905102" CREATED="1705510467182" MODIFIED="1705510482840"/>
<node TEXT="Prioritize moving from one stage of the project to the next based on due date" ID="ID_1876417435" CREATED="1705510498902" MODIFIED="1705510547212"/>
<node TEXT="group tasks to take advantage of economies of scale" ID="ID_1379197837" CREATED="1705510551392" MODIFIED="1705510583807"/>
</node>
<node TEXT="How do you handle conflict in the work place?" FOLDED="true" ID="ID_1147213560" CREATED="1705176693078" MODIFIED="1705176701619">
<node TEXT="Try to first understand the other persons perspective" FOLDED="true" ID="ID_135014720" CREATED="1709663131985" MODIFIED="1709663162425">
<node TEXT="Sabino" ID="ID_209415624" CREATED="1705179571466" MODIFIED="1705179595594"/>
</node>
<node TEXT="Try to get to the heart of the issue." FOLDED="true" ID="ID_1861014475" CREATED="1705178895875" MODIFIED="1705178913561">
<node TEXT="Sabino" ID="ID_542546640" CREATED="1705179571466" MODIFIED="1705179595594"/>
</node>
</node>
<node TEXT="What work situations excite and motivate you?" FOLDED="true" ID="ID_244405851" CREATED="1705176732188" MODIFIED="1705176741099">
<node TEXT="opportunities to help improve breeding projects by finding new ways and improvements to procedures in order to capture better data" ID="ID_9904758" CREATED="1710034636726" MODIFIED="1710034685636"/>
<node TEXT="Opportunities to improve data management by automating reporting or simplifying ways of working" ID="ID_32321744" CREATED="1709663188396" MODIFIED="1709663232620"/>
<node TEXT="Managing complexity, projects with lots of moving parts." FOLDED="true" ID="ID_409963121" CREATED="1705178933277" MODIFIED="1705178953156">
<node TEXT="One of my may motivations for joining the lettuce breeding team was the fact that the team is responsible for many aspects of the breeding program such as seed production, inventory management, trialing, patenting. and nearly every aspect is occurring simultaneously.  Developing a system to manage that complexity was an ongoing project of mine, and the improvements in both the stress level of the team and execution continually motivated me to invest more into it." ID="ID_1105880323" CREATED="1705178954494" MODIFIED="1705179155665"/>
</node>
</node>
<node TEXT="Tell me about a contribution you made to the last team you worked on." FOLDED="true" ID="ID_1259658956" CREATED="1705177765227" MODIFIED="1705177785324">
<node TEXT="Patent data analysis script." FOLDED="true" ID="ID_1136494939" CREATED="1705177786514" MODIFIED="1705177817328">
<node TEXT="In order to patent a variety, the patent application has to be submitted with data showing that the variety is different from others on the market. My responsibility was to manage the trialing, data collection, an analysis for the late stage varieties. Gathering all of the data together and running the analysis initially took the combined efforts of both myself and a breeder, and it took at least two days to complete. In order to greatly simplify and reduce the time it took file a patent application, I developed a R script which generated the necessary data, ANOVA, and comparison tables in the format needed for the patent application. Now anybody on the team can quickly run the analysis to get the patent application done quickly." ID="ID_151142040" CREATED="1705177839480" MODIFIED="1705178232345"/>
</node>
<node TEXT="Seed production" FOLDED="true" ID="ID_286062430" CREATED="1705513048238" MODIFIED="1705513059640">
<node TEXT="One of the challenges with the year-round nature of the lettuce breeding program is that there is a very small window of time between seed production harvest and trial packing." ID="ID_1466627253" CREATED="1705513060910" MODIFIED="1705513134481"/>
<node TEXT="I was responsible for managing seed cleaning and registration." ID="ID_807458319" CREATED="1705513207718" MODIFIED="1705513240648"/>
<node TEXT="In order to ensure that seed belonging to the earliest nurseries was clean first, I developed a spreadsheet which flagged priority materials as soon as the technician scanned them in after harvest" ID="ID_1511139761" CREATED="1705513241350" MODIFIED="1705513322602"/>
<node TEXT="This ensured that seed destined for the earliest trials was registered and the weight was known so that the team could fulfill trials." ID="ID_1554461866" CREATED="1705513326238" MODIFIED="1705513422544"/>
</node>
</node>
<node TEXT="How do you define success?" FOLDED="true" ID="ID_1616408330" CREATED="1705176743535" MODIFIED="1705176749918">
<node TEXT="I define success as meeting all of one&apos;s goals 100%" ID="ID_681747510" CREATED="1709663253995" MODIFIED="1709663298413"/>
</node>
<node TEXT="When have used an inventive method to stretch company resources beyond the normal level?" FOLDED="true" ID="ID_680547838" CREATED="1705176750914" MODIFIED="1705176761176">
<node TEXT="Grouping trials" ID="ID_141015811" CREATED="1705511269622" MODIFIED="1705511280136"/>
</node>
<node TEXT="Tell me about a time when you took initiative to improve work-related procedures." FOLDED="true" ID="ID_1961031066" CREATED="1705176762924" MODIFIED="1705176774177">
<node TEXT="continually refine the trial fulfillment process" FOLDED="true" ID="ID_729290221" CREATED="1705511360310" MODIFIED="1709663359187">
<node TEXT="change the order of fulfillment to match the inventory order" ID="ID_1836413511" CREATED="1709663359191" MODIFIED="1709663379782"/>
<node TEXT="created a shared pull checklist" ID="ID_1087007760" CREATED="1709663379795" MODIFIED="1709663420029"/>
<node TEXT="brought the P4 printer online, developed envelope printing" ID="ID_446674118" CREATED="1709663422193" MODIFIED="1709663449010"/>
</node>
<node TEXT="Improved patent data collection" FOLDED="true" ID="ID_104884033" CREATED="1705511350998" MODIFIED="1709663500790">
<node TEXT="moved to digital collection" ID="ID_460592758" CREATED="1709663500793" MODIFIED="1709663520422"/>
<node TEXT="automated analysis and the development of the final document" ID="ID_722685614" CREATED="1709663522193" MODIFIED="1709663543615"/>
</node>
<node TEXT="Sort seed first" ID="ID_719270244" CREATED="1705511360310" MODIFIED="1705511380519"/>
<node TEXT="Sheller adjustment" ID="ID_707476237" CREATED="1705511350998" MODIFIED="1705511359408"/>
</node>
<node TEXT="Situation when you had incomplete information" FOLDED="true" ID="ID_1208878392" CREATED="1682959136407" MODIFIED="1682959154513">
<node TEXT="during field harvests, there are situations where plants lose their identification information" ID="ID_217562756" CREATED="1710034741254" MODIFIED="1710034787658"/>
</node>
</node>
<node TEXT="develop questions for them, write answers by Interviewer within question here" FOLDED="true" ID="ID_1224097403" CREATED="1682954457630" MODIFIED="1712606201138">
<icon BUILTIN="yes"/>
<node TEXT="reference" FOLDED="true" ID="ID_413277216" CREATED="1712284941257" MODIFIED="1712284942871">
<node ID="ID_1114726904" CREATED="1712285351273" MODIFIED="1712285351273" LINK="https://www.forbes.com/sites/forbescoachescouncil/2023/05/17/20-impressive-questions-to-ask-a-potential-employer-at-a-job-interview/?sh=790712f22103"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.forbes.com/sites/forbescoachescouncil/2023/05/17/20-impressive-questions-to-ask-a-potential-employer-at-a-job-interview/?sh=790712f22103">20 Impressive Questions To Ask A Potential Employer At A Job Interview</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1088565932" CREATED="1712284938946" MODIFIED="1712284938946" LINK="https://www.indeed.com/career-advice/interviewing/interview-questions-to-employers"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.indeed.com/career-advice/interviewing/interview-questions-to-employers">15 of the Best Questions To Ask Employers in a Job Interview | Indeed.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="by role" FOLDED="true" ID="ID_174988181" CREATED="1712285016497" MODIFIED="1712604935195">
<node ID="ID_1767366311" CREATED="1710102260656" MODIFIED="1710102260656" LINK="https://www.themuse.com/advice/5-questions-to-ask-when-youre-interviewing-for-a-tech-job"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/5-questions-to-ask-when-youre-interviewing-for-a-tech-job">5 Questions to Ask When You're Interviewing for a Tech Job | The Muse</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Data Stewardship Analyst" FOLDED="true" ID="ID_1783867853" CREATED="1709926471116" MODIFIED="1712604884173">
<node TEXT="What do you feel is the most challenging part of this role?" FOLDED="true" ID="ID_1106202514" CREATED="1712285252428" MODIFIED="1712285273785">
<font BOLD="true"/>
<node TEXT="Eleni" FOLDED="true" ID="ID_1268773792" CREATED="1712337987570" MODIFIED="1712337989704">
<node TEXT="ambiguity in data space, changes implemented not effectively, nned to implement quickly" FOLDED="true" ID="ID_338247636" CREATED="1712337991050" MODIFIED="1712338084936">
<node TEXT="mange frustraition from breeding teams" ID="ID_821551482" CREATED="1712338085722" MODIFIED="1712338095996"/>
<node TEXT="patience" ID="ID_1852634854" CREATED="1712338134805" MODIFIED="1712338154236"/>
</node>
<node TEXT="stakeholders are entire breeding team global" FOLDED="true" ID="ID_1696362035" CREATED="1712338315980" MODIFIED="1712338335487">
<node TEXT="train at scale" ID="ID_1172717791" CREATED="1712338336089" MODIFIED="1712338524454"/>
</node>
<node TEXT="leadership alignment" ID="ID_675934679" CREATED="1712338532387" MODIFIED="1712338548741"/>
<node TEXT="network proactively" ID="ID_28564832" CREATED="1712338564686" MODIFIED="1712338605246"/>
</node>
<node TEXT="Ryan" FOLDED="true" ID="ID_341852718" CREATED="1712338155807" MODIFIED="1712338158663">
<node TEXT="any role interacting with tool development" FOLDED="true" ID="ID_668258139" CREATED="1712338160292" MODIFIED="1712338182237">
<node TEXT="lots of differnce in working with tools" ID="ID_1468416329" CREATED="1712338182867" MODIFIED="1712338194355"/>
<node TEXT="taking the complexity, translating" FOLDED="true" ID="ID_1959774271" CREATED="1712338195395" MODIFIED="1712338211578">
<node TEXT="true blockers ahead of time" ID="ID_652857244" CREATED="1712338212552" MODIFIED="1712338238565"/>
<node TEXT="communicate true needs of veg ahead of time" ID="ID_1667778728" CREATED="1712338266159" MODIFIED="1712338294804"/>
<node TEXT="advocate for veg to tools teams" ID="ID_744659547" CREATED="1712338410099" MODIFIED="1712338423173"/>
</node>
</node>
</node>
<node TEXT="Much clearer understanding of the roles and current challenges" ID="ID_1862236318" CREATED="1712331718880" MODIFIED="1712331752816"/>
<node TEXT="Marie" FOLDED="true" ID="ID_1463049197" CREATED="1712331524197" MODIFIED="1712331526326">
<node TEXT="management of req, prioritization" FOLDED="true" ID="ID_980750284" CREATED="1712330930307" MODIFIED="1712330964535">
<node TEXT="stay focused" ID="ID_992615783" CREATED="1712330978318" MODIFIED="1712330982765"/>
<node TEXT="push back" FOLDED="true" ID="ID_1044485051" CREATED="1712331003293" MODIFIED="1712331012845">
<node TEXT="otherwise get overloaded with requests" ID="ID_1365806095" CREATED="1712332072200" MODIFIED="1712332082597"/>
<node TEXT="don&apos;t get the coffee" ID="ID_1726520514" CREATED="1712332179394" MODIFIED="1712332184350"/>
</node>
</node>
</node>
<node TEXT="MArtina" FOLDED="true" ID="ID_1385741464" CREATED="1712331044301" MODIFIED="1712331047129">
<node TEXT="train, change management" FOLDED="true" ID="ID_33906909" CREATED="1712331033442" MODIFIED="1712331043202">
<node TEXT="dealing with resistance to new processes" ID="ID_459295884" CREATED="1712331845681" MODIFIED="1712331883527"/>
</node>
</node>
<node TEXT="Me" FOLDED="true" ID="ID_1275246442" CREATED="1712331756137" MODIFIED="1712331757705">
<node TEXT="Leverage peer relationships, sharing of best practices" FOLDED="true" ID="ID_166456805" CREATED="1712331757874" MODIFIED="1712331776651">
<node TEXT="shows that your work can help the whole company" ID="ID_1252489461" CREATED="1712333131019" MODIFIED="1712333143346"/>
</node>
<node TEXT="If I am the source of knowledge, there is a riskj to the company" ID="ID_696116265" CREATED="1712332105265" MODIFIED="1712332118688"/>
<node TEXT="Share knowledge as much as possible" ID="ID_1651600358" CREATED="1712332123297" MODIFIED="1712332134803"/>
<node TEXT="Log support tickets" FOLDED="true" ID="ID_1087410592" CREATED="1712332189149" MODIFIED="1712332195447">
<node TEXT="Examine for widespread knowelkedge gaps and teams requiring losts of support" ID="ID_1629004757" CREATED="1712332196771" MODIFIED="1712332223429"/>
</node>
<node TEXT="Have Data Stewardship Champion for each Team" FOLDED="true" ID="ID_1584540224" CREATED="1712332135055" MODIFIED="1712332156406">
<node TEXT="leverage peer team relationships" ID="ID_740347293" CREATED="1712333034758" MODIFIED="1712333053065"/>
</node>
<node TEXT="Have adoption of tools and data stewardship visible" FOLDED="true" ID="ID_447015005" CREATED="1712332943729" MODIFIED="1712332999875">
<node TEXT="Newsletter, regualar updates" ID="ID_1990513012" CREATED="1712333073399" MODIFIED="1712333088145"/>
</node>
<node TEXT="Insetives, grade for each team" ID="ID_769560313" CREATED="1712333004708" MODIFIED="1712333026420"/>
</node>
</node>
<node TEXT="whats your favorite part of working in data stewardship" POSITION="bottom_or_right" ID="ID_178252020" CREATED="1712125819319" MODIFIED="1712125900412">
<font BOLD="true"/>
</node>
<node TEXT="what&apos;s the current level of alignment among vegetable crops in terms of processes," POSITION="bottom_or_right" ID="ID_250191220" CREATED="1709926776469" MODIFIED="1709926813004"/>
<node TEXT="what new responsibiliities or changes do you want for this person?" POSITION="bottom_or_right" ID="ID_472155331" CREATED="1710037213921" MODIFIED="1710102255902"/>
<node TEXT="KPIs" FOLDED="true" POSITION="bottom_or_right" ID="ID_1870619028" CREATED="1709927401899" MODIFIED="1709927404369">
<node TEXT="what KPIs are most important to you personally?" ID="ID_400559730" CREATED="1710171263700" MODIFIED="1710171291661"/>
<node TEXT="how is missing data captured" FOLDED="true" ID="ID_21619388" CREATED="1709926854490" MODIFIED="1709926886637">
<node TEXT="if my KPI was percentage of planned trial data which successfully made it into the database, how would I identify missing trials or plots" ID="ID_2604297" CREATED="1709926888211" MODIFIED="1709926990891"/>
</node>
<node TEXT="error trial rate" ID="ID_563147903" CREATED="1709927428869" MODIFIED="1709927433463"/>
<node TEXT="data stewardship activity" ID="ID_435907962" CREATED="1709927464523" MODIFIED="1709927472577"/>
</node>
<node TEXT="what are the long-term goals for the lettuce program in terms of genomic selection" POSITION="bottom_or_right" ID="ID_472671821" CREATED="1709926476900" MODIFIED="1709926587855"/>
<node TEXT="are there plans to use marker assisted selection to screen the di-haploid populations before trialing?" POSITION="bottom_or_right" ID="ID_302960219" CREATED="1709926588346" MODIFIED="1709926617003"/>
<node TEXT="is using evaluation data for association studies a goal for vegetable crops" FOLDED="true" POSITION="bottom_or_right" ID="ID_640874433" CREATED="1709926700903" MODIFIED="1709926740353">
<node TEXT="what changes need to be made to the data to be used for association studies identification or QTL mapping" ID="ID_1081869114" CREATED="1709926637985" MODIFIED="1709926688715"/>
</node>
</node>
<node TEXT="How could I impress you in the first three months?" ID="ID_281293303" CREATED="1712285290101" MODIFIED="1712285315180">
<font BOLD="true"/>
</node>
<node TEXT="What metrics might you use to evaluate my performance?" ID="ID_1424110375" CREATED="1712285025516" MODIFIED="1712285106719">
<font BOLD="true"/>
</node>
<node TEXT="Given everything you’ve heard, can you share your thoughts with me on where I do and don’t fit this role?" ID="ID_1558021304" CREATED="1712286502541" MODIFIED="1712286502541"/>
</node>
<node TEXT="company" FOLDED="true" ID="ID_1073668505" CREATED="1712285299303" MODIFIED="1712285301317">
<node TEXT="Challenges" FOLDED="true" ID="ID_735530658" CREATED="1712284986528" MODIFIED="1712284991495">
<node TEXT="What are the biggest challenges facing the company right now?" ID="ID_1566310590" CREATED="1712284993714" MODIFIED="1712285099668">
<font BOLD="true"/>
</node>
</node>
<node TEXT="team dynamics" FOLDED="true" ID="ID_216609629" CREATED="1706898091991" MODIFIED="1706898096139">
<node TEXT="What does your company do for team building or fun?" ID="ID_47414208" CREATED="1712285095888" MODIFIED="1712285097603">
<font BOLD="true"/>
</node>
<node TEXT="opportunities for growth" ID="ID_789907641" CREATED="1704816260027" MODIFIED="1704816264511"/>
<node TEXT="management style" ID="ID_1486440020" CREATED="1704816265084" MODIFIED="1704816269116"/>
</node>
</node>
<node TEXT="Interviewers" FOLDED="true" ID="ID_7392305" CREATED="1712285526741" MODIFIED="1712285530603">
<node TEXT="Eleni" FOLDED="true" ID="ID_981667396" CREATED="1706804785475" MODIFIED="1706804790092">
<node TEXT="What causes germplasm identity data to be inaccurate?" ID="ID_61449948" CREATED="1706804794443" MODIFIED="1706804847841"/>
<node TEXT=" How are germplasm relationships stored in the database?" ID="ID_1180759857" CREATED="1706804860433" MODIFIED="1706804950988"/>
</node>
<node TEXT="dawn Placke" FOLDED="true" ID="ID_1006845795" CREATED="1682954469565" MODIFIED="1682956101418">
<node TEXT="Traveling?" ID="ID_925763640" CREATED="1682956770417" MODIFIED="1682958056224"/>
<node TEXT="are a certain percentage of employees there only during the summer?" ID="ID_1048036906" CREATED="1682954860011" MODIFIED="1682955219036"/>
<node TEXT="how long have you been the site manager?" ID="ID_1050994660" CREATED="1682955228969" MODIFIED="1682955246768"/>
<node TEXT="What do you like best about the area?" ID="ID_1395650865" CREATED="1682955247767" MODIFIED="1682955294850"/>
</node>
<node TEXT="Drew Pullen" FOLDED="true" ID="ID_199241545" CREATED="1682956104937" MODIFIED="1682956110197">
<node TEXT="Manager, Production - Corn Field" ID="ID_1212936743" CREATED="1682956184615" MODIFIED="1682956184615"/>
<node TEXT="Growing region" ID="ID_893426697" CREATED="1682956215252" MODIFIED="1682956219265"/>
<node TEXT="Tim Strebe Slater" ID="ID_143528159" CREATED="1682956247582" MODIFIED="1682956255916"/>
<node TEXT="Doug Foster" FOLDED="true" ID="ID_1932597554" CREATED="1682956259416" MODIFIED="1682956263247">
<node TEXT="Christine Chaulk Grace" ID="ID_629131351" CREATED="1682956264231" MODIFIED="1682956467254"/>
</node>
</node>
</node>
</node>
<node TEXT="Practice delivery" ID="ID_52101817" CREATED="1712605553221" MODIFIED="1712605559066"/>
</node>
<node TEXT="Interview (T -1h) DSA: Last 4/5" FOLDED="true" ID="ID_1850876239" CREATED="1649303265590" MODIFIED="1712611927267">
<node TEXT="reference" FOLDED="true" ID="ID_1695580143" CREATED="1704732548234" MODIFIED="1704732549989">
<node ID="ID_34275505" CREATED="1704521648594" MODIFIED="1704521648594" LINK="https://www.reddit.com/r/recruitinghell/comments/12bsr5x/true_confessions_of_and_advice_from_a_hiring/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/recruitinghell/comments/12bsr5x/true_confessions_of_and_advice_from_a_hiring/">True confessions of and advice from a hiring manager : r/recruitinghell</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="goal" FOLDED="true" ID="ID_360033053" CREATED="1682959104545" MODIFIED="1682959106031">
<node TEXT="show how you are the best fit for the job" FOLDED="true" ID="ID_353333681" CREATED="1682959106579" MODIFIED="1682959114708">
<node TEXT="highlight transferable skills" ID="ID_661958404" CREATED="1682959248036" MODIFIED="1682959253945"/>
</node>
</node>
<node TEXT="Setup workstation" FOLDED="true" ID="ID_639391156" CREATED="1710179967519" MODIFIED="1710179972859">
<node TEXT="Location" FOLDED="true" ID="ID_361521963" CREATED="1712285824372" MODIFIED="1712285826797">
<node TEXT="good lighting" ID="ID_735921040" CREATED="1712285817559" MODIFIED="1712285820094"/>
<node TEXT="Connect Ethernet (hardwire)" ID="ID_1643711403" CREATED="1710179973789" MODIFIED="1710179990909"/>
</node>
</node>
<node TEXT="set up desktop" FOLDED="true" ID="ID_642056517" CREATED="1712285657477" MODIFIED="1712285660151">
<node TEXT="role alignment spreadsheet" ID="ID_250086883" CREATED="1712285661272" MODIFIED="1712285668527"/>
<node TEXT="resume" ID="ID_1399433547" CREATED="1712285668831" MODIFIED="1712285670659"/>
<node TEXT="accomplishments" FOLDED="true" ID="ID_1098200962" CREATED="1712285670986" MODIFIED="1712285674558">
<node ID="ID_867422355" CREATED="1682887923385" MODIFIED="1682887923385" LINK="https://tasks.office.com/Syngenta.onmicrosoft.com/en-US/Home/Planner/#/plantaskboard?groupId=1f9787ad-331f-408e-a953-7907e11bbc4d&amp;planId=yz5907OvU02SLoXkZlwby5YAC7rk"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://tasks.office.com/Syngenta.onmicrosoft.com/en-US/Home/Planner/#/plantaskboard?groupId=1f9787ad-331f-408e-a953-7907e11bbc4d&amp;planId=yz5907OvU02SLoXkZlwby5YAC7rk">NA Leafy R&amp;D - Planner</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_58894126" CREATED="1682889135482" MODIFIED="1682889135482" LINK="https://syngenta.sharepoint.com/:f:/s/Plan1739/EpyQ_0cNVDdJjAAcFAbqFMcBMhiZxeX07Jr9dkhZnvVFQA?e=rldM0h"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/s/Plan1739/EpyQ_0cNVDdJjAAcFAbqFMcBMhiZxeX07Jr9dkhZnvVFQA?e=rldM0h">Improvement Projects</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_449945452" CREATED="1682889277298" MODIFIED="1682889277298" LINK="https://syngenta.sharepoint.com/:o:/s/Plan1739/Ek6wFVvNHOhHtF522xazayYBeogKuY2Md5lVNR6Hn1IelA?e=DqsioI"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:o:/s/Plan1739/Ek6wFVvNHOhHtF522xazayYBeogKuY2Md5lVNR6Hn1IelA?e=DqsioI">Lettuce Manual</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="data analysis script and output" ID="ID_1453874246" CREATED="1712285674974" MODIFIED="1712285759564"/>
</node>
<node TEXT="questions for them" ID="ID_1030363003" CREATED="1712285680849" MODIFIED="1712285693224"/>
<node TEXT="note taking location" ID="ID_1311245853" CREATED="1712285694422" MODIFIED="1712285709319"/>
</node>
<node TEXT="Dress to impress" ID="ID_574526261" CREATED="1709148521058" MODIFIED="1712285734075"/>
<node TEXT="During Interview" FOLDED="true" ID="ID_1905162269" CREATED="1712285804811" MODIFIED="1712285807833">
<node TEXT="Looking to camera" ID="ID_1416867182" CREATED="1712285808606" MODIFIED="1712285814330"/>
<node TEXT="show enthusiasm" ID="ID_1103447100" CREATED="1712285840644" MODIFIED="1712285845321"/>
<node TEXT="smile" ID="ID_426135277" CREATED="1712285849747" MODIFIED="1712285851494"/>
</node>
<node TEXT="Thank you for your time" ID="ID_1798304849" CREATED="1704816295883" MODIFIED="1704816304367"/>
</node>
<node TEXT="Write Interview Notes right after interview" FOLDED="true" ID="ID_1720506121" CREATED="1712206222884" MODIFIED="1712606059419">
<icon BUILTIN="yes"/>
<node TEXT="Template Interview Notes 1/1 @ 1:00am" FOLDED="true" ID="ID_734739520" CREATED="1712606136848" MODIFIED="1712606164996">
<node TEXT="valuable insights from interviewers" ID="ID_815260627" CREATED="1712206242518" MODIFIED="1712206253395"/>
<node TEXT="highlights" ID="ID_1075374135" CREATED="1712206253678" MODIFIED="1712206255885"/>
</node>
</node>
<node TEXT="Send Post-Interview Thank you e-mail within 24 hours" FOLDED="true" ID="ID_1499978907" CREATED="1705640371443" MODIFIED="1710259507792">
<node TEXT="reference" FOLDED="true" ID="ID_1700196250" CREATED="1710256952916" MODIFIED="1710256955088">
<node ID="ID_1931214442" CREATED="1712552148233" MODIFIED="1712552148233" LINK="https://hbr.org/2022/11/how-to-write-a-thank-you-email-after-an-interview"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hbr.org/2022/11/how-to-write-a-thank-you-email-after-an-interview">How to Write a Thank You Email After an Interview</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_425232875" CREATED="1712176824923" MODIFIED="1712176824923" LINK="https://builtin.com/articles/thank-you-email-after-interview"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://builtin.com/articles/thank-you-email-after-interview">How to Write a Thank You Email After an Interview | Built In</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1098203864" CREATED="1709229875824" MODIFIED="1709229875824" LINK="https://www.inhersight.com/blog/interview/thank-you-email-after-phone-interview"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.inhersight.com/blog/interview/thank-you-email-after-phone-interview">How to Send a Thank-You Email After a Phone Interview (Tips &amp; Examples) | InHerSight</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1067122268" CREATED="1705640377444" MODIFIED="1705640377444" LINK="https://www.themuse.com/advice/how-to-write-an-interview-thankyou-note-an-email-template"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/how-to-write-an-interview-thankyou-note-an-email-template">How to Write a Thank You Email After an Interview (With… | The Muse</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="open notes" ID="ID_408294099" CREATED="1712524324269" MODIFIED="1712524348676"/>
<node TEXT="Email" FOLDED="true" ID="ID_1746456418" CREATED="1710256988348" MODIFIED="1710256991484">
<node TEXT="subject line" FOLDED="true" ID="ID_374210634" CREATED="1710258634212" MODIFIED="1710258637879">
<node TEXT="Thanks for your time yesterday" ID="ID_327490626" CREATED="1710258637881" MODIFIED="1710258665911"/>
<node TEXT="Thank You for the Interview" ID="ID_1218942933" CREATED="1712178754767" MODIFIED="1712178771682"/>
<node TEXT="Thank You for Conversation" ID="ID_1046699533" CREATED="1712178772120" MODIFIED="1712178783707"/>
</node>
<node TEXT="Hi [Interviewer Name]," ID="ID_111322550" CREATED="1710257383708" MODIFIED="1710257383708"/>
<node TEXT="Introduction (2)" FOLDED="true" ID="ID_803730210" CREATED="1712175538180" MODIFIED="1712526965452">
<node TEXT="Thank you" FOLDED="true" ID="ID_241191588" CREATED="1712526887671" MODIFIED="1712526895618">
<node TEXT="I appreciate you taking the time to speak with me today." ID="ID_1072977529" CREATED="1712176736492" MODIFIED="1712178882806"/>
<node TEXT="I really appreciate you taking time out of your schedule to meet with me." FOLDED="true" ID="ID_1603079429" CREATED="1712174549271" MODIFIED="1712175998721">
<node TEXT="Michelle" FOLDED="true" ID="ID_1767123276" CREATED="1712175169068" MODIFIED="1712175171089">
<node TEXT="detective" ID="ID_897906642" CREATED="1712175177744" MODIFIED="1712175181537"/>
</node>
<node TEXT="Martina" FOLDED="true" ID="ID_581140852" CREATED="1712175191891" MODIFIED="1712175201993">
<node TEXT="adoption" ID="ID_223963767" CREATED="1712175202813" MODIFIED="1712175207378"/>
</node>
<node TEXT="Veronique" ID="ID_444694963" CREATED="1712175215575" MODIFIED="1712175226865"/>
<node TEXT="Rao" ID="ID_1265167988" CREATED="1712175252084" MODIFIED="1712175253907"/>
</node>
<node TEXT="Thanks so much for taking the time to speak to me yesterday." ID="ID_227937893" CREATED="1710257383708" MODIFIED="1712176744095"/>
</node>
<node TEXT="enjoyed discussion, show excitement" FOLDED="true" ID="ID_1890264910" CREATED="1712526903890" MODIFIED="1712527024846">
<node TEXT="“I appreciated you discussing…”" ID="ID_500768168" CREATED="1712176873274" MODIFIED="1712176873274"/>
<node TEXT="“I enjoyed learning…”" ID="ID_1657115813" CREATED="1712176873274" MODIFIED="1712176873274"/>
<node TEXT="“It was great hearing about…”" ID="ID_73449656" CREATED="1712176873276" MODIFIED="1712176873276"/>
</node>
<node TEXT="Examples" FOLDED="true" ID="ID_322818473" CREATED="1712528288513" MODIFIED="1712528290867">
<node TEXT="Hi Marie-Aude," FOLDED="true" ID="ID_1216834990" CREATED="1712528258088" MODIFIED="1712528258088">
<node TEXT="I appreciate you taking the time to speak with me on Friday. It was a pleasure to learn more about the  role and to get your honest feedback about some of the difficulties faced in this position." ID="ID_417043239" CREATED="1712528258088" MODIFIED="1712528258088"/>
<node TEXT="You mentioned that teaching professionals is more difficult than teenagers, and I’m eager to grow my teaching strategies to help everyone get on board with new tools and initiatives. In addition to promoting the benefits of changes and leveraging personal connections, I’d like to get feedback and identify barriers to adoption early on in a way that gives colleagues an avenue to get their concerns to decision-makers and product owners. My goal is to build the assurance that concerns are being addressed and the needs of their program will be fully met." ID="ID_580652504" CREATED="1712528258091" MODIFIED="1712528258091"/>
</node>
</node>
</node>
<node TEXT="Highlight job fit and enthusiasm for role (2)" FOLDED="true" ID="ID_572835489" CREATED="1712175559038" MODIFIED="1712527078289">
<node TEXT="Martina" FOLDED="true" ID="ID_1835628578" CREATED="1712177155337" MODIFIED="1712177158529">
<node ID="ID_1512439036" CREATED="1712557222465" MODIFIED="1712557222465"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <span style="font-family: Calibri"><font face="Calibri">You mentioned managing change as one of the more challenging aspects of this role, and I’m eager to implement numerous strategies to help my colleagues learn and adapt to new tools and initiatives. Driving change was one of my favorite aspects in my role supporting the Lettuce Breeding Team here in California. </font></span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="It was helpful to learn about some of the challenges people have in working between Spirit and MINT." ID="ID_778767818" CREATED="1712176924647" MODIFIED="1712177105445"/>
<node TEXT="share idea of how you can contribute" ID="ID_187374984" CREATED="1712527047301" MODIFIED="1712527058500"/>
</node>
<node TEXT="Eleni" FOLDED="true" ID="ID_1651507048" CREATED="1712557229377" MODIFIED="1712557232455">
<node ID="ID_1424253918" CREATED="1712557278730" MODIFIED="1712557278730"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <span style="font-family: Calibri"><font face="Calibri">In our conversation you mentioned that since stakeholders are breeding teams across the world, training at scale will be a challenge. I’m excited to use my teaching skill-set in this role by developing a comprehensive training program which includes assessments, and working with each team to customize the program to meet their particular needs. </font></span>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Michelle" FOLDED="true" ID="ID_1881530532" CREATED="1712177161881" MODIFIED="1712177164136">
<node TEXT="It&apos;s nice to learn that you enjoy being a detective when it comes to troubleshooting problems. I also like your idea of creating video tutorials to help with training." ID="ID_1648668008" CREATED="1712177009063" MODIFIED="1712178706725"/>
</node>
<node TEXT="Véronique" FOLDED="true" ID="ID_1571707000" CREATED="1712177166540" MODIFIED="1712206139538">
<node TEXT="I appreciated your interest in discussing ways to improve data quality." ID="ID_100419598" CREATED="1712177474220" MODIFIED="1712177529020"/>
</node>
<node TEXT="Rao" FOLDED="true" ID="ID_1207992125" CREATED="1712177170133" MODIFIED="1712177173118">
<node TEXT="one syllable" ID="ID_1684674426" CREATED="1712207127491" MODIFIED="1712207133458"/>
<node TEXT="I enjoyed sharing some of my experiences and learning about the roadmap for IT tools going forward." ID="ID_646352322" CREATED="1712178073837" MODIFIED="1712208245003"/>
</node>
<node TEXT="I enjoyed our conversation and am excited to bring my plant breeding and IT skills to the Data Stewardship Analyst role." ID="ID_432300875" CREATED="1712176043480" MODIFIED="1712176220751"/>
</node>
<node TEXT="conclusion, express enthusiasm (1)" FOLDED="true" ID="ID_1392831645" CREATED="1712175427903" MODIFIED="1712527084581">
<node TEXT="Feel free to reach out if anything else is needed." ID="ID_1917971882" CREATED="1712176798284" MODIFIED="1712176798284"/>
<node TEXT="If there&apos;s any additional information you need, please don’t hesitate to ask." ID="ID_1271498574" CREATED="1712175432814" MODIFIED="1712208320106"/>
<node TEXT="I look forward to hearing from you about the next steps. Please don’t hesitate to contact me if I can provide any additional information." ID="ID_1900725813" CREATED="1710258170971" MODIFIED="1710274501170"/>
</node>
<node TEXT="Best Regards," ID="ID_1983775425" CREATED="1710258624782" MODIFIED="1710258630235"/>
</node>
</node>
<node TEXT="Connect to Hiring Manager" FOLDED="true" ID="ID_882951925" CREATED="1667774106277" MODIFIED="1667774115467">
<node ID="ID_856006567" CREATED="1667774116910" MODIFIED="1667774116910" LINK="https://www.wikihow.com/Connect-with-Hiring-Manager-on-LinkedIn"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.wikihow.com/Connect-with-Hiring-Manager-on-LinkedIn">How to Connect with a Hiring Manager on LinkedIn</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Field" FOLDED="true" ID="ID_1964257120" CREATED="1706207397004" MODIFIED="1706207399104">
<node TEXT="Agriculture" ID="ID_1568742370" CREATED="1705598351022" MODIFIED="1705598358297">
<node TEXT="Agricultural Research" ID="ID_1639550815" CREATED="1622819798525" MODIFIED="1703809432078">
<node TEXT="Breeding" FOLDED="true" ID="ID_1024420895" CREATED="1703810200862" MODIFIED="1706207466078">
<node TEXT="Next" FOLDED="true" ID="ID_1935929598" CREATED="1704326473411" MODIFIED="1704326475757">
<node TEXT="Breeder" ID="ID_1323931031" CREATED="1704326457268" MODIFIED="1704326460173"/>
<node TEXT="Skills" ID="ID_1537146664" CREATED="1704326485780" MODIFIED="1704326488517">
<node TEXT="Breeding Project Management" FOLDED="true" ID="ID_307013929" CREATED="1519243258910" MODIFIED="1519243258910">
<node TEXT="Certification" FOLDED="true" ID="ID_54428750" CREATED="1621029643493" MODIFIED="1621029647105">
<node TEXT="Lean Six Sigma" FOLDED="true" ID="ID_1660681149" CREATED="1621032527107" MODIFIED="1621032533669">
<node ID="ID_136510445" CREATED="1621032535154" MODIFIED="1621032535154" LINK="https://www.purdue.edu/leansixsigmaonline/blog/six-sigma-vs-lean-six-sigma/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.purdue.edu/leansixsigmaonline/blog/six-sigma-vs-lean-six-sigma/">Six Sigma vs Lean Six Sigma: What's the Difference? - Purdue</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Six Sigma Black Belt" FOLDED="true" ID="ID_365753569" CREATED="1621029649140" MODIFIED="1621029662091">
<node TEXT="institutions" FOLDED="true" ID="ID_1067663233" CREATED="1621029676106" MODIFIED="1621029679096">
<node TEXT="ASQ" ID="ID_833827392" CREATED="1621029698636" MODIFIED="1621029700444"/>
<node TEXT="CSSC" ID="ID_980763010" CREATED="1621029687710" MODIFIED="1621029694453"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Assistant Breeding Project Lead" ID="ID_461364568" CREATED="1696458809364" MODIFIED="1696458815692">
<node TEXT="skills" ID="ID_719639013" CREATED="1701760923621" MODIFIED="1703810337527">
<font BOLD="true"/>
<node TEXT="BS Crop Science" ID="ID_181512558" CREATED="1621029625652" MODIFIED="1621029632216"/>
<node TEXT="MS Plant Breeding" ID="ID_561960585" CREATED="1621029633948" MODIFIED="1621029641373"/>
</node>
</node>
</node>
<node TEXT="Seed Production Research" FOLDED="true" ID="ID_499147742" CREATED="1621309866837" MODIFIED="1703809582706">
<node TEXT="Next?" ID="ID_1541470053" CREATED="1704326518588" MODIFIED="1704326521861"/>
<node TEXT="Skills" ID="ID_1979214015" CREATED="1704326500709" MODIFIED="1704326503597">
<node TEXT="Seed Production Knowledge" ID="ID_951985036" CREATED="1704326504476" MODIFIED="1704326512229"/>
<node TEXT="Resources" FOLDED="true" ID="ID_1814496361" CREATED="1622819559354" MODIFIED="1622819562118">
<node ID="ID_1030449417" CREATED="1622819563402" MODIFIED="1622819563402" LINK="http://agron-www.agron.iastate.edu/Courses/agron338/index.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://agron-www.agron.iastate.edu/Courses/agron338/index.html">SEED SCIENCE AND TECHNOLOGY</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1613701575" CREATED="1622820637392" MODIFIED="1622820637392" LINK="https://sites.google.com/site/princiseedtech/syllabus"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sites.google.com/site/princiseedtech/syllabus">Syllabus - Principles of Seed Technology</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1347985693" CREATED="1622821323160" MODIFIED="1622821323160" LINK="http://agrimoon.com/wp-content/uploads/PRINCIPLES-OF-SEED-TECHNOLOGY.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://agrimoon.com/wp-content/uploads/PRINCIPLES-OF-SEED-TECHNOLOGY.pdf">PRINCIPLES-OF-SEED-TECHNOLOGY.pdf</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="seed systems" FOLDED="true" ID="ID_890601612" CREATED="1622820278760" MODIFIED="1622820284061">
<node TEXT="png_624167978420951376.png" ID="ID_693575709" CREATED="1622820296803" MODIFIED="1622820296803">
<hook URI="Career%20Management_files/png_624167978420951376.png" SIZE="0.57251906" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Type of seed used for multiplication" FOLDED="true" ID="ID_361646196" CREATED="1622829735415" MODIFIED="1622829762240">
<node TEXT="varietal" FOLDED="true" ID="ID_561811529" CREATED="1622829765322" MODIFIED="1622829768429">
<node TEXT="single parent multiplication" ID="ID_1575395276" CREATED="1622829849502" MODIFIED="1622829853534"/>
<node TEXT="Lower isolation distance requirement" ID="ID_1768750545" CREATED="1622829883824" MODIFIED="1622829889786"/>
<node TEXT="production is by open pollination" ID="ID_699012480" CREATED="1622829900635" MODIFIED="1622829906798"/>
<node TEXT="Seed can be used continuously for 3 to 5 generations" ID="ID_1787754530" CREATED="1622829932392" MODIFIED="1622829941202"/>
<node TEXT="Production technique is uniform ( multiplication )" ID="ID_1219338621" CREATED="1622829942658" MODIFIED="1622829951806"/>
<node TEXT="Production care is less" ID="ID_1314470256" CREATED="1622829953290" MODIFIED="1622829957209"/>
<node TEXT="Yield will be lower" ID="ID_1539111473" CREATED="1622829958365" MODIFIED="1622829961796"/>
<node TEXT="Profit is less" ID="ID_1874320195" CREATED="1622829963264" MODIFIED="1622829966951"/>
</node>
<node TEXT="Hybrid" FOLDED="true" ID="ID_668922034" CREATED="1622829769361" MODIFIED="1622829771977">
<node TEXT="2-n parents" ID="ID_1902025295" CREATED="1622829855911" MODIFIED="1622829877259"/>
<node TEXT="higher isolation distance requirement" ID="ID_1260029759" CREATED="1622829893309" MODIFIED="1622829899406"/>
<node TEXT="Production is by managed control pollination" ID="ID_484883183" CREATED="1622829913754" MODIFIED="1622829920387"/>
<node TEXT="new seed is required for each cycle" ID="ID_1823744703" CREATED="1622829972544" MODIFIED="1622829983749"/>
<node TEXT="production technique differs with each crop" ID="ID_424386899" CREATED="1622829985605" MODIFIED="1622830004254"/>
<node TEXT="Production care is more" ID="ID_583170490" CREATED="1622830005178" MODIFIED="1622830008506"/>
<node TEXT="Yield is higher" ID="ID_1625981607" CREATED="1622830009389" MODIFIED="1622830012506"/>
<node TEXT="Profit is higher" ID="ID_971714285" CREATED="1622830012999" MODIFIED="1622830015519"/>
</node>
</node>
<node TEXT="Seed types" FOLDED="true" ID="ID_568370246" CREATED="1622821084197" MODIFIED="1622821088184">
<node TEXT="nucleus" ID="ID_1195195884" CREATED="1622821089332" MODIFIED="1622821092263"/>
<node TEXT="Breeder" ID="ID_190356832" CREATED="1622821093186" MODIFIED="1622821095140"/>
<node TEXT="Foundation" ID="ID_1517042234" CREATED="1622821096003" MODIFIED="1622821099037"/>
<node TEXT="Certified" ID="ID_1755426869" CREATED="1622821100073" MODIFIED="1622821104271"/>
</node>
<node TEXT="Deterioration of Genetic Purity" FOLDED="true" ID="ID_1122049528" CREATED="1622821165828" MODIFIED="1622821168185">
<node TEXT="factors responsible for deterioration" FOLDED="true" ID="ID_1297231931" CREATED="1622821234897" MODIFIED="1622821241189">
<node TEXT=" Developmental variations" FOLDED="true" ID="ID_1791819543" CREATED="1622821187382" MODIFIED="1622821187382">
<node TEXT="from environmental variation" FOLDED="true" ID="ID_1470659306" CREATED="1622821488410" MODIFIED="1622821516281">
<node TEXT="growing outside of area of adaptation" ID="ID_1010466333" CREATED="1622821522196" MODIFIED="1622821551571"/>
</node>
</node>
<node TEXT=" Mechanical mixtures" FOLDED="true" ID="ID_1451891109" CREATED="1622821187382" MODIFIED="1622821187382">
<node TEXT="most important reason for varietal deterioration" ID="ID_256914191" CREATED="1622821865300" MODIFIED="1622821869811"/>
<node TEXT="due to" FOLDED="true" ID="ID_1623180712" CREATED="1622821563469" MODIFIED="1622821883771">
<node TEXT="sowing with same seed drill" ID="ID_504886185" CREATED="1622821585118" MODIFIED="1622821903226"/>
<node TEXT="Volunteer plants in field" ID="ID_1111042657" CREATED="1622821603250" MODIFIED="1622821609725"/>
<node TEXT="different varieties grown in adjacent fields" FOLDED="true" ID="ID_266157034" CREATED="1622821611632" MODIFIED="1622821629404">
<node TEXT="mixing during harvesting and threshing" ID="ID_1886092150" CREATED="1622821652598" MODIFIED="1622821662709"/>
</node>
</node>
<node TEXT="preventative measures" FOLDED="true" ID="ID_1005862952" CREATED="1622821715104" MODIFIED="1622821721956">
<node TEXT="rouging the seed fields" ID="ID_1684919738" CREATED="1622821722974" MODIFIED="1622821782990"/>
<node TEXT="Care during seed production and processing" ID="ID_1208732392" CREATED="1622821733009" MODIFIED="1622821740181"/>
</node>
</node>
<node TEXT=" Mutations" ID="ID_1522177070" CREATED="1622821187386" MODIFIED="1622821187386"/>
<node TEXT=" Natural crossing" ID="ID_591672855" CREATED="1622821187387" MODIFIED="1622821187387"/>
<node TEXT=" Minor genetic variations" ID="ID_1836018863" CREATED="1622821187388" MODIFIED="1622821187388"/>
<node TEXT=" Selected influence of pest and diseases" ID="ID_1512155669" CREATED="1622821187389" MODIFIED="1622821187389"/>
<node TEXT=" The techniques of the plant breeder" ID="ID_1673179824" CREATED="1622821187391" MODIFIED="1622821187391"/>
</node>
</node>
<node TEXT="Stages Of Hybrid Maize Production" FOLDED="true" ID="ID_98754842" CREATED="1622237926637" MODIFIED="1622237942839">
<node TEXT="choice of germplasm and breeding procedure" FOLDED="true" ID="ID_1656711114" CREATED="1622237944004" MODIFIED="1622238330824">
<node TEXT="choice of germplasm" FOLDED="true" ID="ID_998011658" CREATED="1622238332377" MODIFIED="1622238350237">
<node TEXT="sources of genetic variability" FOLDED="true" ID="ID_163964640" CREATED="1622238352323" MODIFIED="1622238440207">
<node TEXT="naturally occurring" FOLDED="true" ID="ID_963443370" CREATED="1622238442653" MODIFIED="1622238452804">
<node TEXT="broad-based populations" FOLDED="true" ID="ID_191227774" CREATED="1622238469552" MODIFIED="1622238475219">
<node TEXT="races" ID="ID_1049826778" CREATED="1622238488141" MODIFIED="1622238501948"/>
<node TEXT="Accessions" ID="ID_217067618" CREATED="1622238503471" MODIFIED="1622238522290"/>
<node TEXT="land race cultivars" ID="ID_113100750" CREATED="1622238523663" MODIFIED="1622238534234"/>
<node TEXT="Improved synthetic cultivars" ID="ID_346050325" CREATED="1622238536224" MODIFIED="1622238540672"/>
</node>
<node TEXT="crossing inbred lines" FOLDED="true" ID="ID_211023477" CREATED="1622238550772" MODIFIED="1622238562676">
<node TEXT="with segregating progeny" FOLDED="true" ID="ID_503333744" CREATED="1622238606027" MODIFIED="1622238828783">
<node TEXT="self pollinating" ID="ID_781056503" CREATED="1622238622539" MODIFIED="1622238625453"/>
<node TEXT="random mating" ID="ID_1022750288" CREATED="1622238663893" MODIFIED="1622238666898"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Methods of creating inbred lines" ID="ID_672770168" CREATED="1622237980999" MODIFIED="1622237985761"/>
<node TEXT="methods of evaluation of S lines" FOLDED="true" ID="ID_1406164696" CREATED="1622238000592" MODIFIED="1622238007279">
<node TEXT="S-line: inbred" FOLDED="true" ID="ID_1157476147" CREATED="1622238168996" MODIFIED="1622238189465">
<node TEXT="S1: Progeny of 1st generation of selfing" ID="ID_586554067" CREATED="1622238199721" MODIFIED="1622238234901"/>
</node>
</node>
<node TEXT="Large-scale hybrid seed production" ID="ID_798262778" CREATED="1622238009029" MODIFIED="1622238013013"/>
</node>
<node TEXT="hybrid seed production systems" FOLDED="true" ID="ID_620970193" CREATED="1621310051895" MODIFIED="1621310059759">
<node TEXT="composed of" FOLDED="true" ID="ID_1621398550" CREATED="1621310361741" MODIFIED="1621310364978">
<node TEXT="inbred lines" ID="ID_717488011" CREATED="1621310061965" MODIFIED="1621310066157"/>
<node TEXT="Hybridization system" ID="ID_621798474" CREATED="1621310067379" MODIFIED="1621310071134"/>
</node>
<node TEXT="objective" FOLDED="true" ID="ID_574486365" CREATED="1621310384564" MODIFIED="1621310389432">
<node TEXT="enforce cross-pollination between inbred lines" FOLDED="true" ID="ID_542611593" CREATED="1621310390962" MODIFIED="1621310400132">
<node TEXT="eliminate self pollination on the female parent line" FOLDED="true" ID="ID_1464605656" CREATED="1621310411483" MODIFIED="1621310426460">
<node TEXT="make male-sterile" FOLDED="true" ID="ID_982222763" CREATED="1621310445192" MODIFIED="1621310472733">
<node TEXT="mechanically" ID="ID_1451176852" CREATED="1621310473983" MODIFIED="1621310476971"/>
<node TEXT="Genetically" FOLDED="true" ID="ID_836385777" CREATED="1621310478053" MODIFIED="1621310480988">
<node TEXT="Brassica" FOLDED="true" ID="ID_659903829" CREATED="1621310632356" MODIFIED="1621310637282">
<node TEXT="self- incompatibility" ID="ID_1725680116" CREATED="1621310597543" MODIFIED="1621310607583"/>
<node TEXT="Cytoplasmic male sterility" ID="ID_1699065547" CREATED="1621310609344" MODIFIED="1621310615561"/>
</node>
<node TEXT="eliminate male fertility" FOLDED="true" ID="ID_1262421188" CREATED="1621310664607" MODIFIED="1621310682697">
<node TEXT="GM" ID="ID_1314603244" CREATED="1621310688866" MODIFIED="1621310700148"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="systems" FOLDED="true" ID="ID_387944345" CREATED="1621311061969" MODIFIED="1621311089661">
<node TEXT="1 line system: Apomixis" ID="ID_1281077829" CREATED="1621311090715" MODIFIED="1621311120378"/>
<node TEXT="2  line  system:" FOLDED="true" ID="ID_648226562" CREATED="1621311121856" MODIFIED="1621311284737">
<node TEXT="Genetic  male  sterility  (GMS)" ID="ID_1026367571" CREATED="1621311284739" MODIFIED="1621311386360"/>
<node TEXT="Cytoplasmic male sterility (CMS)" ID="ID_301980174" CREATED="1621311386362" MODIFIED="1621311386369"/>
</node>
<node TEXT="3  line  system:  Cytoplasmic-genetic  male sterility (CGMS)" ID="ID_1115046977" CREATED="1621311173221" MODIFIED="1621311173222"/>
<node TEXT="reference" FOLDED="true" ID="ID_1754519156" CREATED="1621311679981" MODIFIED="1621311689103">
<node ID="ID_441099442" CREATED="1621311708572" MODIFIED="1621311708572" LINK="https://www.researchgate.net/publication/326957162_Hybrid_Seed_Production_Systems"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.researchgate.net/publication/326957162_Hybrid_Seed_Production_Systems">(PDF) Hybrid Seed Production Systems</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Resources" FOLDED="true" ID="ID_548602448" CREATED="1622819806288" MODIFIED="1622819809286">
<node ID="ID_1815750130" CREATED="1622819810501" MODIFIED="1622819810501" LINK="http://agron-www.agron.iastate.edu/Courses/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://agron-www.agron.iastate.edu/Courses/">Agronomy Courses</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Phenotyping Technology" ID="ID_49927897" CREATED="1519243258910" MODIFIED="1519243258910"/>
<node TEXT="Predictive Agriculture/Modeling" ID="ID_366280552" CREATED="1519243258910" MODIFIED="1519243258910"/>
</node>
<node TEXT="Management" ID="ID_1714745982" CREATED="1705598363870" MODIFIED="1705598367656"/>
</node>
<node TEXT="Data" FOLDED="true" ID="ID_1751594211" CREATED="1698901611411" MODIFIED="1698901619933">
<node TEXT="reference" FOLDED="true" ID="ID_6254608" CREATED="1706805180404" MODIFIED="1709927751171">
<node TEXT="Breedbase" FOLDED="true" ID="ID_956156641" CREATED="1706806808015" MODIFIED="1706806851447">
<node FOLDED="true" ID="ID_183870847" CREATED="1706806852682" MODIFIED="1706806852682" LINK="https://breedbase.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://breedbase.org/">BreedBase</a>
  </body>
</html>
</richcontent>
<node TEXT="mmcmillen" ID="ID_213652414" CREATED="1706806297866" MODIFIED="1706806297866"/>
<node TEXT="Lucydog1" ID="ID_1799712755" CREATED="1706806371639" MODIFIED="1706806385233"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_643602940" CREATED="1706807490633" MODIFIED="1706807494243">
<node ID="ID_1342975780" CREATED="1706807498320" MODIFIED="1706807498320" LINK="https://academic.oup.com/database/article/doi/10.1093/database/bar051/469438"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://academic.oup.com/database/article/doi/10.1093/database/bar051/469438">Chado Natural Diversity module: a new generic database schema for large-scale phenotyping and genotyping data | Database | Oxford Academic</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1935138882" CREATED="1706805188459" MODIFIED="1706805188459" LINK="https://academic.oup.com/g3journal/article/12/7/jkac078/6564228?login=false"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://academic.oup.com/g3journal/article/12/7/jkac078/6564228?login=false">Breedbase: a digital ecosystem for modern plant breeding | G3 Genes|Genomes|Genetics | Oxford Academic</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Data Stewardship" FOLDED="true" ID="ID_58300395" CREATED="1706240193118" MODIFIED="1706240200049">
<node TEXT="reference" FOLDED="true" ID="ID_722675146" CREATED="1712418369394" MODIFIED="1712418372194">
<node ID="ID_813104772" CREATED="1712418376732" MODIFIED="1712418376732" LINK="https://cognopia.com/data-stewardship-ultimate-guide/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://cognopia.com/data-stewardship-ultimate-guide/">The Ultimate Guide To Mastering Data Ownership and Data Stewardship - Cognopia</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="KPIs and Metrics" FOLDED="true" ID="ID_1352373482" CREATED="1709927713674" MODIFIED="1709927719422">
<node TEXT="reference" FOLDED="true" ID="ID_1509341561" CREATED="1709927720234" MODIFIED="1709927721860">
<node ID="ID_647323593" CREATED="1709927722871" MODIFIED="1709927722871" LINK="https://secureframe.com/hub/grc/data-governance-metrics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://secureframe.com/hub/grc/data-governance-metrics">7 Data Governance Metrics and KPIs Every Business Should Track | Secureframe</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Data Quality Score" FOLDED="true" ID="ID_474904263" CREATED="1709927800737" MODIFIED="1709927812612">
<node TEXT="a score rating that represents the accuracy, consistency, timeliness, completeness, and reliability of your data" ID="ID_654320930" CREATED="1709927812614" MODIFIED="1709927836643"/>
</node>
</node>
<node ID="ID_1943114030" CREATED="1706294114247" MODIFIED="1706294114247" LINK="https://atlan.com/data-stewardship-101/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://atlan.com/data-stewardship-101/">Data Stewardship and Its Role in a Data Governance Program</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="accountability and responsibility for data and processes that ensure effective control and use of data assets" ID="ID_1016918807" CREATED="1706294025429" MODIFIED="1706294025429"/>
<node TEXT="the collection of practices that ensure an organization&apos;s data is" FOLDED="true" ID="ID_396840230" CREATED="1706284964817" MODIFIED="1706803247465">
<node TEXT="accessible" ID="ID_1612841044" CREATED="1706803247466" MODIFIED="1706803247467"/>
<node TEXT="usable" ID="ID_1208949383" CREATED="1706803231893" MODIFIED="1706803231893"/>
<node TEXT="safe" ID="ID_1788335523" CREATED="1706803231894" MODIFIED="1706803231894"/>
<node TEXT="trusted" ID="ID_1755811379" CREATED="1706803231895" MODIFIED="1706803266835"/>
</node>
<node ID="ID_1237016282" CREATED="1706293731851" MODIFIED="1706293731851" LINK="https://www.dataversity.net/what-is-data-stewardship/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.dataversity.net/what-is-data-stewardship/">What Is Data Stewardship? - DATAVERSITY</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1718312599" CREATED="1706293551066" MODIFIED="1706293551066" LINK="https://www.data-vault.co.uk/qualities-data-steward/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.data-vault.co.uk/qualities-data-steward/">What qualities Data Stewards should have and what training is needed</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_957231037" CREATED="1706242470666" MODIFIED="1706242470666" LINK="https://www.data-vault.co.uk/what-is-data-stewardship-infographic/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.data-vault.co.uk/what-is-data-stewardship-infographic/">What is Data Stewardship - Infographic GDPR Blog</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="png_7961508215300676117.png" ID="ID_479888563" CREATED="1706242134089" MODIFIED="1706242134089">
<hook URI="Career%20Management_files/png_7961508215300676117.png" SIZE="0.3" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Data Analyst" FOLDED="true" ID="ID_7410964" CREATED="1698901857163" MODIFIED="1698901862210">
<node TEXT="Portfolio" FOLDED="true" ID="ID_1018859741" CREATED="1706308296212" MODIFIED="1706308573690">
<node ID="ID_1752680586" CREATED="1706308575757" MODIFIED="1706308575757" LINK="https://medium.com/@DrewZola/how-to-make-a-good-sql-portfolio-d10938116464"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/@DrewZola/how-to-make-a-good-sql-portfolio-d10938116464">How to make a good SQL Portfolio. And why it matters | by Andrew Zola | Medium</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_396983684" CREATED="1706309110871" MODIFIED="1706309110871" LINK="https://count.co/canvas/3c8Jp1F3V5Y"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://count.co/canvas/3c8Jp1F3V5Y">Untitled – Count</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Terminology" FOLDED="true" ID="ID_317106405" CREATED="1706329790159" MODIFIED="1706329795328">
<node ID="ID_1014560598" CREATED="1706329796528" MODIFIED="1706329796528" LINK="https://www.osmos.io/blog/data-terms-glossary-list"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osmos.io/blog/data-terms-glossary-list">Ultimate Data Glossary: 101 Data Terms You Should Know</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Database" FOLDED="true" ID="ID_774197610" CREATED="1706330217910" MODIFIED="1706330221264">
<node TEXT="table" FOLDED="true" ID="ID_1911737029" CREATED="1706330222191" MODIFIED="1706330600360"><richcontent TYPE="DETAILS" HIDDEN="true">
<html>
  <head>
    
  </head>
  <body>
    <p>
      group of related data
    </p>
  </body>
</html></richcontent>
<node TEXT="AKA a data entity" FOLDED="true" ID="ID_774581624" CREATED="1706331258293" MODIFIED="1706331384423">
<node TEXT="object in a data model" ID="ID_1970867062" CREATED="1706331264920" MODIFIED="1706331268944"/>
<node TEXT="examples" FOLDED="true" ID="ID_102753474" CREATED="1706331270943" MODIFIED="1706331276639">
<node TEXT="customer" ID="ID_766221957" CREATED="1706331278117" MODIFIED="1706331285455"/>
<node TEXT="contact" ID="ID_820899899" CREATED="1706331292942" MODIFIED="1706331295302"/>
<node TEXT="address" ID="ID_1495683413" CREATED="1706331296317" MODIFIED="1706331297247"/>
</node>
</node>
<node TEXT="contains" FOLDED="true" ID="ID_1937081849" CREATED="1706331361461" MODIFIED="1706331363591">
<node TEXT="row, record, tuples" FOLDED="true" ID="ID_840952027" CREATED="1706330236719" MODIFIED="1706677751442">
<node TEXT="data about something or someone" ID="ID_964364036" CREATED="1706330426113" MODIFIED="1706330436152"/>
</node>
<node TEXT="columns, fields, attributes" ID="ID_999272337" CREATED="1706330232131" MODIFIED="1706330518584"><richcontent TYPE="DETAILS" HIDDEN="true">
<html>
  <head>
    
  </head>
  <body>
    <div style="background-color: #191919">
      <p>
        <span style="font-size: 12pt"><font size="12pt">single type of information that appears in each record</font></span>
      </p>
    </div>
    <div style="background-color: #191919">
      <p>
        <span style="font-size: 12pt"><font size="12pt">for example addresses , or names</font></span>
      </p>
    </div>
  </body>
</html></richcontent>
<hook NAME="AlwaysUnfoldedNode"/>
</node>
</node>
</node>
</node>
<node TEXT="Schema" FOLDED="true" ID="ID_206046305" CREATED="1706677763665" MODIFIED="1706677766026">
<node TEXT="show datatypes for each field and all tables" ID="ID_670216633" CREATED="1706677813769" MODIFIED="1706677821725"/>
<node TEXT="show relationships between tables" ID="ID_757612720" CREATED="1706677821740" MODIFIED="1706677838348"/>
</node>
<node TEXT="Data Quality" FOLDED="true" ID="ID_1845925602" CREATED="1706241293231" MODIFIED="1706241296420">
<node TEXT="a measure of how reliable a data set is to serve the specific needs of an organization based on factors such as:" ID="ID_1027952644" CREATED="1706911406193" MODIFIED="1706911424490"/>
<node TEXT="Data quality measures how well a dataset meets criteria for accuracy, completeness, validity, consistency, uniqueness, timeliness, and fitness for purpose, and it is critical to all data governance initiatives within an organization." ID="ID_1330652392" CREATED="1706241298607" MODIFIED="1706241298607"/>
<node TEXT="Integrity" FOLDED="true" ID="ID_881893930" CREATED="1706249450845" MODIFIED="1706249461368">
<node TEXT="accuracy" FOLDED="true" ID="ID_396984379" CREATED="1706249463806" MODIFIED="1706249479790">
<node TEXT="error-free records that can be used as a reliable source of information" ID="ID_1242610602" CREATED="1706911750865" MODIFIED="1706911758635"/>
<node ID="ID_1934962345" CREATED="1706911842568" MODIFIED="1706911842568" LINK="https://dataladder.com/what-is-data-accuracy/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dataladder.com/what-is-data-accuracy/">What is Data Accuracy, Why it Matters and How Companies Can Ensure They Have Accurate Data. - Data Ladder</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="completeness" ID="ID_144183330" CREATED="1706249480301" MODIFIED="1706249488055"/>
<node TEXT="consistency" ID="ID_139980441" CREATED="1706249488478" MODIFIED="1706249493718"/>
<node TEXT="validity" ID="ID_247829067" CREATED="1706249494045" MODIFIED="1706249497895"/>
<node TEXT="reliability" ID="ID_1664510712" CREATED="1706329836887" MODIFIED="1706329839744"/>
<node TEXT="up-to-date" ID="ID_999749667" CREATED="1706329831207" MODIFIED="1706329833632"/>
<node TEXT="fitness for purpose" ID="ID_585725213" CREATED="1706329852039" MODIFIED="1706329855535"/>
</node>
</node>
<node TEXT="Data Analytics" FOLDED="true" ID="ID_1714142906" CREATED="1703890228263" MODIFIED="1703890233008">
<node ID="ID_1811052174" CREATED="1703890399592" MODIFIED="1703890399592" LINK="https://www.comptia.org/content/guides/what-is-data-analytics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.comptia.org/content/guides/what-is-data-analytics">What Is Data Analytics - The Ultimate Guide</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Types" FOLDED="true" ID="ID_172192838" CREATED="1703890569817" MODIFIED="1703890575412">
<node TEXT="Descriptive Analytics" FOLDED="true" ID="ID_1819493744" CREATED="1703890685999" MODIFIED="1703890690788">
<node TEXT="What is happening?" ID="ID_982296973" CREATED="1703890722774" MODIFIED="1703890727623"/>
<node TEXT="snapshot" ID="ID_942770547" CREATED="1703890812159" MODIFIED="1703890814986"/>
<node TEXT="past to now" ID="ID_48964713" CREATED="1703890820479" MODIFIED="1703890827449"/>
</node>
<node TEXT="Diagnostic Analytics" FOLDED="true" ID="ID_901191114" CREATED="1703890690810" MODIFIED="1703890695802">
<node TEXT="Why is it happening?" ID="ID_925181794" CREATED="1703890730176" MODIFIED="1703890793008"/>
</node>
<node TEXT="Predictive Analytics" FOLDED="true" ID="ID_1715146099" CREATED="1703890695828" MODIFIED="1703890699779">
<node TEXT="What is likely to happen?" ID="ID_872537088" CREATED="1703890737775" MODIFIED="1703890796832"/>
</node>
<node TEXT="Prescriptive Analytics" FOLDED="true" ID="ID_1342591823" CREATED="1703890699803" MODIFIED="1703890710409">
<node TEXT="What do I need to do?" ID="ID_806286870" CREATED="1703890712175" MODIFIED="1703890799888"/>
</node>
</node>
</node>
<node TEXT="Data Lifecycle" FOLDED="true" ID="ID_33694724" CREATED="1703890440654" MODIFIED="1703890444433">
<node TEXT="Data Collection And Storage" ID="ID_382162614" CREATED="1703890454786" MODIFIED="1703890459393"/>
<node TEXT="Data Processing And Organization" ID="ID_1027222239" CREATED="1703890460219" MODIFIED="1703890465205"/>
<node TEXT="Data Analysis And Visualization" ID="ID_1394987528" CREATED="1703890467610" MODIFIED="1703890472426"/>
</node>
</node>
<node TEXT="Skills" FOLDED="true" ID="ID_1953248921" CREATED="1698902749407" MODIFIED="1698902752308">
<node TEXT="Development" FOLDED="true" ID="ID_1409010030" CREATED="1698943610352" MODIFIED="1698943613999">
<node TEXT="certificates" FOLDED="true" ID="ID_728429003" CREATED="1706679754852" MODIFIED="1706679758569">
<node TEXT="Google Data Analytics Certificate" ID="ID_168824658" CREATED="1706895629764" MODIFIED="1710196549410" LINK="Google%20Data%20Analytics%20Certificate.mm">
<icon BUILTIN="bookmark"/>
<edge DASH="SOLID"/>
</node>
</node>
<node TEXT="courses" FOLDED="true" ID="ID_1396731989" CREATED="1700692973710" MODIFIED="1700692978741">
<node TEXT="DataCamp" ID="ID_1379212029" CREATED="1706677576320" MODIFIED="1706677580011"/>
<node ID="ID_988313159" CREATED="1706673467169" MODIFIED="1706673467169" LINK="https://www.dataquest.io/data-science-courses/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.dataquest.io/data-science-courses/">Data Science Courses in Python, R, SQL, Power BI, and More</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_904845433" CREATED="1703889503622" MODIFIED="1703889503622" LINK="https://iimskills.com/free-data-analytics-courses/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://iimskills.com/free-data-analytics-courses/">Top 13 Free Data Analytics Courses With Practical Training</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_593763396" CREATED="1700700711002" MODIFIED="1700700711002" LINK="https://www.mygreatlearning.com/academy/learn-for-free/courses/statistics-for-data-science2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mygreatlearning.com/academy/learn-for-free/courses/statistics-for-data-science2">Basics of Statistics For Data Science - Great Learning</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_598362840" CREATED="1700692981392" MODIFIED="1700692981392" LINK="https://www.udemy.com/topic/data-analysis/free/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.udemy.com/topic/data-analysis/free/">Top Free Data Analysis Courses &amp; Tutorials Online - Updated [November 2023]</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Master Programs" FOLDED="true" ID="ID_1193770599" CREATED="1700692963634" MODIFIED="1700692968313">
<node TEXT="Illinois Tech Master Of Data Science $15K" ID="ID_1141417731" CREATED="1706899376126" MODIFIED="1706899452157" LINK="https://www.coursera.org/degrees/mas-data-science-illinois-tech"/>
<node ID="ID_56642879" CREATED="1706654811335" MODIFIED="1706654811335" LINK="https://www.reddit.com/r/WGU/comments/augtzg/completing_wgus_masters_of_data_analytics_in_1/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/WGU/comments/augtzg/completing_wgus_masters_of_data_analytics_in_1/">Completing WGU's Masters of Data Analytics in 1 Term : r/WGU</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_731403312" CREATED="1703887373553" MODIFIED="1703887373553" LINK="https://www.eastern.edu/academics/graduate-programs/ms-data-science"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.eastern.edu/academics/graduate-programs/ms-data-science">MS in Data Science | Online | $9,900 | Eastern University</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1552460433" CREATED="1698943605145" MODIFIED="1698943605145" LINK="https://www.degreeinfo.com/index.php?threads/ms-in-data-science-self-paced-10-months-under-10k.57214/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.degreeinfo.com/index.php?threads/ms-in-data-science-self-paced-10-months-under-10k.57214/">MS in Data Science: self-paced, 10 months, under $10k | DegreeInfo</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1906617019" CREATED="1698903858067" MODIFIED="1698903858067" LINK="https://mpierce710006.medium.com/wgu-masters-of-science-in-data-analytics-msda-review-48ecdba186a3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mpierce710006.medium.com/wgu-masters-of-science-in-data-analytics-msda-review-48ecdba186a3">WGU “Master of Science in Data Analytics” (MSDA) Review | by Matt Pierce | Medium</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Boot Camps" FOLDED="true" ID="ID_1896345393" CREATED="1700692969717" MODIFIED="1703879966609">
<node ID="ID_390376453" CREATED="1706672890597" MODIFIED="1706672890597" LINK="https://www.edx.org/boot-camps/data-analytics"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edx.org/boot-camps/data-analytics">Compare Online Data Analytics Boot Camps | edX</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1438052116" CREATED="1698902322452" MODIFIED="1698902322452" LINK="https://brainstation.io/career-guides/are-data-science-bootcamps-worth-it#:~:text=Yes%2C%20it%20is%20very%20likely,found%20work%20in%20the%20field."><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://brainstation.io/career-guides/are-data-science-bootcamps-worth-it#:~:text=Yes%2C%20it%20is%20very%20likely,found%20work%20in%20the%20field.">Are Data Science Bootcamps Worth It? (2023 Guide) | BrainStation®</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="testing" FOLDED="true" ID="ID_1281752431" CREATED="1700686315645" MODIFIED="1700686317861">
<node ID="ID_1407336851" CREATED="1700686319431" MODIFIED="1700686319431" LINK="https://www.simplilearn.com/tutorials/data-analytics-tutorial/data-analyst-interview-questions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.simplilearn.com/tutorials/data-analytics-tutorial/data-analyst-interview-questions">Top 65+ Data Analyst Interview Questions and Answers [2023]</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_755331403" CREATED="1700685649469" MODIFIED="1700685657626">
<node ID="ID_851705497" CREATED="1700685658492" MODIFIED="1700685658492" LINK="https://www.dataquest.io/blog/data-analyst-skills/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.dataquest.io/blog/data-analyst-skills/">8 Data Analyst Skills Employers Need to See in 2023</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Database Design and Development" FOLDED="true" ID="ID_1132290833" CREATED="1706329368687" MODIFIED="1708466907919">
<node TEXT="reference" FOLDED="true" ID="ID_820279794" CREATED="1706329964599" MODIFIED="1706329967856">
<node ID="ID_839360921" CREATED="1706329400206" MODIFIED="1706329400206" LINK="https://www.lucidchart.com/pages/database-diagram/database-design"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.lucidchart.com/pages/database-diagram/database-design">Database Structure and Design Tutorial | Lucidchart</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1835374865" CREATED="1706331497179" MODIFIED="1706331497179" LINK="https://www.vertabelo.com/blog/entities-attributes-data-model/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.vertabelo.com/blog/entities-attributes-data-model/">The Difference Between Entities and Attributes in a Data Model | Vertabelo Database Modeler</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1790780031" CREATED="1706329969334" MODIFIED="1706329969334" LINK="https://open.umn.edu/opentextbooks/textbooks/354"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://open.umn.edu/opentextbooks/textbooks/354">Database Design - 2nd Edition - Open Textbook Library</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="A well-structured database:" FOLDED="true" ID="ID_647217476" CREATED="1706329475924" MODIFIED="1706329501910">
<node TEXT="saves discs space by eliminating redundant data" ID="ID_1681956108" CREATED="1706329501912" MODIFIED="1706329530549"/>
<node TEXT="maintains data accuracy and integrity" ID="ID_1783065024" CREATED="1706329531759" MODIFIED="1706329540147"/>
<node TEXT="provides access to the data in useful ways" ID="ID_1375377115" CREATED="1706329544354" MODIFIED="1706329554719"/>
</node>
<node TEXT="Designing an efficient, useful database is a matter of following the proper process, including these phases:" FOLDED="true" ID="ID_1353345821" CREATED="1706329574150" MODIFIED="1706329613128">
<node TEXT="1. Requirements analysis, identifying the purpose of your database" ID="ID_271709555" CREATED="1706329613131" MODIFIED="1706329639511"/>
<node TEXT="2. organizing data into tables" ID="ID_104270877" CREATED="1706329639544" MODIFIED="1706329654506"/>
<node TEXT="3. specifying primary keys in analyzing relationships" ID="ID_1258337982" CREATED="1706329654528" MODIFIED="1706329663904"/>
<node TEXT="4. normalizing to standardize the tables" ID="ID_754369853" CREATED="1706329663921" MODIFIED="1706329671142"/>
</node>
<node TEXT="entity-relationship diagram" FOLDED="true" ID="ID_1467556040" CREATED="1706330880734" MODIFIED="1706330893145">
<node TEXT="visual overview of the database" ID="ID_1450722809" CREATED="1706330894315" MODIFIED="1706330899343"/>
<node TEXT="each table is a box" FOLDED="true" ID="ID_109989686" CREATED="1706330958213" MODIFIED="1706330968548">
<node TEXT="title= what the data in that table describes" ID="ID_1701091227" CREATED="1706330969127" MODIFIED="1706330989927"/>
<node TEXT="attributes are listed below" ID="ID_1251542822" CREATED="1706330989949" MODIFIED="1706330998199"/>
<node TEXT="which attribute will serve as the primary key, if any" FOLDED="true" ID="ID_1534509471" CREATED="1706331009462" MODIFIED="1706331025871">
<node TEXT="primary key (PK)" FOLDED="true" ID="ID_1384399926" CREATED="1706331115316" MODIFIED="1706331126376">
<node TEXT="unique identifier for a given entity" ID="ID_1702402830" CREATED="1706331127550" MODIFIED="1706331135150"/>
</node>
</node>
</node>
</node>
<node TEXT="database" FOLDED="true" ID="ID_1847752459" CREATED="1706677691368" MODIFIED="1706677694942">
<node TEXT="tables" FOLDED="true" ID="ID_119464575" CREATED="1706677694945" MODIFIED="1706677704066">
<node TEXT="" ID="ID_1909738" CREATED="1706677711524" MODIFIED="1706677711524"/>
</node>
</node>
</node>
<node TEXT="Data Models" ID="ID_1698975138" CREATED="1708466942223" MODIFIED="1708466959808">
<font ITALIC="true"/>
</node>
<node TEXT="Data Mining" ID="ID_206248189" CREATED="1708466927112" MODIFIED="1708466936915">
<font ITALIC="true"/>
</node>
<node TEXT="Data Segmentation" ID="ID_597541286" CREATED="1708466931250" MODIFIED="1708466935320">
<font ITALIC="true"/>
</node>
<node TEXT="Data Cleaning And Preparation" ID="ID_1332817574" CREATED="1700685683683" MODIFIED="1700685689834"/>
<node TEXT="Data Analysis And Exploration" FOLDED="true" ID="ID_329655715" CREATED="1700685695685" MODIFIED="1700685703235">
<node TEXT="SQL" ID="ID_867713833" CREATED="1696449030675" MODIFIED="1710196640741">
<icon BUILTIN="bookmark"/>
<node TEXT="MySQL" FOLDED="true" ID="ID_952376777" CREATED="1705686790563" MODIFIED="1705686795762">
<node TEXT="Reference Manual" FOLDED="true" ID="ID_1094808557" CREATED="1705691107482" MODIFIED="1705691111173">
<node FOLDED="true" ID="ID_1451938369" CREATED="1706309634682" MODIFIED="1706309634682" LINK="https://www.mysqltutorial.org/mysql-basics/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mysqltutorial.org/mysql-basics/">MySQL Basics</a>
  </body>
</html>
</richcontent>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_69971949" CREATED="1706317705188" MODIFIED="1706317739975"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 1. Querying data
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_588799282" CREATED="1706317705190" MODIFIED="1706317705190" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-select-from/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-select-from/">SELECT FROM </a>– show you how to use a simple <code class="western">SELECT FROM</code>&#xa0;&#xa0;statement to query the data from a single table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1220366473" CREATED="1706317705191" MODIFIED="1706317705191" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-select/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-select/">SELECT</a>&#xa0;– learn how to use the SELECT statement without referencing a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_142987355" CREATED="1706317705192" MODIFIED="1706317739978"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 2. Sorting data
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1954066873" CREATED="1706317705201" MODIFIED="1706317705201" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-order-by/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-order-by/">ORDER BY </a>– show you how to sort the result set using the ORDER BY clause. You will also learn how to use custom sort order with the FIELD function.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1675317742" CREATED="1706317705202" MODIFIED="1706317739979"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 3. Filtering data
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1643176778" CREATED="1706317705208" MODIFIED="1706317705208" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-where/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-where/">WHERE </a>– learn how to use the WHERE clause to filter rows based on specified conditions.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_47411245" CREATED="1706317705209" MODIFIED="1706317705209" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-distinct/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-distinct/">SELECT DISTINCT</a>&#xa0;– show you how to use the DISTINCT operator in the SELECT statement to eliminate duplicate rows in a result set.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_90367819" CREATED="1706317705210" MODIFIED="1706317705210" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-and/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-and/">AND</a>&#xa0;– introduce you to the AND operator to combine Boolean expressions to form a complex condition for filtering data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1796922913" CREATED="1706317705212" MODIFIED="1706317705212" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-or/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-or/">OR</a>– introduce you to the OR operator and show you how to combine the OR operator with the AND operator to filter data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1017940646" CREATED="1706317705213" MODIFIED="1706317705213" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-in/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-in/">IN&#xa0;</a>– show you how to use the IN operator in the WHERE clause to determine if a value matches any value in a set.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1505872547" CREATED="1706317705214" MODIFIED="1706317705214" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-not-in/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-not-in/">NOT IN</a>&#xa0;– negate the IN operator using the NOT operator to check if a value doesn’t match any value in a set.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_559354390" CREATED="1706317705214" MODIFIED="1706317705214" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-between/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-between/">BETWEEN</a>&#xa0;– show you how to query data based on a range using the BETWEEN operator.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_733815901" CREATED="1706317705215" MODIFIED="1706317705215" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-like/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-like/">LIKE &#xa0;</a>– query database on pattern matching using wildcards such as <code class="western">%</code>&#xa0;and <code class="western">_</code>.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1644158089" CREATED="1706317705216" MODIFIED="1706317705216" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-limit/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-limit/">LIMIT</a>&#xa0;– use&#xa0;LIMIT to limit the number of rows returned by the SELECT statement
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1902211438" CREATED="1706317705217" MODIFIED="1706317705217" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-is-null/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-is-null/">IS NULL</a>&#xa0;– test whether a value is NULL or not by using the IS NULL operator.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1699786115" CREATED="1706317705218" MODIFIED="1706317739980"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 4. Joining tables
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node TEXT="SQL Join Diagram" FOLDED="true" ID="ID_1644510053" CREATED="1708632858707" MODIFIED="1708632867521">
<node TEXT="SQL Joins" ID="ID_990902644" CREATED="1708632837106" MODIFIED="1708632852049">
<hook URI="Career%20Management_files/png_11019785430929181354.png" SIZE="0.621118" NAME="ExternalObject"/>
</node>
</node>
<node ID="ID_1773118086" CREATED="1706317705222" MODIFIED="1706317705222" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-alias/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-alias/">Table &amp; Column Aliases </a>– introduce you to table and column aliases.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_459558109" CREATED="1706317705223" MODIFIED="1706317705223" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-join/">Joins</a>&#xa0;&#xa0;– give you an overview of joins supported in MySQL including inner join, left join, and right join.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1304739693" CREATED="1706317705224" MODIFIED="1706317705224" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-inner-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-inner-join/">INNER JOIN </a>– query rows from a table that has matching rows in another table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="most common type of join" ID="ID_1147090090" CREATED="1706332314137" MODIFIED="1706332329262"/>
</node>
<node ID="ID_700644875" CREATED="1706317705225" MODIFIED="1706317705225" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-left-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-left-join/">LEFT JOIN </a>– return all rows from the left table and matching rows from the right table or null if no matching rows are found in the right table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_652217047" CREATED="1706317705226" MODIFIED="1706317705226" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-right-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-right-join/">RIGHT JOIN</a>&#xa0;– return all rows from the right table and matching rows from the left table or null if no matching rows are found in the left table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1155566887" CREATED="1706317705227" MODIFIED="1706317705227" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-self-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-self-join/">Self-join </a>– join a table to itself using a table alias and connect rows within the same table using inner join and left join.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1247267244" CREATED="1706317705228" MODIFIED="1706317705228" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-cross-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-cross-join/">CROSS JOIN</a>&#xa0;– make a Cartesian product of rows from multiple tables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_111288623" CREATED="1706317705228" MODIFIED="1706317739981"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 5. Grouping data
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_204286174" CREATED="1706317705232" MODIFIED="1706317705232" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-group-by/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-group-by/">GROUP BY</a>&#xa0;– show you how to group rows into groups based on columns or expressions.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_634153845" CREATED="1706317705233" MODIFIED="1706317705233" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-having/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-having/">HAVING </a>– filter the groups by a specific condition.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_271825071" CREATED="1706317705234" MODIFIED="1706317705234" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-having-count/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-having-count/">HAVING COUNT</a>&#xa0;– show you how to use the HAVING clause with the COUNT function to filter groups by the number of items.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_825531269" CREATED="1706317705235" MODIFIED="1706317705235" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-rollup/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-rollup/">ROLLUP</a>&#xa0;–&#xa0;generate multiple grouping sets considering a hierarchy between columns specified in the GROUP BY clause.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1851463955" CREATED="1706317705236" MODIFIED="1706317739982"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      &#xa0;Section 6. Subqueries
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_195077693" CREATED="1706317705239" MODIFIED="1706317705239" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-subquery/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-subquery/">Subquery </a>– show you how to nest a query (inner query) within another query (outer query) and use the result of the inner query for the outer query.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1105850487" CREATED="1706317705240" MODIFIED="1706317705240" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-derived-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-derived-table/">Derived table</a>&#xa0;– introduce you to the derived table concept and show you how to use it to simplify complex queries.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_176772986" CREATED="1706317705241" MODIFIED="1706317705241" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-exists/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-exists/">EXISTS</a>&#xa0;– test for the existence of rows.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1920411777" CREATED="1706317705241" MODIFIED="1706317739983"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 7. Set operators
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1754427737" CREATED="1706317705244" MODIFIED="1706317705244" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-union/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-union/">UNION </a>– combine two or more result sets of multiple queries into a single result set.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_102312606" CREATED="1706317705245" MODIFIED="1706317705245" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-except/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-except/">EXCEPT</a>&#xa0;– show you how to use the EXCEPT operator to find the set difference between two sets of data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_149280524" CREATED="1706317705246" MODIFIED="1706317705246" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-intersect/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-intersect/">INTERSECT</a>&#xa0;– show you how to use the INTERSECT operator to find common rows of two or more queries.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1202275042" CREATED="1706317705246" MODIFIED="1706317739984"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 8. Managing databases
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node FOLDED="true" ID="ID_1698307440" CREATED="1706317705250" MODIFIED="1706317705250"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      This section shows you how to manage MySQL databases.
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1105676697" CREATED="1706317705251" MODIFIED="1706317705251" LINK="https://www.mysqltutorial.org/mysql-basics/selecting-a-mysql-database-using-use-statement/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/selecting-a-mysql-database-using-use-statement/">Selecting a database</a>&#xa0;– show you how to use the USE statement to set the current database.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1786571020" CREATED="1706317705252" MODIFIED="1706317705252" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-create-database/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-create-database/">CREATE DATABASE</a>&#xa0;– show you step by step how to create a new database in MySQL Server.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_490370007" CREATED="1706317705253" MODIFIED="1706317705253" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-drop-database/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-drop-database/">DROP DATABASE</a>&#xa0;– walk you through the steps of deleting a database from the database server.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_736932197" CREATED="1706317705254" MODIFIED="1706317739985"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 9. Working with tables
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node FOLDED="true" ID="ID_1004924114" CREATED="1706317705258" MODIFIED="1706317705258"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      This section shows you how to manage the most important database objects in MySQL, including databases and tables.
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1348658167" CREATED="1706317705259" MODIFIED="1706317705259" LINK="https://www.mysqltutorial.org/mysql-administration/mysql-storage-engines/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-administration/mysql-storage-engines/">MySQL storage engines</a>– it is essential to understand the features of each storage engine so that you can use them effectively to maximize the performance of your databases.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1579174606" CREATED="1706317705260" MODIFIED="1706317705260" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-create-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-create-table/">CREATE TABLE </a>– show you how to create new tables in a database using the CREATE TABLE statement.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1484185195" CREATED="1706317705261" MODIFIED="1706317705261" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-data-types/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-data-types/">MySQL data types </a>– show you various data types in MySQL so that you can apply them effectively in designing database tables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="common data types" FOLDED="true" ID="ID_1368471570" CREATED="1706330730350" MODIFIED="1706330739343">
<node TEXT="CHAR - a specific length of text" ID="ID_13312944" CREATED="1706330803340" MODIFIED="1706330803340"/>
<node TEXT="VARCHAR - text of variable lengths" ID="ID_199012170" CREATED="1706330803340" MODIFIED="1706330803340"/>
<node TEXT="TEXT - large amounts of text" ID="ID_635517492" CREATED="1706330803341" MODIFIED="1706330803341"/>
<node TEXT="INT - positive or negative whole number" ID="ID_922700249" CREATED="1706330803342" MODIFIED="1706330803342"/>
<node TEXT="FLOAT, DOUBLE - can also store floating point numbers" ID="ID_1014697391" CREATED="1706330803343" MODIFIED="1706330803343"/>
<node TEXT="BLOB - binary data" ID="ID_758890103" CREATED="1706330803343" MODIFIED="1706330803343"/>
</node>
</node>
<node ID="ID_1370869710" CREATED="1706317705262" MODIFIED="1706317705262" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-auto_increment/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-auto_increment/">AUTO_INCREMENT </a>– show you how to use an AUTO_INCREMENT column to generate unique numbers automatically for the primary key.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_520979746" CREATED="1706317705263" MODIFIED="1706317705263" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-alter-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-alter-table/">ALTER TABLE&#xa0;</a>– learn how to change the structure of a table using the ALTER TABLE statement.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1500189469" CREATED="1706317705263" MODIFIED="1706317705263" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-rename-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-rename-table/">Renaming tables</a>&#xa0;– &#xa0;show you how to rename a table using the RENAME TABLE statement.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_681283170" CREATED="1706317705264" MODIFIED="1706317705264" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-drop-column/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-drop-column/">Removing a&#xa0;column from a table</a>&#xa0;– show you how to use the ALTER TABLE&#xa0;DROP COLUMN statement to remove one or more columns from a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_761750417" CREATED="1706317705265" MODIFIED="1706317705265" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-add-column/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-add-column/">Adding a new column to a table</a>&#xa0;– show you how to add one or more columns to an existing table using the ALTER TABLE ADD COLUMN statement.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1143895523" CREATED="1706317705266" MODIFIED="1706317705266" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-drop-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-drop-table/">DROP TABLE</a>&#xa0;– show you how to remove existing tables using the DROP TABLE statement.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_813333602" CREATED="1706317705267" MODIFIED="1706317705267" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-temporary-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-temporary-table/">Temporary tables </a>– discuss MySQL temporary tables and show you how to manage temporary tables effectively.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="sometimes referred to as preprocessing of the data" ID="ID_1056088040" CREATED="1709235204780" MODIFIED="1709235231012"/>
<node TEXT="data staging" FOLDED="true" ID="ID_1598327360" CREATED="1709235261160" MODIFIED="1709235266959">
<node TEXT="can collect the results of multiple, separate queries" ID="ID_494410195" CREATED="1709235243166" MODIFIED="1709235254162"/>
</node>
<node TEXT="How" FOLDED="true" ID="ID_413830009" CREATED="1709235189152" MODIFIED="1709235191589">
<node ID="ID_1447021998" CREATED="1709233576816" MODIFIED="1709233576816" LINK="https://learnsql.com/blog/what-is-with-clause-sql/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://learnsql.com/blog/what-is-with-clause-sql/">What Is the WITH Clause in SQL?</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="CREATE TABLE" FOLDED="true" ID="ID_704942191" CREATED="1709234465720" MODIFIED="1709234470743">
<node TEXT="adds table into the database" ID="ID_116286753" CREATED="1709234501961" MODIFIED="1709234516594"/>
<node TEXT="use when" FOLDED="true" ID="ID_942213393" CREATED="1709234470746" MODIFIED="1709234474745">
<node TEXT="other people need the table" ID="ID_852676471" CREATED="1709234474747" MODIFIED="1709234550337"/>
<node TEXT="code is difficult to replicate, table is complex" FOLDED="true" ID="ID_1750945746" CREATED="1709234550355" MODIFIED="1709234589991">
<node TEXT="safe for you to access later" ID="ID_1034716294" CREATED="1709234556553" MODIFIED="1709234568174"/>
</node>
</node>
</node>
<node TEXT="CREATE TEMPORARY TABLE" FOLDED="true" ID="ID_919003074" CREATED="1709233465214" MODIFIED="1709233474346">
<node TEXT="use when" ID="ID_955532336" CREATED="1709234441344" MODIFIED="1709234463382"/>
</node>
<node TEXT="SELECT INTO" FOLDED="true" ID="ID_1510803691" CREATED="1709234045478" MODIFIED="1709234055339">
<node TEXT="use when" FOLDED="true" ID="ID_1015903855" CREATED="1709234415951" MODIFIED="1709234429351">
<node TEXT="you don&apos;t need other people using the table" ID="ID_1061175333" CREATED="1709234429354" MODIFIED="1709234434391"/>
</node>
</node>
</node>
</node>
<node ID="ID_566957106" CREATED="1706317705268" MODIFIED="1706317705268" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-truncate-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-truncate-table/">TRUNCATE TABLE </a>– show you how to delete all data from a table quickly and more efficiently using the TRUNCATE TABLE statement.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1097190319" CREATED="1706317705269" MODIFIED="1706317705269" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-generated-columns/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-generated-columns/">Generated columns</a>&#xa0;– guide you on how to use the generated columns to store data computed from an expression or other columns.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1239411610" CREATED="1706317705269" MODIFIED="1706317739986"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 10. MySQL constraints
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_364043263" CREATED="1706317705273" MODIFIED="1706317705273" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-primary-key/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-primary-key/">Primary key</a>&#xa0;– guide you on how to use the primary key constraint to create the primary key for a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1882007693" CREATED="1706317705274" MODIFIED="1706317705274" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-foreign-key/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-foreign-key/">Foreign key</a>&#xa0;– introduce you to the foreign key and show you step by step how to create and drop foreign keys.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1339149279" CREATED="1706317705274" MODIFIED="1706317705274" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-disable-foreign-key-checks/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-disable-foreign-key-checks/">Disable foreign key checks</a>&#xa0;– learn how to disable foreign key checks.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_48696267" CREATED="1706317705275" MODIFIED="1706317705275" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-not-null-constraint/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-not-null-constraint/">NOT NULL</a>– introduce you to the NOT NULL constraint and show you how to declare a&#xa0;NOT NULL column or add a&#xa0;NOT NULL constraint to an existing column.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1744984290" CREATED="1706317705276" MODIFIED="1706317705276" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-unique-constraint/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-unique-constraint/">UNIQUE constraint</a>&#xa0;–&#xa0;show you how to use the UNIQUE constraint to enforce the uniqueness of values in a column or a group of columns in a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_893744510" CREATED="1706317705276" MODIFIED="1706317705276" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-check-constraint/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-check-constraint/">CHECK constraint</a>&#xa0;– learn how to create CHECK constraints to ensure data integrity.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1213713521" CREATED="1706317705277" MODIFIED="1706317705277" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-default/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-default/">DEFAULT</a>&#xa0;– show you how to set a default value for a column using the DEFAULT constraint.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_200044637" CREATED="1706317705277" MODIFIED="1706317739987"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 11. MySQL data types
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_94840783" CREATED="1706317705281" MODIFIED="1706317705281" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-bit/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-bit/">BIT</a>&#xa0;– introduce&#xa0;you to BIT datatype and how to store bit values in MySQL.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1249860639" CREATED="1706317705281" MODIFIED="1706317705281" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-int/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-int/">INT</a>&#xa0;– show you how to use integer data type.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_71434764" CREATED="1706317705282" MODIFIED="1706317705282" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-boolean/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-boolean/">BOOLEAN</a>&#xa0;– explain to you how MySQL handles Boolean values by using TINYINT(1) internally.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1737404856" CREATED="1706317705283" MODIFIED="1706317705283" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-decimal/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-decimal/">DECIMAL</a>&#xa0;–&#xa0;show you how to use DECIMAL datatype to store exact values in decimal format.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1011207649" CREATED="1706317705283" MODIFIED="1706317705283" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-char-data-type/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-char-data-type/">CHAR</a>&#xa0;– a guide to CHAR data type for storing the fixed-length string.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_218538954" CREATED="1706317705284" MODIFIED="1706317705284" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-varchar/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-varchar/">VARCHAR</a>&#xa0;– give you the essential guide to VARCHAR datatype.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1232288660" CREATED="1706317705284" MODIFIED="1706317705284" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-text/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-text/">TEXT</a>&#xa0;– show you how to store text data using TEXT datatype.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1648106951" CREATED="1706317705285" MODIFIED="1706317705285" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-datetime/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-datetime/">DATETIME</a>&#xa0;– introduce you to the DATETIME datatype and some useful functions to manipulate DATETIME values.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1210962882" CREATED="1706317705286" MODIFIED="1706317705286" LINK="https://www.mysqltutorial.org/mysql-basics/understanding-mysql-timestamp/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/understanding-mysql-timestamp/">TIMESTAMP </a>– introduce you to TIMESTAMP and its features called automatic initialization and automatic update, which allow you to define auto-initialized and auto-updated columns for a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1514551104" CREATED="1706317705286" MODIFIED="1706317705286" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-date/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-date/">DATE</a>&#xa0;–&#xa0;introduce you to the DATE datatype and show you some date functions to handle the date data effectively.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_35925291" CREATED="1706317705287" MODIFIED="1706317705287" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-time/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-time/">TIME </a>– walk you through the features of TIME datatype and show you how to use some useful temporal functions to handle time data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1223055228" CREATED="1706317705287" MODIFIED="1706317705287" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-binary/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-binary/">BINARY</a>&#xa0;– show you how to store fixed-length byte data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1158206891" CREATED="1706317705288" MODIFIED="1706317705288" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-varbinary/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-varbinary/">VARBINARY</a>&#xa0;– learn how to store variable-length byte data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1469544875" CREATED="1706317705289" MODIFIED="1706317705289" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-blob/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-blob/">BLOB</a>&#xa0;– guide you on how to use the BLOB data type to store large binary data such as images, videos, and so on.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1102126916" CREATED="1706317705289" MODIFIED="1706317705289" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-enum/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-enum/">ENUM</a>&#xa0;– learn how to use ENUM datatype correctly to store enumeration values.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_303153006" CREATED="1706317705290" MODIFIED="1706317705290" LINK="https://www.mysqltutorial.org/mysql-json/mysql-json-data-type/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-json/mysql-json-data-type/">JSON</a>&#xa0;– show you how to use JSON data type to store JSON documents.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_777673423" CREATED="1706317705290" MODIFIED="1706317705290" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-uuid/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-uuid/">MySQL UUID Smackdown: UUID vs. INT for Primary Key</a>&#xa0;– introduce you to MySQL UUID, shows you how to use it as the primary key (PK) for a table, and discusses the pros and cons of using it as the PK.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_76802179" CREATED="1706317705291" MODIFIED="1706317739987"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 12. Modifying data in MySQL
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node FOLDED="true" ID="ID_1094398212" CREATED="1706317705294" MODIFIED="1706317705294"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      In this section, you will learn how to insert, update, and delete data from tables using various MySQL statements.
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_634751114" CREATED="1706317705296" MODIFIED="1706317705296" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-insert/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-insert/">INSERT&#xa0;</a>– use various forms of the INSERT statement to insert data into a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1871616703" CREATED="1706317705297" MODIFIED="1706317705297" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-insert-multiple-rows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-insert-multiple-rows/">INSERT Multiple Rows</a>&#xa0;– insert multiple rows into a table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1169786478" CREATED="1706317705298" MODIFIED="1706317705298" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-insert-into-select/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-insert-into-select/">INSERT INTO SELECT</a>&#xa0;– insert data into a table from the result set of a query.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1234100209" CREATED="1706317705299" MODIFIED="1706317705299" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-insert-ingore/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-insert-ingore/">INSERT IGNORE</a>&#xa0;&#xa0;– explain the INSERT IGNORE statement that inserts rows into a table and ignores rows that cause errors.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1067674623" CREATED="1706317705300" MODIFIED="1706317705300" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-insert-datetime/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-insert-datetime/">Insert datetime values</a>&#xa0;– show you how to insert datetime values into a DATETIME column.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_73022027" CREATED="1706317705301" MODIFIED="1706317705301" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-insert-date/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-insert-date/">Insert date values</a>&#xa0;– learn how to insert date values into a DATE column.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1708742970" CREATED="1706317705301" MODIFIED="1706317705301" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-update/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-update/">UPDATE&#xa0;</a>– learn how to use the UPDATE statement to update data in database tables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="example" FOLDED="true" ID="ID_23746062" CREATED="1706331899453" MODIFIED="1706331904736">
<node TEXT="UPDATE employees" ID="ID_181373761" CREATED="1706331906339" MODIFIED="1706331906339"/>
<node TEXT="SET" FOLDED="true" ID="ID_585517062" CREATED="1706331906339" MODIFIED="1706331906339">
<node TEXT="lastname = &apos;Hill&apos;," ID="ID_1798724532" CREATED="1706331906341" MODIFIED="1706331906341"/>
<node TEXT="email = &apos;mary.hill@classicmodelcars.com&apos;" ID="ID_781324611" CREATED="1706331906343" MODIFIED="1706331929780"/>
</node>
<node TEXT="WHERE" FOLDED="true" ID="ID_808422983" CREATED="1706331906343" MODIFIED="1706331906343">
<node TEXT="employeeNumber = 1056;" ID="ID_1691825138" CREATED="1706331906344" MODIFIED="1706331906344"/>
</node>
</node>
<node TEXT="UPDATE [LOW_PRIORITY] [IGNORE] table_name" ID="ID_1910564995" CREATED="1706331622178" MODIFIED="1706331622178"/>
<node TEXT="SET" FOLDED="true" ID="ID_137353239" CREATED="1706331622178" MODIFIED="1706331622178">
<node TEXT="column_name1 = expr1," ID="ID_534770370" CREATED="1706331622178" MODIFIED="1706331622178"/>
<node TEXT="column_name2 = expr2," ID="ID_1401844683" CREATED="1706331622178" MODIFIED="1706331622178"/>
<node TEXT="..." ID="ID_1911160842" CREATED="1706331622178" MODIFIED="1706331622178"/>
</node>
<node TEXT="[WHERE" FOLDED="true" ID="ID_173661291" CREATED="1706331622178" MODIFIED="1706331622178">
<node TEXT="condition];" ID="ID_926278125" CREATED="1706331622180" MODIFIED="1706331622180"/>
</node>
</node>
<node ID="ID_1142144560" CREATED="1706317705302" MODIFIED="1706317705302" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-update-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-update-join/">UPDATE JOIN </a>– show you how to perform cross-table updates using the UPDATE JOIN statement with INNER JOIN and LEFT JOIN.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1867274357" CREATED="1706317705303" MODIFIED="1706317705303" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-delete/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-delete/">DELETE </a>– show you how to use the DELETE statement to delete rows from one or more tables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_619831522" CREATED="1706317705304" MODIFIED="1706317705304" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-on-delete-cascade/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-on-delete-cascade/">ON DELETE CASCADE </a>– learn how to use ON DELETE CASCADE referential action for a foreign key to delete data from a child table automatically when you delete data from a parent table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_882563026" CREATED="1706317705305" MODIFIED="1706317705305" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-delete-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-delete-join/">DELETE JOIN </a>– show you how to delete data from multiple tables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1336485410" CREATED="1706317705306" MODIFIED="1706317705306" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-replace/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-replace/">REPLACE&#xa0;</a>– learn how to insert or update data depending on whether data exists in the table or not.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1293806988" CREATED="1706317705306" MODIFIED="1706317739988"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 13. Common Table Expressions
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1556099831" CREATED="1706317705310" MODIFIED="1706317705310" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-cte/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-cte/">Common Table Expression</a>&#xa0;– explain to you the common table expression concept and show you how to use CTE for querying data from tables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1664217389" CREATED="1706317705311" MODIFIED="1706317705311" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-recursive-cte/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-recursive-cte/">Recursive CTE</a>&#xa0;–&#xa0;&#xa0;use the recursive CTE to traverse the hierarchical data.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_369374834" CREATED="1706317705312" MODIFIED="1706317739988"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 14. MySQL Locking
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1288169963" CREATED="1706317705315" MODIFIED="1706317705315" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-table-locking/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-table-locking/">Table locking</a>&#xa0;– learn how to use MySQL locking for cooperating table access between sessions.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_411115894" CREATED="1706317705316" MODIFIED="1706317739990"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 15. MySQL globalization
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_635843829" CREATED="1706317705319" MODIFIED="1706317705319" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-character-set/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-character-set/">Character Set </a>– discuss character set and show you step by step how to perform various operations on character sets.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_408488588" CREATED="1706317705320" MODIFIED="1706317705320" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-collation/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-collation/">Collation </a>– discuss collation and show you how to set character sets and collations for the MySQL server, database, tables, and columns.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_96881329" CREATED="1706317705320" MODIFIED="1706317739990"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 16. User-defined variables
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1210858257" CREATED="1706317705326" MODIFIED="1706317705326" LINK="https://www.mysqltutorial.org/mysql-basics/import-csv-file-mysql-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/import-csv-file-mysql-table/">Import CSV File Into MySQL Table</a>&#xa0;– show you how to use LOAD DATA INFILE statement to import CSV files into a MySQL table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_589663170" CREATED="1706317705327" MODIFIED="1706317705327" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-export-table-to-csv/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-export-table-to-csv/">Export MySQL Table to CSV</a>&#xa0;– &#xa0;learn various techniques of how to export MySQL table to a CSV file format.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1428156559" CREATED="1706317705328" MODIFIED="1706317739991"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 17. MySQL import &amp; export CSV
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_1870193130" CREATED="1706317705335" MODIFIED="1706317705335" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-variables/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-variables/">User-defined Variables</a>&#xa0;– learn how to use MySQL user-defined variables in SQL statements.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1593465275" CREATED="1706317705336" MODIFIED="1706317705336" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-select-into-variable/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-select-into-variable/">SELECT INTO Variable</a>&#xa0;– show you how to use the MySQL SELECT INTO variable&#xa0;to store query results in one or more variables.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,14" FOLDED="true" ID="ID_1658745984" CREATED="1706317705337" MODIFIED="1706317739991"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 class="western">
      Section 18. Advanced techniques
    </h2>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
<node ID="ID_719198803" CREATED="1706317705340" MODIFIED="1706317705340" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-natural-sorting/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-natural-sorting/">Natural sorting</a>&#xa0;– walk you through various natural sorting techniques in MySQL using the ORDER BY clause.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1476474517" CREATED="1706317705341" MODIFIED="1706317705341" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-row-count/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-row-count/">Get Row Count in MySQL</a>&#xa0;– show you various ways to get MySQL row count in the MySQL database.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1198508576" CREATED="1706317705342" MODIFIED="1706317705342" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-compare-two-tables/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-compare-two-tables/">Compare Two Tables</a>&#xa0;– show you how to compare two tables to find the unmatched records in MySQL
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1197066401" CREATED="1706317705342" MODIFIED="1706317705342" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-find-duplicate-values/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-find-duplicate-values/">Find Duplicate Values</a>&#xa0;– show you step by step how to find duplicate values in one or more columns in MySQL.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_238253248" CREATED="1706317705344" MODIFIED="1706317705344" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-delete-duplicate-rows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-delete-duplicate-rows/">Delete Duplicate Rows</a>&#xa0;– learn how to delete duplicate rows in MySQL by using the DELETE JOIN statement or an immediate table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1864998622" CREATED="1706317705344" MODIFIED="1706317705344" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-copy-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-copy-table/">Copy Tables</a>&#xa0;– copy tables within the same database or from one database to another using CREATE TABLE LIKE and SELECT statements in MySQL.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_660178230" CREATED="1706317705345" MODIFIED="1706317705345" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-compare-rows-within-the-same-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-compare-rows-within-the-same-table/">Compare Successive Rows within the same table</a>&#xa0;– how to compare successive rows within the same table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_138109615" CREATED="1706317705346" MODIFIED="1706317705346" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-select-random/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-select-random/">Select Random Records</a>&#xa0;– Show you various techniques to select random records from a database table.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_151445377" CREATED="1706317705347" MODIFIED="1706317705347" LINK="https://www.mysqltutorial.org/mysql-basics/select-the-nth-highest-record-in-a-database-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/select-the-nth-highest-record-in-a-database-table/">Select The nth Highest Record</a>&#xa0;– learn how to the nth highest record in a database table using various techniques.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1112459063" CREATED="1706317705348" MODIFIED="1706317705348" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-reset-auto-increment-value/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-reset-auto-increment-value/">Reset Auto Increment Values</a>&#xa0;– reset auto-increment values of AUTO_INCREMENT columns.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_197919422" CREATED="1706317705348" MODIFIED="1706317705348" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-comment/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-comment/">MySQL Comments</a>&#xa0;– show you how to use MySQL comments to document an SQL statement or a block of code.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1395381242" CREATED="1706317705349" MODIFIED="1706317705349" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-null/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-null/">MySQL NULL</a>&#xa0;– learn how to work with MySQL NULL values. In addition, you’ll learn some useful functions to deal with the NULL values effectively.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1928549000" CREATED="1706317705349" MODIFIED="1706317705349" LINK="https://www.mysqltutorial.org/mysql-basics/avoid-displaying-null-values-by-mapping-to-other-values/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/avoid-displaying-null-values-by-mapping-to-other-values/">Map NULL to Meaningful Values</a>&#xa0;– map NULL to other values for a better data representation.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1145756729" CREATED="1706317705350" MODIFIED="1706317705350" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-adjacency-list-tree/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-adjacency-list-tree/">Managing Hierarchical Data in MySQL Using the Adjacency List Model</a>&#xa0;&#xa0;– learn how to use the adjacency list model for managing hierarchical data in MySQL.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_37734402" CREATED="1706317705353" MODIFIED="1706317705353" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-interval/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p style="margin-bottom: 0in">
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-interval/">MySQL Interval</a>&#xa0;– show you how to use the MySQL interval for date and time arithmetic with many practical examples.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_586577969" CREATED="1706317705353" MODIFIED="1706317705353" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-commands/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li>
        <p>
          <a href="https://www.mysqltutorial.org/mysql-basics/mysql-commands/">MySQL commands</a>&#xa0;– learn how to use the most commonly used mysql commands for mysql client.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_626767816" CREATED="1705692910615" MODIFIED="1705692910615" LINK="https://www.interviewbit.com/blog/mysql-commands/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.interviewbit.com/blog/mysql-commands/">MySQL Commands: Full List With Examples - InterviewBit</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_786807166" CREATED="1705687778976" MODIFIED="1705687778976" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-create-database/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mysqltutorial.org/mysql-basics/mysql-create-database/">MySQL CREATE DATABASE - Creating a New Database in MySQL</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Backup And Recovery" FOLDED="true" ID="ID_1714362245" CREATED="1705691088394" MODIFIED="1705691095985">
<node ID="ID_945840718" CREATED="1705691096983" MODIFIED="1705691096983" LINK="https://dev.mysql.com/doc/refman/8.0/en/backup-and-recovery.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/backup-and-recovery.html">MySQL :: MySQL 8.0 Reference Manual :: 7 Backup and Recovery</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Commands" FOLDED="true" ID="ID_497594502" CREATED="1706133967344" MODIFIED="1706807913605">
<node TEXT="naming conventions" FOLDED="true" ID="ID_1803688313" CREATED="1707690829405" MODIFIED="1707690832537">
<node TEXT="COMMANDS" ID="ID_942626096" CREATED="1707690835686" MODIFIED="1707690842521"/>
<node TEXT="table_names" FOLDED="true" ID="ID_861459050" CREATED="1707690853654" MODIFIED="1707690861001">
<node TEXT="must begin with a letter, contain only letters, numbers, and _" ID="ID_308862696" CREATED="1711053471888" MODIFIED="1711053491248"/>
</node>
</node>
<node TEXT="comments" FOLDED="true" ID="ID_1637109531" CREATED="1706822827001" MODIFIED="1706822830681">
<node TEXT="/* comment block */" ID="ID_746364337" CREATED="1706822830686" MODIFIED="1706822859526"/>
<node TEXT="-- comment (--space comment)" ID="ID_789303184" CREATED="1706822846019" MODIFIED="1711062410319"/>
</node>
<node TEXT="General functions" FOLDED="true" ID="ID_22068228" CREATED="1707606125029" MODIFIED="1707606130489">
<node FOLDED="true" ID="ID_2378379" CREATED="1708643412689" MODIFIED="1708643412689" LINK="https://www.mysqltutorial.org/mysql-aggregate-functions/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mysqltutorial.org/mysql-aggregate-functions/">MySQL Aggregate Functions</a>
  </body>
</html>
</richcontent>
<node TEXT="AVG" ID="ID_1700468584" CREATED="1708643446399" MODIFIED="1708643448398"/>
<node TEXT="COUNT" ID="ID_438102985" CREATED="1708643449013" MODIFIED="1708643450745"/>
<node TEXT="SUM" ID="ID_1305174993" CREATED="1708643451631" MODIFIED="1708643457267"/>
<node TEXT="MAX" ID="ID_811430160" CREATED="1708643457855" MODIFIED="1708643460228"/>
<node TEXT="MIN" ID="ID_1391665526" CREATED="1708643460486" MODIFIED="1708643462134"/>
</node>
<node TEXT="window functions" FOLDED="true" ID="ID_657322679" CREATED="1707606131605" MODIFIED="1707606144445">
<node ID="ID_1435958935" CREATED="1707608713515" MODIFIED="1707608713515" LINK="https://www.sqltutorial.org/sql-window-functions/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sqltutorial.org/sql-window-functions/">SQL Window Functions</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="ranking functions" FOLDED="true" ID="ID_1089815761" CREATED="1707606144449" MODIFIED="1707606147604">
<node ID="ID_240252337" CREATED="1707606149099" MODIFIED="1707606149099" LINK="https://learnsql.com/blog/how-to-rank-rows-in-sql/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://learnsql.com/blog/how-to-rank-rows-in-sql/">How to Rank Rows in SQL: A Complete Guide</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Connecting And Disconnecting from Server" FOLDED="true" ID="ID_1706897956" CREATED="1705789625219" MODIFIED="1705789663628">
<node TEXT="$&gt;mysql -h host -u user -p [database]" ID="ID_812908723" CREATED="1706141726876" MODIFIED="1706141738538"/>
</node>
<node ID="ID_1950236248" CREATED="1706141664823" MODIFIED="1706141699212"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      CREATE DATABASE <i>database</i>;
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1069692315" CREATED="1706141531031" MODIFIED="1706141539212"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      USE <i>database</i>
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="CREATE TABLE tablename (column_name type, ...);" FOLDED="true" ID="ID_153424723" CREATED="1706141835519" MODIFIED="1706141878338">
<node TEXT="CREATE TABLE pet (name VARCHAR(20), owner VARCHAR(20), species VARCHAR(20), sex CHAR(1), birth DATE, death DATE);" ID="ID_965331981" CREATED="1706142206282" MODIFIED="1706142304857"/>
</node>
<node TEXT="Load external Data into table" FOLDED="true" ID="ID_698513081" CREATED="1706141988439" MODIFIED="1711078470129">
<node TEXT="small datasets" FOLDED="true" ID="ID_91837589" CREATED="1711053518046" MODIFIED="1711053528012">
<node TEXT="Workbench" FOLDED="true" ID="ID_1032627470" CREATED="1711052124495" MODIFIED="1711052127128">
<node ID="ID_1000500580" CREATED="1711052128411" MODIFIED="1711052128411" LINK="https://dev.mysql.com/doc/workbench/en/wb-admin-export-import-table.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/workbench/en/wb-admin-export-import-table.html">MySQL :: MySQL Workbench Manual :: 6.5.1 Table Data Export and Import Wizard</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Table Data Import Wizard" FOLDED="true" ID="ID_545104117" CREATED="1711052177374" MODIFIED="1711052316276">
<node TEXT="change csv settings" FOLDED="true" ID="ID_1461679390" CREATED="1711052317281" MODIFIED="1711052337696">
<node TEXT="Field Separator:" ID="ID_1956078751" CREATED="1711052339014" MODIFIED="1711052683864"/>
</node>
</node>
</node>
<node TEXT="large datasets" FOLDED="true" ID="ID_1643451957" CREATED="1711053690524" MODIFIED="1711078365539">
<node TEXT="import first 10 rows as small dataset" ID="ID_1970505499" CREATED="1711064433460" MODIFIED="1711064451536"/>
<node TEXT="DELETE FROM new_table" ID="ID_950443606" CREATED="1711064458071" MODIFIED="1711064474760"/>
<node TEXT="LOAD DATA LOCAL INFILE &apos;C:/filename.txt&apos; -- forward slashes" ID="ID_1817107221" CREATED="1711062539282" MODIFIED="1711064740226"/>
<node TEXT="INTO TABLE tablename" ID="ID_1291804682" CREATED="1711062539282" MODIFIED="1711062539282"/>
<node TEXT="FIELDS TERMINATED BY &apos;,&apos;  -- Specify the delimiter here" ID="ID_303302123" CREATED="1711062539283" MODIFIED="1711062539283"/>
<node TEXT="OPTIONALLY ENCLOSED BY &apos;&quot;&apos; -- Specify if fields are enclosed by a character" ID="ID_551265969" CREATED="1711062539284" MODIFIED="1711062539284"/>
<node TEXT="LINES TERMINATED BY &apos;\r&apos;  -- Specify line terminator if different from newline" ID="ID_1212478313" CREATED="1711062539285" MODIFIED="1711064394825"/>
<node TEXT="IGNORE 1 LINES -- Skip first row" ID="ID_511758824" CREATED="1711064050740" MODIFIED="1711064063424"/>
<node TEXT="reference" FOLDED="true" ID="ID_806188059" CREATED="1711063904942" MODIFIED="1711063907091">
<node ID="ID_1861185054" CREATED="1711063908306" MODIFIED="1711063908306" LINK="https://dev.mysql.com/doc/refman/8.0/en/load-data.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/load-data.html">MySQL :: MySQL 8.0 Reference Manual :: 15.2.9 LOAD DATA Statement</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="single rows" FOLDED="true" ID="ID_1301744087" CREATED="1711053704940" MODIFIED="1711053707781">
<node TEXT=" INSERT INTO" FOLDED="true" ID="ID_1371590940" CREATED="1706319836216" MODIFIED="1706319842284">
<node TEXT="table as row" FOLDED="true" ID="ID_913007226" CREATED="1706319847928" MODIFIED="1706319868506">
<node TEXT="mysql&gt; INSERT INTO pet VALUES (&apos;Puffball&apos;,&apos;Diane&apos;,&apos;hamster&apos;,&apos;f&apos;,&apos;1999-03-30&apos;,NULL);" ID="ID_945326364" CREATED="1706142499076" MODIFIED="1706142511610"/>
</node>
<node TEXT="particular columns" FOLDED="true" ID="ID_1915900335" CREATED="1706319878399" MODIFIED="1706319882433">
<node TEXT="INSERT INTO Customers (CustomerName, City, Country)&#xa;VALUES (&apos;Cardinal&apos;, &apos;Stavanger&apos;, &apos;Norway&apos;);" ID="ID_1350320827" CREATED="1706319820712" MODIFIED="1706319825122"/>
</node>
</node>
</node>
<node TEXT="if error" FOLDED="true" ID="ID_1814494209" CREATED="1711061593451" MODIFIED="1711061604269">
<node TEXT="Enabling or Disabling Local Data Loading Capability" FOLDED="true" ID="ID_338785022" CREATED="1705791183827" MODIFIED="1705791187294">
<node TEXT="Both the server and the client can restrict use of the LOCAL keyword for LOAD DATA and LOAD XML. The same error message is produced if either one blocks it." ID="ID_909038834" CREATED="1711078160559" MODIFIED="1711078160559"/>
<node TEXT="To cause the server to permit access, set the local_infile variable with SET GLOBAL local_infile = 1; or check it with SHOW GLOBAL VARIABLES LIKE &apos;local_infile&apos;;. Alternatively, edit mysql&apos;s config to include local_infile=1." FOLDED="true" ID="ID_1323610018" CREATED="1711078160559" MODIFIED="1711078160559">
<node TEXT="edit config" FOLDED="true" ID="ID_1566205476" CREATED="1711078265106" MODIFIED="1711078308907">
<font BOLD="true"/>
<node TEXT="For default installation of MySQL 8.0.20:" ID="ID_556637278" CREATED="1711078269781" MODIFIED="1711078269781"/>
<node TEXT="i) Look for the initialization file located at C:\ProgramData\MySQL\MySQL Server 8.0\my.ini." ID="ID_980017879" CREATED="1711078269781" MODIFIED="1711078269781"/>
<node TEXT="ii) Open my.ini file with notepad." ID="ID_192940520" CREATED="1711078269783" MODIFIED="1711078269783"/>
<node TEXT="iii) Look for the headers [client], [mysql] under the CLIENT section &amp; [mysqld] under the SERVER section." ID="ID_1324212329" CREATED="1711078269787" MODIFIED="1711078269787"/>
<node TEXT="iv) Add the following statement under each header:" ID="ID_623161145" CREATED="1711078269788" MODIFIED="1711078269788"/>
<node TEXT="local_infile=ON" ID="ID_700072864" CREATED="1711078269789" MODIFIED="1711078269789"/>
<node TEXT="v) Save the file and restart MySQL80 service under the Windows local services." ID="ID_44666763" CREATED="1711078269790" MODIFIED="1711078269790"/>
<node TEXT="It should work" ID="ID_263832145" CREATED="1711078269790" MODIFIED="1711078269790"/>
</node>
</node>
<node TEXT="To cause Workbench to permit access, edit the connection (click the wrench icon by the MySQL Connections, or right-click on a particular connection and choose Edit Connection...). On the Advanced tab, in the &quot;Others:&quot; box, add the line OPT_LOCAL_INFILE=1" ID="ID_1889615494" CREATED="1711078160562" MODIFIED="1711078303726">
<font BOLD="true"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_849022225" CREATED="1711055766171" MODIFIED="1711055767969">
<node ID="ID_1805455873" CREATED="1711055758540" MODIFIED="1711055758540" LINK="https://stackoverflow.com/questions/31450389/connect-with-local-infile-option-in-mysql-workbench"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/31450389/connect-with-local-infile-option-in-mysql-workbench">Connect with local-infile Option in MySql Workbench - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1802380847" CREATED="1705791284892" MODIFIED="1705791284892" LINK="https://stackoverflow.com/questions/59993844/error-loading-local-data-is-disabled-this-must-be-enabled-on-both-the-client"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/59993844/error-loading-local-data-is-disabled-this-must-be-enabled-on-both-the-client">mysql - ERROR: Loading local data is disabled - this must be enabled on both the client and server sides - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="SHOW TABLES;" ID="ID_329799783" CREATED="1706141812959" MODIFIED="1706141817691"/>
<node TEXT="DESCRIBE table_name" ID="ID_1841488331" CREATED="1706141906966" MODIFIED="1706141923609"/>
<node TEXT="Add column" FOLDED="true" ID="ID_1227564486" CREATED="1711080377413" MODIFIED="1711080382625">
<node TEXT="just column" FOLDED="true" ID="ID_699232923" CREATED="1711080507814" MODIFIED="1711080551479">
<node TEXT="ALTER TABLE table_name" ID="ID_1928420576" CREATED="1711080561712" MODIFIED="1711080561712"/>
<node TEXT="ADD COLUMN column_name datatype;" ID="ID_1451862100" CREATED="1711080561712" MODIFIED="1711080561712"/>
</node>
<node TEXT="computed column" FOLDED="true" ID="ID_139143235" CREATED="1711080551939" MODIFIED="1711080556473">
<node ID="ID_1925601383" CREATED="1711081027754" MODIFIED="1711081027754" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-generated-columns/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mysqltutorial.org/mysql-basics/mysql-generated-columns/">How to Use MySQL Generated Column Effectively</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1505901400" CREATED="1711080501022" MODIFIED="1711080503911">
<node ID="ID_1827759953" CREATED="1711080505023" MODIFIED="1711080505023" LINK="https://database.guide/add-a-computed-column-to-an-existing-table-in-sql-server/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://database.guide/add-a-computed-column-to-an-existing-table-in-sql-server/">Add a Computed Column to an Existing Table in SQL Server</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="DELETE FROM" FOLDED="true" ID="ID_1139214799" CREATED="1706142974134" MODIFIED="1706143540438">
<node TEXT="FROM which_table" FOLDED="true" ID="ID_1790306788" CREATED="1706142805272" MODIFIED="1711065921686">
<font BOLD="true"/>
<node TEXT="all rows" FOLDED="true" ID="ID_472916922" CREATED="1711062305837" MODIFIED="1711062309693">
<node TEXT="DELETE FROM test_tripdata;" ID="ID_1294025129" CREATED="1711062311080" MODIFIED="1711062311080"/>
</node>
</node>
<node TEXT="WHERE conditions_to_satisfy;" FOLDED="true" ID="ID_1034185192" CREATED="1706142805274" MODIFIED="1706142805274">
<node ID="ID_792997751" CREATED="1706141319728" MODIFIED="1706141458611"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      WHERE <i>identifier</i>&#xa0;&#xa0;= '&#xa0;&#xa0;'
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="comparison operators" FOLDED="true" ID="ID_1005182458" CREATED="1706143103040" MODIFIED="1706143266601">
<font NAME="Arial"/>
<node TEXT="&apos;=" ID="ID_751522511" CREATED="1706143125040" MODIFIED="1706143127521"/>
<node TEXT="IN" FOLDED="true" ID="ID_307990934" CREATED="1706151733187" MODIFIED="1706151736249">
<node TEXT="IN (&apos;Menachem Begin&apos;, &apos;Yitzhak Rabin&apos;)" ID="ID_170245508" CREATED="1706151752608" MODIFIED="1706151752608"/>
</node>
<node TEXT="&lt;&gt;" ID="ID_728836255" CREATED="1706143319133" MODIFIED="1706143324033"/>
<node TEXT="&gt;=" ID="ID_1831145379" CREATED="1706143128774" MODIFIED="1706143135729"/>
<node TEXT="&gt;" ID="ID_228931899" CREATED="1706143330766" MODIFIED="1706143332480"/>
<node TEXT="BETWEEN" FOLDED="true" ID="ID_335889999" CREATED="1706154597198" MODIFIED="1706154602176">
<node TEXT="BETWEEN 200 AND 600" ID="ID_1015602639" CREATED="1706154616259" MODIFIED="1706154616259"/>
</node>
<node TEXT="LIKE" FOLDED="true" ID="ID_1762477170" CREATED="1706143252038" MODIFIED="1706143254923">
<node ID="ID_916490582" CREATED="1706143292651" MODIFIED="1706143292651" LINK="https://dev.mysql.com/doc/refman/8.0/en/pattern-matching.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/pattern-matching.html">MySQL :: MySQL 8.0 Reference Manual :: 3.3.4.7 Pattern Matching</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="_" FOLDED="true" ID="ID_1935899307" CREATED="1706144109525" MODIFIED="1706144111721">
<node TEXT="any single character" ID="ID_1710274350" CREATED="1706144112740" MODIFIED="1706144117897"/>
</node>
<node TEXT="%" FOLDED="true" ID="ID_200136540" CREATED="1706143689685" MODIFIED="1706143695648">
<node TEXT="unknown string of 0 or more characters" ID="ID_322678066" CREATED="1706143698749" MODIFIED="1706143807808"/>
</node>
<node TEXT="extended regular expressions" FOLDED="true" ID="ID_866979982" CREATED="1706144139604" MODIFIED="1706144145520">
<node TEXT="." FOLDED="true" ID="ID_428171408" CREATED="1706143848445" MODIFIED="1706143851177">
<node TEXT="single character" ID="ID_1253422619" CREATED="1706143853045" MODIFIED="1706143873865"/>
</node>
<node TEXT="[...]" FOLDED="true" ID="ID_1569907253" CREATED="1706143893693" MODIFIED="1706143908305">
<node TEXT="character class" ID="ID_1442114189" CREATED="1706143909617" MODIFIED="1706143916144"/>
<node TEXT="[abc]" FOLDED="true" ID="ID_1929483253" CREATED="1706143916669" MODIFIED="1706143925151">
<node TEXT="matches a, b, or c" ID="ID_1059216940" CREATED="1706143925749" MODIFIED="1706143933952"/>
</node>
<node TEXT="[a-z]" FOLDED="true" ID="ID_941077564" CREATED="1706143941180" MODIFIED="1706143947113">
<node TEXT="matches range a-z (any letter)" ID="ID_869414235" CREATED="1706143947917" MODIFIED="1706143962944"/>
</node>
<node TEXT="[0-9]" FOLDED="true" ID="ID_87270170" CREATED="1706143964901" MODIFIED="1706143974039">
<node TEXT="matches any digit" ID="ID_466217861" CREATED="1706143975093" MODIFIED="1706143981625"/>
</node>
</node>
<node TEXT="x*" FOLDED="true" ID="ID_239580988" CREATED="1706143993557" MODIFIED="1706144063993">
<node TEXT="zero or more instances of the thing preceding it" ID="ID_719111578" CREATED="1706144002020" MODIFIED="1706144014192"/>
<node TEXT="x*" FOLDED="true" ID="ID_1955359935" CREATED="1706144017718" MODIFIED="1706144023168">
<node TEXT="matches any number of x characters" ID="ID_665690667" CREATED="1706144024316" MODIFIED="1706144039865"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="logical" FOLDED="true" ID="ID_1861198932" CREATED="1706143137934" MODIFIED="1706143140891">
<node TEXT="NOT" ID="ID_1348236638" CREATED="1706152420502" MODIFIED="1706152423002"/>
<node TEXT="AND" ID="ID_455276251" CREATED="1706143141366" MODIFIED="1706143144153"/>
<node TEXT="OR" ID="ID_323193860" CREATED="1706143144471" MODIFIED="1706143146320"/>
</node>
</node>
</node>
<node TEXT="evaluation order" FOLDED="true" ID="ID_264456549" CREATED="1706811288986" MODIFIED="1706811292115">
<node TEXT="FROM" ID="ID_1805883047" CREATED="1706819365133" MODIFIED="1706819365133"/>
<node TEXT="ON" ID="ID_20118232" CREATED="1706819365133" MODIFIED="1706819365133"/>
<node TEXT="JOIN" ID="ID_1807157760" CREATED="1706819365135" MODIFIED="1706819365135"/>
<node TEXT="WHERE" ID="ID_1705096437" CREATED="1706819365139" MODIFIED="1706819365139"/>
<node TEXT="GROUP BY" ID="ID_702942955" CREATED="1706819365141" MODIFIED="1706819365141"/>
<node TEXT="WITH CUBE or WITH ROLLUP" ID="ID_1310724082" CREATED="1706819365142" MODIFIED="1706819365142"/>
<node TEXT="HAVING" ID="ID_707117891" CREATED="1706819365144" MODIFIED="1706819365144"/>
<node TEXT="SELECT" ID="ID_1112059993" CREATED="1706819365145" MODIFIED="1706819365145"/>
<node TEXT="DISTINCT" ID="ID_87236094" CREATED="1706819365147" MODIFIED="1706819365147"/>
<node TEXT="ORDER BY" ID="ID_1160988845" CREATED="1706819365149" MODIFIED="1706819365149"/>
<node TEXT="TOP" ID="ID_1227925022" CREATED="1706819365151" MODIFIED="1706819365151"/>
</node>
<node TEXT="SELECT what_to_select -- Query" FOLDED="true" ID="ID_1509000546" CREATED="1706141063168" MODIFIED="1711065857152">
<font BOLD="true"/>
<node TEXT="* -- everything" ID="ID_1800186781" CREATED="1706141300895" MODIFIED="1711065193216"/>
<node FOLDED="true" ID="ID_1458002623" CREATED="1706142894060" MODIFIED="1706142894060" LINK="https://dev.mysql.com/doc/refman/8.0/en/retrieving-data.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/retrieving-data.html">MySQL :: MySQL 8.0 Reference Manual :: 3.3.4 Retrieving Information from a Table</a>
  </body>
</html>
</richcontent>
<node ID="ID_1332737320" CREATED="1706141281132" MODIFIED="1706141281132" LINK="https://dev.mysql.com/doc/refman/8.0/en/entering-queries.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/entering-queries.html">MySQL :: MySQL 8.0 Reference Manual :: 3.2 Entering Queries</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Query Operators" FOLDED="true" ID="ID_151207321" CREATED="1696473242110" MODIFIED="1696473247138">
<node TEXT="reference" FOLDED="true" ID="ID_1365145550" CREATED="1696473251030" MODIFIED="1696473253347">
<node ID="ID_124562399" CREATED="1711078556945" MODIFIED="1711078556945" LINK="https://www.w3schools.com/sql/sql_operators.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.w3schools.com/sql/sql_operators.asp">SQL Operators</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_487841504" CREATED="1696473254384" MODIFIED="1696473254384" LINK="https://docs.snowflake.com/en/sql-reference/operators"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.snowflake.com/en/sql-reference/operators">Query Operators | Snowflake Documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Arithmetic" FOLDED="true" ID="ID_557013750" CREATED="1696473268626" MODIFIED="1696473271953">
<node TEXT="+" ID="ID_1716486874" CREATED="1696473273179" MODIFIED="1696473275551"/>
<node TEXT="-" ID="ID_1687269436" CREATED="1696473276354" MODIFIED="1696473278524"/>
<node TEXT="*" ID="ID_449167554" CREATED="1696473278537" MODIFIED="1696473281926"/>
<node TEXT="/" ID="ID_547363038" CREATED="1696473281938" MODIFIED="1696473284301"/>
<node TEXT="%" ID="ID_133501649" CREATED="1696473284316" MODIFIED="1696473287208"/>
</node>
<node TEXT="Comparison" FOLDED="true" ID="ID_1958541319" CREATED="1711066460286" MODIFIED="1711066463003">
<node TEXT="&apos;=        Equal to" ID="ID_1025461482" CREATED="1711078527196" MODIFIED="1711078542161"/>
<node TEXT="&gt;        Greater than" ID="ID_1360145372" CREATED="1711078527196" MODIFIED="1711078527196"/>
<node TEXT="&lt;        Less than" ID="ID_1220022328" CREATED="1711078527575" MODIFIED="1711078527575"/>
<node TEXT="&gt;=        Greater than or equal to" ID="ID_779251710" CREATED="1711078527578" MODIFIED="1711078527578"/>
<node TEXT="&lt;=        Less than or equal to" ID="ID_521482654" CREATED="1711078527579" MODIFIED="1711078527579"/>
<node TEXT="&lt;&gt;        Not equal to" ID="ID_1701121668" CREATED="1711078527581" MODIFIED="1711078527581"/>
</node>
<node TEXT="Logical / Boolean" FOLDED="true" ID="ID_1643446455" CREATED="1696473291357" MODIFIED="1696473311131">
<node TEXT="ALL        TRUE if all of the subquery values meet the condition" ID="ID_1945936887" CREATED="1711078615164" MODIFIED="1711078615164"/>
<node TEXT="AND        TRUE if all the conditions separated by AND is TRUE" FOLDED="true" ID="ID_31928968" CREATED="1711078615164" MODIFIED="1711078615164">
<node TEXT="SELECT * FROM employees" ID="ID_1151947764" CREATED="1711065886442" MODIFIED="1711065886442"/>
<node TEXT="WHERE (department = &apos;HR&apos; OR department = &apos;Finance&apos;) AND age &gt; 30;" ID="ID_464384269" CREATED="1711065886442" MODIFIED="1711065886442"/>
<node TEXT="WHERE subject = &apos;Chemistry&apos; AND year&gt;=1965 AND year&lt;=1975;" ID="ID_762214365" CREATED="1696471978180" MODIFIED="1696471986945"/>
</node>
<node TEXT="ANY        TRUE if any of the subquery values meet the condition" ID="ID_919516533" CREATED="1711078615168" MODIFIED="1711078615168"/>
<node TEXT="BETWEEN        TRUE if the operand is within the range of comparisons" ID="ID_185851224" CREATED="1711078615170" MODIFIED="1711078615170"/>
<node TEXT="EXISTS        TRUE if the subquery returns one or more records" ID="ID_1871406583" CREATED="1711078615171" MODIFIED="1711078615171"/>
<node TEXT="IN        TRUE if the operand is equal to one of a list of expressions" FOLDED="true" ID="ID_1510974177" CREATED="1711078615174" MODIFIED="1711078615174">
<node TEXT="IN (&apos;Menachem Begin&apos;, &apos;Yitzhak Rabin&apos;)" ID="ID_579653997" CREATED="1696472142177" MODIFIED="1696472188476"/>
</node>
<node TEXT="LIKE        TRUE if the operand matches a pattern" FOLDED="true" ID="ID_1482173370" CREATED="1711078615175" MODIFIED="1711078615175">
<node TEXT="LIKE &apos;P%&apos; OR name LIKE &apos;%s&apos;;" FOLDED="true" ID="ID_1648600243" CREATED="1696470887170" MODIFIED="1696470893998">
<node TEXT="starts with P" ID="ID_1644395858" CREATED="1696470896650" MODIFIED="1696470900074"/>
<node TEXT="wildcards" FOLDED="true" ID="ID_547447124" CREATED="1696470913510" MODIFIED="1696470916351">
<node TEXT="_ letter" ID="ID_381972245" CREATED="1696470918490" MODIFIED="1696470924968"/>
<node TEXT="% string" ID="ID_1789048953" CREATED="1696470926504" MODIFIED="1696470930372"/>
</node>
</node>
</node>
<node TEXT="NOT        Displays a record if the condition(s) is NOT TRUE" FOLDED="true" ID="ID_1451449973" CREATED="1711078615175" MODIFIED="1711078615175">
<node TEXT="SELECT * FROM employees" ID="ID_1144988052" CREATED="1711065874966" MODIFIED="1711065874966"/>
<node TEXT="WHERE NOT department = &apos;HR&apos;;" ID="ID_1582677755" CREATED="1711065874966" MODIFIED="1711065874966"/>
<node TEXT="NOT NULL" ID="ID_1052607153" CREATED="1696470949459" MODIFIED="1696470954313"/>
</node>
<node TEXT="OR        TRUE if any of the conditions separated by OR is TRUE" ID="ID_1622192801" CREATED="1711078615176" MODIFIED="1711078615176"/>
<node TEXT="SOME        TRUE if any of the subquery values meet the condition" ID="ID_1223428221" CREATED="1711078615177" MODIFIED="1711078615177"/>
</node>
</node>
<node TEXT="SQL functions" FOLDED="true" ID="ID_1651557917" CREATED="1706141776783" MODIFIED="1706332110286">
<node TEXT="NOW()" ID="ID_1226454929" CREATED="1706141785817" MODIFIED="1706141790091"/>
<node TEXT="DATABASE()" ID="ID_214244319" CREATED="1706141790488" MODIFIED="1706141795658"/>
<node TEXT="AVG(what_to_select)" ID="ID_1685877650" CREATED="1706154686826" MODIFIED="1706154714550"/>
<node TEXT="COUNT()" FOLDED="true" ID="ID_681449918" CREATED="1706332151253" MODIFIED="1706332159254">
<node TEXT="example" FOLDED="true" ID="ID_1589579714" CREATED="1706332218869" MODIFIED="1706332221540">
<node TEXT="SELECT COUNT(*)" ID="ID_1327854143" CREATED="1706332215348" MODIFIED="1706332215348"/>
<node TEXT="FROM Products;" ID="ID_458698187" CREATED="1706332215348" MODIFIED="1706332215348"/>
</node>
</node>
</node>
<node TEXT="DISTINCT" ID="ID_1198615784" CREATED="1706151104895" MODIFIED="1706151111018"/>
<node TEXT="AS &quot;Desired Name&quot; (alias)" FOLDED="true" ID="ID_1810251302" CREATED="1706316922678" MODIFIED="1706822898922">
<node TEXT="table_name [AS] table_alias" FOLDED="true" ID="ID_1100503229" CREATED="1706808137835" MODIFIED="1706808165748">
<node TEXT="SELECT * FROM employees e;" ID="ID_5204566" CREATED="1706808174843" MODIFIED="1706808174843"/>
<node TEXT="reference a table column" FOLDED="true" ID="ID_1308031553" CREATED="1706808190371" MODIFIED="1706808198324">
<node TEXT="table_alias.column_name" ID="ID_334216157" CREATED="1706808182843" MODIFIED="1706808182843"/>
</node>
</node>
</node>
<node ID="ID_705376244" CONTENT_ID="ID_1790306788"/>
<node TEXT="JOIN" FOLDED="true" ID="ID_1680208590" CREATED="1706807755282" MODIFIED="1706807760848">
<node TEXT="reference" FOLDED="true" ID="ID_1375673571" CREATED="1706819128875" MODIFIED="1706819133699">
<node TEXT="method of linking data between one (self-join ) or more tables based on the values of the common column between the tables" ID="ID_731327132" CREATED="1706808401236" MODIFIED="1706808428648"/>
<node TEXT="types" FOLDED="true" ID="ID_1929390924" CREATED="1706819534275" MODIFIED="1706819536910">
<node TEXT="png_6371984856434217246.png" ID="ID_1960607912" CREATED="1706819540938" MODIFIED="1706819540938">
<hook URI="Career%20Management_files/png_6371984856434217246.png" SIZE="0.64724916" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="[INNER] JOIN (default)" FOLDED="true" ID="ID_161830594" CREATED="1706808533579" MODIFIED="1706809948551">
<node TEXT="SELECT" FOLDED="true" ID="ID_1472699062" CREATED="1706810728251" MODIFIED="1706810728251">
<node TEXT="select_list" ID="ID_1425807726" CREATED="1706810728251" MODIFIED="1706810728251"/>
</node>
<node TEXT="FROM t1" ID="ID_1872153293" CREATED="1706810728251" MODIFIED="1706810820672"/>
<node TEXT="INNER JOIN t2" ID="ID_188006244" CREATED="1706810728253" MODIFIED="1706810810659"/>
<node TEXT="USING (foreign_key_column)" ID="ID_307139111" CREATED="1706811005329" MODIFIED="1706811042659"/>
<node TEXT="or" ID="ID_1141117835" CREATED="1706811049194" MODIFIED="1706811053251"/>
<node TEXT="ON join_condition;" ID="ID_1626948290" CREATED="1706810810660" MODIFIED="1706810810661"/>
<node TEXT="description" FOLDED="true" ID="ID_326575703" CREATED="1706810133001" MODIFIED="1706810135675">
<node TEXT="matches each row in one table with every row and other tables" ID="ID_1248245395" CREATED="1706809899214" MODIFIED="1706810021984"/>
<node TEXT="allows you to query rows that contain columns from both tables" ID="ID_231635043" CREATED="1706809915058" MODIFIED="1706809930453"/>
<node TEXT="typically join tables that have foreign key relationships" ID="ID_1142876436" CREATED="1706810510048" MODIFIED="1706810531772"/>
<node ID="ID_1576642175" CREATED="1706810223842" MODIFIED="1706810223842" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-inner-join/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mysqltutorial.org/mysql-basics/mysql-inner-join/">MySQL INNER JOIN</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="png_17933576681105425091.png" ID="ID_465357476" CREATED="1706810143392" MODIFIED="1706810143392">
<hook URI="Career%20Management_files/png_17933576681105425091.png" SIZE="1.0" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="types" ID="ID_1474227126" CREATED="1706808530299" MODIFIED="1706808532908"/>
</node>
<node ID="ID_493538961" CONTENT_ID="ID_1034185192">
<node ID="ID_621415990" CONTENT_ID="ID_792997751"/>
<node ID="ID_1954801492" CONTENT_ID="ID_1005182458">
<node ID="ID_854023442" CONTENT_ID="ID_751522511"/>
<node ID="ID_1217722213" CONTENT_ID="ID_307990934">
<node ID="ID_490918660" CONTENT_ID="ID_170245508"/>
</node>
<node ID="ID_353684717" CONTENT_ID="ID_728836255"/>
<node ID="ID_1159416444" CONTENT_ID="ID_1831145379"/>
<node ID="ID_132611798" CONTENT_ID="ID_228931899"/>
<node ID="ID_1786916700" CONTENT_ID="ID_335889999">
<node ID="ID_59354263" CONTENT_ID="ID_1015602639"/>
</node>
<node ID="ID_415150252" CONTENT_ID="ID_1762477170">
<node ID="ID_1551449847" CONTENT_ID="ID_916490582"/>
<node ID="ID_361745536" CONTENT_ID="ID_1935899307">
<node ID="ID_595357522" CONTENT_ID="ID_1710274350"/>
</node>
<node ID="ID_1440388388" CONTENT_ID="ID_200136540">
<node ID="ID_1985413250" CONTENT_ID="ID_322678066"/>
</node>
<node ID="ID_836127850" CONTENT_ID="ID_866979982">
<node ID="ID_436638247" CONTENT_ID="ID_428171408">
<node ID="ID_21367961" CONTENT_ID="ID_1253422619"/>
</node>
<node ID="ID_344321560" CONTENT_ID="ID_1569907253">
<node ID="ID_76830284" CONTENT_ID="ID_1442114189"/>
<node ID="ID_395525759" CONTENT_ID="ID_1929483253">
<node ID="ID_89597151" CONTENT_ID="ID_1059216940"/>
</node>
<node ID="ID_806625681" CONTENT_ID="ID_941077564">
<node ID="ID_151398389" CONTENT_ID="ID_869414235"/>
</node>
<node ID="ID_499545428" CONTENT_ID="ID_87270170">
<node ID="ID_392155276" CONTENT_ID="ID_466217861"/>
</node>
</node>
<node ID="ID_693113219" CONTENT_ID="ID_239580988">
<node ID="ID_1597806452" CONTENT_ID="ID_719111578"/>
<node ID="ID_1746712570" CONTENT_ID="ID_1955359935">
<node ID="ID_601517363" CONTENT_ID="ID_665690667"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_646318087" CONTENT_ID="ID_1861198932">
<node ID="ID_877892885" CONTENT_ID="ID_1348236638"/>
<node ID="ID_14646343" CONTENT_ID="ID_455276251"/>
<node ID="ID_284337112" CONTENT_ID="ID_323193860"/>
</node>
</node>
<node TEXT="GROUP BY" FOLDED="true" ID="ID_735461623" CREATED="1706808041218" MODIFIED="1706808044579">
<node TEXT="reference" FOLDED="true" ID="ID_1592985365" CREATED="1706811246639" MODIFIED="1706811249386">
<node ID="ID_403887570" CREATED="1706811250674" MODIFIED="1706811250674" LINK="https://www.mysqltutorial.org/mysql-basics/mysql-group-by/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mysqltutorial.org/mysql-basics/mysql-group-by/">MySQL GROUP BY</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="ORDER BY" FOLDED="true" ID="ID_1532222880" CREATED="1706152995422" MODIFIED="1706153001780">
<node TEXT="ASC" ID="ID_508253030" CREATED="1706154160987" MODIFIED="1706154163705"/>
<node TEXT="DESC" FOLDED="true" ID="ID_755608034" CREATED="1706153013341" MODIFIED="1706153019810">
<node TEXT="decending" ID="ID_1015477582" CREATED="1706153020622" MODIFIED="1706153025778"/>
<node TEXT="ORDER BY year DESC, winner;" ID="ID_1947663450" CREATED="1706153006576" MODIFIED="1706153006576"/>
</node>
<node TEXT="CASE" FOLDED="true" ID="ID_974718951" CREATED="1706153717120" MODIFIED="1706153719456">
<node TEXT="ORDER BY" ID="ID_1534446979" CREATED="1706153731026" MODIFIED="1706153731026"/>
<node TEXT="-- The CASE statement assigns a priority (1 or 0) based on the &apos;subject&apos; column." FOLDED="true" ID="ID_140843484" CREATED="1706153731026" MODIFIED="1706153731026">
<node TEXT="CASE" FOLDED="true" ID="ID_1608108515" CREATED="1706153731026" MODIFIED="1706153731026">
<node TEXT="WHEN subject IN (&apos;Economics&apos;, &apos;Chemistry&apos;) THEN 1" ID="ID_1139429125" CREATED="1706153731026" MODIFIED="1706153731026"/>
<node TEXT="ELSE 0" ID="ID_1665759736" CREATED="1706153731026" MODIFIED="1706153731026"/>
</node>
<node TEXT="END ASC," ID="ID_307266372" CREATED="1706153731026" MODIFIED="1706153731026"/>
<node TEXT="-- Orders the result set by &apos;subject&apos; in ascending order." ID="ID_350561165" CREATED="1706153731026" MODIFIED="1706153731026"/>
<node TEXT="subject," ID="ID_1117143460" CREATED="1706153731026" MODIFIED="1706153731026"/>
<node TEXT="-- Orders the result set by &apos;winner&apos; in ascending order." ID="ID_505177035" CREATED="1706153731026" MODIFIED="1706153731026"/>
<node TEXT="winner;" ID="ID_1974478142" CREATED="1706153731026" MODIFIED="1706153731026"/>
</node>
<node ID="ID_678767125" CREATED="1706154371014" MODIFIED="1706154371014" LINK="https://stackoverflow.com/questions/25949837/case-statement-for-order-by-clause-with-desc-asc-sort"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/25949837/case-statement-for-order-by-clause-with-desc-asc-sort">sql - Case statement for Order By clause with Desc/Asc sort - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="\c #cancel" ID="ID_1114633410" CREATED="1706141488414" MODIFIED="1706141494859"/>
</node>
<node TEXT="UNION" FOLDED="true" ID="ID_1946076588" CREATED="1706152061384" MODIFIED="1706152064571">
<node TEXT="combines select results" ID="ID_1093346641" CREATED="1706152065274" MODIFIED="1706152072650"/>
</node>
<node TEXT="subqueries" FOLDED="true" ID="ID_1330494602" CREATED="1711489884373" MODIFIED="1711489890386">
<node TEXT="" ID="ID_266111495" CREATED="1711489917836" MODIFIED="1711489917836"/>
<node TEXT="reference" FOLDED="true" ID="ID_1706203120" CREATED="1711489891269" MODIFIED="1711489893556">
<node ID="ID_188623155" CREATED="1711490030238" MODIFIED="1711490030238"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/5%20Analyze%20Data%20To%20Answer%20Questions/M3%20Aggregate%20data%20for%20analysis.one#SQL functions and subqueries A functional friendship&amp;section-id={BA702C4E-52F5-4EA0-9696-CF0EAE9C0E3B}&amp;page-id={1CE15C49-4C80-4C03-9F5E-332B565E3E63}&amp;end">SQL functions and subqueries A functional friendship</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%285%20Analyze%20Data%20To%20Answer%20Questions%2FM3%20Aggregate%20data%20for%20analysis.one%7CBA702C4E-52F5-4EA0-9696-CF0EAE9C0E3B%2FSQL%20functions%20and%20subqueries%3A%20A%20functional%20friendship%7C1CE15C49-4C80-4C03-9F5E-332B565E3E63%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1336165026" CREATED="1711489897348" MODIFIED="1711489897348"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://d.docs.live.net/641687e415c70099/Documents/Google%20Data%20Analytics%20Certificate/5%20Analyze%20Data%20To%20Answer%20Questions/M3%20Aggregate%20data%20for%20analysis.one#Step-by-Step Queries within queries&amp;section-id={BA702C4E-52F5-4EA0-9696-CF0EAE9C0E3B}&amp;page-id={8A8ED16A-E36B-4CC0-BAC2-24C8169D8AE6}&amp;end">Step-by-Step Queries within queries</a>&#xa0;&#xa0;(<a href="https://onedrive.live.com/view.aspx?resid=641687E415C70099%214400&amp;id=documents&amp;wd=target%285%20Analyze%20Data%20To%20Answer%20Questions%2FM3%20Aggregate%20data%20for%20analysis.one%7CBA702C4E-52F5-4EA0-9696-CF0EAE9C0E3B%2FStep-by-Step%3A%20Queries%20within%20queries%7C8A8ED16A-E36B-4CC0-BAC2-24C8169D8AE6%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="temporary tables" FOLDED="true" ID="ID_325687988" CREATED="1711645484418" MODIFIED="1711645489046">
<node TEXT="WITH" ID="ID_1539810987" CREATED="1711645490130" MODIFIED="1711645497710"/>
</node>
<node TEXT="permissions" FOLDED="true" ID="ID_716590699" CREATED="1706332065804" MODIFIED="1706332069356">
<node TEXT="mysql&gt; GRANT ALL ON menagerie.* TO &apos;your_mysql_name&apos;@&apos;your_client_host&apos;;" ID="ID_617013758" CREATED="1706141577015" MODIFIED="1706141591931"/>
</node>
<node TEXT="Batch Mode (using file)" FOLDED="true" ID="ID_138468257" CREATED="1706134530455" MODIFIED="1706134547837">
<node ID="ID_570580216" CREATED="1706134548861" MODIFIED="1706134548861" LINK="https://dev.mysql.com/doc/refman/8.0/en/batch-mode.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/batch-mode.html">MySQL :: MySQL 8.0 Reference Manual :: 3.5 Using mysql in Batch Mode</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT=" Use Scripts" FOLDED="true" ID="ID_1737093366" CREATED="1705689436594" MODIFIED="1705689456020">
<node ID="ID_1040513747" CREATED="1705789510270" MODIFIED="1705789529247"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      mysql&gt; source <i>file_name</i>
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="mysql&gt; \. file_name" ID="ID_36368622" CREATED="1705789510270" MODIFIED="1705789510270"/>
<node ID="ID_279490569" CREATED="1705692601605" MODIFIED="1705692601605" LINK="https://dev.mysql.com/doc/refman/8.0/en/mysql-batch-commands.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/refman/8.0/en/mysql-batch-commands.html">MySQL :: MySQL 8.0 Reference Manual :: 4.5.1.5 Executing SQL Statements from a Text File</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1873657220" CREATED="1705689457189" MODIFIED="1705689457189" LINK="https://www.sqlshack.com/learn-sql-sql-script/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sqlshack.com/learn-sql-sql-script/">Learn SQL: SQL Scripts</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Enabling or Disabling Local Data Loading Capability" FOLDED="true" ID="ID_465057380" CREATED="1705791183827" MODIFIED="1705791187294">
<node TEXT="reference" FOLDED="true" ID="ID_409822108" CREATED="1711055766171" MODIFIED="1711055767969">
<node ID="ID_293642114" CREATED="1711055758540" MODIFIED="1711055758540" LINK="https://stackoverflow.com/questions/31450389/connect-with-local-infile-option-in-mysql-workbench"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/31450389/connect-with-local-infile-option-in-mysql-workbench">Connect with local-infile Option in MySql Workbench - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1348819866" CREATED="1705791284892" MODIFIED="1705791284892" LINK="https://stackoverflow.com/questions/59993844/error-loading-local-data-is-disabled-this-must-be-enabled-on-both-the-client"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/59993844/error-loading-local-data-is-disabled-this-must-be-enabled-on-both-the-client">mysql - ERROR: Loading local data is disabled - this must be enabled on both the client and server sides - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Enable" FOLDED="true" ID="ID_281447420" CREATED="1705791316716" MODIFIED="1705791319533">
<node TEXT="SET GLOBAL local_infile=1;" ID="ID_958663678" CREATED="1705791325005" MODIFIED="1705791325005"/>
<node TEXT="quit" ID="ID_1016159177" CREATED="1705791356748" MODIFIED="1705791359542"/>
<node TEXT="launch sql  with local infile enabled" FOLDED="true" ID="ID_1054405199" CREATED="1706140869568" MODIFIED="1706140885694">
<node TEXT="from commandline" FOLDED="true" ID="ID_1397400912" CREATED="1706140847247" MODIFIED="1706140861206">
<node TEXT="C:\Program Files\MySQL\MySQL Server 8.0\bin\" ID="ID_1043786468" CREATED="1706140848261" MODIFIED="1706140848261"/>
<node TEXT="mysql --local-infile=1 -u root -p" ID="ID_250656964" CREATED="1705791374427" MODIFIED="1706140826059"/>
</node>
<node TEXT="using shortcut" FOLDED="true" ID="ID_1202952126" CREATED="1706140889592" MODIFIED="1706140893076">
<node TEXT="create shortcut to mysql" ID="ID_1088823907" CREATED="1706140896041" MODIFIED="1706140909379"/>
<node TEXT="add launch parameters after &quot;" ID="ID_505269304" CREATED="1706140910376" MODIFIED="1706140927171"/>
</node>
</node>
</node>
</node>
<node TEXT="MySQL Workbench (GUI)" FOLDED="true" ID="ID_542307028" CREATED="1706133849824" MODIFIED="1706133873109">
<node ID="ID_1484627855" CREATED="1706133891931" MODIFIED="1706133891931" LINK="https://dev.mysql.com/doc/workbench/en/wb-admin-export-import-table.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/workbench/en/wb-admin-export-import-table.html">MySQL :: MySQL Workbench Manual :: 6.5.1 Table Data Export and Import Wizard</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_530149753" CREATED="1705686796642" MODIFIED="1705686796642" LINK="https://dev.mysql.com/doc/mysql-getting-started/en/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dev.mysql.com/doc/mysql-getting-started/en/">MySQL :: Getting Started with MySQL</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="others" FOLDED="true" ID="ID_1359078959" CREATED="1705423164399" MODIFIED="1706807887661">
<node TEXT="MS SQL Server" FOLDED="true" ID="ID_283483366" CREATED="1705691568997" MODIFIED="1705691579980">
<node TEXT="comparison" FOLDED="true" ID="ID_1960947160" CREATED="1705691589948" MODIFIED="1705691592369">
<node ID="ID_432095949" CREATED="1705691593012" MODIFIED="1705691593012" LINK="https://blog.dreamfactory.com/ms-sql-server-vs-mysql/#1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://blog.dreamfactory.com/ms-sql-server-vs-mysql/#1">MySQL vs MS SQL Server | Key Similarities and Differences - DreamFactory Software- Blog</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Certification" FOLDED="true" ID="ID_247820734" CREATED="1705353412103" MODIFIED="1705353414809">
<node TEXT="paid" FOLDED="true" ID="ID_1842259748" CREATED="1705353478735" MODIFIED="1705353481008">
<node ID="ID_1685870076" CREATED="1705353475866" MODIFIED="1705353475866" LINK="https://education.oracle.com/learning-explorer#startLearning"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://education.oracle.com/learning-explorer#startLearning">Oracle Learning Explorer: Learn Oracle for Free | Oracle University</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="tests" FOLDED="true" ID="ID_1771019104" CREATED="1696479096561" MODIFIED="1696479098991">
<node ID="ID_1292453333" CREATED="1706332240331" MODIFIED="1706332240331" LINK="https://www.w3schools.com/quiztest/quiztest.asp?qtest=SQL"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.w3schools.com/quiztest/quiztest.asp?qtest=SQL">W3Schools SQL Quiz</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1556869555" CREATED="1696479100037" MODIFIED="1696479100037" LINK="https://www.google.com/search?q=sql+query+test+online&amp;oq=sql+query+test&amp;gs_lcrp=EgZjaHJvbWUqBwgCEAAYgAQyBwgAEAAYgAQyCQgBEEUYORiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIKCAYQABiGAxiKBTIKCAcQABiGAxiKBTIGCAgQRRhA0gEJMTIyNDBqMGoxqAIAsAIA&amp;sourceid=chrome&amp;ie=UTF-8"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.google.com/search?q=sql+query+test+online&amp;oq=sql+query+test&amp;gs_lcrp=EgZjaHJvbWUqBwgCEAAYgAQyBwgAEAAYgAQyCQgBEEUYORiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIKCAYQABiGAxiKBTIKCAcQABiGAxiKBTIGCAgQRRhA0gEJMTIyNDBqMGoxqAIAsAIA&amp;sourceid=chrome&amp;ie=UTF-8">sql query test online - Google Search</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_793642904" CREATED="1705353938602" MODIFIED="1705353938602" LINK="https://www.coursera.org/articles/sql-interview-questions?trk_ref=relatedArticlesCard"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/articles/sql-interview-questions?trk_ref=relatedArticlesCard">SQL Interview Questions: A Data Analyst's Guide for Success | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="exercises" FOLDED="true" ID="ID_1954783006" CREATED="1696471374141" MODIFIED="1696471376022">
<node ID="ID_266640368" CREATED="1706309561268" MODIFIED="1706309561268" LINK="https://www.codeconquest.com/blog/top-50-websites-to-learn-mysql/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.codeconquest.com/blog/top-50-websites-to-learn-mysql/">The 50 Best Websites to Learn MySQL - Code Conquest</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_411055411" CREATED="1705686375001" MODIFIED="1705686375001" LINK="https://datalemur.com/sql-tutorial"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://datalemur.com/sql-tutorial">Free SQL Tutorial for Data Analysts &amp; Data Scientists</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_304663994" CREATED="1706144412431" MODIFIED="1706144412431" LINK="https://www.w3resource.com/sql-exercises/sql-retrieve-from-table.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.w3resource.com/sql-exercises/sql-retrieve-from-table.php">SQL Exercises: Retrieve data from tables - w3resource</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_444603098" CREATED="1696448882744" MODIFIED="1696448882744" LINK="https://www.w3resource.com/sql/tutorials.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.w3resource.com/sql/tutorials.php">SQL Tutorial - w3resource</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Commands" ID="ID_1677108759" CREATED="1696450238502" MODIFIED="1696450240883">
<node TEXT="SQL" FOLDED="true" ID="ID_246365753" CREATED="1700679427030" MODIFIED="1700679427030">
<node TEXT="with src as ()" ID="ID_1483010247" CREATED="1700679427030" MODIFIED="1700679427030"/>
<node TEXT="partition by" ID="ID_657353071" CREATED="1700679427031" MODIFIED="1700679427031"/>
<node TEXT="having" ID="ID_1080880392" CREATED="1700679427032" MODIFIED="1700679427032"/>
<node TEXT="case when" ID="ID_1321569861" CREATED="1700679427033" MODIFIED="1700679427033"/>
<node TEXT="union" ID="ID_1308585654" CREATED="1700679427034" MODIFIED="1700679427034"/>
<node TEXT="within group" ID="ID_253615436" CREATED="1700679427035" MODIFIED="1700679427035"/>
</node>
<node TEXT="reference" ID="ID_1268696468" CREATED="1696471196152" MODIFIED="1696471197942">
<node ID="ID_533333740" CREATED="1696449487494" MODIFIED="1696449487494" LINK="https://learnsql.com/blog/sql-for-data-analysis-cheat-sheet/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://learnsql.com/blog/sql-for-data-analysis-cheat-sheet/">SQL for Data Analysis Cheat Sheet | LearnSQL.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_622695982" CREATED="1696471199161" MODIFIED="1696471199161" LINK="https://docs.snowflake.com/en/sql-reference-commands"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.snowflake.com/en/sql-reference-commands">SQL Command Reference | Snowflake Documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="server" ID="ID_361595532" CREATED="1719006135950" MODIFIED="1719006137719">
<node ID="ID_539936485" CREATED="1719006139036" MODIFIED="1719006139036" LINK="https://www.mssqltips.com/sqlservertip/2470/understanding-the-sql-server-nolock-hint/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mssqltips.com/sqlservertip/2470/understanding-the-sql-server-nolock-hint/">Understanding the SQL Server NOLOCK hint</a>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="SELECT" FOLDED="true" ID="ID_1024890748" CREATED="1696450241536" MODIFIED="1696450243863">
<node TEXT="*" FOLDED="true" ID="ID_323885717" CREATED="1696450501776" MODIFIED="1696450509150">
<node TEXT="entire table" ID="ID_1853303259" CREATED="1696450509925" MODIFIED="1696450512058"/>
</node>
<node TEXT="column(, column_2, etc)" FOLDED="true" ID="ID_1409782853" CREATED="1696450514002" MODIFIED="1696450626231">
<node TEXT="particular columns from table in desired order" ID="ID_166520598" CREATED="1696450517245" MODIFIED="1696450645615"/>
</node>
<node TEXT="DISTINCT" FOLDED="true" ID="ID_1191546740" CREATED="1696450307717" MODIFIED="1696450660186">
<node TEXT="distinct values" ID="ID_1295263" CREATED="1696450649376" MODIFIED="1696450653708"/>
</node>
<node TEXT="|| &apos; - &apos; ||" FOLDED="true" ID="ID_1270667993" CREATED="1696470768680" MODIFIED="1696470775486">
<node TEXT="concatenate" ID="ID_856980986" CREATED="1696470776528" MODIFIED="1696470779147"/>
</node>
</node>
<node TEXT="FROM" FOLDED="true" ID="ID_1147822843" CREATED="1696450244429" MODIFIED="1696450663798">
<node TEXT="desired table" ID="ID_1252537955" CREATED="1696450665523" MODIFIED="1696450671465"/>
</node>
<node TEXT="WHERE" FOLDED="true" ID="ID_82875598" CREATED="1696450246441" MODIFIED="1696450680283">
<node TEXT="conditions" ID="ID_1240560592" CREATED="1696450681036" MODIFIED="1696452555155">
<font ITALIC="true"/>
</node>
</node>
<node TEXT="UNION" FOLDED="true" ID="ID_1427331787" CREATED="1696472614347" MODIFIED="1696472617770">
<node TEXT="example" FOLDED="true" ID="ID_524000796" CREATED="1696470820721" MODIFIED="1696470822891">
<node TEXT="price &gt; 15" ID="ID_356102823" CREATED="1696470823917" MODIFIED="1696470830470"/>
</node>
<node TEXT="UNION (SELECT * FROM nobel_win  WHERE (subject =&apos;Economics&apos; AND year=1971));" ID="ID_1728135689" CREATED="1696472635375" MODIFIED="1696472643020"/>
</node>
<node TEXT="Aggregate Functions" FOLDED="true" ID="ID_537397815" CREATED="1696470970389" MODIFIED="1696470974252">
<node TEXT="COUNT(*)" FOLDED="true" ID="ID_1361367490" CREATED="1696470975838" MODIFIED="1696470997753">
<node TEXT="counts row #" ID="ID_342806832" CREATED="1696470999407" MODIFIED="1696471026188"/>
</node>
</node>
<node TEXT="ORDER BY column [ASC] or DESC" FOLDED="true" ID="ID_616774454" CREATED="1696478780469" MODIFIED="1696478817820">
<node TEXT="ORDER BY year DESC, winner;" FOLDED="true" ID="ID_1550794935" CREATED="1696479224209" MODIFIED="1696479224209">
<node TEXT="orders by year descending, and winner for same years" ID="ID_667393140" CREATED="1696479227567" MODIFIED="1696479261084"/>
</node>
</node>
<node TEXT="Computations" ID="ID_1230001900" CREATED="1696478822382" MODIFIED="1696478832390"/>
<node TEXT=";" FOLDED="true" ID="ID_1501263258" CREATED="1696450414758" MODIFIED="1696450691684">
<node TEXT="end statement" ID="ID_1427723242" CREATED="1696450695699" MODIFIED="1696450701500"/>
</node>
</node>
<node TEXT="Queries : Retrieves data against some criteria." ID="ID_401492333" CREATED="1696449035943" MODIFIED="1696449035943"/>
<node TEXT="Statements : Controls transactions, program flow, connections, sessions, or diagnostics." ID="ID_180939095" CREATED="1696449035943" MODIFIED="1696449035943"/>
<node TEXT="Expressions : Combination of symbols and operators and a key part of the SQL statements." FOLDED="true" ID="ID_1852939447" CREATED="1696449035946" MODIFIED="1696449035946">
<node TEXT="Clauses : Components of Queries and Statements." POSITION="bottom_or_right" ID="ID_641023695" CREATED="1696449035945" MODIFIED="1696449035945"/>
</node>
<node TEXT="Predicates : Specifies conditions." ID="ID_1432087794" CREATED="1696449035947" MODIFIED="1696449035947"/>
<node TEXT="reference" FOLDED="true" ID="ID_1806565094" CREATED="1696448884557" MODIFIED="1696449029490">
<node ID="ID_1465611993" CREATED="1696448654338" MODIFIED="1696448654338" LINK="https://aws.amazon.com/what-is/sql/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://aws.amazon.com/what-is/sql/">What is SQL? - Structured Query Language (SQL) Explained - AWS</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1743243191" CREATED="1696448387573" MODIFIED="1696448387573" LINK="https://www.testdome.com/tests/sql-online-test/12"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.testdome.com/tests/sql-online-test/12">SQL Online Test | TestDome</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_653249049" CREATED="1663046097741" MODIFIED="1663046097741" LINK="https://www.codespaces.com/best-sql-courses-certifications-training.html#10-free-sql-courses-online-edx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.codespaces.com/best-sql-courses-certifications-training.html#10-free-sql-courses-online-edx">20 Best SQL Certification Courses &amp; Training Online 2022</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Statistical Knowledge" FOLDED="true" ID="ID_667229698" CREATED="1700685706020" MODIFIED="1700685710618">
<node TEXT="SAS" ID="ID_685806450" CREATED="1708466831765" MODIFIED="1708466840934"/>
<node TEXT="SPSS" ID="ID_1773656242" CREATED="1708466858480" MODIFIED="1708466864035"/>
<node TEXT="Excel" ID="ID_313117304" CREATED="1708466864414" MODIFIED="1708466866666"/>
<node TEXT="reference" FOLDED="true" ID="ID_1159878367" CREATED="1700706118721" MODIFIED="1700706121208">
<node ID="ID_1013796177" CREATED="1700706181819" MODIFIED="1700706181819" LINK="https://www.kaggle.com/discussions/general/101419"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.kaggle.com/discussions/general/101419">Statistics for Data Science - Mind Map | Kaggle</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_149250627" CREATED="1700706122015" MODIFIED="1700706122015" LINK="https://www.sherrytowers.com/cowan_statistical_data_analysis.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sherrytowers.com/cowan_statistical_data_analysis.pdf">cowan_statistical_data_analysis.pdf</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Reverting to Jon Wayland&apos;s answer to What kind of statistics should be learned to make a good data analyst?" FOLDED="true" ID="ID_884053450" CREATED="1700679400255" MODIFIED="1700679400255">
<node TEXT="Descriptive Statistics" ID="ID_641271926" CREATED="1700679400256" MODIFIED="1700679400256"/>
<node TEXT="Mean &amp; Median (specifically when to use one over the other)" ID="ID_143413281" CREATED="1700679400257" MODIFIED="1700679400257"/>
<node TEXT="Standard Deviation" ID="ID_1120244284" CREATED="1700679400258" MODIFIED="1700679400258"/>
<node TEXT="Percentiles" ID="ID_636876209" CREATED="1700679400259" MODIFIED="1700679400259"/>
<node TEXT="Using the Distribution for Identifying Outliers" ID="ID_1642704057" CREATED="1700679400260" MODIFIED="1700679400260"/>
<node TEXT="Hypothesis Testing" ID="ID_1911203046" CREATED="1700679400260" MODIFIED="1700679400260"/>
<node TEXT="Difference in Means" ID="ID_124629290" CREATED="1700679400261" MODIFIED="1700679400261"/>
<node TEXT="Difference in Proportions" ID="ID_1094694371" CREATED="1700679400263" MODIFIED="1700679400263"/>
<node TEXT="Modeling" ID="ID_240607709" CREATED="1700679400263" MODIFIED="1700679400263"/>
<node TEXT="Logistic Regression (with interpretation on likelihood)" ID="ID_1001519917" CREATED="1700679400264" MODIFIED="1700679400264"/>
<node TEXT="Linear Regression" ID="ID_1423044686" CREATED="1700679400265" MODIFIED="1700679400265"/>
</node>
</node>
<node TEXT="Creating Data Visualizations" FOLDED="true" ID="ID_357748725" CREATED="1700685720768" MODIFIED="1700685728806">
<node TEXT="Power BI" ID="ID_1476814256" CREATED="1698902754007" MODIFIED="1698902756989"/>
<node TEXT="Tableau" ID="ID_98919482" CREATED="1708466804180" MODIFIED="1708466814200"/>
<node TEXT="Verifiable proficiency in building and maintaining BI dashboards (e.g., PowerBI, Tableau, or Business Objects)" ID="ID_1046160722" CREATED="1700673129830" MODIFIED="1700673129830"/>
<node TEXT="1-2 years of experience with Microsoft Power Platform development to include Microsoft Power Automate and Microsoft Power Apps" ID="ID_1391707021" CREATED="1700673129830" MODIFIED="1700673129830"/>
</node>
<node TEXT="Creating Dashboards And Reports" ID="ID_289549904" CREATED="1700685795789" MODIFIED="1700685800502"/>
<node TEXT="Industry Knowledge" FOLDED="true" ID="ID_82969155" CREATED="1700679400247" MODIFIED="1700679400247">
<node TEXT="How your company makes profit" ID="ID_783869820" CREATED="1700679400249" MODIFIED="1700679400249"/>
<node TEXT="What your company’s biggest expenses are" ID="ID_1870142544" CREATED="1700679400249" MODIFIED="1700679400249"/>
<node TEXT="What your company sells" ID="ID_958262177" CREATED="1700679400250" MODIFIED="1700679400250"/>
</node>
<node TEXT="One of: R, Python, or SAS" FOLDED="true" ID="ID_541728595" CREATED="1700679400251" MODIFIED="1700679400251">
<node TEXT="Write reporting programs" ID="ID_1724736261" CREATED="1700679400252" MODIFIED="1700679400252"/>
<node TEXT="Connect to a SQL or Hadoop database" ID="ID_451912796" CREATED="1700679400252" MODIFIED="1700679400252"/>
<node TEXT="Build visualizations" ID="ID_1132356243" CREATED="1700679400252" MODIFIED="1700679400252"/>
<node TEXT="Build basic models" ID="ID_1900195994" CREATED="1700679400253" MODIFIED="1700679400253"/>
</node>
<node TEXT="Python" ID="ID_1633356642" CREATED="1698902757472" MODIFIED="1698902759612"/>
<node TEXT="Excel" FOLDED="true" ID="ID_495494239" CREATED="1700679400243" MODIFIED="1700679400243">
<node TEXT="Pivot Tables" ID="ID_599913725" CREATED="1700679400244" MODIFIED="1700679400244"/>
<node TEXT="vlookup()" ID="ID_573218314" CREATED="1700679400244" MODIFIED="1700679400244"/>
<node TEXT="sumif()" ID="ID_48872619" CREATED="1700679400245" MODIFIED="1700679400245"/>
<node TEXT="countif()" ID="ID_1850701630" CREATED="1700679400246" MODIFIED="1700679400246"/>
<node TEXT="VBA Familiarity" ID="ID_841322943" CREATED="1700679400246" MODIFIED="1700679400246"/>
</node>
<node TEXT="R" ID="ID_1110091729" CREATED="1698902760819" MODIFIED="1698902761476"/>
<node TEXT="Tableau" ID="ID_794235737" CREATED="1700681952269" MODIFIED="1700681956118"/>
<node TEXT="Power Apps" ID="ID_622595734" CREATED="1698902770105" MODIFIED="1698902773328"/>
<node ID="ID_1427473947" CREATED="1698902833852" MODIFIED="1698902833852"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: rgb(45, 45, 45); font-family: Noto Sans, Helvetica Neue, Helvetica, Arial, sans-serif; font-size: 14px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none"><font color="rgb(45, 45, 45)" face="Noto Sans, Helvetica Neue, Helvetica, Arial, sans-serif" size="14px">Microsoft Azure Certified</font></span>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1739892225" CREATED="1703889282196" MODIFIED="1703889282196" LINK="https://careerfoundry.com/en/blog/data-analytics/data-analyst-job-descriptions/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careerfoundry.com/en/blog/data-analytics/data-analyst-job-descriptions/">Data Analytics Job Descriptions (And What They Really Mean)</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_17391486" CREATED="1700680359207" MODIFIED="1700680361226">
<node ID="ID_1482117448" CREATED="1699230491145" MODIFIED="1699230491145" LINK="https://careerfoundry.com/en/blog/data-analytics/entry-level-data-analyst-jobs/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careerfoundry.com/en/blog/data-analytics/entry-level-data-analyst-jobs/">The Ultimate Guide to Entry-Level Data Analyst Jobs</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1069734006" CREATED="1699230075593" MODIFIED="1699230075593" LINK="https://www.coursera.org/articles/entry-level-data-analyst"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/articles/entry-level-data-analyst">Entry-Level Data Analyst: What They Do + How to Get Started | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1215562438" CREATED="1700680307521" MODIFIED="1700680307521" LINK="https://365datascience.com/career-advice/transition-into-data-science-career/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://365datascience.com/career-advice/transition-into-data-science-career/">How to Transition Your Career into Data Science in 2023 | 365 Data Science</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1327873325" CREATED="1698903186783" MODIFIED="1698903186783" LINK="https://brainstation.io/career-guides/how-to-become-a-data-analyst"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://brainstation.io/career-guides/how-to-become-a-data-analyst">How to Become a Data Analyst (2023 Guide) | BrainStation®</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Advice" FOLDED="true" ID="ID_578075734" CREATED="1699325285937" MODIFIED="1700679608419">
<node TEXT="Analyze the data analyst career." FOLDED="true" ID="ID_1549347838" CREATED="1700679885799" MODIFIED="1700679885799">
<node TEXT="Collect data analyst job postings from employment web sites." ID="ID_118676052" CREATED="1700679885799" MODIFIED="1700679885799"/>
<node TEXT="Cleanse and transform the contents so you can analyze them." ID="ID_559269543" CREATED="1700679885800" MODIFIED="1700679885800"/>
<node TEXT="Extract common skill and experience requirements that appear across employer-industries for different job levels." ID="ID_154629076" CREATED="1700679885801" MODIFIED="1700679885801"/>
<node TEXT="Extract common skill and experience requirements that appear in specific employer-industries for different job levels." ID="ID_662811732" CREATED="1700679885803" MODIFIED="1700679885803"/>
<node TEXT="Develop skills and experiences that get you to meeting requirements at the 100% level for many openings in your suitable geographies." ID="ID_1677949563" CREATED="1700679885805" MODIFIED="1700679885805"/>
<node TEXT="Publish your findings" ID="ID_1486548882" CREATED="1700679885807" MODIFIED="1700679885807"/>
</node>
<node TEXT="Start with all of your repetitive tasks, automate them with your scripting language of choice. Maybe you have to run a SQL query, transform the data, save a summary table in an Excel file, and email it to someone. Easily done in your preferred scripting language." ID="ID_73521845" CREATED="1700679609827" MODIFIED="1700679609827"/>
<node TEXT="Learn to do all your data visualization in in Python or R. This is great because there are no training wheels here like on an MOOC. It all depends on you to develop this skill." ID="ID_1046536454" CREATED="1700679609829" MODIFIED="1700679609829"/>
<node TEXT="With your newly acquired free time at work thanks to your task automation, find an interesting problem to solve that may be similar to something you’ve done on Kaggle. If you aren’t that far along in your data science journey, there’s a ton of opportunity for exploratory data analysis with your company’s data." ID="ID_1781754601" CREATED="1700679609830" MODIFIED="1700679609830"/>
<node TEXT="Take the time to learn how the various applications in use at your company work. Appreciate the inner workings and how small tweaks may provide large impacts, or how limitations of the application might impact your company’s business." ID="ID_1907766018" CREATED="1700679609831" MODIFIED="1700679609831"/>
<node TEXT="Take the time to learn the domain. Be patient and think critically. This point can tie in with the above point. Learn how to reach out for help and to ask good questions." ID="ID_1227796219" CREATED="1700679609833" MODIFIED="1700679609833"/>
<node TEXT="All the while, continue your data science education outside of work. You will still need data science projects, probably a github repo, a kaggle presence, etc. But you will also have professional experience dealing with data. You will also demonstrate that you go above and beyond the base requirements of your job. If given the opportunity, and you are in the self-taught crowd, I think working as a Data Analyst would go a long way to help land that first DS role." ID="ID_516013717" CREATED="1700679609834" MODIFIED="1700679609834"/>
</node>
</node>
<node TEXT="Data Scientist" FOLDED="true" ID="ID_43848120" CREATED="1703888297320" MODIFIED="1703888301816">
<node TEXT="Portfolio" FOLDED="true" ID="ID_1329481229" CREATED="1703891606350" MODIFIED="1703891610592">
<font BOLD="true"/>
<node TEXT="GitHub" ID="ID_355519389" CREATED="1703891620335" MODIFIED="1703891623232"/>
</node>
<node TEXT="versus data analyst" FOLDED="true" ID="ID_745773747" CREATED="1703888332977" MODIFIED="1703888336576">
<node ID="ID_1802124496" CREATED="1703888337433" MODIFIED="1703888337433" LINK="https://www.degreeforum.net/mybb/Thread-MS-Data-Analytics-vs-MS-Data-Science"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.degreeforum.net/mybb/Thread-MS-Data-Analytics-vs-MS-Data-Science">MS Data Analytics vs MS Data Science</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1617373700" CREATED="1703888303602" MODIFIED="1703888303602" LINK="https://careerfoundry.com/en/blog/data-analytics/data-analyst-to-data-scientist-career-transition/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careerfoundry.com/en/blog/data-analytics/data-analyst-to-data-scientist-career-transition/">How To Go From Data Analyst To Data Scientist [2023 Guide]</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_745501918" CREATED="1703889007443" MODIFIED="1703889007443" LINK="https://careerfoundry.com/en/blog/data-analytics/data-analyst-to-data-scientist-career-transition/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://careerfoundry.com/en/blog/data-analytics/data-analyst-to-data-scientist-career-transition/">How To Go From Data Analyst To Data Scientist [2023 Guide]</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_515949385" TREE_ID="ID_1953248921">
<node ID="ID_304143276" TREE_ID="ID_1409010030">
<node ID="ID_473626294" TREE_ID="ID_728429003">
<node ID="ID_556166602" TREE_ID="ID_168824658"/>
</node>
<node ID="ID_235323401" TREE_ID="ID_1396731989">
<node ID="ID_1264717478" TREE_ID="ID_1379212029"/>
<node ID="ID_407418257" TREE_ID="ID_988313159"/>
<node ID="ID_1982566784" TREE_ID="ID_904845433"/>
<node ID="ID_581827567" TREE_ID="ID_593763396"/>
<node ID="ID_1111958741" TREE_ID="ID_598362840"/>
</node>
<node ID="ID_417117931" TREE_ID="ID_1193770599">
<node ID="ID_914667131" TREE_ID="ID_1141417731"/>
<node ID="ID_207969835" TREE_ID="ID_56642879"/>
<node ID="ID_888812294" TREE_ID="ID_731403312"/>
<node ID="ID_738257979" TREE_ID="ID_1552460433"/>
<node ID="ID_680272258" TREE_ID="ID_1906617019"/>
</node>
<node ID="ID_718588763" TREE_ID="ID_1896345393">
<node ID="ID_560982524" TREE_ID="ID_390376453"/>
<node ID="ID_1578013513" TREE_ID="ID_1438052116"/>
</node>
</node>
<node ID="ID_660038819" TREE_ID="ID_1281752431">
<node ID="ID_1733589910" TREE_ID="ID_1407336851"/>
</node>
<node ID="ID_1079921334" TREE_ID="ID_755331403">
<node ID="ID_87184755" TREE_ID="ID_851705497"/>
</node>
<node ID="ID_1306597921" TREE_ID="ID_1132290833">
<node ID="ID_1203075917" TREE_ID="ID_820279794">
<node ID="ID_1455709927" TREE_ID="ID_839360921"/>
<node ID="ID_1454641462" TREE_ID="ID_1835374865"/>
<node ID="ID_871860045" TREE_ID="ID_1790780031"/>
</node>
<node ID="ID_820941403" TREE_ID="ID_647217476">
<node ID="ID_1779273794" TREE_ID="ID_1681956108"/>
<node ID="ID_871195554" TREE_ID="ID_1783065024"/>
<node ID="ID_494587077" TREE_ID="ID_1375377115"/>
</node>
<node ID="ID_638568989" TREE_ID="ID_1353345821">
<node ID="ID_1030432845" TREE_ID="ID_271709555"/>
<node ID="ID_1304452246" TREE_ID="ID_104270877"/>
<node ID="ID_1354339822" TREE_ID="ID_1258337982"/>
<node ID="ID_403522230" TREE_ID="ID_754369853"/>
</node>
<node ID="ID_225578025" TREE_ID="ID_1467556040">
<node ID="ID_1017599117" TREE_ID="ID_1450722809"/>
<node ID="ID_46645795" TREE_ID="ID_109989686">
<node ID="ID_955112949" TREE_ID="ID_1701091227"/>
<node ID="ID_1415782423" TREE_ID="ID_1251542822"/>
<node ID="ID_198395613" TREE_ID="ID_1534509471">
<node ID="ID_16643364" TREE_ID="ID_1384399926">
<node ID="ID_1118035051" TREE_ID="ID_1702402830"/>
</node>
</node>
</node>
</node>
<node ID="ID_506975198" TREE_ID="ID_1847752459">
<node ID="ID_1946185094" TREE_ID="ID_119464575">
<node ID="ID_346068164" TREE_ID="ID_1909738"/>
</node>
</node>
</node>
<node ID="ID_688511218" TREE_ID="ID_1698975138"/>
<node ID="ID_497928591" TREE_ID="ID_206248189"/>
<node ID="ID_1012832513" TREE_ID="ID_597541286"/>
<node ID="ID_236294574" TREE_ID="ID_1332817574"/>
<node ID="ID_759794974" TREE_ID="ID_329655715">
<node ID="ID_178152857" TREE_ID="ID_867713833">
<node ID="ID_1351492269" TREE_ID="ID_952376777">
<node ID="ID_1006212794" TREE_ID="ID_1094808557">
<node ID="ID_117099655" TREE_ID="ID_1451938369">
<node ID="ID_1887608290" TREE_ID="ID_69971949">
<node ID="ID_162473995" TREE_ID="ID_588799282"/>
<node ID="ID_1142020784" TREE_ID="ID_1220366473"/>
</node>
<node ID="ID_864749612" TREE_ID="ID_142987355">
<node ID="ID_660497670" TREE_ID="ID_1954066873"/>
</node>
<node ID="ID_836640307" TREE_ID="ID_1675317742">
<node ID="ID_536912966" TREE_ID="ID_1643176778"/>
<node ID="ID_1980799459" TREE_ID="ID_47411245"/>
<node ID="ID_1783640012" TREE_ID="ID_90367819"/>
<node ID="ID_157296793" TREE_ID="ID_1796922913"/>
<node ID="ID_1392163857" TREE_ID="ID_1017940646"/>
<node ID="ID_1970598078" TREE_ID="ID_1505872547"/>
<node ID="ID_399785013" TREE_ID="ID_559354390"/>
<node ID="ID_1129629254" TREE_ID="ID_733815901"/>
<node ID="ID_450442556" TREE_ID="ID_1644158089"/>
<node ID="ID_1219486791" TREE_ID="ID_1902211438"/>
</node>
<node ID="ID_782255499" TREE_ID="ID_1699786115">
<node ID="ID_1309211788" TREE_ID="ID_1644510053">
<node ID="ID_1299759992" TREE_ID="ID_990902644"/>
</node>
<node ID="ID_513172908" TREE_ID="ID_1773118086"/>
<node ID="ID_781782779" TREE_ID="ID_459558109"/>
<node ID="ID_136072183" TREE_ID="ID_1304739693">
<node ID="ID_489746674" TREE_ID="ID_1147090090"/>
</node>
<node ID="ID_1016076717" TREE_ID="ID_700644875"/>
<node ID="ID_785601651" TREE_ID="ID_652217047"/>
<node ID="ID_1423181388" TREE_ID="ID_1155566887"/>
<node ID="ID_1348854700" TREE_ID="ID_1247267244"/>
</node>
<node ID="ID_610724538" TREE_ID="ID_111288623">
<node ID="ID_681193468" TREE_ID="ID_204286174"/>
<node ID="ID_877345698" TREE_ID="ID_634153845"/>
<node ID="ID_1937319148" TREE_ID="ID_271825071"/>
<node ID="ID_1476595610" TREE_ID="ID_825531269"/>
</node>
<node ID="ID_352878123" TREE_ID="ID_1851463955">
<node ID="ID_817028473" TREE_ID="ID_195077693"/>
<node ID="ID_1793143652" TREE_ID="ID_1105850487"/>
<node ID="ID_340542692" TREE_ID="ID_176772986"/>
</node>
<node ID="ID_1416861241" TREE_ID="ID_1920411777">
<node ID="ID_754333615" TREE_ID="ID_1754427737"/>
<node ID="ID_1599538409" TREE_ID="ID_102312606"/>
<node ID="ID_125007471" TREE_ID="ID_149280524"/>
</node>
<node ID="ID_1066411670" TREE_ID="ID_1202275042">
<node ID="ID_225313522" TREE_ID="ID_1698307440">
<node ID="ID_665850714" TREE_ID="ID_1105676697"/>
<node ID="ID_1445425361" TREE_ID="ID_1786571020"/>
<node ID="ID_939174340" TREE_ID="ID_490370007"/>
</node>
</node>
<node ID="ID_933614800" TREE_ID="ID_736932197">
<node ID="ID_1458859911" TREE_ID="ID_1004924114">
<node ID="ID_388087377" TREE_ID="ID_1348658167"/>
<node ID="ID_1074315615" TREE_ID="ID_1579174606"/>
<node ID="ID_754311603" TREE_ID="ID_1484185195">
<node ID="ID_804272433" TREE_ID="ID_1368471570">
<node ID="ID_379178797" TREE_ID="ID_13312944"/>
<node ID="ID_1477535551" TREE_ID="ID_199012170"/>
<node ID="ID_895206246" TREE_ID="ID_635517492"/>
<node ID="ID_1603673222" TREE_ID="ID_922700249"/>
<node ID="ID_484655866" TREE_ID="ID_1014697391"/>
<node ID="ID_711664206" TREE_ID="ID_758890103"/>
</node>
</node>
<node ID="ID_1014779884" TREE_ID="ID_1370869710"/>
<node ID="ID_1547371494" TREE_ID="ID_520979746"/>
<node ID="ID_1419831941" TREE_ID="ID_1500189469"/>
<node ID="ID_1724266462" TREE_ID="ID_681283170"/>
<node ID="ID_822614402" TREE_ID="ID_761750417"/>
<node ID="ID_1839645884" TREE_ID="ID_1143895523"/>
<node ID="ID_1222061459" TREE_ID="ID_813333602">
<node ID="ID_1020382218" TREE_ID="ID_1056088040"/>
<node ID="ID_822572061" TREE_ID="ID_1598327360">
<node ID="ID_1813091247" TREE_ID="ID_494410195"/>
</node>
<node ID="ID_1261802826" TREE_ID="ID_413830009">
<node ID="ID_1488013465" TREE_ID="ID_1447021998"/>
<node ID="ID_594023289" TREE_ID="ID_704942191">
<node ID="ID_882026832" TREE_ID="ID_116286753"/>
<node ID="ID_1176644386" TREE_ID="ID_942213393">
<node ID="ID_1265981340" TREE_ID="ID_852676471"/>
<node ID="ID_1100241307" TREE_ID="ID_1750945746">
<node ID="ID_1582537139" TREE_ID="ID_1034716294"/>
</node>
</node>
</node>
<node ID="ID_1713350709" TREE_ID="ID_919003074">
<node ID="ID_924030972" TREE_ID="ID_955532336"/>
</node>
<node ID="ID_1966072854" TREE_ID="ID_1510803691">
<node ID="ID_485672272" TREE_ID="ID_1015903855">
<node ID="ID_980820519" TREE_ID="ID_1061175333"/>
</node>
</node>
</node>
</node>
<node ID="ID_686122825" TREE_ID="ID_566957106"/>
<node ID="ID_39911118" TREE_ID="ID_1097190319"/>
</node>
</node>
<node ID="ID_1677481912" TREE_ID="ID_1239411610">
<node ID="ID_1224870943" TREE_ID="ID_364043263"/>
<node ID="ID_1900511005" TREE_ID="ID_1882007693"/>
<node ID="ID_1309293001" TREE_ID="ID_1339149279"/>
<node ID="ID_1254948845" TREE_ID="ID_48696267"/>
<node ID="ID_1613427355" TREE_ID="ID_1744984290"/>
<node ID="ID_1479062389" TREE_ID="ID_893744510"/>
<node ID="ID_255902782" TREE_ID="ID_1213713521"/>
</node>
<node ID="ID_920325451" TREE_ID="ID_200044637">
<node ID="ID_373341412" TREE_ID="ID_94840783"/>
<node ID="ID_1611320310" TREE_ID="ID_1249860639"/>
<node ID="ID_1303756788" TREE_ID="ID_71434764"/>
<node ID="ID_1486458806" TREE_ID="ID_1737404856"/>
<node ID="ID_1501357159" TREE_ID="ID_1011207649"/>
<node ID="ID_1963428609" TREE_ID="ID_218538954"/>
<node ID="ID_271446021" TREE_ID="ID_1232288660"/>
<node ID="ID_1643760394" TREE_ID="ID_1648106951"/>
<node ID="ID_925643073" TREE_ID="ID_1210962882"/>
<node ID="ID_714158275" TREE_ID="ID_1514551104"/>
<node ID="ID_955165169" TREE_ID="ID_35925291"/>
<node ID="ID_1714122445" TREE_ID="ID_1223055228"/>
<node ID="ID_1475827198" TREE_ID="ID_1158206891"/>
<node ID="ID_764522957" TREE_ID="ID_1469544875"/>
<node ID="ID_1261833073" TREE_ID="ID_1102126916"/>
<node ID="ID_1843830478" TREE_ID="ID_303153006"/>
<node ID="ID_297758946" TREE_ID="ID_777673423"/>
</node>
<node ID="ID_95421265" TREE_ID="ID_76802179">
<node ID="ID_93853599" TREE_ID="ID_1094398212">
<node ID="ID_1115682102" TREE_ID="ID_634751114"/>
<node ID="ID_1991083541" TREE_ID="ID_1871616703"/>
<node ID="ID_271962848" TREE_ID="ID_1169786478"/>
<node ID="ID_203550065" TREE_ID="ID_1234100209"/>
<node ID="ID_1200522897" TREE_ID="ID_1067674623"/>
<node ID="ID_1633658834" TREE_ID="ID_73022027"/>
<node ID="ID_373804906" TREE_ID="ID_1708742970">
<node ID="ID_983833521" TREE_ID="ID_23746062">
<node ID="ID_28914449" TREE_ID="ID_181373761"/>
<node ID="ID_262604077" TREE_ID="ID_585517062">
<node ID="ID_750099620" TREE_ID="ID_1798724532"/>
<node ID="ID_1670543118" TREE_ID="ID_781324611"/>
</node>
<node ID="ID_1794177078" TREE_ID="ID_808422983">
<node ID="ID_426994549" TREE_ID="ID_1691825138"/>
</node>
</node>
<node ID="ID_785774020" TREE_ID="ID_1910564995"/>
<node ID="ID_912916301" TREE_ID="ID_137353239">
<node ID="ID_1037464346" TREE_ID="ID_534770370"/>
<node ID="ID_106052530" TREE_ID="ID_1401844683"/>
<node ID="ID_100663768" TREE_ID="ID_1911160842"/>
</node>
<node ID="ID_1837694294" TREE_ID="ID_173661291">
<node ID="ID_1147098052" TREE_ID="ID_926278125"/>
</node>
</node>
<node ID="ID_1354622471" TREE_ID="ID_1142144560"/>
<node ID="ID_878341780" TREE_ID="ID_1867274357"/>
<node ID="ID_94084815" TREE_ID="ID_619831522"/>
<node ID="ID_1308471254" TREE_ID="ID_882563026"/>
<node ID="ID_742993075" TREE_ID="ID_1336485410"/>
</node>
</node>
<node ID="ID_566057410" TREE_ID="ID_1293806988">
<node ID="ID_1060458759" TREE_ID="ID_1556099831"/>
<node ID="ID_1991436840" TREE_ID="ID_1664217389"/>
</node>
<node ID="ID_139646096" TREE_ID="ID_369374834">
<node ID="ID_262522547" TREE_ID="ID_1288169963"/>
</node>
<node ID="ID_1675334908" TREE_ID="ID_411115894">
<node ID="ID_225556569" TREE_ID="ID_635843829"/>
<node ID="ID_1858284711" TREE_ID="ID_408488588"/>
</node>
<node ID="ID_594313451" TREE_ID="ID_96881329">
<node ID="ID_1049721126" TREE_ID="ID_1210858257"/>
<node ID="ID_1368788176" TREE_ID="ID_589663170"/>
</node>
<node ID="ID_1035862038" TREE_ID="ID_1428156559">
<node ID="ID_1597155154" TREE_ID="ID_1870193130"/>
<node ID="ID_1848291962" TREE_ID="ID_1593465275"/>
</node>
<node ID="ID_1681896054" TREE_ID="ID_1658745984">
<node ID="ID_1033905850" TREE_ID="ID_719198803"/>
<node ID="ID_1503931577" TREE_ID="ID_1476474517"/>
<node ID="ID_645837334" TREE_ID="ID_1198508576"/>
<node ID="ID_1124330828" TREE_ID="ID_1197066401"/>
<node ID="ID_1736546850" TREE_ID="ID_238253248"/>
<node ID="ID_156194171" TREE_ID="ID_1864998622"/>
<node ID="ID_1383980091" TREE_ID="ID_660178230"/>
<node ID="ID_1969772608" TREE_ID="ID_138109615"/>
<node ID="ID_1418220404" TREE_ID="ID_151445377"/>
<node ID="ID_1069038389" TREE_ID="ID_1112459063"/>
<node ID="ID_747605308" TREE_ID="ID_197919422"/>
<node ID="ID_911946677" TREE_ID="ID_1395381242"/>
<node ID="ID_901810970" TREE_ID="ID_1928549000"/>
<node ID="ID_1934424675" TREE_ID="ID_1145756729"/>
<node ID="ID_1620686974" TREE_ID="ID_37734402"/>
<node ID="ID_1208664842" TREE_ID="ID_586577969"/>
</node>
</node>
<node ID="ID_1956823638" TREE_ID="ID_626767816"/>
<node ID="ID_568146965" TREE_ID="ID_786807166"/>
<node ID="ID_1463670992" TREE_ID="ID_1714362245">
<node ID="ID_1848227498" TREE_ID="ID_945840718"/>
</node>
</node>
<node ID="ID_1683012608" TREE_ID="ID_497594502">
<node ID="ID_428578449" TREE_ID="ID_1803688313">
<node ID="ID_1370040609" TREE_ID="ID_942626096"/>
<node ID="ID_148838983" TREE_ID="ID_861459050">
<node ID="ID_520297223" TREE_ID="ID_308862696"/>
</node>
</node>
<node ID="ID_1869904872" TREE_ID="ID_1637109531">
<node ID="ID_1961088030" TREE_ID="ID_746364337"/>
<node ID="ID_492191615" TREE_ID="ID_789303184"/>
</node>
<node ID="ID_1325922247" TREE_ID="ID_22068228">
<node ID="ID_1142897253" TREE_ID="ID_2378379">
<node ID="ID_1317949263" TREE_ID="ID_1700468584"/>
<node ID="ID_1102364803" TREE_ID="ID_438102985"/>
<node ID="ID_1865178750" TREE_ID="ID_1305174993"/>
<node ID="ID_682500804" TREE_ID="ID_811430160"/>
<node ID="ID_412926518" TREE_ID="ID_1391665526"/>
</node>
<node ID="ID_288318652" TREE_ID="ID_657322679">
<node ID="ID_1710926549" TREE_ID="ID_1435958935"/>
<node ID="ID_579714203" TREE_ID="ID_1089815761">
<node ID="ID_925679946" TREE_ID="ID_240252337"/>
</node>
</node>
</node>
<node ID="ID_1853249565" TREE_ID="ID_1706897956">
<node ID="ID_996886227" TREE_ID="ID_812908723"/>
</node>
<node ID="ID_1149533435" TREE_ID="ID_1950236248"/>
<node ID="ID_690260572" TREE_ID="ID_1069692315"/>
<node ID="ID_1729148486" TREE_ID="ID_153424723">
<node ID="ID_1050321883" TREE_ID="ID_965331981"/>
</node>
<node ID="ID_1841541726" TREE_ID="ID_698513081">
<node ID="ID_988041440" TREE_ID="ID_91837589">
<node ID="ID_1008966057" TREE_ID="ID_1032627470">
<node ID="ID_773928938" TREE_ID="ID_1000500580"/>
</node>
<node ID="ID_610207830" TREE_ID="ID_545104117">
<node ID="ID_1969188886" TREE_ID="ID_1461679390">
<node ID="ID_1443707307" TREE_ID="ID_1956078751"/>
</node>
</node>
</node>
<node ID="ID_1078863180" TREE_ID="ID_1643451957">
<node ID="ID_41446454" TREE_ID="ID_1970505499"/>
<node ID="ID_1985164113" TREE_ID="ID_950443606"/>
<node ID="ID_740082942" TREE_ID="ID_1817107221"/>
<node ID="ID_605721213" TREE_ID="ID_1291804682"/>
<node ID="ID_1276205109" TREE_ID="ID_303302123"/>
<node ID="ID_2176800" TREE_ID="ID_551265969"/>
<node ID="ID_1064248114" TREE_ID="ID_1212478313"/>
<node ID="ID_1921757939" TREE_ID="ID_511758824"/>
<node ID="ID_1646843431" TREE_ID="ID_806188059">
<node ID="ID_1983684151" TREE_ID="ID_1861185054"/>
</node>
</node>
<node ID="ID_807561487" TREE_ID="ID_1301744087">
<node ID="ID_780619330" TREE_ID="ID_1371590940">
<node ID="ID_1938119225" TREE_ID="ID_913007226">
<node ID="ID_325684354" TREE_ID="ID_945326364"/>
</node>
<node ID="ID_1688514946" TREE_ID="ID_1915900335">
<node ID="ID_928444497" TREE_ID="ID_1350320827"/>
</node>
</node>
</node>
<node ID="ID_282951583" TREE_ID="ID_1814494209">
<node ID="ID_336520139" TREE_ID="ID_338785022">
<node ID="ID_1723255650" TREE_ID="ID_909038834"/>
<node ID="ID_350956080" TREE_ID="ID_1323610018">
<node ID="ID_502260841" TREE_ID="ID_1566205476">
<node ID="ID_65224966" TREE_ID="ID_556637278"/>
<node ID="ID_1508437061" TREE_ID="ID_980017879"/>
<node ID="ID_1938467541" TREE_ID="ID_192940520"/>
<node ID="ID_1594874280" TREE_ID="ID_1324212329"/>
<node ID="ID_1967828109" TREE_ID="ID_623161145"/>
<node ID="ID_655446245" TREE_ID="ID_700072864"/>
<node ID="ID_193075603" TREE_ID="ID_44666763"/>
<node ID="ID_706854118" TREE_ID="ID_263832145"/>
</node>
</node>
<node ID="ID_145841653" TREE_ID="ID_1889615494"/>
<node ID="ID_1484576164" TREE_ID="ID_849022225">
<node ID="ID_634103689" TREE_ID="ID_1805455873"/>
<node ID="ID_1396206478" TREE_ID="ID_1802380847"/>
</node>
</node>
</node>
</node>
<node ID="ID_1467716208" TREE_ID="ID_329799783"/>
<node ID="ID_1234194242" TREE_ID="ID_1841488331"/>
<node ID="ID_1098556217" TREE_ID="ID_1227564486">
<node ID="ID_1901666633" TREE_ID="ID_699232923">
<node ID="ID_1780665340" TREE_ID="ID_1928420576"/>
<node ID="ID_1154074740" TREE_ID="ID_1451862100"/>
</node>
<node ID="ID_58867707" TREE_ID="ID_139143235">
<node ID="ID_1850762779" TREE_ID="ID_1925601383"/>
</node>
<node ID="ID_1548203995" TREE_ID="ID_1505901400">
<node ID="ID_1668523316" TREE_ID="ID_1827759953"/>
</node>
</node>
<node ID="ID_1458183241" TREE_ID="ID_1139214799">
<node ID="ID_11516651" CONTENT_ID="ID_1790306788"/>
<node ID="ID_864440682" CONTENT_ID="ID_1034185192">
<node ID="ID_1209311039" CONTENT_ID="ID_792997751"/>
<node ID="ID_1379551282" CONTENT_ID="ID_1005182458">
<node ID="ID_1852465805" CONTENT_ID="ID_751522511"/>
<node ID="ID_412646846" CONTENT_ID="ID_307990934">
<node ID="ID_1711208111" CONTENT_ID="ID_170245508"/>
</node>
<node ID="ID_54205336" CONTENT_ID="ID_728836255"/>
<node ID="ID_1230112516" CONTENT_ID="ID_1831145379"/>
<node ID="ID_1538925554" CONTENT_ID="ID_228931899"/>
<node ID="ID_1119638596" CONTENT_ID="ID_335889999">
<node ID="ID_1597491933" CONTENT_ID="ID_1015602639"/>
</node>
<node ID="ID_244879277" CONTENT_ID="ID_1762477170">
<node ID="ID_650323166" CONTENT_ID="ID_916490582"/>
<node ID="ID_942870562" CONTENT_ID="ID_1935899307">
<node ID="ID_921285616" CONTENT_ID="ID_1710274350"/>
</node>
<node ID="ID_184307695" CONTENT_ID="ID_200136540">
<node ID="ID_1856122253" CONTENT_ID="ID_322678066"/>
</node>
<node ID="ID_1990599427" CONTENT_ID="ID_866979982">
<node ID="ID_1408896770" CONTENT_ID="ID_428171408">
<node ID="ID_669731739" CONTENT_ID="ID_1253422619"/>
</node>
<node ID="ID_19456253" CONTENT_ID="ID_1569907253">
<node ID="ID_362284649" CONTENT_ID="ID_1442114189"/>
<node ID="ID_153112522" CONTENT_ID="ID_1929483253">
<node ID="ID_1880301423" CONTENT_ID="ID_1059216940"/>
</node>
<node ID="ID_1427022706" CONTENT_ID="ID_941077564">
<node ID="ID_715531756" CONTENT_ID="ID_869414235"/>
</node>
<node ID="ID_687411570" CONTENT_ID="ID_87270170">
<node ID="ID_680505269" CONTENT_ID="ID_466217861"/>
</node>
</node>
<node ID="ID_755925367" CONTENT_ID="ID_239580988">
<node ID="ID_1430311857" CONTENT_ID="ID_719111578"/>
<node ID="ID_564846345" CONTENT_ID="ID_1955359935">
<node ID="ID_1855081586" CONTENT_ID="ID_665690667"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1261490683" CONTENT_ID="ID_1861198932">
<node ID="ID_132811558" CONTENT_ID="ID_1348236638"/>
<node ID="ID_1338093367" CONTENT_ID="ID_455276251"/>
<node ID="ID_1663346403" CONTENT_ID="ID_323193860"/>
</node>
</node>
</node>
<node ID="ID_838212820" TREE_ID="ID_264456549">
<node ID="ID_1811269499" TREE_ID="ID_1805883047"/>
<node ID="ID_479409746" TREE_ID="ID_20118232"/>
<node ID="ID_1779623676" TREE_ID="ID_1807157760"/>
<node ID="ID_509287236" TREE_ID="ID_1705096437"/>
<node ID="ID_159732003" TREE_ID="ID_702942955"/>
<node ID="ID_362646959" TREE_ID="ID_1310724082"/>
<node ID="ID_281026476" TREE_ID="ID_707117891"/>
<node ID="ID_748262754" TREE_ID="ID_1112059993"/>
<node ID="ID_643413302" TREE_ID="ID_87236094"/>
<node ID="ID_1924867978" TREE_ID="ID_1160988845"/>
<node ID="ID_1013802821" TREE_ID="ID_1227925022"/>
</node>
<node ID="ID_68929928" TREE_ID="ID_1509000546">
<node ID="ID_803594581" TREE_ID="ID_1800186781"/>
<node ID="ID_366028288" TREE_ID="ID_1458002623">
<node ID="ID_1218605860" TREE_ID="ID_1332737320"/>
</node>
<node ID="ID_451996263" TREE_ID="ID_151207321">
<node ID="ID_151899614" TREE_ID="ID_1365145550">
<node ID="ID_449104725" TREE_ID="ID_124562399"/>
<node ID="ID_205040140" TREE_ID="ID_487841504"/>
</node>
<node ID="ID_394975618" TREE_ID="ID_557013750">
<node ID="ID_345689421" TREE_ID="ID_1716486874"/>
<node ID="ID_822026536" TREE_ID="ID_1687269436"/>
<node ID="ID_789921525" TREE_ID="ID_449167554"/>
<node ID="ID_1714202117" TREE_ID="ID_547363038"/>
<node ID="ID_645854216" TREE_ID="ID_133501649"/>
</node>
<node ID="ID_1240404367" TREE_ID="ID_1958541319">
<node ID="ID_720297282" TREE_ID="ID_1025461482"/>
<node ID="ID_1174037066" TREE_ID="ID_1360145372"/>
<node ID="ID_1896101612" TREE_ID="ID_1220022328"/>
<node ID="ID_1061767200" TREE_ID="ID_779251710"/>
<node ID="ID_577821929" TREE_ID="ID_521482654"/>
<node ID="ID_78209494" TREE_ID="ID_1701121668"/>
</node>
<node ID="ID_1756751824" TREE_ID="ID_1643446455">
<node ID="ID_1367419968" TREE_ID="ID_1945936887"/>
<node ID="ID_1794528016" TREE_ID="ID_31928968">
<node ID="ID_557736049" TREE_ID="ID_1151947764"/>
<node ID="ID_1165111456" TREE_ID="ID_464384269"/>
<node ID="ID_1380670651" TREE_ID="ID_762214365"/>
</node>
<node ID="ID_1523761862" TREE_ID="ID_919516533"/>
<node ID="ID_1075387654" TREE_ID="ID_185851224"/>
<node ID="ID_73088239" TREE_ID="ID_1871406583"/>
<node ID="ID_1297137252" TREE_ID="ID_1510974177">
<node ID="ID_72221360" TREE_ID="ID_579653997"/>
</node>
<node ID="ID_1759263211" TREE_ID="ID_1482173370">
<node ID="ID_1860345049" TREE_ID="ID_1648600243">
<node ID="ID_1859381472" TREE_ID="ID_1644395858"/>
<node ID="ID_168337591" TREE_ID="ID_547447124">
<node ID="ID_96814107" TREE_ID="ID_381972245"/>
<node ID="ID_884925034" TREE_ID="ID_1789048953"/>
</node>
</node>
</node>
<node ID="ID_972679653" TREE_ID="ID_1451449973">
<node ID="ID_1220902989" TREE_ID="ID_1144988052"/>
<node ID="ID_805800349" TREE_ID="ID_1582677755"/>
<node ID="ID_996738352" TREE_ID="ID_1052607153"/>
</node>
<node ID="ID_1712843390" TREE_ID="ID_1622192801"/>
<node ID="ID_1846516415" TREE_ID="ID_1223428221"/>
</node>
</node>
<node ID="ID_1260546722" TREE_ID="ID_1651557917">
<node ID="ID_166321182" TREE_ID="ID_1226454929"/>
<node ID="ID_386890931" TREE_ID="ID_214244319"/>
<node ID="ID_1017894629" TREE_ID="ID_1685877650"/>
<node ID="ID_131538699" TREE_ID="ID_681449918">
<node ID="ID_1070915178" TREE_ID="ID_1589579714">
<node ID="ID_68716823" TREE_ID="ID_1327854143"/>
<node ID="ID_1764259763" TREE_ID="ID_458698187"/>
</node>
</node>
</node>
<node ID="ID_1792603333" TREE_ID="ID_1198615784"/>
<node ID="ID_1434171218" TREE_ID="ID_1810251302">
<node ID="ID_835523207" TREE_ID="ID_1100503229">
<node ID="ID_985773143" TREE_ID="ID_5204566"/>
<node ID="ID_571615912" TREE_ID="ID_1308031553">
<node ID="ID_595957200" TREE_ID="ID_334216157"/>
</node>
</node>
</node>
<node ID="ID_1158258190" CONTENT_ID="ID_1790306788"/>
<node ID="ID_720153650" TREE_ID="ID_1680208590">
<node ID="ID_1025016825" TREE_ID="ID_1375673571">
<node ID="ID_743921637" TREE_ID="ID_731327132"/>
<node ID="ID_13903044" TREE_ID="ID_1929390924">
<node ID="ID_310833777" TREE_ID="ID_1960607912"/>
</node>
</node>
<node ID="ID_1677561017" TREE_ID="ID_161830594">
<node ID="ID_1396498804" TREE_ID="ID_1472699062">
<node ID="ID_842449739" TREE_ID="ID_1425807726"/>
</node>
<node ID="ID_1623061101" TREE_ID="ID_1872153293"/>
<node ID="ID_1462664873" TREE_ID="ID_188006244"/>
<node ID="ID_1203820686" TREE_ID="ID_307139111"/>
<node ID="ID_1323226471" TREE_ID="ID_1141117835"/>
<node ID="ID_1249943506" TREE_ID="ID_1626948290"/>
<node ID="ID_509548413" TREE_ID="ID_326575703">
<node ID="ID_640539893" TREE_ID="ID_1248245395"/>
<node ID="ID_975064369" TREE_ID="ID_231635043"/>
<node ID="ID_1421158459" TREE_ID="ID_1142876436"/>
<node ID="ID_1398706233" TREE_ID="ID_1576642175"/>
<node ID="ID_852496938" TREE_ID="ID_465357476"/>
</node>
</node>
<node ID="ID_1189764959" TREE_ID="ID_1474227126"/>
</node>
<node ID="ID_200306889" CONTENT_ID="ID_1034185192">
<node ID="ID_849850169" CONTENT_ID="ID_792997751"/>
<node ID="ID_1613858193" CONTENT_ID="ID_1005182458">
<node ID="ID_590662932" CONTENT_ID="ID_751522511"/>
<node ID="ID_263986321" CONTENT_ID="ID_307990934">
<node ID="ID_610318211" CONTENT_ID="ID_170245508"/>
</node>
<node ID="ID_701153652" CONTENT_ID="ID_728836255"/>
<node ID="ID_751041154" CONTENT_ID="ID_1831145379"/>
<node ID="ID_1749271414" CONTENT_ID="ID_228931899"/>
<node ID="ID_1018385672" CONTENT_ID="ID_335889999">
<node ID="ID_94900039" CONTENT_ID="ID_1015602639"/>
</node>
<node ID="ID_772470752" CONTENT_ID="ID_1762477170">
<node ID="ID_1431534655" CONTENT_ID="ID_916490582"/>
<node ID="ID_1653458100" CONTENT_ID="ID_1935899307">
<node ID="ID_1347836646" CONTENT_ID="ID_1710274350"/>
</node>
<node ID="ID_44740517" CONTENT_ID="ID_200136540">
<node ID="ID_363354781" CONTENT_ID="ID_322678066"/>
</node>
<node ID="ID_1622122462" CONTENT_ID="ID_866979982">
<node ID="ID_1423399887" CONTENT_ID="ID_428171408">
<node ID="ID_1015759541" CONTENT_ID="ID_1253422619"/>
</node>
<node ID="ID_800545949" CONTENT_ID="ID_1569907253">
<node ID="ID_1205469457" CONTENT_ID="ID_1442114189"/>
<node ID="ID_1668280275" CONTENT_ID="ID_1929483253">
<node ID="ID_1358820072" CONTENT_ID="ID_1059216940"/>
</node>
<node ID="ID_20075758" CONTENT_ID="ID_941077564">
<node ID="ID_14492387" CONTENT_ID="ID_869414235"/>
</node>
<node ID="ID_1355374370" CONTENT_ID="ID_87270170">
<node ID="ID_978299666" CONTENT_ID="ID_466217861"/>
</node>
</node>
<node ID="ID_107881951" CONTENT_ID="ID_239580988">
<node ID="ID_578698145" CONTENT_ID="ID_719111578"/>
<node ID="ID_1201476393" CONTENT_ID="ID_1955359935">
<node ID="ID_717960054" CONTENT_ID="ID_665690667"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_18143461" CONTENT_ID="ID_1861198932">
<node ID="ID_578142636" CONTENT_ID="ID_1348236638"/>
<node ID="ID_1799630669" CONTENT_ID="ID_455276251"/>
<node ID="ID_1755267952" CONTENT_ID="ID_323193860"/>
</node>
</node>
<node ID="ID_653189229" TREE_ID="ID_735461623">
<node ID="ID_1803488962" TREE_ID="ID_1592985365">
<node ID="ID_1243609054" TREE_ID="ID_403887570"/>
</node>
</node>
<node ID="ID_1014269916" TREE_ID="ID_1532222880">
<node ID="ID_170521363" TREE_ID="ID_508253030"/>
<node ID="ID_144911591" TREE_ID="ID_755608034">
<node ID="ID_1853068599" TREE_ID="ID_1015477582"/>
<node ID="ID_212292622" TREE_ID="ID_1947663450"/>
</node>
<node ID="ID_1592790136" TREE_ID="ID_974718951">
<node ID="ID_822981983" TREE_ID="ID_1534446979"/>
<node ID="ID_574434104" TREE_ID="ID_140843484">
<node ID="ID_912002989" TREE_ID="ID_1608108515">
<node ID="ID_1149958634" TREE_ID="ID_1139429125"/>
<node ID="ID_865653604" TREE_ID="ID_1665759736"/>
</node>
<node ID="ID_1858806040" TREE_ID="ID_307266372"/>
<node ID="ID_858524635" TREE_ID="ID_350561165"/>
<node ID="ID_1921176348" TREE_ID="ID_1117143460"/>
<node ID="ID_1469182596" TREE_ID="ID_505177035"/>
<node ID="ID_1497114683" TREE_ID="ID_1974478142"/>
</node>
<node ID="ID_270562643" TREE_ID="ID_678767125"/>
</node>
</node>
<node ID="ID_1149378997" TREE_ID="ID_1114633410"/>
</node>
<node ID="ID_1098660091" TREE_ID="ID_1946076588">
<node ID="ID_1471712334" TREE_ID="ID_1093346641"/>
</node>
<node ID="ID_1010039006" TREE_ID="ID_1330494602">
<node ID="ID_1640427426" TREE_ID="ID_266111495"/>
<node ID="ID_1482060251" TREE_ID="ID_1706203120">
<node ID="ID_1492773240" TREE_ID="ID_188623155"/>
<node ID="ID_1023706203" TREE_ID="ID_1336165026"/>
</node>
</node>
<node ID="ID_1688554535" TREE_ID="ID_325687988">
<node ID="ID_904476638" TREE_ID="ID_1539810987"/>
</node>
<node ID="ID_465320737" TREE_ID="ID_716590699">
<node ID="ID_621627070" TREE_ID="ID_617013758"/>
</node>
<node ID="ID_367244434" TREE_ID="ID_138468257">
<node ID="ID_43133580" TREE_ID="ID_570580216"/>
</node>
<node ID="ID_482498586" TREE_ID="ID_1737093366">
<node ID="ID_1832796308" TREE_ID="ID_1040513747"/>
<node ID="ID_1530737750" TREE_ID="ID_36368622"/>
<node ID="ID_836472971" TREE_ID="ID_279490569"/>
<node ID="ID_552064590" TREE_ID="ID_1873657220"/>
</node>
<node ID="ID_566529688" TREE_ID="ID_465057380">
<node ID="ID_247006173" TREE_ID="ID_409822108">
<node ID="ID_1688953780" TREE_ID="ID_293642114"/>
<node ID="ID_35492263" TREE_ID="ID_1348819866"/>
</node>
<node ID="ID_1278426450" TREE_ID="ID_281447420">
<node ID="ID_930309434" TREE_ID="ID_958663678"/>
<node ID="ID_1772628699" TREE_ID="ID_1016159177"/>
<node ID="ID_270719059" TREE_ID="ID_1054405199">
<node ID="ID_1470395927" TREE_ID="ID_1397400912">
<node ID="ID_170412886" TREE_ID="ID_1043786468"/>
<node ID="ID_1339217682" TREE_ID="ID_250656964"/>
</node>
<node ID="ID_1602303754" TREE_ID="ID_1202952126">
<node ID="ID_1318048335" TREE_ID="ID_1088823907"/>
<node ID="ID_328680940" TREE_ID="ID_505269304"/>
</node>
</node>
</node>
</node>
<node ID="ID_694500448" TREE_ID="ID_542307028">
<node ID="ID_1295422290" TREE_ID="ID_1484627855"/>
</node>
</node>
<node ID="ID_622887580" TREE_ID="ID_530149753"/>
</node>
<node ID="ID_151224632" TREE_ID="ID_1359078959">
<node ID="ID_203485134" TREE_ID="ID_283483366">
<node ID="ID_729524100" TREE_ID="ID_1960947160">
<node ID="ID_346264959" TREE_ID="ID_432095949"/>
</node>
</node>
</node>
<node ID="ID_353935376" TREE_ID="ID_247820734">
<node ID="ID_1135709236" TREE_ID="ID_1842259748">
<node ID="ID_506117245" TREE_ID="ID_1685870076"/>
</node>
</node>
<node ID="ID_1206508550" TREE_ID="ID_1771019104">
<node ID="ID_1175541580" TREE_ID="ID_1292453333"/>
<node ID="ID_151574493" TREE_ID="ID_1556869555"/>
<node ID="ID_1494288727" TREE_ID="ID_793642904"/>
</node>
<node ID="ID_1104172906" TREE_ID="ID_1954783006">
<node ID="ID_55991607" TREE_ID="ID_266640368"/>
<node ID="ID_1617741966" TREE_ID="ID_411055411"/>
<node ID="ID_1902829360" TREE_ID="ID_304663994"/>
<node ID="ID_170156634" TREE_ID="ID_444603098"/>
</node>
<node ID="ID_1228235956" TREE_ID="ID_1677108759">
<node ID="ID_696122635" TREE_ID="ID_246365753">
<node ID="ID_462908591" TREE_ID="ID_1483010247"/>
<node ID="ID_978944757" TREE_ID="ID_657353071"/>
<node ID="ID_549386865" TREE_ID="ID_1080880392"/>
<node ID="ID_1559945829" TREE_ID="ID_1321569861"/>
<node ID="ID_1510344529" TREE_ID="ID_1308585654"/>
<node ID="ID_280106028" TREE_ID="ID_253615436"/>
</node>
<node ID="ID_416246083" TREE_ID="ID_1268696468">
<node ID="ID_1442738214" TREE_ID="ID_533333740"/>
<node ID="ID_222020854" TREE_ID="ID_622695982"/>
</node>
<node ID="ID_303170559" TREE_ID="ID_361595532">
<node ID="ID_918132782" TREE_ID="ID_539936485"/>
</node>
<node ID="ID_517196951" TREE_ID="ID_1024890748">
<node ID="ID_1547449865" TREE_ID="ID_323885717">
<node ID="ID_669480207" TREE_ID="ID_1853303259"/>
</node>
<node ID="ID_1555362340" TREE_ID="ID_1409782853">
<node ID="ID_240746922" TREE_ID="ID_166520598"/>
</node>
<node ID="ID_1333497455" TREE_ID="ID_1191546740">
<node ID="ID_1788989754" TREE_ID="ID_1295263"/>
</node>
<node ID="ID_261224858" TREE_ID="ID_1270667993">
<node ID="ID_1755118036" TREE_ID="ID_856980986"/>
</node>
</node>
<node ID="ID_1522616122" TREE_ID="ID_1147822843">
<node ID="ID_24526663" TREE_ID="ID_1252537955"/>
</node>
<node ID="ID_1249865861" TREE_ID="ID_82875598">
<node ID="ID_778861637" TREE_ID="ID_1240560592"/>
</node>
<node ID="ID_346766396" TREE_ID="ID_1427331787">
<node ID="ID_1638935092" TREE_ID="ID_524000796">
<node ID="ID_726719213" TREE_ID="ID_356102823"/>
</node>
<node ID="ID_1827455474" TREE_ID="ID_1728135689"/>
</node>
<node ID="ID_1160067869" TREE_ID="ID_537397815">
<node ID="ID_923259983" TREE_ID="ID_1361367490">
<node ID="ID_568596476" TREE_ID="ID_342806832"/>
</node>
</node>
<node ID="ID_1257334009" TREE_ID="ID_616774454">
<node ID="ID_1940237586" TREE_ID="ID_1550794935">
<node ID="ID_457056755" TREE_ID="ID_667393140"/>
</node>
</node>
<node ID="ID_535773216" TREE_ID="ID_1230001900"/>
<node ID="ID_381971837" TREE_ID="ID_1501263258">
<node ID="ID_584425125" TREE_ID="ID_1427723242"/>
</node>
</node>
<node ID="ID_1657817936" TREE_ID="ID_401492333"/>
<node ID="ID_1168552410" TREE_ID="ID_180939095"/>
<node ID="ID_969577650" TREE_ID="ID_1852939447">
<node POSITION="bottom_or_right" ID="ID_1301528546" TREE_ID="ID_641023695"/>
</node>
<node ID="ID_749767291" TREE_ID="ID_1432087794"/>
<node ID="ID_1090282488" TREE_ID="ID_1806565094">
<node ID="ID_236400990" TREE_ID="ID_1465611993"/>
<node ID="ID_37582166" TREE_ID="ID_1743243191"/>
<node ID="ID_1102046654" TREE_ID="ID_653249049"/>
</node>
</node>
</node>
<node ID="ID_606197667" TREE_ID="ID_667229698">
<node ID="ID_753192476" TREE_ID="ID_685806450"/>
<node ID="ID_1812681965" TREE_ID="ID_1773656242"/>
<node ID="ID_1518748837" TREE_ID="ID_313117304"/>
<node ID="ID_1354946239" TREE_ID="ID_1159878367">
<node ID="ID_1025053408" TREE_ID="ID_1013796177"/>
<node ID="ID_926956525" TREE_ID="ID_149250627"/>
</node>
<node ID="ID_1010477900" TREE_ID="ID_884053450">
<node ID="ID_191834074" TREE_ID="ID_641271926"/>
<node ID="ID_9752524" TREE_ID="ID_143413281"/>
<node ID="ID_1477314660" TREE_ID="ID_1120244284"/>
<node ID="ID_1558138654" TREE_ID="ID_636876209"/>
<node ID="ID_1547192290" TREE_ID="ID_1642704057"/>
<node ID="ID_75553050" TREE_ID="ID_1911203046"/>
<node ID="ID_25810862" TREE_ID="ID_124629290"/>
<node ID="ID_1288571050" TREE_ID="ID_1094694371"/>
<node ID="ID_343445111" TREE_ID="ID_240607709"/>
<node ID="ID_496593506" TREE_ID="ID_1001519917"/>
<node ID="ID_1298476762" TREE_ID="ID_1423044686"/>
</node>
</node>
<node ID="ID_1561052838" TREE_ID="ID_357748725">
<node ID="ID_628358821" TREE_ID="ID_1476814256"/>
<node ID="ID_1222734847" TREE_ID="ID_98919482"/>
<node ID="ID_749097971" TREE_ID="ID_1046160722"/>
<node ID="ID_1317774452" TREE_ID="ID_1391707021"/>
</node>
<node ID="ID_585375075" TREE_ID="ID_289549904"/>
<node ID="ID_1383122384" TREE_ID="ID_82969155">
<node ID="ID_550302029" TREE_ID="ID_783869820"/>
<node ID="ID_1496767663" TREE_ID="ID_1870142544"/>
<node ID="ID_763851882" TREE_ID="ID_958262177"/>
</node>
<node ID="ID_1940847383" TREE_ID="ID_541728595">
<node ID="ID_1690292859" TREE_ID="ID_1724736261"/>
<node ID="ID_1083844011" TREE_ID="ID_451912796"/>
<node ID="ID_1620474381" TREE_ID="ID_1132356243"/>
<node ID="ID_1231663134" TREE_ID="ID_1900195994"/>
</node>
<node ID="ID_720840993" TREE_ID="ID_1633356642"/>
<node ID="ID_419183542" TREE_ID="ID_495494239">
<node ID="ID_448321182" TREE_ID="ID_599913725"/>
<node ID="ID_476129214" TREE_ID="ID_573218314"/>
<node ID="ID_1514132931" TREE_ID="ID_48872619"/>
<node ID="ID_290332296" TREE_ID="ID_1850701630"/>
<node ID="ID_1220240693" TREE_ID="ID_841322943"/>
</node>
<node ID="ID_1712998879" TREE_ID="ID_1110091729"/>
<node ID="ID_365073470" TREE_ID="ID_794235737"/>
<node ID="ID_1475714387" TREE_ID="ID_622595734"/>
<node ID="ID_536901171" TREE_ID="ID_1427473947"/>
</node>
</node>
</node>
<node TEXT="others" FOLDED="true" ID="ID_1528838676" CREATED="1696633520364" MODIFIED="1696633524821">
<node TEXT="Education" FOLDED="true" ID="ID_672430258" CREATED="1703808905198" MODIFIED="1703808909256">
<node TEXT="Biology Teacher" FOLDED="true" ID="ID_530730413" CREATED="1653624110386" MODIFIED="1703808899113">
<font BOLD="true"/>
<node TEXT="Hollister High School" FOLDED="true" ID="ID_162163389" CREATED="1696445196949" MODIFIED="1703808946073">
<node TEXT="Kevin Medeiros" ID="ID_1883220944" CREATED="1696458803704" MODIFIED="1696458803704"/>
<node TEXT="Aug 1 2022" ID="ID_413282062" CREATED="1696445199954" MODIFIED="1696445315315"/>
</node>
<node TEXT="Alignment: " ID="ID_1761867255" CREATED="1699334108789" MODIFIED="1699334118442"/>
<node TEXT="Potential Role: Ag Teacher" FOLDED="true" ID="ID_1197769508" CREATED="1653624147908" MODIFIED="1653624158710">
<font BOLD="true"/>
<node TEXT="Other potential roles" FOLDED="true" ID="ID_1568534650" CREATED="1588265883900" MODIFIED="1653624217110">
<node TEXT="workflow engineer" ID="ID_539470407" CREATED="1622746825721" MODIFIED="1622746836131"/>
<node TEXT="Leadership" FOLDED="true" ID="ID_583015941" CREATED="1590034093341" MODIFIED="1603149694479">
<node TEXT="R&amp;D Project Manager" FOLDED="true" ID="ID_1537140396" CREATED="1588265891407" MODIFIED="1588265903073">
<node ID="ID_1731031523" CREATED="1588265903969" MODIFIED="1588265903969" LINK="https://www.pmi.org/learning/library/research-development-project-manager-challenges-1842"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.pmi.org/learning/library/research-development-project-manager-challenges-1842">Research and development project manager - Resolving Challenges</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Research and Development Manager" FOLDED="true" ID="ID_1249501513" CREATED="1589838331483" MODIFIED="1589838331483">
<node TEXT="The research and development (R&amp;D) manager directs the research efforts in their territory (from Watsonville, CA south to Oxnard, CA) to determine the viability of new and cutting edge products, concepts and technologies and expands use of existing branded products through their work in the crop spectrum throughout the coastal region of California. This position is also responsible for managing members of the R&amp;D team. This position is integral to the growth of the growing community and crop protection industry in our coastal area." ID="ID_1245888117" CREATED="1589838351947" MODIFIED="1589838351947"/>
<node TEXT="The employee s primary duty must be the performance of office and/or work in the field directly related to the management or general business operations of Helena or Helena s customers. This also includes the exercise of discretion and independent judgement with respect to matters of significance." ID="ID_1074074474" CREATED="1589838351947" MODIFIED="1589838351947"/>
<node TEXT="What your day may look like" ID="ID_1218903902" CREATED="1589838351947" MODIFIED="1589838351947"/>
<node TEXT="Reviews all protocols for product testing. This includes (i.e. greenhouse, field screens, plots, commercial use, cooperative testing, etc.) within assigned area." ID="ID_1076965072" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Reviews R&amp;D proposals including objectives, purpose of project and applications that can be utilized from results to equipment and people requirements." ID="ID_208048993" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Manages all assigned research projects and communicates potential issues and opportunities to appropriate R&amp;D team members." ID="ID_246727492" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Serves as the expert to the sales and marketing department in the field." ID="ID_1615251043" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Identifies and tracks new potential targets for product testing and communicates them to leadership." ID="ID_1109366083" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Identifies upcoming product technologies, trends or issues within their respective discipline." ID="ID_221525708" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Establishes relationships with clients and growers and exhibits fundamental knowledge of where to place trials." ID="ID_817622976" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Actively identifies new clients and research technologies." ID="ID_793465481" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Monitors budget allocation, P&amp;L statements and maintains good communication with the team." ID="ID_840461170" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Coordinates and monitors the collection, packaging, shipping and disposal of all products used in R&amp;D." ID="ID_327910058" CREATED="1589838351962" MODIFIED="1589838351962"/>
<node TEXT="Reviews and compiles collected data and reports overall findings for use in sales and marketing." ID="ID_1391595614" CREATED="1589838351978" MODIFIED="1589838351978"/>
<node TEXT="Continually improves skills in statistical evaluation of data (software and techniques), scientific validity of data and other areas pertaining to R&amp;D responsibilities." ID="ID_223236263" CREATED="1589838351978" MODIFIED="1589838351978"/>
<node TEXT="Communicates results of testing and development to appropriate departments, vendors, academia, customers and others as needed. This includes making presentations at sales, training, supplier and professional meetings." ID="ID_576281156" CREATED="1589838351978" MODIFIED="1589838351978"/>
<node TEXT="Actively involved in vendor, customer and professional meetings." ID="ID_1129345524" CREATED="1589838351978" MODIFIED="1589838351978"/>
<node TEXT="Presents new technologies at professional meetings." ID="ID_1686845888" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Makes development recommendations based on trial results (i.e. new objectives, unmet objectives that need to be retested, deficiencies in the data)." ID="ID_61600283" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Serves as the resource expert to sales, marketing and HPG when they seek advice about development decisions." ID="ID_541443941" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Represents Helena in the professional community as an expert in the R&amp;D field." ID="ID_1064580831" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Actively involved in respective professional societies." ID="ID_429837873" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Responsible for suggested changes/additions/deletions/improvements in formulations of products to make them more crop/user friendly. Communicates this information to the appropriate departments and leadership." ID="ID_1726477398" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Provides research results to appropriate teams for editing of use labels, technical data sheets, technical bulletins and other information related to products tested." ID="ID_6890958" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Writes, reviews, analyzes and submits proposals to determine the benefits derived and possible expenditures." ID="ID_375505758" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Develops and implements methods and procedures for monitoring products and projects. This includes providing information to support budgets, expenditures, data, progress reports, staff meetings, etc. to keep the team informed of the current status of each project." ID="ID_778366171" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Manages the R&amp;D team in their territory to ensure appropriate technical team is assigned to projects and the team is staffed with the appropriate levels of expertise." ID="ID_1077506800" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Ensures all company policies are followed." ID="ID_1452413974" CREATED="1589838351994" MODIFIED="1589838351994"/>
<node TEXT="Other work-related duties as assigned by leader." FOLDED="true" ID="ID_244308219" CREATED="1589838352009" MODIFIED="1589838352009">
<node TEXT="Reliable and regular attendance is expected." ID="ID_548708967" CREATED="1589838352009" MODIFIED="1589838352009"/>
</node>
<node TEXT="Education and experience needed for this position" ID="ID_576587846" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Master s or PhD degree in agronomy, weed science, entomology, pathology or related discipline is preferred." ID="ID_242419410" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Master s degree and three years of experience will be considered." ID="ID_1087054370" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Equivalent combination of education and experience will be considered." ID="ID_790579355" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Minimum education of a bachelors degree is required." ID="ID_683575541" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Two years of leadership experience is required." ID="ID_1202923901" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Five years of cropping systems, products (HPG and non-HPG), timing ratings, and standards experience is preferred." ID="ID_1538114460" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Intermediate understanding of statistics and data analysis is required." ID="ID_1779845751" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Must have QAL (qualified applicators license) or will need to immediately obtain." ID="ID_754889185" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Other skills that will help you succeed" ID="ID_1615413588" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Consistently produces high quality data evaluation and presentations." ID="ID_1629081444" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Certified Crop Adviser (CCA) license and Pest Control Adviser (PCA)." ID="ID_1506718636" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Written and verbal communication skills to small and large groups with ability to lead and influence." ID="ID_841720785" CREATED="1589838352009" MODIFIED="1589838352009"/>
<node TEXT="Detail and accuracy orientated with an ability to handle multiple projects simultaneously." ID="ID_101634714" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Ability to work independently with minimum supervision." ID="ID_1624116378" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Proficient in Microsoft Office particularly Excel." ID="ID_1711317562" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Excellent knowledge with ARM." ID="ID_191814337" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Organizational skills." ID="ID_857542801" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Ability to travel." ID="ID_77901060" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Decision making skills." ID="ID_779410578" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Ability to coordinate a high level of activities under a variety of conditions and constraints." ID="ID_1370238980" CREATED="1589838352025" MODIFIED="1589838352025"/>
<node TEXT="Expert in data analysis skills." ID="ID_1410342147" CREATED="1589838352040" MODIFIED="1589838352040"/>
<node TEXT="Ability to work in a collaborative environment with all members of the sales and marketing and HPG team." ID="ID_573722451" CREATED="1589838352040" MODIFIED="1589838352040"/>
</node>
</node>
</node>
<node TEXT="Technical" FOLDED="true" ID="ID_990802767" CREATED="1603149695241" MODIFIED="1603149701656">
<node TEXT="Data Analyst" FOLDED="true" ID="ID_1769824137" CREATED="1589836545077" MODIFIED="1589836549532">
<node TEXT="Research Scientist - Statistics Specialist" FOLDED="true" ID="ID_724750979" CREATED="1589838254005" MODIFIED="1589838301298">
<node TEXT="Apply to this position" ID="ID_920806730" CREATED="1589838254005" MODIFIED="1589838254005"/>
<node TEXT="Follow CompanyMore Jobs from Cortev...Send to Friend" ID="ID_1798855860" CREATED="1589838254006" MODIFIED="1589838254006"/>
<node TEXT="Description" ID="ID_786316087" CREATED="1589838254007" MODIFIED="1589838254007"/>
<node TEXT="Join us at Corteva Agriscience, a world leader and supplier of plant genetics, to tackle important agricultural challenges and help secure a reliable and sustainable food supply across the world for years to come." ID="ID_1945823472" CREATED="1589838254008" MODIFIED="1589838254008"/>
<node TEXT="Our team is seeking a candidate who will focus on developing statistics analysis methods, fulfilling data analysis and building robust data pipelines for multiple high-throughput assay platforms. The position will provide statistics guidance on analytics of insect trait assay in various configurations, formats and stages during the lead discovery and development processes. A successful candidate is not only equipped with solid probability theory and experience in multi-factor statistics but also has a strong background and proven track record on quantitative decision science including application of machine learning to solve complex biological / genetics problems." ID="ID_568634065" CREATED="1589838254008" MODIFIED="1589838254008"/>
<node TEXT="Responsibilities What Youll Do" ID="ID_1675595037" CREATED="1589838254011" MODIFIED="1589838254011"/>
<node TEXT="Provide statistical and mathematical support in analyzing phenotypic and genetic data to improve discovery and development process efficiency" ID="ID_190922347" CREATED="1589838254014" MODIFIED="1589838254014"/>
<node TEXT="Provide guidance and perform Experiment Design tasks on multi-factor biological assays" ID="ID_849850291" CREATED="1589838254014" MODIFIED="1589838254014"/>
<node TEXT="Provide statistical support in performing power analyses to optimize controlled environment insect bioassays to predict construct field performance." ID="ID_685583408" CREATED="1589838254017" MODIFIED="1589838254017"/>
<node TEXT="Provide statistical support in performing power analyses for Disease resistance assays" ID="ID_971785576" CREATED="1589838254019" MODIFIED="1589838254019"/>
<node TEXT="Work with stakeholders to evaluate, maintain and continuously improve several efficient and healthy data pipelines" ID="ID_1745648611" CREATED="1589838254021" MODIFIED="1589838254021"/>
<node TEXT="Utilizes standard statistics analysis and data visualization tools to communicate complex and under-structured information at appropriate abstraction levels" ID="ID_1751200393" CREATED="1589838254024" MODIFIED="1589838254024"/>
<node TEXT="Courageously taking on noisy data analysis with a keen sense of detecting hidden factors and be amply prepared to recommend actionable plans to explore and elucidate these factors" ID="ID_295483459" CREATED="1589838254027" MODIFIED="1589838254027"/>
<node TEXT="Align with business needs by providing insights on key decision-making processes" ID="ID_597877825" CREATED="1589838254029" MODIFIED="1589838254029"/>
<node TEXT="Continuously improves existing tools, and develops new approaches for comprehensive analysis of multiple data types and effective data visualization" ID="ID_311271102" CREATED="1589838254031" MODIFIED="1589838254031"/>
<node TEXT="Maintains accurate and thorough records in data management system" ID="ID_297878528" CREATED="1589838254034" MODIFIED="1589838254034"/>
<node TEXT="Analyzes and presents data, both in written reports and oral presentations" ID="ID_211040952" CREATED="1589838254036" MODIFIED="1589838254036"/>
<node TEXT="Qualifications" ID="ID_1344118881" CREATED="1589838254037" MODIFIED="1589838254037"/>
<node TEXT="Requirements" ID="ID_1020787597" CREATED="1589838254037" MODIFIED="1589838254037"/>
<node TEXT="Ph. D. with 2+ years industry experience, or MS with 5+ years of experience; degree in a relevant field, including statistics, genetics or related quantitative biological sciences" ID="ID_689327309" CREATED="1589838254038" MODIFIED="1589838254038"/>
<node TEXT="Proficiency in statistics and applicable tools (e.g. JMP, SAS and R)" ID="ID_668123244" CREATED="1589838254039" MODIFIED="1589838254039"/>
<node TEXT="Proficiency in R and Python, including machine learning and data analysis packages such as Scikit-learn and pandas" ID="ID_1122319899" CREATED="1589838254041" MODIFIED="1589838254041"/>
<node TEXT="Direct experience of deep learning (Tensorflow, Keras or PyTorch) a plus" ID="ID_1376928721" CREATED="1589838254042" MODIFIED="1589838254042"/>
<node TEXT="Experience with non-parametric statistics, categorical data analysis and statistical inference" ID="ID_1601881269" CREATED="1589838254044" MODIFIED="1589838254044"/>
<node TEXT="Experience organizing, analyzing, and interpreting large volumes of data" ID="ID_1553330177" CREATED="1589838254046" MODIFIED="1589838254046"/>
<node TEXT="Excellent organization skills; communication in succinct styles and clear terms" ID="ID_93797323" CREATED="1589838254050" MODIFIED="1589838254050"/>
<node TEXT="Ability to work independently and collaboratively across multiple groups" ID="ID_996007562" CREATED="1589838254051" MODIFIED="1589838254051"/>
</node>
</node>
<node ID="ID_730658249" CREATED="1619303081505" MODIFIED="1619303081505" LINK="https://lifehacker.com/will-a-programming-boot-camp-help-me-get-a-coding-job-1695422265"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://lifehacker.com/will-a-programming-boot-camp-help-me-get-a-coding-job-1695422265">Will a &quot;Programming Boot Camp&quot; Help Me Get a Coding Job?</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Entrepreneur" FOLDED="true" ID="ID_861039766" CREATED="1548189226423" MODIFIED="1548189233794">
<node TEXT="Traits" FOLDED="true" ID="ID_905320911" CREATED="1548189405035" MODIFIED="1548189408552">
<node ID="ID_796422142" CREATED="1548189409650" MODIFIED="1548189409650" LINK="https://smallbusiness.chron.com/traits-entrepreneur-vs-manager-38558.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://smallbusiness.chron.com/traits-entrepreneur-vs-manager-38558.html">Traits of an Entrepreneur vs. a Manager | Chron.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="integrated management system" FOLDED="true" ID="ID_1909344669" CREATED="1617854691116" MODIFIED="1617854703162">
<node TEXT="examples" FOLDED="true" ID="ID_1516557742" CREATED="1617855003337" MODIFIED="1617855006345">
<node ID="ID_1688512173" CREATED="1617855007865" MODIFIED="1617855007865" LINK="https://checkify.com/faq/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://checkify.com/faq/">Frequently Asked Questions • Checkify</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Currently Interested in" ID="ID_455638342" CREATED="1519861379183" MODIFIED="1519861397954"/>
<node TEXT="Position by Skillset" FOLDED="true" ID="ID_1275590027" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Statistics" FOLDED="true" ID="ID_1737038280" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="® Statistician" FOLDED="true" ID="ID_186089671" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Responsibilities" FOLDED="true" ID="ID_1945921294" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Conduct statistical analyses and prepare statistical reports." ID="ID_686231297" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Collaborate effectively with multi-disciplinary teams from Regulatory Sciences and Regulatory Affairs to ensure scientifically-rigorous experimental designs and statistical methods are implemented." ID="ID_577496099" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Proactively identify and help solve problems related to design of experiments and statistical analyses in the area of Regulatory Sciences using traditional and/or non-traditional statistical methodologies." ID="ID_1156589780" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Provide statistical training and knowledge transfer to Regulatory Sciences and Regulatory Affairs team to improve understanding and interpretation of statistical methods and results." ID="ID_879548838" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Partner with teammates to drive quality and increase efficiency in reporting statistical analyses and results through code and document automation." ID="ID_871568159" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_78478435" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Required Experience/Skills" FOLDED="true" ID="ID_815533233" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Ph.D. in Statistics or Biostatistics or M.S. in Statistics or Biostatistics." ID="ID_171030177" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="At least two years of statistical consulting experience." ID="ID_1325132432" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Experience with experimental designs and statistical models used for the analysis of environmental, agricultural, and/or industrial data for both continuous and categorical endpoints." ID="ID_1353903878" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Experience with linear- and generalized linear mixed models." ID="ID_88602133" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Experience with nonlinear models." ID="ID_1102849071" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability to solve problems using non-conventional statistical techniques." ID="ID_44511557" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Proficiency in SAS, including PROC MIXED and/or GLIMMIX." ID="ID_1780148989" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Proficiency in Microsoft Word and Excel." ID="ID_1881990911" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Excellent written and verbal communication skills." ID="ID_1508706230" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability to communicate complex quantitative analyses in a clear, precise, and actionable manner" ID="ID_193820842" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Desired Experience/Skills" FOLDED="true" ID="ID_694502278" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Degree or coursework in an IT-related field (e.g., computer science)" ID="ID_290296892" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Degree or coursework in an agricultural-related field (e.g., agronomy, ecology)" ID="ID_1057239732" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Experience with Good Laboratory Practice (GLP) standards" ID="ID_1667869584" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
</node>
<node TEXT="® Research Statistician (Job Number: RES00003948)" FOLDED="true" ID="ID_1750131378" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" FOLDED="true" ID="ID_693053123" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="The statistician will work with prediction agriculture teams to lead the discovery of novel methods to solve complex genotype by environment by management crop yield prediction problems. Provides advanced statistical leadership for experimental design and for identifying, developing and applying robust statistical methods to analyze large, highly complex linear and non-linear multivariate data sets generated from a series of experiments conducted to enable prediction of on-farm crop yields. The statistician will be a key member of scientific teams, comprised of specialists from multiple scientific, informatics and engineering disciplines, undertaking research that will lead to development of robust prediction methods for applications in prediction agriculture." ID="ID_1765114727" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Provides leadership for the correct design of multiple series of experiments and data collection practices to achieve the required statistical power to realize prediction agriculture project goals. Critically involved in the development and communication of experimental protocols." ID="ID_1988964633" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Provides leadership for the definition and application of appropriate statistical methods for analysis of complex multivariate data sets." ID="ID_1383008644" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Works with information management specialists to ensure the correct implementation and deployment of statistical methods within internal information management systems." ID="ID_740789804" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Whenever necessary, will undertake research and initiate research collaborations to develop novel statistical methods to design and analyze results obtained from complex series of experiments." ID="ID_1616460230" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="The position will be based in Johnston, Iowa. As a member of global teams the statistician will work across many locations. Monitors research progress and meets with participating researchers to identify and resolve problems and impacting project timelines and success." ID="ID_807308496" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Remains current on new technology by participating in professional meetings, career development activities and by encouraging others to bring information into research activities." ID="ID_464714809" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Clearly communicates to other team members and Research leadership the correct interpretation of the results obtained from complex series of experiments." ID="ID_1560491882" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Recruits, hires, orients, organizes, supervises, and evaluates performance of any additional statisticians added to the team in the future." ID="ID_452218772" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Implements and monitors safe working practices." ID="ID_144811832" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Other duties:" FOLDED="true" ID="ID_1321747846" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Accountable for research facilities, equipment and other resources." ID="ID_1891151108" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="May serve on teams appropriate to cross project research initiatives." ID="ID_808875252" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="May contribute to scientific publications, conferences and patent applications." ID="ID_1960968972" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_251954122" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="All applicants should have advanced training and experience in the application of statistical methodology to complex biological problems. PhD degree in statistics with relevance to applications in predictive biology and a minimum of 2-4 years relevant industry related experience. Post-doctoral experience may serve as industry related experience. Alternatively a Master’s degree in statistics with relevance to applications in predictive biology or 6-8 years relevant industry related experience." ID="ID_543897304" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Should be experienced in the use of the major statistical software packages such as R, ASreml or SAS." ID="ID_769910712" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Experienced with:" FOLDED="true" ID="ID_1946144112" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="experimental design" ID="ID_1175008204" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="applications of mixed model methodology" ID="ID_161152466" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="maximum likelihood" ID="ID_1565201064" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="predictive modeling" ID="ID_476708021" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="and Bayesian methods to large multi-dimensional data sets." ID="ID_1276121234" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Required to have excellent written and spoken communication skills that are necessary for effective local teamwork and participation in and engagement with the international scientific community." ID="ID_1120180556" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="A good understanding of crop physiology, plant genetics and plant breeding is desired." ID="ID_422585968" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Expected to travel and work at multiple locations." ID="ID_33055899" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Independent programming skills will be a major advantage." ID="ID_745826625" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
<node TEXT="® Data Analyst - (1702656)" FOLDED="true" ID="ID_1761344712" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" ID="ID_1107596339" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="About Syngenta" ID="ID_1883195190" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="As global demand for food and fuel continues to rise, we are dedicated to our purpose: Bringing plant potential to life. Syngenta is one of the world’s leading companies with more than 28,000 employees in over 90 countries. We work in a collaborative and inspiring culture where personal contribution is rewarded and growth and development are at the heart of our culture." ID="ID_761449593" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Through our world-class science, global reach and commitment to working with our customers, we help to increase crop productivity, protect the environment and improve health and quality of life." ID="ID_997935351" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="There’s never been a more important time to join Syngenta." ID="ID_1948110299" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="For more information about us please visit www.syngenta.com" ID="ID_1549500946" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Data Analyst will:" FOLDED="true" ID="ID_1143330778" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="• Work as part of the Digital Data and Insight team enabling the integration of data sources with next generation technologies across functional boundaries." ID="ID_198193784" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Review legacy data platforms and data sets to innovate and integrate across the business to collaborate and partner with key stakeholders to deliver the next generation data platform for Syngenta." ID="ID_37426799" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Work with analysts, project teams and others within Syngenta, translating data-driven insights into actions and decisions" ID="ID_1880900142" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Identify and establish analytics tool guidelines and standards, driving best in class solutions for data preparation, analysis, visualization, and reporting." ID="ID_1486100846" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Set clear and inspiring visions, bringing to life the business and architectural context showing how the analytics tools fit within the overall infrastructure and high-performance data architecture." ID="ID_1013513558" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Drive, organize and deliver the data integration support for a corporate computing capability." ID="ID_495243069" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Promote a corporate entrepreneur mindset within the Digital Digital Data and Insight Lab that will positively influence the successful delivery of fast paced digital Digital Data and Insight solutions, ideas &amp; opportunities." ID="ID_1647617522" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Ensure experiments and sprints are delivered within compliant Syngenta&apos;s project standards, security standards." ID="ID_1970029069" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" ID="ID_17556312" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Knowledge, experience &amp; capabilities" ID="ID_800174738" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Experience and skills:" FOLDED="true" ID="ID_978377308" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="• Expert knowledge of applied data analytics and informatics." ID="ID_61177767" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Experience with large scale data integration and analysis." ID="ID_962855295" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Experience in Big Data tools, analysis, methods and integration." ID="ID_910344213" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Knowledge of informatics, analytics, computational science, service management, delivery." ID="ID_1860868435" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Knowledge of toolsets and capabilities utilized by expert data scientists and modelers." ID="ID_1996419632" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• NoSQL and RDBMS databases." ID="ID_14179244" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Hadoop-based tools (Hive, Hbase, MapReduce, MongoDB, Cassandra)." ID="ID_61560000" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Data modeling and ELT / ETL." ID="ID_257817368" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Data analytics and visualization." ID="ID_1579238696" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="• Working with cross-functional / organizational / geography people and teams." ID="ID_1946433630" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
</node>
<node TEXT="Prediction Theory" FOLDED="true" ID="ID_171771996" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Research Scientist, Statistician, Prediction Theory and Ag Systems  (Job Number:  015967W-01)" FOLDED="true" ID="ID_1222150268" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" FOLDED="true" ID="ID_1184672986" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="DuPont has a rich history of scientific discovery that has enabled countless innovations in industry and life science. Today, more than ever before we need to collaborate across disciplines to make life the best that it can be. The Prediction Theory and Ag Systems Modeling team focuses on developing mathematical models of plants and agricultural systems to enable prediction methodologies for digital solutions. We are looking for individuals with a desire to help farmers, familiarity with nonlinear dynamical systems and an aptitude for analytics, machine learning and data science." ID="ID_1988892614" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Job Duties/Responsibilities:" FOLDED="true" ID="ID_1796880026" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="The scientist will create novel algorithms to simulate growth and development for multiple crops and cropping systems, along with methodologies to train these models to maximize predictability of performance. Modeling and training frameworks include dynamic and Bayesian methods, and combination of mechanistic and data driven algorithms. The scientist participates in interdisciplinary teams of plant scientists, mathematicians, data scientists and software engineers to ensure successful development of high performing prediction methodologies that harness biological knowledge, genetics, environment and management." ID="ID_526551897" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Work in conjunction with Research Scientists to establish project portfolio with goals aligned with research strategy." ID="ID_1231863400" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Lead the development of next generation of plant growth models through the integration of statistical learning methods with mechanistic models." ID="ID_104431040" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Conduct basic research to enable the design of novel cropping systems that harness biological knowledge, genetics, environment and management." ID="ID_1886363619" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_73686119" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="PhD in mathematics, physics, statistics, computer science or related disciplines." ID="ID_260135169" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Competencies &amp; Experience Desired:" FOLDED="true" ID="ID_83657402" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Demonstrated ability to work with nonlinear dynamic systems, including model development in Bayesian framework, uncertainty quantification and predictability assessment and improvement." ID="ID_1501796457" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Expertise in mathematical modeling, numerical analysis, statistical methodology, machine learning and demonstrated experience using these techniques to solve research problems." ID="ID_1361171508" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Proficiency in both scripting and programming languages such as R, Python, C and etc." ID="ID_1410257223" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Outstanding written and oral communication and interpersonal skills." ID="ID_1254373961" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
</node>
<node TEXT="Modeling" FOLDED="true" ID="ID_791539518" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="® Senior Research Associate, Crop Modeling Associate (Job Number: RES00003941)" FOLDED="true" ID="ID_1592368353" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" FOLDED="true" ID="ID_635479634" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="The crop systems modeling associate will provide technical support to scientists developing crop models and applications that create value and improve business processes. The associate will adapt existing algorithms to extend crop model functionality to simulate multiple crops and physiological processes, implement methodologies to train and evaluate crop models within a Bayesian framework, and implement capabilities to simulate cropping systems. The crop modeling associate participates of interdisciplinary teams to ensure successful development of crop models through training and iterative model building, and development of applications that facilitate crop model development and deployment. The associate interacts with Data and software engineers to assure quality implementation of algorithms in crop model production systems." ID="ID_1824229026" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Works in conjunction with Senior Scientist to establish project portfolio with goals aligned with research strategy for North America and protocols and deliverables well defined." ID="ID_1901818051" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Provide technical support and training on crop growth models and prediction algorithms" ID="ID_1468997601" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Collaborate with research scientists to develop algorithms to improve crop model functionality, and extend algorithms to simulate new crops." ID="ID_1649827811" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Develop or adapt modeling approaches to enable simulation of cropping systems." ID="ID_804896033" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Implement methods to train and evaluate crop models within Bayesian framework." ID="ID_1941676372" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_1197170092" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="PhD or Masters with 2+ years of experience in mathematics, physics, engineering, statistics or related discipline" ID="ID_257951230" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Working knowledge in Python and R." ID="ID_59950323" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability to develop methods within Bayesian framework." ID="ID_1640491251" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Strong analytical skills." ID="ID_244566485" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Familiarity with UNIX, C++, and crop growth models such as APSIM, STICS and DSSAT is a plus." ID="ID_229254974" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Able to work with georeferenced and complex data including large images." ID="ID_1484810430" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Outstanding written and oral communication and interpersonal skills" ID="ID_391118972" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
<node TEXT="® Research Scientist, Crop Systems Modeling (PhD) (Job Number: 016692W-01)" FOLDED="true" ID="ID_1454613879" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" FOLDED="true" ID="ID_1675690536" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="The crop systems modeling scientist will develop approaches to fuse mechanistic models, advance phenomics data and statistical learning algorithms to create value and improve business processes. The scientist will create novel algorithms to simulate growth and development for multiple crops and cropping systems, along with methodologies to train these models to maximize predictability of performance. Modeling and training frameworks include dynamic and Bayesian methods. The scientist participates and leads interdisciplinary teams of plant scientists, data scientists, software engineers and social scientists to ensure successful development of prediction models through training and iterative model building, and development of applications that facilitate model deployment." ID="ID_1688847659" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Works in conjunction with Senior Scientist to establish project portfolio with goals aligned with worldwide research strategy, and protocols and deliverables well defined." ID="ID_1945263729" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Lead the development of algorithms to improve crop models and predictability for various crops as prioritized by the organization. Collaborate with breeding technology teams. Communicate results and implement upgrade in production systems" ID="ID_1411269583" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Develop and implement statistical learning methodology to train and evaluate crop models that harness multiple sources of phenomic and genomic data. Work with information management and phenomic teams to implement systems and upgrades." ID="ID_1474308693" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Provide technical support and training on crop growth models and prediction algorithms" ID="ID_484455166" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_122587397" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Ph.D. in mathematics, plant breeding, statistics or related discipline" ID="ID_1739925282" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Able to travel to different locations worldwide" ID="ID_1572886448" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Knowledge in genomic prediction, crop physiology, plant breeding and genetics" ID="ID_1560692425" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Demonstrated ability to model biophysical systems in Python or R within dynamics or Bayesian frameworks" ID="ID_1907843321" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Outstanding analytical skills." ID="ID_901427990" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Familiarity with crop growth models such as APSIM, STICS and DSSAT is a plus." ID="ID_1773804757" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Outstanding written and oral communication and interpersonal skills" ID="ID_915866118" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
<node TEXT="® Senior Research Associate, Predictive Agriculture (Job Number: RES00003927)" FOLDED="true" ID="ID_1001124504" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" FOLDED="true" ID="ID_483585469" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Establish and develop Prediction Agriculture infrastructure and technical capabilities as a core function of an Incubator Research Station. Accountable for development and correct use of all relevant experimental protocols to generate advanced data sets required to achieve prediction agriculture priorities. Design, execute and manage the daily deployment of operational, labor and equipment resources to obtain complex environmental, phenotypic and sensor data from field and controlled environment experiments. Conduct advanced phenotypic measurements on genotype, environment and management treatments at a series of complex field experiments conducted across multiple locations and years to enable the development and deployment of prediction agriculture methodologies. Work as a core member of a multi-location research team to deploy team resources across locations and times to collect the critical data required to translate complex prediction research goals into actionable experimental plans. Responsible for managing daily use of team resources to ensure critical data collection, data quality control, data management, data analysis and data interpretation support for all experiments." ID="ID_1346574653" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Plan experiments in consultation with the Incubator Team Leader and other relevant team members. Ensures all experimental requirements are clearly defined within experimental protocols. (20%)" ID="ID_795695050" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Conduct experiments using protocols to lead data collection teams comprising of research associates, research assistants and temporary labor. Adapts procedures as required. (30%)" ID="ID_1321743328" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Execute and oversee all processes from experiment creation to harvest. Updating protocols as needed during the season, communicating any protocol changes to all team members and maintaining records of data collection activities. (10%)" ID="ID_1812019387" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Interact with members of the data sciences group to develop methods of data collection specific to experiments conducted for prediction agriculture. (10%)" ID="ID_1027408679" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ensure all required workplace and data collection training is completed by team members. Maintains or improves efficient daily work place operations. (10%)" ID="ID_359041500" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Summarizes experiments, manages and analyzes data and prepares reports. (10%)" ID="ID_1463461870" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Supervises and coordinates resources deployment for experiments with other locations. (10%)" ID="ID_1071327523" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Other duties:" FOLDED="true" ID="ID_1903530509" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="May recruit, hire, orient, supervise and evaluate employee performance." ID="ID_1536116741" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="May organize and supervise work of other employees." ID="ID_247128138" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="May serve on teams appropriate to specific research project." ID="ID_531367174" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="May travel to other locations in N.A. or internationally to support data collection." ID="ID_1975198601" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_390883991" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Master&apos;s degree in an agriculture or scientific related field plus a minimum of 2 to 4 years of industry relevant research experience is required" ID="ID_1935497213" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Familiarity with computers, experimental design principles and statistical analysis" ID="ID_673194263" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Demonstrated excellent communication and interpersonal skills" ID="ID_607424279" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability to operate and troubleshoot electronic devices such as those used for agriculture data collection (for instance proximal and remote sensing)" ID="ID_601620912" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="GIS skills desirable" ID="ID_1056897331" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
</node>
<node TEXT="Breeding Program Management" FOLDED="true" ID="ID_947020833" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Entry Level Plant Breeder, Baby Greens" FOLDED="true" ID="ID_844449992" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Vilmorin" ID="ID_1596144625" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Location: Hollister/Gilroy/Salinas area, California, USA" ID="ID_147880709" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="To apply: Send resumes to Careers@vilmorin.com" ID="ID_215605129" CREATED="1519773039798" MODIFIED="1519773039798" LINK="mailto:Careers@vilmorin.com"/>
<node TEXT="1. POSITION DESCRIPTION SUMMARY" FOLDED="true" ID="ID_447024844" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="This position is based in California (USA)." ID="ID_137947134" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="We have facilities in Salinas, Hollister and Gilroy, CA" ID="ID_321422526" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="The incumbent is expected to travel to the areas of baby leaf and greens production mainly in the US (California and south west desert) but also to Europe and others as needed." ID="ID_1756666184" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="2. PURPOSE / OVERALL MISSION" FOLDED="true" ID="ID_1312374162" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="The position will provide the company with new varieties in the target market segments by implementing appropriate genetic resources and methodologies." ID="ID_1697118442" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Overall the goal is to create new varieties of greens with improvement compared to the main varieties currently on the market and to find innovative products/crops to grow market share and turnover, all over the world in accordance with business strategy," ID="ID_681449372" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="4. ESSENTIAL DUTIES AND ACTIVITIES" FOLDED="true" ID="ID_960211998" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="ESSENTIAL DUTIES" FOLDED="true" ID="ID_1516990738" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Plant Breeding Program" FOLDED="true" ID="ID_1121103537" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Active role for the definition of the breeding objectives, in cooperation with the marketing teams (in the US and in Europe)." ID="ID_972921380" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Work closely with the sales and product development teams as well as industry leaders." ID="ID_33814758" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Use appropriate methods and techniques to create competitive new varieties" ID="ID_1317843126" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Use appropriate methods, techniques and germplasm to create high level breeding populations for mid and long term." ID="ID_594052318" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Look for mid-term (5 to 10 years) and long term (10 to 20 years) innovative objectives. Some of these innovative objectives may be outside the current scope." ID="ID_339541791" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Initiate technical and scientific projects useful for the above-mentioned goals. Use internal or external cooperation when necessary." ID="ID_1802459909" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Implement all necessary steps for the development, seed increase, and homogeneity control and file IP application for varieties reaching the commercial stage." ID="ID_1280258022" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ensures the provision of uniform and stable breeders&apos; and stock seed." ID="ID_1772169549" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Supervisory and Managerial Responsibilities." FOLDED="true" ID="ID_1010790908" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Manage the collaborators (performance appraisal, training proposal, day to day work supervision) if any" ID="ID_452414767" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Maximizes the use of all resources allocated to the breeding program such as human, technical and budget parameters." ID="ID_814800139" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Follow all safety, legal and other ethical rules within the company." ID="ID_537793571" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
</node>
</node>
<node TEXT="7. COMPETENCIES TO SUCCESSFULLY PERFORM THE JOB" FOLDED="true" ID="ID_1748644382" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="REQUIRED COMPETENCIES" FOLDED="true" ID="ID_630112601" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Technical skills both in analyzing experimental data, genetics etc. and Microsoft products along with breeding system" ID="ID_538816668" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Team player with a positive attitude and the ability to facilitate work amongst colleagues and staff. Must be able to keep accurate and timely records." ID="ID_929140315" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability to communicate well in written and spoken." FOLDED="true" ID="ID_294802783" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="PROFESSIONAL CAPABILITIES" ID="ID_560706256" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Rigorous, innovative, dedicated to long term actions" ID="ID_1957918650" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Sound judgement with accuracy" ID="ID_1455598906" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Strategic planning and analysis required to properly manage multiple projects" ID="ID_1278567005" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="INTERPERSONNAL SKILLS" FOLDED="true" ID="ID_675312798" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Autonomous, persevering, open to information, communication" ID="ID_1073366303" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Relationship skills" ID="ID_1920350949" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Persuasive, sharing of knowledge and technology" ID="ID_444098133" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="EDUCATIONAL REQUIREMENTS:" FOLDED="true" ID="ID_92540398" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="M.Sc. Plant Breeding and Genetics" ID="ID_1789402796" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="CERTIFICATES, LICENSES, REGISTRATIONS:" FOLDED="true" ID="ID_120752734" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Must have valid driver’s license." ID="ID_1551652588" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
<node TEXT="To apply: Send resumes to Careers@vilmorin.com" ID="ID_285694822" CREATED="1519773039798" MODIFIED="1519773039798" LINK="mailto:Careers@vilmorin.com"/>
<node TEXT="More positions from: Vilmorin North America" ID="ID_1739453661" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Posted from July 25, 2017 until January 25, 2018" ID="ID_1876058889" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="SeedQuest reference number: 90074" ID="ID_251721418" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Corn Breeder - (1700377)" FOLDED="true" ID="ID_1354550976" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Description" ID="ID_947265024" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="About Syngenta" FOLDED="true" ID="ID_1536344160" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="As global demand for food and fuel continues to rise, we are dedicated to our purpose: Bringing plant potential to life. Syngenta is one of the world’s leading companies with more than 28,000 employees in over 90 countries. We work in a collaborative and inspiring culture where personal contribution is rewarded and growth and development are at the heart of our culture." ID="ID_430225086" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="About This Job" FOLDED="true" ID="ID_1149178082" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="The purpose of the role is to improve the performance of Syngenta’s corn germplasm by developing competitive inbreds for the desired target market that produce superior performing hybrids while meeting production standards and work together with the other regional Breeding Project Leads (Inbreds) within the Project Team to share results and produce new and innovative pipelines for commercial sales." ID="ID_769558428" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Accountabilities" FOLDED="true" ID="ID_1484386120" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Manage corn breeding program from Stage 0 through 4:" ID="ID_1063971113" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Plan breeding crosses and tester selection." ID="ID_1873381044" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Allocate allotted nursery, topcross and replicated yield trial resources on mainland and contra season locations." ID="ID_641578187" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Make selection and advancement decisions through Stage 4." ID="ID_1869020597" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Work towards maximum efficiency of germplasm improvement (genetic gain and cost)." ID="ID_1359914139" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ensure appropriate technology integration in germplasm improvement projects and product development processes." ID="ID_628411377" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Plan, evaluate and implement marker-assisted breeding (MAB), double haploid (DH) and other breeding tools and technologies as appropriate." ID="ID_1899118012" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Maintain a thorough understanding of available germplasm and product performance/needs within the target maturity/markets." ID="ID_1701289040" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Participate in NAFTA plot tours and advancement meetings as needed/required." ID="ID_1303334078" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Attend international plot tours and advancement meetings as appropriate." ID="ID_257599640" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Facilitate exchange of germplasm and information within Syngenta’s global corn network." ID="ID_1669201211" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Assist Breeding Project Leads (Hybrids), Product Evaluation Leads and Product Managers with decisions on conversions and product advancement and placement." ID="ID_1190857204" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Work with Trialing Managers to provide feedback that allows for continuous improvement in plot quality and testing efficiency." ID="ID_251298363" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_92472932" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Essential Knowledge &amp; Experience" FOLDED="true" ID="ID_1169157859" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Demonstrated commercial breeding success." ID="ID_1226997054" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability and experience to work in a team setting." ID="ID_778927079" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Excellent organization, communication and computer skills." ID="ID_1255875996" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Excellent interpersonal skills, especially those required to successfully function as part of a cross-functional team." ID="ID_1904438171" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Ability to understand and communicate complex instructions." ID="ID_112377737" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_175142360" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="A Master&apos;s degree is required with 5 years of hands-on work experience" ID="ID_510182978" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="A PhD is preferred, newly graduated PhD&apos;s are encouraged to apply" ID="ID_225139429" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="A thorough knowledge of breeding theory (genetics, statistics, genetic gain theory and field plot technique)." ID="ID_1387861819" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="A thorough knowledge of corn germplasm." ID="ID_217207666" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Good knowledge of marker applications to breeding." ID="ID_557235516" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
<node TEXT="Additional Information" FOLDED="true" ID="ID_1243996679" CREATED="1519773039798" MODIFIED="1519773039798">
<node TEXT="Travel - 20%" ID="ID_421953170" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Applicants must be able to work in the US without visa sponsorship" ID="ID_1070394301" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Extensive travel by car and occasional air travel (e.g., winter nursery, meetings)." ID="ID_730785883" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Periods of intense work at critical times of the year (e.g., planting, pollinating, harvesting)." ID="ID_981486297" CREATED="1519773039798" MODIFIED="1519773039798"/>
<node TEXT="Must have the ability to complete work outdoors– extensive work under various weathe" ID="ID_1632366883" CREATED="1519773039798" MODIFIED="1519773039798"/>
</node>
</node>
</node>
</node>
<node TEXT="Trial Management" FOLDED="true" ID="ID_1744172982" CREATED="1520981840682" MODIFIED="1520981845356">
<node TEXT="Agronomic Research Manager" FOLDED="true" ID="ID_99643921" CREATED="1520982189948" MODIFIED="1520982189948">
<node TEXT="-" ID="ID_608532297" CREATED="1520982189948" MODIFIED="1520982189948"/>
<node TEXT="01OYX" ID="ID_1929207204" CREATED="1520982189969" MODIFIED="1520982189969"/>
<node TEXT="Description" FOLDED="true" ID="ID_1896323500" CREATED="1520982189971" MODIFIED="1520982189971">
<node TEXT="Twenty years from now, the earth’s population will need 55% more food than it can produce now. Today, Monsanto is working with farmers around the world to do something about it. In over 60 countries, Monsanto has established industry-leading products because we give professionals the freedom to make real decisions. Monsanto is an Employer Of Choice with an outstanding professional development program and a history of building careers. Make an impact by joining the team that is working to solve one of mankind’s greatest challenges." ID="ID_1247291287" CREATED="1520982189974" MODIFIED="1520982189974"/>
<node TEXT="Monsanto is seeking a highly motivated Agronomic Research Manager with the ability to assume a key role within the North America Field Testing Organization. The role will aid in the testing and evaluation of new biotechnology traits, chemistry, pathology, seed treatment and agronomic system improvement for our products within Technology. This position travel to various North America Field Testing locations but preferably will be based in Wichita, KS. This is a unique opportunity to work with leading edge technology and build relationships and networks with talented cross functional teams such as Breeding, Biotechnology, Technology Development &amp; Agronomy, Commercial and Discovery Traits and Chemistry." ID="ID_1269357094" CREATED="1520982189975" MODIFIED="1520982189975"/>
</node>
<node TEXT="Responsibilities:" FOLDED="true" ID="ID_1508644341" CREATED="1520982189999" MODIFIED="1520982189999">
<node TEXT="Leading and managing the execution of multiple complex field research trial programs related to delivery of Discovery to Phase II projects within Technology" ID="ID_1802440657" CREATED="1520982190003" MODIFIED="1520982190003"/>
<node TEXT="Manage testing and evaluation of new biotechnology traits and other new products at specific NAFTO locations and projects related to or supporting our discovery breeding activities" ID="ID_1125233700" CREATED="1520982190004" MODIFIED="1520982190004"/>
<node TEXT="Develop strong, sustainable relationships with key Technology personnel, St. Louis Product Assessment Scientists, Breeders and other key influencers" ID="ID_1562408137" CREATED="1520982190008" MODIFIED="1520982190008"/>
<node TEXT="Develop and maintain relationships with Technology Development to help gain efficiencies in practice" ID="ID_1519048698" CREATED="1520982190012" MODIFIED="1520982190012"/>
<node TEXT="Work independently to administer and provide maintenance of testing locations and operating research planting and harvesting equipment" ID="ID_1111926617" CREATED="1520982190016" MODIFIED="1520982190016"/>
<node TEXT="Preparation for/and planting, field plot maintenance, data collection and harvesting" ID="ID_1770969073" CREATED="1520982190017" MODIFIED="1520982190017"/>
<node TEXT="Participate in task-related document creation and process review for job-related activities" ID="ID_1910768826" CREATED="1520982190021" MODIFIED="1520982190021"/>
<node TEXT="Ensure that company assets are well-cared for and properly maintained" ID="ID_226565436" CREATED="1520982190022" MODIFIED="1520982190022"/>
<node TEXT="Establish long-term relationships with cooperators to locate and rent appropriate yield trial land on an annual basis" ID="ID_1732197232" CREATED="1520982190023" MODIFIED="1520982190023"/>
<node TEXT="Maintain Monsanto’s Freedom to Operate by adhering to all Federal and State Regulatory Compliance requirements" ID="ID_1141741608" CREATED="1520982190024" MODIFIED="1520982190024"/>
<node TEXT="Administer and execute Regulatory Science projects to ensure compliance" ID="ID_1277686648" CREATED="1520982190027" MODIFIED="1520982190027"/>
<node TEXT="Responsible for specific aspects of the home site’s safety program and workload" ID="ID_1515612921" CREATED="1520982190031" MODIFIED="1520982190031"/>
<node TEXT="Responsible for recruiting and sourcing part time in season labor to help ensure program success" ID="ID_477083557" CREATED="1520982190032" MODIFIED="1520982190032"/>
<node TEXT="Familiarity with emerging technology in the realm of agronomic systems and equipment technology" ID="ID_977384973" CREATED="1520982190033" MODIFIED="1520982190033"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_328019349" CREATED="1520982190034" MODIFIED="1520982190034">
<node TEXT="Required Education and Skills/Experience:" FOLDED="true" ID="ID_828090585" CREATED="1520982190036" MODIFIED="1520982190036">
<node TEXT="Minimum of a Master’s Degree or equivalent experience in Agronomy, Weed Science, Entomology, Soil Science, Plant Pathology or a closely related field" ID="ID_1920061964" CREATED="1520982190037" MODIFIED="1520982190037"/>
<node TEXT="At least 5 years of related experience" ID="ID_557582846" CREATED="1520982190038" MODIFIED="1520982190038"/>
<node TEXT="Ability to coordinate a team of Agronomic Research Specialist conducting independent trial work" ID="ID_157937096" CREATED="1520982190042" MODIFIED="1520982190042"/>
<node TEXT="Training and experience in experimental design, field test plot management, statistics and data interpretation" ID="ID_1740942163" CREATED="1520982190044" MODIFIED="1520982190044"/>
<node TEXT="Possess (or ability to obtain) State Certified Pesticide Applicators" ID="ID_1993810777" CREATED="1520982190046" MODIFIED="1520982190046"/>
<node TEXT="Strong oral and written presentation skills" ID="ID_462751540" CREATED="1520982190047" MODIFIED="1520982190047"/>
<node TEXT="Strong computer skills, especially in scientific software" ID="ID_646146033" CREATED="1520982190048" MODIFIED="1520982190048"/>
<node TEXT="Demonstrated self-discipline and ability to function effectively without direct supervision" ID="ID_805162059" CREATED="1520982190049" MODIFIED="1520982190049"/>
<node TEXT="Ability to work effectively with other NAFTO personnel, research and marketing personnel" ID="ID_773793159" CREATED="1520982190050" MODIFIED="1520982190050"/>
<node TEXT="Ability to provide technical leadership to product and project teams" ID="ID_1103026404" CREATED="1520982190051" MODIFIED="1520982190051"/>
<node TEXT="Excellent time management skills required" ID="ID_578679418" CREATED="1520982190052" MODIFIED="1520982190052"/>
<node TEXT="Ability to travel up to 50% of time" ID="ID_153975601" CREATED="1520982190053" MODIFIED="1520982190053"/>
<node TEXT="May be required to push, lift or pull up to 60 lbs" ID="ID_1819193673" CREATED="1520982190054" MODIFIED="1520982190054"/>
<node TEXT="May be required to work in strained or cramped positions" ID="ID_1216727859" CREATED="1520982190056" MODIFIED="1520982190056"/>
</node>
<node TEXT="Desired Education and Skills/Experience:" FOLDED="true" ID="ID_1478261518" CREATED="1520982190057" MODIFIED="1520982190057">
<node TEXT="PhD in Agronomy, Weed Science, Entomology, Soil Science, Plant Pathology or a closely related field" ID="ID_611358699" CREATED="1520982190058" MODIFIED="1520982190058"/>
<node TEXT="Possess (or ability to obtain) Certified Crop Advisor (CCA) status" ID="ID_1967495166" CREATED="1520982190059" MODIFIED="1520982190059"/>
<node TEXT="Experience with operating agricultural equipment preferred." ID="ID_191584105" CREATED="1520982190060" MODIFIED="1520982190060"/>
<node TEXT="Possess (or ability to obtain) class A CDL driver&apos;s license" ID="ID_1736074430" CREATED="1520982190061" MODIFIED="1520982190061"/>
</node>
</node>
</node>
</node>
<node TEXT="Bioinformatics" FOLDED="true" ID="ID_1073581243" CREATED="1519848474598" MODIFIED="1519848488874">
<node TEXT="Bioinformatics Scientist (PhD)  (Job Number:  RES00004155)" FOLDED="true" ID="ID_440824326" CREATED="1519848502461" MODIFIED="1519848502461">
<node TEXT="Description" FOLDED="true" ID="ID_358194038" CREATED="1519848502461" MODIFIED="1519848502461">
<node TEXT="DuPont Industrial Biosciences is seeking a Bioinformatics Scientist to work on biotechnology projects using fungal hosts. Industrial Biosciences is an industry leader in providing biobased solutions to meet the needs of a growing population while protecting our environment. We create enzymes and other biobased inventions used by manufacturers to increase the productivity and environmental benefits of nearly 400 consumer and commercial products, such as foods, beverages, animal nutrition, textiles, household cleaning and fuel for vehicles.   We have major US research locations in Wilmington, Delaware and Palo Alto, California, and the location of this position is flexible with respect to existing research sites." ID="ID_1346929216" CREATED="1519848502462" MODIFIED="1519848502462"/>
<node TEXT="The successful candidate will be part of multidisciplinary teams within a larger community of computational biologists, molecular biologists, microbiologists, biochemists and biochemical engineers. The successful applicant will be part of project teams working on fungal expression hosts, gene discovery, protein engineering and protein expression.  These projects will likely include genome assembly and analysis, transcriptomics, metabolomics, metabolic modeling and data mining of existing large datasets.  Candidates should be self-motivated, thrive in a research team environment, and be eager to take on new challenges presented by diverse projects." ID="ID_297626743" CREATED="1519848502463" MODIFIED="1519848502463"/>
<node TEXT="This position is open to candidates with a Ph.D. and a minimum of two years of postdoctoral training in Computational Biology, Bioinformatics, Computer Science or related field.  Preference will be given to candidates with a broad knowledge base who have demonstrated experience with fungal or yeast biology, experience with NGS data and familiarity with machine learning approaches." ID="ID_433993999" CREATED="1519848502468" MODIFIED="1519848502468"/>
</node>
<node TEXT="Qualifications" FOLDED="true" ID="ID_1605825045" CREATED="1519848502473" MODIFIED="1519848502473">
<node TEXT="·    Ph.D. and a minimum of two years of postdoctoral training in Bioinformatics or related fields or equivalent experience." ID="ID_123077106" CREATED="1519848502477" MODIFIED="1519848502477"/>
<node TEXT="·    Experience working with NGS data for genomic and transcriptomic analyses." ID="ID_1581667935" CREATED="1519848502478" MODIFIED="1519848502478"/>
<node TEXT="·    Strong linux skills and programming ability in at least one of the following: Python, C/C++, Java, R or Perl." ID="ID_1922251217" CREATED="1519848502482" MODIFIED="1519848502482"/>
<node TEXT="·    Productivity demonstrated through a track record of publications and /or patents." ID="ID_1778018251" CREATED="1519848502484" MODIFIED="1519848502484"/>
<node TEXT="·    Effective written and oral communication of scientific results." ID="ID_46570090" CREATED="1519848502485" MODIFIED="1519848502485"/>
</node>
</node>
</node>
<node TEXT="Find positions at multiple settings incl govt" ID="ID_1857981232" CREATED="1519848555040" MODIFIED="1519848608576">
<icon BUILTIN="unchecked"/>
</node>
</node>
<node ID="ID_254092290" CREATED="1592327734758" MODIFIED="1592327734758" LINK="https://www.payscale.com/research/US/Job=Plant_Breeder/Salary"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.payscale.com/research/US/Job=Plant_Breeder/Salary">Plant Breeder Salary | PayScale</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Corporate" FOLDED="true" ID="ID_1924214816" CREATED="1547049966710" MODIFIED="1547049971927">
<node TEXT="Individual Contributor" FOLDED="true" ID="ID_543272968" CREATED="1547049972934" MODIFIED="1547049980088">
<node TEXT="Current Role" ID="ID_679276800" CREATED="1549406550474" MODIFIED="1549406554317"/>
</node>
<node TEXT="Manager" FOLDED="true" ID="ID_554734224" CREATED="1548189243719" MODIFIED="1548189246459">
<node TEXT="First Line Manager" ID="ID_896469687" CREATED="1547049981085" MODIFIED="1547049986928"/>
<node TEXT="Manager of Managers" ID="ID_1457687695" CREATED="1547049988804" MODIFIED="1547050097636"/>
<node TEXT="Executive" ID="ID_903426088" CREATED="1547050103526" MODIFIED="1547050106570"/>
</node>
<node TEXT="Fellow" FOLDED="true" ID="ID_283588105" CREATED="1575301576815" MODIFIED="1575301586630">
<node TEXT="Our Syngenta Fellows are role models in science, technology and engineering. Through their scientific leadership and technical delivery, they continually demonstrate a track record in sustained technical achievement and innovation. Their achievements and expertise enable us to develop the new capabilities needed by the organization.&#xa;&#xa;Fellows are important ambassadors for Syngenta. Externally, they play an active role in strengthening effective information exchange and maintaining our visibility in the international scientific community. Internally, they support career development and mentor our scientists, technologists and engineers – this is critical to developing Syngenta’s future pipeline. Fellows are nominated by their line managers and endorsed by a Fellow panel." ID="ID_1820317418" CREATED="1575301591047" MODIFIED="1575301596031"/>
</node>
</node>
<node TEXT="Trying out roles" FOLDED="true" ID="ID_1605243968" CREATED="1561584880324" MODIFIED="1561584890350">
<node TEXT="gaining exposure to roles that i would be interested in filling" ID="ID_1799742630" CREATED="1561584898317" MODIFIED="1561584923696"/>
<node ID="ID_1549293344" CREATED="1561704714680" MODIFIED="1561704714680" LINK="https://www.themuse.com/advice/how-to-get-experience-in-a-new-field-without-starting-at-the-bottom"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.themuse.com/advice/how-to-get-experience-in-a-new-field-without-starting-at-the-bottom">How to Get Experience in A New Field - The Muse</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1185708871" CREATED="1561704779588" MODIFIED="1561704779588" LINK="https://www.rasmussen.edu/degrees/technology/blog/how-to-break-the-experience-barrier-in-it-jobs/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.rasmussen.edu/degrees/technology/blog/how-to-break-the-experience-barrier-in-it-jobs/">6 Ways to Gain the IT Experience Employers Are Looking For | Rasmussen College</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1440261472" CREATED="1561705459749" MODIFIED="1561705459749" LINK="http://www.learnanalytics.in/blog/?p=26"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.learnanalytics.in/blog/?p=26">How to enter the Analytics Industry? | Analytics Training</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Role Areas" FOLDED="true" ID="ID_1443351764" CREATED="1547049958405" MODIFIED="1620599564787">
<node TEXT="trait development" ID="ID_1224815047" CREATED="1619908341125" MODIFIED="1619908351361"/>
<node TEXT="Breeding" ID="ID_1204767714" CREATED="1619908352104" MODIFIED="1619908354709"/>
<node TEXT="Phenotyping" ID="ID_243520441" CREATED="1619908355098" MODIFIED="1619908357410"/>
<node TEXT="Technology" ID="ID_107750646" CREATED="1619908357774" MODIFIED="1619908360494"/>
<node TEXT="field production technology" FOLDED="true" ID="ID_175699269" CREATED="1619905964405" MODIFIED="1619905976205">
<node ID="ID_570173490" CREATED="1619905977592" MODIFIED="1619905977592" LINK="https://www.instructables.com/SEEDS-SOWING-ROBOT/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.instructables.com/SEEDS-SOWING-ROBOT/">SEEDS SOWING ROBOT : 11 Steps - Instructables</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="developing phenotyping tools" ID="ID_253790745" CREATED="1619741943988" MODIFIED="1619741964061"/>
<node TEXT="Ideal" FOLDED="true" ID="ID_466269160" CREATED="1619583193488" MODIFIED="1619583196707">
<node TEXT="take everything, give nothing" ID="ID_12936454" CREATED="1619583514730" MODIFIED="1619583525472"/>
<node TEXT="Freedom to do anything" ID="ID_329344934" CREATED="1619583656507" MODIFIED="1619583660691"/>
<node TEXT="No responsibilities to anyone" ID="ID_1130075178" CREATED="1619583671948" MODIFIED="1619583676693"/>
<node TEXT="no effort" FOLDED="true" ID="ID_525568799" CREATED="1619583199086" MODIFIED="1619583208453">
<node TEXT="taking is easier than giving" ID="ID_1548052776" CREATED="1619583430670" MODIFIED="1619583443301"/>
</node>
<node TEXT="Pays a lot" ID="ID_360814694" CREATED="1619583209912" MODIFIED="1619583214809"/>
<node TEXT="Ideally people would give me money for existing" ID="ID_862785027" CREATED="1619583284265" MODIFIED="1619583302693"/>
</node>
<node TEXT="Past" FOLDED="true" ID="ID_1164247316" CREATED="1590038624388" MODIFIED="1590038627212">
<node TEXT="Research Associate - MSE" ID="ID_1884278372" CREATED="1590038630571" MODIFIED="1590038651215"/>
<node TEXT="Accomplishments" FOLDED="true" ID="ID_716002297" CREATED="1590038653080" MODIFIED="1590038666106">
<node TEXT="" ID="ID_1610958581" CREATED="1590038862844" MODIFIED="1590038862844"/>
<node TEXT="Streamlined trialing protocols to improve data quality and reduce costs" ID="ID_796501492" CREATED="1590038809256" MODIFIED="1590038852977"/>
</node>
<node TEXT="" ID="ID_405765835" CREATED="1590038666759" MODIFIED="1590038666759"/>
</node>
</node>
</node>
</node>
<node TEXT="Credential" FOLDED="true" ID="ID_1970295706" CREATED="1651117124686" MODIFIED="1651117128162">
<node TEXT="CBEST" FOLDED="true" ID="ID_942741005" CREATED="1651117218741" MODIFIED="1651117222041">
<node TEXT="Resources" FOLDED="true" ID="ID_1271318286" CREATED="1651117227213" MODIFIED="1651117480754">
<node ID="ID_598739617" CREATED="1651117481774" MODIFIED="1651117481774" LINK="http://www.ctcexams.nesinc.com/TestView.aspx?f=HTML_FRAG/CA_CBEST_PrepMaterials.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.ctcexams.nesinc.com/TestView.aspx?f=HTML_FRAG/CA_CBEST_PrepMaterials.html">CBEST Preparation Materials</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="CSET" ID="ID_1927011835" CREATED="1651117222462" MODIFIED="1651117224484"/>
<node TEXT="program" FOLDED="true" ID="ID_186934500" CREATED="1651117131023" MODIFIED="1651117139738">
<node TEXT="criteria" FOLDED="true" ID="ID_694419322" CREATED="1653942345363" MODIFIED="1653942351909">
<node TEXT="enrollment period" ID="ID_499221190" CREATED="1653942353442" MODIFIED="1653942376238"/>
<node TEXT="program length" ID="ID_536235544" CREATED="1653942689859" MODIFIED="1653942692450"/>
<node TEXT="Cost" ID="ID_580695250" CREATED="1653942377555" MODIFIED="1653942379461"/>
<node TEXT="Masters" ID="ID_1340419668" CREATED="1653942379859" MODIFIED="1653942382150"/>
</node>
<node TEXT="search" FOLDED="true" ID="ID_1382833174" CREATED="1653944163977" MODIFIED="1653944179693">
<node ID="ID_216366561" CREATED="1654231093571" MODIFIED="1654231093571" LINK="https://www.teachcalifornia.org/Partners"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.teachcalifornia.org/Partners">Partners of TEACH California - Recruiting Teachers | TEACH California</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_451473774" CREATED="1653944151786" MODIFIED="1653944151786" LINK="https://www.ctc.ca.gov/commission/reports/data/approved-institutions-and-programs"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ctc.ca.gov/commission/reports/data/approved-institutions-and-programs">Approved Institutions and Programs</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_132295055" CREATED="1654062051325" MODIFIED="1654062051325" LINK="https://infolearners.com/best-online-teaching-credential-programs-california/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://infolearners.com/best-online-teaching-credential-programs-california/">Best Online Teaching Credential Programs California - INFOLEARNERS</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1663931792" CREATED="1653946027617" MODIFIED="1653946027617" LINK="https://www.calstate.edu/attend/degrees-certificates-credentials/Pages/Credential-Programs.aspx#InplviewHashc547a385-25b1-4ce5-8dc5-5a00ec04fbcb=WebPartID%3D%7Bc547a385-25b1%3D-4ce5%3D-8dc5%3D-5a00ec04fbcb%7D%3D-FilterField1%3DCredentialType-FilterValue1%3D2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.calstate.edu/attend/degrees-certificates-credentials/Pages/Credential-Programs.aspx#InplviewHashc547a385-25b1-4ce5-8dc5-5a00ec04fbcb=WebPartID%3D%7Bc547a385-25b1%3D-4ce5%3D-8dc5%3D-5a00ec04fbcb%7D%3D-FilterField1%3DCredentialType-FilterValue1%3D2">Credential Programs | CSU</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="options" FOLDED="true" ID="ID_618397761" CREATED="1651117140758" MODIFIED="1651117142898">
<node ID="ID_1634764836" CREATED="1651117147738" MODIFIED="1651117147738" LINK="https://csumb.edu/teach/secondary-education/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://csumb.edu/teach/secondary-education/">Secondary Education | California State University Monterey Bay</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_422181726" CREATED="1651117389380" MODIFIED="1651117389380" LINK="https://www.nu.edu/ourprograms/schoolofeducation/teachereducation/programs/inspired-teaching-and-learning-preliminary-single-subject/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.nu.edu/ourprograms/schoolofeducation/teachereducation/programs/inspired-teaching-and-learning-preliminary-single-subject/">Single Subject Credential for California Teachers - NU.edu</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_824063988" CREATED="1651117389393" MODIFIED="1651117389393" LINK="https://ce.csueastbay.edu/ce/programs/single-subject-teaching-credential/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://ce.csueastbay.edu/ce/programs/single-subject-teaching-credential/">Online Single Subject Teaching Credential | California State University, East Bay</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1152394782" CREATED="1651117389396" MODIFIED="1651117389396"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Lato; font-size: 10.5pt; color: #2A2E32">
      <span style="background-color: white; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null">Deadline:</span><span>&nbsp; </span><span style="background-color: white; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null">4/1</span>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_1509975849" CREATED="1651103773143" MODIFIED="1651103775097">
<node ID="ID_894142019" CREATED="1651103781001" MODIFIED="1651103781001" LINK="https://www.teachcalifornia.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.teachcalifornia.org/">Become a teacher in California | TEACH California</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1383182943" CREATED="1651116595523" MODIFIED="1651116595523" LINK="https://sites.google.com/csumb.edu/csumbcoteaching/teacher-candidates/professional-dispositions?authuser=0"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sites.google.com/csumb.edu/csumbcoteaching/teacher-candidates/professional-dispositions?authuser=0">CSUMB CO-TEACHING - Professional Dispositions</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="HSE Lead" FOLDED="true" ID="ID_1798026891" CREATED="1681532197118" MODIFIED="1681532204202">
<node TEXT="reference" FOLDED="true" ID="ID_428009547" CREATED="1681532839652" MODIFIED="1681532842771">
<node ID="ID_1466312801" CREATED="1681532844418" MODIFIED="1681532844418" LINK="https://en.wikipedia.org/wiki/Environment,_health_and_safety"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://en.wikipedia.org/wiki/Environment,_health_and_safety">Environment, health and safety - Wikipedia</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="OSHA" FOLDED="true" ID="ID_1267798804" CREATED="1682476939291" MODIFIED="1682476942256">
<node TEXT="Training" FOLDED="true" ID="ID_1618738166" CREATED="1682477874939" MODIFIED="1682477878535">
<node TEXT="ref" FOLDED="true" ID="ID_353068780" CREATED="1682477879043" MODIFIED="1682889560392">
<node ID="ID_1826598390" CREATED="1682478032479" MODIFIED="1682478032479" LINK="https://www.osha.gov/training/outreach/training-providers"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osha.gov/training/outreach/training-providers">OSHA-Authorized Online Outreach Training Providers | Occupational Safety and Health Administration</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_808397833" CREATED="1682476943510" MODIFIED="1682476943510" LINK="https://www.osha.gov/sites/default/files/publications/osha2254.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osha.gov/sites/default/files/publications/osha2254.pdf">Training Requirements in OSHA Standards</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_491564865" CREATED="1682477369086" MODIFIED="1682477369086" LINK="https://www.osha.gov/agricultural-operations"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osha.gov/agricultural-operations">Agricultural Operations - Overview | Occupational Safety and Health Administration</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="OSHA 30 General Industry" FOLDED="true" ID="ID_451742480" CREATED="1682477883691" MODIFIED="1682477891000">
<node ID="ID_1242656011" CREATED="1682478256105" MODIFIED="1682478256105" LINK="https://www.360training.com/course/osha-30-hour-outreach-training-general-industry-free-study-guide"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.360training.com/course/osha-30-hour-outreach-training-general-industry-free-study-guide">OSHA 30-Hour General Industry Training Course Online</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="360" OBJECT="java.lang.Long|360" FOLDED="true" ID="ID_264201932" CREATED="1682481917715" MODIFIED="1682481920465">
<node ID="ID_1807224214" CREATED="1682773027521" MODIFIED="1682773027521" LINK="https://www.360training.com/student-login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.360training.com/student-login">Student Log-In | 360training.com</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="m.mcmillen" ID="ID_1693280872" CREATED="1682481921710" MODIFIED="1682481921710"/>
<node TEXT="RyXa6_Xh:cw_4WS" ID="ID_542736470" CREATED="1682481929148" MODIFIED="1682482232336"/>
<node TEXT="Qs" FOLDED="true" ID="ID_1134787283" CREATED="1682482233099" MODIFIED="1682482234001">
<node TEXT="maternal grandmother maiden name" FOLDED="true" ID="ID_48438978" CREATED="1682482234900" MODIFIED="1682482237977">
<node TEXT="Buyser" ID="ID_1497628888" CREATED="1682482238724" MODIFIED="1682482241031"/>
</node>
<node TEXT="Town parents met" FOLDED="true" ID="ID_1624572506" CREATED="1682482244963" MODIFIED="1682482247576">
<node TEXT="Salinas" ID="ID_200249796" CREATED="1682482248532" MODIFIED="1682482250386"/>
</node>
<node TEXT="Town of first job" FOLDED="true" ID="ID_308587733" CREATED="1682482251660" MODIFIED="1682482257761">
<node TEXT="Gilroy" ID="ID_662352429" CREATED="1682482258875" MODIFIED="1682482264880"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="skills" FOLDED="true" ID="ID_1297544057" CREATED="1681533158183" MODIFIED="1681533161808">
<node TEXT="Knowledge" ID="ID_1961315361" CREATED="1681533162603" MODIFIED="1681533169698"/>
<node TEXT="analytical skills" ID="ID_1397543467" CREATED="1681533170354" MODIFIED="1681533174863"/>
<node TEXT="Problem-solving skills" ID="ID_1617318538" CREATED="1681533175231" MODIFIED="1681533178673"/>
<node TEXT="Communication skills" ID="ID_1263473045" CREATED="1681533182049" MODIFIED="1681533185690"/>
<node TEXT="Empathy" ID="ID_1579655597" CREATED="1681533194572" MODIFIED="1681533197295"/>
<node TEXT="Adaptability" ID="ID_405435099" CREATED="1681533218960" MODIFIED="1681533221495"/>
<node TEXT="Integrity" ID="ID_432725773" CREATED="1681533239629" MODIFIED="1681533241922"/>
<node TEXT="Ability to lead" ID="ID_488971438" CREATED="1681533248639" MODIFIED="1681533254451"/>
<node TEXT="Detail oriented" ID="ID_1634058519" CREATED="1681533268582" MODIFIED="1681533271528"/>
<node TEXT="Proactive" ID="ID_1057832338" CREATED="1681533283159" MODIFIED="1681533285786"/>
</node>
</node>
<node TEXT="Contract Work" FOLDED="true" ID="ID_843631656" CREATED="1701299600255" MODIFIED="1701299607273">
<node TEXT="reference" FOLDED="true" ID="ID_1720662749" CREATED="1701299608432" MODIFIED="1701299610078">
<node ID="ID_1033135060" CREATED="1701299759048" MODIFIED="1701299759048" LINK="https://www.freelanzing.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.freelanzing.com/">Freelanzing</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_887190033" CREATED="1701299611349" MODIFIED="1701299611349" LINK="https://www.cbinsights.com/company/crowdflower/alternatives-competitors"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.cbinsights.com/company/crowdflower/alternatives-competitors">Top Figure Eight Alternatives, Competitors</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Home Office Support" ID="ID_509579166" CREATED="1703879930311" MODIFIED="1703879935546"/>
</node>
</node>
<node TEXT="Developing" FOLDED="true" ID="ID_916537917" CREATED="1709772039059" MODIFIED="1709772041617">
<node ID="ID_453358450" CREATED="1709772043159" MODIFIED="1709772052896" LINK="https://myidp.sciencecareers.org/?AspxAutoDetectCookieSupport=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://myidp.sciencecareers.org/?AspxAutoDetectCookieSupport=1">IDP Home Page</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Side Hustles" FOLDED="true" ID="ID_106749912" CREATED="1706207373141" MODIFIED="1706207376410">
<node ID="ID_1043244206" CREATED="1706207377692" MODIFIED="1706207377692" LINK="https://medium.com/@bap_16778/5-achievable-side-hustles-for-developers-946c7cad1ff2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/@bap_16778/5-achievable-side-hustles-for-developers-946c7cad1ff2">🫵 5 achievable side hustles for developers💰 | by Bap | Dec, 2023 | Medium</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="reference" FOLDED="true" POSITION="bottom_or_right" ID="ID_1123508846" CREATED="1539714774136" MODIFIED="1682887946589">
<node TEXT="conscious planning of one’s activities and engagements in the jobs one undertakes in the course of his life" FOLDED="true" ID="ID_1249529805" CREATED="1539714796817" MODIFIED="1539714961032">
<node TEXT="for better" FOLDED="true" ID="ID_63999852" CREATED="1539714961036" MODIFIED="1539714966973">
<node TEXT="fulfilment" ID="ID_512484051" CREATED="1539714966975" MODIFIED="1539714977828"/>
<node TEXT="growth" ID="ID_1173517468" CREATED="1539714977830" MODIFIED="1539714987966"/>
<node TEXT="financial stability." ID="ID_444730973" CREATED="1539714987968" MODIFIED="1539714987969"/>
</node>
<node ID="ID_1851480680" CREATED="1539715065680" MODIFIED="1539715065680" LINK="https://www.managementstudyguide.com/career-management.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.managementstudyguide.com/career-management.htm">Career Management - Meaning and Important Concepts</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="What is a career" FOLDED="true" ID="ID_1420229228" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Course or progress through life" FOLDED="true" ID="ID_435598883" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Learning" ID="ID_691886487" CREATED="1519234503662" MODIFIED="1519234503662"/>
<node TEXT="Occupation" ID="ID_370032753" CREATED="1519234503662" MODIFIED="1519234503662"/>
<node TEXT="Accomplishments" ID="ID_1240996110" CREATED="1519234503662" MODIFIED="1519234503662"/>
</node>
<node TEXT="A challenging opportunity which allows me to fully express my talents and interests" FOLDED="true" ID="ID_50651547" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Challenge" FOLDED="true" ID="ID_1019380923" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="Increasing responsibility" ID="ID_1533137393" CREATED="1519234503662" MODIFIED="1519234503662"/>
</node>
<node TEXT="Talents/Skills" FOLDED="true" ID="ID_725436281" CREATED="1519234503662" MODIFIED="1519234503662">
<node TEXT="What I&apos;m good at" ID="ID_215695638" CREATED="1519234503662" MODIFIED="1519234503662"/>
</node>
<node TEXT="Aligned with self-image" ID="ID_1378779830" CREATED="1519234503662" MODIFIED="1519234503662"/>
</node>
</node>
<node TEXT="IDP - Individual Delevopment Plan" ID="ID_505678450" CREATED="1592407440474" MODIFIED="1696633570779"/>
</node>
<node TEXT="Monica&apos;s Career" FOLDED="true" POSITION="top_or_left" ID="ID_1112089803" CREATED="1519772813609" MODIFIED="1519772848439">
<node TEXT="Goals" FOLDED="true" ID="ID_162075109" CREATED="1589836170624" MODIFIED="1589836173623">
<node TEXT="Get Gate certified" ID="ID_1372780873" CREATED="1589836174686" MODIFIED="1589836184734"/>
<node TEXT="Continue teaching" ID="ID_1844856297" CREATED="1589836187477" MODIFIED="1589836192944"/>
</node>
<node TEXT="Role" FOLDED="true" ID="ID_704483968" CREATED="1703808996637" MODIFIED="1703808998239">
<node TEXT="Elementary School Teacher" FOLDED="true" ID="ID_1558216672" CREATED="1699334007414" MODIFIED="1703809006511">
<node TEXT="Alignment: 100%" ID="ID_127518455" CREATED="1699334064726" MODIFIED="1699334080656"/>
</node>
</node>
<node TEXT="Sick Days" ID="ID_1388692636" CREATED="1713558672981" MODIFIED="1713558792426">
<node TEXT="get paid out day four day when you retire" FOLDED="true" ID="ID_1309994956" CREATED="1713558794599" MODIFIED="1713558820811">
<node TEXT="if you quit or go to another state then you lose them" ID="ID_1561413122" CREATED="1713558821982" MODIFIED="1713558839406"/>
</node>
<node TEXT="can negotiate with new job to get them transferred but it is not a guarantee" ID="ID_1462781924" CREATED="1713558960259" MODIFIED="1713558972016"/>
</node>
<node TEXT="Retirement" ID="ID_486616849" CREATED="1713559017185" MODIFIED="1713559186095" LINK="freeplane:/%20/M:/My%20Drive/My%20Google%20Docs/MindMaps/LifeMgmt.mm#ID_1024046144"/>
<node FOLDED="true" ID="ID_516308279" CREATED="1519772826907" MODIFIED="1519772826907"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Pregnancy Leave
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_339627221" CREATED="1519772826907" MODIFIED="1519772826907"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Contract
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1923436055" CREATED="1519772826922" MODIFIED="1519772826922" LINK="http://www.gusd.k12.ca.us/cms/page_view?d=x&amp;piid=&amp;vpid=1223618690170"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://www.gusd.k12.ca.us/cms/page_view?d=x&amp;piid=&amp;vpid=1223618690170">Gilroy Unified School District: Collective Bargaining Agreements</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1546912202" CREATED="1519772826938" MODIFIED="1519772826938"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      20.7.2 Unit members on part-time service whose daily service is half-time (50%) or more shall accumulate service time as though they were teaching full-time for the purpose of advancement on the salary schedule. Unit members working less than 50 percent (50%) of a normal assignment shall be eligible for prorated increments for the purpose of advancement on the salary schedule.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1759925652" CREATED="1519772826938" MODIFIED="1519772826938"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      23.9.3 One Year Of Service Both for outside experience and for payment of increments within this system, 75% of work days in any one school year shall constitute a year of service.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_173091854" CREATED="1519772826938" MODIFIED="1519772826938" LINK="https://www.dfeh.ca.gov/resources/frequently-asked-questions/employment-faqs/pregnancy-disability-leave-faqs/pdl-cfra-fmla-guide/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.dfeh.ca.gov/resources/frequently-asked-questions/employment-faqs/pregnancy-disability-leave-faqs/pdl-cfra-fmla-guide/">PDL, CFRA, and FMLA Requirements and Obligations &#8211; DFEH</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1017682569" CREATED="1519772826954" MODIFIED="1519772826954"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Standard Insurance for Disability
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1188916949" CREATED="1519772826954" MODIFIED="1519772826954" LINK="https://login.standard.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://login.standard.com/">https://login.standard.com/</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_982451319" CREATED="1519772826969" MODIFIED="1519772826969"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      GUSD Start Date
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1499097782" CREATED="1519772826985" MODIFIED="1519772826985"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      08/11/2015
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_543037465" CREATED="1519772826985" MODIFIED="1519772869995"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Motivations
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1217420539" CREATED="1519772826969" MODIFIED="1519772826969"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Passion
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_714066663" CREATED="1519772826985" MODIFIED="1519772826985"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Challenge
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1060859762" CREATED="1519772827000" MODIFIED="1519772827000"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Getting kids to grade level
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1837891007" CREATED="1519772827000" MODIFIED="1519772827000"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Sense of responsibility to improve others
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_614921517" CREATED="1519772827000" MODIFIED="1519772827000"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Do something that children aspire to
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_528413531" CREATED="1519772827016" MODIFIED="1519772827016"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Invested a lot, don't want to give investment up
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_621686786" CREATED="1519772827016" MODIFIED="1519772827016"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Proving doubters wrong
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_777371722" CREATED="1519772827016" MODIFIED="1537304769882"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Schedule&#160;
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Wednesday 1:25p" ID="ID_153873294" CREATED="1537304772217" MODIFIED="1537304828480"/>
<node TEXT="2:18p" ID="ID_720085965" CREATED="1537304829960" MODIFIED="1537304863050"/>
</node>
<node TEXT="Monica Info" FOLDED="true" ID="ID_1084284695" CREATED="1520106458102" MODIFIED="1649304607968">
<node TEXT="SS:" FOLDED="true" ID="ID_666938008" CREATED="1520106458102" MODIFIED="1520106458102">
<node TEXT="620-30-9659" ID="ID_1969470536" CREATED="1520106458102" MODIFIED="1520106458102"/>
</node>
<node TEXT="DOB" FOLDED="true" ID="ID_269153408" CREATED="1520106458102" MODIFIED="1562797200617">
<node TEXT="12/29/87" OBJECT="org.freeplane.features.format.FormattedDate|1987-12-29T00:00-0800|date" ID="ID_355227135" CREATED="1562797202151" MODIFIED="1562797208586"/>
</node>
<node TEXT="Standard insurance (disability Monica)" FOLDED="true" ID="ID_94778103" CREATED="1520106458102" MODIFIED="1649304599697">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="4" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_94778103" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="4" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_94778103" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<node TEXT="mnmcmillen" ID="ID_690746105" CREATED="1520106458102" MODIFIED="1520106458102"/>
<node TEXT="Lucydog123" ID="ID_531469115" CREATED="1520106458102" MODIFIED="1520106458102"/>
<node TEXT="Mandmmcmillen@gmail.com" ID="ID_1372451145" CREATED="1520106458102" MODIFIED="1520106458102" LINK="mailto:Mandmmcmillen@gmail.com"/>
</node>
<node TEXT="Monica CTA ID: 0010035586" ID="ID_404347289" CREATED="1520106458102" MODIFIED="1520106458102"/>
</node>
</node>
</node>
</map>
