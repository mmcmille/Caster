<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="Computing" FOLDED="false" ID="ID_57096850" CREATED="1519926472332" MODIFIED="1712429703144">
<font NAME="Nirmala UI"/>
<edge DASH="SOLID"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<hook NAME="MapStyle" background="#171717" layout="OUTLINE">
    <properties show_icon_for_attributes="true" show_note_icons="true" associatedTemplateLocation="file:/C:/GitHub/MindMaps/LifeMgmt.mm" allow_compact_layout="false" fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" ID="ID_459057019" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="oval" UNIFORM_SHAPE="true" TEXT_ALIGN="LEFT" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial" SIZE="24"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial" SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_800897947" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" NUMBERED="false" FORMAT="STANDARD_FORMAT" TEXT_ALIGN="LEFT" TEXT_WRITING_DIRECTION="LEFT_TO_RIGHT" MAX_WIDTH="120 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#808080" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="AUTO" VGAP_QUANTITY="2 pt" COMMON_HGAP_QUANTITY="14 pt">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_800897947" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Arial" SIZE="9" BOLD="true" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#333333" WIDTH="3"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/html"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/html"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial" SIZE="11"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.tags">
<font NAME="Arial" SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial" SIZE="9"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial"/>
<edge STYLE="hide_edge" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#1e3360" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#203868">
<font NAME="Arial"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial" SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<icon BUILTIN="yes"/>
<font NAME="Arial"/>
<edge COLOR="#333333"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" ID="ID_1213579137" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font NAME="Arial" SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" ID="ID_383128495" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="22" BOLD="false" ITALIC="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="20" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" ID="ID_1706681405" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="18" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="16" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="Routers" FOLDED="true" POSITION="top_or_left" ID="ID_788497520" CREATED="1527867457237" MODIFIED="1527867462616">
<node TEXT="Netgear / linksys" FOLDED="true" ID="ID_556090806" CREATED="1527796578720" MODIFIED="1527867472413">
<node TEXT="admin" ID="ID_731966836" CREATED="1527796582897" MODIFIED="1527796586922"/>
<node TEXT="Lucydog1" ID="ID_1609694005" CREATED="1527796587352" MODIFIED="1527796591722"/>
</node>
<node ID="ID_1205865484" CREATED="1595364336404" MODIFIED="1595364336404" LINK="https://kb.netgear.com/77/How-to-enable-wireless-repeating-function-on-WNR834Bv2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://kb.netgear.com/77/How-to-enable-wireless-repeating-function-on-WNR834Bv2">How to enable wireless repeating function on WNR834Bv2? | Answer | NETGEAR Support</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Desk" FOLDED="true" POSITION="bottom_or_right" ID="ID_1746814640" CREATED="1703377728951" MODIFIED="1703377733482">
<node TEXT="keyboard tray" FOLDED="true" ID="ID_803429033" CREATED="1704564095285" MODIFIED="1704564098104">
<node TEXT="Lowes A36 Bay15" ID="ID_703644217" CREATED="1704564099685" MODIFIED="1704564127110"/>
</node>
<node TEXT="desktop" FOLDED="true" ID="ID_1749966965" CREATED="1703377735135" MODIFIED="1703377737587">
<node ID="ID_1380997186" CREATED="1703377738756" MODIFIED="1703377738756" LINK="https://www.homedepot.com/p/Columbia-Forest-Products-3-4-in-x-2-ft-x-4-ft-PureBond-Red-Oak-Plywood-Project-Panel-Free-Custom-Cut-Available-2014/204311230"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.homedepot.com/p/Columbia-Forest-Products-3-4-in-x-2-ft-x-4-ft-PureBond-Red-Oak-Plywood-Project-Panel-Free-Custom-Cut-Available-2014/204311230">Columbia Forest Products 3/4 in. x 2 ft. x 4 ft. PureBond Red Oak Plywood Project Panel (Free Custom Cut Available) 2014 - The Home Depot</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Positions" FOLDED="true" POSITION="bottom_or_right" ID="ID_443905747" CREATED="1695355799750" MODIFIED="1695355803170">
<node TEXT="Monitor" ID="ID_438236196" CREATED="1521567800747" MODIFIED="1521567803496">
<node TEXT="Sceptre U515CV-UMRD" FOLDED="true" ID="ID_1622092870" CREATED="1622663806672" MODIFIED="1622663878539">
<node ID="ID_349352474" CREATED="1622665201067" MODIFIED="1622665201067" LINK="https://www.sceptre.com/TV/4K-UHD-TV/U515CV-UMRD-50-4K-UHD-TV-product1173category1category73.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sceptre.com/TV/4K-UHD-TV/U515CV-UMRD-50-4K-UHD-TV-product1173category1category73.html">U515CV-UMRD 50&quot; 4K UHD TV</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Height = center at eye level" ID="ID_593055554" CREATED="1708370299633" MODIFIED="1708370328542"/>
<node TEXT="Angle = 0" ID="ID_1205046293" CREATED="1521568415935" MODIFIED="1700697658157"/>
<node TEXT="On TV settings" FOLDED="true" ID="ID_381187611" CREATED="1708370331444" MODIFIED="1708370337004">
<node TEXT="Color temperature = Warm" ID="ID_1155452951" CREATED="1708370337009" MODIFIED="1708370358044"/>
<node TEXT="Picture settings" FOLDED="true" ID="ID_1209038097" CREATED="1708370362846" MODIFIED="1708370367394">
<node TEXT="Start with standard, adjust to" ID="ID_1418240759" CREATED="1708370618495" MODIFIED="1708370628269"/>
<node TEXT="Backlight = 0" ID="ID_1073760682" CREATED="1708370367398" MODIFIED="1708370393867"/>
<node TEXT="Sharpness = 25" ID="ID_1765877557" CREATED="1708370394385" MODIFIED="1708370414982"/>
</node>
</node>
<node TEXT="Viewing distance = 40&quot;" FOLDED="true" ID="ID_1513539085" CREATED="1695356742949" MODIFIED="1695356750746">
<node TEXT="Windows Settings" FOLDED="true" ID="ID_1978762552" CREATED="1701566537204" MODIFIED="1701566541953">
<node TEXT="Window zoom = 125%" ID="ID_203673453" CREATED="1695357507754" MODIFIED="1701566874548"/>
<node TEXT="Text size = 105% for both sitting and standing" ID="ID_879191400" CREATED="1701566625816" MODIFIED="1708369720652"/>
<node TEXT="Taskbar Location = bottom, with height of taskbar at the bottom of the desired viewing window" FOLDED="true" ID="ID_157881292" CREATED="1701929295119" MODIFIED="1701929331360">
<node TEXT="display settings for extended" FOLDED="true" ID="ID_1813028583" CREATED="1622664363602" MODIFIED="1622664370790">
<node TEXT="show taskbar on all displays" ID="ID_1918730598" CREATED="1622664378674" MODIFIED="1622664383962"/>
<node TEXT="If the location is incorrect, change location on screen, change back to desired location" ID="ID_1124584482" CREATED="1622664385631" MODIFIED="1622664402568"/>
</node>
</node>
</node>
</node>
<node TEXT="Window Panes" FOLDED="true" ID="ID_1344013636" CREATED="1695356155869" MODIFIED="1695356181882">
<node TEXT="set height of the bottom set of windows to eye level" ID="ID_916464460" CREATED="1695356185159" MODIFIED="1695356206807"/>
</node>
</node>
<node TEXT="Acer EB321HQU Awidpx 32&quot; WQHD (2560 x 1440) IPS Monitor (Display Port, HDMI &amp; DVI port)" ID="ID_686685909" CREATED="1536596854954" MODIFIED="1536596901470"/>
<node TEXT="Reference" ID="ID_1736009404" CREATED="1704563864605" MODIFIED="1704563867293">
<node TEXT="Viewing Distance" ID="ID_519919077" CREATED="1521567804354" MODIFIED="1521567808243">
<node TEXT="Current = 40&quot;" ID="ID_1144782480" CREATED="1521568542196" MODIFIED="1521568549746"/>
<node TEXT="Convergence is when the eyes turn inward toward the nose when we view close objects" FOLDED="true" ID="ID_1453896798" CREATED="1521568288911" MODIFIED="1521568288911">
<node TEXT="contributes more to discomfot vs RPA" ID="ID_27804810" CREATED="1521568368633" MODIFIED="1521568386664"/>
<node TEXT="45&quot; straight ahead" ID="ID_1360428039" CREATED="1521568317062" MODIFIED="1521568328245"/>
<node TEXT="~35&quot; w/ downward gaze angle" ID="ID_652140628" CREATED="1521568328877" MODIFIED="1521568345990"/>
</node>
<node TEXT="resting point of accommodation (RPA)" ID="ID_320360636" CREATED="1521568247838" MODIFIED="1521568247838">
<node TEXT="30&quot; avg" ID="ID_1659341164" CREATED="1521568301485" MODIFIED="1521568305683"/>
</node>
<node TEXT="http://www.office-ergo.com/wp-content/uploads/2010/12/Monitor-Viewing-Distance.-Ankrum-D.R..pdf" ID="ID_540001437" CREATED="1521569124045" MODIFIED="1521569124045" LINK="http://www.office-ergo.com/wp-content/uploads/2010/12/Monitor-Viewing-Distance.-Ankrum-D.R..pdf"/>
<node ID="ID_1895278657" CREATED="1521569984478" MODIFIED="1521569984478" LINK="http://www.allscan.ca/ergo/vangle.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.allscan.ca/ergo/vangle.htm">Viewing Angle And Distance In Computer Workstations</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Color Temperature" FOLDED="true" ID="ID_423469141" CREATED="1521568197329" MODIFIED="1521568202855">
<node TEXT="Blue?" ID="ID_1922666706" CREATED="1521568203741" MODIFIED="1521568209602"/>
</node>
</node>
<node TEXT="Standing" FOLDED="true" ID="ID_1751530253" CREATED="1695355804075" MODIFIED="1695355807528">
<node TEXT="&lt;25 minutes" ID="ID_1499326169" CREATED="1696539534847" MODIFIED="1704563906270"/>
<node TEXT="Keyboard Tray" FOLDED="true" ID="ID_1926906298" CREATED="1695358073059" MODIFIED="1695358080987">
<node TEXT="position = outside left" ID="ID_164965330" CREATED="1701566968300" MODIFIED="1701566986944"/>
</node>
<node TEXT="Windows taskbar at top" ID="ID_501499425" CREATED="1712763697281" MODIFIED="1712763705541"/>
<node TEXT="Change window panes" ID="ID_411638163" CREATED="1712763709863" MODIFIED="1712763715183"/>
</node>
<node TEXT="Sitting" FOLDED="true" ID="ID_237274748" CREATED="1695355808726" MODIFIED="1695355811687">
<node TEXT="keyboard height: 26.5" ID="ID_1689587170" CREATED="1702618317909" MODIFIED="1702618361075"/>
<node TEXT="monitor height 27.5" ID="ID_1432842616" CREATED="1702618361347" MODIFIED="1702618375165"/>
<node TEXT="upper body angle" FOLDED="true" ID="ID_559303139" CREATED="1696481278867" MODIFIED="1696481392105">
<node TEXT="0" OBJECT="java.lang.Long|0" ID="ID_157114750" CREATED="1696481285283" MODIFIED="1696481446543"/>
<node TEXT="-35" OBJECT="java.lang.Long|-35" FOLDED="true" ID="ID_902862868" CREATED="1696481448658" MODIFIED="1696481481069">
<node TEXT="cons" FOLDED="true" ID="ID_482943095" CREATED="1696481485219" MODIFIED="1696481489125">
<node TEXT="neck" FOLDED="true" ID="ID_593110379" CREATED="1696481489936" MODIFIED="1696481492427">
<node TEXT="lifting" ID="ID_893940036" CREATED="1696481613978" MODIFIED="1696481631753"/>
</node>
</node>
</node>
</node>
<node TEXT="Chair" FOLDED="true" ID="ID_1903242521" CREATED="1696481243393" MODIFIED="1696481246279">
<node TEXT="saddle chair" ID="ID_1417460836" CREATED="1707244777907" MODIFIED="1707244814951"/>
<node TEXT="Angle" ID="ID_597336159" CREATED="1696481247239" MODIFIED="1696481254826"/>
</node>
<node TEXT="Reclining" ID="ID_1255117395" CREATED="1696481188611" MODIFIED="1696481194411"/>
</node>
<node TEXT="Walking" FOLDED="true" ID="ID_1320345963" CREATED="1695355812657" MODIFIED="1695355815919">
<node TEXT="phenotyping gear" FOLDED="true" ID="ID_775990142" CREATED="1624491280756" MODIFIED="1624491280756">
<node TEXT="shoulder straps" FOLDED="true" ID="ID_748490239" CREATED="1695860353392" MODIFIED="1695860356127">
<node ID="ID_1562945133" CREATED="1695860357200" MODIFIED="1695860357200" LINK="https://www.amazon.com/s?k=adjustable+shoulder+straps&amp;crid=37MO0U5Y4OTR2&amp;sprefix=shoulder+straps+adjustable+%2Caps%2C221&amp;ref=nb_sb_ss_ts-doa-p_1_27"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/s?k=adjustable+shoulder+straps&amp;crid=37MO0U5Y4OTR2&amp;sprefix=shoulder+straps+adjustable+%2Caps%2C221&amp;ref=nb_sb_ss_ts-doa-p_1_27">Amazon.com : adjustable shoulder straps</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="miniature PC" ID="ID_53796952" CREATED="1624491280757" MODIFIED="1695860167901">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="battery pack" ID="ID_273633931" CREATED="1695860163520" MODIFIED="1695860163520"/>
<node TEXT="screen" ID="ID_1678011924" CREATED="1695860155517" MODIFIED="1695860155517"/>
<node TEXT="microphone" ID="ID_1264353905" CREATED="1695860150712" MODIFIED="1695860150712"/>
</node>
</node>
<node TEXT="Goal" FOLDED="true" POSITION="bottom_or_right" ID="ID_1891868423" CREATED="1695077406990" MODIFIED="1695077412967">
<node TEXT="hands-free" ID="ID_1800576090" CREATED="1695077413980" MODIFIED="1695077435928"/>
</node>
<node TEXT="x86" POSITION="bottom_or_right" ID="ID_1133772120" CREATED="1694745589403" MODIFIED="1694879608602">
<node TEXT="Hardware" ID="ID_565501997" CREATED="1539188349529" MODIFIED="1648262486315">
<font BOLD="true"/>
<node TEXT="ideal" FOLDED="true" ID="ID_883423699" CREATED="1694880029828" MODIFIED="1694880032059">
<node TEXT="battery powered mini pc" FOLDED="true" ID="ID_1007361648" CREATED="1694880033214" MODIFIED="1694880040868">
<node TEXT="pc" FOLDED="true" ID="ID_1596258349" CREATED="1695066545742" MODIFIED="1695066547759">
<node TEXT="n100 processor" ID="ID_1599917310" CREATED="1695066553974" MODIFIED="1695066560040"/>
<node TEXT="usb c ideally" ID="ID_126673160" CREATED="1695066579222" MODIFIED="1695066584400"/>
<node TEXT="12V 3a" ID="ID_1867873165" CREATED="1695066548838" MODIFIED="1695066552592"/>
</node>
<node TEXT="screen" ID="ID_1036875296" CREATED="1695066570598" MODIFIED="1695066572898"/>
<node TEXT="battery" FOLDED="true" ID="ID_261541298" CREATED="1695066519606" MODIFIED="1695066522576">
<node TEXT="65W 30000mAh" ID="ID_170444841" CREATED="1695066526486" MODIFIED="1695066540591"/>
</node>
</node>
</node>
<node TEXT="Acer" FOLDED="true" ID="ID_253386980" CREATED="1580652628133" MODIFIED="1580652633180">
<node TEXT="SNID" FOLDED="true" ID="ID_1703459918" CREATED="1580652635378" MODIFIED="1580652639544">
<node TEXT="22801628634" ID="ID_419053164" CREATED="1580652640519" MODIFIED="1580652640519"/>
</node>
<node TEXT="SN" FOLDED="true" ID="ID_117281720" CREATED="1580652799845" MODIFIED="1580652802248">
<node TEXT="nusgyaa00522803f9e3400" ID="ID_88118365" CREATED="1580652803259" MODIFIED="1580652803259"/>
</node>
</node>
<node TEXT="Lenovo Yoga Laptop" FOLDED="true" ID="ID_1853756065" CREATED="1635185244398" MODIFIED="1635185253749">
<node TEXT="Boot" FOLDED="true" ID="ID_485806990" CREATED="1694736263286" MODIFIED="1694736267095">
<node ID="ID_734756507" CREATED="1694736767453" MODIFIED="1694736767453" LINK="https://pcsupport.lenovo.com/us/en/products/laptops-and-netbooks/yoga-series/yoga-700-14isk/solutions/ht500216-recommended-way-to-enter-bios-ideapad"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pcsupport.lenovo.com/us/en/products/laptops-and-netbooks/yoga-series/yoga-700-14isk/solutions/ht500216-recommended-way-to-enter-bios-ideapad">Recommended way to enter BIOS - ideapad - Lenovo Support US</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Novo Buton" FOLDED="true" ID="ID_1213618444" CREATED="1694736757351" MODIFIED="1694736760830">
<node TEXT="earring is good" ID="ID_315931943" CREATED="1694745445140" MODIFIED="1694745452174"/>
</node>
<node TEXT="F2 Key repeatedly" ID="ID_380993094" CREATED="1694736371789" MODIFIED="1694736756412"/>
</node>
<node TEXT="Wi-Fi" FOLDED="true" ID="ID_726467540" CREATED="1635185260173" MODIFIED="1635185262582">
<node TEXT="disabled Wi-Fi on waking" FOLDED="true" ID="ID_26084192" CREATED="1647802474912" MODIFIED="1647802481476">
<node TEXT="fix" FOLDED="true" ID="ID_63418377" CREATED="1647802798203" MODIFIED="1647802801097">
<node TEXT="Power Optionss: change Wi-Fi settings" ID="ID_1383908740" CREATED="1647802801971" MODIFIED="1647802987784"/>
<node ID="ID_55285607" CREATED="1648478736890" MODIFIED="1648478736890" LINK="https://stackoverflow.com/questions/47530182/enabling-disabling-a-device-in-windows-10-from-command-line"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/47530182/enabling-disabling-a-device-in-windows-10-from-command-line">batch file - Enabling/disabling a device in Windows 10 from command line - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_478282964" CREATED="1635185271054" MODIFIED="1635185271054" LINK="https://oemdrivers.com/network-qualcomm-atheros-qca9377-wireless-adaptor"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://oemdrivers.com/network-qualcomm-atheros-qca9377-wireless-adaptor">Qualcomm Atheros QCA9377 Wireless Driver Windows 10 64bit | Device Drivers</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="drivers" ID="ID_1219183363" CREATED="1635185255484" MODIFIED="1635185258964"/>
</node>
<node TEXT="Toshiba Laptop" FOLDED="true" ID="ID_590903842" CREATED="1536596542572" MODIFIED="1536596548351">
<node FOLDED="true" ID="ID_1499010105" CREATED="1536596556745" MODIFIED="1536596556745" LINK="https://support.toshiba.com/support/modelHome?freeText=18440478K"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.toshiba.com/support/modelHome?freeText=18440478K">Satellite A215-S6816 Support | Toshiba</a>
  </body>
</html>
</richcontent>
<node TEXT="Resolution: 1280 x 800" ID="ID_248805651" CREATED="1545426878554" MODIFIED="1545426889123"/>
<node TEXT="A215-S6816" ID="ID_1748023185" CREATED="1546983670222" MODIFIED="1546983676841"/>
<node TEXT="Serial" FOLDED="true" ID="ID_902314558" CREATED="1546983872499" MODIFIED="1546983875675">
<node TEXT="Z7306483K" ID="ID_1577494922" CREATED="1546983876676" MODIFIED="1546983933777"/>
</node>
</node>
<node TEXT="Lubuntu" FOLDED="true" ID="ID_1714062681" CREATED="1545425242666" MODIFIED="1545425246536">
<node TEXT="Fix shutdown hang" FOLDED="true" ID="ID_1100950915" CREATED="1545427559770" MODIFIED="1545427566253">
<node TEXT="My simple fix was to edit /etc/default/grub line:" FOLDED="true" ID="ID_974738491" CREATED="1545427567894" MODIFIED="1545427567894">
<node TEXT="GRUB_CMDLINE_LINUX_DEFAULT=&quot;quiet splash&quot;" ID="ID_561783671" CREATED="1545427567894" MODIFIED="1545427567894"/>
<node TEXT="to" ID="ID_1715984810" CREATED="1545427567894" MODIFIED="1545427567894"/>
<node TEXT="GRUB_CMDLINE_LINUX_DEFAULT=&quot;quiet splash acpi=force&quot;" ID="ID_1143551935" CREATED="1545427567909" MODIFIED="1545427567909"/>
</node>
<node TEXT="sudo update-grub." ID="ID_1058032943" CREATED="1545428754424" MODIFIED="1545428754424"/>
</node>
<node TEXT="ACPI errors" ID="ID_736006162" CREATED="1545425247415" MODIFIED="1545425253568"/>
</node>
</node>
<node TEXT="PC" FOLDED="true" ID="ID_125981414" CREATED="1521567777194" MODIFIED="1536182920253">
<font NAME="Nirmala UI"/>
<node TEXT="gaming PC living room" FOLDED="true" ID="ID_274588796" CREATED="1527000090669" MODIFIED="1622215659883">
<node TEXT="GPU settings" FOLDED="true" ID="ID_518501627" CREATED="1611343464638" MODIFIED="1622215636319">
<node ID="ID_302876318" CREATED="1611343530464" MODIFIED="1611343560817"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      920MHz/850mV<br/>1165MHz/915mV<br/>1240MHz/945mV<br/>1280MHz/980mV<br/>1325MHz/1020mV (a bit lower than I'd expect (~1040mV), but based on your impressive seemingly stable results....)<br/>1365MHz/1070mV (again a bit lower than I'd expect (~1110mV))<br/><br/><br/>VRAM = 900mV
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="SSD" FOLDED="true" ID="ID_1264007943" CREATED="1527000096486" MODIFIED="1527000098306">
<node TEXT="Apacer AS340 PANTHER" FOLDED="true" ID="ID_820042429" CREATED="1527005907111" MODIFIED="1527005907111">
<node ID="ID_37752593" CREATED="1527006077663" MODIFIED="1527006077663" LINK="https://www.eteknix.com/apacer-panther-as330-240gb-solid-state-drive-review/10/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.eteknix.com/apacer-panther-as330-240gb-solid-state-drive-review/10/">Apacer Panther AS330 240GB Solid State Drive Review | Page 10 of 11 | eTeknix</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="CPU" FOLDED="true" ID="ID_1172775095" CREATED="1525705198367" MODIFIED="1525705200708">
<node TEXT="x5670" ID="ID_1803545978" CREATED="1570030071026" MODIFIED="1570030087826"/>
<node TEXT="Throttling" ID="ID_12527127" CREATED="1525705203095" MODIFIED="1525705206280"/>
<node TEXT="Core parking" ID="ID_1864844334" CREATED="1525705206735" MODIFIED="1525705211230"/>
<node TEXT="Overclock" FOLDED="true" ID="ID_261797054" CREATED="1527101709360" MODIFIED="1527101712892">
<node ID="ID_312274228" CREATED="1527101716619" MODIFIED="1527101716619" LINK="http://www.clunk.org.uk/forums/overclocking/22106-core-i7-overclocking-guide-beginners.html#post66636"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.clunk.org.uk/forums/overclocking/22106-core-i7-overclocking-guide-beginners.html#post66636">Core i7 Overclocking Guide For Beginners</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Motherboard" FOLDED="true" ID="ID_1997679569" CREATED="1569033785132" MODIFIED="1569033789459">
<node TEXT="ATX" ID="ID_262131473" CREATED="1569033792972" MODIFIED="1569033794739"/>
<node ID="ID_411594218" CREATED="1569034015270" MODIFIED="1569034015270" LINK="https://www.asus.com/Motherboards/P6X58D_Premium/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.asus.com/Motherboards/P6X58D_Premium/">P6X58D Premium | Motherboards | ASUS Global</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Case" FOLDED="true" ID="ID_1243691748" CREATED="1569033813129" MODIFIED="1569033815382">
<node FOLDED="true" ID="ID_1797953867" CREATED="1569033878814" MODIFIED="1569033878814" LINK="https://www.thermaltake.com/C_00002936.htm?id=C_00002936"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.thermaltake.com/C_00002936.htm?id=C_00002936">Core G3</a>
  </body>
</html>
</richcontent>
<node TEXT="CPU cooler height limitation: 110mm" ID="ID_1576961910" CREATED="1569033929430" MODIFIED="1569033929430"/>
<node TEXT="VGA length limitation: 310mm (With Front Fan)" ID="ID_1647756804" CREATED="1569033929430" MODIFIED="1569033929430"/>
<node TEXT="PSU clearance limitation: 130mm" ID="ID_1391405284" CREATED="1569033929430" MODIFIED="1569033929430"/>
</node>
</node>
<node TEXT="SFX PSU" FOLDED="true" ID="ID_434705968" CREATED="1569033897860" MODIFIED="1569033902239">
<node ID="ID_562844053" CREATED="1569045178189" MODIFIED="1569045178189" LINK="https://www.tomshardware.co.uk/power-supply-specifications-atx-reference,review-32338-4.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tomshardware.co.uk/power-supply-specifications-atx-reference,review-32338-4.html">Modern Form Factors: ATX And SFX - Power Supply 101: A Reference Of Specifications</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Hard Drives" FOLDED="true" ID="ID_417908105" CREATED="1608764693453" MODIFIED="1608764698771">
<node ID="ID_887231440" CREATED="1608764699753" MODIFIED="1608764699753" LINK="https://www.diskpart.com/articles/3tb-hdd-not-showing-full-capacity-3889.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.diskpart.com/articles/3tb-hdd-not-showing-full-capacity-3889.html">Quick Fix: 3TB HDD Not Showing Full Capacity in Windows 7/10</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Peripherals" ID="ID_120352356" CREATED="1548350539088" MODIFIED="1548350552799">
<node TEXT="Keyboard" FOLDED="true" ID="ID_1342565553" CREATED="1703801345734" MODIFIED="1703801348202">
<node TEXT="Delux KS200D" ID="ID_467642977" CREATED="1703801352629" MODIFIED="1703801376268"/>
</node>
<node TEXT="macro keyboard" FOLDED="true" ID="ID_1679815439" CREATED="1708200223744" MODIFIED="1708200226296">
<node TEXT="Software" FOLDED="true" ID="ID_851685454" CREATED="1708966989377" MODIFIED="1708966993509">
<node ID="ID_1815260216" CREATED="1708967848657" MODIFIED="1708967848657" LINK="https://github.com/kriomant/ch57x-keyboard-tool"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/kriomant/ch57x-keyboard-tool">GitHub - kriomant/ch57x-keyboard-tool: Utility for programming ch57x small keyboard</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_119100652" CREATED="1708200227479" MODIFIED="1708200227479" LINK="https://drive.google.com/drive/folders/1nffveqPOdLAfJ4WLYJWUbaFUJCACPJ8B"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://drive.google.com/drive/folders/1nffveqPOdLAfJ4WLYJWUbaFUJCACPJ8B">K808 - Google Drive</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="alternative" ID="ID_110073821" CREATED="1708215580384" MODIFIED="1708215593751" LINK="http://www.mkespnhk.com/Download.aspx?ClassID=9"/>
</node>
<node TEXT="Keys" FOLDED="true" ID="ID_736724623" CREATED="1708966997664" MODIFIED="1708967002229">
<node TEXT="C:\Temp\MKESPN-K808\0\skins\0_INI_CN\KbIndexText.ini" ID="ID_938321760" CREATED="1708967283213" MODIFIED="1708967283213"/>
<node TEXT="1: KU_16" ID="ID_1520954116" CREATED="1708967014489" MODIFIED="1708967032256"/>
</node>
</node>
<node TEXT="Mousing" FOLDED="true" ID="ID_1184306378" CREATED="1704835971779" MODIFIED="1704835974804">
<node TEXT="Changing Angles" FOLDED="true" ID="ID_1718075486" CREATED="1706548476918" MODIFIED="1706548482935">
<node ID="ID_515370524" CREATED="1706558548121" MODIFIED="1706558548121" LINK="https://mouseaccel.blogspot.com/2015/12/new-method-for-mouse-acceleration.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mouseaccel.blogspot.com/2015/12/new-method-for-mouse-acceleration.html">Mouse Acceleration in competitive gaming: New method for the mouse acceleration!</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Logitech T650" FOLDED="true" ID="ID_1155457407" CREATED="1548350553890" MODIFIED="1548350568108">
<node ID="ID_835067094" CREATED="1548350573031" MODIFIED="1548350573031" LINK="https://support.logitech.com/en_us/product/touchpad-t650/downloads"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.logitech.com/en_us/product/touchpad-t650/downloads">Wireless Rechargeable Touchpad T650 - Logitech Support</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1230878909" CREATED="1548350620910" MODIFIED="1548350620910" LINK="https://support.logitech.com/en_nz/article/unifying-firmware?product=a0qi00000069uqdAAA"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.logitech.com/en_nz/article/unifying-firmware?product=a0qi00000069uqdAAA">Update the firmware for a Logitech Unifying device</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Gamepads" FOLDED="true" ID="ID_1070222347" CREATED="1704835979131" MODIFIED="1704835989933">
<node TEXT="SP4248" ID="ID_1456185515" CREATED="1704835991294" MODIFIED="1704836006923"/>
</node>
<node TEXT="Drum Pad" ID="ID_443766710" CREATED="1717645607523" MODIFIED="1717645610187">
<node TEXT="install" ID="ID_402871968" CREATED="1717645664138" MODIFIED="1717645665993">
<node ID="ID_746991187" CREATED="1717697848605" MODIFIED="1717697848605" LINK="https://coyotemidi.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://coyotemidi.com/">CoyoteMIDI - MIDI to Key Commands for Windows</a>
  </body>
</html>

</richcontent>
</node>
<node TEXT="other methods" ID="ID_941105666" CREATED="1717697815992" MODIFIED="1717697818184">
<node ID="ID_1053036304" CREATED="1717645692567" MODIFIED="1717645692567" LINK="https://github.com/GlovePIEPreservation/GlovePIE/releases/tag/Release"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/GlovePIEPreservation/GlovePIE/releases/tag/Release">Release All Version Downloads · GlovePIEPreservation/GlovePIE · GitHub</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_963043919" CREATED="1717645666993" MODIFIED="1717645666993" LINK="https://www.microsoft.com/en-us/download/details.aspx?id=35"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.microsoft.com/en-us/download/details.aspx?id=35">Download DirectX End-User Runtime Web Installer from Official Microsoft Download Center</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="External Hardrives" FOLDED="true" ID="ID_440522428" CREATED="1609623813879" MODIFIED="1609623821678">
<node TEXT="SSK-DK10" FOLDED="true" ID="ID_1591687582" CREATED="1609623822996" MODIFIED="1609623836076">
<node TEXT="Setup: in device manager, disk drives, DoubleClick drives" FOLDED="true" ID="ID_507809100" CREATED="1609623836661" MODIFIED="1609623874793">
<node TEXT="Change polic to better perfomance" ID="ID_865621496" CREATED="1609623875848" MODIFIED="1609624513092"/>
</node>
</node>
</node>
<node TEXT="External HDMI Adapter" FOLDED="true" ID="ID_10412510" CREATED="1692384609324" MODIFIED="1692384627474">
<node ID="ID_617390170" CREATED="1692385071904" MODIFIED="1692385071904" LINK="https://mail.qq.com/cgi-bin/ftnExs_download?k=656266666c19d2cd1fbc94cf1238561d520003570d01560b190755035615505050574b045709061f06575703570b53530d510204342464655d0c0209434b531f630b08025b4f1703043d54480416561c511a036609&amp;t=exs_ftn_download&amp;code=4bff48d2&amp;from=mobile&amp;expiretime=-1&amp;fsize=4.62M&amp;suffix=exe&amp;from=mobile&amp;expiretime=0&amp;fsize=4.62M&amp;suffix=exe&amp;from=mobile&amp;expiretime=0&amp;fsize=4.62M&amp;suffix=exe"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mail.qq.com/cgi-bin/ftnExs_download?k=656266666c19d2cd1fbc94cf1238561d520003570d01560b190755035615505050574b045709061f06575703570b53530d510204342464655d0c0209434b531f630b08025b4f1703043d54480416561c511a036609&amp;t=exs_ftn_download&amp;code=4bff48d2&amp;from=mobile&amp;expiretime=-1&amp;fsize=4.62M&amp;suffix=exe&amp;from=mobile&amp;expiretime=0&amp;fsize=4.62M&amp;suffix=exe&amp;from=mobile&amp;expiretime=0&amp;fsize=4.62M&amp;suffix=exe">QQ邮箱中转站文件</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_13965611" CREATED="1692385059207" MODIFIED="1692385059207" LINK="https://github.com/MindShow/USBDisplay/releases/tag/AA"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/MindShow/USBDisplay/releases/tag/AA">Release USB Display Driver 20201030 · MindShow/USBDisplay · GitHub</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="msusb video" ID="ID_1906327129" CREATED="1692384664919" MODIFIED="1692384671048"/>
</node>
<node TEXT="Network Adapters" ID="ID_473601529" CREATED="1716013275255" MODIFIED="1716013280489">
<node TEXT="Netgear A6100" ID="ID_1901262053" CREATED="1527085955391" MODIFIED="1527085960704">
<node ID="ID_1297808019" CREATED="1716013343749" MODIFIED="1716013343749" LINK="https://www.netgear.com/support/product/a6100/#download"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.netgear.com/support/product/a6100/#download">A6100 | WiFi Adapters | NETGEAR Support</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Bluetooth Music Pedal" ID="ID_1979321701" CREATED="1716331885787" MODIFIED="1716331893705">
<node TEXT="Connect" ID="ID_26066539" CREATED="1716331894523" MODIFIED="1716331899758"/>
</node>
</node>
<node TEXT="SBC" FOLDED="true" ID="ID_754509125" CREATED="1549056961250" MODIFIED="1549056962680">
<node TEXT="portable?" ID="ID_1767709249" CREATED="1641312942456" MODIFIED="1641312991170"/>
<node TEXT="miniPCs" FOLDED="true" ID="ID_1253194100" CREATED="1546962609452" MODIFIED="1546962615171">
<node TEXT="Raspberi Pi 3 b+" FOLDED="true" ID="ID_1318254367" CREATED="1546968860873" MODIFIED="1546968867262">
<node TEXT="OS" FOLDED="true" ID="ID_986630138" CREATED="1547067994454" MODIFIED="1547067996605">
<node ID="ID_798850083" CREATED="1547067997712" MODIFIED="1547067997712" LINK="https://raspberrypi.stackexchange.com/questions/79389/rpi3-distro-optimized-for-linuxsampler"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://raspberrypi.stackexchange.com/questions/79389/rpi3-distro-optimized-for-linuxsampler">pi 3 - rpi3 distro optimized for linuxsampler - Raspberry Pi Stack Exchange</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Orange pi 3" FOLDED="true" ID="ID_518223104" CREATED="1549064325169" MODIFIED="1549064329910">
<node ID="ID_871958225" CREATED="1549064331433" MODIFIED="1549064331433" LINK="http://linux-sunxi.org/Linux_mainlining_effort#cite_note-h6-pcie-4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://linux-sunxi.org/Linux_mainlining_effort#cite_note-h6-pcie-4">Linux mainlining effort - linux-sunxi.org</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Pine H64" ID="ID_934883333" CREATED="1549295023283" MODIFIED="1549295026769"/>
<node TEXT="Lattepanda" ID="ID_1734820900" CREATED="1549315149363" MODIFIED="1549315153730"/>
<node TEXT="battery" FOLDED="true" ID="ID_679933393" CREATED="1546968868196" MODIFIED="1546968870696">
<node TEXT="12000mAh = 18h" ID="ID_593358339" CREATED="1546968871405" MODIFIED="1546968937600"/>
</node>
<node ID="ID_963277164" CREATED="1546963107238" MODIFIED="1546963107238" LINK="https://www.linux.com/news/top-10-open-source-linux-boards-under-200"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.linux.com/news/top-10-open-source-linux-boards-under-200">Top 10 Open Source Linux Boards Under $200 | Linux.com | The source for Linux information</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1101949906" CREATED="1547675537732" MODIFIED="1547675537732" LINK="https://www.slant.co/topics/1629/~best-single-board-computers"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.slant.co/topics/1629/~best-single-board-computers">41 Best single-board computers as of 2019 - Slant</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_732947764" CREATED="1547754319466" MODIFIED="1547754319466" LINK="https://www.electromaker.io/blog/article/best-raspberry-pi-alternatives-2019"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.electromaker.io/blog/article/best-raspberry-pi-alternatives-2019">Best Raspberry Pi Alternatives 2019</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1197298404" CREATED="1547755654796" MODIFIED="1547755654796" LINK="https://www.alibaba.com/product-detail/2018-Wins10-Linux-OS-TV-Box_60625296658.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.alibaba.com/product-detail/2018-Wins10-Linux-OS-TV-Box_60625296658.html">2018 Wins10/linux Os Tv Box Z83-v Usb 3.0 Powerful Intel Cpu X5-z8350 Smart Tv Box Z83-v - Buy Smart Tv Box,Linux Internet Tv Box,Best Smart Tv Box Product on Alibaba.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_341488717" CREATED="1548275074134" MODIFIED="1549307349925" LINK="https://www.zdnet.com/pictures/the-best-raspberry-pi-alternatives-2019-edition/13/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.zdnet.com/pictures/the-best-raspberry-pi-alternatives-2019-edition/13/">The best Raspberry Pi alternatives (2019 edition) - Page 13 | ZDNet</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1266127889" CREATED="1548279262703" MODIFIED="1548279262703" LINK="https://forum.armbian.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://forum.armbian.com/">Forums - Armbian forum</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_37944231" CREATED="1549056964416" MODIFIED="1549056964416" LINK="https://www.techrepublic.com/article/cheap-but-powerful-raspberry-pi-rival-25-pine-h64-offers-4k-hdr-video-pcie-and-usb-3-0/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.techrepublic.com/article/cheap-but-powerful-raspberry-pi-rival-25-pine-h64-offers-4k-hdr-video-pcie-and-usb-3-0/">Cheap but powerful Raspberry Pi rival: $25 Pine H64 offers 4K HDR video, PCIe and USB 3.0 - TechRepublic</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_634236669" CREATED="1549057128928" MODIFIED="1549057128928" LINK="https://www.asrock.com/mb/Intel/N3150DC-ITX/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.asrock.com/mb/Intel/N3150DC-ITX/">ASRock &gt; N3150DC-ITX</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Windows 11" FOLDED="true" ID="ID_1418516600" CREATED="1684814521319" MODIFIED="1684814525926">
<node TEXT="Android emulation" FOLDED="true" ID="ID_1218419367" CREATED="1694880145975" MODIFIED="1696223532386">
<node TEXT="LDPlayer" FOLDED="true" ID="ID_655673576" CREATED="1696223431503" MODIFIED="1696223436812">
<node TEXT=" Syngenta" FOLDED="true" ID="ID_1037064401" CREATED="1696223450948" MODIFIED="1696223457242">
<node TEXT="don&apos;t set  root permission" ID="ID_282161032" CREATED="1696223437652" MODIFIED="1696223449907"/>
<node TEXT="does allow encryption" FOLDED="true" ID="ID_1402989207" CREATED="1696224931377" MODIFIED="1696224938042">
<node TEXT="no EZCapture" ID="ID_1952601375" CREATED="1696224938362" MODIFIED="1696224953143"/>
</node>
</node>
<node TEXT="VMWare" ID="ID_1794190499" CREATED="1694880150834" MODIFIED="1694880164543"/>
</node>
</node>
<node TEXT="Break Timer" FOLDED="true" ID="ID_709254668" CREATED="1700110218283" MODIFIED="1700110222236">
<node ID="ID_1144556180" CREATED="1686849651186" MODIFIED="1686849651186" LINK="https://github.com/hovancik/stretchly/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/hovancik/stretchly/releases">Releases · hovancik/stretchly</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Interface" FOLDED="true" ID="ID_387232" CREATED="1526971433695" MODIFIED="1624645419232">
<font NAME="Nirmala UI"/>
<node TEXT="agent" FOLDED="true" ID="ID_216692035" CREATED="1710189622738" MODIFIED="1710189625201">
<node TEXT="web" FOLDED="true" ID="ID_561659905" CREATED="1710191469359" MODIFIED="1710191471387">
<node FOLDED="true" ID="ID_1167545487" CREATED="1710191472765" MODIFIED="1710191472765" LINK="https://dl.acm.org/doi/10.1145/3022671.2984020"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dl.acm.org/doi/10.1145/3022671.2984020">Ringer: web automation by demonstration | ACM SIGPLAN Notices</a>
  </body>
</html>
</richcontent>
<node ID="ID_1864679657" CREATED="1710192907771" MODIFIED="1710192907771" LINK="https://www.youtube.com/watch?v=WwsCzRb2iI8"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.youtube.com/watch?v=WwsCzRb2iI8">Ringer: Web Automation by Demonstration - YouTube</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Rabbit OS" FOLDED="true" ID="ID_70600280" CREATED="1710189879407" MODIFIED="1710189886236">
<node TEXT="Large Action Model" FOLDED="true" ID="ID_1745674817" CREATED="1710189887408" MODIFIED="1710189892207">
<node ID="ID_758014650" CREATED="1710190420468" MODIFIED="1710190420468" LINK="https://www.rabbit.tech/research"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.rabbit.tech/research">rabbit - research</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="neuro- symbolic programming" ID="ID_204018856" CREATED="1710189892209" MODIFIED="1710189897208"/>
</node>
</node>
</node>
<node TEXT="Window Management" FOLDED="true" ID="ID_227805815" CREATED="1646978948303" MODIFIED="1716348478640">
<node FOLDED="true" ID="ID_1847435396" CREATED="1715905138410" MODIFIED="1715905138410" LINK="https://github.com/microsoft/PowerToys"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/microsoft/PowerToys">microsoft/PowerToys: Windows system utilities to maximize productivity</a>
  </body>
</html>
</richcontent>
<node TEXT="Fancy Zones" FOLDED="true" ID="ID_534947386" CREATED="1715740853073" MODIFIED="1715740857601">
<node ID="ID_627805064" CREATED="1715740860132" MODIFIED="1715740860132" LINK="https://github.com/microsoft/PowerToys/issues/4419"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/microsoft/PowerToys/issues/4419">FancyZones, move custom-zone-sets to separate setting file(s) · Issue #4419 · microsoft/PowerToys · GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="remap &quot;Home Key&quot; to shortcut" ID="ID_224222057" CREATED="1686370681534" MODIFIED="1695962084099">
<arrowlink DESTINATION="ID_962712039"/>
</node>
</node>
<node TEXT="macros" FOLDED="true" ID="ID_1378600743" CREATED="1686372880969" MODIFIED="1686372883370">
<node ID="ID_1488708291" CREATED="1686372890477" MODIFIED="1686372890477" LINK="https://www.phraseexpress.com/download/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.phraseexpress.com/download/">Download PhraseExpress from the official source</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Autohotkey, Keyboard macros" FOLDED="true" ID="ID_1797829298" CREATED="1649782448086" MODIFIED="1649782448086">
<node ID="ID_563435382" CREATED="1686372143102" MODIFIED="1686372143102" LINK="https://www.howtogeek.com/45068/how-to-get-spelling-autocorrect-across-all-applications-on-your-system/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.howtogeek.com/45068/how-to-get-spelling-autocorrect-across-all-applications-on-your-system/">How to Get Spelling Autocorrect Across All Applications on Your System</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Point-N-Click Virtual Mouse By Polital Enterprises" ID="ID_1577992661" CREATED="1649782448086" MODIFIED="1649782717722" LINK="https://www.polital.com/pnc/"/>
<node TEXT="Space desk, use android tablet as 2nd monitor" ID="ID_186341679" CREATED="1656344436694" MODIFIED="1656344436694"/>
<node TEXT="Control My Monitor, nirsoft.net" FOLDED="true" ID="ID_998496411" CREATED="1649782448086" MODIFIED="1649782448086">
<node ID="ID_1787940674" CREATED="1686850680215" MODIFIED="1686850680215" LINK="https://www.nirsoft.net/utils/control_my_monitor.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.nirsoft.net/utils/control_my_monitor.html">View and modify the settings of your monitor (VCP Features)</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="brightness" ID="ID_1056569671" CREATED="1651855722783" MODIFIED="1651855726137"/>
</node>
</node>
<node TEXT="Implemented" FOLDED="true" ID="ID_575843456" CREATED="1695922252198" MODIFIED="1695922255910">
<node TEXT="Caster" ID="ID_1219441798" CREATED="1610316346504" MODIFIED="1637707184812" LINK="https://caster.readthedocs.io">
<font BOLD="false"/>
<node TEXT="Installation" FOLDED="true" ID="ID_1327730210" CREATED="1717686902169" MODIFIED="1717686906075">
<node TEXT="Reinstallation or Removal" FOLDED="true" ID="ID_387341379" CREATED="1646977485627" MODIFIED="1646977901166">
<node TEXT="Delete or Rename C:\Users\u581917\AppData\Local\caster\" ID="ID_321896403" CREATED="1646977485627" MODIFIED="1697396515869"/>
<node TEXT="Unistall Natlink" ID="ID_494729369" CREATED="1646977485627" MODIFIED="1646977485627"/>
<node TEXT="Unpython" ID="ID_1194393416" CREATED="1646977485627" MODIFIED="1646977485627"/>
</node>
<node FOLDED="true" ID="ID_1919202037" CREATED="1684988109227" MODIFIED="1685167754059" LINK="https://desktop.github.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://desktop.github.com/">Install GitHub Desktop</a>
  </body>
</html>
</richcontent>
<node TEXT="First time (only, on any computer)" FOLDED="true" ID="ID_1514163178" CREATED="1684988513215" MODIFIED="1684988544507">
<node TEXT="Clone GitHub - dictation-toolbox/Caster" FOLDED="true" ID="ID_1756964168" CREATED="1646977485627" MODIFIED="1646977958731" LINK="https://github.com/dictation-toolbox/Caster/">
<node TEXT="Clone GitHub - dictation-toolbox/Caster at DropPy2" ID="ID_1754548741" CREATED="1684987362180" MODIFIED="1684987362180"/>
</node>
</node>
<node TEXT="Currently clone mmcmille/Caster" FOLDED="true" ID="ID_292269063" CREATED="1684988546793" MODIFIED="1684988648955">
<node TEXT="C:/Github/Caster" ID="ID_843734674" CREATED="1684988667969" MODIFIED="1684988681683"/>
</node>
</node>
<node TEXT="Choose Engine" ID="ID_941242643" CREATED="1636264182528" MODIFIED="1717686935469">
<node TEXT="Dragon, py 3.10" ID="ID_1355317208" CREATED="1622579678519" MODIFIED="1695775367917">
<node TEXT="install" ID="ID_810972003" CREATED="1697396380161" MODIFIED="1697396385255">
<node TEXT="install Dragon NS 16" FOLDED="true" ID="ID_1425757049" CREATED="1625240512948" MODIFIED="1695614986082">
<node TEXT="Install 15" FOLDED="true" ID="ID_545290636" CREATED="1695508498716" MODIFIED="1695508507045">
<node TEXT="Get File" FOLDED="true" ID="ID_420522429" CREATED="1695508509769" MODIFIED="1695508513511">
<node ID="ID_320660073" CREATED="1686954296263" MODIFIED="1686954296263" LINK="https://download.nuance.com/Nuance/downloadform.aspx?language=en-US"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://download.nuance.com/Nuance/downloadform.aspx?language=en-US">9. Nuance Product Download Center</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Serial Number:" FOLDED="true" ID="ID_1062881287" CREATED="1625241374314" MODIFIED="1625241477425">
<node TEXT="DC09A-G00-3RD5-JX6Z-1X" ID="ID_718846891" CREATED="1625241477426" MODIFIED="1625241477427"/>
<node TEXT="Order Number:" FOLDED="true" ID="ID_116947690" CREATED="1625241434024" MODIFIED="1625241445570">
<node TEXT="Lucydog1" ID="ID_1332968111" CREATED="1622586343679" MODIFIED="1622586355797"/>
<node TEXT="1003120694520" ID="ID_319566647" CREATED="1625241445585" MODIFIED="1625241445585"/>
</node>
</node>
<node TEXT="Install, dont register" ID="ID_5191090" CREATED="1695508580274" MODIFIED="1695508588791"/>
</node>
<node TEXT="Install 16" FOLDED="true" ID="ID_1259781054" CREATED="1695501382427" MODIFIED="1695508530887">
<node TEXT="Get Dragon 16" FOLDED="true" ID="ID_1919323864" CREATED="1687370039866" MODIFIED="1695508542373">
<node ID="ID_192098416" CREATED="1687370033397" MODIFIED="1687370033397" LINK="https://shop.nuance.com/DRHM/store#"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://shop.nuance.com/DRHM/store#">29. Nuance Online Store</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1914585461" CREATED="1695501385893" MODIFIED="1695501385893" LINK="https://shopaccount.nuance.com/login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://shopaccount.nuance.com/login">Nuance Shop Account</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="ID:" FOLDED="true" ID="ID_1243440251" CREATED="1686957340493" MODIFIED="1686957342628">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_452132674" CREATED="1686957429357" MODIFIED="1686957438160"/>
<node TEXT="Lucydog1" ID="ID_1094811205" CREATED="1686957439036" MODIFIED="1686957442550"/>
</node>
</node>
<node TEXT="Serial" FOLDED="true" ID="ID_999505344" CREATED="1695501410520" MODIFIED="1695501420080">
<node TEXT="DP89A-R00-JN88-FJPD-X5" ID="ID_996711977" CREATED="1695501424996" MODIFIED="1695501424996"/>
</node>
</node>
</node>
<node TEXT="install python" FOLDED="true" ID="ID_1829787567" CREATED="1695698259739" MODIFIED="1695698263669">
<node TEXT="uninstall previous, if needed" ID="ID_573239335" CREATED="1695700980387" MODIFIED="1695700993772"/>
<node TEXT="add python to environment variables" ID="ID_282714908" CREATED="1695701386093" MODIFIED="1695701396723"/>
<node TEXT="install to C:\" ID="ID_1747352101" CREATED="1695756505910" MODIFIED="1695756515330"/>
<node TEXT="need 3.10.0 x32 for natlink" ID="ID_91654459" CREATED="1695753829225" MODIFIED="1715897422697"/>
<node ID="ID_128703296" CREATED="1695698272352" MODIFIED="1695698272352" LINK="https://www.python.org/downloads/release/python-3100/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.python.org/downloads/release/python-3100/">Python Release Python 3.10.0 | Python.org</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="restart PC" ID="ID_1525677671" CREATED="1695701518887" MODIFIED="1695701522259"/>
<node TEXT="install Natlink" FOLDED="true" ID="ID_45931877" CREATED="1695698242958" MODIFIED="1695698247683">
<node FOLDED="true" ID="ID_1278587462" CREATED="1695698160167" MODIFIED="1695701115425" LINK="https://natlink.readthedocs.io/en/latest/install.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://natlink.readthedocs.io/en/latest/install.html">Install instructions for Natlink — natlink 5.5.5 documentation</a>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node FOLDED="true" ID="ID_1289670029" CREATED="1715897737624" MODIFIED="1715897737624" LINK="https://web.archive.org/web/20231003135029/https://natlink.readthedocs.io/en/latest/install.html#install-instructions-for-natlink"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h1 style="margin-top: 0px; font-weight: 700; font-family: Roboto Slab, ff-tisa-web-pro, Georgia, Arial, sans-serif; font-size: 28px; margin-bottom: 24px; color: rgb(64, 64, 64); font-style: normal; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      Install instructions for Natlink<a class="headerlink" href="https://web.archive.org/web/20231003135029/https://natlink.readthedocs.io/en/latest/install.html#install-instructions-for-natlink" title="Permalink to this heading" style="color: rgb(41, 128, 185); text-decoration: none; display: inline-block; font-style: normal; font-variant: normal; font-weight: normal; font-size: 14px; line-height: 1; font-family: FontAwesome; margin-left: 0"><span style="color: rgb(41, 128, 185); text-decoration: none; display: inline-block; font-style: normal; font-variant: normal; font-weight: normal; font-size: 14px; line-height: 1; font-family: FontAwesome; margin-left: 0;"></span></a>
    </h1>
  </body>
</html>
</richcontent>
<node ID="ID_912665957" CREATED="1715897737626" MODIFIED="1715897737626"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          Install Dragon NaturallySpeaking
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1838351079" CREATED="1715897737629" MODIFIED="1715897737629"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          Optional: install Python 3.10 (32 bit required) for your user and do not add to path. This will also be done, if necessary, when you run the installer program, but the path where python is installed may be less convenient.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1857686082" CREATED="1715897737632" MODIFIED="1715897737632" LINK="https://web.archive.org/web/20231003135029/https://github.com/dictation-toolbox/natlink/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          Download and run the latest [Natlink installer](<a class="reference external" href="https://web.archive.org/web/20231003135029/https://github.com/dictation-toolbox/natlink/releases" style="color: rgb(41, 128, 185); text-decoration: none"><span style="color: rgb(41, 128, 185); text-decoration: none;">https://github.com/dictation-toolbox/natlink/releases</span></a>): choose the most recent release, at the top of the page, and then scroll down and choose the file natlink?.?.?-py3.10-32-setup.exe.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_469293071" CREATED="1715897737634" MODIFIED="1715897737634"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          As last step of the install procedure, the program&#xa0;<cite>natlinkconfig_gui</cite>&#xa0;is started. When you want to run this program later (again), type the program name at the Windows start program prompt.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1199648225" CREATED="1715897737635" MODIFIED="1715897737635"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          When using ‘dragonfly’, ‘vocola’ and/or ‘unimacro’, these packages are installed via&#xa0;<cite>pip</cite>&#xa0;with the config program. When you need other packages, you can install these with pip.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_179119155" CREATED="1715897737638" MODIFIED="1715897737638"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          Then start Dragon, the ‘Messages from Natlink’ window should show up.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_61948163" CREATED="1715897737640" MODIFIED="1715897737640"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          See configure Natlink for more details.
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_958279301" CREATED="1715897737644" MODIFIED="1715897737644" LINK="https://web.archive.org/web/20231003135029/https://github.com/dictation-toolbox/natlink/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul class="simple" style="margin-top: 0px; margin-right: 0px; margin-bottom: 24px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; list-style: disc; line-height: 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, Helvetica Neue, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(252, 252, 252)">
      <li style="list-style: disc; margin-left: 24px">
        <p style="line-height: 24px; font-size: 16px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          Also see [installation instructions](<a class="reference external" href="https://web.archive.org/web/20231003135029/https://github.com/dictation-toolbox/natlink/" style="color: rgb(41, 128, 185); text-decoration: none"><span style="color: rgb(41, 128, 185); text-decoration: none;">https://github.com/dictation-toolbox/natlink/</span></a>) (scroll down a bit…)
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="install Caster Dependencies" FOLDED="true" ID="ID_6432024" CREATED="1695704216368" MODIFIED="1695704223247">
<node TEXT="python -m pip install --upgrade pip" ID="ID_1864436097" CREATED="1646977485627" MODIFIED="1646977485627"/>
<node TEXT="pillow" FOLDED="true" ID="ID_1166777541" CREATED="1695704245965" MODIFIED="1695704249815">
<node TEXT="get .whl" FOLDED="true" ID="ID_1811181418" CREATED="1695704334125" MODIFIED="1695704338496">
<node ID="ID_1021794625" CREATED="1695704225598" MODIFIED="1695704225598" LINK="https://www.lfd.uci.edu/~gohlke/pythonlibs/#pillow"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.lfd.uci.edu/~gohlke/pythonlibs/#pillow">Archived: Python Extension Packages for Windows - Christoph Gohlke</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="install using" FOLDED="true" ID="ID_337713452" CREATED="1695704341016" MODIFIED="1695704351259">
<node TEXT="python -m pip install C:\Users\micha\Downloads\Pillow-9.1.1-cp310-cp310-win32.whl" ID="ID_977700122" CREATED="1695704377434" MODIFIED="1695757279021"/>
<node ID="ID_1338717227" CREATED="1695704342410" MODIFIED="1695704342410" LINK="https://www.educative.io/answers/how-to-install-a-python-package-with-a-whl-file"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.educative.io/answers/how-to-install-a-python-package-with-a-whl-file">How to install a Python package with a .whl file</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="run" FOLDED="true" ID="ID_329413610" CREATED="1695755948305" MODIFIED="1695755950716">
<node TEXT="C:\GitHub\Caster\Install_Caster_DNS-WSR.bat" FOLDED="true" ID="ID_808822240" CREATED="1695757460871" MODIFIED="1695757460871">
<node TEXT="changed wxPython" ID="ID_361496157" CREATED="1695791225012" MODIFIED="1695791241836"/>
<node TEXT="important tomlkit" ID="ID_1760281890" CREATED="1695791250620" MODIFIED="1695791258638"/>
<node TEXT="requirements.txt" FOLDED="true" ID="ID_1129118258" CREATED="1695791196057" MODIFIED="1695791202212">
<node TEXT="regex&lt;2022.1.18" ID="ID_943836767" CREATED="1695791203843" MODIFIED="1695791288019">
<font BOLD="true"/>
</node>
<node TEXT="dragonfly2&gt;=0.29.0" ID="ID_1876157603" CREATED="1695791203843" MODIFIED="1695791203843"/>
<node TEXT="pillow&gt;=6.2.2" ID="ID_1877101294" CREATED="1695791203845" MODIFIED="1695791203845"/>
<node TEXT="tomlkit&lt;=0.11.6" ID="ID_393981467" CREATED="1695791203845" MODIFIED="1695791219410">
<font BOLD="true"/>
</node>
<node TEXT="future&gt;=0.18.2" ID="ID_1942676067" CREATED="1695791203847" MODIFIED="1695791203847"/>
<node TEXT="mock&gt;=3.0.5" ID="ID_1998963801" CREATED="1695791203847" MODIFIED="1695791203847"/>
<node TEXT="appdirs&gt;=1.4.3" ID="ID_1894935259" CREATED="1695791203848" MODIFIED="1695791203848"/>
<node TEXT="scandir&gt;=1.10.0" ID="ID_707921799" CREATED="1695791203848" MODIFIED="1695791203848"/>
<node TEXT="pyvda==0.0.8" ID="ID_1396398486" CREATED="1695791203849" MODIFIED="1695791295410">
<font BOLD="true"/>
</node>
<node TEXT="six" ID="ID_418853527" CREATED="1695791203849" MODIFIED="1695791203849"/>
<node TEXT="wxpython" ID="ID_701701079" CREATED="1695791203850" MODIFIED="1695791214857">
<font BOLD="true"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="configure" FOLDED="true" ID="ID_637773615" CREATED="1695698773652" MODIFIED="1695698794826">
<node TEXT="manual" ID="ID_794959699" CREATED="1695700874582" MODIFIED="1695700876733">
<node TEXT="edit" FOLDED="true" ID="ID_17808905" CREATED="1695700878478" MODIFIED="1695700880088">
<node TEXT="C:\Users\micha\.natlink\natlink.ini" ID="ID_503300595" CREATED="1695700881617" MODIFIED="1695700881617">
<node TEXT="add caster directory" ID="ID_955012133" CREATED="1695704571130" MODIFIED="1695704577661"/>
</node>
</node>
</node>
<node TEXT="NAtlink configuration GUI" FOLDED="true" ID="ID_917928431" CREATED="1695698795183" MODIFIED="1695698802363">
<node TEXT="Configure Projects, Dragonfly" ID="ID_1676393095" CREATED="1695698803800" MODIFIED="1695698823952">
<node TEXT="point to Caster directory" ID="ID_1506544927" CREATED="1695698825209" MODIFIED="1695698831634"/>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1175701220" CREATED="1695698877541" MODIFIED="1695698880303">
<node ID="ID_419595350" CREATED="1695698881267" MODIFIED="1695698881267" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/#-alternative-natlink-configuration"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/#-alternative-natlink-configuration">Dragon NaturallySpeaking - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1007547191" CREATED="1695615162124" MODIFIED="1695615162124" LINK="https://github.com/dictation-toolbox/natlink"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/dictation-toolbox/natlink">GitHub - dictation-toolbox/natlink: Natlink provides the interface between Dragon and python</a>
  </body>
</html>
</richcontent>
</node>
<node POSITION="bottom_or_right" ID="ID_1443572411" CREATED="1695615055793" MODIFIED="1695615055793" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/">Dragon NaturallySpeaking - Caster</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="if it&apos;s a Reinstall, change user directory" FOLDED="true" ID="ID_1779737421" CREATED="1687371878858" MODIFIED="1695699134433">
<node TEXT="Rename or delete folder:" FOLDED="true" ID="ID_1139132554" CREATED="1687371878858" MODIFIED="1687371878858">
<node TEXT="C:\Users\u581917\AppData\Local\caster\" ID="ID_1717340912" CREATED="1687371878859" MODIFIED="1687371878859"/>
</node>
<node TEXT="Run Install .bat file" ID="ID_61551739" CREATED="1687371878860" MODIFIED="1687371878860"/>
<node TEXT="Config Natlink via GUI for Dragon engine" ID="ID_1482145407" CREATED="1687371878861" MODIFIED="1687371878861"/>
<node TEXT="Unregister" ID="ID_1688717654" CREATED="1687371878862" MODIFIED="1687371878862"/>
<node TEXT="Restart Dragon" ID="ID_603687258" CREATED="1687371878863" MODIFIED="1687371878863"/>
<node TEXT="Run config" ID="ID_1788045389" CREATED="1687371878864" MODIFIED="1687371878864"/>
<node TEXT="Change UserDirectory" ID="ID_1712557008" CREATED="1687371878865" MODIFIED="1687371878865"/>
<node TEXT="Regester" ID="ID_433584577" CREATED="1687371878865" MODIFIED="1687371878865"/>
</node>
<node TEXT="errors" FOLDED="true" ID="ID_797072233" CREATED="1695752229240" MODIFIED="1695752232428">
<node FOLDED="true" ID="ID_1521086646" CREATED="1695752233789" MODIFIED="1695752233789" LINK="https://github.com/GoogleCloudPlatform/gsutil/issues/1331"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/GoogleCloudPlatform/gsutil/issues/1331">Python 3.10 -- AttributeError: module 'collections' has no attribute 'Mapping' · Issue #1331 · GoogleCloudPlatform/gsutil · GitHub</a>
  </body>
</html>
</richcontent>
<node ID="ID_1916014201" CREATED="1695752859723" MODIFIED="1695752859723" LINK="https://appdividend.com/2022/12/20/attributeerror-module-collections-has-no-attribute-mutablemapping/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://appdividend.com/2022/12/20/attributeerror-module-collections-has-no-attribute-mutablemapping/">How to Fix AttributeError: Module 'collections' has no attribute 'mutablemapping'</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Caster NL (previous install)" FOLDED="true" ID="ID_533641432" CREATED="1636265192150" MODIFIED="1695700950301">
<node TEXT="current installation, Python 3.8.x 32-bit" FOLDED="true" ID="ID_1240155923" CREATED="1636264202928" MODIFIED="1646977794312">
<node TEXT="Install Python" FOLDED="true" ID="ID_332534682" CREATED="1646977485627" MODIFIED="1646977485627">
<node TEXT="Install Python 3.8 x32 ( current )" ID="ID_416694678" CREATED="1646977485627" MODIFIED="1646977485627"/>
<node TEXT="CMD" FOLDED="true" ID="ID_964847242" CREATED="1646977485627" MODIFIED="1646977485627">
<node TEXT="Go to python folder" ID="ID_318842908" CREATED="1646977485627" MODIFIED="1646977485627"/>
<node TEXT="Update pip" FOLDED="true" ID="ID_836912042" CREATED="1646977485627" MODIFIED="1646977485627">
<node TEXT="python -m pip install --upgrade pip" ID="ID_946519626" CREATED="1646977485627" MODIFIED="1646977485627"/>
</node>
</node>
</node>
<node TEXT="Install Natlink 5" FOLDED="true" ID="ID_618834979" CREATED="1646977485627" MODIFIED="1646977485627">
<node TEXT="https://github.com/dictation-toolbox/natlink/releases" ID="ID_869459981" CREATED="1646978057300" MODIFIED="1646978057300" LINK="https://github.com/dictation-toolbox/natlink/releases"/>
</node>
<node TEXT="Install caster dependencies" FOLDED="true" ID="ID_1823055466" CREATED="1646977485627" MODIFIED="1646977485627">
<node TEXT="python -m pip install dragonfly2 wxpython pillow tomlkit future mock appdirs scandir pyvda six wheel" ID="ID_8479231" CREATED="1646977485643" MODIFIED="1646977485643"/>
</node>
<node TEXT="Update Natlink.ini" FOLDED="true" ID="ID_1606783587" CREATED="1646977485643" MODIFIED="1646977485643">
<node TEXT="Caster = C:\GD_sync\Voice\GitHub\Caster\" ID="ID_628704067" CREATED="1646977485643" MODIFIED="1646977485643"/>
</node>
<node TEXT="Run Dragon" ID="ID_835387614" CREATED="1646977485643" MODIFIED="1646977485643"/>
<node TEXT="File Operations" FOLDED="true" ID="ID_1096406731" CREATED="1646977485659" MODIFIED="1646977485659">
<node TEXT="After 1st run, rename C:\GD_sync\Voice\GitHub\Caster\castervoice\lib\util\pathlib\x__init__.pyx (prefix and suffix with x)" FOLDED="true" ID="ID_424779579" CREATED="1646977485659" MODIFIED="1646977485659">
<node TEXT="If you don&apos;t, you&apos;ll get errors because it will try to transition the castor settings from Python 2 to 3" ID="ID_91393315" CREATED="1646977485659" MODIFIED="1646977485659"/>
</node>
<node TEXT="! Replace C:\Users\u581917\AppData\Local\caster\settings\sm_bringme.toml with saved" ID="ID_1009548496" CREATED="1646977485659" MODIFIED="1646977485659"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1441857518" CREATED="1646977856871" MODIFIED="1646977861062">
<node ID="ID_755619107" CREATED="1636264262016" MODIFIED="1636264262016" LINK="https://github.com/dictation-toolbox/natlink"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/dictation-toolbox/natlink">GitHub - dictation-toolbox/natlink</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Python reference" FOLDED="true" ID="ID_874595691" CREATED="1636259739878" MODIFIED="1646977646275">
<node ID="ID_228366529" CREATED="1636234367645" MODIFIED="1636234367645" LINK="https://stackoverflow.com/questions/4583367/how-to-run-multiple-python-versions-on-windows"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/4583367/how-to-run-multiple-python-versions-on-windows">How to run multiple Python versions on Windows - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1048669304" CREATED="1636234855868" MODIFIED="1636234855868" LINK="https://www.freecodecamp.org/news/installing-multiple-python-versions-on-windows-using-virtualenv/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.freecodecamp.org/news/installing-multiple-python-versions-on-windows-using-virtualenv/">Installing Multiple Python Versions on Windows Using Virtualenv</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_481652900" CREATED="1636236349281" MODIFIED="1636236349281" LINK="http://testerstories.com/2014/06/multiple-versions-of-python-on-windows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://testerstories.com/2014/06/multiple-versions-of-python-on-windows/">Multiple Versions of Python on Windows – Stories from a Software Tester</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="old installation Python 2.7 x32" FOLDED="true" ID="ID_398156906" CREATED="1636265292415" MODIFIED="1646977769721">
<node TEXT="1) Install Natlink 4.2" FOLDED="true" ID="ID_258806279" CREATED="1623709628511" MODIFIED="1623709641631">
<node FOLDED="true" ID="ID_169856060" CREATED="1623708699086" MODIFIED="1623708699086" LINK="https://qh.antenna.nl/unimacro/installation/installationstableversionpython2.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://qh.antenna.nl/unimacro/installation/installationstableversionpython2.html">installation stable version python2</a>
  </body>
</html>
</richcontent>
<node TEXT="pip" ID="ID_1159054771" CREATED="1623773868152" MODIFIED="1623773873390"/>
</node>
</node>
<node TEXT="2) Install Caster" FOLDED="true" ID="ID_533466093" CREATED="1623709677006" MODIFIED="1623709690025">
<node ID="ID_1382592942" CREATED="1618091486224" MODIFIED="1618091514795" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/">Install:&nbsp;&nbsp;Dragon NaturallySpeaking - Caster</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Reinstall" FOLDED="true" ID="ID_1482373625" CREATED="1618092600057" MODIFIED="1618092603292">
<node TEXT="delete folder:" FOLDED="true" ID="ID_391963279" CREATED="1618092604934" MODIFIED="1618092614036">
<node TEXT="C:\Users\u581917\AppData\Local\caster\" ID="ID_1987326877" CREATED="1618092617465" MODIFIED="1618092617465"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="adjust Dragon settings" ID="ID_767931384" CREATED="1622579684293" MODIFIED="1717686998749">
<node TEXT="C:\ProgramData\Nuance\NaturallySpeaking16\nsdefaults.ini" ID="ID_1385615366" CREATED="1706566374192" MODIFIED="1706566374192">
<node TEXT="Disable Dictation=1" ID="ID_1271588734" CREATED="1706566756989" MODIFIED="1706566756989"/>
</node>
<node TEXT="change event delays" ID="ID_447442315" CREATED="1706560924672" MODIFIED="1706560931133">
<node TEXT="Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Nuance\NaturallySpeaking16" ID="ID_1526909264" CREATED="1706560942456" MODIFIED="1706560942456">
<node TEXT="keyboard event delay" ID="ID_665128242" CREATED="1706561005622" MODIFIED="1706561010713">
<node TEXT="set all to 0" ID="ID_1613283315" CREATED="1706561116172" MODIFIED="1706561119042"/>
<node TEXT="originally 100, 10, 25, 0" ID="ID_755210619" CREATED="1706561013903" MODIFIED="1706561051377"/>
</node>
</node>
<node TEXT="C:\Users\micha\AppData\Local\Nuance\NS16\Users\Michael McMillen\current\soptions.ini" ID="ID_1100589341" CREATED="1706563070904" MODIFIED="1706563070904">
<node TEXT="Speed Versus Accuracy" ID="ID_445854893" CREATED="1706563384544" MODIFIED="1706563388650">
<node TEXT="ComputeSpeed=0-100" ID="ID_816467275" CREATED="1706563378246" MODIFIED="1706563458616">
<node TEXT="-1" OBJECT="java.lang.Long|-1" ID="ID_321391080" CREATED="1706565090717" MODIFIED="1706565092160"/>
</node>
</node>
<node TEXT="pause between commands" ID="ID_1628375443" CREATED="1706562957953" MODIFIED="1706562972795">
<node TEXT="DwTimeOutIncomplete=160" ID="ID_765635287" CREATED="1706564961943" MODIFIED="1706564961943">
<node TEXT="10" OBJECT="java.lang.Long|10" ID="ID_1683795848" CREATED="1706565013081" MODIFIED="1706565017858"/>
</node>
<node TEXT="DwTimeOutComplete=100-1000" ID="ID_1752825659" CREATED="1706563422878" MODIFIED="1706563604926">
<node TEXT="1" OBJECT="java.lang.Long|1" ID="ID_482615909" CREATED="1706564037340" MODIFIED="1706564345453"/>
</node>
</node>
</node>
</node>
<node TEXT="disable web browser extensions" FOLDED="true" ID="ID_1267116220" CREATED="1695790804628" MODIFIED="1695790812922">
<node TEXT="open notepad as administrator" FOLDED="true" ID="ID_894182107" CREATED="1695790832398" MODIFIED="1695790842236">
<node TEXT="C:\ProgramData\Nuance\NaturallySpeaking16\nssystem.ini" FOLDED="true" ID="ID_144068376" CREATED="1695790817396" MODIFIED="1695790827487">
<node TEXT="[MSAA Modules Disabled]" ID="ID_323165998" CREATED="1695790814667" MODIFIED="1695790814667"/>
<node TEXT="chrome=1" ID="ID_792657825" CREATED="1695790814667" MODIFIED="1695790814667"/>
<node TEXT="edge=1" ID="ID_1684197854" CREATED="1695790814669" MODIFIED="1695790814669"/>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1817569118" CREATED="1695790859624" MODIFIED="1695790862043">
<node ID="ID_1984483401" CREATED="1695790866665" MODIFIED="1695790866665" LINK="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=4&amp;threadid=37445&amp;enterthread=y"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=4&amp;threadid=37445&amp;enterthread=y">KnowBrainer Speech Recognition Forums - Dragon 16 Hangs when using Chrome and Edge</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Dragon Vocabulary" FOLDED="true" ID="ID_1975720300" CREATED="1707088136474" MODIFIED="1707088143061">
<node TEXT="edit commands for ( and ), removing spaces after" FOLDED="true" ID="ID_1062143369" CREATED="1707088143065" MODIFIED="1707155093277">
<node TEXT="(replaced by hug command in punctuation )" ID="ID_1232898135" CREATED="1707088159018" MODIFIED="1707088190081"/>
</node>
</node>
<node TEXT="within Dragon" FOLDED="true" ID="ID_105896462" CREATED="1695785478234" MODIFIED="1695785481055">
<node TEXT="enable dictation box to prevent accidental edits" ID="ID_1530463847" CREATED="1622579694405" MODIFIED="1622579708645"/>
<node TEXT="Check: Use automatic dictation box for this application, to disable for each application" ID="ID_1287327982" CREATED="1622579710143" MODIFIED="1622579736164"/>
<node TEXT="autoformatting options" FOLDED="true" ID="ID_957011591" CREATED="1623342187530" MODIFIED="1623342194001">
<node TEXT="numbers greater than 0" ID="ID_1979092184" CREATED="1623342195121" MODIFIED="1623342198263"/>
<node TEXT="Other numbers" ID="ID_1079935195" CREATED="1623342199800" MODIFIED="1623342202989"/>
<node TEXT="enable pauses between phrases" ID="ID_1163799958" CREATED="1632243879083" MODIFIED="1632243887384"/>
</node>
</node>
<node TEXT="Dragon scripting" FOLDED="true" ID="ID_48798731" CREATED="1610314537071" MODIFIED="1622220315804">
<node ID="ID_341384236" CREATED="1610314599694" MODIFIED="1610314599694" LINK="https://www.nuance.com/products/help/dragon/dragon-for-pc/scriptref/Content/scrptref/setmouseposition.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.nuance.com/products/help/dragon/dragon-for-pc/scriptref/Content/scrptref/setmouseposition.htm">SetMousePosition scripting command</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1995276932" CREATED="1610314537072" MODIFIED="1610314537072" LINK="https://www.nuance.com/products/help/dragon/dragon-for-pc/scriptref/Content/scrptref/scripting_language_quickref.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.nuance.com/products/help/dragon/dragon-for-pc/scriptref/Content/scrptref/scripting_language_quickref.htm">Dragon scripting language extensions quick reference</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1257572966" CREATED="1610314537081" MODIFIED="1610314537081" LINK="http://www.exaq.com/DNS/QR10/ScriptingReference.html#SetMousePostion"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://www.exaq.com/DNS/QR10/ScriptingReference.html#SetMousePostion">DNS Scripting Reference</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="files" FOLDED="true" ID="ID_1120275028" CREATED="1695785489991" MODIFIED="1695785492651">
<node TEXT="C:\Users\micha\AppData\Local\Nuance\NS16\Users\micha\current\soptions.ini" FOLDED="true" ID="ID_400709089" CREATED="1695785504084" MODIFIED="1695785504084">
<node TEXT="lower" FOLDED="true" ID="ID_1327674800" CREATED="1695785507348" MODIFIED="1695785545722">
<node TEXT="DwTimeOutIncomplete=80" ID="ID_1801475154" CREATED="1695785547041" MODIFIED="1695785547041"/>
<node TEXT="DwTimeOutComplete=50" ID="ID_1781630337" CREATED="1695785547041" MODIFIED="1695785547041"/>
</node>
</node>
</node>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_1958312684" CREATED="1625259873391" MODIFIED="1625259876115">
<node ID="ID_940444279" CREATED="1625259877889" MODIFIED="1625259877889" LINK="https://www.nuance.com/products/help/dragon/dragon-for-pc/enx/professionalgroup/main/Content/DragonBar/dragonbar_recognition_modes.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.nuance.com/products/help/dragon/dragon-for-pc/enx/professionalgroup/main/Content/DragonBar/dragonbar_recognition_modes.htm">Using recognition modes</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Settings" FOLDED="true" ID="ID_1451191032" CREATED="1610314495858" MODIFIED="1610314523343">
<node ID="ID_1849704061" CREATED="1610562143947" MODIFIED="1610562143947" LINK="https://www.nuance.com/products/help/dragon/dragon-for-pc/enx/professionalgroup/main/Content/Dictation/dictating_numbers.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.nuance.com/products/help/dragon/dragon-for-pc/enx/professionalgroup/main/Content/Dictation/dictating_numbers.htm">Dictating numbers</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_142770493" CREATED="1610314495869" MODIFIED="1610314495869" LINK="https://www.nuance.com/products/help/dragon/dragon-for-pc/enx/professionalgroup/main/Content/DialogBoxes/options/options_dialog_formatting_tab.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.nuance.com/products/help/dragon/dragon-for-pc/enx/professionalgroup/main/Content/DialogBoxes/options/options_dialog_formatting_tab.htm">Auto-Formatting dialog box</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1789805852" CREATED="1622219897712" MODIFIED="1622219897712" LINK="https://www.nuance.com/products/help/dragon/dragon-for-mac/enx/Content/Formatting/Capitalization.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.nuance.com/products/help/dragon/dragon-for-mac/enx/Content/Formatting/Capitalization.htm">Capitalization</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Caster" FOLDED="true" ID="ID_963944595" CREATED="1610316346504" MODIFIED="1610557849754" LINK="https://caster.readthedocs.io">
<node TEXT="Reference" FOLDED="true" ID="ID_1009139648" CREATED="1622220076298" MODIFIED="1622220085032">
<node ID="ID_840836627" CREATED="1610318585275" MODIFIED="1610318585275" LINK="https://github.com/dictation-toolbox/Caster/blob/master/CasterQuickReference.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/dictation-toolbox/Caster/blob/master/CasterQuickReference.pdf">Caster/CasterQuickReference.pdf at master · dictation-toolbox/Caster · GitHub</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_20909583" CREATED="1610318585278" MODIFIED="1610318585278" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/">Editing Starter Rules - Caster</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_130592688" CREATED="1610318585279" MODIFIED="1610318585279" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/">Editing Starter Rules - CasterEditing Starter Rules -</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_83504920" CREATED="1610318642364" MODIFIED="1610318642364" LINK="https://www.youtube.com/watch?v=UISjQBMmQ-I"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.youtube.com/watch?v=UISjQBMmQ-I">Alternate Mouse Movement Modes - YouTube</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_77852388" CREATED="1610318642365" MODIFIED="1610318642365" LINK="https://github.com/synkarius/caster"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/synkarius/caster">GitHub - synkarius/Caster: Dragonfly-Based Voice Programming ToolkitGitHub - synkarius/Caster: Dragonfly-Based Voice Programming Toolkit</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Dragonfly" FOLDED="true" ID="ID_1021404680" CREATED="1610314697697" MODIFIED="1622220184721">
<node TEXT="Reference" FOLDED="true" ID="ID_863996568" CREATED="1610490026026" MODIFIED="1610490032970">
<node TEXT="Application specific" ID="ID_1253376619" CREATED="1610573418097" MODIFIED="1610573424587"/>
<node ID="ID_1860242071" CREATED="1611253223779" MODIFIED="1611253223779" LINK="https://groups.google.com/g/dragonflyspeech"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://groups.google.com/g/dragonflyspeech">Dragonfly Speech Recognition - Google Groups</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1573404577" CREATED="1610574047037" MODIFIED="1610574047037" LINK="https://dragonfly2.readthedocs.io/en/latest/related_resources.html#command-modules"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/related_resources.html#command-modules">Related resources — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Rules" FOLDED="true" ID="ID_193710519" CREATED="1610558605383" MODIFIED="1610558608036">
<node ID="ID_471758154" CREATED="1610558616330" MODIFIED="1610558616330" LINK="https://caster.readthedocs.io/en/latest/readthedocs/meta/Dragonfly_Rules/Dragonfly_Rules/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/meta/Dragonfly_Rules/Dragonfly_Rules/">Dragonfly Rules - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1683288963" CREATED="1610643230657" MODIFIED="1610643230657" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Basic_Caster_Rules/Your_First_Rule/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Basic_Caster_Rules/Your_First_Rule/">Your First Rule - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_646424949" CREATED="1610643896887" MODIFIED="1610643896887" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Caster_Commands/Application_Commands_Quick_Reference/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Caster_Commands/Application_Commands_Quick_Reference/">Application Commands Reference - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1647221593" CREATED="1610895234344" MODIFIED="1610895234344" LINK="https://dragonfly2.readthedocs.io/en/latest/_modules/dragonfly/grammar/rule_compound.html?highlight=extras#"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/_modules/dragonfly/grammar/rule_compound.html?highlight=extras#">dragonfly.grammar.rule_compound — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
<node TEXT="Compound Rume Class, main class for defining rules" ID="ID_265412610" CREATED="1610895239037" MODIFIED="1610895259407"/>
</node>
</node>
<node FOLDED="true" ID="ID_1061145232" CREATED="1610490034541" MODIFIED="1610490034541" LINK="https://dragonfly2.readthedocs.io/en/latest/actions.html#basic-examples"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/actions.html#basic-examples">Actions sub-package — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
<node TEXT="Mouse" ID="ID_1166008497" CREATED="1610574191269" MODIFIED="1610574194878"/>
<node TEXT="Function" ID="ID_68026513" CREATED="1610574195549" MODIFIED="1610574198251"/>
<node TEXT="Key" ID="ID_247571149" CREATED="1610574199286" MODIFIED="1610574201717"/>
</node>
<node ID="ID_995205585" CREATED="1610489988832" MODIFIED="1610489988832" LINK="https://pypi.org/project/dragonfly/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pypi.org/project/dragonfly/">dragonfly · PyPI</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_826260277" CREATED="1610490279385" MODIFIED="1610490279385" LINK="https://handsfreecoding.org/2015/04/25/designing-dragonfly-grammars/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://handsfreecoding.org/2015/04/25/designing-dragonfly-grammars/">Designing Dragonfly grammars | Hands-Free Coding</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1029134280" CREATED="1610497219613" MODIFIED="1610497219613" LINK="https://stackoverflow.com/questions/3644129/how-do-you-recognize-speech-with-the-python-module-dragonfly"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/3644129/how-do-you-recognize-speech-with-the-python-module-dragonfly">How do you recognize speech with the Python module Dragonfly? - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_574743555" CREATED="1610381748639" MODIFIED="1610381748639" LINK="https://pypi.org/project/dragonfly2/#sr-engine-back-ends"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pypi.org/project/dragonfly2/#sr-engine-back-ends">dragonfly2 · PyPI</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Grammars/add-ons" FOLDED="true" ID="ID_1894114570" CREATED="1610724736128" MODIFIED="1610724742463">
<node ID="ID_868690251" CREATED="1610724759796" MODIFIED="1610724759796" LINK="https://dragonfluid.readthedocs.io/en/latest/Concepts.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfluid.readthedocs.io/en/latest/Concepts.html">Concepts — dragonfluid 0.9.0.a5 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1576093656" CREATED="1610315382657" MODIFIED="1610315382657"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 12.0pt; color: #5B9BD5">
      Vocola 2
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_727564776" CREATED="1610315382658" MODIFIED="1610315382658" LINK="http://vocola.net/v2/voicecmd.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v2/voicecmd.pdf">Microsoft Word - Scriptrf.doc (vocola.net)</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1845713145" CREATED="1597164440744" MODIFIED="1597164440744" LINK="http://vocola.net/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://vocola.net/">Vocola - A Voice Command Language</a>
  </body>
</html>
</richcontent>
<node TEXT="http://vocola.net/unofficial/extensions.html" ID="ID_67171945" CREATED="1601335805705" MODIFIED="1601335805705" LINK="http://vocola.net/unofficial/extensions.html"/>
</node>
<node ID="ID_601858415" CREATED="1610317270129" MODIFIED="1610317270129" LINK="http://vocola.net/v2/BuiltinFunctions.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v2/BuiltinFunctions.asp">Vocola 2 - Built-in Functions</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_942676050" CREATED="1610317277046" MODIFIED="1610317277046" LINK="http://vocola.net/v2/BuiltinFunctions.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v2/BuiltinFunctions.asp">Vocola 2 - Built-in Functions</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Installation" FOLDED="true" ID="ID_1829048106" CREATED="1610318258674" MODIFIED="1610318262343">
<node ID="ID_801143047" CREATED="1610314751796" MODIFIED="1610314751796" LINK="https://github.com/simianhacker/code-by-voice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/simianhacker/code-by-voice">GitHub - simianhacker/code-by-voice: All the support file for my code by voice setup using Dragon Naturally Speaking and DragonFly</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1741192570" CREATED="1610314751800" MODIFIED="1610314751800" LINK="https://dragonfly2.readthedocs.io/en/latest/faq.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://dragonfly2.readthedocs.io/en/latest/faq.html">Frequently Asked Questions (FAQ) — Dragonfly 0.28.1 documentation</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_535899538" CREATED="1610314697697" MODIFIED="1610314697697" LINK="https://qh.antenna.nl/unimacro/installation/installationexperimentalversionpython3.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://qh.antenna.nl/unimacro/installation/installationexperimentalversionpython3.html">installation experimental version python3</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_935965712" CREATED="1610314808082" MODIFIED="1610314808082" LINK="https://qh.antenna.nl/unimacro/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://qh.antenna.nl/unimacro/">unimacro</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_677308647" CREATED="1597163128970" MODIFIED="1597163128970" LINK="https://dragonfly2.readthedocs.io/en/latest/index.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/index.html">Dragonfly &#8212; Dragonfly 0.26.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_929780518" CREATED="1597242570761" MODIFIED="1597242570761" LINK="https://github.com/synkarius/caster"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/synkarius/caster">GitHub - synkarius/Caster: Dragonfly-Based Voice Programming Toolkit</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_702008952" CREATED="1610317968844" MODIFIED="1610317968844" LINK="https://github.com/dictation-toolbox/dragonfly"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/dictation-toolbox/dragonfly">dictation-toolbox/dragonfly: Speech recognition framework allowing powerful Python-based scripting and extension of Dragon NaturallySpeaking (DNS), Windows Speech Recognition (WSR), Kaldi and CMU Pocket Sphinx</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1138893919" CREATED="1610317968843" MODIFIED="1610317968843" LINK="https://kaldi-asr.org/doc/install.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://kaldi-asr.org/doc/install.html">Kaldi: Downloading and installing Kaldi</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Other Automation Apps" FOLDED="true" ID="ID_888667000" CREATED="1610318287978" MODIFIED="1610318312319">
<node ID="ID_1483949455" CREATED="1610318201208" MODIFIED="1610318201208" LINK="https://voicecomputer.com/dragon-add-on/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://voicecomputer.com/dragon-add-on/">VoiceComputer</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Troubleshooting" FOLDED="true" ID="ID_1567333220" CREATED="1619108372833" MODIFIED="1619108376299">
<node TEXT="Keys not registering" FOLDED="true" ID="ID_579474612" CREATED="1619108377200" MODIFIED="1619108388451">
<node TEXT="add pause (/10 ) after keystroke" ID="ID_1598714429" CREATED="1619108390353" MODIFIED="1619108414708"/>
<node TEXT="R(Key(&quot;%(modifier)s%(button_dictionary_1)s/10&quot;)," ID="ID_1550036620" CREATED="1619108428515" MODIFIED="1619108428515"/>
</node>
</node>
<node TEXT="Install" FOLDED="true" ID="ID_1430757764" CREATED="1618092591280" MODIFIED="1618092595020">
<node ID="ID_247306116" CREATED="1618091486224" MODIFIED="1618091514795" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Dragon_NaturallySpeaking/">Install:&nbsp;&nbsp;Dragon NaturallySpeaking - Caster</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Kaldi" FOLDED="true" ID="ID_1916923667" CREATED="1636232418442" MODIFIED="1636232472857">
<node TEXT="working install" FOLDED="true" ID="ID_1427249552" CREATED="1646978557284" MODIFIED="1646978568207">
<node TEXT="Install Python according to: Kaldi - Caster" FOLDED="true" ID="ID_1190331502" CREATED="1684987362171" MODIFIED="1684987362171">
<node ID="ID_963845373" CREATED="1684988776495" MODIFIED="1684988776495" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Kaldi_Windows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Kaldi_Windows/">Kaldi - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="1. Python" FOLDED="true" ID="ID_1875166482" CREATED="1684988787680" MODIFIED="1684988794394">
<node TEXT="Python 3.8.10 x 64" ID="ID_1484659963" CREATED="1636419328704" MODIFIED="1636419341221"/>
<node TEXT="CMD" FOLDED="true" ID="ID_696998987" CREATED="1684987362171" MODIFIED="1684987362171">
<node TEXT="python -m pip install --upgrade pip" ID="ID_851273433" CREATED="1684987362179" MODIFIED="1684987362179"/>
<node TEXT="pip install wheel" ID="ID_347260041" CREATED="1684987362179" MODIFIED="1685161665355"/>
</node>
<node TEXT="edit requirements" FOLDED="true" ID="ID_1281922046" CREATED="1685167488776" MODIFIED="1685167502919">
<node TEXT="tomlkit==0.5.11" ID="ID_785452114" CREATED="1685167504237" MODIFIED="1685167504237"/>
</node>
<node TEXT="KALDI ONLY" FOLDED="true" ID="ID_1439964975" CREATED="1684987362179" MODIFIED="1684987362179">
<node TEXT="Follow directions here:" FOLDED="true" ID="ID_646983405" CREATED="1684987362180" MODIFIED="1684987487597">
<node FOLDED="true" ID="ID_105931907" CREATED="1684987471264" MODIFIED="1684987471264" LINK="https://github.com/daanzu/kaldi-active-grammar"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/daanzu/kaldi-active-grammar">GitHub - daanzu/kaldi-active-grammar: Python Kaldi speech recognition with grammars that can be set active/inactive dynamically at decode-time</a>
  </body>
</html>
</richcontent>
<node TEXT="VC install if errors" ID="ID_263261500" CREATED="1689203720021" MODIFIED="1689203735234"/>
<node TEXT="Download model" FOLDED="true" ID="ID_626153827" CREATED="1684987851601" MODIFIED="1684987858079">
<node TEXT="larger = more accurate" ID="ID_1865905671" CREATED="1689716434206" MODIFIED="1689716440456"/>
<node TEXT="medium" FOLDED="true" ID="ID_451355303" CREATED="1689203814158" MODIFIED="1689203816960">
<node TEXT="high?" ID="ID_951835538" CREATED="1689716425334" MODIFIED="1689716428848"/>
</node>
<node TEXT="Extact model to C:/" ID="ID_722663804" CREATED="1684988843480" MODIFIED="1684989012011"/>
</node>
<node TEXT="CMD" FOLDED="true" ID="ID_1960647516" CREATED="1684987890538" MODIFIED="1684987897540">
<node TEXT="pip install dragonfly2[kaldi]" ID="ID_563056376" CREATED="1684987939164" MODIFIED="1684987945819"/>
<node TEXT="pip install kaldi-active-grammar[g2p_en]" ID="ID_721950537" CREATED="1684988008361" MODIFIED="1684988018484"/>
<node TEXT="python -m pip install pillow tomlkit future mock appdirs scandir pyvda==0.0.8&apos;" ID="ID_1776589374" CREATED="1684989831103" MODIFIED="1684989831103"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Edit Install_Caster_DNS-WSR.bat" FOLDED="true" ID="ID_777355488" CREATED="1684987362180" MODIFIED="1684987362180">
<node TEXT="Change Python to -64" ID="ID_963502461" CREATED="1684987362180" MODIFIED="1684987362180"/>
<node TEXT="Run Install_Caster_DNS-WSR.bat" ID="ID_451768936" CREATED="1684987362180" MODIFIED="1684987362180"/>
<node TEXT="Transfer WSR" ID="ID_302538735" CREATED="1684987362180" MODIFIED="1684987362180"/>
<node TEXT="add" FOLDED="true" ID="ID_79146458" CREATED="1689202487618" MODIFIED="1689202489108">
<node ID="ID_782741956" CREATED="1689202490369" MODIFIED="1689202490369"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: rgb(230, 237, 243); font-family: ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace; font-size: 13.6px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: break-spaces; display: inline !important; float: none"><font color="rgb(230, 237, 243)" face="ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace" size="13.6px">pip install 'kaldi-active-grammar[g2p_en]'</font></span>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="edit &quot;Run_Caster_Kaldi.bat" FOLDED="true" ID="ID_1869185898" CREATED="1637690525463" MODIFIED="1637690565602">
<node TEXT="Configure Engine" FOLDED="true" ID="ID_1348801127" CREATED="1640812593247" MODIFIED="1640812861184">
<node TEXT="reference" FOLDED="true" ID="ID_658228341" CREATED="1640812824516" MODIFIED="1640812831361">
<node ID="ID_561881605" CREATED="1640812600544" MODIFIED="1640812600544" LINK="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#engine-configuration"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#engine-configuration">Kaldi engine back-end — Dragonfly 0.34.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1178059059" CREATED="1640812821630" MODIFIED="1640812821630" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Kaldi_Windows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Kaldi_Windows/">Kaldi - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1307359165" CREATED="1641162439692" MODIFIED="1641162439692" LINK="https://dragonfly2.readthedocs.io/en/latest/cli.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/cli.html">Command-line Interface (CLI) — Dragonfly 0.34.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="edits" FOLDED="true" ID="ID_1755444599" CREATED="1641162558195" MODIFIED="1641162567533">
<node TEXT="removed" FOLDED="true" ID="ID_303605033" CREATED="1641162600555" MODIFIED="1641162602725">
<node TEXT="--no-recobs-messages" FOLDED="true" ID="ID_841707445" CREATED="1641162604043" MODIFIED="1641162604043">
<node TEXT="shows what was recognized" ID="ID_269266206" CREATED="1641162817773" MODIFIED="1641162851961"/>
</node>
</node>
<node TEXT="added" FOLDED="true" ID="ID_386617373" CREATED="1641162608797" MODIFIED="1641162611183">
<node TEXT="auto_add_to_user_lexicon=True" ID="ID_469089842" CREATED="1640812720252" MODIFIED="1641160032772"/>
<node TEXT="expected_error_rate_threshold=0" ID="ID_637181569" CREATED="1641160032772" MODIFIED="1688670473104"/>
<node TEXT="vad_aggressiveness=3" ID="ID_45833858" CREATED="1687370748595" MODIFIED="1688670484198"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="set shortcut for run Kaldi" FOLDED="true" ID="ID_542177779" CREATED="1686370729326" MODIFIED="1686370749144">
<node TEXT="AltCtrl+K" ID="ID_962712039" CREATED="1686370750079" MODIFIED="1686370759264"/>
</node>
<node TEXT="Import local caster folder" ID="ID_1229014725" CREATED="1689023284576" MODIFIED="1689023295774"/>
<node TEXT="Or" FOLDED="true" ID="ID_422637551" CREATED="1689023299414" MODIFIED="1689023301472">
<node TEXT="setup file opening" FOLDED="true" ID="ID_605929741" CREATED="1686008236975" MODIFIED="1686008242827">
<node TEXT="OneCommander" FOLDED="true" ID="ID_1573085974" CREATED="1686008271064" MODIFIED="1686008277474">
<node TEXT="_explorer_path = str(Path(&quot;C:\\Program Files\\OneCommander\\OneCommander.exe&quot;))" ID="ID_1040738839" CREATED="1686008292344" MODIFIED="1686008294626"/>
</node>
<node TEXT="bringme.py" ID="ID_703804169" CREATED="1686008243976" MODIFIED="1686008259410"/>
</node>
<node TEXT="Edit Settings" FOLDED="true" ID="ID_1764490213" CREATED="1685937899433" MODIFIED="1685937903180">
<node TEXT="history_playback_delay_secs = 0.5" FOLDED="true" ID="ID_513806413" CREATED="1687477919194" MODIFIED="1687477919194">
<node TEXT="was 1.0" ID="ID_442236472" CREATED="1687477921500" MODIFIED="1687477924664"/>
</node>
<node TEXT="atom_palette_wait = 0" FOLDED="true" ID="ID_568182947" CREATED="1687477322924" MODIFIED="1687477327288">
<node TEXT="was 30" ID="ID_1683189444" CREATED="1687477927204" MODIFIED="1687477930007"/>
</node>
<node TEXT="disable sleep" ID="ID_1386431833" CREATED="1685937904057" MODIFIED="1685937915035"/>
<node TEXT="keypress_wait = 0" FOLDED="true" ID="ID_976227034" CREATED="1687477189129" MODIFIED="1687477189129">
<node TEXT="was 50" ID="ID_1937634031" CREATED="1687477933572" MODIFIED="1687477936447"/>
</node>
</node>
<node TEXT="Edit Rules" FOLDED="true" ID="ID_839513786" CREATED="1687028632284" MODIFIED="1687028635829">
<node TEXT="rules.toml" FOLDED="true" ID="ID_224514830" CREATED="1687028731860" MODIFIED="1687028895449" LINK="file:/C:/Users/micha/AppData/Local/caster/settings/rules.toml">
<node TEXT="put dictation and Again rule in the beginning" FOLDED="true" ID="ID_1111925368" CREATED="1687028712802" MODIFIED="1687475557827">
<node TEXT="_enabled_ordered = [&quot;DictationRule&quot;, &quot;Again&quot;" ID="ID_1536320732" CREATED="1687028927442" MODIFIED="1687475541178"/>
</node>
</node>
<node TEXT="C:\Users\micha\AppData\Local\caster\settings\rules.toml" FOLDED="true" POSITION="bottom_or_right" ID="ID_1057990905" CREATED="1685937917760" MODIFIED="1685937930731">
<node TEXT="move &quot;Again&quot; to internal" ID="ID_1766539237" CREATED="1685937933065" MODIFIED="1685937952075"/>
</node>
</node>
</node>
<node TEXT="Edit dictionary vocabulary" FOLDED="true" ID="ID_683680555" CREATED="1641157818689" MODIFIED="1686768690588">
<node TEXT="change words" FOLDED="true" ID="ID_1974647533" CREATED="1687541179445" MODIFIED="1687541183623">
<node TEXT="edit words.txt" ID="ID_132247612" CREATED="1687541183836" MODIFIED="1687541195503"/>
</node>
<node TEXT="change recognition" FOLDED="true" ID="ID_30575133" CREATED="1687541196989" MODIFIED="1687541205583">
<node TEXT="delete" FOLDED="true" ID="ID_1245211436" CREATED="1687541694389" MODIFIED="1687541698583">
<node TEXT="words.txt" ID="ID_593260325" CREATED="1687541699445" MODIFIED="1687541702806"/>
</node>
<node TEXT="edit" FOLDED="true" ID="ID_1535301331" CREATED="1687541707285" MODIFIED="1687541708351">
<node TEXT="C:\kaldi_model_daanzu_20211030-smalllm\lexiconp_disambig.base.txt" ID="ID_1543875069" CREATED="1687363753191" MODIFIED="1687363753191"/>
<node TEXT="words.base.txt" ID="ID_1646828263" CREATED="1687541719853" MODIFIED="1687541732966"/>
</node>
<node TEXT="C:\kaldi_model_daanzu_20211030-smalllm\lexiconp_disambig.base.txt" FOLDED="true" ID="ID_502127135" CREATED="1687363753191" MODIFIED="1687363753191">
<node TEXT="decrease weight" ID="ID_518432592" CREATED="1687363755622" MODIFIED="1687541229408"/>
</node>
</node>
<node TEXT="user dictionary" FOLDED="true" ID="ID_592164404" CREATED="1641158263132" MODIFIED="1641158269924">
<node TEXT="C:\Users\mandm\Documents\Caster-kaldi\kaldi_model\user_lexicon.txt" ID="ID_1122279096" CREATED="1641157916110" MODIFIED="1641157916110"/>
</node>
<node TEXT="Eliminate Word From Vocabulary" ID="ID_1523512122" CREATED="1687362901350" MODIFIED="1687362918113"/>
<node TEXT="main dictionary" FOLDED="true" ID="ID_420654536" CREATED="1641158243420" MODIFIED="1641158252064">
<node TEXT="C:\kaldi_model\lexiconp_disambig.txt" ID="ID_274574432" CREATED="1689276564301" MODIFIED="1689276564301"/>
<node TEXT="C:\kaldi_model\lexiconp_disambig.base.txt" ID="ID_1166367300" CREATED="1689276557915" MODIFIED="1689276557915"/>
<node TEXT="lexicon.txt" ID="ID_403743217" CREATED="1686769017478" MODIFIED="1686769023007"/>
<node TEXT="lexiconp.txt" ID="ID_161121222" CREATED="1641158235530" MODIFIED="1686769033086"/>
</node>
<node ID="ID_1988886445" CREATED="1646978526488" MODIFIED="1646978526488"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://">Kaldi engine back-end — Dragonfly 0.33.0 documentation</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="My previous install" FOLDED="true" ID="ID_1745088374" CREATED="1636418878301" MODIFIED="1646978489895">
<node TEXT="Python 3.8.10 x 64" FOLDED="true" ID="ID_1783009864" CREATED="1636419328704" MODIFIED="1636419341221">
<node TEXT="pip install wheels" ID="ID_1193488278" CREATED="1636419488941" MODIFIED="1636419494923"/>
</node>
<node TEXT="Copied caster over" FOLDED="true" ID="ID_1431845653" CREATED="1636419358613" MODIFIED="1636419365454">
<node TEXT="changed" ID="ID_1015024025" CREATED="1636419367624" MODIFIED="1636419487115"/>
</node>
<node TEXT="edit &quot;Run_Caster_Kaldi.bat" FOLDED="true" ID="ID_912509127" CREATED="1637690525463" MODIFIED="1637690565602">
<node TEXT="auto_add_to_user_lexicon=True" ID="ID_1077166335" CREATED="1637690578223" MODIFIED="1637690578223"/>
</node>
<node TEXT="Model" FOLDED="true" ID="ID_896007984" CREATED="1636264322923" MODIFIED="1636264326962">
<node ID="ID_1670436793" CREATED="1636233386835" MODIFIED="1636233386835" LINK="https://github.com/daanzu/kaldi-active-grammar"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/daanzu/kaldi-active-grammar">GitHub - daanzu/kaldi-active-grammar: Python Kaldi speech recognition with grammars that can be set active/inactive dynamically at decode-time</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Training" FOLDED="true" ID="ID_1831227939" CREATED="1649778853017" MODIFIED="1649778855984">
<node ID="ID_110617093" CREATED="1649778857508" MODIFIED="1649778857508" LINK="https://github.com/daanzu/kaldi_ag_training"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/daanzu/kaldi_ag_training">daanzu/kaldi_ag_training: Docker image and scripts for training finetuned or completely personal Kaldi speech models. Particularly for use with kaldi-active-grammar.</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_642094660" CREATED="1637689652709" MODIFIED="1637689656199">
<node ID="ID_128807979" CREATED="1636232475478" MODIFIED="1636232475478" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Kaldi_Windows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Windows/Kaldi_Windows/">Kaldi - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1409927137" CREATED="1636265485659" MODIFIED="1636265485659" LINK="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#engine-configuration"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#engine-configuration">Kaldi engine back-end — Dragonfly 0.33.0 documentation</a>
  </body>
</html>
</richcontent>
<node TEXT="add words to lexicon" FOLDED="true" ID="ID_1989399906" CREATED="1637689927970" MODIFIED="1637689956047">
<node ID="ID_1675215555" CREATED="1637689961366" MODIFIED="1637689961366" LINK="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#cross-platform"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#cross-platform">Kaldi engine back-end — Dragonfly 0.33.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node ID="ID_1998528078" CREATED="1636233323029" MODIFIED="1636233323029" LINK="https://voxhub.io/kag"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://voxhub.io/kag">VoxHub.io - kaldi-active-grammar - Flexible Coding by Voice</a>
  </body>
</html>
</richcontent>
</node>
<node POSITION="bottom_or_right" ID="ID_1226008273" CREATED="1687377192896" MODIFIED="1687377192896" LINK="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#engine-configuration"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/kaldi_engine.html#engine-configuration">21. Kaldi engine back-end — Dragonfly 1.0.0-rc1 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="WSR" FOLDED="true" ID="ID_798849189" CREATED="1610317831631" MODIFIED="1610317833415">
<node TEXT="not accurate" ID="ID_1884657712" CREATED="1687370473490" MODIFIED="1687370478604"/>
<node ID="ID_781599588" CREATED="1626283119879" MODIFIED="1626283119879" LINK="https://fosspost.org/open-source-speech-recognition/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://fosspost.org/open-source-speech-recognition/">10 Greatest Open Source Speech Recognition Systems [2021]</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Vosk" FOLDED="true" ID="ID_128264308" CREATED="1626826133533" MODIFIED="1626826136778">
<node ID="ID_1911963857" CREATED="1626826256242" MODIFIED="1626826256242" LINK="https://github.com/alphacep/vosk-api/tree/master/python"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/alphacep/vosk-api/tree/master/python">vosk-api/python at master · alphacep/vosk-api</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_153810898" CREATED="1626827971381" MODIFIED="1626827971381" LINK="https://www.youtube.com/watch?v=YereI6Gn3bM"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.youtube.com/watch?v=YereI6Gn3bM">(26) I Built a Personal Speech Recognition System for my AI Assistant - YouTube</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Picovoice Leopard" FOLDED="true" ID="ID_1880654702" CREATED="1627084224148" MODIFIED="1627084243182">
<node ID="ID_31667523" CREATED="1627084244955" MODIFIED="1627084244955" LINK="https://github.com/Picovoice/leopard"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Picovoice/leopard">GitHub - Picovoice/leopard: On-device speech-to-text engine powered by deep learning</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Unimacro and &quot;raw&quot; user defined grammars, written in the way Joel Gould originally presented Natlink to us, is even more flexible, as all the possibilities that the glue between Dragon and the python grammars , natlink.pyd, are exploited." FOLDED="true" ID="ID_921029621" CREATED="1626284936515" MODIFIED="1626284936515">
<node ID="ID_73273396" CREATED="1626284946080" MODIFIED="1626284946080" LINK="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34641"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34641">KnowBrainer Speech Recognition Forums - Merits of Vocola vs Talon vs Caster vs Serenade etc</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Lepord" FOLDED="true" ID="ID_1739802204" CREATED="1636434264795" MODIFIED="1636434290665">
<node ID="ID_1268989953" CREATED="1636434297579" MODIFIED="1636434297579" LINK="https://github.com/Picovoice/leopard"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Picovoice/leopard">GitHub - Picovoice/leopard: On-device speech-to-text engine powered by deep learning</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Vocola 3" FOLDED="true" ID="ID_1731602817" CREATED="1610318413183" MODIFIED="1610318416941">
<node ID="ID_516766978" CREATED="1610318404465" MODIFIED="1610318404465" LINK="http://vocola.net/v3/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v3/">Vocola 3 - Vocola 3</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_483588036" CREATED="1610318404465" MODIFIED="1610318404465" LINK="http://vocola.net/v3/KeystrokeSyntax.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v3/KeystrokeSyntax.asp">Vocola 3 - Keystroke Syntax</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1075594790" CREATED="1610318404468" MODIFIED="1610318404468" LINK="http://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=18861"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=18861">KnowBrainer Speech Recognition Forums - Vocola 3 Windows 8</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Reference" FOLDED="true" ID="ID_507187834" CREATED="1610318334169" MODIFIED="1610318341998">
<node FOLDED="true" ID="ID_1020905779" CREATED="1610318404479" MODIFIED="1610318454348"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      &nbsp;Commands
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1733721772" CREATED="1610318404478" MODIFIED="1610318404478"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      Start Spelling
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1824424921" CREATED="1610318404479" MODIFIED="1610318404479"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      Start Typing
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1774929753" CREATED="1610318404480" MODIFIED="1610318404480"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      Settings:
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1121894628" CREATED="1610318404481" MODIFIED="1610318404481"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      C:\Windows\Speech\Engines\SR\en-US
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1681997812" CREATED="1610318404483" MODIFIED="1610318404483" LINK="https://documentation.help/Microsoft-Speech-Platform-SDK-11/SR_Properties_White_Paper.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://documentation.help/Microsoft-Speech-Platform-SDK-11/SR_Properties_White_Paper.htm">Speech Recognition Properties - Microsoft Speech Platform (Server) - Microsoft Speech Platform SDK 11 Documentation</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1424078619" CREATED="1610318404484" MODIFIED="1610318404484" LINK="https://docs.microsoft.com/en-us/archive/blogs/robch/windows-speech-recognition-in-vista-every-single-thing-wsr-is-listening-for"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://docs.microsoft.com/en-us/archive/blogs/robch/windows-speech-recognition-in-vista-every-single-thing-wsr-is-listening-for">Windows Speech Recognition in Vista: Every single thing WSR is quote five listening for | Microsoft Docs</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_186364290" CREATED="1610318404485" MODIFIED="1610318404485" LINK="https://support.microsoft.com/en-au/help/12427/windows-speech-recognition-commands"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://support.microsoft.com/en-au/help/12427/windows-speech-recognition-commands">Windows Speech Recognition commands - Windows Help</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_990498369" CREATED="1636434631183" MODIFIED="1636434631183" LINK="https://github.com/speechbrain/speechbrain"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/speechbrain/speechbrain">GitHub - speechbrain/speechbrain: A PyTorch-based Speech Toolkit</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1957338467" CREATED="1636434688682" MODIFIED="1636434688682" LINK="https://github.com/topics/speech-recognition"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/topics/speech-recognition">speech-recognition · GitHub Topics · GitHub</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Other Recognition Engines" FOLDED="true" ID="ID_1931031299" CREATED="1610317789871" MODIFIED="1640810628737">
<node TEXT="research" FOLDED="true" ID="ID_229696095" CREATED="1637707217097" MODIFIED="1637707219920">
<node ID="ID_1247261596" CREATED="1637707221278" MODIFIED="1637707221278" LINK="https://softwarerecs.stackexchange.com/questions/74532/speech-recognition-free-software-and-complete-privacy"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://softwarerecs.stackexchange.com/questions/74532/speech-recognition-free-software-and-complete-privacy">gratis - Speech Recognition: Free Software and Complete Privacy - Software Recommendations Stack Exchange</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="comparison" FOLDED="true" ID="ID_125967180" CREATED="1627084320826" MODIFIED="1627084327567">
<node ID="ID_4629795" CREATED="1627084329003" MODIFIED="1627084329003" LINK="https://github.com/Picovoice/speech-to-text-benchmark#results"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Picovoice/speech-to-text-benchmark#results">GitHub - Picovoice/speech-to-text-benchmark: speech to text benchmark framework</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Supporting Apps" FOLDED="true" ID="ID_1510681113" CREATED="1644299180227" MODIFIED="1644299234457">
<node TEXT="Sikuli" ID="ID_1221064412" CREATED="1644300698310" MODIFIED="1644300702769"/>
<node TEXT="Setup" FOLDED="true" ID="ID_502304522" CREATED="1644300691449" MODIFIED="1644300696913">
<node FOLDED="true" ID="ID_763043827" CREATED="1644299223298" MODIFIED="1644299223298" LINK="http://sikulix.com/quickstart/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://sikulix.com/quickstart/">SikuliX - QUICKSTART</a>
  </body>
</html>
</richcontent>
<node TEXT="download sikuli setup.jar" ID="ID_186474654" CREATED="1644299954936" MODIFIED="1644299972177"/>
<node TEXT="set environment variables" FOLDED="true" ID="ID_225416675" CREATED="1644299972751" MODIFIED="1644299980101">
<node TEXT="JAVA_HOME" FOLDED="true" ID="ID_860886595" CREATED="1644299981653" MODIFIED="1644299991734">
<node TEXT="path to java jre" ID="ID_1757204486" CREATED="1644299992036" MODIFIED="1644299998782"/>
<node TEXT="shorten PROGRA~1 fo 64 bit" ID="ID_1954931197" CREATED="1644300001221" MODIFIED="1644300039240"/>
</node>
<node TEXT="SIKULI_HOME" ID="ID_676719163" CREATED="1644300041600" MODIFIED="1644300074346"/>
</node>
<node TEXT="run setup" FOLDED="true" ID="ID_317690893" CREATED="1644300122997" MODIFIED="1644300142967">
<node TEXT="pack 1, run" FOLDED="true" ID="ID_511149811" CREATED="1644300144102" MODIFIED="1644300150125">
<node TEXT="ide" ID="ID_229646716" CREATED="1644300224671" MODIFIED="1644300226455"/>
</node>
<node TEXT="then pack 2" FOLDED="true" ID="ID_1109797344" CREATED="1644300150673" MODIFIED="1644300165923">
<node TEXT="sikuli script" ID="ID_301764157" CREATED="1644300215272" MODIFIED="1644300222537"/>
</node>
</node>
<node TEXT="set path in settings.json" ID="ID_290918109" CREATED="1644300271476" MODIFIED="1644300288171"/>
<node ID="ID_249610100" CREATED="1644300632942" MODIFIED="1644300632942" LINK="https://www.youtube.com/watch?v=RFdsD2OgDzk"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.youtube.com/watch?v=RFdsD2OgDzk">Sikuli Commands by Voice - YouTube</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Edit Caster User Settings" FOLDED="true" ID="ID_636985091" CREATED="1695785069616" MODIFIED="1695785572475">
<node TEXT="C:\Users\micha\AppData\Local\bk_caster\settings\settings.toml" FOLDED="true" ID="ID_1680031204" CREATED="1695785052859" MODIFIED="1695785052859">
<node TEXT="lower delays" ID="ID_858176129" CREATED="1695785077133" MODIFIED="1695785080612"/>
</node>
</node>
<node TEXT="Configure Dragon" FOLDED="true" ID="ID_1400458580" CREATED="1696112251545" MODIFIED="1696112256737">
<node TEXT="Autoformatting Options" FOLDED="true" ID="ID_651617562" CREATED="1710260375533" MODIFIED="1710260400024">
<node TEXT="everything off except" ID="ID_287070822" CREATED="1710260409846" MODIFIED="1710260413434"/>
<node TEXT="Numbers" ID="ID_845485283" CREATED="1710260414155" MODIFIED="1710260418935"/>
<node TEXT="Allow pauses in formatted phrases" ID="ID_1631084503" CREATED="1710260419389" MODIFIED="1710260435888"/>
</node>
<node TEXT="Disable everything that you can" ID="ID_1405321552" CREATED="1696179902985" MODIFIED="1696179922217"/>
<node TEXT="Disable auto adjust microphone volume" ID="ID_1494829819" CREATED="1696179420989" MODIFIED="1696179625020"/>
<node ID="ID_1500456779" CREATED="1696112137999" MODIFIED="1696112137999" LINK="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=4&amp;threadid=37312"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=4&amp;threadid=37312">KnowBrainer Speech Recognition Forums - Dragon 16 (running on a sick fast machine) keeps freezing</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Launching Apps" FOLDED="true" ID="ID_1496217787" CREATED="1695421993373" MODIFIED="1695422002170">
<node TEXT="through taskbar" FOLDED="true" ID="ID_1430288754" CREATED="1695422324159" MODIFIED="1695422329824">
<node TEXT="pros" FOLDED="true" ID="ID_864798082" CREATED="1695422407661" MODIFIED="1695422411981">
<node TEXT="can see what is open" ID="ID_1160115649" CREATED="1695422412713" MODIFIED="1695422417277"/>
</node>
<node TEXT="cons" FOLDED="true" ID="ID_814259838" CREATED="1695422360431" MODIFIED="1695422362752">
<node TEXT="free plane doesn&apos;t pin to taskbar" ID="ID_1524738298" CREATED="1695422363754" MODIFIED="1695422372896"/>
<node TEXT="requires taskbar to be visible" ID="ID_336873622" CREATED="1695422375159" MODIFIED="1695422380690"/>
</node>
</node>
<node TEXT="through bring me" FOLDED="true" ID="ID_150572428" CREATED="1695422331146" MODIFIED="1695422336452">
<node TEXT="cons" FOLDED="true" ID="ID_75475344" CREATED="1695422383824" MODIFIED="1695422388871">
<node TEXT="have to add each app" ID="ID_718352704" CREATED="1695422389612" MODIFIED="1695422396795"/>
</node>
</node>
</node>
<node TEXT="Edge" FOLDED="true" ID="ID_1829119413" CREATED="1685167796320" MODIFIED="1685167799121">
<node TEXT="extension" FOLDED="true" ID="ID_613730449" CREATED="1685167806096" MODIFIED="1685167812049">
<node TEXT="Click by Voice" FOLDED="true" ID="ID_1108161636" CREATED="1685167812752" MODIFIED="1685167816449">
<node TEXT="short cut: cs-n" ID="ID_1571603589" CREATED="1685209452618" MODIFIED="1685210284070"/>
</node>
<node TEXT="others" FOLDED="true" ID="ID_1766402798" CREATED="1695790388407" MODIFIED="1695790391017">
<node ID="ID_361434872" CREATED="1695790382799" MODIFIED="1695790382799" LINK="https://microsoftedge.microsoft.com/addons/detail/surfingkeys/kgnghhfkloifoabeaobjkgagcecbnppg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://microsoftedge.microsoft.com/addons/detail/surfingkeys/kgnghhfkloifoabeaobjkgagcecbnppg">Surfingkeys - Microsoft Edge Addons</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Reference" FOLDED="true" ID="ID_749183666" CREATED="1622220076298" MODIFIED="1622220085032">
<node FOLDED="true" ID="ID_805245176" CREATED="1610318019658" MODIFIED="1610318019658" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Dragon_NaturallySpeaking/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://caster.readthedocs.io/en/latest/readthedocs/Installation/Dragon_NaturallySpeaking/">Dragon NaturallySpeaking - Caster</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1874346791" CREATED="1623781093649" MODIFIED="1623781093649" LINK="https://wp.sbcounty.gov/workforce/wp-content/uploads/sites/5/2021/02/Dragon_Command_Cheat_Sheet.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://wp.sbcounty.gov/workforce/wp-content/uploads/sites/5/2021/02/Dragon_Command_Cheat_Sheet.pdf">Dragon Professional Group Cheat Sheet</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1569518016" CREATED="1610318585275" MODIFIED="1610318585275" LINK="https://github.com/dictation-toolbox/Caster/blob/master/CasterQuickReference.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/dictation-toolbox/Caster/blob/master/CasterQuickReference.pdf">Caster/CasterQuickReference.pdf at master · dictation-toolbox/Caster · GitHub</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_423319496" CREATED="1610318585278" MODIFIED="1610318585278" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/">Editing Starter Rules - Caster</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_112706849" CREATED="1610318585279" MODIFIED="1610318585279" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://caster.readthedocs.io/en/latest/readthedocs/Customize_Caster/Customizing_Starter_Rules/">Editing Starter Rules - CasterEditing Starter Rules -</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_16325183" CREATED="1610318642364" MODIFIED="1610318642364" LINK="https://www.youtube.com/watch?v=UISjQBMmQ-I"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.youtube.com/watch?v=UISjQBMmQ-I">Alternate Mouse Movement Modes - YouTube</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_926319863" CREATED="1610318642365" MODIFIED="1610318642365" LINK="https://github.com/synkarius/caster"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/synkarius/caster">GitHub - synkarius/Caster: Dragonfly-Based Voice Programming ToolkitGitHub - synkarius/Caster: Dragonfly-Based Voice Programming Toolkit</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Context Stack" FOLDED="true" ID="ID_1473518929" CREATED="1624060030525" MODIFIED="1624060042546">
<node TEXT="object that stores dragonfly commands" ID="ID_1287761799" CREATED="1624060057750" MODIFIED="1624060065777"/>
<node TEXT="decide how to execute them" ID="ID_1468417779" CREATED="1624060066782" MODIFIED="1624060071442"/>
<node TEXT="enables new features" ID="ID_1405095589" CREATED="1624060084795" MODIFIED="1624060088323"/>
<node ID="ID_336875811" CREATED="1624060051301" MODIFIED="1624060051301" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Advanced_Caster_Rules/ContextStack/#"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Advanced_Caster_Rules/ContextStack/#">Context Stack - Caster</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="grammar" FOLDED="true" ID="ID_255433156" CREATED="1623449026216" MODIFIED="1623449029046">
<node TEXT="collection of rules that are related to each other" ID="ID_476095882" CREATED="1623449033023" MODIFIED="1623449038338"/>
<node TEXT="Rules" FOLDED="true" ID="ID_409089517" CREATED="1623449050819" MODIFIED="1623449121477">
<node TEXT="voice commands or parts of voice commands" ID="ID_1566685445" CREATED="1623449129203" MODIFIED="1623449148646"/>
<node TEXT="Each rule has a single root element" FOLDED="true" ID="ID_1632013429" CREATED="1623449151157" MODIFIED="1623449170734">
<node TEXT="MappingRule" ID="ID_1377415945" CREATED="1623449480253" MODIFIED="1623449492554"/>
<node TEXT="MergeRule" FOLDED="true" ID="ID_1977696008" CREATED="1623449493967" MODIFIED="1623449498163">
<node ID="ID_1342888710" CREATED="1623449716674" MODIFIED="1623449716674" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Advanced_Caster_Rules/Advanced_Rules/#mergerules-vs-mappingrules"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Advanced_Caster_Rules/Advanced_Rules/#mergerules-vs-mappingrules">Advanced Rules - Caster</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="SelfModifyingRule" ID="ID_1456648513" CREATED="1623449502785" MODIFIED="1623449516701"/>
</node>
</node>
</node>
<node TEXT="Dragonfly" FOLDED="true" ID="ID_727598395" CREATED="1610314697697" MODIFIED="1622220184721">
<node TEXT="Reference" FOLDED="true" ID="ID_1090953069" CREATED="1610490026026" MODIFIED="1610490032970">
<node TEXT="Application specific" ID="ID_875026805" CREATED="1610573418097" MODIFIED="1610573424587"/>
<node ID="ID_1238804709" CREATED="1611253223779" MODIFIED="1611253223779" LINK="https://groups.google.com/g/dragonflyspeech"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://groups.google.com/g/dragonflyspeech">Dragonfly Speech Recognition - Google Groups</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_686915869" CREATED="1610574047037" MODIFIED="1610574047037" LINK="https://dragonfly2.readthedocs.io/en/latest/related_resources.html#command-modules"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/related_resources.html#command-modules">Related resources — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Rules" FOLDED="true" ID="ID_1675655108" CREATED="1610558605383" MODIFIED="1610558608036">
<node ID="ID_1693145381" CREATED="1610558616330" MODIFIED="1610558616330" LINK="https://caster.readthedocs.io/en/latest/readthedocs/meta/Dragonfly_Rules/Dragonfly_Rules/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/meta/Dragonfly_Rules/Dragonfly_Rules/">Dragonfly Rules - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1862187639" CREATED="1610643230657" MODIFIED="1610643230657" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Basic_Caster_Rules/Your_First_Rule/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Rule_Construction/Basic_Caster_Rules/Your_First_Rule/">Your First Rule - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1225990821" CREATED="1610643896887" MODIFIED="1610643896887" LINK="https://caster.readthedocs.io/en/latest/readthedocs/Caster_Commands/Application_Commands_Quick_Reference/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://caster.readthedocs.io/en/latest/readthedocs/Caster_Commands/Application_Commands_Quick_Reference/">Application Commands Reference - Caster</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1198294448" CREATED="1610895234344" MODIFIED="1610895234344" LINK="https://dragonfly2.readthedocs.io/en/latest/_modules/dragonfly/grammar/rule_compound.html?highlight=extras#"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/_modules/dragonfly/grammar/rule_compound.html?highlight=extras#">dragonfly.grammar.rule_compound — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
<node TEXT="Compound Rume Class, main class for defining rules" ID="ID_1362659736" CREATED="1610895239037" MODIFIED="1610895259407"/>
</node>
</node>
<node FOLDED="true" ID="ID_221334827" CREATED="1610490034541" MODIFIED="1610490034541" LINK="https://dragonfly2.readthedocs.io/en/latest/actions.html#basic-examples"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/actions.html#basic-examples">Actions sub-package — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
<node TEXT="Mouse" ID="ID_328594580" CREATED="1610574191269" MODIFIED="1610574194878"/>
<node TEXT="Function" ID="ID_1387476085" CREATED="1610574195549" MODIFIED="1610574198251"/>
<node TEXT="Key" ID="ID_707181120" CREATED="1610574199286" MODIFIED="1610574201717"/>
</node>
<node ID="ID_1365141869" CREATED="1610489988832" MODIFIED="1610489988832" LINK="https://pypi.org/project/dragonfly/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pypi.org/project/dragonfly/">dragonfly · PyPI</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_458371470" CREATED="1610490279385" MODIFIED="1610490279385" LINK="https://handsfreecoding.org/2015/04/25/designing-dragonfly-grammars/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://handsfreecoding.org/2015/04/25/designing-dragonfly-grammars/">Designing Dragonfly grammars | Hands-Free Coding</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_751134592" CREATED="1610497219613" MODIFIED="1610497219613" LINK="https://stackoverflow.com/questions/3644129/how-do-you-recognize-speech-with-the-python-module-dragonfly"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/3644129/how-do-you-recognize-speech-with-the-python-module-dragonfly">How do you recognize speech with the Python module Dragonfly? - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_71576277" CREATED="1610381748639" MODIFIED="1610381748639" LINK="https://pypi.org/project/dragonfly2/#sr-engine-back-ends"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pypi.org/project/dragonfly2/#sr-engine-back-ends">dragonfly2 · PyPI</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Grammars/add-ons" FOLDED="true" ID="ID_395742175" CREATED="1610724736128" MODIFIED="1610724742463">
<node ID="ID_368670788" CREATED="1610724759796" MODIFIED="1610724759796" LINK="https://dragonfluid.readthedocs.io/en/latest/Concepts.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfluid.readthedocs.io/en/latest/Concepts.html">Concepts — dragonfluid 0.9.0.a5 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1033439446" CREATED="1610315382657" MODIFIED="1610315382657"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h3 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 12.0pt; color: #5B9BD5">
      Vocola 2
    </h3>
  </body>
</html>
</richcontent>
<node ID="ID_1160750105" CREATED="1610315382658" MODIFIED="1610315382658" LINK="http://vocola.net/v2/voicecmd.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v2/voicecmd.pdf">Microsoft Word - Scriptrf.doc (vocola.net)</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_603294407" CREATED="1597164440744" MODIFIED="1597164440744" LINK="http://vocola.net/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://vocola.net/">Vocola - A Voice Command Language</a>
  </body>
</html>
</richcontent>
<node TEXT="http://vocola.net/unofficial/extensions.html" ID="ID_1514744893" CREATED="1601335805705" MODIFIED="1601335805705" LINK="http://vocola.net/unofficial/extensions.html"/>
</node>
<node ID="ID_1053267160" CREATED="1610317270129" MODIFIED="1610317270129" LINK="http://vocola.net/v2/BuiltinFunctions.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v2/BuiltinFunctions.asp">Vocola 2 - Built-in Functions</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_18568736" CREATED="1610317277046" MODIFIED="1610317277046" LINK="http://vocola.net/v2/BuiltinFunctions.asp"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/v2/BuiltinFunctions.asp">Vocola 2 - Built-in Functions</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Installation" FOLDED="true" ID="ID_968262817" CREATED="1610318258674" MODIFIED="1610318262343">
<node ID="ID_690580554" CREATED="1610314751796" MODIFIED="1610314751796" LINK="https://github.com/simianhacker/code-by-voice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/simianhacker/code-by-voice">GitHub - simianhacker/code-by-voice: All the support file for my code by voice setup using Dragon Naturally Speaking and DragonFly</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1734983669" CREATED="1610314751800" MODIFIED="1610314751800" LINK="https://dragonfly2.readthedocs.io/en/latest/faq.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://dragonfly2.readthedocs.io/en/latest/faq.html">Frequently Asked Questions (FAQ) — Dragonfly 0.28.1 documentation</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_891454819" CREATED="1610314697697" MODIFIED="1610314697697" LINK="https://qh.antenna.nl/unimacro/installation/installationexperimentalversionpython3.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://qh.antenna.nl/unimacro/installation/installationexperimentalversionpython3.html">installation experimental version python3</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_728243842" CREATED="1610314808082" MODIFIED="1610314808082" LINK="https://qh.antenna.nl/unimacro/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://qh.antenna.nl/unimacro/">unimacro</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_885817074" CREATED="1597163128970" MODIFIED="1597163128970" LINK="https://dragonfly2.readthedocs.io/en/latest/index.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/index.html">Dragonfly &#8212; Dragonfly 0.26.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_575701581" CREATED="1597242570761" MODIFIED="1597242570761" LINK="https://github.com/synkarius/caster"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/synkarius/caster">GitHub - synkarius/Caster: Dragonfly-Based Voice Programming Toolkit</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_208351438" CREATED="1610317968844" MODIFIED="1610317968844" LINK="https://github.com/dictation-toolbox/dragonfly"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://github.com/dictation-toolbox/dragonfly">dictation-toolbox/dragonfly: Speech recognition framework allowing powerful Python-based scripting and extension of Dragon NaturallySpeaking (DNS), Windows Speech Recognition (WSR), Kaldi and CMU Pocket Sphinx</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_540033806" CREATED="1610317968843" MODIFIED="1610317968843" LINK="https://kaldi-asr.org/doc/install.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://kaldi-asr.org/doc/install.html">Kaldi: Downloading and installing Kaldi</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Other Automation Apps" FOLDED="true" ID="ID_328752647" CREATED="1610318287978" MODIFIED="1610318312319">
<node ID="ID_560464377" CREATED="1610318201208" MODIFIED="1610318201208" LINK="https://voicecomputer.com/dragon-add-on/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://voicecomputer.com/dragon-add-on/">VoiceComputer</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Natlink" FOLDED="true" ID="ID_828134313" CREATED="1610386071861" MODIFIED="1637692277047">
<node TEXT="Setup/ Settings" FOLDED="true" ID="ID_704816460" CREATED="1610393007067" MODIFIED="1610393022361">
<node TEXT="configure Natlink via GUI" ID="ID_1925339678" CREATED="1610393032334" MODIFIED="1610393052577"/>
<node ID="ID_1318162221" CREATED="1610393023534" MODIFIED="1610393023534" LINK="https://qh.antenna.nl/unimacro/installation/installationexperimentalversionpython3.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://qh.antenna.nl/unimacro/installation/installationexperimentalversionpython3.html">installation experimental version python3</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_587505537" CREATED="1610394410329" MODIFIED="1610394870376" LINK="https://qh.antenna.nl/unimacro/implementationandacceptanceofnatlink.pdf">
<icon BUILTIN="yes"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://qh.antenna.nl/unimacro/implementationandacceptanceofnatlink.pdf">This paper describes NatLink</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_856122396" CREATED="1610314933381" MODIFIED="1610315477777" LINK="https://explosionduck.com/wp/introduction-to-voice-programming-part-one-dns-natlink/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://explosionduck.com/wp/introduction-to-voice-programming-part-one-dns-natlink/">Introduction to Voice Programming, Part One: DNS + Natlink</a>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="10"/>
</node>
<node TEXT="install Natlink alone" FOLDED="true" ID="ID_194057701" CREATED="1610396046335" MODIFIED="1610396052930">
<node ID="ID_588004312" CREATED="1610395927743" MODIFIED="1610395927743" LINK="https://sourceforge.net/projects/natlink/files/natlink/natlinktest4.1/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sourceforge.net/projects/natlink/files/natlink/natlinktest4.1/">NaturallySpeaking python scripting env - Browse /natlink/natlinktest4.1 at SourceForge.net</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Overview of Projects" ID="ID_435274025" CREATED="1610393387363" MODIFIED="1610393433825" LINK="https://dictation-toolbox.github.io/dictation-toolbox.org/"/>
<node ID="ID_1096092615" CREATED="1610386077550" MODIFIED="1610386077550" LINK="https://github.com/dictation-toolbox"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/dictation-toolbox">dictation-toolbox · GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Troubleshooting" FOLDED="true" ID="ID_1699196562" CREATED="1619108372833" MODIFIED="1619108376299">
<node TEXT="restarting Dragon" FOLDED="true" ID="ID_945179914" CREATED="1697396576908" MODIFIED="1697396584880">
<node TEXT="Task Manager .. Users" FOLDED="true" ID="ID_1277587828" CREATED="1697396587689" MODIFIED="1697396614891">
<node TEXT="close all Dragon processes" ID="ID_2799385" CREATED="1697396591878" MODIFIED="1697396626101"/>
</node>
</node>
<node TEXT="hanging in chrome or edge" FOLDED="true" ID="ID_1933069780" CREATED="1695790280773" MODIFIED="1695790288402">
<node ID="ID_1032381288" CREATED="1695790289442" MODIFIED="1695790289442" LINK="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=4&amp;threadid=37445&amp;enterthread=y"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=4&amp;threadid=37445&amp;enterthread=y">KnowBrainer Speech Recognition Forums - Dragon 16 Hangs when using Chrome and Edge</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="dictation not being recognized accurately" FOLDED="true" ID="ID_1096604500" CREATED="1687371941530" MODIFIED="1687371953136">
<node TEXT="kaldi" FOLDED="true" ID="ID_1078024190" CREATED="1687371955890" MODIFIED="1687371959883">
<node TEXT="increase end padding" FOLDED="true" ID="ID_105607397" CREATED="1687371961090" MODIFIED="1687371967876">
<node TEXT="vad_complex_padding_end_ms=600," ID="ID_1681469464" CREATED="1687372000044" MODIFIED="1687372000044"/>
</node>
</node>
</node>
<node TEXT="Keys not registering, modifier keys getting stuck" FOLDED="true" ID="ID_649064897" CREATED="1619108377200" MODIFIED="1687201986406">
<node TEXT="add pause (/1 or /10 ) after keystroke" ID="ID_94515416" CREATED="1619108390353" MODIFIED="1687202001630"/>
<node TEXT="R(Key(&quot;%(modifier)s%(button_dictionary_1)s/10&quot;)," ID="ID_1624059872" CREATED="1619108428515" MODIFIED="1619108428515"/>
</node>
</node>
<node TEXT="extending" FOLDED="true" ID="ID_278811232" CREATED="1646978780698" MODIFIED="1646978784869">
<node ID="ID_1309209823" CREATED="1646978793284" MODIFIED="1646978793284" LINK="https://duckduckgo.com/?q=Python+UI+automation+ocr&amp;kp=1&amp;ia=web"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://duckduckgo.com/?q=Python+UI+automation+ocr&amp;kp=1&amp;ia=web">Python UI automation ocr at DuckDuckGo</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_713365547" CREATED="1646978793284" MODIFIED="1646978793284" LINK="https://pypi.org/project/gui-automation/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://pypi.org/project/gui-automation/">gui-automation · PyPI</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_227244035" CREATED="1646978793299" MODIFIED="1646978793299" LINK="https://www.geeksforgeeks.org/gui-automation-using-python/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.geeksforgeeks.org/gui-automation-using-python/">GUI Automation using Python - GeeksforGeeks</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Linux" FOLDED="true" ID="ID_1857055763" CREATED="1626282730445" MODIFIED="1626282733083">
<node ID="ID_1517471653" CREATED="1626282735348" MODIFIED="1626282735348" LINK="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34641"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34641">KnowBrainer Speech Recognition Forums - Merits of Vocola vs Talon vs Caster vs Serenade etc</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="eViacam" FOLDED="true" ID="ID_137157190" CREATED="1684870403565" MODIFIED="1695406245410">
<font BOLD="true"/>
<node FOLDED="true" ID="ID_382029826" CREATED="1656344355176" MODIFIED="1685636283513" LINK="https://eviacam.crea-si.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://eviacam.crea-si.com/">Enable Viacam. Free webcam based mouse emulator</a>
  </body>
</html>
</richcontent>
<node TEXT="installation" FOLDED="true" ID="ID_1798707262" CREATED="1713553176953" MODIFIED="1713553179777">
<node TEXT="install package" ID="ID_1907147576" CREATED="1713553180749" MODIFIED="1713553185574"/>
<node TEXT="replace face tracker XML" FOLDED="true" ID="ID_1699764114" CREATED="1713553186972" MODIFIED="1713553194568">
<node TEXT="C:\Program Files (x86)\Enable Viacam\bin\haarcascade_frontalface_default.xml" FOLDED="true" ID="ID_1472987350" CREATED="1713553259176" MODIFIED="1713553259176">
<node TEXT="rename original file bk_ to preserve" ID="ID_261965582" CREATED="1713553315344" MODIFIED="1713553334987"/>
</node>
<node TEXT="with" FOLDED="true" ID="ID_1251536089" CREATED="1713553296180" MODIFIED="1713553298983">
<node ID="ID_186921778" CREATED="1713717795464" MODIFIED="1713717795464" LINK="https://github.com/opencv/opencv/blob/4.x/data/haarcascades_cuda/haarcascade_frontalface_alt2.xml"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/opencv/opencv/blob/4.x/data/haarcascades_cuda/haarcascade_frontalface_alt2.xml">opencv/data/haarcascades_cuda/haarcascade_frontalface_alt2.xml at 4.x · opencv/opencv</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="by downloading and renaming" ID="ID_1793329504" CREATED="1713553305789" MODIFIED="1713553314569"/>
</node>
</node>
</node>
<node TEXT="troubleshooting" FOLDED="true" ID="ID_444726818" CREATED="1695573209031" MODIFIED="1695573211015">
<node TEXT="low frame rate" FOLDED="true" ID="ID_227617330" CREATED="1695573211858" MODIFIED="1695573214634">
<node TEXT="change camera settings" FOLDED="true" ID="ID_392237554" CREATED="1695573215577" MODIFIED="1695573219663">
<node TEXT="Exposure, uncheck Auto, set to -6" ID="ID_941147056" CREATED="1695573222214" MODIFIED="1695573282557"/>
</node>
</node>
</node>
<node TEXT="set compatibility for Windows 8" ID="ID_1905526315" CREATED="1656344364265" MODIFIED="1656344372428"/>
</node>
<node TEXT="settings" FOLDED="true" ID="ID_138821388" CREATED="1695922307103" MODIFIED="1695922759398">
<node TEXT="camera zoom 2" ID="ID_284966746" CREATED="1713374237632" MODIFIED="1713374248465"/>
<node TEXT="no automatic face tracking" ID="ID_233943612" CREATED="1713374249657" MODIFIED="1713374259060"/>
<node TEXT="set bounding box within edges of face, not around face (smaller than face)" ID="ID_936114763" CREATED="1713374259855" MODIFIED="1713374293529"/>
<node TEXT="School" FOLDED="true" ID="ID_674974447" CREATED="1695922760132" MODIFIED="1695922768952">
<node TEXT="automatic face recognition" ID="ID_1332182912" CREATED="1695922817375" MODIFIED="1695922838561"/>
<node TEXT="X 12&#xa;Y 10" ID="ID_1968409001" CREATED="1695922780307" MODIFIED="1695922868009"/>
</node>
<node TEXT="Home" FOLDED="true" ID="ID_957623166" CREATED="1695922874728" MODIFIED="1695922877755">
<node TEXT="big-screen" FOLDED="true" ID="ID_97980957" CREATED="1696097728672" MODIFIED="1696097740049">
<node TEXT="camera zoom = 2" ID="ID_1257444552" CREATED="1696097740839" MODIFIED="1696097759087"/>
</node>
<node TEXT="X 12&#xa;Y 12" ID="ID_1309838975" CREATED="1695922780307" MODIFIED="1696097821078"/>
</node>
</node>
<node ID="ID_1327876469" CREATED="1689112494921" MODIFIED="1689112494921" LINK="https://sourceforge.net/projects/eviacam/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sourceforge.net/projects/eviacam/">14. eviacam download | SourceForge.net</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Indirect" FOLDED="true" ID="ID_1897113074" CREATED="1695077534839" MODIFIED="1695077538812">
<node ID="ID_240991606" CREATED="1700004927041" MODIFIED="1700004927041" LINK="https://www.facetracknoir.nl/home/default.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.facetracknoir.nl/home/default.htm">Home</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Voice" FOLDED="true" ID="ID_1289362185" CREATED="1615780611147" MODIFIED="1615780677331">
<icon BUILTIN="bookmark"/>
<node ID="ID_1351446045" TREE_ID="ID_1219441798">
<node ID="ID_1005466755" TREE_ID="ID_1327730210">
<node ID="ID_846132514" TREE_ID="ID_387341379">
<node ID="ID_1004259766" TREE_ID="ID_321896403"/>
<node ID="ID_1767692377" TREE_ID="ID_494729369"/>
<node ID="ID_794515114" TREE_ID="ID_1194393416"/>
</node>
<node ID="ID_97757765" TREE_ID="ID_1919202037">
<node ID="ID_202517518" TREE_ID="ID_1514163178">
<node ID="ID_1428401312" TREE_ID="ID_1756964168">
<node ID="ID_764207362" TREE_ID="ID_1754548741"/>
</node>
</node>
<node ID="ID_1916303960" TREE_ID="ID_292269063">
<node ID="ID_170884238" TREE_ID="ID_843734674"/>
</node>
</node>
<node ID="ID_1389092330" TREE_ID="ID_941242643">
<node ID="ID_1638512566" TREE_ID="ID_1355317208">
<node ID="ID_739065029" TREE_ID="ID_810972003">
<node ID="ID_1604923969" TREE_ID="ID_1425757049">
<node ID="ID_506923889" TREE_ID="ID_545290636">
<node ID="ID_1985352786" TREE_ID="ID_420522429">
<node ID="ID_1926142659" TREE_ID="ID_320660073"/>
</node>
<node ID="ID_140274826" TREE_ID="ID_1062881287">
<node ID="ID_1265278812" TREE_ID="ID_718846891"/>
<node ID="ID_29985219" TREE_ID="ID_116947690">
<node ID="ID_1933064665" TREE_ID="ID_1332968111"/>
<node ID="ID_253831647" TREE_ID="ID_319566647"/>
</node>
</node>
<node ID="ID_1382975391" TREE_ID="ID_5191090"/>
</node>
<node ID="ID_1509597784" TREE_ID="ID_1259781054">
<node ID="ID_1656129264" TREE_ID="ID_1919323864">
<node ID="ID_350041617" TREE_ID="ID_192098416"/>
<node ID="ID_232603427" TREE_ID="ID_1914585461"/>
<node ID="ID_202869518" TREE_ID="ID_1243440251">
<node ID="ID_663253291" TREE_ID="ID_452132674"/>
<node ID="ID_1557455847" TREE_ID="ID_1094811205"/>
</node>
</node>
<node ID="ID_1373005620" TREE_ID="ID_999505344">
<node ID="ID_193992881" TREE_ID="ID_996711977"/>
</node>
</node>
</node>
<node ID="ID_1467193581" TREE_ID="ID_1829787567">
<node ID="ID_1521893243" TREE_ID="ID_573239335"/>
<node ID="ID_1095018036" TREE_ID="ID_282714908"/>
<node ID="ID_766326369" TREE_ID="ID_1747352101"/>
<node ID="ID_1811534036" TREE_ID="ID_91654459"/>
<node ID="ID_1994178039" TREE_ID="ID_128703296"/>
</node>
<node ID="ID_1397294309" TREE_ID="ID_1525677671"/>
<node ID="ID_1982294075" TREE_ID="ID_45931877">
<node ID="ID_1816825997" TREE_ID="ID_1278587462">
<node ID="ID_1506595136" TREE_ID="ID_1289670029">
<node ID="ID_1717781320" TREE_ID="ID_912665957"/>
<node ID="ID_1442142006" TREE_ID="ID_1838351079"/>
<node ID="ID_1594434596" TREE_ID="ID_1857686082"/>
<node ID="ID_353020882" TREE_ID="ID_469293071"/>
<node ID="ID_150786148" TREE_ID="ID_1199648225"/>
<node ID="ID_956225820" TREE_ID="ID_179119155"/>
<node ID="ID_740627290" TREE_ID="ID_61948163"/>
<node ID="ID_1841384242" TREE_ID="ID_958279301"/>
</node>
</node>
</node>
<node ID="ID_1669412561" TREE_ID="ID_6432024">
<node ID="ID_550181421" TREE_ID="ID_1864436097"/>
<node ID="ID_885395456" TREE_ID="ID_1166777541">
<node ID="ID_915177296" TREE_ID="ID_1811181418">
<node ID="ID_1042058667" TREE_ID="ID_1021794625"/>
</node>
<node ID="ID_1765286298" TREE_ID="ID_337713452">
<node ID="ID_999639934" TREE_ID="ID_977700122"/>
<node ID="ID_129712253" TREE_ID="ID_1338717227"/>
</node>
</node>
<node ID="ID_1559052118" TREE_ID="ID_329413610">
<node ID="ID_453892805" TREE_ID="ID_808822240">
<node ID="ID_1453721060" TREE_ID="ID_361496157"/>
<node ID="ID_932199177" TREE_ID="ID_1760281890"/>
<node ID="ID_1082711287" TREE_ID="ID_1129118258">
<node ID="ID_744560995" TREE_ID="ID_943836767"/>
<node ID="ID_1692749288" TREE_ID="ID_1876157603"/>
<node ID="ID_727429079" TREE_ID="ID_1877101294"/>
<node ID="ID_316812452" TREE_ID="ID_393981467"/>
<node ID="ID_1408164379" TREE_ID="ID_1942676067"/>
<node ID="ID_1618106741" TREE_ID="ID_1998963801"/>
<node ID="ID_385530185" TREE_ID="ID_1894935259"/>
<node ID="ID_362468555" TREE_ID="ID_707921799"/>
<node ID="ID_1346169652" TREE_ID="ID_1396398486"/>
<node ID="ID_126520419" TREE_ID="ID_418853527"/>
<node ID="ID_1478449022" TREE_ID="ID_701701079"/>
</node>
</node>
</node>
</node>
<node ID="ID_1166361674" TREE_ID="ID_637773615">
<node ID="ID_1271521455" TREE_ID="ID_794959699">
<node ID="ID_345419675" TREE_ID="ID_17808905">
<node ID="ID_951005526" TREE_ID="ID_503300595">
<node ID="ID_611906262" TREE_ID="ID_955012133"/>
</node>
</node>
</node>
<node ID="ID_1591898817" TREE_ID="ID_917928431">
<node ID="ID_259377493" TREE_ID="ID_1676393095">
<node ID="ID_313421940" TREE_ID="ID_1506544927"/>
</node>
</node>
<node ID="ID_119744756" TREE_ID="ID_1175701220">
<node ID="ID_1090902491" TREE_ID="ID_419595350"/>
<node ID="ID_572207337" TREE_ID="ID_1007547191"/>
<node POSITION="bottom_or_right" ID="ID_484747283" TREE_ID="ID_1443572411"/>
</node>
</node>
<node ID="ID_1609188105" TREE_ID="ID_1779737421">
<node ID="ID_1796839240" TREE_ID="ID_1139132554">
<node ID="ID_1354270845" TREE_ID="ID_1717340912"/>
</node>
<node ID="ID_84890768" TREE_ID="ID_61551739"/>
<node ID="ID_653071833" TREE_ID="ID_1482145407"/>
<node ID="ID_1457560808" TREE_ID="ID_1688717654"/>
<node ID="ID_709632445" TREE_ID="ID_603687258"/>
<node ID="ID_1698557506" TREE_ID="ID_1788045389"/>
<node ID="ID_1784157523" TREE_ID="ID_1712557008"/>
<node ID="ID_1776250565" TREE_ID="ID_433584577"/>
</node>
<node ID="ID_1379915506" TREE_ID="ID_797072233">
<node ID="ID_119241593" TREE_ID="ID_1521086646">
<node ID="ID_1141351822" TREE_ID="ID_1916014201"/>
</node>
</node>
<node ID="ID_833418440" TREE_ID="ID_533641432">
<node ID="ID_284545158" TREE_ID="ID_1240155923">
<node ID="ID_204625117" TREE_ID="ID_332534682">
<node ID="ID_1243103583" TREE_ID="ID_416694678"/>
<node ID="ID_1147720165" TREE_ID="ID_964847242">
<node ID="ID_640286011" TREE_ID="ID_318842908"/>
<node ID="ID_394273670" TREE_ID="ID_836912042">
<node ID="ID_267537773" TREE_ID="ID_946519626"/>
</node>
</node>
</node>
<node ID="ID_1992719982" TREE_ID="ID_618834979">
<node ID="ID_982398184" TREE_ID="ID_869459981"/>
</node>
<node ID="ID_181256749" TREE_ID="ID_1823055466">
<node ID="ID_1660076805" TREE_ID="ID_8479231"/>
</node>
<node ID="ID_1651935119" TREE_ID="ID_1606783587">
<node ID="ID_310303181" TREE_ID="ID_628704067"/>
</node>
<node ID="ID_329406888" TREE_ID="ID_835387614"/>
<node ID="ID_86084503" TREE_ID="ID_1096406731">
<node ID="ID_373335396" TREE_ID="ID_424779579">
<node ID="ID_1631976848" TREE_ID="ID_91393315"/>
</node>
<node ID="ID_941973349" TREE_ID="ID_1009548496"/>
</node>
<node ID="ID_147336360" TREE_ID="ID_1441857518">
<node ID="ID_656567243" TREE_ID="ID_755619107"/>
</node>
</node>
<node ID="ID_1095146012" TREE_ID="ID_874595691">
<node ID="ID_895902318" TREE_ID="ID_228366529"/>
<node ID="ID_1879824918" TREE_ID="ID_1048669304"/>
<node ID="ID_1666020093" TREE_ID="ID_481652900"/>
</node>
<node ID="ID_741600383" TREE_ID="ID_398156906">
<node ID="ID_1834100084" TREE_ID="ID_258806279">
<node ID="ID_1245153748" TREE_ID="ID_169856060">
<node ID="ID_491021741" TREE_ID="ID_1159054771"/>
</node>
</node>
<node ID="ID_1435548824" TREE_ID="ID_533466093">
<node ID="ID_649845223" TREE_ID="ID_1382592942"/>
</node>
<node ID="ID_1204405450" TREE_ID="ID_1482373625">
<node ID="ID_1432397039" TREE_ID="ID_391963279">
<node ID="ID_1400176877" TREE_ID="ID_1987326877"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_371203496" TREE_ID="ID_767931384">
<node ID="ID_209986893" TREE_ID="ID_1385615366">
<node ID="ID_1441026963" TREE_ID="ID_1271588734"/>
</node>
<node ID="ID_213705214" TREE_ID="ID_447442315">
<node ID="ID_829166294" TREE_ID="ID_1526909264">
<node ID="ID_382480153" TREE_ID="ID_665128242">
<node ID="ID_312696815" TREE_ID="ID_1613283315"/>
<node ID="ID_108067154" TREE_ID="ID_755210619"/>
</node>
</node>
<node ID="ID_17574351" TREE_ID="ID_1100589341">
<node ID="ID_1146800305" TREE_ID="ID_445854893">
<node ID="ID_1950517901" TREE_ID="ID_816467275">
<node ID="ID_1291313929" TREE_ID="ID_321391080"/>
</node>
</node>
<node ID="ID_955428244" TREE_ID="ID_1628375443">
<node ID="ID_957088292" TREE_ID="ID_765635287">
<node ID="ID_529442861" TREE_ID="ID_1683795848"/>
</node>
<node ID="ID_1829397404" TREE_ID="ID_1752825659">
<node ID="ID_1098969722" TREE_ID="ID_482615909"/>
</node>
</node>
</node>
</node>
<node ID="ID_1688504642" TREE_ID="ID_1267116220">
<node ID="ID_508399570" TREE_ID="ID_894182107">
<node ID="ID_1145609184" TREE_ID="ID_144068376">
<node ID="ID_694670094" TREE_ID="ID_323165998"/>
<node ID="ID_682148602" TREE_ID="ID_792657825"/>
<node ID="ID_992006027" TREE_ID="ID_1684197854"/>
</node>
</node>
<node ID="ID_515080651" TREE_ID="ID_1817569118">
<node ID="ID_1950054482" TREE_ID="ID_1984483401"/>
</node>
</node>
<node ID="ID_337528514" TREE_ID="ID_1975720300">
<node ID="ID_481485808" TREE_ID="ID_1062143369">
<node ID="ID_46303122" TREE_ID="ID_1232898135"/>
</node>
</node>
<node ID="ID_554139842" TREE_ID="ID_105896462">
<node ID="ID_1918002365" TREE_ID="ID_1530463847"/>
<node ID="ID_55164768" TREE_ID="ID_1287327982"/>
<node ID="ID_1890867400" TREE_ID="ID_957011591">
<node ID="ID_1161272574" TREE_ID="ID_1979092184"/>
<node ID="ID_1924082049" TREE_ID="ID_1079935195"/>
<node ID="ID_1241586943" TREE_ID="ID_1163799958"/>
</node>
</node>
<node ID="ID_1032984691" TREE_ID="ID_48798731">
<node ID="ID_1217527331" TREE_ID="ID_341384236"/>
<node ID="ID_1442382833" TREE_ID="ID_1995276932"/>
<node ID="ID_1009550424" TREE_ID="ID_1257572966"/>
</node>
<node ID="ID_1817045723" TREE_ID="ID_1120275028">
<node ID="ID_798908432" TREE_ID="ID_400709089">
<node ID="ID_1106027489" TREE_ID="ID_1327674800">
<node ID="ID_1268090709" TREE_ID="ID_1801475154"/>
<node ID="ID_1732674346" TREE_ID="ID_1781630337"/>
</node>
</node>
</node>
</node>
<node ID="ID_67059446" TREE_ID="ID_1958312684">
<node ID="ID_550226059" TREE_ID="ID_940444279"/>
</node>
<node ID="ID_1503263586" TREE_ID="ID_1451191032">
<node ID="ID_1241900707" TREE_ID="ID_1849704061"/>
<node ID="ID_14871293" TREE_ID="ID_142770493"/>
<node ID="ID_265029799" TREE_ID="ID_1789805852"/>
</node>
<node ID="ID_1941015001" TREE_ID="ID_963944595">
<node ID="ID_927137705" TREE_ID="ID_1009139648">
<node ID="ID_181346226" TREE_ID="ID_840836627"/>
<node ID="ID_1320957781" TREE_ID="ID_20909583"/>
<node ID="ID_612832333" TREE_ID="ID_130592688"/>
<node ID="ID_1333365885" TREE_ID="ID_83504920"/>
<node ID="ID_887108396" TREE_ID="ID_77852388"/>
</node>
<node ID="ID_1640013985" TREE_ID="ID_1021404680">
<node ID="ID_416200504" TREE_ID="ID_863996568">
<node ID="ID_1604562680" TREE_ID="ID_1253376619"/>
<node ID="ID_808168600" TREE_ID="ID_1860242071"/>
<node ID="ID_749477659" TREE_ID="ID_1573404577"/>
<node ID="ID_1418103271" TREE_ID="ID_193710519">
<node ID="ID_884185929" TREE_ID="ID_471758154"/>
<node ID="ID_806034323" TREE_ID="ID_1683288963"/>
<node ID="ID_1693379059" TREE_ID="ID_646424949"/>
<node ID="ID_1739353407" TREE_ID="ID_1647221593">
<node ID="ID_543927016" TREE_ID="ID_265412610"/>
</node>
</node>
<node ID="ID_1082335975" TREE_ID="ID_1061145232">
<node ID="ID_1591901011" TREE_ID="ID_1166008497"/>
<node ID="ID_725440290" TREE_ID="ID_68026513"/>
<node ID="ID_939082202" TREE_ID="ID_247571149"/>
</node>
<node ID="ID_1184475262" TREE_ID="ID_995205585"/>
<node ID="ID_508936721" TREE_ID="ID_826260277"/>
<node ID="ID_1045179545" TREE_ID="ID_1029134280"/>
<node ID="ID_489603471" TREE_ID="ID_574743555"/>
</node>
<node ID="ID_1524333540" TREE_ID="ID_1894114570">
<node ID="ID_267200866" TREE_ID="ID_868690251"/>
</node>
<node ID="ID_536157408" TREE_ID="ID_1576093656">
<node ID="ID_841922064" TREE_ID="ID_727564776"/>
<node ID="ID_1554012027" TREE_ID="ID_1845713145">
<node ID="ID_860964171" TREE_ID="ID_67171945"/>
</node>
<node ID="ID_502322260" TREE_ID="ID_601858415"/>
<node ID="ID_838240577" TREE_ID="ID_942676050"/>
</node>
<node ID="ID_1038115530" TREE_ID="ID_1829048106">
<node ID="ID_1149655851" TREE_ID="ID_801143047"/>
<node ID="ID_236617639" TREE_ID="ID_1741192570"/>
<node ID="ID_1249659707" TREE_ID="ID_535899538"/>
<node ID="ID_1837741756" TREE_ID="ID_935965712"/>
<node ID="ID_1790380140" TREE_ID="ID_677308647"/>
<node ID="ID_314273523" TREE_ID="ID_929780518"/>
<node ID="ID_479651497" TREE_ID="ID_702008952"/>
<node ID="ID_1441610432" TREE_ID="ID_1138893919"/>
</node>
<node ID="ID_579513410" TREE_ID="ID_888667000">
<node ID="ID_1286077080" TREE_ID="ID_1483949455"/>
</node>
</node>
<node ID="ID_4470009" TREE_ID="ID_1567333220">
<node ID="ID_310694724" TREE_ID="ID_579474612">
<node ID="ID_1737814445" TREE_ID="ID_1598714429"/>
<node ID="ID_705048033" TREE_ID="ID_1550036620"/>
</node>
</node>
<node ID="ID_1502431659" TREE_ID="ID_1430757764">
<node ID="ID_1684161740" TREE_ID="ID_247306116"/>
</node>
</node>
</node>
<node ID="ID_456266603" TREE_ID="ID_1916923667">
<node ID="ID_1738127019" TREE_ID="ID_1427249552">
<node ID="ID_1263903871" TREE_ID="ID_1190331502">
<node ID="ID_1869951414" TREE_ID="ID_963845373"/>
<node ID="ID_1870754834" TREE_ID="ID_1875166482">
<node ID="ID_1735687305" TREE_ID="ID_1484659963"/>
<node ID="ID_1216195108" TREE_ID="ID_696998987">
<node ID="ID_804544330" TREE_ID="ID_851273433"/>
<node ID="ID_553035182" TREE_ID="ID_347260041"/>
</node>
<node ID="ID_247323541" TREE_ID="ID_1281922046">
<node ID="ID_1149947629" TREE_ID="ID_785452114"/>
</node>
<node ID="ID_233151411" TREE_ID="ID_1439964975">
<node ID="ID_1239401840" TREE_ID="ID_646983405">
<node ID="ID_252747883" TREE_ID="ID_105931907">
<node ID="ID_654954366" TREE_ID="ID_263261500"/>
<node ID="ID_953761959" TREE_ID="ID_626153827">
<node ID="ID_1183153829" TREE_ID="ID_1865905671"/>
<node ID="ID_802821042" TREE_ID="ID_451355303">
<node ID="ID_728357366" TREE_ID="ID_951835538"/>
</node>
<node ID="ID_1811347249" TREE_ID="ID_722663804"/>
</node>
<node ID="ID_781799374" TREE_ID="ID_1960647516">
<node ID="ID_191258391" TREE_ID="ID_563056376"/>
<node ID="ID_463322398" TREE_ID="ID_721950537"/>
<node ID="ID_1534348518" TREE_ID="ID_1776589374"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1819699541" TREE_ID="ID_777355488">
<node ID="ID_534196310" TREE_ID="ID_963502461"/>
<node ID="ID_1292399299" TREE_ID="ID_451768936"/>
<node ID="ID_933239642" TREE_ID="ID_302538735"/>
<node ID="ID_1518501105" TREE_ID="ID_79146458">
<node ID="ID_554112615" TREE_ID="ID_782741956"/>
</node>
</node>
<node ID="ID_1811924067" TREE_ID="ID_1869185898">
<node ID="ID_670133670" TREE_ID="ID_1348801127">
<node ID="ID_620005571" TREE_ID="ID_658228341">
<node ID="ID_557654222" TREE_ID="ID_561881605"/>
<node ID="ID_539912395" TREE_ID="ID_1178059059"/>
<node ID="ID_708489889" TREE_ID="ID_1307359165"/>
</node>
<node ID="ID_1248418406" TREE_ID="ID_1755444599">
<node ID="ID_529384320" TREE_ID="ID_303605033">
<node ID="ID_1932000353" TREE_ID="ID_841707445">
<node ID="ID_281485354" TREE_ID="ID_269266206"/>
</node>
</node>
<node ID="ID_1279271095" TREE_ID="ID_386617373">
<node ID="ID_1860982976" TREE_ID="ID_469089842"/>
<node ID="ID_1246955716" TREE_ID="ID_637181569"/>
<node ID="ID_1897653450" TREE_ID="ID_45833858"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1109323055" TREE_ID="ID_542177779">
<node ID="ID_74032882" TREE_ID="ID_962712039"/>
</node>
<node ID="ID_921822726" TREE_ID="ID_1229014725"/>
<node ID="ID_370538119" TREE_ID="ID_422637551">
<node ID="ID_478032794" TREE_ID="ID_605929741">
<node ID="ID_121794923" TREE_ID="ID_1573085974">
<node ID="ID_226636052" TREE_ID="ID_1040738839"/>
</node>
<node ID="ID_1467160361" TREE_ID="ID_703804169"/>
</node>
<node ID="ID_607770001" TREE_ID="ID_1764490213">
<node ID="ID_320006619" TREE_ID="ID_513806413">
<node ID="ID_106045778" TREE_ID="ID_442236472"/>
</node>
<node ID="ID_481447534" TREE_ID="ID_568182947">
<node ID="ID_631495431" TREE_ID="ID_1683189444"/>
</node>
<node ID="ID_472095363" TREE_ID="ID_1386431833"/>
<node ID="ID_526830853" TREE_ID="ID_976227034">
<node ID="ID_860136926" TREE_ID="ID_1937634031"/>
</node>
</node>
<node ID="ID_595573072" TREE_ID="ID_839513786">
<node ID="ID_85371392" TREE_ID="ID_224514830">
<node ID="ID_653778028" TREE_ID="ID_1111925368">
<node ID="ID_1203607225" TREE_ID="ID_1536320732"/>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_1472848606" TREE_ID="ID_1057990905">
<node ID="ID_1566273764" TREE_ID="ID_1766539237"/>
</node>
</node>
</node>
<node ID="ID_332689876" TREE_ID="ID_683680555">
<node ID="ID_281588923" TREE_ID="ID_1974647533">
<node ID="ID_1656617586" TREE_ID="ID_132247612"/>
</node>
<node ID="ID_1470963744" TREE_ID="ID_30575133">
<node ID="ID_206068842" TREE_ID="ID_1245211436">
<node ID="ID_1333662376" TREE_ID="ID_593260325"/>
</node>
<node ID="ID_640313351" TREE_ID="ID_1535301331">
<node ID="ID_1745143320" TREE_ID="ID_1543875069"/>
<node ID="ID_544817778" TREE_ID="ID_1646828263"/>
</node>
<node ID="ID_632430620" TREE_ID="ID_502127135">
<node ID="ID_1155583042" TREE_ID="ID_518432592"/>
</node>
</node>
<node ID="ID_1973832924" TREE_ID="ID_592164404">
<node ID="ID_890094024" TREE_ID="ID_1122279096"/>
</node>
<node ID="ID_300525042" TREE_ID="ID_1523512122"/>
<node ID="ID_801489924" TREE_ID="ID_420654536">
<node ID="ID_1438680753" TREE_ID="ID_274574432"/>
<node ID="ID_1343391616" TREE_ID="ID_1166367300"/>
<node ID="ID_740617508" TREE_ID="ID_403743217"/>
<node ID="ID_1886259162" TREE_ID="ID_161121222"/>
</node>
<node ID="ID_1490815982" TREE_ID="ID_1988886445"/>
</node>
<node ID="ID_713951122" TREE_ID="ID_1745088374">
<node ID="ID_1347023849" TREE_ID="ID_1783009864">
<node ID="ID_530653742" TREE_ID="ID_1193488278"/>
</node>
<node ID="ID_790053513" TREE_ID="ID_1431845653">
<node ID="ID_1462560884" TREE_ID="ID_1015024025"/>
</node>
<node ID="ID_1481559700" TREE_ID="ID_912509127">
<node ID="ID_1776059521" TREE_ID="ID_1077166335"/>
</node>
<node ID="ID_1394536857" TREE_ID="ID_896007984">
<node ID="ID_483498074" TREE_ID="ID_1670436793"/>
</node>
</node>
<node ID="ID_1334092007" TREE_ID="ID_1831227939">
<node ID="ID_916750019" TREE_ID="ID_110617093"/>
</node>
<node ID="ID_137719937" TREE_ID="ID_642094660">
<node ID="ID_850508637" TREE_ID="ID_128807979"/>
<node ID="ID_1649958176" TREE_ID="ID_1409927137">
<node ID="ID_221093797" TREE_ID="ID_1989399906">
<node ID="ID_277281361" TREE_ID="ID_1675215555"/>
</node>
</node>
</node>
<node ID="ID_1636335995" TREE_ID="ID_1998528078"/>
<node POSITION="bottom_or_right" ID="ID_1253267392" TREE_ID="ID_1226008273"/>
</node>
<node ID="ID_643685155" TREE_ID="ID_798849189">
<node ID="ID_1242830063" TREE_ID="ID_1884657712"/>
<node ID="ID_1916096762" TREE_ID="ID_781599588"/>
<node ID="ID_89735476" TREE_ID="ID_128264308">
<node ID="ID_1643693066" TREE_ID="ID_1911963857"/>
<node ID="ID_218528979" TREE_ID="ID_153810898"/>
</node>
<node ID="ID_1256771501" TREE_ID="ID_1880654702">
<node ID="ID_1856768454" TREE_ID="ID_31667523"/>
</node>
<node ID="ID_1037396638" TREE_ID="ID_921029621">
<node ID="ID_1739650356" TREE_ID="ID_73273396"/>
</node>
<node ID="ID_187158588" TREE_ID="ID_1739802204">
<node ID="ID_585226015" TREE_ID="ID_1268989953"/>
</node>
<node ID="ID_1662414366" TREE_ID="ID_1731602817">
<node ID="ID_1879582189" TREE_ID="ID_516766978"/>
<node ID="ID_987888588" TREE_ID="ID_483588036"/>
<node ID="ID_611538743" TREE_ID="ID_1075594790"/>
</node>
<node ID="ID_141271137" TREE_ID="ID_507187834">
<node ID="ID_1213657492" TREE_ID="ID_1020905779">
<node ID="ID_1284563047" TREE_ID="ID_1733721772"/>
<node ID="ID_1012485538" TREE_ID="ID_1824424921"/>
</node>
<node ID="ID_1191020192" TREE_ID="ID_1774929753">
<node ID="ID_838531134" TREE_ID="ID_1121894628"/>
</node>
<node ID="ID_579627862" TREE_ID="ID_1681997812"/>
<node ID="ID_1260640208" TREE_ID="ID_1424078619"/>
<node ID="ID_1614391301" TREE_ID="ID_186364290"/>
</node>
</node>
<node ID="ID_301808618" TREE_ID="ID_990498369"/>
<node ID="ID_861757379" TREE_ID="ID_1957338467"/>
<node ID="ID_812636882" TREE_ID="ID_1931031299">
<node ID="ID_801208043" TREE_ID="ID_229696095">
<node ID="ID_719824259" TREE_ID="ID_1247261596"/>
</node>
<node ID="ID_241277223" TREE_ID="ID_125967180">
<node ID="ID_1837752266" TREE_ID="ID_4629795"/>
</node>
</node>
<node ID="ID_1375129798" TREE_ID="ID_1510681113">
<node ID="ID_953302265" TREE_ID="ID_1221064412"/>
<node ID="ID_379136724" TREE_ID="ID_502304522">
<node ID="ID_116409678" TREE_ID="ID_763043827">
<node ID="ID_770383000" TREE_ID="ID_186474654"/>
<node ID="ID_631291033" TREE_ID="ID_225416675">
<node ID="ID_751099140" TREE_ID="ID_860886595">
<node ID="ID_674783837" TREE_ID="ID_1757204486"/>
<node ID="ID_1653363124" TREE_ID="ID_1954931197"/>
</node>
<node ID="ID_31968761" TREE_ID="ID_676719163"/>
</node>
<node ID="ID_1895368112" TREE_ID="ID_317690893">
<node ID="ID_1521383171" TREE_ID="ID_511149811">
<node ID="ID_1112598928" TREE_ID="ID_229646716"/>
</node>
<node ID="ID_1462753230" TREE_ID="ID_1109797344">
<node ID="ID_1403457753" TREE_ID="ID_301764157"/>
</node>
</node>
<node ID="ID_1096302967" TREE_ID="ID_290918109"/>
<node ID="ID_1109356755" TREE_ID="ID_249610100"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1463168562" TREE_ID="ID_636985091">
<node ID="ID_1927731351" TREE_ID="ID_1680031204">
<node ID="ID_347183310" TREE_ID="ID_858176129"/>
</node>
</node>
<node ID="ID_622864187" TREE_ID="ID_1400458580">
<node ID="ID_1856189677" TREE_ID="ID_651617562">
<node ID="ID_1735491344" TREE_ID="ID_287070822"/>
<node ID="ID_1637551951" TREE_ID="ID_845485283"/>
<node ID="ID_285777691" TREE_ID="ID_1631084503"/>
</node>
<node ID="ID_1292133018" TREE_ID="ID_1405321552"/>
<node ID="ID_1903648460" TREE_ID="ID_1494829819"/>
<node ID="ID_1816326739" TREE_ID="ID_1500456779"/>
</node>
<node ID="ID_1826455256" TREE_ID="ID_1496217787">
<node ID="ID_414819797" TREE_ID="ID_1430288754">
<node ID="ID_422772843" TREE_ID="ID_864798082">
<node ID="ID_1586791772" TREE_ID="ID_1160115649"/>
</node>
<node ID="ID_1264002420" TREE_ID="ID_814259838">
<node ID="ID_1539529054" TREE_ID="ID_1524738298"/>
<node ID="ID_570651403" TREE_ID="ID_336873622"/>
</node>
</node>
<node ID="ID_62392651" TREE_ID="ID_150572428">
<node ID="ID_1158543745" TREE_ID="ID_75475344">
<node ID="ID_1331415858" TREE_ID="ID_718352704"/>
</node>
</node>
</node>
<node ID="ID_1322871375" TREE_ID="ID_1829119413">
<node ID="ID_1486964392" TREE_ID="ID_613730449">
<node ID="ID_1453837077" TREE_ID="ID_1108161636">
<node ID="ID_74579324" TREE_ID="ID_1571603589"/>
</node>
<node ID="ID_1873606826" TREE_ID="ID_1766402798">
<node ID="ID_488632670" TREE_ID="ID_361434872"/>
</node>
</node>
</node>
<node ID="ID_40094320" TREE_ID="ID_749183666">
<node ID="ID_1931044521" TREE_ID="ID_805245176">
<node ID="ID_195708976" TREE_ID="ID_1874346791"/>
</node>
<node ID="ID_1179945619" TREE_ID="ID_1569518016"/>
<node ID="ID_20488827" TREE_ID="ID_423319496"/>
<node ID="ID_1403166975" TREE_ID="ID_112706849"/>
<node ID="ID_492415380" TREE_ID="ID_16325183"/>
<node ID="ID_1668765196" TREE_ID="ID_926319863"/>
<node ID="ID_539725740" TREE_ID="ID_1473518929">
<node ID="ID_1917751427" TREE_ID="ID_1287761799"/>
<node ID="ID_1577557396" TREE_ID="ID_1468417779"/>
<node ID="ID_572023737" TREE_ID="ID_1405095589"/>
<node ID="ID_1266018723" TREE_ID="ID_336875811"/>
</node>
<node ID="ID_1747444801" TREE_ID="ID_255433156">
<node ID="ID_508155067" TREE_ID="ID_476095882"/>
<node ID="ID_135389774" TREE_ID="ID_409089517">
<node ID="ID_63044357" TREE_ID="ID_1566685445"/>
<node ID="ID_545928020" TREE_ID="ID_1632013429">
<node ID="ID_1310575732" TREE_ID="ID_1377415945"/>
<node ID="ID_1373747821" TREE_ID="ID_1977696008">
<node ID="ID_1933921290" TREE_ID="ID_1342888710"/>
</node>
<node ID="ID_736029774" TREE_ID="ID_1456648513"/>
</node>
</node>
</node>
<node ID="ID_1236313361" TREE_ID="ID_727598395">
<node ID="ID_165391701" TREE_ID="ID_1090953069">
<node ID="ID_1878652663" TREE_ID="ID_875026805"/>
<node ID="ID_1091658717" TREE_ID="ID_1238804709"/>
<node ID="ID_1031487527" TREE_ID="ID_686915869"/>
<node ID="ID_496691767" TREE_ID="ID_1675655108">
<node ID="ID_1102919447" TREE_ID="ID_1693145381"/>
<node ID="ID_727399692" TREE_ID="ID_1862187639"/>
<node ID="ID_1042819665" TREE_ID="ID_1225990821"/>
<node ID="ID_451177895" TREE_ID="ID_1198294448">
<node ID="ID_1713480856" TREE_ID="ID_1362659736"/>
</node>
</node>
<node ID="ID_707576023" TREE_ID="ID_221334827">
<node ID="ID_1144663291" TREE_ID="ID_328594580"/>
<node ID="ID_733832850" TREE_ID="ID_1387476085"/>
<node ID="ID_1624886733" TREE_ID="ID_707181120"/>
</node>
<node ID="ID_306539593" TREE_ID="ID_1365141869"/>
<node ID="ID_1682043346" TREE_ID="ID_458371470"/>
<node ID="ID_1795021357" TREE_ID="ID_751134592"/>
<node ID="ID_167552506" TREE_ID="ID_71576277"/>
</node>
<node ID="ID_1103890576" TREE_ID="ID_395742175">
<node ID="ID_1253979818" TREE_ID="ID_368670788"/>
</node>
<node ID="ID_845076946" TREE_ID="ID_1033439446">
<node ID="ID_863378725" TREE_ID="ID_1160750105"/>
<node ID="ID_510901527" TREE_ID="ID_603294407">
<node ID="ID_814199933" TREE_ID="ID_1514744893"/>
</node>
<node ID="ID_1077833956" TREE_ID="ID_1053267160"/>
<node ID="ID_1045786380" TREE_ID="ID_18568736"/>
</node>
<node ID="ID_867549581" TREE_ID="ID_968262817">
<node ID="ID_420923210" TREE_ID="ID_690580554"/>
<node ID="ID_1075573648" TREE_ID="ID_1734983669"/>
<node ID="ID_1933998345" TREE_ID="ID_891454819"/>
<node ID="ID_1659377824" TREE_ID="ID_728243842"/>
<node ID="ID_197815749" TREE_ID="ID_885817074"/>
<node ID="ID_474615576" TREE_ID="ID_575701581"/>
<node ID="ID_1312063795" TREE_ID="ID_208351438"/>
<node ID="ID_1442259434" TREE_ID="ID_540033806"/>
</node>
<node ID="ID_1595346706" TREE_ID="ID_328752647">
<node ID="ID_1521791493" TREE_ID="ID_560464377"/>
</node>
</node>
<node ID="ID_350820944" TREE_ID="ID_828134313">
<node ID="ID_124536357" TREE_ID="ID_704816460">
<node ID="ID_484611722" TREE_ID="ID_1925339678"/>
<node ID="ID_1803679382" TREE_ID="ID_1318162221"/>
</node>
<node ID="ID_1870581397" TREE_ID="ID_587505537"/>
<node ID="ID_635766461" TREE_ID="ID_856122396"/>
<node ID="ID_1039492442" TREE_ID="ID_194057701">
<node ID="ID_1098160255" TREE_ID="ID_588004312"/>
</node>
<node ID="ID_1417498329" TREE_ID="ID_435274025"/>
<node ID="ID_1921540840" TREE_ID="ID_1096092615"/>
</node>
</node>
<node ID="ID_1904570561" TREE_ID="ID_1699196562">
<node ID="ID_610468140" TREE_ID="ID_945179914">
<node ID="ID_480970131" TREE_ID="ID_1277587828">
<node ID="ID_2115552" TREE_ID="ID_2799385"/>
</node>
</node>
<node ID="ID_1166447058" TREE_ID="ID_1933069780">
<node ID="ID_30606849" TREE_ID="ID_1032381288"/>
</node>
<node ID="ID_1975883227" TREE_ID="ID_1096604500">
<node ID="ID_258675706" TREE_ID="ID_1078024190">
<node ID="ID_1660673394" TREE_ID="ID_105607397">
<node ID="ID_318803045" TREE_ID="ID_1681469464"/>
</node>
</node>
</node>
<node ID="ID_1537121420" TREE_ID="ID_649064897">
<node ID="ID_1564155408" TREE_ID="ID_94515416"/>
<node ID="ID_935810328" TREE_ID="ID_1624059872"/>
</node>
</node>
<node ID="ID_1415439665" TREE_ID="ID_278811232">
<node ID="ID_242531132" TREE_ID="ID_1309209823"/>
<node ID="ID_191194162" TREE_ID="ID_713365547"/>
<node ID="ID_1243858114" TREE_ID="ID_227244035"/>
</node>
<node ID="ID_681247573" TREE_ID="ID_1857055763">
<node ID="ID_974751356" TREE_ID="ID_1517471653"/>
</node>
</node>
<node TEXT="Text correction, auto correction" FOLDED="true" ID="ID_1798578648" CREATED="1698968915454" MODIFIED="1698969157703">
<node ID="ID_1100238964" CREATED="1698969006299" MODIFIED="1698969006299" LINK="https://lifehacker.com/lifehacker-code-texter-windows-238306"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://lifehacker.com/lifehacker-code-texter-windows-238306">Lifehacker Code: Texter (Windows)</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1395531065" CREATED="1698968920725" MODIFIED="1698968920725" LINK="https://www.autotext-software.com/download.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.autotext-software.com/download.htm">Download Autotext</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_64611638" CREATED="1698968945901" MODIFIED="1698968945901" LINK="https://rajn.co/free-auto-text-word-expander-softwares-for-medical-transcription/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://rajn.co/free-auto-text-word-expander-softwares-for-medical-transcription/">Free Auto Text Word Expander Softwares for Medical Transcription</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="engines" FOLDED="true" ID="ID_512921089" CREATED="1688656833419" MODIFIED="1688656836008">
<node TEXT="potential" FOLDED="true" ID="ID_1209588897" CREATED="1710193206146" MODIFIED="1710193208482">
<node TEXT="whisper" FOLDED="true" ID="ID_1178815985" CREATED="1710193343795" MODIFIED="1710193346360">
<node ID="ID_1240737881" CREATED="1710193481568" MODIFIED="1710193481568" LINK="https://github.com/ufal/whisper_streaming"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/ufal/whisper_streaming">GitHub - ufal/whisper_streaming: Whisper realtime streaming for long speech-to-text transcription and translation</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1248772125" CREATED="1710193347787" MODIFIED="1710193347787" LINK="https://github.com/davabase/whisper_real_time"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/davabase/whisper_real_time">GitHub - davabase/whisper_real_time: Real time transcription with OpenAI Whisper.</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1248903375" CREATED="1710193209631" MODIFIED="1710193209631" LINK="https://huggingface.co/openai/whisper-large-v3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://huggingface.co/openai/whisper-large-v3">openai/whisper-large-v3 · Hugging Face</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_650084614" CREATED="1688656837086" MODIFIED="1688656837086" LINK="https://www.rev.com/blog/resources/the-5-best-open-source-speech-recognition-engines-apis"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.rev.com/blog/resources/the-5-best-open-source-speech-recognition-engines-apis">9. The 5 Best Open Source Speech Recognition Engines &amp; APIs | Rev</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="extensions" FOLDED="true" ID="ID_1593758737" CREATED="1689929367712" MODIFIED="1689929372003">
<node ID="ID_578692418" CREATED="1689929373369" MODIFIED="1689929373369" LINK="https://chrome.google.com/webstore/detail/vx/obopnfigmanifpiojfhebcegjepgaiif/related"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://chrome.google.com/webstore/detail/vx/obopnfigmanifpiojfhebcegjepgaiif/related">vx - Chrome Web Store</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Talon" FOLDED="true" ID="ID_272364081" CREATED="1688359983705" MODIFIED="1688359986334">
<node TEXT="install talon" ID="ID_931525285" CREATED="1688361862731" MODIFIED="1688361872300"/>
<node TEXT="run" ID="ID_292223971" CREATED="1688361872811" MODIFIED="1688361874331"/>
<node TEXT="check user directory through app" ID="ID_611608136" CREATED="1688361875828" MODIFIED="1688361885061"/>
<node TEXT="use that user directory to install" FOLDED="true" ID="ID_62844280" CREATED="1688361888500" MODIFIED="1688361899924">
<node ID="ID_1699225956" CREATED="1688360005045" MODIFIED="1688360005045" LINK="https://github.com/knausj85/knausj_talon"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/knausj85/knausj_talon">7. knausj85/knausj_talon: Config for talon for Mac, Windows and Linux. Very much in progress.</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="text capture" FOLDED="true" ID="ID_1051045335" CREATED="1624552146502" MODIFIED="1624552152936">
<node TEXT="Notepad alternative" FOLDED="true" ID="ID_1268369813" CREATED="1624552154000" MODIFIED="1624552197876">
<icon BUILTIN="unchecked"/>
<node TEXT="spellcheck" ID="ID_127003087" CREATED="1624552161649" MODIFIED="1624552165313"/>
<node TEXT="Full Dragon editing" ID="ID_757993949" CREATED="1624552166320" MODIFIED="1624552169968"/>
<node ID="ID_128097237" CREATED="1624570808187" MODIFIED="1624570808187" LINK="https://alternativeto.net/software/wordpad/?license=free"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/wordpad/?license=free">Free WordPad Alternatives | AlternativeTo</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1777471824" CREATED="1610317515523" MODIFIED="1610317546404"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h1 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 16.0pt; color: #1E4E79">
      Coding and Automation
    </h1>
  </body>
</html>
</richcontent>
<node TEXT="Principles" FOLDED="true" ID="ID_480381336" CREATED="1623444053729" MODIFIED="1623444057317">
<node ID="ID_1191192871" CREATED="1623444085567" MODIFIED="1623444085567" LINK="https://explosionduck.com/wp/introduction-to-voice-programming-part-three-best-practices/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://explosionduck.com/wp/introduction-to-voice-programming-part-three-best-practices/">Introduction to Voice Programming, Part Three: Best Practices</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Use Command Chains" ID="ID_1383867260" CREATED="1623444235124" MODIFIED="1623444240432"/>
</node>
<node TEXT="Grammar development" FOLDED="true" ID="ID_839739816" CREATED="1618615636082" MODIFIED="1618615640210">
<node TEXT="to implement" FOLDED="true" ID="ID_1112738584" CREATED="1624491254130" MODIFIED="1624491343136">
<node TEXT="done" FOLDED="true" ID="ID_987489312" CREATED="1695791984572" MODIFIED="1695791993240">
<node TEXT="separate work commands into one class" ID="ID_73730376" CREATED="1625801801841" MODIFIED="1625801812468"/>
<node TEXT="freeplane jump to node in map" ID="ID_1815459980" CREATED="1625239584942" MODIFIED="1625239597271"/>
<node TEXT="open" FOLDED="true" ID="ID_1410900750" CREATED="1624491360250" MODIFIED="1624491364731">
<node TEXT="open to place in mind map" ID="ID_638031287" CREATED="1624491280753" MODIFIED="1624491280753"/>
</node>
</node>
<node TEXT="priority" ID="ID_729032205" CREATED="1695792342020" MODIFIED="1695792344205"/>
<node TEXT="text editing" FOLDED="true" ID="ID_972661707" CREATED="1624658037651" MODIFIED="1624658059472">
<node TEXT="line actions" ID="ID_1621804166" CREATED="1624658105246" MODIFIED="1624661952245"/>
<node TEXT="something is something new to replace" ID="ID_461490882" CREATED="1624661929415" MODIFIED="1624661940234"/>
</node>
<node TEXT="Word scratchpad" ID="ID_262271395" CREATED="1625239604571" MODIFIED="1625239611612"/>
<node TEXT="portion of screen mirroring" ID="ID_158620553" CREATED="1624943043220" MODIFIED="1624943053760"/>
<node TEXT="user interface automation" FOLDED="true" ID="ID_1073217686" CREATED="1625009973535" MODIFIED="1625009983586">
<node ID="ID_1766339772" CREATED="1625010235005" MODIFIED="1625010235005" LINK="https://stackoverflow.com/questions/11825322/python-code-to-automate-desktop-activities-in-windows"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/11825322/python-code-to-automate-desktop-activities-in-windows">Python code to automate desktop activities in windows - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="OCR word recognition" ID="ID_687843700" CREATED="1624660391659" MODIFIED="1624660399982"/>
<node TEXT="sheets" FOLDED="true" ID="ID_505852114" CREATED="1624657047812" MODIFIED="1624657049850">
<node TEXT="jump to column on row" ID="ID_379807422" CREATED="1624657050865" MODIFIED="1624657077659"/>
</node>
<node TEXT="web browser" FOLDED="true" ID="ID_1624703161" CREATED="1624655333994" MODIFIED="1624655342211">
<node TEXT="new window" FOLDED="true" ID="ID_1605768922" CREATED="1624655345013" MODIFIED="1624655347266">
<node TEXT="tab to window" ID="ID_1123473478" CREATED="1624655351297" MODIFIED="1624655357006"/>
</node>
</node>
<node TEXT="close number window" ID="ID_806399870" CREATED="1624655381738" MODIFIED="1624655393869"/>
<node TEXT="dictionary, pulled from all sources" ID="ID_1414087823" CREATED="1624491280755" MODIFIED="1624491280755"/>
<node TEXT="speaking out of context captures dictation in new box, then user can run any operation on it" ID="ID_436326964" CREATED="1624491280758" MODIFIED="1624491280758"/>
<node TEXT="pre-interface" ID="ID_1199752773" CREATED="1624491280758" MODIFIED="1624491280758"/>
<node TEXT="tree grammar helper" ID="ID_1053175310" CREATED="1624491280760" MODIFIED="1624491280760"/>
<node TEXT="namespace" FOLDED="true" ID="ID_1842799227" CREATED="1624403805898" MODIFIED="1624403809543">
<node TEXT="easily recallable" ID="ID_1753397069" CREATED="1624405010284" MODIFIED="1624405024135"/>
<node TEXT="Unambiguous." ID="ID_261695648" CREATED="1624405029928" MODIFIED="1624405034140"/>
</node>
</node>
<node TEXT="to do" FOLDED="true" ID="ID_886072494" CREATED="1624056527512" MODIFIED="1624056530992">
<node TEXT="change tab" ID="ID_1254672244" CREATED="1624056534304" MODIFIED="1624056544371"/>
<node TEXT="dynamic add space" FOLDED="true" ID="ID_195153584" CREATED="1624056545354" MODIFIED="1624056584551">
<node TEXT="prefix with space, until go" ID="ID_1649974445" CREATED="1624138911754" MODIFIED="1624139031918"/>
</node>
<node TEXT="add space to the end of punctuation" ID="ID_1988864468" CREATED="1624056737803" MODIFIED="1624056743387"/>
<node TEXT="change toml extension" ID="ID_927694096" CREATED="1624056586754" MODIFIED="1624056616760"/>
<node TEXT="why when I think something, does it not simply happen? Why does this require effort?" ID="ID_1504005049" CREATED="1624056797145" MODIFIED="1624056797145"/>
</node>
<node TEXT="objects" FOLDED="true" ID="ID_209237680" CREATED="1624052841922" MODIFIED="1624052846524">
<node TEXT="string" FOLDED="true" ID="ID_474177905" CREATED="1624053766152" MODIFIED="1624053770129">
<node TEXT="default mode:" FOLDED="true" ID="ID_1822789563" CREATED="1624055007983" MODIFIED="1624055045584">
<node TEXT="no spaces for prefix or suffix" ID="ID_201664120" CREATED="1624053853269" MODIFIED="1624053858401"/>
</node>
<node TEXT="dictation mode:" FOLDED="true" ID="ID_328861665" CREATED="1624055073962" MODIFIED="1624055114202">
<node TEXT="space as suffix" ID="ID_1504955589" CREATED="1624055121767" MODIFIED="1624055128941"/>
<node TEXT="prefix with space if the last command was text" ID="ID_1802136507" CREATED="1624055534777" MODIFIED="1624055593561"/>
</node>
<node TEXT="Dragon sends words with spaces between" FOLDED="true" ID="ID_1111431668" CREATED="1624053775913" MODIFIED="1624053850683">
<node TEXT="no spaces for prefix or suffix" ID="ID_567161468" CREATED="1624053853269" MODIFIED="1624053858401"/>
</node>
</node>
<node TEXT="word" FOLDED="true" ID="ID_313187679" CREATED="1624052847981" MODIFIED="1624052853756">
<node TEXT="default suffix: space" ID="ID_384831192" CREATED="1624052854962" MODIFIED="1624052871935"/>
</node>
<node TEXT="punctuation" FOLDED="true" ID="ID_111374641" CREATED="1624052894160" MODIFIED="1624052896393">
<node TEXT="checks to see if there is a space to the left" ID="ID_1980532627" CREATED="1624052897530" MODIFIED="1624052908337"/>
<node TEXT="If space, delete, add punctuation" ID="ID_160943608" CREATED="1624052913300" MODIFIED="1624052950950"/>
</node>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_202704222" CREATED="1618615643058" MODIFIED="1618615648597">
<node ID="ID_509007814" CREATED="1618615650217" MODIFIED="1618615650217" LINK="http://shorttalk-emacs.sourceforge.net/ShortTalk/index.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://shorttalk-emacs.sourceforge.net/ShortTalk/index.html">ShortTalk -- home page</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="application interfacing" FOLDED="true" ID="ID_1461381474" CREATED="1623966389136" MODIFIED="1695077551844">
<arrowlink DESTINATION="ID_1904570561"/>
<node ID="ID_683982005" CREATED="1623966516480" MODIFIED="1623966516480" LINK="https://pywinauto.readthedocs.io/en/latest/#some-similar-tools-for-comparison"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pywinauto.readthedocs.io/en/latest/#some-similar-tools-for-comparison">What is pywinauto — pywinauto 0.6.8 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Research" FOLDED="true" ID="ID_1861343679" CREATED="1610314914700" MODIFIED="1610318826949">
<node ID="ID_1954224287" CREATED="1685159233929" MODIFIED="1685159233929" LINK="https://spectrum.ieee.org/programming-by-voice-may-be-the-next-frontier-in-software-development#toggle-gdpr"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://spectrum.ieee.org/programming-by-voice-may-be-the-next-frontier-in-software-development#toggle-gdpr">Programming by Voice May Be the Next Frontier in Software Development - IEEE Spectrum</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1410503283" CREATED="1610382958714" MODIFIED="1610382958714" LINK="https://handsfreecoding.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://handsfreecoding.org/">Hands-Free Coding | A hacker's guide to ditching the keyboard and mouse</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1756326659" CREATED="1610314933381" MODIFIED="1610315477776" LINK="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34641"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34641">KnowBrainer Speech Recognition Forums - Merits of Vocola vs Talon vs Caster vs Serenade etc</a>
    </p>
  </body>
</html>
</richcontent>
<font SIZE="10"/>
</node>
<node ID="ID_295361619" CREATED="1597164150222" MODIFIED="1610315477779" LINK="http://knowbrainer.com/forums/forum/messageview.cfm?catid=9&amp;threadid=30361"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://knowbrainer.com/forums/forum/messageview.cfm?catid=9&amp;threadid=30361">KnowBrainer Speech Recognition Forums - Current State MSR vs Dragon</a>
  </body>
</html>
</richcontent>
<font SIZE="10"/>
</node>
<node ID="ID_1888940408" CREATED="1597187844981" MODIFIED="1610315477779" LINK="http://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34206&amp;highlight_key=y&amp;keyword1=vocola"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.knowbrainer.com/forums/forum/messageview.cfm?catid=25&amp;threadid=34206&amp;highlight_key=y&amp;keyword1=vocola">KnowBrainer Speech Recognition Forums - Voice Utilities you use?</a>
  </body>
</html>
</richcontent>
<font SIZE="10"/>
</node>
<node ID="ID_1446118710" CREATED="1597334367766" MODIFIED="1610315477782" LINK="https://fosspost.org/alternative-software/developers/open-source-speech-recognition-speech-to-text"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://fosspost.org/alternative-software/developers/open-source-speech-recognition-speech-to-text">5 Good Open Source Speech Recognition Systems</a>
  </body>
</html>
</richcontent>
<font SIZE="10"/>
</node>
<node ID="ID_1962370009" CREATED="1601333476023" MODIFIED="1610315477783" LINK="https://sourceforge.net/projects/wsrappmacs/files/Speech%20Macros/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sourceforge.net/projects/wsrappmacs/files/Speech%20Macros/">WSR Application Macros - Browse /Speech Macros at SourceForge.net</a>
  </body>
</html>
</richcontent>
<font SIZE="10"/>
</node>
<node FOLDED="true" ID="ID_1868809042" CREATED="1589925964893" MODIFIED="1589925964893" LINK="https://github.com/Ravbug/GlovePIE/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Ravbug/GlovePIE/releases">Releases &#183; Ravbug/GlovePIE &#183; GitHub</a>
  </body>
</html>
</richcontent>
<node ID="ID_1402933943" CREATED="1589927742156" MODIFIED="1589927742156" LINK="https://github.com/Ravbug/GlovePIE/wiki/GlovePIE-Scripts-and-Syntax"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Ravbug/GlovePIE/wiki/GlovePIE-Scripts-and-Syntax">GlovePIE Scripts and Syntax &#183; Ravbug/GlovePIE Wiki &#183; GitHub</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1017180706" CREATED="1589981489805" MODIFIED="1589981489805" LINK="http://www.armaholic.com/page.php?id=23281"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.armaholic.com/page.php?id=23281">GlovePIE Basic Script plus Launcher - Misc and Utilities - Armaholic</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_378422687" CREATED="1610317515525" MODIFIED="1610317515525" LINK="https://handsfreecoding.org/2015/03/14/dictating-code/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://handsfreecoding.org/2015/03/14/dictating-code/">Dictating Code | Hands-Free Coding</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_619533639" CREATED="1610317515525" MODIFIED="1610317515525" LINK="https://sourceforge.net/projects/voicecode/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://sourceforge.net/projects/voicecode/">VoiceCode Programming by Voice Toolbox download | SourceForge.net</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1612878547" CREATED="1610317515526" MODIFIED="1610317515526" LINK="https://explosionduck.com/wp/introduction-to-voice-programming-part-three-best-practices/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://explosionduck.com/wp/introduction-to-voice-programming-part-three-best-practices/">Introduction to Voice Programming, Part Three: Best Practices</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_35980255" CREATED="1610317750778" MODIFIED="1610317750778" LINK="http://vocola.net/programming-by-voice-FAQ.html#section4.6."><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://vocola.net/programming-by-voice-FAQ.html#section4.6.">Frequent Asked Questions (FAQ) on programming by voice</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_120233269" CREATED="1610317750784" MODIFIED="1610317750784" LINK="https://medium.com/@robindji/tactical-recovery-guide-for-wrist-arm-repetitive-strain-injuries-rsi-part-2-of-my-rsi-series-8f648bd55afe"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://medium.com/@robindji/tactical-recovery-guide-for-wrist-arm-repetitive-strain-injuries-rsi-part-2-of-my-rsi-series-8f648bd55afe">Tactical Recovery Guide for Wrist &amp; Arm Repetitive Strain Injuries (RSI) — Part 2 of my RSI Series | by Robin David Ji | Aug, 2020 | Medium</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1685105557" CREATED="1610317686623" MODIFIED="1610317686623" LINK="https://talonvoice.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
      <a href="https://talonvoice.com/">Talon</a>
    </h2>
  </body>
</html>
</richcontent>
<node ID="ID_1501430656" CREATED="1610317686624" MODIFIED="1610317686624" LINK="https://www.youtube.com/watch?v=ddFI63dgpaI&amp;list=PL2wTcyeSmhsbPZYt65mRiKSeuq6WU-rXZ&amp;index=2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.youtube.com/watch?v=ddFI63dgpaI&amp;list=PL2wTcyeSmhsbPZYt65mRiKSeuq6WU-rXZ&amp;index=2">Talon Voice - Python Demo - YouTube</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_592072461" CREATED="1610317686624" MODIFIED="1610317686624" LINK="https://talon.wiki/getting_started/#public-vs-beta-vs-legacy"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://talon.wiki/getting_started/#public-vs-beta-vs-legacy">Getting Started | Talon Wiki</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Helper Apps" FOLDED="true" ID="ID_639744111" CREATED="1610318534901" MODIFIED="1610318541838">
<node ID="ID_386907020" CREATED="1610318971936" MODIFIED="1610318971936" LINK="http://sikulix.com/quickstart/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://sikulix.com/quickstart/">SikuliX - QUICKSTART</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1228011600" CREATED="1596746719398" MODIFIED="1610317922828" LINK="https://github.com/zsims/hunt-and-peck"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/zsims/hunt-and-peck">Show Numbers Alternative - GitHub - zsims/hunt-and-peck: Simple vimium/vimperator style navigation for Windows applications based on the UI Automation framework.</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="O CR" FOLDED="true" ID="ID_90618567" CREATED="1610672278949" MODIFIED="1610672297363">
<node ID="ID_1203641023" CREATED="1610672300109" MODIFIED="1610672300109" LINK="https://handsfreecoding.org/2020/12/24/gaze-ocr-under-the-hood/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://handsfreecoding.org/2020/12/24/gaze-ocr-under-the-hood/">Gaze OCR: Under the Hood | Hands-Free Coding</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1637891734" CREATED="1582958483797" MODIFIED="1582958483797" LINK="https://github.com/ahkscript/awesome-AutoHotkey"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/ahkscript/awesome-AutoHotkey">GitHub - ahkscript/awesome-AutoHotkey: A curated list of awesome AutoHotkey libraries, library distributions, scripts, tools and resources.</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Win Snap" FOLDED="true" ID="ID_426899623" CREATED="1582951197628" MODIFIED="1582951202659">
<node ID="ID_294599464" CREATED="1582951193633" MODIFIED="1582951193633" LINK="https://github.com/henryxrl/WinSnap_Extras"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/henryxrl/WinSnap_Extras">GitHub - henryxrl/WinSnap_Extras: This simple script is written in AutoHotKey. It further extends the Windows' window snapping functionality by splitting screen into halfs/thirds/quarters. It's even able to divide the screen into nine windows.</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_842847517" CREATED="1554996384139" MODIFIED="1554996384139" LINK="http://www.donationcoder.com/forum/index.php?topic=18189.msg162881"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.donationcoder.com/forum/index.php?topic=18189.msg162881">New program: Ethervane ActiveHotkeys (freeware) - DonationCoder.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1571532523" CREATED="1589927391436" MODIFIED="1589927391436" LINK="http://andersmalmgren.github.io/FreePIE/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://andersmalmgren.github.io/FreePIE/">FreePIE (Programmable Input Emulator)</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Operations" ID="ID_1857243501" CREATED="1624403810528" MODIFIED="1624403815947"/>
<node TEXT="Setup" ID="ID_780427274" CREATED="1610312496443" MODIFIED="1610312813817"/>
<node TEXT="Microphone" FOLDED="true" ID="ID_312435133" CREATED="1610312923219" MODIFIED="1610312923219">
<node TEXT="New" ID="ID_1169759423" CREATED="1641447783918" MODIFIED="1641447787255"/>
<node TEXT="muting" FOLDED="true" ID="ID_766042262" CREATED="1690570854325" MODIFIED="1690570857040">
<node ID="ID_151471761" CREATED="1690571047737" MODIFIED="1690571047737" LINK="https://www.windowsdigitals.com/windows-11-mute-microphone-hotkey/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.windowsdigitals.com/windows-11-mute-microphone-hotkey/">7. Windows 11 Mute Microphone Hotkey (How to)</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="set up with mute button on usb interface facing person" ID="ID_1883065947" CREATED="1690571003269" MODIFIED="1690571014794"/>
</node>
<node TEXT="Setting up the microphone is crucial" ID="ID_676328370" CREATED="1610312923219" MODIFIED="1610312923219"/>
<node TEXT="others" FOLDED="true" ID="ID_1753013057" CREATED="1697904279896" MODIFIED="1697904284049">
<node TEXT="Microphone: desktop boom" FOLDED="true" ID="ID_873441805" CREATED="1610312923223" MODIFIED="1619539578222">
<node TEXT="set dial to 75%" ID="ID_531870448" CREATED="1619539579625" MODIFIED="1619539736601"/>
<node TEXT="Sound Control Panel" FOLDED="true" ID="ID_52139364" CREATED="1619539586875" MODIFIED="1619539598960">
<node TEXT="Custom: AGC On" ID="ID_925571859" CREATED="1619539600251" MODIFIED="1619539688671"/>
<node TEXT="Advanced: signal enhancements on" ID="ID_268024953" CREATED="1619539690311" MODIFIED="1619539718563"/>
</node>
</node>
</node>
<node TEXT="Never sent a maximum volume, it will introduce noise" ID="ID_503529210" CREATED="1610312923225" MODIFIED="1610312923225"/>
<node TEXT="Go directly through the microphone" ID="ID_920110432" CREATED="1610312923262" MODIFIED="1610312923262"/>
<node TEXT="position" FOLDED="true" ID="ID_1274008667" CREATED="1697904345153" MODIFIED="1697904396578">
<node TEXT="the microphones should be positioned towards the edge of your mouth, 1/2 to one inch away from the corner." ID="ID_1733921007" CREATED="1610312923292" MODIFIED="1610312923292"/>
</node>
<node TEXT="Don&apos;t use Voicemeeter (VB-Audio)" ID="ID_599658029" CREATED="1610312923275" MODIFIED="1610312923275"/>
<node TEXT="Wireless microphone" FOLDED="true" ID="ID_1338419171" CREATED="1610312923280" MODIFIED="1610312923280">
<node TEXT="Digital" ID="ID_764332448" CREATED="1697904308125" MODIFIED="1697904310059"/>
<node TEXT="don&apos;t use" FOLDED="true" ID="ID_1879894142" CREATED="1697904311116" MODIFIED="1697904324461">
<node TEXT="VHF" ID="ID_1460698381" CREATED="1610312923284" MODIFIED="1610312923284"/>
</node>
<node TEXT="Set volume to 75%," ID="ID_692047047" CREATED="1610312923287" MODIFIED="1610312923287"/>
</node>
<node TEXT="Noise Reduction, Suppression" FOLDED="true" ID="ID_1026368550" CREATED="1619535124706" MODIFIED="1622837364175">
<font BOLD="true"/>
<node TEXT="Files Needed" FOLDED="true" ID="ID_1043692451" CREATED="1623685323551" MODIFIED="1623685333578">
<node TEXT="Equalizer APO" FOLDED="true" ID="ID_483542719" CREATED="1622837286154" MODIFIED="1622837300388">
<node TEXT="VST" FOLDED="true" ID="ID_877505536" CREATED="1622837264769" MODIFIED="1622837268148">
<node TEXT="C:\GD_sync\Apps\Voice\windows_rnnoise_bin_x64\bin\vst\librnnoise_vst.dll" ID="ID_1392633134" CREATED="1622837269576" MODIFIED="1622837269576"/>
</node>
</node>
</node>
<node TEXT="Set Up" FOLDED="true" ID="ID_1679811344" CREATED="1623685345174" MODIFIED="1623685353584">
<node FOLDED="true" ID="ID_430881404" CREATED="1622837184446" MODIFIED="1622837184446" LINK="https://medium.com/@bssankaran/free-and-open-source-software-noise-cancelling-for-working-from-home-edb1b4e9764e"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/@bssankaran/free-and-open-source-software-noise-cancelling-for-working-from-home-edb1b4e9764e">Free and Open Source Software Noise Cancelling for Working from Home | by Sankaran Srinivasan | Medium</a>
  </body>
</html>
</richcontent>
<node ID="ID_539029098" CREATED="1622831590064" MODIFIED="1622831590064" LINK="https://antlionaudio.com/blogs/news/free-active-noise-suppression-without-rtx-voice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://antlionaudio.com/blogs/news/free-active-noise-suppression-without-rtx-voice">(Free) Active Noise Suppression Without RTX Voice! – Antlion Audio</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Video camera" FOLDED="true" ID="ID_1938107983" CREATED="1569648538961" MODIFIED="1610313098251">
<node TEXT="Hardware" FOLDED="true" ID="ID_1491286970" CREATED="1715182075302" MODIFIED="1715182078627">
<node TEXT="auto framing" ID="ID_466473234" CREATED="1715182079388" MODIFIED="1715182082423"/>
</node>
<node TEXT="Software" FOLDED="true" ID="ID_298087649" CREATED="1715182098363" MODIFIED="1715182100999">
<node TEXT="Head Tracking" FOLDED="true" ID="ID_1308996605" CREATED="1684870395755" MODIFIED="1684870400189">
<node POSITION="bottom_or_right" ID="ID_498270655" TREE_ID="ID_137157190">
<node ID="ID_575781285" TREE_ID="ID_382029826">
<node ID="ID_1806774512" TREE_ID="ID_1798707262">
<node ID="ID_1245942075" TREE_ID="ID_1907147576"/>
<node ID="ID_164626981" TREE_ID="ID_1699764114">
<node ID="ID_46224590" TREE_ID="ID_1472987350">
<node ID="ID_848074255" TREE_ID="ID_261965582"/>
</node>
<node ID="ID_1039215663" TREE_ID="ID_1251536089">
<node ID="ID_1184617494" TREE_ID="ID_186921778"/>
<node ID="ID_1657730060" TREE_ID="ID_1793329504"/>
</node>
</node>
</node>
<node ID="ID_1786046109" TREE_ID="ID_444726818">
<node ID="ID_380182879" TREE_ID="ID_227617330">
<node ID="ID_178323116" TREE_ID="ID_392237554">
<node ID="ID_215668644" TREE_ID="ID_941147056"/>
</node>
</node>
</node>
<node ID="ID_475969658" TREE_ID="ID_1905526315"/>
</node>
<node ID="ID_415174869" TREE_ID="ID_138821388">
<node ID="ID_396048875" TREE_ID="ID_284966746"/>
<node ID="ID_321411861" TREE_ID="ID_233943612"/>
<node ID="ID_1715329084" TREE_ID="ID_936114763"/>
<node ID="ID_1671902997" TREE_ID="ID_674974447">
<node ID="ID_1824225444" TREE_ID="ID_1332182912"/>
<node ID="ID_1868112128" TREE_ID="ID_1968409001"/>
</node>
<node ID="ID_1813763444" TREE_ID="ID_957623166">
<node ID="ID_1424954598" TREE_ID="ID_97980957">
<node ID="ID_1429805959" TREE_ID="ID_1257444552"/>
</node>
<node ID="ID_92209426" TREE_ID="ID_1309838975"/>
</node>
</node>
<node ID="ID_560588249" TREE_ID="ID_1327876469"/>
</node>
<node ID="ID_1438262953" CREATED="1712707793262" MODIFIED="1712707793262" LINK="https://steamcommunity.com/sharedfiles/filedetails/?id=3038803528"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://steamcommunity.com/sharedfiles/filedetails/?id=3038803528">Steam Community :: Guide :: Headtracking with a webcam or phone</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_879745620" CREATED="1695953009350" MODIFIED="1695953009350" LINK="https://andersmalmgren.github.io/FreePIE/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://andersmalmgren.github.io/FreePIE/">FreePIE (Programmable Input Emulator)</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Android" FOLDED="true" POSITION="bottom_or_right" ID="ID_372295466" CREATED="1712707655248" MODIFIED="1712707659044">
<node ID="ID_776352295" CREATED="1712707659662" MODIFIED="1712707659662" LINK="https://github.com/opentrack/opentrack/wiki/Smartphone-Headtracking"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/opentrack/opentrack/wiki/Smartphone-Headtracking">Smartphone Headtracking · opentrack/opentrack Wiki · GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="ps3 cam" POSITION="bottom_or_right" ID="ID_1623133983" CREATED="1696375765866" MODIFIED="1696375772291"/>
<node TEXT="potential" FOLDED="true" POSITION="bottom_or_right" ID="ID_1836072177" CREATED="1695406794411" MODIFIED="1695954740391">
<font NAME="Arial Black"/>
<node ID="ID_214487943" CREATED="1712706795570" MODIFIED="1712706795570" LINK="https://precisiongazemouse.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://precisiongazemouse.org/">Precision Gaze Mouse</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_618088578" CREATED="1712705879456" MODIFIED="1712705879456" LINK="https://ofoa.net/eagleeyes/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://ofoa.net/eagleeyes/">EagleEyes – The Opportunity Foundation of America</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1206379507" CREATED="1712705573906" MODIFIED="1712705573906" LINK="https://www.inference.org.uk/opengazer/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.inference.org.uk/opengazer/">Opengazer: open-source gaze tracker for ordinary webcams</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="open track + aitrack or neuralnet" FOLDED="true" ID="ID_1070415818" CREATED="1709942391337" MODIFIED="1712707920084">
<node TEXT="reference" FOLDED="true" ID="ID_236960748" CREATED="1709943251653" MODIFIED="1709943254784">
<node ID="ID_382912987" CREATED="1712707899726" MODIFIED="1712707899726" LINK="https://steamcommunity.com/sharedfiles/filedetails/?id=3038803528"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://steamcommunity.com/sharedfiles/filedetails/?id=3038803528">Steam Community :: Guide :: Headtracking with a webcam or phone</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_382222061" CREATED="1709943273788" MODIFIED="1709943273788" LINK="https://github.com/opentrack/opentrack/issues/120"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/opentrack/opentrack/issues/120">Mouse emulation · Issue #120 · opentrack/opentrack · GitHub</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_693379735" CREATED="1709942481984" MODIFIED="1709942481984" LINK="https://www.reddit.com/r/StarWarsSquadrons/comments/kbpq2s/use_opentrack_aitrack_to_get_headtracking_with/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/StarWarsSquadrons/comments/kbpq2s/use_opentrack_aitrack_to_get_headtracking_with/">Use OpenTrack + AITrack to get headtracking with just a normal webcam : r/StarWarsSquadrons</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="open track settings" FOLDED="true" ID="ID_1262114122" CREATED="1709943258942" MODIFIED="1709943265025">
<node TEXT="Options: disable all,except Yaw=Yaw; Pitch=Pitch[Invert]" ID="ID_1342755105" CREATED="1709943492050" MODIFIED="1709943492052"/>
<node TEXT="Mapping:" FOLDED="true" ID="ID_1266147080" CREATED="1709943288230" MODIFIED="1709943537689">
<node TEXT="Yaw:" FOLDED="true" ID="ID_1711206037" CREATED="1709943538536" MODIFIED="1709943552684">
<node TEXT="Max Input: 30" ID="ID_1408128326" CREATED="1709943552959" MODIFIED="1709944421380"/>
</node>
<node TEXT="Pitch:" FOLDED="true" ID="ID_168438550" CREATED="1709943538536" MODIFIED="1709944434388">
<node TEXT="Max Input: 30" ID="ID_530178143" CREATED="1709943552959" MODIFIED="1709944421380"/>
</node>
</node>
<node TEXT="In Mouse emulation options: Map mouse X to Yaw, Map mouse x to Pitch" ID="ID_853380092" CREATED="1709943288230" MODIFIED="1709943288230"/>
</node>
<node FOLDED="true" ID="ID_1911363648" CREATED="1709941724175" MODIFIED="1709941724175" LINK="https://github.com/opentrack/opentrack/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/opentrack/opentrack/releases">Releases · opentrack/opentrack</a>
  </body>
</html>
</richcontent>
<node ID="ID_807635705" CREATED="1709941863784" MODIFIED="1709941863784" LINK="https://github.com/opentrack/opentrack/issues/1234"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/opentrack/opentrack/issues/1234">Mouse not moving with mouse emulation. · Issue #1234 · opentrack/opentrack · GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="supporting" ID="ID_1249141531" CREATED="1709942408593" MODIFIED="1709942411635"/>
</node>
<node ID="ID_999211243" CREATED="1709942383191" MODIFIED="1709942383191" LINK="https://sourceforge.net/projects/facetracknoir/files/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sourceforge.net/projects/facetracknoir/files/">facetracknoir - Browse Files at SourceForge.net</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_735683435" CREATED="1709941713015" MODIFIED="1709941713015" LINK="https://github.com/AIRLegend/aitrack/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/AIRLegend/aitrack/releases">Releases · AIRLegend/aitrack</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_280991497" CREATED="1704329647360" MODIFIED="1704329647360" LINK="https://github.com/nexayq/webcam_cursor"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/nexayq/webcam_cursor">GitHub - nexayq/webcam_cursor: Move mouse cursor with your head</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_100463149" CREATED="1684965008023" MODIFIED="1684965008023" LINK="https://sourceforge.net/projects/opentrack.mirror/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sourceforge.net/projects/opentrack.mirror/">opentrack download | SourceForge.net</a>
  </body>
</html>
</richcontent>
<node ID="ID_172313209" CREATED="1695963591706" MODIFIED="1695963591706" LINK="https://forum.il2sturmovik.com/topic/34403-a-complete-guide-to-set-up-head-tracking-opentrack/?tab=comments#comment-580169"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://forum.il2sturmovik.com/topic/34403-a-complete-guide-to-set-up-head-tracking-opentrack/?tab=comments#comment-580169">A complete guide to set up Head-tracking (Opentrack) - Hardware, Software and Controllers - IL-2 Sturmovik Forum</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="hardware" FOLDED="true" ID="ID_1948957613" CREATED="1695965268840" MODIFIED="1695965271286">
<node ID="ID_575498052" CREATED="1695965274850" MODIFIED="1695965274850" LINK="https://www.zonetrigger.com/articles/high-framerate-cameras/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.zonetrigger.com/articles/high-framerate-cameras/">High framerate webcams - 60, 120 fps...</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="ps3 eye camera" FOLDED="true" ID="ID_1570053433" CREATED="1695964755695" MODIFIED="1695964760004">
<node ID="ID_461906824" CREATED="1695964771061" MODIFIED="1695964771061" LINK="https://www.amazon.com/Sony-Station-Camera-Packaging-PlayStation-3/dp/B0735KNH2X/ref=d_pd_sbs_sccl_4_1/142-2899133-6707457?pd_rd_w=T3C4I&amp;content-id=amzn1.sym.7a9b9953-4675-430a-a4f6-ea3f74308c2f&amp;pf_rd_p=7a9b9953-4675-430a-a4f6-ea3f74308c2f&amp;pf_rd_r=MN4J0HC71D1K7XQMRH93&amp;pd_rd_wg=D8aRt&amp;pd_rd_r=98159814-9325-45a5-bb68-0c1060e979b1&amp;pd_rd_i=B0735KNH2X&amp;psc=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/Sony-Station-Camera-Packaging-PlayStation-3/dp/B0735KNH2X/ref=d_pd_sbs_sccl_4_1/142-2899133-6707457?pd_rd_w=T3C4I&amp;content-id=amzn1.sym.7a9b9953-4675-430a-a4f6-ea3f74308c2f&amp;pf_rd_p=7a9b9953-4675-430a-a4f6-ea3f74308c2f&amp;pf_rd_r=MN4J0HC71D1K7XQMRH93&amp;pd_rd_wg=D8aRt&amp;pd_rd_r=98159814-9325-45a5-bb68-0c1060e979b1&amp;pd_rd_i=B0735KNH2X&amp;psc=1">Amazon.com: Sony Play Station Eye Camera for PS3 (Bulk Packaging) : Video Games</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1259811561" CREATED="1695964761248" MODIFIED="1695964761248" LINK="https://github.com/opentrack/opentrack/issues/1475"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/opentrack/opentrack/issues/1475">PS3 Eye Camera not working on Windows 11 21H2 (PS3 Eye Open Driver issues) · Issue #1475 · opentrack/opentrack</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node ID="ID_205010252" CREATED="1695952932146" MODIFIED="1695952932146" LINK="https://www.reddit.com/r/oculus/comments/1fpf7p/is_there_any_apps_to_map_head_tracking_to_mouse/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/oculus/comments/1fpf7p/is_there_any_apps_to_map_head_tracking_to_mouse/">Is there any apps to map head tracking to mouse movements? : r/oculus</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1683943006" CREATED="1695952611701" MODIFIED="1695952611701" LINK="https://forums.flightsimulator.com/t/a-review-of-several-free-head-tracking-alternatives-to-use-with-flight/237659"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://forums.flightsimulator.com/t/a-review-of-several-free-head-tracking-alternatives-to-use-with-flight/237659">A review of several “free” head-tracking alternatives to use with Flight - General Discussion &amp; Community Support / Tech Talk - Microsoft Flight Simulator Forums</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="two high cpu" FOLDED="true" ID="ID_1888344281" CREATED="1695583376672" MODIFIED="1695583380276">
<node ID="ID_953313030" CREATED="1695406877450" MODIFIED="1695406877450" LINK="https://github.com/google/project-gameface"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/google/project-gameface">GitHub - google/project-gameface</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_460749024" CREATED="1664465895323" MODIFIED="1664465895323" LINK="https://alternativeto.net/software/handsfree-js/about/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/handsfree-js/about/">Handsfree.js: App Reviews, Features, Pricing &amp; Download | AlternativeTo</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="inaccurate" FOLDED="true" ID="ID_241656527" CREATED="1712706337189" MODIFIED="1712706339227">
<node TEXT="Camera Mouse" FOLDED="true" ID="ID_1739847844" CREATED="1695942619791" MODIFIED="1695942622848">
<node ID="ID_1754601105" CREATED="1695942615510" MODIFIED="1695942615510" LINK="http://cameramouse.org/downloads.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://cameramouse.org/downloads.html">Downloads / Camera Mouse</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_751451917" CREATED="1695944996414" MODIFIED="1695944996414" LINK="http://cameramouse.bu.edu/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://cameramouse.bu.edu/">Camera Mouse Research</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="reference point" POSITION="bottom_or_right" ID="ID_364410027" CREATED="1695952457282" MODIFIED="1695952476094"/>
</node>
<node FOLDED="true" ID="ID_1528199422" CREATED="1702074907090" MODIFIED="1702074907090" LINK="https://web.archive.org/web/20071021025743/http://vrs.iit.nrc.ca/Nouse/download.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://web.archive.org/web/20071021025743/http://vrs.iit.nrc.ca/Nouse/download.html">Nouse Perceptual Vision Interface (NRC-IIT Video Recognition Systems)</a>
  </body>
</html>
</richcontent>
<node ID="ID_33899707" CREATED="1702074917317" MODIFIED="1702074917317" LINK="https://web.archive.org/web/20070910075049/http://www.cv.iit.nrc.ca/people/dmitry.html#fg2002"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://web.archive.org/web/20070910075049/http://www.cv.iit.nrc.ca/people/dmitry.html#fg2002">Dmitry Gorodnichy: Homepage</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1166592373" CREATED="1702074681916" MODIFIED="1702074681916" LINK="https://dl.acm.org/doi/abs/10.1145/3287076"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dl.acm.org/doi/abs/10.1145/3287076">HeadGesture: Hands-Free Input Approach Leveraging Head Movements for HMD Devices: Proceedings of the ACM on Interactive, Mobile, Wearable and Ubiquitous Technologies: Vol 2, No 4</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1542091913" CREATED="1702074395965" MODIFIED="1702074395965" LINK="http://www.shifz.org/brainbay/publications/ICCHP_brainbay.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.shifz.org/brainbay/publications/ICCHP_brainbay.pdf">Microsoft Word - abstract.doc</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Eye tracking" FOLDED="true" ID="ID_796580979" CREATED="1610319801816" MODIFIED="1700004336659">
<node ID="ID_860400361" CREATED="1700004341239" MODIFIED="1700004341239" LINK="https://gazerecorder.com/gazepointer/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://gazerecorder.com/gazepointer/">GazePointer | Real-Time WebCam Eye-Tracking Software | Free</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_11591744" CREATED="1610319814954" MODIFIED="1610319814954" LINK="https://support.microsoft.com/en-us/windows/get-started-with-eye-control-in-windows-10-1a170a20-1083-2452-8f42-17a7d4fe89a9"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://support.microsoft.com/en-us/windows/get-started-with-eye-control-in-windows-10-1a170a20-1083-2452-8f42-17a7d4fe89a9">Get started with eye control in Windows 10</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="facial recognition" FOLDED="true" ID="ID_1894887079" CREATED="1569648543699" MODIFIED="1569648557611">
<node ID="ID_600336135" CREATED="1686353225994" MODIFIED="1686353225994" LINK="https://alternativeto.net/software/handsfree-js/about/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/handsfree-js/about/">Handsfree.js: App Reviews, Features, Pricing &amp; Download | AlternativeTo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="lip reading" ID="ID_868139001" CREATED="1569648557980" MODIFIED="1569648561973"/>
<node TEXT="RoboRealm" FOLDED="true" ID="ID_1178755616" CREATED="1695943155806" MODIFIED="1695943162473">
<node TEXT="https://www.roborealm.com/" ID="ID_1864554618" CREATED="1695943163410" MODIFIED="1695943163410" LINK="https://www.roborealm.com/"/>
<node TEXT="links" FOLDED="true" ID="ID_896921547" CREATED="1695943177584" MODIFIED="1695943182887">
<node ID="ID_103468042" CREATED="1695944470093" MODIFIED="1695944470093" LINK="https://web.archive.org/web/20070314011053/http://www.roborealm.com/downloads/RoboRealm.zip"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://web.archive.org/web/20070314011053/http://www.roborealm.com/downloads/RoboRealm.zip">Wayback Machine (archive.org)</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_816686881" CREATED="1695943734396" MODIFIED="1695943734396" LINK="http://www.roborealm.com/forum/index.php?thread_id=4770"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.roborealm.com/forum/index.php?thread_id=4770">RoboRealm - Old freeware roborealm is still available from archive.org</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Direct" FOLDED="true" ID="ID_1674141490" CREATED="1695077517338" MODIFIED="1695077520641">
<node ID="ID_276521038" CREATED="1700003804937" MODIFIED="1700003804937" LINK="https://www.ucdenver.edu/centers/center-for-inclusive-design-and-engineering/community-engagement/colorado-assistive-technology-act-program/technology-and-transition-to-employment/alternative-mice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ucdenver.edu/centers/center-for-inclusive-design-and-engineering/community-engagement/colorado-assistive-technology-act-program/technology-and-transition-to-employment/alternative-mice">Alternative Mice</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Feet" FOLDED="true" ID="ID_77129652" CREATED="1695925854528" MODIFIED="1695925859710">
<node TEXT="prevent dragging when clicking" FOLDED="true" ID="ID_1215144166" CREATED="1696098712683" MODIFIED="1696098718666">
<node TEXT="&quot;HKEY_CURRENT_USER\Control Panel\Desktop&quot; Highlight DragHeight and DragWidth one at a time. Change the Value to something like 100. This defines the distance in pixel you need to drag and drop." FOLDED="true" ID="ID_229954376" CREATED="1696098620675" MODIFIED="1696098620675">
<node ID="ID_1541754668" CREATED="1696098729426" MODIFIED="1696098729426" LINK="https://www.tenforums.com/general-support/152616-i-want-really-disable-drag-drop.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tenforums.com/general-support/152616-i-want-really-disable-drag-drop.html">I want to REALLY disable drag and drop Solved - Windows 10 Forums</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="ideal" FOLDED="true" ID="ID_1300201872" CREATED="1695925899710" MODIFIED="1695925902324">
<node TEXT="attached to foot" ID="ID_870687551" CREATED="1695926274502" MODIFIED="1695926288145"/>
<node TEXT="trigger on lift" ID="ID_535991747" CREATED="1695925907502" MODIFIED="1695925911743"/>
<node TEXT="ideas" FOLDED="true" ID="ID_500975305" CREATED="1695926334116" MODIFIED="1695926336720">
<node TEXT="angle switch" ID="ID_1857750423" CREATED="1695926337728" MODIFIED="1695926340751"/>
</node>
</node>
<node TEXT="page switcher" FOLDED="true" ID="ID_829246335" CREATED="1695925876504" MODIFIED="1695925882329">
<node TEXT="Donner Page Turner" ID="ID_806023935" CREATED="1696995142526" MODIFIED="1696995149048"/>
<node TEXT="triggers on press" FOLDED="true" ID="ID_1317010558" CREATED="1695925931304" MODIFIED="1695925935321">
<node TEXT="requires" FOLDED="true" ID="ID_220837298" CREATED="1695926038708" MODIFIED="1695926042550">
<node TEXT="foot to rest on" ID="ID_1922762032" CREATED="1695926043902" MODIFIED="1695926067161"/>
<node TEXT="extra pressure to trigger" ID="ID_1109301024" CREATED="1695926070356" MODIFIED="1695926076540"/>
</node>
</node>
</node>
</node>
<node TEXT="Hands" FOLDED="true" ID="ID_1756702592" CREATED="1695925860946" MODIFIED="1695925863934">
<node TEXT="cons" FOLDED="true" ID="ID_1700030308" CREATED="1695926099302" MODIFIED="1695926104162">
<node TEXT="overuse" ID="ID_1642635289" CREATED="1695926105518" MODIFIED="1695926108917"/>
</node>
<node TEXT="Keyboard" FOLDED="true" ID="ID_1549777276" CREATED="1582119739520" MODIFIED="1582119742990">
<node TEXT="KS200 Keyboard" FOLDED="true" ID="ID_480564613" CREATED="1692156941683" MODIFIED="1692156950443">
<node TEXT="Designer" ID="ID_246643210" CREATED="1692156974321" MODIFIED="1692156977045"/>
<node ID="ID_657938765" CREATED="1692156966343" MODIFIED="1692156966343" LINK="https://www.deluxworld.com/en-service-12.html?stoken=4d6de0ba2ac7fd339d51270395880b91&amp;title=ks200"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.deluxworld.com/en-service-12.html?stoken=4d6de0ba2ac7fd339d51270395880b91&amp;title=ks200">DELUX | GAMING DEVICE | ERGONOMIC MOUSE AND KEYBOARD | OFFICE DEVICE</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="unused" FOLDED="true" ID="ID_949625641" CREATED="1695961941641" MODIFIED="1695961944468">
<node TEXT="Vertical Keyboard" FOLDED="true" ID="ID_706087367" CREATED="1520523616423" MODIFIED="1520523626676">
<node TEXT="Surfingkeys settings" FOLDED="true" ID="ID_844927350" CREATED="1520523628021" MODIFIED="1520523639382">
<node TEXT="map(&quot;c&quot;, &quot;R&quot;);" ID="ID_557582957" CREATED="1520523645376" MODIFIED="1520523645376"/>
<node TEXT="map(&quot;s&quot;, &quot;f&quot;);" ID="ID_1962859929" CREATED="1520523645376" MODIFIED="1520523645376"/>
<node TEXT="map(&quot;i&quot;, &quot;s&quot;);" ID="ID_1595106031" CREATED="1520523645378" MODIFIED="1520523645378"/>
<node TEXT="map(&quot;y&quot;, &quot;E&quot;);" ID="ID_76931659" CREATED="1520523645379" MODIFIED="1520523645379"/>
<node TEXT="map(&quot;m&quot;, &quot;e&quot;);" ID="ID_1727480332" CREATED="1520523645380" MODIFIED="1520523645380"/>
<node TEXT="map(&quot;t&quot;, &quot;d&quot;);" ID="ID_1222317175" CREATED="1520523645381" MODIFIED="1520523645381"/>
<node TEXT="map(&quot;w&quot;, &quot;S&quot;);" ID="ID_892459474" CREATED="1520523645382" MODIFIED="1520523645382"/>
<node TEXT="Hints.characters = &quot;sinafbcypgj&quot;;" ID="ID_923888411" CREATED="1520523645384" MODIFIED="1520523645384"/>
</node>
</node>
</node>
</node>
<node TEXT="Mouse" FOLDED="true" ID="ID_995760397" CREATED="1610318895727" MODIFIED="1610318898456">
<node TEXT="Drawing pad" FOLDED="true" ID="ID_475871966" CREATED="1687971843393" MODIFIED="1687971847234">
<node TEXT="prop up pad with book" ID="ID_1152893390" CREATED="1687972036034" MODIFIED="1687972041387"/>
<node TEXT="use wrist rest" ID="ID_577419577" CREATED="1687972042323" MODIFIED="1687972046644"/>
<node TEXT="hold pen between the index and middle finger" ID="ID_727171296" CREATED="1687971851280" MODIFIED="1687971875436"/>
<node TEXT="hover pen" ID="ID_1133894543" CREATED="1687972070184" MODIFIED="1687972079428"/>
<node TEXT="S620 (not tablet drivers)" FOLDED="true" ID="ID_1840532222" CREATED="1687971812884" MODIFIED="1687971825959">
<node ID="ID_1122438852" CREATED="1707499545483" MODIFIED="1707499545483" LINK="https://download.gaomon.net/plus/list.php?cateId=12&amp;type=0&amp;system=0&amp;Keyword=&amp;tid=9#pcb"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://download.gaomon.net/plus/list.php?cateId=12&amp;type=0&amp;system=0&amp;Keyword=&amp;tid=9#pcb">GAOMON | Official Home - Global | Graphics Tablet, Pen Display</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_1590478989" CREATED="1610318908415" MODIFIED="1610318908415" LINK="http://www.rw-designer.com/online-cursor-editor"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="http://www.rw-designer.com/online-cursor-editor">Online Cursor Maker - create your own cursors online</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Touchscreen" FOLDED="true" ID="ID_1998889548" CREATED="1594959087099" MODIFIED="1610313082928">
<node TEXT="emulate mouse with touchscreen" ID="ID_1074085696" CREATED="1625587133791" MODIFIED="1625587154796"/>
<node TEXT="Hardware" FOLDED="true" ID="ID_75727666" CREATED="1610319085855" MODIFIED="1610319089182">
<node ID="ID_1548692169" CREATED="1694727772964" MODIFIED="1694727772964" LINK="https://www.aliexpress.us/item/3256805466844719.html?spm=a2g0o.detail.0.0.6bab77c5jgvHgF&amp;gps-id=pcDetailTopMoreOtherSeller&amp;scm=1007.40050.354490.0&amp;scm_id=1007.40050.354490.0&amp;scm-url=1007.40050.354490.0&amp;pvid=9c15ed5f-94ab-4881-9793-066c33656ddd&amp;_t=gps-id:pcDetailTopMoreOtherSeller,scm-url:1007.40050.354490.0,pvid:9c15ed5f-94ab-4881-9793-066c33656ddd,tpp_buckets:668%232846%238108%231977&amp;pdp_npi=4%40dis%21USD%2145.99%2145.99%21%21%2145.99%21%21%402101c80216947276435937597e8e96%2112000035295197369%21rec%21US%21%21ABS"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.aliexpress.us/item/3256805466844719.html?spm=a2g0o.detail.0.0.6bab77c5jgvHgF&amp;gps-id=pcDetailTopMoreOtherSeller&amp;scm=1007.40050.354490.0&amp;scm_id=1007.40050.354490.0&amp;scm-url=1007.40050.354490.0&amp;pvid=9c15ed5f-94ab-4881-9793-066c33656ddd&amp;_t=gps-id:pcDetailTopMoreOtherSeller,scm-url:1007.40050.354490.0,pvid:9c15ed5f-94ab-4881-9793-066c33656ddd,tpp_buckets:668%232846%238108%231977&amp;pdp_npi=4%40dis%21USD%2145.99%2145.99%21%21%2145.99%21%21%402101c80216947276435937597e8e96%2112000035295197369%21rec%21US%21%21ABS">8.8 inch HDMI Touch Long Wide Monitor With Case PC Temperature Display PC Sensor Panel Display Small Extender Monitor(8.8/5inch) - AliExpress</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1459542125" CREATED="1594959093387" MODIFIED="1594959093387" LINK="http://www.lcdwiki.com/7inch_HDMI_Display-C#Product_Parameters"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.lcdwiki.com/7inch_HDMI_Display-C#Product_Parameters">7inch HDMI Display-C - LCD wiki</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_971421352" CREATED="1601699899436" MODIFIED="1601699899436" LINK="https://www.aliexpress.com/item/4000959465945.html?spm=a2g0o.detail.1000060.1.66bd74e4nMvvHG&amp;gps-id=pcDetailBottomMoreThisSeller&amp;scm=1007.13339.169870.0&amp;scm_id=1007.13339.169870.0&amp;scm-url=1007.13339.169870.0&amp;pvid=46a8ded4-5f40-44b7-b7fc-9d293acbab88&amp;_t=gps-id:pcDetailBottomMoreThisSeller,scm-url:1007.13339.169870.0,pvid:46a8ded4-5f40-44b7-b7fc-9d293acbab88,tpp_buckets:668%230%23131923%2383_668%23808%233772%23940_668%23888%233325%234_668%232846%238108%23197_668%232717%237563%23560_668%231000022185%231000066058%230_668%233468%2315615%23677"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.aliexpress.com/item/4000959465945.html?spm=a2g0o.detail.1000060.1.66bd74e4nMvvHG&amp;gps-id=pcDetailBottomMoreThisSeller&amp;scm=1007.13339.169870.0&amp;scm_id=1007.13339.169870.0&amp;scm-url=1007.13339.169870.0&amp;pvid=46a8ded4-5f40-44b7-b7fc-9d293acbab88&amp;_t=gps-id:pcDetailBottomMoreThisSeller,scm-url:1007.13339.169870.0,pvid:46a8ded4-5f40-44b7-b7fc-9d293acbab88,tpp_buckets:668%230%23131923%2383_668%23808%233772%23940_668%23888%233325%234_668%232846%238108%23197_668%232717%237563%23560_668%231000022185%231000066058%230_668%233468%2315615%23677">7 inch 1024*600 Capacitive Touch Panel TFT LCD Module Screen Display for Raspberry Pi 3 B+/4b|LCD Modules| - AliExpress</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Laptop" ID="ID_322928428" CREATED="1625871486413" MODIFIED="1625871491006"/>
</node>
<node TEXT="Utility Software" FOLDED="true" ID="ID_1353547863" CREATED="1637208193247" MODIFIED="1637208213444">
<node FOLDED="true" ID="ID_310924924" CREATED="1637208215003" MODIFIED="1637208215003" LINK="http://www.airesoft.co.uk/windowwatcher"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.airesoft.co.uk/windowwatcher">WindowWatcher | Airesoft</a>
  </body>
</html>
</richcontent>
<node TEXT="PIP" ID="ID_1498592076" CREATED="1637208219576" MODIFIED="1637208231559"/>
<node ID="ID_1314108429" CREATED="1637208837171" MODIFIED="1637208837171" LINK="http://www.airesoft.co.uk/help/windowwatcher/operation/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.airesoft.co.uk/help/windowwatcher/operation/">WindowWatcher Help - Operation | Airesoft</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="magnification" FOLDED="true" ID="ID_31291868" CREATED="1638227180712" MODIFIED="1638227185143">
<node TEXT="research" FOLDED="true" ID="ID_845910226" CREATED="1638227438938" MODIFIED="1638227441344">
<node ID="ID_1712260151" CREATED="1638227442355" MODIFIED="1638227442355" LINK="https://listoffreeware.com/list-best-free-screen-magnifiers/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://listoffreeware.com/list-best-free-screen-magnifiers/">List Of Best Free Screen Magnifiers</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_145439610" CREATED="1638227186609" MODIFIED="1638227186609" LINK="https://visionaware.org/everyday-living/helpful-products/using-a-computer/assessing-which-computer-is-right-for-you/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://visionaware.org/everyday-living/helpful-products/using-a-computer/assessing-which-computer-is-right-for-you/">Questions to Ask About Which Assistive Technology Is Right for You - VisionAware</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="use magnifier to zoom screen" FOLDED="true" ID="ID_1711647885" CREATED="1625871500180" MODIFIED="1625871515056">
<node TEXT="current application" ID="ID_1330314497" CREATED="1636585177658" MODIFIED="1636585181688"/>
<node TEXT="apps" ID="ID_867309873" CREATED="1636587958031" MODIFIED="1636587965473"/>
<node TEXT="Win+ + and -" ID="ID_174970846" CREATED="1625871515670" MODIFIED="1625871525963"/>
</node>
</node>
<node TEXT="Dynamic Keyboard" FOLDED="true" ID="ID_1168367403" CREATED="1610319108986" MODIFIED="1610319108986">
<node TEXT="Hardware: Android Tablet" ID="ID_1116216385" CREATED="1610319108986" MODIFIED="1610319108986"/>
<node TEXT="Software:" FOLDED="true" ID="ID_891074084" CREATED="1610319077400" MODIFIED="1610319077400">
<node TEXT="Spacedesk" FOLDED="true" ID="ID_570054489" CREATED="1610319077400" MODIFIED="1610319077400">
<node ID="ID_21626450" CREATED="1610319055394" MODIFIED="1610319264245" LINK="https://spacedesk.net/user-manual/#usb-tethering"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p tethered="#DEFAULT" via="#DEFAULT" usb="#DEFAULT">
      <a href="https://spacedesk.net/user-manual/#usb-tethering">spacedesk | Multi Monitor App | Virtual Display Screen | Software Video Wall | documentation</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Move window to another desktop using desktop manager" ID="ID_975226752" CREATED="1610319077412" MODIFIED="1610319077412"/>
<node TEXT="Autohotkey script to return mouse" ID="ID_518837907" CREATED="1610319077422" MODIFIED="1610319077422"/>
<node TEXT="Touchkey for keyboard" ID="ID_1344820162" CREATED="1610319077433" MODIFIED="1610319077433"/>
</node>
<node TEXT="Touch Key" FOLDED="true" ID="ID_363235817" CREATED="1622731403581" MODIFIED="1622731433733">
<node ID="ID_1126885973" CREATED="1622731391283" MODIFIED="1622731391283" LINK="http://www.kannagi.net/touchkey/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.kannagi.net/touchkey/">Windows 8 / Windows 10 タブレット用 ソフトウェア左手キーボード TouchKey - 幻影の都</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Gamepad" FOLDED="true" ID="ID_641833085" CREATED="1689113213061" MODIFIED="1689113218536">
<node ID="ID_196735681" CREATED="1689113219676" MODIFIED="1689113219676" LINK="https://joytokey.net/en/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://joytokey.net/en/">15. JoyToKey - Download the Latest Official Version</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Actions" FOLDED="true" ID="ID_1984714074" CREATED="1610313001552" MODIFIED="1610313005577">
<node TEXT="typing" FOLDED="true" ID="ID_308338059" CREATED="1534535780389" MODIFIED="1534536114852">
<node TEXT="words" ID="ID_1637993514" CREATED="1534536119198" MODIFIED="1534536131901"/>
<node TEXT="symbols" ID="ID_1658801778" CREATED="1534536132366" MODIFIED="1534536158192"/>
<node TEXT="numbers" ID="ID_1257224536" CREATED="1534536286633" MODIFIED="1534536294377"/>
</node>
<node TEXT="navigating" FOLDED="true" ID="ID_980525834" CREATED="1534535798799" MODIFIED="1534535820461">
<node TEXT="Writing pad" FOLDED="true" ID="ID_1922163964" CREATED="1564157067716" MODIFIED="1564157072780">
<node TEXT="7x5&quot;" ID="ID_573985966" CREATED="1564157074827" MODIFIED="1564174973790"/>
</node>
</node>
<node TEXT="selecting" FOLDED="true" ID="ID_1796338104" CREATED="1534535823417" MODIFIED="1534535861370">
<node TEXT="word" ID="ID_1153287005" CREATED="1534539559092" MODIFIED="1534539576715"/>
<node TEXT="sentence" ID="ID_1693238267" CREATED="1534539577415" MODIFIED="1534539583789"/>
<node TEXT="paragraph" ID="ID_2770003" CREATED="1534539584627" MODIFIED="1534539594939"/>
</node>
<node TEXT="copy cut paste" ID="ID_448724390" CREATED="1534535862849" MODIFIED="1534535881991"/>
<node TEXT="swtching apps" ID="ID_447031104" CREATED="1534535884626" MODIFIED="1534535898844"/>
<node TEXT="manipulating windows" ID="ID_92040259" CREATED="1534535900361" MODIFIED="1534535917408"/>
<node TEXT="in app commands" ID="ID_676554193" CREATED="1534535922111" MODIFIED="1534535934415"/>
</node>
<node TEXT="Toolbar" FOLDED="true" ID="ID_120963311" CREATED="1583859505687" MODIFIED="1583859508746">
<node ID="ID_1108476336" CREATED="1583859509761" MODIFIED="1583859509761" LINK="http://forum.tabletpcreview.com/threads/hotkey-toolbar-list-of-hotkey-toolbars.55519/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://forum.tabletpcreview.com/threads/hotkey-toolbar-list-of-hotkey-toolbars.55519/">Hotkey ToolBar - List of Hotkey Toolbars | TabletPCReview.com - Tablet PC Reviews, Discussion and News</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_143896703" CREATED="1654059642099" MODIFIED="1654059644220">
<node ID="ID_1946209146" CREATED="1654059645473" MODIFIED="1654059645473" LINK="https://www.youtube.com/watch?v=sqioybTNhBg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.youtube.com/watch?v=sqioybTNhBg">Use a Computer only with Eye Movement - Tobii Eye Tracker 5 with Windows Eye Control - YouTube</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_281600294" CREATED="1654059774581" MODIFIED="1654059774581" LINK="http://optikey.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://optikey.org/">Home | Optikey</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1184728409" CREATED="1654060193550" MODIFIED="1654060193550" LINK="https://openassistive.org/tags/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://openassistive.org/tags/">Tags</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1564518276" CREATED="1654061324717" MODIFIED="1654061324717" LINK="https://www.myzips.com/listings/Automation/Utilities/52/2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.myzips.com/listings/Automation/Utilities/52/2">Software</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="GUI Helpers" FOLDED="true" ID="ID_1348305094" CREATED="1695962014458" MODIFIED="1695962019273">
<node TEXT="Screen Search, Application interfacing" FOLDED="true" ID="ID_1116841987" CREATED="1712852769467" MODIFIED="1716349883389">
<node ID="ID_1084866859" CREATED="1623966516480" MODIFIED="1623966516480" LINK="https://pywinauto.readthedocs.io/en/latest/#some-similar-tools-for-comparison"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pywinauto.readthedocs.io/en/latest/#some-similar-tools-for-comparison">What is pywinauto — pywinauto 0.6.8 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Fluent Search - Search for running applications and browser tabs" FOLDED="true" ID="ID_464556663" CREATED="1649782448086" MODIFIED="1649782755036" LINK="https://www.fluentsearch.net/">
<node TEXT="Tasks" FOLDED="true" ID="ID_1822550127" CREATED="1701965288476" MODIFIED="1701965291355">
<node ID="ID_1715739324" CREATED="1701965292355" MODIFIED="1701965292355" LINK="https://discord.com/channels/740636963396124714/904135785916268554"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://discord.com/channels/740636963396124714/904135785916268554">• Discord | #tasks | Fluent Search</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_368267436" CREATED="1701931011661" MODIFIED="1701931011661" LINK="https://www.fluentsearch.net/posts/fluent-search-tasks-nightly-test"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.fluentsearch.net/posts/fluent-search-tasks-nightly-test">Fluent Search Tasks - nightly test &amp; Fluent Search</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Text size changed by &quot;Font Scale&quot; setting" ID="ID_562170576" CREATED="1656344436694" MODIFIED="1656344436694"/>
<node TEXT="Letters" FOLDED="true" ID="ID_80134895" CREATED="1699132736586" MODIFIED="1699132739247">
<node TEXT="Screen Search" ID="ID_1751701320" CREATED="1712852769467" MODIFIED="1712852772314"/>
<node TEXT="transparency" ID="ID_931070965" CREATED="1712850128212" MODIFIED="1712850130831"/>
</node>
</node>
<node TEXT="Alternatives" ID="ID_1774233309" CREATED="1716349387965" MODIFIED="1716349392463"/>
</node>
<node ID="ID_730114728" TREE_ID="ID_464556663">
<node ID="ID_1829007902" TREE_ID="ID_1822550127">
<node ID="ID_251531344" TREE_ID="ID_1715739324"/>
<node ID="ID_1007677628" TREE_ID="ID_368267436"/>
</node>
<node ID="ID_1068590021" TREE_ID="ID_562170576"/>
<node ID="ID_1244599183" TREE_ID="ID_80134895">
<node ID="ID_1599177791" TREE_ID="ID_1751701320"/>
<node ID="ID_1786991972" TREE_ID="ID_931070965"/>
</node>
</node>
<node TEXT="inactive window dimmer" FOLDED="true" ID="ID_1097369333" CREATED="1706559878908" MODIFIED="1706559884239">
<node ID="ID_1804808104" CREATED="1706560075729" MODIFIED="1706560075729" LINK="https://alternativeto.net/software/powerdimmer/about/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/powerdimmer/about/">PowerDimmer: Reviews, Features, Pricing &amp; Download | AlternativeTo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Task Switcher" FOLDED="true" ID="ID_95636669" CREATED="1701931179333" MODIFIED="1701931182534">
<node ID="ID_383148906" CREATED="1701931183340" MODIFIED="1701931183340" LINK="http://oelgaard.dk/torkils/?TorkilsTaskSwitcher"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://oelgaard.dk/torkils/?TorkilsTaskSwitcher">Torkils - TorkilsTaskSwitcher</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Taskbar" FOLDED="true" ID="ID_1799530441" CREATED="1684820556827" MODIFIED="1684820561433">
<node TEXT="Explorer Patcher" FOLDED="true" ID="ID_389292588" CREATED="1707427490687" MODIFIED="1707427503367">
<node ID="ID_456176340" CREATED="1684820395706" MODIFIED="1684820395706" LINK="https://github.com/valinet/ExplorerPatcher"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/valinet/ExplorerPatcher">GitHub - valinet/ExplorerPatcher: This project aims to enhance the working environment on Windows</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="to change back to Windows 10 Taskbar" ID="ID_1430355481" CREATED="1707427503789" MODIFIED="1707427524001"/>
<node TEXT="taskbar on left" FOLDED="true" ID="ID_1195973368" CREATED="1684818212488" MODIFIED="1684818220106">
<node ID="ID_1474249293" CREATED="1684819451833" MODIFIED="1684819451833" LINK="https://pureinfotech.com/move-taskbar-top-side-windows-11/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pureinfotech.com/move-taskbar-top-side-windows-11/">How to move Taskbar to top or side on Windows 11 - Pureinfotech</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Taskbar Numberer" FOLDED="true" ID="ID_936460156" CREATED="1646979222563" MODIFIED="1646979222563">
<node ID="ID_474944997" CREATED="1707427617770" MODIFIED="1707427617770" LINK="https://ramensoftware.com/7-taskbar-numberer"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://ramensoftware.com/7-taskbar-numberer">7+ Taskbar Numberer: taskbar numbers for Utter Command - Ramen Software</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="to number taskbar icons" ID="ID_465296528" CREATED="1707427525701" MODIFIED="1707427536727"/>
<node TEXT="create shortcut" ID="ID_119709609" CREATED="1715920163152" MODIFIED="1715920180705"/>
<node TEXT="move to start up folder" FOLDED="true" ID="ID_544437016" CREATED="1715920181665" MODIFIED="1715920670132">
<node TEXT="C:\Users\u581917\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\7+ Taskbar Numberer - Shortcut.lnk" ID="ID_1758663567" CREATED="1715920677944" MODIFIED="1715920677944"/>
</node>
</node>
<node TEXT="numbered" FOLDED="true" ID="ID_281894704" CREATED="1684820564971" MODIFIED="1684820573180">
<node TEXT="transparent" FOLDED="true" ID="ID_1232724447" CREATED="1684820574267" MODIFIED="1684820579084">
<node TEXT="Translucent TB" ID="ID_504053670" CREATED="1684820893066" MODIFIED="1684820900684"/>
<node TEXT="C:\GD_sync\Other computers\My Laptop\GD_sync\Wallpapers\2560x1440 bg num.jpg" ID="ID_824829056" CREATED="1684820911603" MODIFIED="1684820911603"/>
</node>
</node>
</node>
<node TEXT="wallpaper" ID="ID_1021852448" CREATED="1700341100713" MODIFIED="1700341104991"/>
<node TEXT="web browsers" FOLDED="true" ID="ID_1137876586" CREATED="1695962123038" MODIFIED="1695962125689">
<node TEXT="click by voice" FOLDED="true" ID="ID_523051078" CREATED="1695962508873" MODIFIED="1695962513886">
<node TEXT="display" FOLDED="true" ID="ID_623185585" CREATED="1695962830237" MODIFIED="1695962832468">
<node TEXT="Switches&#xa;The following switches are officially supported:&#xa;&#xa;i: use inline mode&#xa;o: use overlay mode&#xa;h: use hybrid mode&#xa;c: use high contrast hints&#xa;i, o, and h are mutually exclusive, with the last one present winning." ID="ID_756422553" CREATED="1695962834240" MODIFIED="1695963018481"/>
</node>
<node ID="ID_1289266492" CREATED="1695962649069" MODIFIED="1695962649069" LINK="https://github.com/mdbridge/click-by-voice/blob/master/doc/displaying_hints.md"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/mdbridge/click-by-voice/blob/master/doc/displaying_hints.md">click-by-voice/doc/displaying_hints.md at master · mdbridge/click-by-voice</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1528618373" CREATED="1695962506112" MODIFIED="1695962506112" LINK="https://github.com/mdbridge/click-by-voice"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/mdbridge/click-by-voice">mdbridge/click-by-voice: Chrome browser extension that provides support for activating links and other elements by voice commands</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Surfingkeys" FOLDED="true" ID="ID_485043309" CREATED="1526973677344" MODIFIED="1526973684724">
<node TEXT="Copy text" FOLDED="true" ID="ID_527510533" CREATED="1526973687560" MODIFIED="1526973693685">
<node TEXT="v - visual mode" ID="ID_956519362" CREATED="1526973694960" MODIFIED="1526973701484"/>
<node TEXT="y - yank text" FOLDED="true" ID="ID_1861011525" CREATED="1526973702191" MODIFIED="1526973710956">
<node TEXT="w - word" ID="ID_862881637" CREATED="1526973712776" MODIFIED="1526973739333"/>
<node TEXT="l - line" ID="ID_1551131810" CREATED="1526973740256" MODIFIED="1526973743188"/>
<node TEXT="s - sentence" ID="ID_273637350" CREATED="1526973743656" MODIFIED="1526973748084"/>
<node TEXT="p - paragraph" ID="ID_1813732422" CREATED="1526973748584" MODIFIED="1526973761493"/>
<node TEXT="g - page" ID="ID_1380619151" CREATED="1526974300699" MODIFIED="1526974303902"/>
</node>
</node>
</node>
</node>
<node ID="ID_1585107022" CREATED="1582119744328" MODIFIED="1582119744328" LINK="https://autohotkey.com/board/topic/66103-show-numbers-function-speech-recognition/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://autohotkey.com/board/topic/66103-show-numbers-function-speech-recognition/">&quot;Show Numbers&quot; function Speech Recognition - Ask for Help - AutoHotkey Community</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="machine emulation" FOLDED="true" ID="ID_251520310" CREATED="1615530810078" MODIFIED="1695233898361">
<node TEXT="On PC" FOLDED="true" ID="ID_519672777" CREATED="1589820040195" MODIFIED="1589820042683">
<node ID="ID_1704566296" CREATED="1624048924771" MODIFIED="1624048924771" LINK="https://www.geekrar.com/how-to-install-android-in-virtualbox-2021/#Required_Files_to_Download"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.geekrar.com/how-to-install-android-in-virtualbox-2021/#Required_Files_to_Download">How To Install Android In VirtualBox (2021) - Geekrar</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Windows to android" FOLDED="true" ID="ID_1005410502" CREATED="1625240118259" MODIFIED="1625240122995">
<node ID="ID_314130147" CREATED="1625240124270" MODIFIED="1625240124270" LINK="https://itnext.io/how-you-can-control-your-android-device-with-python-45c3ab15e260"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://itnext.io/how-you-can-control-your-android-device-with-python-45c3ab15e260">How you can Control your Android Device with Python | by Kush | ITNEXT</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_256517251" CREATED="1625611574819" MODIFIED="1625611574819" LINK="https://github.com/topics/screensharing"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/topics/screensharing">screensharing · GitHub Topics</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_146414592" CREATED="1615530840332" MODIFIED="1615530840332" LINK="https://www.qemu.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.qemu.org/">QEMU</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Work computer setup" FOLDED="true" ID="ID_1376792040" CREATED="1646978881353" MODIFIED="1694879724499">
<node FOLDED="true" ID="ID_499731957" CREATED="1646978948287" MODIFIED="1646978948287"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.0055in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.0055in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            Work application storage:
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_626145837" CREATED="1646978948303" MODIFIED="1646978948303" LINK="../../../../Users/u581917/OneDrive%20-%20Syngenta"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.0055in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.0055in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="file:///C:/Users/u581917/OneDrive%20-%20Syngenta/">C:\Users\u581917\OneDrive - Syngenta\</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Other apps:" FOLDED="true" ID="ID_1426726995" CREATED="1649782923516" MODIFIED="1649782923516">
<node TEXT="Office Utility" FOLDED="true" ID="ID_1530975125" CREATED="1649782923516" MODIFIED="1649782923516">
<node TEXT="Pdfsam, PDF utility" ID="ID_1479080858" CREATED="1649782923520" MODIFIED="1649782923520"/>
<node TEXT="PDF-XChangeEditorPortable, OCR" ID="ID_938046298" CREATED="1649782923520" MODIFIED="1649782923520"/>
</node>
<node TEXT="Input" FOLDED="true" ID="ID_1754022284" CREATED="1649782923520" MODIFIED="1649782923520">
<node TEXT="Luamacros: used for custom keyboard" ID="ID_244234992" CREATED="1649782923537" MODIFIED="1649782923537"/>
</node>
<node TEXT="Linux" FOLDED="true" ID="ID_1334200346" CREATED="1649782923537" MODIFIED="1649782923537">
<node TEXT="YUMI, bootloader" ID="ID_849757129" CREATED="1649782923548" MODIFIED="1649782923548"/>
</node>
<node TEXT="Image editing" FOLDED="true" ID="ID_459948930" CREATED="1649782923549" MODIFIED="1649782923549">
<node TEXT="Xnconvert        Batch image converter" ID="ID_221187846" CREATED="1649782923556" MODIFIED="1649782923556"/>
<node TEXT="GIMP" ID="ID_836190517" CREATED="1649782923557" MODIFIED="1649782923557"/>
</node>
</node>
</node>
<node TEXT="Ryzen PC" FOLDED="true" ID="ID_550068221" CREATED="1690926790687" MODIFIED="1690926800971">
<node TEXT="Boot" FOLDED="true" ID="ID_809937438" CREATED="1690926801240" MODIFIED="1690926802818">
<node TEXT="Del Key" ID="ID_1115533083" CREATED="1690926864938" MODIFIED="1690926867691"/>
<node ID="ID_1976635839" CREATED="1690926848831" MODIFIED="1690926848831" LINK="https://www.lifewire.com/bios-setup-utility-access-keys-for-major-bios-manufacturers-2624461"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.lifewire.com/bios-setup-utility-access-keys-for-major-bios-manufacturers-2624461">19. How to Access BIOS Setup Utility for Major BIOS Manufacturers</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="american megatrends" ID="ID_1776807970" CREATED="1690926803770" MODIFIED="1690926807580"/>
</node>
</node>
<node TEXT="Downgrade from Pro to Home" FOLDED="true" ID="ID_42761320" CREATED="1689176272686" MODIFIED="1689176283040">
<node TEXT="Fresh install" ID="ID_191395670" CREATED="1689186172381" MODIFIED="1689186180007"/>
</node>
<node TEXT="Windows settings" FOLDED="true" ID="ID_1979456592" CREATED="1684815821488" MODIFIED="1684815859530">
<node TEXT="Disable services" FOLDED="true" ID="ID_1049436898" CREATED="1684993440372" MODIFIED="1684993448183">
<node ID="ID_1650260029" CREATED="1684993523701" MODIFIED="1684993523701" LINK="https://windowsreport.com/services-to-disable-windows-11/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://windowsreport.com/services-to-disable-windows-11/">Windows 11 Services To Disable: How to Safely do it</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Personalization" FOLDED="true" ID="ID_1266001481" CREATED="1684821122819" MODIFIED="1684821126964">
<node TEXT="Change Theme to Dark" ID="ID_279017668" CREATED="1684814526780" MODIFIED="1684814534971"/>
<node TEXT="Disable transparency" ID="ID_490456287" CREATED="1684815828552" MODIFIED="1684815834889"/>
<node TEXT="accent color" FOLDED="true" ID="ID_45217932" CREATED="1684821068011" MODIFIED="1684821074419">
<node TEXT="green" ID="ID_1645546364" CREATED="1684821096099" MODIFIED="1684821099180"/>
</node>
</node>
<node TEXT="Enable Hybernate" FOLDED="true" ID="ID_353026119" CREATED="1686093067674" MODIFIED="1686093079587">
<node ID="ID_1264963895" CREATED="1686093088957" MODIFIED="1686093088957" LINK="https://www.makeuseof.com/windows-11-turn-on-hibernate-mode/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.makeuseof.com/windows-11-turn-on-hibernate-mode/">How to Turn On Hibernate Mode on Windows 11</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Windows modifications" FOLDED="true" ID="ID_1450724065" CREATED="1539701337292" MODIFIED="1695077714018">
<node TEXT="Taskbar" FOLDED="true" ID="ID_1584980617" CREATED="1595870803009" MODIFIED="1595870810485">
<node TEXT="pin websites to taskbar" FOLDED="true" ID="ID_889142802" CREATED="1624645197024" MODIFIED="1624645220873">
<node ID="ID_1005609663" CREATED="1624647338190" MODIFIED="1624647338190" LINK="https://www.onmsft.com/how-to/how-to-use-pinned-tabs-in-microsoft-edge-insider"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.onmsft.com/how-to/how-to-use-pinned-tabs-in-microsoft-edge-insider">How to use pinned tabs in Microsoft Edge Insider - OnMSFT.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Task Switching" FOLDED="true" ID="ID_1329726230" CREATED="1555361895470" MODIFIED="1622672248035" VGAP_QUANTITY="0 pt">
<node ID="ID_1297527962" CREATED="1622672232532" MODIFIED="1622672248032" LINK="https://executor.dk/download"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://executor.dk/download">Executor</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1956465603" CREATED="1555361904735" MODIFIED="1555361904735" LINK="https://www.nsaneforums.com/topic/196236-windowtabs-v2013523/page/2/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.nsaneforums.com/topic/196236-windowtabs-v2013523/page/2/">WindowTabs v2013.5.23 - Software Updates - nsane.forums</a>
  </body>
</html>
</richcontent>
<node ID="ID_992399639" CREATED="1555362235418" MODIFIED="1555362235418" LINK="https://www.muchosportables.com/windowtabs-v2018-7-20-portable/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.muchosportables.com/windowtabs-v2018-7-20-portable/">WindowTabs v2018.7.20 Portable | Many Portables</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_966031319" CREATED="1595607122266" MODIFIED="1595607122266" LINK="https://alternativeto.net/software/menuapp/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/menuapp/">menuApp Alternatives and Similar Software - AlternativeTo.net</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Web Browser" FOLDED="true" ID="ID_876630004" CREATED="1624655945183" MODIFIED="1624655949898">
<node ID="ID_1127137323" CREATED="1624655952976" MODIFIED="1624655952976" LINK="https://answers.microsoft.com/en-us/windows/forum/windows_10-performance/pinned-tab-keeps-disappearing/2b44ff22-78e6-4dd3-9dfa-197e796f542a"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://answers.microsoft.com/en-us/windows/forum/windows_10-performance/pinned-tab-keeps-disappearing/2b44ff22-78e6-4dd3-9dfa-197e796f542a">Pinned Tab Keeps Disappearing - Microsoft Community</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Visual tweaks" FOLDED="true" ID="ID_1515850687" CREATED="1554911269882" MODIFIED="1554911273318">
<node TEXT="Screen Dimmer" FOLDED="true" ID="ID_487594559" CREATED="1700695766578" MODIFIED="1700695769535">
<node ID="ID_125169835" CREATED="1700695805942" MODIFIED="1700695805942" LINK="https://download.cnet.com/pangobright/3000-2072_4-75327791.html?tag=mncol%3B1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://download.cnet.com/pangobright/3000-2072_4-75327791.html?tag=mncol%3B1">PangoBright - Free download and software reviews - CNET Download</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1207125445" CREATED="1700695770593" MODIFIED="1700695770593" LINK="https://alternativeto.net/software/pangobright/about/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/pangobright/about/">PangoBright: Reviews, Features, Pricing &amp; Download | AlternativeTo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Dark" FOLDED="true" ID="ID_1171817058" CREATED="1555783707417" MODIFIED="1555783710293">
<node ID="ID_820436028" CREATED="1555783711784" MODIFIED="1555783711784" LINK="https://midnight-lizard.org/home"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://midnight-lizard.org/home">Midnight Lizard - color schemes for all websites</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_229163563" CREATED="1554911274897" MODIFIED="1554911274897" LINK="https://www.askvg.com/registry-tweak-to-decrease-window-border-size-and-padding-in-windows-8/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.askvg.com/registry-tweak-to-decrease-window-border-size-and-padding-in-windows-8/">Registry Tweak to Decrease Window Border Size and Padding in Windows 8 and Later - AskVG</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1664253819" CREATED="1555783033885" MODIFIED="1555783033885" LINK="https://alternativeto.net/software/night-eye/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/night-eye/">Night Eye Alternatives and Similar Software - AlternativeTo.net</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_691076749" CREATED="1610319028938" MODIFIED="1610319028938" LINK="https://www.tenforums.com/tutorials/79875-change-size-scroll-bars-windows-10-a.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://www.tenforums.com/tutorials/79875-change-size-scroll-bars-windows-10-a.html">Change Size of Scroll Bars in Windows 10 | Tutorials</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Wallpaper" FOLDED="true" ID="ID_232034623" CREATED="1544721207938" MODIFIED="1544721210828">
<node TEXT="set for each individual monitor" FOLDED="true" ID="ID_304819428" CREATED="1544721223871" MODIFIED="1544721240089">
<node TEXT="control /name Microsoft.Personalization /page pageWallpaper" ID="ID_1344480762" CREATED="1544721212156" MODIFIED="1544721222843"/>
</node>
</node>
</node>
<node TEXT="optimization" FOLDED="true" ID="ID_661316894" CREATED="1527007688326" MODIFIED="1624645609214">
<node TEXT="Remove Ads" FOLDED="true" ID="ID_1573389687" CREATED="1622223671208" MODIFIED="1622223675228">
<node ID="ID_482177662" CREATED="1622223676267" MODIFIED="1622223676267" LINK="https://www.howtogeek.com/269331/how-to-disable-all-of-windows-10s-built-in-advertising/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.howtogeek.com/269331/how-to-disable-all-of-windows-10s-built-in-advertising/">How to Disable All of Windows 10’s Built-in Advertising</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Fresh Install" FOLDED="true" ID="ID_227856164" CREATED="1527085905062" MODIFIED="1527085909969">
<node TEXT="Install:" FOLDED="true" ID="ID_710666700" CREATED="1527085944438" MODIFIED="1527085949563">
<node TEXT="Drivers" FOLDED="true" ID="ID_366496611" CREATED="1527085922553" MODIFIED="1527085925532"/>
</node>
<node TEXT="Windows" FOLDED="true" ID="ID_1743633" CREATED="1527175190888" MODIFIED="1527175193919">
<node TEXT="Windows Update" ID="ID_384436095" CREATED="1527085965329" MODIFIED="1527085970360"/>
<node TEXT="autohotkey" ID="ID_102955170" CREATED="1527175211200" MODIFIED="1527175216060"/>
<node TEXT="Move main script to startup folder" ID="ID_1811895347" CREATED="1527175250216" MODIFIED="1527175423726" LINK="../../AppData/Roaming/Microsoft/Windows/Start%20Menu/Programs/Startup/"/>
<node TEXT="TranslucentTB.exe" FOLDED="true" ID="ID_1990284075" CREATED="1527092136349" MODIFIED="1527092136360" LINK="../../../../../E:/App%20Install%20Files/Utility/Windows/TranslucentTB.2017.3/TranslucentTB.exe">
<node TEXT="Make taskbar transparent" FOLDED="true" ID="ID_210336694" CREATED="1527087417102" MODIFIED="1527087427347">
<node TEXT="Use numbered image for background" ID="ID_1291176718" CREATED="1527087429346" MODIFIED="1527087445955"/>
</node>
</node>
<node TEXT="Disable auto install of games" FOLDED="true" ID="ID_1667642949" CREATED="1527175431660" MODIFIED="1527175439326">
<node TEXT="HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CloudContent" ID="ID_10367440" CREATED="1527176286029" MODIFIED="1527176286029"/>
<node TEXT="DisableWindowsConsumerFeatures" ID="ID_667620699" CREATED="1527176391591" MODIFIED="1527176391591"/>
</node>
<node TEXT="Improve SSD performance" FOLDED="true" ID="ID_872852424" CREATED="1527604129391" MODIFIED="1527619599369">
<node ID="ID_1143473434" CREATED="1527619672308" MODIFIED="1527619672308" LINK="https://www.tomshardware.com/reviews/ssd-performance-tweak,2911.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tomshardware.com/reviews/ssd-performance-tweak,2911.html">Can You Get More Space Or Speed From Your SSD?</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Apps" FOLDED="true" ID="ID_1581078550" CREATED="1527085913892" MODIFIED="1527085916125">
<node TEXT="Avast AV" ID="ID_212289679" CREATED="1527177890436" MODIFIED="1527177893904"/>
<node TEXT="Chrome" ID="ID_1644818298" CREATED="1527085973360" MODIFIED="1527085976376"/>
<node TEXT="Google Drive Sync" ID="ID_1117665811" CREATED="1527085976944" MODIFIED="1527085983844"/>
<node TEXT="GIMP" ID="ID_1626042784" CREATED="1527087450705" MODIFIED="1527087453558"/>
<node TEXT="Anaconda" ID="ID_923227891" CREATED="1527086001125" MODIFIED="1527086004586"/>
<node TEXT="Gaming" FOLDED="true" ID="ID_771562326" CREATED="1527094936831" MODIFIED="1527094939305">
<node TEXT="Steam" ID="ID_1349324842" CREATED="1527094940623" MODIFIED="1527094942825"/>
<node TEXT="G27" ID="ID_1622827109" CREATED="1527094943376" MODIFIED="1527094952064"/>
</node>
<node TEXT="Freeplane" FOLDED="true" ID="ID_46579768" CREATED="1694880000069" MODIFIED="1694880004478">
<node TEXT="Guide" FOLDED="true" ID="ID_70175057" CREATED="1683997696679" MODIFIED="1683997699956">
<node TEXT="go to node from outside app" FOLDED="true" ID="ID_700032025" CREATED="1684000035508" MODIFIED="1684000055481">
<node TEXT="use command line" ID="ID_975816636" CREATED="1684000079058" MODIFIED="1684000084511"/>
<node TEXT="select Node" ID="ID_1048399413" CREATED="1684000056267" MODIFIED="1684000065627"/>
<node TEXT="copy node URI" ID="ID_1341710059" CREATED="1684000066128" MODIFIED="1684000074911"/>
<node TEXT="Create Shortcut" ID="ID_1864350174" CREATED="1684001601000" MODIFIED="1684001604434"/>
<node ID="ID_915472855" CREATED="1684000113172" MODIFIED="1684000113172" LINK="https://github.com/freeplane/freeplane/discussions/835"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/freeplane/freeplane/discussions/835">Command line argument or URI to open file and jump to a specific node ID? · freeplane/freeplane · Discussion #835 · GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Checkboxes are for tasks or activity blocks on calendar" ID="ID_1476886353" CREATED="1650581851221" MODIFIED="1650581926054">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="Active Projects" ID="ID_836494682" CREATED="1675831847337" MODIFIED="1700330284541">
<icon BUILTIN="bookmark"/>
</node>
</node>
<node TEXT="Setup" FOLDED="true" ID="ID_1230296935" CREATED="1683999304078" MODIFIED="1683999306602">
<node TEXT="Autosave" ID="ID_1382897103" CREATED="1683999307418" MODIFIED="1683999311567"/>
</node>
<node TEXT="Freeplane Usage" FOLDED="true" ID="ID_424095239" CREATED="1519760814192" MODIFIED="1536182920194">
<icon BUILTIN="info"/>
<font NAME="Nirmala UI" SIZE="14"/>
<node TEXT="!Notes" FOLDED="true" ID="ID_550430356" CREATED="1716218811534" MODIFIED="1716218847517">
<font BOLD="true"/>
<node TEXT="note editing behavior changes based on if you are in outline view or not" FOLDED="true" ID="ID_1526953795" CREATED="1716218822991" MODIFIED="1716218838443">
<node TEXT="If node is it being placed at end, then change from outline mode" ID="ID_1484645832" CREATED="1716184815345" MODIFIED="1716184848517"/>
<node TEXT="pasting nodes" ID="ID_1813556746" CREATED="1716218851568" MODIFIED="1716218857972"/>
<node TEXT="changing hierarchy" ID="ID_571366227" CREATED="1716218858910" MODIFIED="1716218863109"/>
</node>
</node>
<node TEXT="jump to node from outside of the app" FOLDED="true" ID="ID_1688089550" CREATED="1716491548749" MODIFIED="1716492226822">
<node TEXT="use Win+R or shortcut" ID="ID_607781642" CREATED="1716492194210" MODIFIED="1716492209451"/>
<node ID="ID_1811155592" CREATED="1716491560526" MODIFIED="1716491560526" LINK="https://github.com/freeplane/freeplane/discussions/835"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/freeplane/freeplane/discussions/835">Command line argument or URI to open file and jump to a specific node ID? · freeplane/freeplane · Discussion #835</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="improvements" FOLDED="true" ID="ID_955351238" CREATED="1622557871231" MODIFIED="1622557876280">
<node TEXT="move location of center to middle top" ID="ID_837542412" CREATED="1622557877451" MODIFIED="1622557887483"/>
</node>
<node TEXT="Keyboard Shortcuts" FOLDED="true" ID="ID_1723912226" CREATED="1519775228883" MODIFIED="1519775236773">
<node TEXT="Change to" FOLDED="true" ID="ID_208977864" CREATED="1716218894037" MODIFIED="1716218897150">
<node TEXT="" ID="ID_1746252515" CREATED="1716219052330" MODIFIED="1716219052330">
<hook NAME="FirstGroupNode"/>
</node>
<node TEXT="" ID="ID_1395632654" CREATED="1716219033318" MODIFIED="1716219033318">
<hook NAME="FirstGroupNode"/>
</node>
<node TEXT="" ID="ID_1635396653" CREATED="1716219052325" MODIFIED="1716219052330">
<hook NAME="SummaryNode"/>
<hook NAME="AlwaysUnfoldedNode"/>
<node TEXT="fg" ID="ID_300453430" CREATED="1716219052331" MODIFIED="1716219053870"/>
</node>
<node TEXT="match caster rules" ID="ID_1361321382" CREATED="1716218951023" MODIFIED="1716218959960"/>
<node TEXT="" ID="ID_1304204928" CREATED="1716219033315" MODIFIED="1716219033318">
<hook NAME="SummaryNode"/>
<hook NAME="AlwaysUnfoldedNode"/>
<node TEXT="" ID="ID_1724846998" CREATED="1716219033321" MODIFIED="1716219033321"/>
</node>
</node>
</node>
<node TEXT="Transfer from Onenote" FOLDED="true" ID="ID_576545906" CREATED="1519760572911" MODIFIED="1519760587070">
<node TEXT="Onenote transfer" FOLDED="true" ID="ID_1929948543" CREATED="1683997088236" MODIFIED="1683997673271">
<node TEXT="from" FOLDED="true" ID="ID_1359691968" CREATED="1683997675461" MODIFIED="1683997676725">
<node TEXT="copy" ID="ID_1001187324" CREATED="1683997099455" MODIFIED="1683997101389"/>
<node TEXT="on desired Node, paste As.., Plain text as Node hierarchy" ID="ID_510024061" CREATED="1683997102159" MODIFIED="1683997221688"/>
</node>
<node TEXT="to" FOLDED="true" ID="ID_342091593" CREATED="1683997679997" MODIFIED="1683997681602">
<node TEXT="link to OneNote through web" ID="ID_976982371" CREATED="1683255573746" MODIFIED="1683255584134"/>
</node>
</node>
</node>
<node TEXT="Icon Guide" FOLDED="true" ID="ID_501809413" CREATED="1519759991717" MODIFIED="1519759997480">
<node TEXT="Task" ID="ID_1854948253" CREATED="1519760016422" MODIFIED="1519760023213">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="Habit" ID="ID_926378345" CREATED="1519760016422" MODIFIED="1519864110302">
<icon BUILTIN="unchecked"/>
<icon BUILTIN="unchecked"/>
<icon BUILTIN="clock"/>
</node>
<node TEXT="(!) To do" ID="ID_1415352444" CREATED="1519760024667" MODIFIED="1547049325950"/>
<node TEXT="Review" ID="ID_1470721092" CREATED="1519760070213" MODIFIED="1519760076047">
<icon BUILTIN="xmag"/>
</node>
<node TEXT="Reorganize" ID="ID_408040355" CREATED="1519761571101" MODIFIED="1519761586112">
<icon BUILTIN="help"/>
</node>
<node TEXT="Access" ID="ID_1081136875" CREATED="1519763158987" MODIFIED="1519763178127">
<icon BUILTIN="password"/>
</node>
<node TEXT="To Be Refined" ID="ID_729886864" CREATED="1519773176026" MODIFIED="1519773184004">
<icon BUILTIN="pencil"/>
</node>
</node>
<node TEXT="Clone" FOLDED="true" ID="ID_1901486656" CREATED="1519864291172" MODIFIED="1519864295729">
<node TEXT="Creates copy of node, with changes matched" ID="ID_1487126333" CREATED="1519864296759" MODIFIED="1519864436893"/>
</node>
</node>
<node TEXT="add-ons" FOLDED="true" ID="ID_372879423" CREATED="1622822614921" MODIFIED="1622822619216">
<node TEXT="used" FOLDED="true" ID="ID_901693127" CREATED="1622823158315" MODIFIED="1622823161019">
<node ID="ID_172997201" CREATED="1716869594790" MODIFIED="1716869594790" LINK="https://www.itworks.hu/portfolio/freeplane-gtd/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.itworks.hu/portfolio/freeplane-gtd/">ITWorks - Freeplane GTD+</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="wikd node" ID="ID_1672870849" CREATED="1687366549724" MODIFIED="1687366555710"/>
<node TEXT="Jumper" FOLDED="true" ID="ID_1460616690" CREATED="1687366576781" MODIFIED="1687366579063">
<node ID="ID_1007594471" CREATED="1622823151133" MODIFIED="1622823151133" LINK="https://github.com/lilive/Freeplane-Jumper/releases/tag/v1.0.1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/lilive/Freeplane-Jumper/releases/tag/v1.0.1">Release v1.0.1 · lilive/Freeplane-Jumper · GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_1624279671" CREATED="1622822621149" MODIFIED="1622822621149" LINK="https://sourceforge.net/p/freeplane/discussion/758437/thread/1603e503/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sourceforge.net/p/freeplane/discussion/758437/thread/1603e503/">Freeplane / Discussion / Open Discussion: The Freeplane Task Time Tracker</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Viewers on alternative OSes" FOLDED="true" ID="ID_1899428840" CREATED="1716218773212" MODIFIED="1716218780727">
<node TEXT="Android" FOLDED="true" ID="ID_841675451" CREATED="1688929347997" MODIFIED="1688929350471">
<node TEXT="Z Mind" FOLDED="true" ID="ID_707863750" CREATED="1688929351637" MODIFIED="1688929359094">
<node TEXT="view as list" ID="ID_1436663409" CREATED="1688929359740" MODIFIED="1688929363024"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="troubleshooting updates" FOLDED="true" ID="ID_516175284" CREATED="1622215461321" MODIFIED="1622220485026">
<node TEXT="fix update problems" FOLDED="true" ID="ID_1152566951" CREATED="1622215472069" MODIFIED="1622220441874">
<node TEXT="✔REBOOT/RESTART your PC/Laptop" ID="ID_1308713566" CREATED="1622215516698" MODIFIED="1622215516698"/>
<node TEXT="Open Command Prompt(Admin)" ID="ID_526613490" CREATED="1622215516698" MODIFIED="1622215516698"/>
<node TEXT="✔ type SFC /SCANNOW &amp; hit enter" ID="ID_1745204188" CREATED="1622215516789" MODIFIED="1622215516789"/>
<node TEXT="if corrupted files detected &amp; repaired, run SFC again." ID="ID_928307474" CREATED="1622215516789" MODIFIED="1622215516789"/>
<node TEXT="✔ type DISM /ONLINE /CLEANUP-IMAGE /SCANHEALTH &amp; hit enter" ID="ID_1539186876" CREATED="1622215516798" MODIFIED="1622215516798"/>
<node TEXT="✔ type EXIT &amp; hit enter." ID="ID_99128833" CREATED="1622215516798" MODIFIED="1622215516798"/>
</node>
<node TEXT="Remove sound devices" ID="ID_1378741792" CREATED="1622220444646" MODIFIED="1622220456395"/>
</node>
</node>
<node TEXT="Windows 7" FOLDED="true" ID="ID_229636613" CREATED="1580652358473" MODIFIED="1580652367469">
<node TEXT="image copy" ID="ID_1120427976" CREATED="1580653040116" MODIFIED="1580653044372"/>
<node ID="ID_1719593237" CREATED="1580652370160" MODIFIED="1580652370160" LINK="https://www.lifewire.com/how-to-install-windows-7-from-usb-2626264"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.lifewire.com/how-to-install-windows-7-from-usb-2626264">How to Install Windows 7 From USB (Flash Drive, Ext HD)</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="jxvcd-wdbm2-jjjfr-8h7j4-jhfv6" ID="ID_674833047" CREATED="1580652550410" MODIFIED="1580652550410"/>
</node>
<node TEXT="Bugs" FOLDED="true" ID="ID_1357588722" CREATED="1550090315718" MODIFIED="1550090318281">
<node ID="ID_476457624" CREATED="1550090320110" MODIFIED="1550090320110" LINK="https://superuser.com/questions/587971/windows-shortcut-utility-to-switch-between-application-windows?noredirect=1&amp;lq=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://superuser.com/questions/587971/windows-shortcut-utility-to-switch-between-application-windows?noredirect=1&amp;lq=1">Windows Shortcut/Utility to switch between application windows - Super User</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1009800915" CREATED="1550090345962" MODIFIED="1550090345962" LINK="https://superuser.com/questions/1332923/ctrl-win-num-stopped-working-after-windows-10-updated-to-ver-1803"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://superuser.com/questions/1332923/ctrl-win-num-stopped-working-after-windows-10-updated-to-ver-1803">hotkeys - Ctrl + Win + Num stopped working after Windows 10 updated to ver. 1803 - Super User</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="File Management" FOLDED="true" ID="ID_1541787028" CREATED="1624038601073" MODIFIED="1624038605010">
<node TEXT="file browser" FOLDED="true" ID="ID_1881686268" CREATED="1624038642062" MODIFIED="1624038645828">
<node TEXT="double commander" ID="ID_1539348382" CREATED="1624038647658" MODIFIED="1624038654874"/>
</node>
<node TEXT="change file associations" FOLDED="true" ID="ID_1345803892" CREATED="1624052348346" MODIFIED="1624052352980">
<node ID="ID_1990273718" CREATED="1624052353605" MODIFIED="1624052353605" LINK="http://woshub.com/managing-default-file-associations-in-windows-10/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://woshub.com/managing-default-file-associations-in-windows-10/">Changing Default File Associations in Windows 10 via GPO | Windows OS Hub</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="disc cleanup" FOLDED="true" ID="ID_1059041722" CREATED="1624039665297" MODIFIED="1624039675678">
<node TEXT="find large sized folders" FOLDED="true" ID="ID_1789910563" CREATED="1624038614279" MODIFIED="1624038628729">
<node ID="ID_1477691833" CREATED="1624038606316" MODIFIED="1624038606316" LINK="https://www.fosshub.com/WinDirStat.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.fosshub.com/WinDirStat.html">Download WinDirStat latest release</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="WinDirStat.lnk" ID="ID_483679448" CREATED="1624040391746" MODIFIED="1624040391750" LINK="../../../../Users/u581917/AppData/Roaming/Microsoft/Windows/Start%20Menu/Programs/WinDirStat/WinDirStat.lnk"/>
</node>
<node ID="ID_1379502315" CREATED="1624039681976" MODIFIED="1624039681976" LINK="https://superuser.com/questions/786288/what-is-in-c-ccmcache"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://superuser.com/questions/786288/what-is-in-c-ccmcache">windows 7 - What is in `C:\ccmcache`? - Super User</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Email" FOLDED="true" ID="ID_528569090" CREATED="1662591205179" MODIFIED="1662591207970">
<node TEXT="Gmail" ID="ID_420201090" CREATED="1662591208941" MODIFIED="1662591211781"/>
</node>
</node>
<node TEXT="Essential Apps:" FOLDED="true" POSITION="bottom_or_right" ID="ID_1233445410" CREATED="1649782429346" MODIFIED="1649782433447">
<node TEXT="Files" FOLDED="true" ID="ID_1267543223" CREATED="1684814761082" MODIFIED="1684814764388">
<node TEXT="Google Drive" ID="ID_1308786411" CREATED="1684814770397" MODIFIED="1684814775020"/>
<node TEXT="OneDrive" FOLDED="true" ID="ID_94498774" CREATED="1649782448071" MODIFIED="1649782448071">
<node TEXT="Disable office updating files if using WPS Office:" ID="ID_1774279582" CREATED="1649782448071" MODIFIED="1649782448071"/>
<node TEXT="Onedrive renaming and duplicating files - Windows Central Forums" ID="ID_350221683" CREATED="1649782448072" MODIFIED="1649782582811" LINK="https://forums.windowscentral.com/onedrive/410913-onedrive-renaming-duplicating-files.html"/>
</node>
</node>
<node TEXT="File Explorer" FOLDED="true" ID="ID_300080546" CREATED="1649782448072" MODIFIED="1649782448072">
<node TEXT="One Commander" ID="ID_1363544151" CREATED="1684817906560" MODIFIED="1684817910532"/>
<node TEXT="unused" FOLDED="true" ID="ID_1853381276" CREATED="1684817913057" MODIFIED="1684817914906">
<node TEXT="Double Commander,File browser" FOLDED="true" ID="ID_434617677" CREATED="1649782448083" MODIFIED="1649782448083">
<node TEXT="Shortcut for renaming only filename - Double Commander" ID="ID_277425801" CREATED="1649782448083" MODIFIED="1649782665830" LINK="https://doublecmd.h1n.ru/viewtopic.php?f=5&amp;t=3763&amp;p=20154&amp;hilit=rename+extension#p20154"/>
</node>
</node>
<node TEXT="Replace windows explorer as default file viewer in windows 10? - Super User" ID="ID_755931358" CREATED="1649782448083" MODIFIED="1649782623643" LINK="https://superuser.com/questions/1031250/replace-windows-explorer-as-default-file-viewer-in-windows-10"/>
</node>
<node TEXT="Android Emulation" FOLDED="true" ID="ID_1291197126" CREATED="1690921649377" MODIFIED="1690921656746">
<node TEXT="methods" FOLDED="true" ID="ID_1675867713" CREATED="1690928247642" MODIFIED="1690928249698">
<node TEXT="working" FOLDED="true" ID="ID_696326940" CREATED="1690928292883" MODIFIED="1690928297591">
<node ID="ID_167816584" CREATED="1690928304620" MODIFIED="1690928304620" LINK="https://www.ldplayer.net/download/install"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ldplayer.net/download/install">3. Download and Use LDPlayer on PC</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="virtual box" FOLDED="true" ID="ID_985248932" CREATED="1690928260723" MODIFIED="1690928264381">
<node TEXT="Get Virtuabox" ID="ID_559232029" CREATED="1690921867405" MODIFIED="1690921873702"/>
<node TEXT="Get ISO" FOLDED="true" ID="ID_727006884" CREATED="1690921859421" MODIFIED="1690921866903">
<node ID="ID_1455268872" CREATED="1690921684365" MODIFIED="1690921684365" LINK="https://www.tech21century.com/best-android-os-for-pc-computers/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tech21century.com/best-android-os-for-pc-computers/">22. 11 Best Android OS for PC Computers (32,64 bit) in 2023</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Install" FOLDED="true" ID="ID_470656437" CREATED="1690924252240" MODIFIED="1690924254836">
<node TEXT="Other Linux x64" ID="ID_1039785361" CREATED="1690924274137" MODIFIED="1690924291924"/>
<node TEXT="ext4" ID="ID_767685488" CREATED="1690924255609" MODIFIED="1690924258395"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1861555718" CREATED="1690926529146" MODIFIED="1690926531528">
<node ID="ID_1420890850" CREATED="1690926532445" MODIFIED="1690926532445" LINK="https://www.osboxes.org/primeos/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.osboxes.org/primeos/">25. PrimeOS Virtual Machine Images for VMware and VirtualBox</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="windows, amazon marketplace" FOLDED="true" ID="ID_1490554153" CREATED="1690928265526" MODIFIED="1690928271013">
<node ID="ID_675130913" CREATED="1690926641904" MODIFIED="1690926641904" LINK="https://www.androidauthority.com/android-apps-on-windows-11-3048569/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.androidauthority.com/android-apps-on-windows-11-3048569/">26. How to run Android apps on Windows 11: A detailed guide</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_720987458" CREATED="1690921739656" MODIFIED="1690921739656" LINK="https://www.howtogeek.com/164570/how-to-install-android-in-virtualbox/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.howtogeek.com/164570/how-to-install-android-in-virtualbox/">22. How to Install Android in VirtualBox</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="OneNote" FOLDED="true" ID="ID_1326821991" CREATED="1692158701875" MODIFIED="1692158709035">
<node ID="ID_967850136" CREATED="1699120160807" MODIFIED="1699120160807" LINK="https://www.reddit.com/r/OneNote/comments/v9hcvn/todo_view_as_list_option/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/OneNote/comments/v9hcvn/todo_view_as_list_option/">ToDo - view as list option : r/OneNote</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="updating" FOLDED="true" ID="ID_1564176181" CREATED="1699116978963" MODIFIED="1699116981336">
<node ID="ID_1802444218" CREATED="1699116982673" MODIFIED="1699116982673" LINK="https://answers.microsoft.com/en-us/msoffice/forum/all/onenote-update/df3528d2-45b2-491d-b094-3f99e824e1e1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://answers.microsoft.com/en-us/msoffice/forum/all/onenote-update/df3528d2-45b2-491d-b094-3f99e824e1e1">OneNote update? - Microsoft Community</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Done use directly for Syngenta notebooks" FOLDED="true" ID="ID_1948851649" CREATED="1696225165959" MODIFIED="1696225175881">
<node TEXT="LDPlayer" ID="ID_23737737" CREATED="1696225176765" MODIFIED="1696225383977"/>
</node>
<node ID="ID_1113918484" CREATED="1692158763267" MODIFIED="1692158763267" LINK="https://www.onenote.com/download"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.onenote.com/download">Download OneNote</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Language Checker" FOLDED="true" ID="ID_906887957" CREATED="1687935215513" MODIFIED="1687935225203">
<node TEXT="ProWritingAid" ID="ID_533155348" CREATED="1687935863434" MODIFIED="1687935868636"/>
</node>
<node TEXT="Google sheets" FOLDED="true" ID="ID_921631760" CREATED="1708816290231" MODIFIED="1708816296040">
<node TEXT="scripting" FOLDED="true" ID="ID_212130201" CREATED="1708816309906" MODIFIED="1708816312645">
<node ID="ID_1101930436" CREATED="1708816329429" MODIFIED="1708816329429" LINK="https://developers.google.com/apps-script/reference/spreadsheet/text-finder"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://developers.google.com/apps-script/reference/spreadsheet/text-finder">Class TextFinder &#xa0;|&#xa0;&#xa0;Apps Script &#xa0;|&#xa0;&#xa0;Google for Developers</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_220104048" CREATED="1708816313702" MODIFIED="1708816313702" LINK="https://stackoverflow.com/questions/19877554/how-to-replace-text-in-google-spreadsheet-using-app-scripts"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/19877554/how-to-replace-text-in-google-spreadsheet-using-app-scripts">How to replace text in Google Spreadsheet using App Scripts? - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="triggering" FOLDED="true" ID="ID_256067465" CREATED="1708818707621" MODIFIED="1708818714524">
<node TEXT="checkbox works too" ID="ID_1239879058" CREATED="1708818717466" MODIFIED="1708818728775"/>
<node ID="ID_322016553" CREATED="1708818715643" MODIFIED="1708818715643" LINK="https://webapps.stackexchange.com/questions/87346/add-a-script-trigger-to-google-sheet-that-will-work-in-android-mobile-app"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://webapps.stackexchange.com/questions/87346/add-a-script-trigger-to-google-sheet-that-will-work-in-android-mobile-app">Add a script trigger to Google Sheet that will work in Android mobile app - Web Applications Stack Exchange</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Office" FOLDED="true" ID="ID_1551117558" CREATED="1689032064434" MODIFIED="1689032066648">
<node TEXT="OnlyOffice" ID="ID_1297233631" CREATED="1689032069433" MODIFIED="1689032077773"/>
<node TEXT="LibreOffice" FOLDED="true" ID="ID_228503992" CREATED="1651121665267" MODIFIED="1651121673178">
<node TEXT="crashing" FOLDED="true" ID="ID_937833953" CREATED="1654058331106" MODIFIED="1654058336758">
<node TEXT="disable Fluent Search" ID="ID_1584639940" CREATED="1654058338523" MODIFIED="1654058348940"/>
</node>
<node TEXT="configuration" FOLDED="true" ID="ID_355642227" CREATED="1654056684412" MODIFIED="1654056687119">
<node TEXT="disable hardware acceleration" ID="ID_402447836" CREATED="1654056687823" MODIFIED="1654056692671"/>
</node>
<node ID="ID_1814410146" CREATED="1651121674886" MODIFIED="1651121674886" LINK="https://www.debugpoint.com/2020/01/how-to-enable-dark-mode-libreoffice/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.debugpoint.com/2020/01/how-to-enable-dark-mode-libreoffice/">How to Enable 'Dark Mode' in LibreOffice</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1055470897" CREATED="1651121772902" MODIFIED="1651121772902" LINK="https://itsfoss.com/libreoffice-dark-mode/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://itsfoss.com/libreoffice-dark-mode/">How to Go Full Dark Mode With LibreOffice</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Web Browser" FOLDED="true" ID="ID_1897568726" CREATED="1686862508664" MODIFIED="1686862511075">
<node TEXT="Edge" FOLDED="true" ID="ID_1114234580" CREATED="1649782448099" MODIFIED="1649782448099">
<node TEXT="How to Remove Edge Browser Tabs From Alt+Tab on Windows 10" ID="ID_657376365" CREATED="1649782448102" MODIFIED="1649782791656" LINK="https://www.howtogeek.com/696775/how-to-stop-alttab-from-showing-edge-browser-tabs/"/>
<node TEXT="Disable Swipe to refresh" FOLDED="true" ID="ID_1923126836" CREATED="1674310013628" MODIFIED="1674310021617">
<node ID="ID_965945002" CREATED="1674310022545" MODIFIED="1674310022545" LINK="https://www.askvg.com/tip-enable-pull-or-swipe-down-to-refresh-feature-in-google-chrome-on-desktop/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.askvg.com/tip-enable-pull-or-swipe-down-to-refresh-feature-in-google-chrome-on-desktop/">[Tip] Enable Pull or Swipe Down to Refresh Feature in Google Chrome on Desktop – AskVG</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_319285400" CREATED="1674310393034" MODIFIED="1674310393034" LINK="https://www.stevefenton.co.uk/blog/2019/10/disable-swipe-navigation-in-chrome-and-edge-chromium-edition/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.stevefenton.co.uk/blog/2019/10/disable-swipe-navigation-in-chrome-and-edge-chromium-edition/">Disable swipe navigation in Chrome and Edge (Chromium edition) | Steve Fenton</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Extensions" FOLDED="true" ID="ID_1091216384" CREATED="1686862513976" MODIFIED="1686862516609">
<node TEXT="Tabs" FOLDED="true" ID="ID_821198784" CREATED="1686862517705" MODIFIED="1686862519706">
<node ID="ID_1791114373" CREATED="1686862573957" MODIFIED="1686862573957" LINK="https://chrome.google.com/webstore/detail/chrome-show-tab-numbers/pflnpcinjbcfefgbejjfanemlgcfjbna/related"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://chrome.google.com/webstore/detail/chrome-show-tab-numbers/pflnpcinjbcfefgbejjfanemlgcfjbna/related">Chrome Show Tab Numbers - Chrome Web Store</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_461124129" CREATED="1686862520742" MODIFIED="1686862520742" LINK="https://chrome.google.com/webstore/detail/spark-tabs/mcbakkceggomfmikgcmcncoobaclkbam"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://chrome.google.com/webstore/detail/spark-tabs/mcbakkceggomfmikgcmcncoobaclkbam">Spark Tabs - Chrome Web Store</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node ID="ID_412790533" TREE_ID="ID_46579768">
<node ID="ID_1184969035" TREE_ID="ID_70175057">
<node ID="ID_1019636464" TREE_ID="ID_700032025">
<node ID="ID_1876938919" TREE_ID="ID_975816636"/>
<node ID="ID_1572791002" TREE_ID="ID_1048399413"/>
<node ID="ID_976981706" TREE_ID="ID_1341710059"/>
<node ID="ID_1900853425" TREE_ID="ID_1864350174"/>
<node ID="ID_1298926206" TREE_ID="ID_915472855"/>
</node>
<node ID="ID_1034231742" TREE_ID="ID_1476886353"/>
<node ID="ID_1720062811" TREE_ID="ID_836494682"/>
</node>
<node ID="ID_423882272" TREE_ID="ID_1230296935">
<node ID="ID_350644873" TREE_ID="ID_1382897103"/>
</node>
<node ID="ID_1082898612" TREE_ID="ID_424095239">
<node ID="ID_1751966274" TREE_ID="ID_550430356">
<node ID="ID_932254327" TREE_ID="ID_1526953795">
<node ID="ID_1450496220" TREE_ID="ID_1484645832"/>
<node TEXT="" ID="ID_982121719" CREATED="1716219066337" MODIFIED="1716219066337">
<hook NAME="FirstGroupNode"/>
</node>
<node ID="ID_1683369950" TREE_ID="ID_1813556746"/>
<node ID="ID_1950690819" TREE_ID="ID_571366227"/>
<node TEXT="" ID="ID_1821251383" CREATED="1716219066334" MODIFIED="1716219066337">
<hook NAME="SummaryNode"/>
<hook NAME="AlwaysUnfoldedNode"/>
<node TEXT="dsfs" ID="ID_866931398" CREATED="1716219066339" MODIFIED="1716219067433"/>
</node>
</node>
</node>
<node ID="ID_490199981" TREE_ID="ID_1688089550">
<node ID="ID_671620000" TREE_ID="ID_607781642"/>
<node ID="ID_1738973136" TREE_ID="ID_1811155592"/>
</node>
<node ID="ID_203436135" TREE_ID="ID_955351238">
<node ID="ID_1132216843" TREE_ID="ID_837542412"/>
</node>
<node ID="ID_27284819" TREE_ID="ID_1723912226">
<node ID="ID_1563011995" TREE_ID="ID_208977864">
<node ID="ID_1281010735" TREE_ID="ID_1746252515"/>
<node ID="ID_6972260" TREE_ID="ID_1395632654"/>
<node ID="ID_132145639" TREE_ID="ID_1635396653">
<node ID="ID_1404608080" TREE_ID="ID_300453430"/>
</node>
<node ID="ID_1877370495" TREE_ID="ID_1361321382"/>
<node ID="ID_1725673212" TREE_ID="ID_1304204928">
<node ID="ID_732790928" TREE_ID="ID_1724846998"/>
</node>
</node>
</node>
<node ID="ID_896569236" TREE_ID="ID_576545906">
<node ID="ID_1475465627" TREE_ID="ID_1929948543">
<node ID="ID_1102667355" TREE_ID="ID_1359691968">
<node ID="ID_1091805418" TREE_ID="ID_1001187324"/>
<node ID="ID_378316172" TREE_ID="ID_510024061"/>
</node>
<node ID="ID_8531968" TREE_ID="ID_342091593">
<node ID="ID_112250464" TREE_ID="ID_976982371"/>
</node>
</node>
</node>
<node ID="ID_1921768702" TREE_ID="ID_501809413">
<node ID="ID_1058394406" TREE_ID="ID_1854948253"/>
<node ID="ID_1906936060" TREE_ID="ID_926378345"/>
<node ID="ID_724604322" TREE_ID="ID_1415352444"/>
<node ID="ID_1851867192" TREE_ID="ID_1470721092"/>
<node ID="ID_579711094" TREE_ID="ID_408040355"/>
<node ID="ID_947251158" TREE_ID="ID_1081136875"/>
<node ID="ID_635763244" TREE_ID="ID_729886864"/>
</node>
<node ID="ID_469153571" TREE_ID="ID_1901486656">
<node ID="ID_1573824355" TREE_ID="ID_1487126333"/>
</node>
</node>
<node ID="ID_683625594" TREE_ID="ID_372879423">
<node ID="ID_296516913" TREE_ID="ID_901693127">
<node ID="ID_95403579" TREE_ID="ID_172997201"/>
<node ID="ID_1529233286" TREE_ID="ID_1672870849"/>
<node ID="ID_934471547" TREE_ID="ID_1460616690">
<node ID="ID_142806293" TREE_ID="ID_1007594471"/>
</node>
</node>
<node ID="ID_1116416037" TREE_ID="ID_1624279671"/>
</node>
<node ID="ID_394084216" TREE_ID="ID_1899428840">
<node ID="ID_1535161816" TREE_ID="ID_841675451">
<node ID="ID_493952587" TREE_ID="ID_707863750">
<node ID="ID_1661678334" TREE_ID="ID_1436663409"/>
</node>
</node>
</node>
</node>
<node TEXT="Text Editor" FOLDED="true" ID="ID_915898542" CREATED="1685209738929" MODIFIED="1685209743268">
<node TEXT="&apos;body&apos;:&#xa;  &apos;ctrl-tab&apos;: &apos;pane:show-next-item&apos;&#xa;  &apos;ctrl-shift-tab&apos;: &apos;pane:show-previous-item&apos;" ID="ID_1606355018" CREATED="1686109370532" MODIFIED="1686109385179"/>
<node FOLDED="true" ID="ID_535191626" CREATED="1685210889668" MODIFIED="1685210889668" LINK="https://github.com/atom/atom/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/atom/atom/releases">Releases · atom/atom</a>
  </body>
</html>
</richcontent>
<node TEXT="edit &quot;C:\Users\micha\.atom\keymap.cson&quot;" ID="ID_1599264492" CREATED="1686109342076" MODIFIED="1686109396754"/>
</node>
<node ID="ID_1256530414" CREATED="1685209753001" MODIFIED="1685209753001" LINK="https://www.sublimetext.com/download_thanks?target=win-x64"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.sublimetext.com/download_thanks?target=win-x64">Thank You - Sublime Text</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Backup" FOLDED="true" POSITION="bottom_or_right" ID="ID_849145665" CREATED="1689011534534" MODIFIED="1689011537336">
<node ID="ID_1446504252" CREATED="1689011812182" MODIFIED="1689011812182" LINK="https://www.windowscentral.com/how-make-full-backup-windows-10"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.windowscentral.com/how-make-full-backup-windows-10">13. How to make a full backup of your Windows 10 PC | Windows Central</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Applications" FOLDED="true" ID="ID_839763807" CREATED="1611254200888" MODIFIED="1611254209036">
<node TEXT="Email" FOLDED="true" ID="ID_1822275146" CREATED="1613754330672" MODIFIED="1613754333260">
<node ID="ID_1587293306" CREATED="1613754335056" MODIFIED="1613754335056" LINK="https://addons.thunderbird.net/en-US/thunderbird/addon/nostalgy_ng/?src=search"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://addons.thunderbird.net/en-US/thunderbird/addon/nostalgy_ng/?src=search">Manage emails / Nostalgy++ for TB78 :: Add-ons for Thunderbird</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_654979514" CREATED="1613760682095" MODIFIED="1613760682095" LINK="https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040?ui=en-us&amp;rs=en-us&amp;ad=us"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040?ui=en-us&amp;rs=en-us&amp;ad=us">POP, IMAP, and SMTP settings for Outlook.com - Outlook</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_674662675" CREATED="1613763674441" MODIFIED="1613763674441" LINK="https://support.microsoft.com/en-us/office/pop-imap-and-stmp-settings-8361e398-8af4-4e97-b147-6c6c4ac95353"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.microsoft.com/en-us/office/pop-imap-and-stmp-settings-8361e398-8af4-4e97-b147-6c6c4ac95353">POP, IMAP, and STMP settings - Office Support</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1416814189" CREATED="1613763961399" MODIFIED="1613763961399" LINK="https://support.microsoft.com/en-us/office/add-an-email-account-to-outlook-6e27792a-9267-4aa4-8bb6-c84ef146101b?ui=en-US&amp;rs=en-US&amp;ad=US"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.microsoft.com/en-us/office/add-an-email-account-to-outlook-6e27792a-9267-4aa4-8bb6-c84ef146101b?ui=en-US&amp;rs=en-US&amp;ad=US">Add an email account to Outlook - Office Support</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1152312955" CREATED="1614375874793" MODIFIED="1614375874793" LINK="https://docs.microsoft.com/en-us/microsoft-365/enterprise/urls-and-ip-address-ranges?view=o365-worldwide"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.microsoft.com/en-us/microsoft-365/enterprise/urls-and-ip-address-ranges?view=o365-worldwide">Office 365 URLs and IP address ranges - Microsoft 365 Enterprise | Microsoft Docs</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1647899374" CREATED="1614376002352" MODIFIED="1614376002352" LINK="https://portal.office.com/account/?ref=MeControl#"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://portal.office.com/account/?ref=MeControl#">My account</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1252208329" CREATED="1617726257150" MODIFIED="1617726257150" LINK="https://kb.uwm.edu/uwmhd/page.php?id=109671"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://kb.uwm.edu/uwmhd/page.php?id=109671">Thunderbird - Configure OAuth2 (Modern Authenticaiton)</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_690550213" CREATED="1617726844123" MODIFIED="1617726844123" LINK="https://www.g-ipc.shimane-u.ac.jp/_files/00220798/office365_mfa_set_thunderbird_modern_en.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.g-ipc.shimane-u.ac.jp/_files/00220798/office365_mfa_set_thunderbird_modern_en.pdf">office365_mfa_set_thunderbird_modern_en.pdf</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1673626299" CREATED="1617728548119" MODIFIED="1617728548119" LINK="https://support.mozilla.org/en-US/questions/1171201"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.mozilla.org/en-US/questions/1171201">How to disable saving of passwords in Thunderbird ? | Thunderbird Support Forum | Mozilla Support</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_801720732" CREATED="1617732536518" MODIFIED="1617732536518" LINK="https://forums.slipstick.com/threads/88135-looking-for-a-productivity-add-in-similar-to-nostalgy-for-thunderbird/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://forums.slipstick.com/threads/88135-looking-for-a-productivity-add-in-similar-to-nostalgy-for-thunderbird/">Looking for a productivity add-in similar to &quot;Nostalgy&quot; for Thunderbird | Outlook Forums by Slipstick.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Office" FOLDED="true" ID="ID_1728051684" CREATED="1619120703334" MODIFIED="1619120711242">
<node TEXT="WPS office" FOLDED="true" ID="ID_1963443882" CREATED="1619120712048" MODIFIED="1619120720021">
<node TEXT="Keyboard shortcuts" FOLDED="true" ID="ID_1967925606" CREATED="1623167782619" MODIFIED="1623167788470">
<node TEXT="assign" FOLDED="true" ID="ID_467242978" CREATED="1623167772462" MODIFIED="1623167804240">
<node TEXT="Options, General And Save, Shortcuts, Custom Shortcuts:" ID="ID_812223771" CREATED="1623167811058" MODIFIED="1623167864156"/>
</node>
<node ID="ID_1774748448" CREATED="1619120726464" MODIFIED="1619120726464" LINK="https://help.wps.com/articles/list-of-keyboard-shortcuts-for-spreadsheets"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://help.wps.com/articles/list-of-keyboard-shortcuts-for-spreadsheets">Keyboard Shortcuts in WPS Spreadsheets</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Microsoft Office" FOLDED="true" ID="ID_664672417" CREATED="1611254210192" MODIFIED="1611254215303">
<node TEXT="Outlook" FOLDED="true" ID="ID_476355294" CREATED="1611254217503" MODIFIED="1611254222051">
<node ID="ID_1033197879" CREATED="1611254223558" MODIFIED="1611254223558" LINK="https://www.extendoffice.com/documents/outlook/5111-outlook-assign-category-and-move-to-folder.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.extendoffice.com/documents/outlook/5111-outlook-assign-category-and-move-to-folder.html">How to move emails to specified folder after assigning certain category in Outlook?</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_80226407" CREATED="1611254238497" MODIFIED="1611254238497" LINK="https://support.microsoft.com/en-us/office/keyboard-shortcuts-for-outlook-3cdeb221-7ae5-4c1d-8c1d-9e63216c1efd"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      <a href="https://support.microsoft.com/en-us/office/keyboard-shortcuts-for-outlook-3cdeb221-7ae5-4c1d-8c1d-9e63216c1efd">Keyboard shortcuts for Outlook - Office Support</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1529734631" CREATED="1612540696859" MODIFIED="1612540696859" LINK="https://www.extendoffice.com/documents/outlook/5109-outlook-keep-category-replying.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.extendoffice.com/documents/outlook/5109-outlook-keep-category-replying.html">How to keep original categories when replying or forwarding email in Outlook?</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Troubleshooting" FOLDED="true" ID="ID_1040261866" CREATED="1705787983058" MODIFIED="1705787989790">
<node TEXT="Remove Bluetooth device" FOLDED="true" ID="ID_1277753317" CREATED="1705787990467" MODIFIED="1705787997074">
<node ID="ID_1310471644" CREATED="1705787998599" MODIFIED="1705787998599"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: rgb(242, 242, 242); font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, sans-serif; font-size: 14px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(11, 20, 22); display: inline !important; float: none"><font color="rgb(242, 242, 242)" face="-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, sans-serif" size="14px">- using the device manager in the old control panel UI, you can find the device's id. i then nuked it from Computer\HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\BTHPORT\Parameters\Devices\{yourdeviceid}</font></span>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Android" ID="ID_651534525" CREATED="1694745681061" MODIFIED="1694879652531">
<node TEXT="Interface" ID="ID_561710994" CREATED="1713903604300" MODIFIED="1713903606560">
<node TEXT="off-line speech recognition" ID="ID_1862416990" CREATED="1713903609674" MODIFIED="1713903613210">
<node ID="ID_426200002" CREATED="1713903685275" MODIFIED="1713903685275" LINK="https://support.google.com/accessibility/android/answer/6151848?hl=en#zippy=%2Coptional-other-ways-to-start-voice-access"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.google.com/accessibility/android/answer/6151848?hl=en#zippy=%2Coptional-other-ways-to-start-voice-access">Get started with Voice Access spoken commands - Android Accessibility Help</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Android" ID="ID_1792213629" CREATED="1694745610010" MODIFIED="1694745612723">
<node TEXT="interfacing with windows" ID="ID_1587775143" CREATED="1694745629127" MODIFIED="1694745632079">
<node TEXT="use a shared document" ID="ID_1376095739" CREATED="1694745634416" MODIFIED="1694745637986"/>
</node>
</node>
<node TEXT="gboard" FOLDED="true" ID="ID_1366033576" CREATED="1694745615933" MODIFIED="1694745619927">
<node TEXT="reference" FOLDED="true" ID="ID_874796039" CREATED="1694745659833" MODIFIED="1694745661759">
<node ID="ID_1273071394" CREATED="1694745662385" MODIFIED="1694745662385" LINK="https://www.computerworld.com/article/3631590/gboard-android-google-enhancement.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.computerworld.com/article/3631590/gboard-android-google-enhancement.html">The most important enhancement you can make to Gboard on Android | Computerworld</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="reference" ID="ID_1058360514" CREATED="1694745993222" MODIFIED="1694745994936">
<node ID="ID_299070914" CREATED="1694745995778" MODIFIED="1694745995778" LINK="https://www.techworm.net/2022/06/best-android-os-pc.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.techworm.net/2022/06/best-android-os-pc.html">12 Best Android OS for PC (64 bit/ 32bit)- 2023</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1011745791" CREATED="1694746389726" MODIFIED="1694746389726" LINK="https://fydeos.io/download/vm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://fydeos.io/download/vm">Download - FydeOS</a>
  </body>
</html>
</richcontent>
<node TEXT="reference" FOLDED="true" ID="ID_1458310193" CREATED="1694746609728" MODIFIED="1694746611699">
<node ID="ID_1255939962" CREATED="1694746612500" MODIFIED="1694746612500" LINK="https://fydeos.io/docs/knowledge-base/getting-started/instructions-vmware/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://fydeos.io/docs/knowledge-base/getting-started/instructions-vmware/">FydeOS for VMware Installation Instructions - FydeOS</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="BlissOS" FOLDED="true" ID="ID_1159594651" CREATED="1694839145488" MODIFIED="1694839148650">
<node ID="ID_1829700965" CREATED="1694880236722" MODIFIED="1694880236722" LINK="https://docs.blissos.org/installation/install-in-a-virtual-machine/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.blissos.org/installation/install-in-a-virtual-machine/">Install in a Virtual Machine</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_340811405" CREATED="1694839155178" MODIFIED="1694839155178" LINK="https://blissos.org/index.html#download"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://blissos.org/index.html#download">Bliss OS For PC</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="PrimeOS" FOLDED="true" ID="ID_1749255407" CREATED="1694745684779" MODIFIED="1694745688319">
<node ID="ID_1865875948" CREATED="1694745701108" MODIFIED="1694745701108" LINK="https://androidpctv.com/tutorial-primeos-install-android/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://androidpctv.com/tutorial-primeos-install-android/">TUTORIAL: PrimeOS how to install Android on your PC</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Linux" FOLDED="true" ID="ID_1648508543" CREATED="1539701341303" MODIFIED="1539701344295">
<node TEXT="window manager" FOLDED="true" ID="ID_194794539" CREATED="1657813779051" MODIFIED="1657813783403">
<node ID="ID_1688164350" CREATED="1657813784586" MODIFIED="1657813784586" LINK="https://xmonad.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://xmonad.org/">home | xmonad - the tiling window manager that rocks</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Sound" FOLDED="true" ID="ID_1029033583" CREATED="1546977565218" MODIFIED="1546977568993">
<node TEXT="ALSA" FOLDED="true" ID="ID_1105784816" CREATED="1546977570450" MODIFIED="1546977573454">
<node TEXT="working" ID="ID_979283791" CREATED="1546977574307" MODIFIED="1546977576167"/>
<node ID="ID_1550394779" CREATED="1546977782357" MODIFIED="1546977782357" LINK="https://www.maketecheasier.com/alsa-utilities-manage-linux-audio-command-line/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.maketecheasier.com/alsa-utilities-manage-linux-audio-command-line/">How to Use ALSA Utilities to Manage Linux Audio from the Terminal - Make Tech Easier</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1111280683" CREATED="1547069406297" MODIFIED="1547069406297" LINK="http://sandsoftwaresound.net/get-started-alsa-jack/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://sandsoftwaresound.net/get-started-alsa-jack/">Get started: Linux ALSA and JACK | Sand, software and sound</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Jack" FOLDED="true" ID="ID_1840331095" CREATED="1547070425669" MODIFIED="1547070429211">
<node ID="ID_812751957" CREATED="1547070430053" MODIFIED="1547070430053" LINK="http://write.flossmanuals.net/ardour/starting-jack-on-ubuntu/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://write.flossmanuals.net/ardour/starting-jack-on-ubuntu/">/chapter: Starting-Jack-On-Ubuntu / ARDOUR</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Music" FOLDED="true" ID="ID_1380849820" CREATED="1546878233278" MODIFIED="1546878242977">
<node TEXT="Saffire PRO 24 DSP" FOLDED="true" ID="ID_890136001" CREATED="1546877807042" MODIFIED="1546877816908">
<node TEXT="ffado" FOLDED="true" ID="ID_973709013" CREATED="1546877817905" MODIFIED="1546877826083">
<node ID="ID_254964112" CREATED="1546878210059" MODIFIED="1546878210059" LINK="https://www.linuxmusicians.com/viewtopic.php?t=19385"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.linuxmusicians.com/viewtopic.php?t=19385">Is the limitation me, or ffado support for my Saffire Pro 24 DSP? - LinuxMusicians</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="DAW" FOLDED="true" ID="ID_1805098824" CREATED="1546880361834" MODIFIED="1546880363845">
<node TEXT="pure data" ID="ID_1525089537" CREATED="1546976307171" MODIFIED="1546976309532"/>
<node TEXT="LMMS" ID="ID_206899606" CREATED="1546976441093" MODIFIED="1546976443097"/>
<node TEXT="Non" FOLDED="true" ID="ID_1153948267" CREATED="1547071386723" MODIFIED="1547071390305">
<node TEXT="Install" FOLDED="true" ID="ID_634080811" CREATED="1547071392819" MODIFIED="1547071395809">
<node FOLDED="true" ID="ID_1824034558" CREATED="1546880365445" MODIFIED="1546880365445" LINK="http://non.tuxfamily.org/wiki/Downloads?_sm_au_=iVVsFMfqd6QnVSNP"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://non.tuxfamily.org/wiki/Downloads?_sm_au_=iVVsFMfqd6QnVSNP">Downloads | Non</a>
  </body>
</html>
</richcontent>
<node TEXT="Prebuilt" FOLDED="true" ID="ID_1882057202" CREATED="1547066838567" MODIFIED="1547066845094">
<node ID="ID_577328459" CREATED="1547066846645" MODIFIED="1547066846645" LINK="http://kxstudio.linuxaudio.org/Repositories"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://kxstudio.linuxaudio.org/Repositories">KXStudio : Repositories</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1150685655" CREATED="1547067394638" MODIFIED="1547067394638" LINK="http://non.tuxfamily.org/wiki/BinaryPackagesAndBuilds?_sm_au_=iVVtMPjjSnrq7jWr"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://non.tuxfamily.org/wiki/BinaryPackagesAndBuilds?_sm_au_=iVVtMPjjSnrq7jWr">BinaryPackagesAndBuilds | Non</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Build Non" FOLDED="true" ID="ID_25922406" CREATED="1547048382995" MODIFIED="1547048839952">
<icon BUILTIN="yes"/>
<node TEXT="dependancies" FOLDED="true" ID="ID_1312334683" CREATED="1546986691834" MODIFIED="1546987727164">
<node TEXT="gcc" ID="ID_478902810" CREATED="1546987733009" MODIFIED="1546987736539"/>
<node TEXT="g++" ID="ID_692721468" CREATED="1546987745107" MODIFIED="1546987748087"/>
<node TEXT="clang++" FOLDED="true" ID="ID_785563347" CREATED="1546987710417" MODIFIED="1546987713998">
<node ID="ID_1678251160" CREATED="1546986688704" MODIFIED="1546986688704" LINK="https://askubuntu.com/questions/509218/how-to-install-clang"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://askubuntu.com/questions/509218/how-to-install-clang">gcc - How to install clang++? - Ask Ubuntu</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="pkg-config" ID="ID_1230770805" CREATED="1546991504325" MODIFIED="1546991512932"/>
<node TEXT="x11" FOLDED="true" ID="ID_1441441637" CREATED="1546987705064" MODIFIED="1546987706980">
<node ID="ID_1948457250" CREATED="1546987694901" MODIFIED="1546987694901" LINK="https://askubuntu.com/questions/213678/how-to-install-x11-xorg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://askubuntu.com/questions/213678/how-to-install-x11-xorg">software installation - How to install X11/xorg? - Ask Ubuntu</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="sudo apt-get install libx11-dev" ID="ID_350311121" CREATED="1546989743090" MODIFIED="1546989743090"/>
</node>
<node TEXT="fontconfig" FOLDED="true" ID="ID_193129821" CREATED="1546991430099" MODIFIED="1546991434831">
<node TEXT="libfontconfig1-dev" ID="ID_838292335" CREATED="1546991436019" MODIFIED="1546991455127"/>
<node ID="ID_1339571282" CREATED="1547059963571" MODIFIED="1547059963571" LINK="http://www.linuxfromscratch.org/blfs/view/svn/general/fontconfig.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.linuxfromscratch.org/blfs/view/svn/general/fontconfig.html">Fontconfig-2.13.1</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="xft" FOLDED="true" ID="ID_58112673" CREATED="1546991572606" MODIFIED="1546991576163">
<node TEXT="libghc-x11-xft-dev" ID="ID_1138856528" CREATED="1546991577437" MODIFIED="1546991931045"/>
</node>
<node TEXT="cairo" FOLDED="true" ID="ID_164388687" CREATED="1546991933015" MODIFIED="1546991935661">
<node TEXT="guile-cairo-dev" ID="ID_1362100062" CREATED="1546992018945" MODIFIED="1546992127600"/>
<node ID="ID_645991749" CREATED="1547059681641" MODIFIED="1547059681641" LINK="https://www.cairographics.org/news/cairo-1.16.0/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.cairographics.org/news/cairo-1.16.0/">cairo-1.16.0</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_905012438" CREATED="1547059770685" MODIFIED="1547059770685" LINK="http://www.linuxfromscratch.org/blfs/view/svn/x/cairo.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.linuxfromscratch.org/blfs/view/svn/x/cairo.html">Cairo-1.16.0</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="stdtypes.h" FOLDED="true" ID="ID_933317803" CREATED="1547063100512" MODIFIED="1547063107389">
<node ID="ID_625415463" CREATED="1547063108219" MODIFIED="1547063108219" LINK="http://www.softwarepreservation.org/projects/c_plus_plus/cfront/release_3.0.3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.softwarepreservation.org/projects/c_plus_plus/cfront/release_3.0.3">Release 3.0.3 &#8212; Software Preservation Group</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Docs" FOLDED="true" ID="ID_1766126017" CREATED="1547071433493" MODIFIED="1547071434762">
<node ID="ID_1554751703" CREATED="1547071444702" MODIFIED="1547071444702" LINK="http://non.tuxfamily.org/timeline/doc/MANUAL.html?_sm_au_=iVVtMPjjSnrq7jWr"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://non.tuxfamily.org/timeline/doc/MANUAL.html?_sm_au_=iVVtMPjjSnrq7jWr">Non Timeline User Manual</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1966083759" CREATED="1547071481972" MODIFIED="1547071481972" LINK="http://non.tuxfamily.org/mixer/doc/MANUAL.html?_sm_au_=iVVtMPjjSnrq7jWr"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://non.tuxfamily.org/mixer/doc/MANUAL.html?_sm_au_=iVVtMPjjSnrq7jWr">Non Mixer User Manual</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1945674885" CREATED="1547071631604" MODIFIED="1547071631604" LINK="http://non.tuxfamily.org/sequencer/doc/MANUAL.html?_sm_au_=iVVtMPjjSnrq7jWr"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://non.tuxfamily.org/sequencer/doc/MANUAL.html?_sm_au_=iVVtMPjjSnrq7jWr">The Non Sequencer</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_241174341" CREATED="1546976296122" MODIFIED="1546976296122" LINK="https://www.reddit.com/r/raspberry_pi/comments/3z4wal/incredibly_you_can_produce_music_on_a_raspberry/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.reddit.com/r/raspberry_pi/comments/3z4wal/incredibly_you_can_produce_music_on_a_raspberry/">Incredibly, you can produce music on a Raspberry Pi using Non, a DAW written by Jonathan Liles! : raspberry_pi</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1012033580" CREATED="1547136246743" MODIFIED="1547136246743" LINK="https://en.wikipedia.org/wiki/Comparison_of_MIDI_editors_and_sequencers"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://en.wikipedia.org/wiki/Comparison_of_MIDI_editors_and_sequencers">Comparison of MIDI editors and sequencers - Wikipedia</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_802598612" CREATED="1547136473442" MODIFIED="1547136473442" LINK="http://www.hitsquad.com/smm/linux/MIDI_SEQUENCERS/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.hitsquad.com/smm/linux/MIDI_SEQUENCERS/">Linux Music Software: MIDI Sequencers (Hitsquad)</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Gear" FOLDED="true" ID="ID_1800091395" CREATED="1547673094554" MODIFIED="1547673096296">
<node TEXT="Guitar" FOLDED="true" ID="ID_1236190864" CREATED="1546541455404" MODIFIED="1546541458631">
<node ID="ID_376667774" CREATED="1546541460364" MODIFIED="1546541460364" LINK="https://www.youtube.com/watch?time_continue=199&amp;v=_nBK8sAl9nw"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.youtube.com/watch?time_continue=199&amp;v=_nBK8sAl9nw">(43) Raspberry Pi Looper/synth/drum thing - YouTube</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Specs" FOLDED="true" ID="ID_1909772610" CREATED="1546966141592" MODIFIED="1546966144642">
<node TEXT="Battery Area" FOLDED="true" ID="ID_1026663050" CREATED="1546966145456" MODIFIED="1546966151476">
<node TEXT="2 1/2 x 2 1/4&quot;" ID="ID_1362370013" CREATED="1546966400018" MODIFIED="1546966439967"/>
</node>
<node TEXT="Top of Strings" FOLDED="true" ID="ID_991050359" CREATED="1546966152408" MODIFIED="1546966157204">
<node TEXT="2.9x2.25" ID="ID_893762138" CREATED="1546966385420" MODIFIED="1546966390433"/>
<node TEXT="7.4 cm" ID="ID_1404064656" CREATED="1546966213975" MODIFIED="1546966219676"/>
<node TEXT="5.7" OBJECT="java.lang.Double|5.7" ID="ID_1221946562" CREATED="1546966246689" MODIFIED="1546966250917"/>
</node>
</node>
</node>
<node TEXT="Quneo" FOLDED="true" ID="ID_427592835" CREATED="1547673098588" MODIFIED="1547673101160">
<node ID="ID_1707738323" CREATED="1547673107331" MODIFIED="1547673107331" LINK="https://linuxmusicians.com/viewtopic.php?t=10485"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://linuxmusicians.com/viewtopic.php?t=10485">QuNeo pad controller (works on linux??) - LinuxMusicians</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1445435094" CREATED="1547673186926" MODIFIED="1547673186926" LINK="https://github.com/jnurmine/quneo-linux"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/jnurmine/quneo-linux">GitHub - jnurmine/quneo-linux: Command-line tool for the KMI QuNeo MIDI controller</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node ID="ID_1086564754" CREATED="1547672091689" MODIFIED="1547672091689" LINK="https://www.raspberrypi.org/forums/viewtopic.php?p=1038738"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.raspberrypi.org/forums/viewtopic.php?p=1038738">Pi 3 Studio DAW - Raspberry Pi Forums</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_893761022" CREATED="1547672106538" MODIFIED="1547672106538" LINK="https://raspberrypi.stackexchange.com/questions/31936/use-a-usb-midi-controller-as-an-input"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://raspberrypi.stackexchange.com/questions/31936/use-a-usb-midi-controller-as-an-input">audio - Use a USB MIDI controller as an input - Raspberry Pi Stack Exchange</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Booting" FOLDED="true" ID="ID_62835358" CREATED="1545431579585" MODIFIED="1546878048449">
<node TEXT="Get to GRUB bootloader" FOLDED="true" ID="ID_1214029832" CREATED="1545431584512" MODIFIED="1545431595918">
<node TEXT="Hold Shift" ID="ID_595354877" CREATED="1545431596856" MODIFIED="1545431599750"/>
<node TEXT="grub bootloader options" FOLDED="true" ID="ID_568195211" CREATED="1545431715311" MODIFIED="1545431726302">
<node ID="ID_790731366" CREATED="1546981518859" MODIFIED="1546981518859" LINK="https://askubuntu.com/questions/160036/how-do-i-disable-acpi-when-booting"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://askubuntu.com/questions/160036/how-do-i-disable-acpi-when-booting">installation - How do I disable ACPI when booting? - Ask Ubuntu</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1278788798" CREATED="1546981815293" MODIFIED="1546981815293" LINK="https://askubuntu.com/questions/19486/how-do-i-add-a-kernel-boot-parameter"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://askubuntu.com/questions/19486/how-do-i-add-a-kernel-boot-parameter">grub2 - How do I add a kernel boot parameter? - Ask Ubuntu</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="DO NOT USE" FOLDED="true" ID="ID_648957187" CREATED="1545431728170" MODIFIED="1545431735404">
<node TEXT="acpi=off" ID="ID_1050088844" CREATED="1545431736638" MODIFIED="1545431742218"/>
</node>
<node TEXT="quiet" ID="ID_1202287167" CREATED="1545431954273" MODIFIED="1545431965406"/>
<node TEXT="splash" ID="ID_541812242" CREATED="1545431965758" MODIFIED="1545431968361"/>
<node TEXT="reboot=bios" ID="ID_716827054" CREATED="1545431968950" MODIFIED="1545431973770"/>
<node TEXT="reboot=pci" ID="ID_490858223" CREATED="1545432874820" MODIFIED="1546981897966">
<font BOLD="false"/>
</node>
<node TEXT="acpi=force" ID="ID_1240697747" CREATED="1545432782435" MODIFIED="1546981898966">
<font BOLD="false"/>
</node>
<node TEXT="apm=power_off" ID="ID_316091533" CREATED="1545432792101" MODIFIED="1545432821110"/>
</node>
</node>
<node TEXT="Studio 4 boot options" FOLDED="true" ID="ID_1229604500" CREATED="1544733431528" MODIFIED="1544733471523">
<node TEXT="pmedia=usbflash" ID="ID_1676646963" CREATED="1544733437961" MODIFIED="1544733446635"/>
<node TEXT="pfix=ramdisplay" ID="ID_1083311108" CREATED="1544733446928" MODIFIED="1544733454275"/>
<node TEXT="debug=true" ID="ID_1170868681" CREATED="1544733455873" MODIFIED="1544733460115"/>
</node>
</node>
<node TEXT="shutdown" FOLDED="true" ID="ID_1153698129" CREATED="1545432989582" MODIFIED="1545432994509">
<node TEXT="sudo shutdown -P now" ID="ID_1921006655" CREATED="1545433002762" MODIFIED="1545433002762"/>
<node ID="ID_1490810413" CREATED="1545928205980" MODIFIED="1545928205980" LINK="https://askubuntu.com/questions/578144/why-doesnt-running-sudo-shutdown-now-shut-down"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://askubuntu.com/questions/578144/why-doesnt-running-sudo-shutdown-now-shut-down">command line - Why doesn't running &quot;sudo shutdown now&quot; shut down? - Ask Ubuntu</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Commands" FOLDED="true" ID="ID_1762706188" CREATED="1545428678382" MODIFIED="1545428680558">
<node TEXT="Command line" FOLDED="true" ID="ID_472340352" CREATED="1547060772752" MODIFIED="1547060775724">
<node ID="ID_741876426" CREATED="1545429299654" MODIFIED="1545429299654" LINK="http://www.unixguide.net/linux/linuxshortcuts.shtml"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.unixguide.net/linux/linuxshortcuts.shtml">Linux Newbie Guide: Shortcuts And Commands</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_660786726" CREATED="1546991239288" MODIFIED="1546991239288" LINK="https://www.git-tower.com/blog/command-line-cheat-sheet/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.git-tower.com/blog/command-line-cheat-sheet/">Command Line Cheat Sheet</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="delete file" FOLDED="true" ID="ID_590369734" CREATED="1545429306529" MODIFIED="1545429336643">
<node TEXT="rm" ID="ID_1314131432" CREATED="1545429337607" MODIFIED="1545429339310"/>
</node>
<node TEXT="install package" FOLDED="true" ID="ID_1604248949" CREATED="1547060790288" MODIFIED="1547060799908">
<node TEXT="sudo apt-get package" ID="ID_878558684" CREATED="1547060800500" MODIFIED="1547060811023"/>
</node>
<node TEXT="vi text editor" FOLDED="true" ID="ID_1335894391" CREATED="1545428681661" MODIFIED="1545428687576">
<node ID="ID_184228976" CREATED="1545428688679" MODIFIED="1545428688679" LINK="https://www.howtogeek.com/102468/a-beginners-guide-to-editing-text-files-with-vi/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.howtogeek.com/102468/a-beginners-guide-to-editing-text-files-with-vi/">A Beginner&#8217;s Guide to Editing Text Files With Vi</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="save" FOLDED="true" ID="ID_1018639491" CREATED="1545428969004" MODIFIED="1545428975491">
<node TEXT=":w" ID="ID_1668147661" CREATED="1545428976583" MODIFIED="1545428979412"/>
</node>
<node TEXT="Quit" FOLDED="true" ID="ID_821800108" CREATED="1545428981066" MODIFIED="1545428988036">
<node TEXT=":q" ID="ID_601674861" CREATED="1545428989036" MODIFIED="1545428993287"/>
</node>
</node>
</node>
<node TEXT="Scripts" FOLDED="true" ID="ID_447432702" CREATED="1547060165137" MODIFIED="1547060763860">
<node TEXT="Create" FOLDED="true" ID="ID_546103136" CREATED="1547060616424" MODIFIED="1547060622142">
<node TEXT="First line" FOLDED="true" ID="ID_878130455" CREATED="1547060622792" MODIFIED="1547060627537">
<node TEXT="#!/bin/bash" ID="ID_1660331153" CREATED="1547060628000" MODIFIED="1547060639745"/>
</node>
<node TEXT="insert commands" ID="ID_1170300005" CREATED="1547060642320" MODIFIED="1547060652478"/>
<node TEXT="save *.sh" ID="ID_1987023078" CREATED="1547060655457" MODIFIED="1547060660853"/>
</node>
<node TEXT="make executable" FOLDED="true" ID="ID_741333164" CREATED="1547060671545" MODIFIED="1547060674956">
<node TEXT="in command prompt" FOLDED="true" ID="ID_94342288" CREATED="1547060663248" MODIFIED="1547060670853">
<node TEXT="chmod +x file" ID="ID_787728283" CREATED="1547060679017" MODIFIED="1547060693132"/>
</node>
</node>
<node TEXT="run" FOLDED="true" ID="ID_715857690" CREATED="1547060696408" MODIFIED="1547060698683">
<node TEXT="./file" ID="ID_1921989587" CREATED="1547060701945" MODIFIED="1547060733621"/>
</node>
</node>
</node>
<node TEXT="Ubuntu" FOLDED="true" ID="ID_193026410" CREATED="1545419726210" MODIFIED="1545419728747">
<node TEXT="Lubuntu" FOLDED="true" ID="ID_1865252329" CREATED="1545333399471" MODIFIED="1545340656988">
<node TEXT="Using 18.04.1" ID="ID_1928227321" CREATED="1545419883801" MODIFIED="1545419892564"/>
<node ID="ID_507007807" CREATED="1545340658464" MODIFIED="1545340658464" LINK="https://lubuntu.me/downloads/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://lubuntu.me/downloads/">Downloads | Lubuntu</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_225038454" CREATED="1545419733114" MODIFIED="1545419733114" LINK="https://www.ubuntu.com/about/release-cycle"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ubuntu.com/about/release-cycle">Ubuntu release cycle | Ubuntu</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="On Windows" FOLDED="true" ID="ID_308299063" CREATED="1539701348479" MODIFIED="1539701352942">
<node ID="ID_1360195663" CREATED="1539701359867" MODIFIED="1539701359867" LINK="https://github.com/hakuna-m/wubiuefi/releases"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/hakuna-m/wubiuefi/releases">Releases &#183; hakuna-m/wubiuefi &#183; GitHub</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_30078618" CREATED="1539975656141" MODIFIED="1539975656141" LINK="https://www.pendrivelinux.com/using-a-portable-virtualbox-to-run-linux-from-usb/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.pendrivelinux.com/using-a-portable-virtualbox-to-run-linux-from-usb/">Using a Portable VirtualBox to run Linux from USB | USB Pen Drive Linux</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1853239834" CREATED="1641187962233" MODIFIED="1641187962233" LINK="https://stackoverflow.com/questions/1006452/sync-between-local-and-virtual-machine"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/1006452/sync-between-local-and-virtual-machine">windows - sync between local and virtual machine - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="ARM" FOLDED="true" POSITION="bottom_or_right" ID="ID_1460594369" CREATED="1694745592234" MODIFIED="1694879621090">
<node TEXT="Hardware" FOLDED="true" ID="ID_1387696086" CREATED="1694879478353" MODIFIED="1694879481622">
<node TEXT="Phone" FOLDED="true" ID="ID_241069261" CREATED="1704849072745" MODIFIED="1704849074722">
<node ID="ID_1428919284" CREATED="1704849075925" MODIFIED="1704849075925" LINK="https://www.bestbuy.com/site/blu-g93-128gb-unlocked-black/6544770.p?skuId=6544770"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.bestbuy.com/site/blu-g93-128gb-unlocked-black/6544770.p?skuId=6544770">BLU G93 128GB (Unlocked) Black G0910 - Best Buy</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Galaxy S7" FOLDED="true" ID="ID_116740728" CREATED="1615228796415" MODIFIED="1615228802761">
<node ID="ID_723782269" CREATED="1615229431642" MODIFIED="1615229431642" LINK="https://www.getdroidtips.com/resurrection-remix-oreo-galaxy-s7/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.getdroidtips.com/resurrection-remix-oreo-galaxy-s7/">How To Install Resurrection Remix on Samsung Galaxy S7 (Android 10 Q)</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_329416412" CREATED="1615868450141" MODIFIED="1615868450141" LINK="https://en.wikipedia.org/wiki/Samsung_Galaxy_S7"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://en.wikipedia.org/wiki/Samsung_Galaxy_S7">Samsung Galaxy S7 - Wikipedia</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1688139662" CREATED="1615868703985" MODIFIED="1615868703985" LINK="https://www.mobosdata.com/phone/samsung-galaxy-s7-sm-g930a/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mobosdata.com/phone/samsung-galaxy-s7-sm-g930a/">Samsung galaxy s7 sm g930a full specifications</a>
  </body>
</html>
</richcontent>
<node ID="ID_263588724" CREATED="1615870246962" MODIFIED="1615870246962" LINK="https://dragonfly2.readthedocs.io/en/latest/actions.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dragonfly2.readthedocs.io/en/latest/actions.html">Actions sub-package — Dragonfly 0.29.0 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Samsung Galazy A20" FOLDED="true" ID="ID_1777847792" CREATED="1703205476045" MODIFIED="1703205497143">
<node TEXT="SM-A205U1" ID="ID_57160821" CREATED="1703205497973" MODIFIED="1703205507862"/>
</node>
</node>
<node TEXT="installing new ROM" FOLDED="true" ID="ID_1154216255" CREATED="1703206884005" MODIFIED="1703206888804">
<node TEXT="process" FOLDED="true" ID="ID_1963736908" CREATED="1703206890181" MODIFIED="1703206892398">
<node ID="ID_1314124439" CREATED="1703206897478" MODIFIED="1703206897478" LINK="https://www.hardreset.info/devices/samsung/samsung-galaxy-a20/recovery-mode/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.hardreset.info/devices/samsung/samsung-galaxy-a20/recovery-mode/">How to put and get out SAMSUNG Galaxy A20 in recovery mode? - HardReset.info</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1872432655" CREATED="1703207084384" MODIFIED="1703207084384" LINK="https://www.minitool.com/news/odin-firmware-flashing-software.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.minitool.com/news/odin-firmware-flashing-software.html">How to Download and Use Odin to Flash Samsung Firmware - MiniTool</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1244752702" CREATED="1703206902430" MODIFIED="1703206902430" LINK="https://xdaforums.com/t/rom-a20-a20e-aosp-13-blissos-16-7-vanilla-unofficial.4595303/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://xdaforums.com/t/rom-a20-a20e-aosp-13-blissos-16-7-vanilla-unofficial.4595303/">[ROM] [a20/a20e] [AOSP] [13] BlissOS 16.7 Vanilla Unofficial | XDA Forums</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="" ID="ID_701460" CREATED="1703206894637" MODIFIED="1703206894637"/>
</node>
</node>
<node TEXT="Upgrade" FOLDED="true" ID="ID_791626027" CREATED="1694879505201" MODIFIED="1694879510845">
<node TEXT="Tablet" FOLDED="true" ID="ID_597154258" CREATED="1694829963888" MODIFIED="1694829969511">
<node TEXT="chosen" FOLDED="true" ID="ID_1680822672" CREATED="1701552541972" MODIFIED="1701552543959">
<node ID="ID_1020942265" CREATED="1702934610297" MODIFIED="1702934610297" LINK="https://www.amazon.com/gp/product/B0CG31J44J/ref=ppx_yo_dt_b_asin_title_o02_s00?ie=UTF8&amp;psc=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/gp/product/B0CG31J44J/ref=ppx_yo_dt_b_asin_title_o02_s00?ie=UTF8&amp;psc=1">Amazon.com : ALLDOCUBE Android 13 Tablet，16GB (8+8) RAM 256GB ROM 512GB Expandable Android Tablet，Helio G99 8-Core CPU,1920×1200 IPS in-Cell 8.4 inch Tablet iPlay 50 Mini Pro，5000mAh，5MP/13MP，4G LTE : Electronics</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1237083507" CREATED="1701552545120" MODIFIED="1701552545120" LINK="https://www.amazon.com/gp/product/B0CDPRV2TH/ref=ppx_yo_dt_b_asin_title_o00_s00?ie=UTF8&amp;psc=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/gp/product/B0CDPRV2TH/ref=ppx_yo_dt_b_asin_title_o00_s00?ie=UTF8&amp;psc=1">Amazon.com : ALLDOCUBE 𝟮𝗞 𝗔𝗻𝗱𝗿𝗼𝗶𝗱 𝗧𝗮𝗯𝗹𝗲𝘁 FHD 10.36 Inch Tablet PC 8GB RAM 𝟮𝟱𝟲𝗚𝗕 ROM and 2TB Expand Octa Core Helio G99 Processor Gaming Tablets Bluetooth 5.2 iPlay 50 Pro Max : Electronics</a>
  </body>
</html>
</richcontent>
<node TEXT="like" FOLDED="true" ID="ID_923648500" CREATED="1701552867377" MODIFIED="1701552869741">
<node ID="ID_1491923225" CREATED="1702934580339" MODIFIED="1702934580339" LINK="https://www.gsmarena.com/samsung_galaxy_tab_a_8_4_(2020)-10483.php"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.gsmarena.com/samsung_galaxy_tab_a_8_4_(2020)-10483.php">Samsung Galaxy Tab A 8.4 (2020) - Full tablet specifications</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="stand" FOLDED="true" ID="ID_930747671" CREATED="1701554350734" MODIFIED="1701554352738">
<node TEXT="check for whole for charger" ID="ID_1463177450" CREATED="1701554689284" MODIFIED="1701554706894"/>
<node ID="ID_1410281772" CREATED="1701554684904" MODIFIED="1701554684904" LINK="https://www.amazon.com/FIEWESEY-Heavy-Duty-Shockproof-Friendly-Protective/dp/B0BC8HBGYK/ref=sr_1_16?crid=1ALEGEB8D0DLB&amp;keywords=Nokia%2BT20%2BTablet%2B10.36%2Bcase&amp;qid=1701554528&amp;sprefix=nokia%2Bt20%2Btablet%2B10.36%2Bcase%27%2Caps%2C142&amp;sr=8-16&amp;th=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/FIEWESEY-Heavy-Duty-Shockproof-Friendly-Protective/dp/B0BC8HBGYK/ref=sr_1_16?crid=1ALEGEB8D0DLB&amp;keywords=Nokia%2BT20%2BTablet%2B10.36%2Bcase&amp;qid=1701554528&amp;sprefix=nokia%2Bt20%2Btablet%2B10.36%2Bcase%27%2Caps%2C142&amp;sr=8-16&amp;th=1">Amazon.com: FIEWESEY for TCL TABMAX 10.4 Inch Tablet Case,Heavy-Duty Shockproof Kids Friendly Hybrid Rugged Protective Case for Nokia T20/Nokia T21/TCL Tab Pro 5G 9198S/VASTKING KingPad M10 Tablet(Black/Black) : Electronics</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_48950455" CREATED="1701554353710" MODIFIED="1701554353710" LINK="https://www.amazon.com/Anozer-Adjustable-Foldable-Aluminium-Compatible/dp/B0C2GTMQ83/ref=sr_1_20?crid=17JGXI65L4B6S&amp;keywords=tablet%2Bkeyboard%2Bstand&amp;qid=1701554268&amp;s=electronics&amp;sprefix=tablet%2Bstand%2Bkeyboard%2B%2Celectronics%2C148&amp;sr=1-20&amp;th=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/Anozer-Adjustable-Foldable-Aluminium-Compatible/dp/B0C2GTMQ83/ref=sr_1_20?crid=17JGXI65L4B6S&amp;keywords=tablet%2Bkeyboard%2Bstand&amp;qid=1701554268&amp;s=electronics&amp;sprefix=tablet%2Bstand%2Bkeyboard%2B%2Celectronics%2C148&amp;sr=1-20&amp;th=1">Amazon.com: Anozer Tablet Stand, Adjustable &amp; Foldable Aluminium for iPad Stand,Designed for 2022 iPad Air 5/4,for iPad Mini 6/5,for iPad 10.2,for iPad Pro 12.9/11,Portable Monitor, Surface (4-13 inch)-Black : Electronics</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="screen" FOLDED="true" ID="ID_1560926317" CREATED="1701552554881" MODIFIED="1701552558706">
<node TEXT="2000x1200" ID="ID_256967536" CREATED="1701552909661" MODIFIED="1701552918700"/>
<node TEXT="10.36" OBJECT="java.lang.Double|10.36" ID="ID_25806989" CREATED="1701552559240" MODIFIED="1701552562600"/>
<node TEXT="Aspect Ratio 15:9" ID="ID_125133695" CREATED="1701552574908" MODIFIED="1701552589329"/>
</node>
<node TEXT="case" FOLDED="true" ID="ID_1384342761" CREATED="1701552738540" MODIFIED="1701552740724">
<node ID="ID_1788282773" CREATED="1701552819183" MODIFIED="1701552819183" LINK="https://www.amazon.com/HminSen-TCL-TABMAX-10-4-Adjustable/dp/B0B62Y66HB/ref=sr_1_8?crid=2HNCTM2M6OJ7K&amp;keywords=tablet%2Bcase%2B10.36%2Bin&amp;qid=1701552645&amp;s=electronics&amp;sprefix=tablet%2Bcase%2B10.36%2Bin%2Celectronics%2C140&amp;sr=1-8&amp;th=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/HminSen-TCL-TABMAX-10-4-Adjustable/dp/B0B62Y66HB/ref=sr_1_8?crid=2HNCTM2M6OJ7K&amp;keywords=tablet%2Bcase%2B10.36%2Bin&amp;qid=1701552645&amp;s=electronics&amp;sprefix=tablet%2Bcase%2B10.36%2Bin%2Celectronics%2C140&amp;sr=1-8&amp;th=1">Amazon.com: HminSen Case for TCL TABMAX 10.4 Tablet,Kids Friendly Soft Silicone Adjustable Stand Cover for Nokia T20 Tablet 10.36 inch (Black) : Electronics</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="protector" FOLDED="true" ID="ID_1543199670" CREATED="1701554018323" MODIFIED="1701554020499">
<node ID="ID_792587636" CREATED="1701554021314" MODIFIED="1701554021314" LINK="https://www.amazon.com/s?k=tabmax+10.4+case&amp;i=electronics&amp;crid=L3RISIA64DWO&amp;sprefix=tabmax+10.4+case%2Celectronics%2C142&amp;ref=nb_sb_noss_2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/s?k=tabmax+10.4+case&amp;i=electronics&amp;crid=L3RISIA64DWO&amp;sprefix=tabmax+10.4+case%2Celectronics%2C142&amp;ref=nb_sb_noss_2">Amazon.com : tabmax 10.4 case</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="purchasing" FOLDED="true" ID="ID_923884" CREATED="1694829979152" MODIFIED="1694829981850">
<node TEXT="compare processors" FOLDED="true" ID="ID_1682902261" CREATED="1694829982513" MODIFIED="1694829985403">
<node TEXT="reference" FOLDED="true" ID="ID_945549308" CREATED="1694830412133" MODIFIED="1694830415178">
<node ID="ID_1990490289" CREATED="1694830214871" MODIFIED="1694830214871" LINK="https://www.notebookcheck.net/Smartphone-Processors-Benchmark-List.149513.0.html?&amp;sort=b_717_2170&amp;deskornote=3∨=1&amp;showBars=1&amp;geekbench2=1&amp;geekbench3_single=1&amp;geekbench3_multi=1&amp;geekbench4_1_single=1&amp;geekbench4_1_multi=1&amp;geekbench5_1_single=1&amp;geekbench5_1_multi=1&amp;passmark_cpu=1&amp;sunspider=1&amp;cpu_fullname=1&amp;codename=1&amp;mhz=1&amp;turbo_mhz=1&amp;cores=1&amp;threads=1&amp;architecture=1&amp;64bit=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.notebookcheck.net/Smartphone-Processors-Benchmark-List.149513.0.html?&amp;sort=b_717_2170&amp;deskornote=3∨=1&amp;showBars=1&amp;geekbench2=1&amp;geekbench3_single=1&amp;geekbench3_multi=1&amp;geekbench4_1_single=1&amp;geekbench4_1_multi=1&amp;geekbench5_1_single=1&amp;geekbench5_1_multi=1&amp;passmark_cpu=1&amp;sunspider=1&amp;cpu_fullname=1&amp;codename=1&amp;mhz=1&amp;turbo_mhz=1&amp;cores=1&amp;threads=1&amp;architecture=1&amp;64bit=1">Smartphone Processors - Benchmark List - NotebookCheck.net Tech</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="p60T" ID="ID_676920909" CREATED="1701553811908" MODIFIED="1701553813981"/>
<node TEXT="g99" FOLDED="true" ID="ID_1731397290" CREATED="1694830903805" MODIFIED="1694830905200">
<node TEXT="910" OBJECT="java.lang.Long|910" ID="ID_1011741582" CREATED="1694830915804" MODIFIED="1694830918444"/>
</node>
<node TEXT="T606" FOLDED="true" ID="ID_1888593656" CREATED="1694830418856" MODIFIED="1694830420933">
<node TEXT="1133" OBJECT="java.lang.Long|1133" ID="ID_947804104" CREATED="1694830471844" MODIFIED="1694830474460"/>
</node>
<node TEXT="8183 - 1160" ID="ID_996336709" CREATED="1701547227582" MODIFIED="1701547232897"/>
<node TEXT="snapdragon 680" FOLDED="true" ID="ID_634314000" CREATED="1694830425372" MODIFIED="1694830430617">
<node TEXT="968" OBJECT="java.lang.Long|968" ID="ID_744785951" CREATED="1694830461193" MODIFIED="1694830462701"/>
</node>
<node TEXT="MT6750" ID="ID_703186391" CREATED="1701547543669" MODIFIED="1701547549070"/>
</node>
</node>
</node>
</node>
<node TEXT="Syngenta Samsung 8&quot;" ID="ID_117130010" CREATED="1694879485649" MODIFIED="1694879965865"/>
<node TEXT="Galaxy Tab 7 Tablet" FOLDED="true" ID="ID_199758297" CREATED="1519926476777" MODIFIED="1595561893246">
<font NAME="Nirmala UI"/>
<node TEXT="AIO Remote" FOLDED="true" ID="ID_1368290184" CREATED="1520895923956" MODIFIED="1520895927725">
<node TEXT="Use AIO Server 3.3 to avoid pgup pgdn issue" ID="ID_1101707944" CREATED="1520895928752" MODIFIED="1520895956365"/>
</node>
<node TEXT="Boot" FOLDED="true" ID="ID_1920781393" CREATED="1519926483490" MODIFIED="1519926489077">
<node TEXT="Hold Vol Up + Power until flashes twice" ID="ID_1882072364" CREATED="1519926763779" MODIFIED="1519926812137"/>
</node>
<node TEXT="SCH-I800" ID="ID_1338496699" CREATED="1595561824523" MODIFIED="1595561832865"/>
<node TEXT="1024 x 600" ID="ID_580884144" CREATED="1595561876724" MODIFIED="1595561927335"/>
<node ID="ID_1328331868" CREATED="1595564641739" MODIFIED="1595564641739" LINK="https://www.netbooknews.com/tips/use-tablet-second-monitor/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.netbooknews.com/tips/use-tablet-second-monitor/">How To Use Tablet As Second Monitor (Windows, Android &amp; IPad)</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Android" ID="ID_121896431" CREATED="1694880604300" MODIFIED="1694880608847">
<node TEXT="debloat" FOLDED="true" ID="ID_1026180618" CREATED="1626798186781" MODIFIED="1626798193884">
<node TEXT="install ADB" FOLDED="true" ID="ID_494217666" CREATED="1626808657044" MODIFIED="1626808662794">
<node ID="ID_1699843621" CREATED="1626809272049" MODIFIED="1626809272049" LINK="https://developer.android.com/studio/command-line/adb"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://developer.android.com/studio/command-line/adb">Android Debug Bridge (adb) &nbsp;|&nbsp;&nbsp;Android Developers</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1841029451" CREATED="1626808664183" MODIFIED="1626808664183" LINK="https://www.howtogeek.com/125769/how-to-install-and-use-abd-the-android-debug-bridge-utility/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.howtogeek.com/125769/how-to-install-and-use-abd-the-android-debug-bridge-utility/">How to Install and Use ADB, the Android Debug Bridge Utility</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="enable USB debugging" ID="ID_1181105593" CREATED="1626808000153" MODIFIED="1626808006248"/>
<node TEXT="remove apps" FOLDED="true" ID="ID_853419144" CREATED="1626819316018" MODIFIED="1626819319470">
<node TEXT="cmd" FOLDED="true" ID="ID_1257262762" CREATED="1626820787679" MODIFIED="1626820795598">
<node TEXT="platform tools folder" ID="ID_1633264783" CREATED="1626820796525" MODIFIED="1626820806226"/>
<node TEXT="adb shell" FOLDED="true" ID="ID_232710071" CREATED="1626820807890" MODIFIED="1626820816606">
<node TEXT="cp from excel" FOLDED="true" ID="ID_174584212" CREATED="1626820818609" MODIFIED="1626820826527">
<node ID="ID_1265611185" CREATED="1626821261598" MODIFIED="1626821261598" LINK="https://technastic.com/remove-samsung-bloatware-safe-to-remove-apps/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://technastic.com/remove-samsung-bloatware-safe-to-remove-apps/">Samsung Bloatware List (2020) | Remove Samsung Bloatware Safely</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node ID="ID_658870997" CREATED="1626819320797" MODIFIED="1626819320797" LINK="https://medium.com/@kaikoenig/samsungs-bloatware-disgrace-c7d14a298ad7"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/@kaikoenig/samsungs-bloatware-disgrace-c7d14a298ad7">Samsung’s bloatware disgrace. Cleaning up a Samsung Galaxy Tab S3 | by Kai Koenig | Medium</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_767777610" CREATED="1626807932118" MODIFIED="1626807932118" LINK="https://r1.community.samsung.com/t5/others/how-to-remove-samsung-bloatware-without-root/td-p/5817510"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://r1.community.samsung.com/t5/others/how-to-remove-samsung-bloatware-without-root/td-p/5817510">How to Remove Samsung Bloatware&nbsp;without Root - Samsung Members</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="alternative ROMs" FOLDED="true" ID="ID_342622432" CREATED="1626819350821" MODIFIED="1626819357628">
<node TEXT="unlock bootloader" FOLDED="true" ID="ID_1062220681" CREATED="1626819509045" MODIFIED="1626819518404">
<node ID="ID_630547862" CREATED="1626823247167" MODIFIED="1626823247167" LINK="https://technastic.com/magisk-zip-magisk-manager-apk-download/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://technastic.com/magisk-zip-magisk-manager-apk-download/">Download Magisk ZIP v22.0 | Magisk Manager v8.0.7 APK (Latest)</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="install TWRP" FOLDED="true" ID="ID_1496167697" CREATED="1626819519675" MODIFIED="1626819527930">
<node ID="ID_1993948240" CREATED="1626823129425" MODIFIED="1626823129425" LINK="https://technastic.com/android-root-magisk-twrp/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://technastic.com/android-root-magisk-twrp/">Root Android Phone with ADB Command, Magisk &amp; TWRP | Technastic</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="backup" ID="ID_1610337251" CREATED="1626819528376" MODIFIED="1626819530775"/>
</node>
<node TEXT="Unlock developper options" FOLDED="true" ID="ID_543871040" CREATED="1585326355063" MODIFIED="1585326361248">
<node TEXT="About Tablet &gt; Build # , Tap 7 times" ID="ID_1635318558" CREATED="1585326362867" MODIFIED="1585326398867"/>
</node>
<node TEXT="input" FOLDED="true" ID="ID_1666170589" CREATED="1626824417610" MODIFIED="1626824420351">
<node ID="ID_1657275020" CREATED="1626824421829" MODIFIED="1626824421829" LINK="https://github.com/Kaljurand/K6nele"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Kaljurand/K6nele">Kaljurand/K6nele: An Android app that offers speech-to-text services and user interfaces to other apps</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Voice" FOLDED="true" ID="ID_484534908" CREATED="1695094999859" MODIFIED="1695095003746">
<node TEXT="Voice Access" FOLDED="true" ID="ID_1475204885" CREATED="1695095349781" MODIFIED="1695095354767">
<node TEXT="Settings" FOLDED="true" ID="ID_633926670" CREATED="1695095357976" MODIFIED="1695095361300">
<node TEXT="Accessability" ID="ID_741736329" CREATED="1695095385555" MODIFIED="1695101956835"/>
<node TEXT="Installed services" FOLDED="true" ID="ID_1790951817" CREATED="1695095362230" MODIFIED="1695095369287">
<node TEXT="Voice Access" ID="ID_491640300" CREATED="1695095371290" MODIFIED="1695095377525"/>
</node>
</node>
</node>
<node ID="ID_1868023536" CREATED="1695095005164" MODIFIED="1695095005164" LINK="https://support.google.com/accessibility/android/answer/6151854?hl=en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://support.google.com/accessibility/android/answer/6151854?hl=en">Use Voice Access commands - Android Accessibility Help</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_116460961" CREATED="1695095155183" MODIFIED="1695095157056">
<node ID="ID_1456548170" CREATED="1695095157924" MODIFIED="1695095157924" LINK="https://mcmw.abilitynet.org.uk/how-to-make-it-easier-to-launch-voice-access-in-android-12"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mcmw.abilitynet.org.uk/how-to-make-it-easier-to-launch-voice-access-in-android-12">How to make it easier to launch Voice Access in Android 12 | My Computer My Way</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="apk storage location" ID="ID_1966736911" CREATED="1694880609352" MODIFIED="1694880617716"/>
<node TEXT="automation" ID="ID_643688208" CREATED="1713309561385" MODIFIED="1713309564234">
<node ID="ID_129241473" CREATED="1713309851427" MODIFIED="1713309851427" LINK="https://www.androidcentral.com/hands-free-automation-tasker-and-autovoice-part-1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.androidcentral.com/hands-free-automation-tasker-and-autovoice-part-1">Hands-free automation: Tasker and AutoVoice Part 1 | Android Central</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="installing Google play" FOLDED="true" ID="ID_1357948037" CREATED="1698696770685" MODIFIED="1698696774637">
<node ID="ID_352727810" CREATED="1698696779654" MODIFIED="1698696779654" LINK="https://www.androidpolice.com/install-google-play-store-any-android-device/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.androidpolice.com/install-google-play-store-any-android-device/">How to install the Google Play Store on any Android device</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Syngenta" FOLDED="true" ID="ID_1485784870" CREATED="1695093358040" MODIFIED="1695093361698">
<node TEXT="Goal" FOLDED="true" ID="ID_1398220464" CREATED="1695094532195" MODIFIED="1695094537338">
<node TEXT="run EZCapture on Windows to take advantage of voice control" ID="ID_1108818949" CREATED="1695094538033" MODIFIED="1695094570174"/>
</node>
<node TEXT="Setup" FOLDED="true" ID="ID_1219648583" CREATED="1695094014946" MODIFIED="1695094021064">
<node TEXT="reference" FOLDED="true" ID="ID_1636360992" CREATED="1695094144645" MODIFIED="1695094146587">
<node ID="ID_1863709111" CREATED="1695094147375" MODIFIED="1695094147375" LINK="https://android.stackexchange.com/questions/229030/encrypt-tablet-function-in-android-x86-android-6-in-oracle-virtual-box"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://android.stackexchange.com/questions/229030/encrypt-tablet-function-in-android-x86-android-6-in-oracle-virtual-box">6.0 marshmallow - Encrypt Tablet function in Android x86. Android 6 in Oracle Virtual Box - Android Enthusiasts Stack Exchange</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="LDPlayer" ID="ID_1258721195" CREATED="1695094066895" MODIFIED="1695094070994"/>
<node TEXT="Set Screenlock" FOLDED="true" ID="ID_1487618113" CREATED="1695094021866" MODIFIED="1695094031434">
<node TEXT="73083" OBJECT="java.lang.Long|73083" ID="ID_1705492322" CREATED="1695094032140" MODIFIED="1695094042043"/>
</node>
<node TEXT=" Settings -&gt; Security -&gt; Encrypt Tablet feature in Android." ID="ID_1482607212" CREATED="1695093891305" MODIFIED="1695093894713"/>
</node>
<node TEXT="Install through google play" FOLDED="true" ID="ID_1197676245" CREATED="1695094048083" MODIFIED="1695094059039">
<node TEXT="Intune Company Portal App" ID="ID_454552796" CREATED="1695093362524" MODIFIED="1695093373537"/>
</node>
</node>
</node>
<node TEXT="Transfer Files" FOLDED="true" POSITION="bottom_or_right" ID="ID_808471163" CREATED="1680809579772" MODIFIED="1680809584595">
<font NAME="Nirmala UI"/>
<node TEXT="iPhone to PC" ID="ID_1503521267" CREATED="1680809585427" MODIFIED="1680809593079">
<node TEXT="Change settings" FOLDED="true" ID="ID_1564117803" CREATED="1680809593864" MODIFIED="1680809598186">
<node TEXT="Direct transfer (dont convert)" ID="ID_493745420" CREATED="1680809598602" MODIFIED="1680809606592"/>
</node>
</node>
</node>
<node TEXT="Mapping" POSITION="bottom_or_right" ID="ID_1468786479" CREATED="1622138216991" MODIFIED="1622138220719">
<node TEXT="Mindmaps" ID="ID_526721561" CREATED="1567752965872" MODIFIED="1567752971914">
<node ID="ID_367803155" TREE_ID="ID_46579768">
<node ID="ID_1480944192" TREE_ID="ID_70175057">
<node ID="ID_1987137635" TREE_ID="ID_700032025">
<node ID="ID_1492628440" TREE_ID="ID_975816636"/>
<node ID="ID_259374011" TREE_ID="ID_1048399413"/>
<node ID="ID_892879008" TREE_ID="ID_1341710059"/>
<node ID="ID_1998714165" TREE_ID="ID_1864350174"/>
<node ID="ID_1375075779" TREE_ID="ID_915472855"/>
</node>
<node ID="ID_213273808" TREE_ID="ID_1476886353"/>
<node ID="ID_594719265" TREE_ID="ID_836494682"/>
</node>
<node ID="ID_188230748" TREE_ID="ID_1230296935">
<node ID="ID_1609602395" TREE_ID="ID_1382897103"/>
</node>
<node ID="ID_1052855361" TREE_ID="ID_424095239">
<node ID="ID_909455747" TREE_ID="ID_550430356">
<node ID="ID_1899153724" TREE_ID="ID_1526953795">
<node ID="ID_614798012" TREE_ID="ID_1484645832"/>
<node ID="ID_1091138888" TREE_ID="ID_1813556746"/>
<node ID="ID_1366485785" TREE_ID="ID_571366227"/>
</node>
</node>
<node ID="ID_494132658" TREE_ID="ID_1688089550">
<node ID="ID_1958858676" TREE_ID="ID_607781642"/>
<node ID="ID_1961600470" TREE_ID="ID_1811155592"/>
</node>
<node ID="ID_1894232332" TREE_ID="ID_955351238">
<node ID="ID_1408708474" TREE_ID="ID_837542412"/>
</node>
<node ID="ID_1146779648" TREE_ID="ID_1723912226">
<node ID="ID_1647071473" TREE_ID="ID_208977864">
<node ID="ID_584819986" TREE_ID="ID_1361321382"/>
</node>
</node>
<node ID="ID_249461406" TREE_ID="ID_576545906">
<node ID="ID_874261410" TREE_ID="ID_1929948543">
<node ID="ID_583685900" TREE_ID="ID_1359691968">
<node ID="ID_408205141" TREE_ID="ID_1001187324"/>
<node ID="ID_990326963" TREE_ID="ID_510024061"/>
</node>
<node ID="ID_1888494072" TREE_ID="ID_342091593">
<node ID="ID_826783657" TREE_ID="ID_976982371"/>
</node>
</node>
</node>
<node ID="ID_1430158267" TREE_ID="ID_501809413">
<node ID="ID_1413052634" TREE_ID="ID_1854948253"/>
<node ID="ID_142361387" TREE_ID="ID_926378345"/>
<node ID="ID_123792405" TREE_ID="ID_1415352444"/>
<node ID="ID_244959683" TREE_ID="ID_1470721092"/>
<node ID="ID_150461504" TREE_ID="ID_408040355"/>
<node ID="ID_1504829018" TREE_ID="ID_1081136875"/>
<node ID="ID_1263288055" TREE_ID="ID_729886864"/>
</node>
<node ID="ID_1633500583" TREE_ID="ID_1901486656">
<node ID="ID_3291569" TREE_ID="ID_1487126333"/>
</node>
</node>
<node ID="ID_688700452" TREE_ID="ID_372879423">
<node ID="ID_1392852049" TREE_ID="ID_901693127">
<node ID="ID_1714403725" TREE_ID="ID_172997201"/>
<node ID="ID_1418101583" TREE_ID="ID_1672870849"/>
<node ID="ID_106051702" TREE_ID="ID_1460616690">
<node ID="ID_529856715" TREE_ID="ID_1007594471"/>
</node>
</node>
<node ID="ID_771592698" TREE_ID="ID_1624279671"/>
</node>
<node ID="ID_1651311202" TREE_ID="ID_1899428840">
<node ID="ID_1781213962" TREE_ID="ID_841675451">
<node ID="ID_1313224660" TREE_ID="ID_707863750">
<node ID="ID_248149093" TREE_ID="ID_1436663409"/>
</node>
</node>
</node>
</node>
<node TEXT="Converting from Onenote" FOLDED="true" ID="ID_558028290" CREATED="1567752973801" MODIFIED="1567752983243">
<node TEXT="CP" ID="ID_1497926322" CREATED="1567752985861" MODIFIED="1567753364085"/>
</node>
</node>
<node TEXT="Diagram" FOLDED="true" ID="ID_1816928606" CREATED="1622138268321" MODIFIED="1622138273910">
<node TEXT="Untitled Diagram.drawio - diagrams.net" ID="ID_794247628" CREATED="1622138308635" MODIFIED="1622138308635"/>
<node TEXT="https://app.diagrams.net/#Wb!1KfLWun_1UGD4k9hsemG8qhv3upyfrpEvc496EyBIBCSxvcKWg5OTqgYoeHHvuai%2F01YETSEWL66CCZ6KHGVBHIS5QSNISBWAU3" ID="ID_1623926013" CREATED="1622138308636" MODIFIED="1622138308636" LINK="https://app.diagrams.net/#Wb!1KfLWun_1UGD4k9hsemG8qhv3upyfrpEvc496EyBIBCSxvcKWg5OTqgYoeHHvuai%2F01YETSEWL66CCZ6KHGVBHIS5QSNISBWAU3"/>
<node FOLDED="true" ID="ID_63386117" CREATED="1622138343197" MODIFIED="1622138343197" LINK="https://www.researchgate.net/publication/324865991_Automatic_contextual_recognition_of_hand-drawn_content"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.researchgate.net/publication/324865991_Automatic_contextual_recognition_of_hand-drawn_content">(PDF) Automatic contextual recognition of hand-drawn content</a>
  </body>
</html>
</richcontent>
<node ID="ID_1588925865" CREATED="1622138578556" MODIFIED="1622138578556" LINK="https://www.tdcommons.org/dpubs_series/1102/?utm_source=www.tdcommons.org%2Fdpubs_series%2F1102&amp;utm_medium=PDF&amp;utm_campaign=PDFCoverPages"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tdcommons.org/dpubs_series/1102/?utm_source=www.tdcommons.org%2Fdpubs_series%2F1102&amp;utm_medium=PDF&amp;utm_campaign=PDFCoverPages">&quot;Automatic contextual recognition of hand-drawn content&quot; by Kyle Williams, Milton Ribeiro Filho et al.</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Image Editing" FOLDED="true" POSITION="bottom_or_right" ID="ID_922016390" CREATED="1539188322635" MODIFIED="1539188328862">
<node ID="ID_1921033462" CREATED="1539188337407" MODIFIED="1539188337407" LINK="https://www.xnview.com/en/xnconvert/#downloads"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.xnview.com/en/xnconvert/#downloads">XnConvert &#183; One of the Best Batch Image Processing</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Coding" FOLDED="true" POSITION="bottom_or_right" ID="ID_1026054623" CREATED="1610642502074" MODIFIED="1610642504346">
<node TEXT="AI" FOLDED="true" ID="ID_724784948" CREATED="1710646652244" MODIFIED="1710646656553">
<node TEXT="reference" FOLDED="true" ID="ID_961950320" CREATED="1710646661570" MODIFIED="1710646663306">
<node ID="ID_1268235081" CREATED="1710646664797" MODIFIED="1710646664797" LINK="https://www.datacamp.com/blog/best-ai-coding-assistants"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.datacamp.com/blog/best-ai-coding-assistants">The Top 11 AI Coding Assistants to Use in 2024 | DataCamp</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="options" FOLDED="true" ID="ID_1686431236" CREATED="1710701242388" MODIFIED="1710701244923">
<node TEXT="Using AI to assist you in coding can significantly enhance your productivity and efficiency. Here are several ways you can utilize AI in your coding workflow:" ID="ID_1298321362" CREATED="1710701246377" MODIFIED="1710701246377"/>
<node TEXT="1. **Code Autocompletion**: AI-powered code editors like Visual Studio Code with IntelliSense or JetBrains&apos; IntelliJ IDEA offer intelligent code autocompletion features. These tools analyze your code context and suggest relevant completions, which can save you time and reduce typing errors." ID="ID_1883219632" CREATED="1710701246377" MODIFIED="1710701246377"/>
<node TEXT="2. **Code Refactoring**: AI tools can analyze your codebase and suggest refactorings to improve code quality, readability, and performance. For instance, tools like ReSharper for C# or SonarLint for various languages provide AI-powered suggestions for code improvements." ID="ID_387809404" CREATED="1710701246380" MODIFIED="1710701246380"/>
<node TEXT="3. **Code Generation**: AI models, such as OpenAI&apos;s Codex, can generate code snippets based on natural language descriptions. You can describe the functionality you need in plain English, and the AI model will provide you with corresponding code snippets, potentially saving you from writing repetitive or boilerplate code." ID="ID_894796183" CREATED="1710701246383" MODIFIED="1710701246383"/>
<node TEXT="4. **Bug Detection and Fixing**: AI-powered static analysis tools can detect potential bugs in your codebase by analyzing patterns and data flows. Tools like DeepCode or CodeSonar use AI algorithms to identify and suggest fixes for common programming errors." ID="ID_922263145" CREATED="1710701246386" MODIFIED="1710701246386"/>
<node TEXT="5. **Code Review Assistance**: AI-based tools like CodeGuru from AWS or PullRequest use machine learning algorithms to analyze code changes, identify potential issues, and provide feedback during code reviews, helping teams maintain code quality and adhere to best practices." ID="ID_1561351415" CREATED="1710701246389" MODIFIED="1710701246389"/>
<node TEXT="6. **Natural Language Programming**: Some AI platforms enable you to write code using natural language commands. For example, OpenAI&apos;s GPT models can understand and execute simple programming commands described in natural language." ID="ID_378637887" CREATED="1710701246392" MODIFIED="1710701246392"/>
<node TEXT="7. **Test Generation**: AI can assist in generating test cases automatically based on code analysis. Tools like Diffblue Cover can automatically generate unit tests for Java code, helping ensure better test coverage and code reliability." ID="ID_1154389197" CREATED="1710701246394" MODIFIED="1710701246394"/>
<node TEXT="8. **Code Documentation**: AI can help in generating code documentation by analyzing code structures and inferring the purpose of functions, variables, and classes. Tools like Documancer or Natural Docs utilize AI algorithms to generate documentation from code comments and structures." ID="ID_1526202850" CREATED="1710701246395" MODIFIED="1710701246395"/>
<node TEXT="9. **Code Translation**: AI-powered tools can assist in translating code between programming languages. For example, Facebook&apos;s AI-based tool, TransCoder, can automatically translate code between various programming languages." ID="ID_1132891193" CREATED="1710701246397" MODIFIED="1710701246397"/>
<node TEXT="10. **Code Optimization**: AI-based compilers and optimizers can analyze code performance and suggest optimizations to improve execution speed or reduce resource usage. Tools like Intel&apos;s Performance Profiler or LLVM&apos;s Polly framework use AI techniques to optimize code for specific architectures or execution environments." ID="ID_200938477" CREATED="1710701246399" MODIFIED="1710701246399"/>
<node TEXT="Integrating AI tools into your coding workflow can provide significant benefits, such as increased productivity, improved code quality, and faster development cycles. However, it&apos;s essential to understand the limitations of these tools and use them judiciously in conjunction with your own expertise and best practices." ID="ID_116062068" CREATED="1710701246400" MODIFIED="1710701246400"/>
</node>
<node TEXT="Chat GPT" FOLDED="true" ID="ID_775312448" CREATED="1710646390905" MODIFIED="1710646394581">
<node TEXT="reference" FOLDED="true" ID="ID_921629146" CREATED="1710646400333" MODIFIED="1710646402923">
<node ID="ID_488184146" CREATED="1710645903148" MODIFIED="1710645903148" LINK="https://www.r-bloggers.com/2023/09/chatgpt-how-to-automate-google-sheets-in-under-2-minutes-with-r/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.r-bloggers.com/2023/09/chatgpt-how-to-automate-google-sheets-in-under-2-minutes-with-r/">ChatGPT: How to automate Google Sheets in under 2 minutes (with R) | R-bloggers</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="put this into one script and comment the script" ID="ID_1039077122" CREATED="1710646406266" MODIFIED="1710646482738"/>
</node>
</node>
<node TEXT="R" FOLDED="true" ID="ID_1411049819" CREATED="1711032269020" MODIFIED="1711032269849">
<node TEXT="editor" FOLDED="true" ID="ID_1849891312" CREATED="1711032846010" MODIFIED="1711032847629">
<node TEXT="R Studio" FOLDED="true" ID="ID_1930037508" CREATED="1711032561768" MODIFIED="1711032565208">
<node TEXT="AI" FOLDED="true" ID="ID_1122271874" CREATED="1711032901271" MODIFIED="1711032903084">
<node ID="ID_651875742" CREATED="1711032907620" MODIFIED="1711032907620" LINK="https://github.com/MichelNivard/GPTstudio"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/MichelNivard/GPTstudio">MichelNivard/gptstudio: GPT RStudio addins that enable GPT assisted coding, writing &amp; analysis</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="R Programming Language" ID="ID_722022376" CREATED="1622865846801" MODIFIED="1710523582445" LINK="freeplane:/%20/M:/My%20Drive/My%20Google%20Docs/MindMaps/Google%20Data%20Analytics%20Certificate.mm#ID_611054735"/>
</node>
<node TEXT="Python" FOLDED="true" ID="ID_572362696" CREATED="1609872710132" MODIFIED="1609873570708">
<node TEXT="Object Oriented" FOLDED="true" ID="ID_1197012763" CREATED="1611851053513" MODIFIED="1611851059808">
<node TEXT="reference" FOLDED="true" ID="ID_1128829336" CREATED="1624128091147" MODIFIED="1624128094765">
<node ID="ID_1916798869" CREATED="1624127949816" MODIFIED="1624127949816" LINK="https://pythonnumericalmethods.berkeley.edu/notebooks/chapter07.00-Object-Oriented-Programming.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pythonnumericalmethods.berkeley.edu/notebooks/chapter07.00-Object-Oriented-Programming.html">Chapter 7. Object Oriented Programming (OOP) — Python Numerical Methods</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1057607635" CREATED="1611851086945" MODIFIED="1611851086945" LINK="https://www.datacamp.com/community/tutorials/python-oop-tutorial"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.datacamp.com/community/tutorials/python-oop-tutorial">Object-Oriented Programming in Python - DataCamp</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_794172026" CREATED="1611851375570" MODIFIED="1611851375570" LINK="https://www.tutorialspoint.com/python/python_classes_objects.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tutorialspoint.com/python/python_classes_objects.htm">Python - Object Oriented - Tutorialspoint</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Key Principles" FOLDED="true" ID="ID_1364930841" CREATED="1624128960364" MODIFIED="1624128965349">
<node TEXT="Inheritance - a way of creating new classes from existing class without modifying it." ID="ID_576618171" CREATED="1624128981815" MODIFIED="1624128981815"/>
<node TEXT="Encapsulation - a way of hiding some of the private details of a class from other objects." ID="ID_884226036" CREATED="1624128981815" MODIFIED="1624128981815"/>
<node TEXT="Polymorphism - a way of using common operation in different ways for different data input." ID="ID_1083683012" CREATED="1624128981819" MODIFIED="1624128981819"/>
</node>
<node TEXT="class" FOLDED="true" ID="ID_1717069710" CREATED="1624128505439" MODIFIED="1624128508366">
<node TEXT="template for defining objects" ID="ID_1942068827" CREATED="1624128513326" MODIFIED="1624128518512"/>
<node TEXT="contains" FOLDED="true" ID="ID_106311037" CREATED="1624129237171" MODIFIED="1624129240568">
<node TEXT="init method" FOLDED="true" ID="ID_474166499" CREATED="1624129243931" MODIFIED="1624129256117">
<node TEXT="run in soon as an object of the classes instantiated" ID="ID_1317607924" CREATED="1624129259864" MODIFIED="1624129275160"/>
<node TEXT="assigns initial values to the object before it is ready to be used" ID="ID_1910802228" CREATED="1624129277022" MODIFIED="1624129309391"/>
</node>
<node TEXT="other methods" ID="ID_1449492928" CREATED="1624129521999" MODIFIED="1624129524977"/>
</node>
<node TEXT="example" FOLDED="true" ID="ID_1802606949" CREATED="1624129363159" MODIFIED="1624129366177">
<node TEXT="class ClassName(superclass):" FOLDED="true" ID="ID_1156365090" CREATED="1624129434392" MODIFIED="1624129434392">
<node TEXT="def __init__(self, arguments):" FOLDED="true" ID="ID_1541037334" CREATED="1624129434392" MODIFIED="1624129434392">
<node TEXT="# define or assign object attributes" ID="ID_643168788" CREATED="1624129434392" MODIFIED="1624129434392"/>
</node>
<node TEXT="def other_methods(self, arguments):" FOLDED="true" ID="ID_1828140481" CREATED="1624129434392" MODIFIED="1624129434392">
<node TEXT="# body of the method" ID="ID_76842815" CREATED="1624129434392" MODIFIED="1624129434392"/>
</node>
</node>
</node>
<node ID="ID_183425345" CREATED="1624128533138" MODIFIED="1624128533138" LINK="https://www.ncl.ucar.edu/Document/HLUs/User_Guide/classes/classoview.shtml"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ncl.ucar.edu/Document/HLUs/User_Guide/classes/classoview.shtml">Understanding classes and objects</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="object" FOLDED="true" ID="ID_449511845" CREATED="1624128115368" MODIFIED="1624128118126">
<node TEXT="instance of the class with actual values" ID="ID_503276894" CREATED="1624128706322" MODIFIED="1624128716002"/>
<node TEXT="contains" FOLDED="true" ID="ID_1654428374" CREATED="1624128763766" MODIFIED="1624128767765">
<node TEXT="attributes or data" ID="ID_1828244389" CREATED="1624128134140" MODIFIED="1624128171121"/>
<node TEXT="methods or functions" ID="ID_151643760" CREATED="1624128173163" MODIFIED="1624128185173"/>
</node>
</node>
</node>
<node TEXT="functions" FOLDED="true" ID="ID_722391929" CREATED="1623134343111" MODIFIED="1623134347267">
<node TEXT="lambda" FOLDED="true" ID="ID_1070981686" CREATED="1623134356741" MODIFIED="1623134362152">
<node ID="ID_53325340" CREATED="1623134363515" MODIFIED="1623134363515" LINK="https://pythonspot.com/python-lambda/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pythonspot.com/python-lambda/">Python lambda - Python Tutorial</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="religion furniture" ID="ID_486433109" CREATED="1623164507391" MODIFIED="1623164545894"/>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1454009840" CREATED="1612045939119" MODIFIED="1612045942156">
<node ID="ID_1013089320" CREATED="1609877249752" MODIFIED="1609877249752" LINK="https://docs.python.org/3/reference/index.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.python.org/3/reference/index.html">The Python Language Reference &#8212; Python 3.9.1 documentation</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Types" FOLDED="true" ID="ID_1272016272" CREATED="1612042926266" MODIFIED="1612042928539">
<node TEXT="String Formatting" FOLDED="true" ID="ID_1289691697" CREATED="1610578017473" MODIFIED="1610578022436">
<node ID="ID_28898571" CREATED="1610578038300" MODIFIED="1610578038300" LINK="https://python-reference.readthedocs.io/en/latest/docs/str/formatting.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://python-reference.readthedocs.io/en/latest/docs/str/formatting.html">% (String Formatting Operator) — Python Reference (The Right Way) 0.1 documentation</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="list = [&apos;aaa&apos;, &apos;bbb&apos;, &apos;ccc&apos;]&#xa;string = &apos;&apos;.join(list)" FOLDED="true" ID="ID_288220761" CREATED="1609965890334" MODIFIED="1609965936177">
<node ID="ID_1664939860" CREATED="1609965963124" MODIFIED="1609965963124" LINK="https://stackoverflow.com/questions/12453580/how-to-concatenate-items-in-a-list-to-a-single-string"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/12453580/how-to-concatenate-items-in-a-list-to-a-single-string">python - How to concatenate items in a list to a single string? - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="objects and classes" FOLDED="true" ID="ID_1585587644" CREATED="1610994235283" MODIFIED="1610994255795">
<node ID="ID_1937586539" CREATED="1610994257483" MODIFIED="1610994257483" LINK="https://www.digitalocean.com/community/tutorials/how-to-construct-classes-and-define-objects-in-python-3"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.digitalocean.com/community/tutorials/how-to-construct-classes-and-define-objects-in-python-3">Object-Oriented Programming: Classes and Objects in Python | DigitalOcean</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="operators" FOLDED="true" ID="ID_1561673911" CREATED="1612045927173" MODIFIED="1612045930767">
<node ID="ID_1656097182" CREATED="1609872710141" MODIFIED="1609872710141" LINK="https://www.tutorialspoint.com/python/python_basic_operators.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.tutorialspoint.com/python/python_basic_operators.htm">Python - Basic Operators - Tutorialspoint</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Databases" FOLDED="true" ID="ID_402597758" CREATED="1610757016347" MODIFIED="1610757020621">
<node ID="ID_688539876" CREATED="1610757021399" MODIFIED="1610757021399" LINK="https://www.freecodecamp.org/news/connect-python-with-sql/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.freecodecamp.org/news/connect-python-with-sql/">How to Create and Manipulate SQL Databases with Python</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_786679465" CREATED="1609872710163" MODIFIED="1610642455840"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
            Speech Packages
          </h2>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="conda install PyAudio" FOLDED="true" ID="ID_93139046" CREATED="1609872710164" MODIFIED="1609874006013">
<node ID="ID_55408174" CREATED="1609872710166" MODIFIED="1609872710166" LINK="https://stackoverflow.com/questions/52283840/i-cant-install-pyaudio-on-windows-how-to-solve-error-microsoft-visual-c-14"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p>
            <cite style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 9.0pt; color: #595959"><font face="Calibri" size="9.0pt" color="#595959">From &lt;<a href="https://stackoverflow.com/questions/52283840/i-cant-install-pyaudio-on-windows-how-to-solve-error-microsoft-visual-c-14">https://stackoverflow.com/questions/52283840/i-cant-install-pyaudio-on-windows-how-to-solve-error-microsoft-visual-c-14</a>&gt; </font></cite>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="conda install swig" FOLDED="true" ID="ID_580987306" CREATED="1609872710167" MODIFIED="1609874354363">
<node ID="ID_1441402611" CREATED="1609872710167" MODIFIED="1609872710167" LINK="https://stackoverflow.com/questions/44504899/installing-pocketsphinx-python-module-command-swig-exe-failed"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p>
            <cite style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 9.0pt; color: #595959"><font face="Calibri" size="9.0pt" color="#595959">From &lt;<a href="https://stackoverflow.com/questions/44504899/installing-pocketsphinx-python-module-command-swig-exe-failed">https://stackoverflow.com/questions/44504899/installing-pocketsphinx-python-module-command-swig-exe-failed</a>&gt; </font></cite>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_850082906" CREATED="1609872710169" MODIFIED="1609872710169"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            python setup.py install
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1532751988" CREATED="1609872710170" MODIFIED="1609872710170" LINK="https://github.com/Uberi/speech_recognition"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p>
            <cite style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 9.0pt; color: #595959"><font face="Calibri" size="9.0pt" color="#595959">From &lt;<a href="https://github.com/Uberi/speech_recognition">https://github.com/Uberi/speech_recognition</a>&gt; </font></cite>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1797961913" CREATED="1609872710171" MODIFIED="1609872710171"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            &#160;
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_963795655" CREATED="1609872710172" MODIFIED="1610153037610" LINK="https://github.com/Uberi/speech_recognition/blob/master/examples/microphone_recognition.py"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://github.com/Uberi/speech_recognition/blob/master/examples/microphone_recognition.py"><font color="#009999">speech_recognition/microphone_recognition.py at master &#183; Uberi/speech_recognition &#183; GitHub</font></a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1210150745" CREATED="1609872710185" MODIFIED="1609872710185"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
            GUI
          </h2>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_867648485" CREATED="1609872710186" MODIFIED="1609872710186" LINK="https://sattia.blogspot.com/2018/09/add-guis-to-your-programs-and-scripts.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h3 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 12.0pt; color: #5B9BD5">
            <a href="https://sattia.blogspot.com/2018/09/add-guis-to-your-programs-and-scripts.html">Sameh Attia: Add GUIs to your programs and scripts easily with PySimpleGUI</a>
          </h3>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1679197090" CREATED="1609872710188" MODIFIED="1609872710188"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h3 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 12.0pt; color: #5B9BD5">
            Tkinter
          </h3>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1320720119" CREATED="1609872710188" MODIFIED="1609872710188" LINK="https://realpython.com/python-gui-tkinter/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://realpython.com/python-gui-tkinter/">Python GUI Programming With Tkinter &#8211; Real Python </a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1167287287" CREATED="1609872710189" MODIFIED="1609872710189" LINK="https://www.geeksforgeeks.org/create-table-using-tkinter/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.geeksforgeeks.org/create-table-using-tkinter/">Create Table Using Tkinter - GeeksforGeeks</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_38894326" CREATED="1609872710190" MODIFIED="1609872710190" LINK="https://pythonbasics.org/pyqt-table/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://pythonbasics.org/pyqt-table/">How to use Tables in PyQt - Python Tutorial</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1944777503" CREATED="1609872710145" MODIFIED="1609872710145"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
            Data Collection And Storage
          </h2>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_711626543" CREATED="1609872710146" MODIFIED="1609872710146" LINK="https://www.postgresqltutorial.com/postgresql-python/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.postgresqltutorial.com/postgresql-python/">PostgreSQL Python Tutorial With Practical Examples</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_445150862" CREATED="1609872710149" MODIFIED="1609872710149" LINK="https://campus.datacamp.com/courses/intermediate-python/dictionaries-pandas?ex=13"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://campus.datacamp.com/courses/intermediate-python/dictionaries-pandas?ex=13">CSV to DataFrame (2) | Python</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_986539796" CREATED="1609872710150" MODIFIED="1609872710150" LINK="https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.at.html#pandas.DataFrame.at"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.at.html#pandas.DataFrame.at">pandas.DataFrame.at &#8212; pandas 1.1.2 documentation</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_242319758" CREATED="1609872710152" MODIFIED="1609872710152" LINK="https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_csv.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_csv.html">pandas.DataFrame.to_csv &#8212; pandas 1.1.2 documentation</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_228773594" CREATED="1609872710154" MODIFIED="1609872710154"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            Csv
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_287490543" CREATED="1609872710154" MODIFIED="1609872710154"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            csv.DictReader()
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1795785809" CREATED="1609872710155" MODIFIED="1609872710155" LINK="https://realpython.com/python-csv/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://realpython.com/python-csv/">Reading and Writing CSV Files in Python &#8211; Real Python</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_337411606" CREATED="1609872710156" MODIFIED="1609872710156" LINK="https://realpython.com/learning-paths/data-collection-storage/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://realpython.com/learning-paths/data-collection-storage/">Data Collection &amp; Storage (Learning Path) &#8211; Real Python</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1706895026" CREATED="1609872710157" MODIFIED="1609872710157"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            &#160;
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_220456555" CREATED="1609872710157" MODIFIED="1609872710157"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            &#160;
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1518174923" CREATED="1609872710158" MODIFIED="1609872710158" LINK="https://wiki.python.org/moin/IntegratedDevelopmentEnvironments"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://wiki.python.org/moin/IntegratedDevelopmentEnvironments">IntegratedDevelopmentEnvironments - Python Wiki</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_458585942" CREATED="1609872710158" MODIFIED="1609872710158"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            &#160;
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1431264311" CREATED="1609872710159" MODIFIED="1609872710159" LINK="https://pythonhosted.org/dragonfly/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://pythonhosted.org/dragonfly/">Dragonfly &#8212; Dragonfly v0.6.6b1 documentation</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_304954973" CREATED="1609872710160" MODIFIED="1609872710160" LINK="https://realpython.com/python-speech-recognition/#picking-a-python-speech-recognition-package"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://realpython.com/python-speech-recognition/#picking-a-python-speech-recognition-package">The Ultimate Guide To Speech Recognition With Python &#8211; Real Python</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1376675196" CREATED="1609872710161" MODIFIED="1609872710161"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            &#160;
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1173919981" CREATED="1609872710176" MODIFIED="1609872710176"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
            Speech to Text
          </h2>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1454480721" CREATED="1610492797807" MODIFIED="1610492797807" LINK="https://awesomeopensource.com/projects/speech-recognition"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://awesomeopensource.com/projects/speech-recognition">The Top 184 Speech Recognition Open Source Projects</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Using Dragon" FOLDED="true" ID="ID_1060174953" CREATED="1610492120070" MODIFIED="1610492124886">
<node TEXT="dragonfly" ID="ID_1444327789" CREATED="1610497210513" MODIFIED="1610497217150"/>
<node TEXT="Natlink" FOLDED="true" ID="ID_1716050584" CREATED="1610491715971" MODIFIED="1610491722729">
<node ID="ID_924822123" CREATED="1610491734535" MODIFIED="1610491734535" LINK="https://stackoverflow.com/questions/2952899/dragon-naturallyspeaking-programmers"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/2952899/dragon-naturallyspeaking-programmers">python - Dragon NaturallySpeaking Programmers - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Using WSR" FOLDED="true" ID="ID_1111876333" CREATED="1610492184976" MODIFIED="1610492190182">
<node ID="ID_1655845301" CREATED="1610492191719" MODIFIED="1610492191719" LINK="http://surguy.net/articles/speechrecognition.xml"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://surguy.net/articles/speechrecognition.xml">Speech recognition in Windows using Python</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_38951791" CREATED="1610492353266" MODIFIED="1610492353266" LINK="https://docs.microsoft.com/en-us/azure/cognitive-services/speech-service/speech-sdk?tabs=windows%2Cubuntu%2Cios-xcode%2Cmac-xcode%2Candroid-studio"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://docs.microsoft.com/en-us/azure/cognitive-services/speech-service/speech-sdk?tabs=windows%2Cubuntu%2Cios-xcode%2Cmac-xcode%2Candroid-studio">About the Speech SDK - Speech service - Azure Cognitive Services | Microsoft Docs</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Not Used" FOLDED="true" ID="ID_1661255820" CREATED="1610381762603" MODIFIED="1610381773734">
<node FOLDED="true" ID="ID_1477201992" CREATED="1609872710176" MODIFIED="1609872710176" LINK="https://pypi.org/project/SpeechRecognition/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://pypi.org/project/SpeechRecognition/">SpeechRecognition &#183; PyPI</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1808335232" CREATED="1610326941431" MODIFIED="1610326941431" LINK="https://github.com/Uberi/speech_recognition/tree/master/examples"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/Uberi/speech_recognition/tree/master/examples">speech_recognition/examples at master · Uberi/speech_recognition · GitHub</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Engine" FOLDED="true" ID="ID_1409992868" CREATED="1610325187291" MODIFIED="1610325193218">
<node TEXT="PocketSphinx" FOLDED="true" ID="ID_517014918" CREATED="1610327198389" MODIFIED="1610327210502">
<node ID="ID_70916660" CREATED="1609875755617" MODIFIED="1609875755617" LINK="https://github.com/bambocher/pocketsphinx-python"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/bambocher/pocketsphinx-python">GitHub - bambocher/pocketsphinx-python: Python interface to CMU Sphinxbase and Pocketsphinx libraries</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1162382658" CREATED="1609872710178" MODIFIED="1609872710178" LINK="https://cmusphinx.github.io/wiki/tutorialpocketsphinx/#advanced-usage"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://cmusphinx.github.io/wiki/tutorialpocketsphinx/#advanced-usage">Building an application with PocketSphinx &#8211; CMUSphinx Open Source Speech Recognition</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="" ID="ID_634412210" CREATED="1610327220917" MODIFIED="1610327220917"/>
</node>
</node>
<node ID="ID_1903940978" CREATED="1609872710180" MODIFIED="1609872710180" LINK="https://www.geeksforgeeks.org/voice-assistant-using-python/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.geeksforgeeks.org/voice-assistant-using-python/">Voice Assistant using python - GeeksforGeeks</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_25223273" CREATED="1610491409357" MODIFIED="1610491409357" LINK="https://realpython.com/python-speech-recognition/#picking-a-python-speech-recognition-package"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://realpython.com/python-speech-recognition/#picking-a-python-speech-recognition-package">The Ultimate Guide To Speech Recognition With Python – Real Python</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_665485992" CREATED="1609872710182" MODIFIED="1609872710182"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
            Text to speech
          </h2>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_104036344" CREATED="1609872710183" MODIFIED="1609872710183"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            Pyttsx3
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1482428518" CREATED="1609872710183" MODIFIED="1609872710183" LINK="https://www.geeksforgeeks.org/voice-assistant-using-python/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p>
            <cite style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 9.0pt; color: #595959"><font face="Calibri" size="9.0pt" color="#595959">From &lt;<a href="https://www.geeksforgeeks.org/voice-assistant-using-python/">https://www.geeksforgeeks.org/voice-assistant-using-python/</a>&gt; </font></cite>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1732077959" CREATED="1609872710182" MODIFIED="1609872710182" LINK="https://pythonprogramminglanguage.com/text-to-speech/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
        <div style="margin-top: 0in; margin-left: 0in; width: 4.3152in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://pythonprogramminglanguage.com/text-to-speech/">Speech Recognition in Python (Text to speech) - Learn Python</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="GUI" FOLDED="true" ID="ID_1566818074" CREATED="1612045958497" MODIFIED="1612045960480">
<node ID="ID_1315998754" CREATED="1612045969827" MODIFIED="1612045969827" LINK="https://pypi.org/project/PySimpleGUI/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pypi.org/project/PySimpleGUI/">PySimpleGUI · PyPI</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1180046063" CREATED="1612046438743" MODIFIED="1612046438743" LINK="https://pysimplegui.readthedocs.io/en/latest/call%20reference/#input-element"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pysimplegui.readthedocs.io/en/latest/call%20reference/#input-element">Call reference - PySimpleGUI</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="fonts" FOLDED="true" ID="ID_651849952" CREATED="1612046505988" MODIFIED="1612046508974">
<node ID="ID_1459594393" CREATED="1612046512089" MODIFIED="1612046512089" LINK="https://www.tutorialspoint.com/python/tk_fonts.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.tutorialspoint.com/python/tk_fonts.htm">Python - Tkinter Fonts - Tutorialspoint</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="import" FOLDED="true" ID="ID_1745718911" CREATED="1610400035797" MODIFIED="1610400040366">
<node ID="ID_1178995025" CREATED="1610400097178" MODIFIED="1610400097178" LINK="https://stackoverflow.com/questions/2349991/how-to-import-other-python-files"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/2349991/how-to-import-other-python-files">How to import other Python files? - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="time, waiting" FOLDED="true" ID="ID_1716917343" CREATED="1612050023649" MODIFIED="1612050028711">
<node ID="ID_826837385" CREATED="1612050030218" MODIFIED="1612050030218" LINK="https://blog.miguelgrinberg.com/post/how-to-make-python-wait"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://blog.miguelgrinberg.com/post/how-to-make-python-wait">How To Make Python Wait - miguelgrinberg.com</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_642124387" CREATED="1612911806195" MODIFIED="1612911806195" LINK="https://realpython.com/python-time-module/#dealing-with-python-time-using-seconds"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://realpython.com/python-time-module/#dealing-with-python-time-using-seconds">A Beginner’s Guide to the Python time Module – Real Python</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="CMD Commandline" FOLDED="true" ID="ID_577902205" CREATED="1711046516284" MODIFIED="1711046521622">
<node TEXT="merge csv txt" FOLDED="true" ID="ID_394178740" CREATED="1711046522596" MODIFIED="1711046534896">
<node TEXT="copy /b *.txt newfile.txt" ID="ID_1440181946" CREATED="1711046555765" MODIFIED="1711046555765"/>
<node TEXT="reference" FOLDED="true" ID="ID_269544905" CREATED="1711046541349" MODIFIED="1711046544517">
<node ID="ID_1742032261" CREATED="1711046547780" MODIFIED="1711046547780" LINK="https://superuser.com/questions/111825/a-command-line-or-batch-cmd-to-concatenate-multiple-files"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://superuser.com/questions/111825/a-command-line-or-batch-cmd-to-concatenate-multiple-files">windows - A command-line or batch cmd to concatenate multiple files - Super User</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="General editors" FOLDED="true" ID="ID_534343935" CREATED="1622185393184" MODIFIED="1711032883248">
<node TEXT="Atom" FOLDED="true" ID="ID_750863487" CREATED="1622185507419" MODIFIED="1622185516620">
<node ID="ID_833651860" CREATED="1622185544853" MODIFIED="1622185544853" LINK="https://flight-manual.atom.io/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://flight-manual.atom.io/">Atom</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_298195274" CREATED="1622185525688" MODIFIED="1622185525688" LINK="https://github.com/nwinkler/atom-keyboard-shortcuts"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://github.com/nwinkler/atom-keyboard-shortcuts">GitHub - nwinkler/atom-keyboard-shortcuts: A list of keyboard shortcuts for the Atom text editor</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_440411175" CREATED="1711032106429" MODIFIED="1711032106429" LINK="https://code.visualstudio.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://code.visualstudio.com/">Visual Studio Code - Code Editing. Redefined</a>
  </body>
</html>
</richcontent>
<node TEXT="R" FOLDED="true" ID="ID_1915704284" CREATED="1711032866660" MODIFIED="1711032867728">
<node ID="ID_1505049274" CREATED="1711032546768" MODIFIED="1711032546768" LINK="https://towardsdatascience.com/vscode-vs-rstudio-worth-the-switch-7a4415fc3275"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://towardsdatascience.com/vscode-vs-rstudio-worth-the-switch-7a4415fc3275">VSCode vs RStudio Worth the switch? | Karat Sidhu | Towards Data Science</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_638502477" CREATED="1711032247337" MODIFIED="1711032247337" LINK="https://marketplace.visualstudio.com/items?itemName=captainstack.captain-stack&amp;ssr=false"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://marketplace.visualstudio.com/items?itemName=captainstack.captain-stack&amp;ssr=false">Captain Stack - Visual Studio Marketplace</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Data" POSITION="bottom_or_right" ID="ID_1381923917" CREATED="1711047759900" MODIFIED="1711047762404"/>
<node TEXT="Audio" FOLDED="true" POSITION="bottom_or_right" ID="ID_1652254434" CREATED="1542145373170" MODIFIED="1542145375579">
<node TEXT="Utilities" FOLDED="true" ID="ID_421536077" CREATED="1608673202069" MODIFIED="1608673209720">
<node TEXT="Voicemeeter" ID="ID_641111658" CREATED="1608673212409" MODIFIED="1608673221081"/>
</node>
<node TEXT="Bluetooth Speakers" FOLDED="true" ID="ID_942945839" CREATED="1542145376438" MODIFIED="1542145383350">
<node TEXT="Small: HX-007" FOLDED="true" ID="ID_374179555" CREATED="1542145384366" MODIFIED="1542145391144">
<node TEXT="Connecting:" FOLDED="true" ID="ID_29083048" CREATED="1542147306518" MODIFIED="1542147310146">
<node TEXT="Blue light will flash when looking to connect" FOLDED="true" ID="ID_1817163162" CREATED="1542147111275" MODIFIED="1542147158679">
<node TEXT="Automatically looks when not connected to anything" ID="ID_1680727640" CREATED="1542147138082" MODIFIED="1542147152212"/>
</node>
<node TEXT="Solid when connected" ID="ID_1334269791" CREATED="1542147124446" MODIFIED="1542147137450"/>
</node>
<node TEXT="Call function:" FOLDED="true" ID="ID_739063967" CREATED="1542147299788" MODIFIED="1542147299788">
<node TEXT="When the music box is connected with a mobile phone through Bluetooth and then there is a phone call," ID="ID_208942175" CREATED="1542147299788" MODIFIED="1542147299788"/>
<node TEXT="you can click the power button to answer the call, so that you do not have to worry about" ID="ID_1132978273" CREATED="1542147299795" MODIFIED="1542147299795"/>
<node TEXT="missing an important phone call while taking shower. Click the power button again to hang up." ID="ID_1613306985" CREATED="1542147299806" MODIFIED="1542147299806"/>
<node TEXT="Double-click the power button to answer back the last call." ID="ID_220726217" CREATED="1542147299812" MODIFIED="1542147299812"/>
</node>
<node TEXT="Switch songs:" ID="ID_20635013" CREATED="1542147299820" MODIFIED="1542147299820"/>
<node TEXT="long press &quot;+&quot; or &quot;-&quot; to adjust the music volume, and click &quot;+&quot; or &quot;-&quot; to switch the next or previous song." ID="ID_271234957" CREATED="1542147299823" MODIFIED="1542147299823"/>
<node TEXT="Stable connection:" ID="ID_1999579738" CREATED="1542147299827" MODIFIED="1542147299827"/>
<node TEXT="Bluetooth can connect with a distance of 40 feet stably. Even if your mobile phone is in the room," ID="ID_293353598" CREATED="1542147299837" MODIFIED="1542147299837"/>
<node TEXT="it is free for you to switch songs and answer phone calls in the bathroom." ID="ID_315665319" CREATED="1542147299839" MODIFIED="1542147299839"/>
<node TEXT="Charging and use:" ID="ID_772024415" CREATED="1542147299845" MODIFIED="1542147299845"/>
<node TEXT="The music box uses USB charging, convenient and simple, full 3-5 hours. In the boot state, it can work continuously for 8 hours." ID="ID_399715067" CREATED="1542147299849" MODIFIED="1542147299849"/>
<node TEXT="In the off state, it can stand by for 12 days." ID="ID_1298708295" CREATED="1542147299852" MODIFIED="1542147299852"/>
</node>
</node>
<node TEXT="Bluetooth TX RX BT 500" FOLDED="true" ID="ID_1955271480" CREATED="1598066016925" MODIFIED="1598066028842">
<node TEXT="" ID="ID_1869706600" CREATED="1598066030965" MODIFIED="1598066030965"/>
</node>
<node ID="ID_1819481492" CREATED="1592349587587" MODIFIED="1592349587587" LINK="https://www.vb-audio.com/Voicemeeter/banana.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.vb-audio.com/Voicemeeter/banana.htm">VB-Audio VoiceMeeter Banana</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="House Design" FOLDED="true" POSITION="bottom_or_right" ID="ID_1672303322" CREATED="1608673266572" MODIFIED="1608673271886">
<node TEXT="SweetHome3D" ID="ID_468264379" CREATED="1608673272763" MODIFIED="1608673281358"/>
</node>
<node TEXT="Ripping Music" FOLDED="true" POSITION="bottom_or_right" ID="ID_839820387" CREATED="1545945222263" MODIFIED="1545945230180">
<node TEXT="From Youtube" FOLDED="true" ID="ID_1127344768" CREATED="1545945231378" MODIFIED="1545945235069">
<node ID="ID_1687264575" CREATED="1545945236577" MODIFIED="1545945236577" LINK="https://rg3.github.io/youtube-dl/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://rg3.github.io/youtube-dl/">youtube-dl</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_278245911" CREATED="1545945377119" MODIFIED="1545945377119" LINK="https://stackoverflow.com/questions/35608686/how-can-i-get-the-actual-video-url-of-a-youtube-live-stream"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackoverflow.com/questions/35608686/how-can-i-get-the-actual-video-url-of-a-youtube-live-stream">How can I get the actual video URL of a YouTube live stream? - Stack Overflow</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Converting" FOLDED="true" ID="ID_1782345322" CREATED="1546015685802" MODIFIED="1546015688357">
<node ID="ID_684889687" CREATED="1546015692209" MODIFIED="1546015692209" LINK="https://www.quora.com/What-is-the-best-way-to-convert-mp4-to-mp3-files-in-bulk"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.quora.com/What-is-the-best-way-to-convert-mp4-to-mp3-files-in-bulk">What is the best way to convert mp4 to mp3 files in bulk? - Quora</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_598646038" CREATED="1546015705656" MODIFIED="1546015705656" LINK="http://ffmpeg.org/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://ffmpeg.org/">FFmpeg</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="alternate word models" FOLDED="true" POSITION="bottom_or_right" ID="ID_1173144347" CREATED="1548803247482" MODIFIED="1623167747401">
<node ID="ID_1930711604" CREATED="1548803252570" MODIFIED="1548803252570" LINK="https://alternativeto.net/software/treesheets/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://alternativeto.net/software/treesheets/">TreeSheets Alternatives and Similar Software - AlternativeTo.net</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Faxing" FOLDED="true" POSITION="bottom_or_right" ID="ID_1892110362" CREATED="1713462867238" MODIFIED="1713462869379">
<node ID="ID_1734691960" CREATED="1713462870692" MODIFIED="1713462870692" LINK="https://faxzero.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://faxzero.com/">Free Fax • Free Internet Faxing</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Printing" POSITION="bottom_or_right" ID="ID_1217160863" CREATED="1713499171905" MODIFIED="1713499175170">
<node TEXT="Monica School" ID="ID_832859414" CREATED="1713499176444" MODIFIED="1713499197030">
<node TEXT="HP LaserJet Pro 400 M401n" ID="ID_949456" CREATED="1713499197033" MODIFIED="1713499214464"/>
</node>
</node>
<node TEXT="Website Access" POSITION="bottom_or_right" ID="ID_622343386" CREATED="1534952662307" MODIFIED="1536182920254" LINK="WebsiteAccess.mm">
<font NAME="Nirmala UI"/>
</node>
</node>
</map>
