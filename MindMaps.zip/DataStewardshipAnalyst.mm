<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<attribute_registry SHOW_ATTRIBUTES="selected">
    <attribute_name VISIBLE="true" NAME="Due"/>
    <attribute_name VISIBLE="true" NAME="Last Action "/>
    <attribute_name VISIBLE="true" MANUAL="true" NAME="Start">
        <attribute_value VALUE=""/>
        <attribute_value VALUE="11/8/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-11-08T00:00-0500|date"/>
    </attribute_name>
    <attribute_name VISIBLE="true" NAME="When"/>
    <attribute_name VISIBLE="true" NAME="WhenDone"/>
    <attribute_name MANUAL="true" NAME="d">
        <attribute_value VALUE=""/>
    </attribute_name>
</attribute_registry>
<node TEXT="Data Stewardship Analyst" FOLDED="false" ID="ID_1578275913" CREATED="1706245947491" MODIFIED="1720793029983" LINK="Career%20Management.mm">
<icon BUILTIN="bookmark"/>
<edge DASH="SOLID"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<hook NAME="MapStyle" background="#000000">
    <properties show_icon_for_attributes="true" show_note_icons="true" allow_compact_layout="true" fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" ID="ID_1067616591" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="oval" UNIFORM_SHAPE="true" TEXT_ALIGN="LEFT" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="24"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_238255399" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" NUMBERED="false" FORMAT="STANDARD_FORMAT" TEXT_ALIGN="LEFT" TEXT_WRITING_DIRECTION="LEFT_TO_RIGHT" MAX_WIDTH="120 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#808080" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM" VGAP_QUANTITY="2 pt" COMMON_HGAP_QUANTITY="14 pt">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_238255399" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Segoe UI" SIZE="9" BOLD="true" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#333333" WIDTH="3"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/html"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/html"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="11"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.tags" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="9"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI"/>
<edge STYLE="hide_edge" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#203868" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<icon BUILTIN="yes"/>
<font NAME="Segoe UI"/>
<edge COLOR="#333333"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" ID="ID_1878240162" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" VGAP_QUANTITY="3 pt" CHILD_NODES_LAYOUT="LEFTTORIGHT_BOTTOM_FLOW">
<font NAME="Segoe UI" SIZE="22" ITALIC="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="LEFTTORIGHT_BOTTOM_FLOW">
<font NAME="Segoe UI" SIZE="20" BOLD="true"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Segoe UI" SIZE="18"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" ID="ID_10527866" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="3 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1.2 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_FIRST">
<font NAME="Segoe UI" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#1b1b1b" WIDTH="1" DASH="SOLID"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<font BOLD="false"/>
<node TEXT="Tasks" ID="ID_1437224000" CREATED="1738682513254" MODIFIED="1738682515917">
<node TEXT="Today" ID="ID_1141464389" CREATED="1738682561149" MODIFIED="1738682567135"/>
<node TEXT="#Quick" ID="ID_29846467" CREATED="1739754095021" MODIFIED="1739754113642">
<node TEXT="Mint Igencd question" ID="ID_1495630483" CREATED="1739800616476" MODIFIED="1739800616476">
<node TEXT="Olaf" ID="ID_738979573" CREATED="1739800558252" MODIFIED="1739800560386"/>
</node>
</node>
<node TEXT="Priority" ID="ID_1458904082" CREATED="1739385606359" MODIFIED="1739385609706">
<node TEXT="MBE Cleanup (transferred)" FOLDED="true" ID="ID_1622150356" CREATED="1715792298477" MODIFIED="1739386244606">
<node TEXT="reference" FOLDED="true" POSITION="bottom_or_right" ID="ID_114744824" CREATED="1715792375313" MODIFIED="1715792377497">
<node FOLDED="true" ID="ID_1675819868" CREATED="1716400555450" MODIFIED="1716400555450" LINK="https://syngenta.sharepoint.com/sites/MINTIdentityGapAnalysisResolution"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/MINTIdentityGapAnalysisResolution">MINT Identity Gap Analysis &amp; Resolution - Home</a>
  </body>
</html>
</richcontent>
<node ID="ID_1648023656" CREATED="1716412994703" MODIFIED="1716412994703" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/MINT%20MBE%20Resolution%20Kickoff%20-%20Tomato.pptx?d=w313314a8aacc4c2682cbf2e57e3e66b7&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=35BiPU"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/MINT%20MBE%20Resolution%20Kickoff%20-%20Tomato.pptx?d=w313314a8aacc4c2682cbf2e57e3e66b7&amp;csf=1&amp;web=1&amp;e=35BiPU">MINT MBE Resolution Kickoff - Tomato.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1412138084" CREATED="1716412667076" MODIFIED="1716869365382" LINK="https://syngenta.sharepoint.com/:f:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup?csf=1&amp;amp;web=1&amp;amp;e=b0jYx2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup?csf=1&amp;web=1&amp;e=b0jYx2">MBE cleanup (Applied Data Science V&amp;F)</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1072168160" CREATED="1716507205579" MODIFIED="1716507205579" LINK="https://syngenta.sharepoint.com/:w:/r/sites/SupportImplementation/Shared%20Documents/General/Breeder_Ressources/MINT_PreventingNewMBEs.docx?d=web6a6d039dd84f8f8a28295972fd8bf2&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=gnpL1h"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:w:/r/sites/SupportImplementation/Shared%20Documents/General/Breeder_Ressources/MINT_PreventingNewMBEs.docx?d=web6a6d039dd84f8f8a28295972fd8bf2&amp;csf=1&amp;web=1&amp;e=gnpL1h">MINT_PreventingNewMBEs.docx</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1341593430" CREATED="1716870013985" MODIFIED="1716870023147" LINK="https://syngenta.sharepoint.com/:f:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task?csf=1&amp;amp;web=1&amp;amp;e=vt4gVd"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task?csf=1&amp;web=1&amp;e=vt4gVd">02_Multiple BE Task (Michele transition)</a>
  </body>
</html>
</richcontent>
<node TEXT="Lines" FOLDED="true" ID="ID_808644064" CREATED="1717446105770" MODIFIED="1717446107921">
<node FOLDED="true" ID="ID_697389802" CREATED="1717444174451" MODIFIED="1717444174451" LINK="https://syngenta.sharepoint.com/:x:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task/INC16979999_MBE_stable_line_code.xlsx?d=w3eaa2b4b5ac646cba166f843e5f379ca&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=MNh6pg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task/INC16979999_MBE_stable_line_code.xlsx?d=w3eaa2b4b5ac646cba166f843e5f379ca&amp;csf=1&amp;web=1&amp;e=MNh6pg">INC16979999_MBE_stable_line_code.xlsx</a>
  </body>
</html>
</richcontent>
<node TEXT="about" FOLDED="true" ID="ID_1354736803" CREATED="1717445954149" MODIFIED="1717445963268">
<node TEXT="source for MBE Groupings" ID="ID_678094443" CREATED="1717445963882" MODIFIED="1717445972598"/>
</node>
<node TEXT="origianl line code sheet" FOLDED="true" ID="ID_903065207" CREATED="1717444178138" MODIFIED="1717444197288">
<node TEXT="crop mane" ID="ID_953611565" CREATED="1717444199051" MODIFIED="1717444201916"/>
<node TEXT="create_year_of last batch" FOLDED="true" ID="ID_833166916" CREATED="1717444239664" MODIFIED="1717444252655">
<node TEXT="2017 cutoff date" ID="ID_921225547" CREATED="1717444254344" MODIFIED="1717444265916"/>
</node>
</node>
<node TEXT="working line code" FOLDED="true" ID="ID_1662138357" CREATED="1717444542487" MODIFIED="1717444548645">
<node TEXT="$ concat divider" ID="ID_1101783268" CREATED="1717444549212" MODIFIED="1717444554145"/>
</node>
<node TEXT="SQL" FOLDED="true" ID="ID_486709957" CREATED="1717444723026" MODIFIED="1717444726196">
<node TEXT="Crop code is 4 CHAR, (trailing space)" ID="ID_1212162815" CREATED="1717444729144" MODIFIED="1717444769199"/>
</node>
<node TEXT="Summary" FOLDED="true" ID="ID_52691862" CREATED="1717444773445" MODIFIED="1717444776659">
<node TEXT="Name = Spirit Names (vs ID names)" ID="ID_544182708" CREATED="1717444831793" MODIFIED="1717444846513"/>
</node>
<node TEXT="Line Pepper" FOLDED="true" ID="ID_172122378" CREATED="1717444878628" MODIFIED="1717444883865">
<node TEXT="Data pull from Spirit Line Table" ID="ID_755416123" CREATED="1717444885616" MODIFIED="1717444937143"/>
</node>
<node TEXT="ASAP" FOLDED="true" ID="ID_371305537" CREATED="1717444588500" MODIFIED="1717444592678">
<node TEXT="create index" ID="ID_63474697" CREATED="1717444594685" MODIFIED="1717444600545"/>
</node>
</node>
</node>
<node TEXT="Varieties" FOLDED="true" ID="ID_174708495" CREATED="1717446110718" MODIFIED="1717446114789">
<node TEXT="reference" FOLDED="true" ID="ID_925903416" CREATED="1717538061966" MODIFIED="1717538065033">
<node TEXT="Spirit" FOLDED="true" ID="ID_593329032" CREATED="1716387020452" MODIFIED="1716387023196">
<node TEXT="Profile" FOLDED="true" ID="ID_77858093" CREATED="1716387023947" MODIFIED="1716387035718">
<node TEXT="MINT .. IM.. VH Varieties" ID="ID_677264525" CREATED="1716387037744" MODIFIED="1716387075170"/>
</node>
<node TEXT="What is a variety /hybrid in spirit vs IM?" ID="ID_96781328" CREATED="1720806937673" MODIFIED="1720806956540">
<icon BUILTIN="yes"/>
</node>
<node TEXT="Variety Number" FOLDED="true" ID="ID_282277003" CREATED="1716388629876" MODIFIED="1716388634304">
<node TEXT="in 2 places" ID="ID_589795323" CREATED="1716388634474" MODIFIED="1716388747625"/>
</node>
<node TEXT="Lines" FOLDED="true" ID="ID_756918018" CREATED="1716387426911" MODIFIED="1716387428951">
<node TEXT="Manually Generated Flag" ID="ID_808664725" CREATED="1716387429488" MODIFIED="1716387441663"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_200062557" CREATED="1717446137578" MODIFIED="1717446137578" LINK="https://syngenta.sharepoint.com/:x:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task/2024_11_January_VH__SPIRITreview.xlsx?d=wbb97227250e3499fb30085bb55715012&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=CwPXq1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task/2024_11_January_VH__SPIRITreview.xlsx?d=wbb97227250e3499fb30085bb55715012&amp;csf=1&amp;web=1&amp;e=CwPXq1">2024_11_January_VH__SPIRITreview.xlsx</a>
  </body>
</html>
</richcontent>
<node TEXT="Identity has to have a batch" FOLDED="true" ID="ID_810293878" CREATED="1717446558882" MODIFIED="1717446614878">
<node TEXT="In Migration" FOLDED="true" ID="ID_1802550515" CREATED="1717446616812" MODIFIED="1717446620287">
<node TEXT="if material record had" ID="ID_1073372178" CREATED="1717446620543" MODIFIED="1717446635154"/>
<node TEXT="SVC = Var" ID="ID_329644166" CREATED="1717446638806" MODIFIED="1717446977797"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="get references" FOLDED="true" ID="ID_272257328" CREATED="1716871158241" MODIFIED="1717084941441">
<node TEXT="2024_Biological_Entity_Discussion.pptx" ID="ID_1587337136" CREATED="1716386778278" MODIFIED="1716386902372">
<font BOLD="true"/>
</node>
<node TEXT="2024_Watermelon_VH_MBEIssue.xlsx" FOLDED="true" ID="ID_1959167635" CREATED="1716387458481" MODIFIED="1716387478459">
<node TEXT="Tracking MBE" ID="ID_407346657" CREATED="1716387515293" MODIFIED="1716387522062"/>
</node>
</node>
<node TEXT="how lines end up with multiple BE" FOLDED="true" ID="ID_1408649453" CREATED="1716416605600" MODIFIED="1718080146323">
<font BOLD="true"/>
<node TEXT="" ID="ID_1184426261" CREATED="1718063381344" MODIFIED="1718063381344"/>
<node TEXT="• Decision on the migration of data from SPIRIT to Identity Management in 2017/2018" FOLDED="true" ID="ID_475619557" CREATED="1716870956386" MODIFIED="1716871034780">
<node TEXT="reference" FOLDED="true" ID="ID_1485955406" CREATED="1716871819739" MODIFIED="1716871828159">
<node ID="ID_646470016" CREATED="1716871833373" MODIFIED="1716871833373" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/_layouts/15/Doc.aspx?sourcedoc=%7B2B51ABC2-EF25-4D98-8138-75E1B93022A7%7D&amp;amp;file=MultipleBEExplanation%20-%20Copy.pptx&amp;amp;action=edit&amp;amp;mobileredirect=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/_layouts/15/Doc.aspx?sourcedoc=%7B2B51ABC2-EF25-4D98-8138-75E1B93022A7%7D&amp;file=MultipleBEExplanation%20-%20Copy.pptx&amp;action=edit&amp;mobileredirect=true">MultipleBEExplanation - Copy.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1980597006" CREATED="1716872005580" MODIFIED="1716872005580" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/Presentations/Identity%20Gap%20Analysis%20Project.pptx?d=wf3703b9e056843cf9abc29452444af32&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=NGi3Hd&amp;amp;nav=eyJzSWQiOjI2OCwiY0lkIjozMjIzNzEyNjd9"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/Presentations/Identity%20Gap%20Analysis%20Project.pptx?d=wf3703b9e056843cf9abc29452444af32&amp;csf=1&amp;web=1&amp;e=NGi3Hd&amp;nav=eyJzSWQiOjI2OCwiY0lkIjozMjIzNzEyNjd9">Identity Gap Analysis Project.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="preserve relationships from Spirit and have multiple BEs" FOLDED="true" ID="ID_262901420" CREATED="1716416969603" MODIFIED="1716872121862">
<font BOLD="true"/>
<node TEXT="A question was posed during migration of data from SPIRIT to MINT in Feb 2017:​" FOLDED="true" ID="ID_69251967" CREATED="1716871782999" MODIFIED="1716871782999">
<node TEXT="Forfeit relationships and have single BEs​" ID="ID_1166759573" CREATED="1716871782999" MODIFIED="1716871782999"/>
<node TEXT="Preserve relationships and have multiple BEs​" ID="ID_549145544" CREATED="1716871783004" MODIFIED="1716871783004"/>
</node>
<node TEXT="A decision was made by the Identity BPOC to preserve relationships and have Multiple BE’s" ID="ID_1282218650" CREATED="1716871783006" MODIFIED="1716871783006"/>
</node>
</node>
<node TEXT="Same Line In Different Generations" FOLDED="true" ID="ID_1898749700" CREATED="1716416780207" MODIFIED="1716416786029">
<node TEXT="png-240522-152408684-15505295557342039702.png" ID="ID_323593953" CREATED="1716416650635" MODIFIED="1716416687082" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/MINT%20MBE%20Resolution%20Kickoff%20-%20Tomato.pptx?d=w313314a8aacc4c2682cbf2e57e3e66b7&amp;csf=1&amp;web=1&amp;e=6TgDfd&amp;nav=eyJzSWQiOjI2MSwiY0lkIjoxOTYwNDQ5NTcxfQ">
<hook URI="DataStewardshipAnalyst_files/png-240522-152408684-15505295557342039702.png" SIZE="0.37220845" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="CMS /Maintainer Lines" FOLDED="true" ID="ID_691041826" CREATED="1716416790035" MODIFIED="1716416855249" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/MINT%20MBE%20Resolution%20Kickoff%20-%20Tomato.pptx?d=w313314a8aacc4c2682cbf2e57e3e66b7&amp;csf=1&amp;web=1&amp;e=Th1qKx&amp;nav=eyJzSWQiOjI2NSwiY0lkIjoyMjI1MzQxODA0fQ">
<node TEXT="CMS/Maintainer pairs are not systematically identifiable in the source system (SPIRIT)​" ID="ID_342750978" CREATED="1716416825853" MODIFIED="1716416825853"/>
<node TEXT="Source System (SPIRIT) does not have the concept of a BE. This forces pairs of  CMS/Maintainer to be identified in MINT post migration​" ID="ID_1786702686" CREATED="1716416825863" MODIFIED="1716416825863"/>
<node TEXT="At this point a SL BE representing CMS  Stable Line Code 123 already exists​" ID="ID_1406902311" CREATED="1716416825873" MODIFIED="1716416825873"/>
<node TEXT="A cross operation then occurs in the migration which results in a NEW BE.  ​" ID="ID_1547054781" CREATED="1716416825877" MODIFIED="1716416825877"/>
<node TEXT="Since the Progeny has a stable line in the migration it is marked as stable and coded with the line given​" ID="ID_1712828479" CREATED="1716416825879" MODIFIED="1716416825879"/>
<node TEXT="Result:  2 BE’s with the same stable line code (ex. Stable Line Code 123)​" ID="ID_1353643406" CREATED="1716416825888" MODIFIED="1716416825888"/>
</node>
<node TEXT="• BE not stabilized at the correct time in development" ID="ID_1024079353" CREATED="1716870956384" MODIFIED="1716870956384"/>
<node TEXT="• Manually Added Batches not correctly assigned the correct BE" ID="ID_875516056" CREATED="1716870956385" MODIFIED="1716870956385"/>
<node TEXT="• Incorrect information assigned in SPIRIT" FOLDED="true" ID="ID_1274719821" CREATED="1716870956385" MODIFIED="1716870956385">
<node TEXT="- Wrong Line Code assigned to a SPIRIT material record" ID="ID_1892173623" CREATED="1716870956385" MODIFIED="1716870956385"/>
<node TEXT="- Parent information in SPIRIT was incorrect for the expected line" ID="ID_1519293086" CREATED="1716870956386" MODIFIED="1716870956386"/>
</node>
<node TEXT="Variety /Hybrid Records, Stable Variety Code" FOLDED="true" ID="ID_400525641" CREATED="1718080052391" MODIFIED="1718080118350">
<font BOLD="true"/>
<node TEXT="Not all variety/hybrids in SPIRIT will be assigned a Stable Variety Code" FOLDED="true" ID="ID_865910132" CREATED="1718080072942" MODIFIED="1718080072942">
<node TEXT="No material ids/batches exist for the variety record" ID="ID_1763882610" CREATED="1718080072942" MODIFIED="1718080072942"/>
<node TEXT="Variety Name exists for multiple BE BID and not migrated in June 2023" ID="ID_618601487" CREATED="1718080072943" MODIFIED="1718080072943"/>
</node>
<node TEXT="Stable Variety Code is assigned to several Variety records" ID="ID_470697690" CREATED="1718080072945" MODIFIED="1718080072945"/>
<node TEXT="Variety Records in SPIRIT have multiple variety number" FOLDED="true" ID="ID_310521887" CREATED="1718080072946" MODIFIED="1718080072946">
<node TEXT="Created prior to migration" ID="ID_1816164398" CREATED="1718080072947" MODIFIED="1718080072947"/>
</node>
</node>
<node TEXT="Scenarios" FOLDED="true" ID="ID_1677756188" CREATED="1717096030100" MODIFIED="1717096034512">
<node ID="ID_219441470" CREATED="1717096035601" MODIFIED="1717096035601" LINK="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Archived%20folders/MINT%20MBE%20issue%20documentation/MBE%20issue%20-%20Scenarios.xlsx?d=wd28e9f289a6e40c48def5a85a4c48a78&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=qteeBg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Archived%20folders/MINT%20MBE%20issue%20documentation/MBE%20issue%20-%20Scenarios.xlsx?d=wd28e9f289a6e40c48def5a85a4c48a78&amp;csf=1&amp;web=1&amp;e=qteeBg">MBE issue - Scenarios.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Purpose of Cleanup" FOLDED="true" ID="ID_762186699" CREATED="1716871547392" MODIFIED="1716871587004">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_177909570" CREATED="1716871594203" MODIFIED="1716871596425">
<node ID="ID_1834597036" CONTENT_ID="ID_1587337136"/>
</node>
<node TEXT="In Identity Management, each physical material is assigned to a batch, biological entity and lineage-based group." ID="ID_1561940335" CREATED="1716871547392" MODIFIED="1716871547392"/>
<node TEXT="Biological Entity Business Identifier (BE BID) is a primary indicator of the germplasm background." ID="ID_1542116123" CREATED="1716871547392" MODIFIED="1716871547392"/>
</node>
</node>
<node TEXT="Tasks" FOLDED="true" POSITION="bottom_or_right" ID="ID_1040425489" CREATED="1739385166025" MODIFIED="1739753708986">
<node TEXT="Quartly High Level Cross Crop MBE Update" FOLDED="true" ID="ID_494101793" CREATED="1718813017331" MODIFIED="1739753863063">
<icon BUILTIN="bookmark"/>
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_1295222821" CREATED="1720804359828" MODIFIED="1720804362193">
<node ID="ID_1618255624" CREATED="1720804363094" MODIFIED="1720804363094" LINK="https://syngenta.sharepoint.com/:f:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Quarterly%20MBE%20Update%20Veg?csf=1&amp;amp;web=1&amp;amp;e=tkhNMV"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Quarterly%20MBE%20Update%20Veg?csf=1&amp;web=1&amp;e=tkhNMV">Quarterly MBE Update Veg</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="was ran by" FOLDED="true" ID="ID_1548640473" CREATED="1719443724281" MODIFIED="1719443730118">
<node TEXT="Marie-Aude Somville" FOLDED="true" ID="ID_1090012634" CREATED="1712331524197" MODIFIED="1713132342977">
<node TEXT="info" FOLDED="true" ID="ID_1684723252" CREATED="1720478064699" MODIFIED="1720478066803">
<node TEXT="Pronunciation (French): Mah-ree Aud (like Aud-ee)" ID="ID_1966496053" CREATED="1713133443289" MODIFIED="1713133742488"/>
<node TEXT="no breeding background" ID="ID_1709065880" CREATED="1715613571081" MODIFIED="1715613604111"/>
<node TEXT="Working together on:" FOLDED="true" ID="ID_962153682" CREATED="1715612997685" MODIFIED="1715615512037">
<node TEXT="MINT" FOLDED="true" ID="ID_593315971" CREATED="1715613027031" MODIFIED="1715615586497">
<node TEXT="ID Management" FOLDED="true" ID="ID_22481248" CREATED="1715613036900" MODIFIED="1715615594264">
<node TEXT="authorizatation management" FOLDED="true" ID="ID_1815961243" CREATED="1715613215032" MODIFIED="1715615010254">
<icon BUILTIN="unchecked"/>
<node TEXT="shift to local teams" FOLDED="true" ID="ID_289985125" CREATED="1715613242260" MODIFIED="1715613259964">
<node TEXT="train" ID="ID_329660836" CREATED="1715615055788" MODIFIED="1715615057980"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Global Project Lead for Vegetables" ID="ID_544294901" CREATED="1713133311496" MODIFIED="1713133321521"/>
<node TEXT="Location: France?" ID="ID_1266636964" CREATED="1713133342960" MODIFIED="1713133361441"/>
<node TEXT="Most challenging part of this role" FOLDED="true" ID="ID_1441941811" CREATED="1713132036314" MODIFIED="1713132045528">
<node TEXT="management of req, prioritization" FOLDED="true" ID="ID_1186863893" CREATED="1712330930307" MODIFIED="1712330964535">
<node TEXT="stay focused" ID="ID_69076925" CREATED="1712330978318" MODIFIED="1712330982765"/>
<node TEXT="push back" FOLDED="true" ID="ID_799495607" CREATED="1712331003293" MODIFIED="1712331012845">
<node TEXT="otherwise get overloaded with requests" ID="ID_1334307869" CREATED="1712332072200" MODIFIED="1712332082597"/>
<node TEXT="don&apos;t get the coffee" ID="ID_1518032914" CREATED="1712332179394" MODIFIED="1712332184350"/>
</node>
</node>
</node>
<node TEXT="project manager MINT veg" FOLDED="true" ID="ID_1469909171" CREATED="1715613004811" MODIFIED="1715615501940">
<node TEXT="representative for Material Management" FOLDED="true" ID="ID_1344370561" CREATED="1715613044839" MODIFIED="1715615545202">
<node TEXT="managed ny benjamin" ID="ID_748030573" CREATED="1715613049877" MODIFIED="1715613057399"/>
</node>
</node>
<node TEXT="Somville Marie-Aude FRSS marie-aude.somville@syngenta.com" ID="ID_1833454613" CREATED="1716186377442" MODIFIED="1716186377442" LINK="mailto:marie-aude.somville@syngenta.com"/>
<node TEXT="Vacation" FOLDED="true" ID="ID_985163255" CREATED="1719248137699" MODIFIED="1719248140094">
<node TEXT="7/4-7/29" ID="ID_1799732326" CREATED="1719248141734" MODIFIED="1719444076527"/>
</node>
</node>
<node TEXT="MINT Authorization" ID="ID_799257618" CREATED="1718376141856" MODIFIED="1718376255337"/>
<node TEXT="Meetings" FOLDED="true" ID="ID_1864885996" CREATED="1719244423804" MODIFIED="1719244426338">
<node TEXT="6/24/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-06-24T03:00-0400|date" ID="ID_1076220124" CREATED="1719244427672" MODIFIED="1719244430457"/>
</node>
</node>
<node TEXT="wants to schedule for September" FOLDED="true" ID="ID_23613990" CREATED="1719444128852" MODIFIED="1719444141293">
<node TEXT="show progress first" ID="ID_539142152" CREATED="1719444147193" MODIFIED="1719444150062"/>
</node>
</node>
<node TEXT="Aparna" FOLDED="true" ID="ID_107100276" CREATED="1719245250290" MODIFIED="1719245254955">
<node TEXT="updating KPI" ID="ID_1811884828" CREATED="1719245255139" MODIFIED="1719245259851"/>
</node>
<node TEXT="check to see how last presentation was run" FOLDED="true" ID="ID_181676330" CREATED="1718926939497" MODIFIED="1718926948947">
<node TEXT="text" FOLDED="true" ID="ID_1521256150" CREATED="1719349211149" MODIFIED="1719349214104">
<node TEXT="Dear All,&#xa;&#xa; &#xa;&#xa;Here&apos;s a placeholder to share the status of the MBE clean Up project gather feedback, and share what worked well.&#xa;&#xa; &#xa;&#xa;Thank you in advance for your joining,&#xa;&#xa; &#xa;&#xa;Have a great day,&#xa;&#xa; &#xa;&#xa;Marie-Aude" ID="ID_1087094263" CREATED="1719349235407" MODIFIED="1719356670045"/>
<node TEXT="" ID="ID_429216299" CREATED="1719362095689" MODIFIED="1719362095689"/>
</node>
</node>
<node TEXT="Schedule" FOLDED="true" ID="ID_1087320689" CREATED="1718903827544" MODIFIED="1718991101253">
<node TEXT="Next" ID="ID_925461297" CREATED="1737399389625" MODIFIED="1737399441133">
<attribute NAME="Due" VALUE="2/1/25" OBJECT="org.freeplane.features.format.FormattedDate|2025-02-01T00:00-0500|M/d/yy"/>
</node>
<node TEXT="attendees" FOLDED="true" ID="ID_1890446112" CREATED="1718991185421" MODIFIED="1718991187980">
<node TEXT="see grouping in Outlook" ID="ID_133893544" CREATED="1718991190554" MODIFIED="1719444168692"/>
</node>
<node TEXT="time allocation:" FOLDED="true" ID="ID_1947488786" CREATED="1718922000725" MODIFIED="1718922005936">
<node TEXT="1h" FOLDED="true" ID="ID_769403582" CREATED="1718922007130" MODIFIED="1718991138770">
<node TEXT="MBE Update Veg" ID="ID_1678051479" CREATED="1718991153622" MODIFIED="1718991163405"/>
</node>
</node>
<node TEXT="date" FOLDED="true" ID="ID_928199408" CREATED="1718924946987" MODIFIED="1718924948879">
<node TEXT="schedule in advance, Reserve Slot" ID="ID_1638248557" CREATED="1719244458574" MODIFIED="1719244500374"/>
</node>
<node TEXT="time" FOLDED="true" ID="ID_680698101" CREATED="1718924940240" MODIFIED="1718924945341">
<node TEXT="Earliest (start time) 5am" ID="ID_1571758653" CREATED="1719505944905" MODIFIED="1719508541181"/>
<node TEXT="Latest (end time): 10pm" ID="ID_357314509" CREATED="1719505947151" MODIFIED="1719508553726"/>
<node TEXT="12p" FOLDED="true" ID="ID_1511699442" CREATED="1718991148460" MODIFIED="1718991152121">
<node TEXT="MBE Update Veg" ID="ID_1065125409" CREATED="1718991153622" MODIFIED="1718991163405"/>
</node>
</node>
<node TEXT="Options" FOLDED="true" ID="ID_1944674053" CREATED="1719519455579" MODIFIED="1719519458606">
<node ID="ID_1583631948" CREATED="1719519459777" MODIFIED="1719519459777" LINK="https://outlook.office.com/bookings/homepage"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://outlook.office.com/bookings/homepage">Bookings - McMillen Michael USRE - Outlook</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Title" FOLDED="true" ID="ID_574066061" CREATED="1719515618064" MODIFIED="1719515621606">
<node TEXT="{Crop} {Purpose} Meeting - {Platform}" FOLDED="true" ID="ID_1603368068" CREATED="1719515622238" MODIFIED="1719515670876">
<node TEXT="Platform" FOLDED="true" ID="ID_1236581485" CREATED="1719515671922" MODIFIED="1719515681348">
<node TEXT="Zoom" ID="ID_783623084" CREATED="1719515682325" MODIFIED="1719515684308"/>
<node TEXT="Teams" ID="ID_38855085" CREATED="1719515684695" MODIFIED="1719515687553"/>
</node>
</node>
</node>
</node>
<node TEXT="update presentation" FOLDED="true" ID="ID_1662442903" CREATED="1718903833436" MODIFIED="1718903836142">
<node FOLDED="true" ID="ID_789628824" CREATED="1718903877365" MODIFIED="1718903877365" LINK="https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;amp;web=1&amp;amp;e=b0jYx2&amp;amp;CID=99edbc00%2D1741%2D410a%2D9b57%2D8bf6894e99fd&amp;amp;FolderCTID=0x0120007E8FE8CA1B3FCD44AC7FAEB60DEB1D5E&amp;amp;id=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2FMBE%20cleanup"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/Forms/AllItems.aspx?csf=1&amp;web=1&amp;e=b0jYx2&amp;CID=99edbc00%2D1741%2D410a%2D9b57%2D8bf6894e99fd&amp;FolderCTID=0x0120007E8FE8CA1B3FCD44AC7FAEB60DEB1D5E&amp;id=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2FMBE%20cleanup">Applied Data Science V&amp;F - MBE cleanup - All Documents</a>
  </body>
</html>
</richcontent>
<node TEXT="make a copy for next update" FOLDED="true" ID="ID_758758514" CREATED="1718903884792" MODIFIED="1718903901621">
<node ID="ID_1038143854" CREATED="1718903807169" MODIFIED="1718903807169" LINK="https://syngenta.sharepoint.com/:p:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Veg%20MBE%20CleanUpFollowUp%20July%202024.pptx?d=wee334d5f84b54191a44cc10553f4559c&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=gb0R70"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Veg%20MBE%20CleanUpFollowUp%20July%202024.pptx?d=wee334d5f84b54191a44cc10553f4559c&amp;csf=1&amp;web=1&amp;e=gb0R70">Veg MBE CleanUpFollowUp July 2024.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="update:" FOLDED="true" ID="ID_1980403210" CREATED="1718903904787" MODIFIED="1718903907778">
<node TEXT="KPIs" LOCALIZED_STYLE_REF="AutomaticLayout.level,1" FOLDED="true" ID="ID_1726625690" CREATED="1716417117717" MODIFIED="1739385220270">
<font NAME="Segoe UI Black"/>
<node TEXT="New KPI" ID="ID_1295678317" CREATED="1730829795869" MODIFIED="1730829821393">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="reports" FOLDED="true" ID="ID_1249155642" CREATED="1720665017090" MODIFIED="1720665021210">
<node TEXT="Generated by?" ID="ID_79733480" CREATED="1720665023056" MODIFIED="1720665029727"/>
<node TEXT="Goal: KPI to be updated monthly" FOLDED="true" ID="ID_206468509" CREATED="1720665032569" MODIFIED="1721055020346">
<icon BUILTIN="yes"/>
<attribute NAME="When" VALUE="7/10/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-07-10T00:00-0400|date"/>
<node TEXT="should be simple if using SQL query" ID="ID_1768050153" CREATED="1720665060005" MODIFIED="1720665074724"/>
</node>
</node>
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\MBE\mbe_kpi_for_veg_crops.xlsx" FOLDED="true" ID="ID_790142568" CREATED="1716510737468" MODIFIED="1716510744737" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/MBE/mbe_kpi_for_veg_crops.xlsx">
<node ID="ID_736496220" CREATED="1716510235708" MODIFIED="1716510235708" LINK="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/mbe_kpi_for_veg_crops.xlsx?d=w9cfa5c9f172946acbe44af3a5b8f47fc&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=5vNLkQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/mbe_kpi_for_veg_crops.xlsx?d=w9cfa5c9f172946acbe44af3a5b8f47fc&amp;csf=1&amp;web=1&amp;e=5vNLkQ">mbe_kpi_for_veg_crops.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Line" FOLDED="true" ID="ID_698994150" CREATED="1719443516291" MODIFIED="1719443518633">
<node ID="ID_689608680" CREATED="1716510064570" MODIFIED="1716510064570" LINK="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/MBE%20KPIs.xlsx?d=weffb998def8c4f289e097541b597387f&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=BPlu3g"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/MBE%20KPIs.xlsx?d=weffb998def8c4f289e097541b597387f&amp;csf=1&amp;web=1&amp;e=BPlu3g">MBE KPIs.xlsx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1713139331" CREATED="1716510230005" MODIFIED="1716510230005" LINK="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/mbe_kpi_for_veg_crops.xlsx?d=w9cfa5c9f172946acbe44af3a5b8f47fc&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=5vNLkQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/mbe_kpi_for_veg_crops.xlsx?d=w9cfa5c9f172946acbe44af3a5b8f47fc&amp;csf=1&amp;web=1&amp;e=5vNLkQ">mbe_kpi_for_veg_crops.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Variety" FOLDED="true" ID="ID_1057213635" CREATED="1719443545633" MODIFIED="1719443548652">
<node TEXT="Michele?" ID="ID_1732163526" CREATED="1719443549597" MODIFIED="1719443552818"/>
<node TEXT="Develop SQL Query based on F1s, see if all have same BE BID" FOLDED="true" ID="ID_475536648" CREATED="1720664904008" MODIFIED="1721055020347">
<icon BUILTIN="yes"/>
<attribute NAME="When" VALUE="7/11/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-07-11T00:00-0400|date"/>
<node TEXT="count BE BID" ID="ID_1471466774" CREATED="1720664956197" MODIFIED="1720664960554"/>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1243899754" CREATED="1718909701567" MODIFIED="1718909705221">
<node ID="ID_1638996376" CREATED="1718909725645" MODIFIED="1718909725645" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/_layouts/15/Doc.aspx?sourcedoc=%7B313314A8-AACC-4C26-82CB-F2E57E3E66B7%7D&amp;amp;file=MINT%20MBE%20Resolution%20Kickoff%20-%20Tomato.pptx&amp;amp;action=edit&amp;amp;mobileredirect=true&amp;amp;wdsle=0"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/_layouts/15/Doc.aspx?sourcedoc=%7B313314A8-AACC-4C26-82CB-F2E57E3E66B7%7D&amp;file=MINT%20MBE%20Resolution%20Kickoff%20-%20Tomato.pptx&amp;action=edit&amp;mobileredirect=true&amp;wdsle=0">MINT MBE Resolution Kickoff - Tomato.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="KPI 1 Frequency of MBE Line codes by year (Measure of uniqueness)​" ID="ID_1812462462" CREATED="1718909714256" MODIFIED="1718909714256"/>
<node TEXT="KPI 2. Frequency of MBE Batch Creation by Year (Operational Impact)" ID="ID_1696504647" CREATED="1718909714258" MODIFIED="1718909714258"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1490029294" TREE_ID="ID_1726625690">
<node ID="ID_902731270" TREE_ID="ID_1295678317"/>
<node ID="ID_1033046276" TREE_ID="ID_1249155642">
<node ID="ID_915136283" TREE_ID="ID_79733480"/>
<node ID="ID_1832747532" TREE_ID="ID_206468509">
<node ID="ID_664899870" TREE_ID="ID_1768050153"/>
</node>
</node>
<node ID="ID_1883443593" TREE_ID="ID_790142568">
<node ID="ID_283925603" TREE_ID="ID_736496220"/>
</node>
<node ID="ID_320926116" TREE_ID="ID_698994150">
<node ID="ID_1512502330" TREE_ID="ID_689608680"/>
<node ID="ID_652780820" TREE_ID="ID_1713139331"/>
</node>
<node ID="ID_1372762730" TREE_ID="ID_1057213635">
<node ID="ID_436455648" TREE_ID="ID_1732163526"/>
<node ID="ID_1620500079" TREE_ID="ID_475536648">
<node ID="ID_333856976" TREE_ID="ID_1471466774"/>
</node>
</node>
<node ID="ID_529295772" TREE_ID="ID_1243899754">
<node ID="ID_330458160" TREE_ID="ID_1638996376"/>
<node ID="ID_1847475902" TREE_ID="ID_1812462462"/>
<node ID="ID_1680726541" TREE_ID="ID_1696504647"/>
</node>
</node>
<node TEXT="Primary Management File" FOLDED="true" ID="ID_915190982" CREATED="1719414684474" MODIFIED="1719414691479">
<node ID="ID_1215247997" CREATED="1737399641735" MODIFIED="1737399641735" LINK="https://syngenta.sharepoint.com/:x:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/Projects/MBE%20cleanup/MBE%20Clean%20Up%20Management.xlsx?d=w66f7ad288d044cca8c92e50b0daccac0&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=uEefFB"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/Projects/MBE%20cleanup/MBE%20Clean%20Up%20Management.xlsx?d=w66f7ad288d044cca8c92e50b0daccac0&amp;csf=1&amp;web=1&amp;e=uEefFB">MBE Clean Up Management.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Crops" LOCALIZED_STYLE_REF="AutomaticLayout.level,2" FOLDED="true" ID="ID_370640114" CREATED="1739384752156" MODIFIED="1739384778394">
<font BOLD="true"/>
<node TEXT="All" POSITION="bottom_or_right" ID="ID_1130267107" CREATED="1739385352807" MODIFIED="1739385383987" LINK="file:/C:/Users/u581917/Syngenta/MINT%20Identity%20Gap%20Analysis%20&amp;%20Resolution%20-%20MBE%20Clean%20up/"/>
<node TEXT="Broccoli" FOLDED="true" POSITION="bottom_or_right" ID="ID_1778360976" CREATED="1739384807099" MODIFIED="1739388754283" LINK="file:/C:/Users/u581917/Syngenta/MINT%20Identity%20Gap%20Analysis%20&amp;%20Resolution%20-%20MBE%20Clean%20up/Broccoli">
<node TEXT="Tickets" FOLDED="true" ID="ID_1705238931" CREATED="1739386714654" MODIFIED="1739386718521">
<node TEXT="INC18996018\updated_Broccoli Crop IM changes_11-Feb-25.xlsx&quot;" ID="ID_1141854625" CREATED="1739388839227" MODIFIED="1739388878521" LINK="file:/C:/Users/u581917/Syngenta/MINT%20Identity%20Gap%20Analysis%20&amp;%20Resolution%20-%20MBE%20Clean%20up/Broccoli/Tickets/INC18996018/incident_8724b435c36c16146048534ed40131ca_attachments/updated_Broccoli%20Crop%20IM%20changes_11-Feb-25.xlsx"/>
</node>
</node>
<node TEXT="Sweetcorn" FOLDED="true" POSITION="bottom_or_right" ID="ID_139133939" CREATED="1739385289831" MODIFIED="1739386752605" LINK="file:/C:/Users/u581917/Syngenta/MINT%20Identity%20Gap%20Analysis%20&amp;%20Resolution%20-%20MBE%20Clean%20up/Sweet%20Corn/SWC%20MBE%20Line%20and%20VH%20Tracker%2024-Sept-24.xlsx">
<node TEXT="Email" FOLDED="true" ID="ID_110367319" CREATED="1739385293414" MODIFIED="1739385318473">
<node TEXT="Veg MBE Cleanup, Priority Lines" ID="ID_181410077" CREATED="1739385319568" MODIFIED="1739385323263"/>
</node>
<node TEXT="#Ryan" FOLDED="true" ID="ID_421891300" CREATED="1739586968569" MODIFIED="1739587045403">
<node TEXT="Fix Selfs with MP" FOLDED="true" ID="ID_1904347377" CREATED="1739572215527" MODIFIED="1739572231024">
<node ID="ID_208760073" CREATED="1739574141690" MODIFIED="1739574141690" LINK="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/Sweet%20Corn/Materials/SWC%20Materials%20OP%20w%20Line.xlsx?d=wc7cfd00a370c40168363e0368934734c&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=xxEHnR&amp;amp;nav=MTVfezczMDQ2RDUyLTFDM0MtNEIzNi05REFFLUREMDBCOEU4RjYzQn0"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/Sweet%20Corn/Materials/SWC%20Materials%20OP%20w%20Line.xlsx?d=wc7cfd00a370c40168363e0368934734c&amp;csf=1&amp;web=1&amp;e=xxEHnR&amp;nav=MTVfezczMDQ2RDUyLTFDM0MtNEIzNi05REFFLUREMDBCOEU4RjYzQn0">SWC Materials OP w Line.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="#Do" FOLDED="true" ID="ID_1091931019" CREATED="1739386725306" MODIFIED="1739386834562">
<node TEXT="Submit Ticket" ID="ID_1228513810" CREATED="1739572231769" MODIFIED="1739572236156"/>
</node>
</node>
</node>
</node>
<node TEXT="Prevention" FOLDED="true" POSITION="bottom_or_right" ID="ID_1357766553" CREATED="1716872571507" MODIFIED="1716872575422">
<font BOLD="true"/>
<node ID="ID_788309612" CREATED="1716872576764" MODIFIED="1716872576764" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/LT%20Update%20preparation/LT%20Update%20-%20Sept%2030/MINT%20LT%20Update%20-%20Preread.pptx?d=wc3be642588624029821215f327ed4462&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=djqZtk&amp;amp;nav=eyJzSWQiOjI5NiwiY0lkIjozOTkyNDU2OTIzfQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/LT%20Update%20preparation/LT%20Update%20-%20Sept%2030/MINT%20LT%20Update%20-%20Preread.pptx?d=wc3be642588624029821215f327ed4462&amp;csf=1&amp;web=1&amp;e=djqZtk&amp;nav=eyJzSWQiOjI5NiwiY0lkIjozOTkyNDU2OTIzfQ">MINT LT Update - Preread.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Notes" FOLDED="true" POSITION="bottom_or_right" ID="ID_1129945756" CREATED="1718035464534" MODIFIED="1718035551849">
<node TEXT="Tickets by July" ID="ID_1592678049" CREATED="1718035592283" MODIFIED="1718036280666">
<font BOLD="true"/>
</node>
<node TEXT="When can I launch crop?" ID="ID_1668918675" CREATED="1718036282678" MODIFIED="1718036299439"/>
</node>
<node TEXT="MBE resolution" FOLDED="true" POSITION="bottom_or_right" ID="ID_741790450" CREATED="1716417064814" MODIFIED="1720491379699">
<font SIZE="16" BOLD="true"/>
<node TEXT="reference" FOLDED="true" POSITION="bottom_or_right" ID="ID_441111747" CREATED="1716870123113" MODIFIED="1716870125091">
<node ID="ID_1239255670" CREATED="1717090325547" MODIFIED="1717090325547" LINK="https://syngenta.sharepoint.com/:p:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/MINT%20MBE%20Resolution_1.25.23.pptx?d=w48666ceb58c34c24b7158c4c749637a6&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=ZP6lZG&amp;amp;nav=eyJzSWQiOjI5NywiY0lkIjo0MjMzODE3NzE2fQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/MINT%20MBE%20Resolution_1.25.23.pptx?d=w48666ceb58c34c24b7158c4c749637a6&amp;csf=1&amp;web=1&amp;e=ZP6lZG&amp;nav=eyJzSWQiOjI5NywiY0lkIjo0MjMzODE3NzE2fQ">MINT MBE Resolution_1.25.23.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1400433292" CREATED="1718925672994" MODIFIED="1718925672994" LINK="https://syngenta.sharepoint.com/:f:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/LT%20Update%20preparation/LT%20Update%20-%20Sept%2030?csf=1&amp;amp;web=1&amp;amp;e=ejo1qL"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/LT%20Update%20preparation/LT%20Update%20-%20Sept%2030?csf=1&amp;web=1&amp;e=ejo1qL">LT Update - Sept 30</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Cleanup process (Eleni)" FOLDED="true" ID="ID_211451090" CREATED="1716489211702" MODIFIED="1716870135643">
<node TEXT="reference" FOLDED="true" ID="ID_530385201" CREATED="1716489437368" MODIFIED="1716489439927">
<node TEXT="png-240523-113902386-6439229182710240510.png" ID="ID_1350846327" CREATED="1716489544397" MODIFIED="1716489571173" LINK="https://syngenta.sharepoint.com/:x:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Follow%20Up%20MBE%20Clean%20Up%20Onbaording%20MMcM%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20.xlsx?d=w66f7ad288d044cca8c92e50b0daccac0&amp;csf=1&amp;web=1&amp;e=2vg9li">
<hook URI="DataStewardshipAnalyst_files/png-240523-113902386-6439229182710240510.png" SIZE="0.35671818" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Understand the MBE Clean Up" ID="ID_79235655" CREATED="1716489293806" MODIFIED="1716489293806"/>
<node TEXT="Prepare userguide to share instructions with Melon &amp; Squash to launch the MBE Line Clean Up" FOLDED="true" ID="ID_588124249" CREATED="1716489293806" MODIFIED="1716489293806">
<node TEXT="Meet with SMEs to Explain" ID="ID_372715237" CREATED="1716489219919" MODIFIED="1716491237720" LINK="freeplane:/%20/C:/GitHub/MindMaps/DataStewardshipAnalyst.mm#ID_1118690362"/>
</node>
<node TEXT="Prepare userguide to share instructions for Watermelon &amp; Tomato to launch the MBE Clean Up" ID="ID_492682643" CREATED="1716489293810" MODIFIED="1716489293810"/>
<node TEXT="Coordinate first incidents to solve MBE Clean Up" ID="ID_770048968" CREATED="1716489293813" MODIFIED="1716489293813"/>
<node TEXT="Build targets by crop (Worklard, Crops cycle, KPI results)" ID="ID_877354798" CREATED="1716489293816" MODIFIED="1716489293816"/>
<node TEXT="Follow Up MBE Clean Up to finlaize MBE Clean Up Line + Hybrid" ID="ID_1819306437" CREATED="1716489293817" MODIFIED="1716489293817"/>
</node>
<node TEXT="Defining SBE" FOLDED="true" ID="ID_1386950334" CREATED="1716780029334" MODIFIED="1716780039125">
<node TEXT="For each linecode, there exists only one unique BEBID" FOLDED="true" ID="ID_162454548" CREATED="1716780043147" MODIFIED="1716780080927">
<node TEXT="Each BEBID is associated with only one Line code" ID="ID_945260664" CREATED="1716780085447" MODIFIED="1716780105947"/>
</node>
</node>
<node TEXT="Previous process" FOLDED="true" ID="ID_1194745404" CREATED="1737399188872" MODIFIED="1737399218218">
<icon BUILTIN="button_cancel"/>
<node TEXT="Request Updated pull of Multiple BE for vegetable crops" FOLDED="true" ID="ID_1665457409" CREATED="1720480433971" MODIFIED="1720480473194">
<font BOLD="true"/>
<node TEXT="MINT- Identity Management - Incident - Updated pull of Multiple BE for vegetable crops - LIne and Stable Variety Code by 6/30" FOLDED="true" ID="ID_1204210680" CREATED="1716869182483" MODIFIED="1716869226918">
<node TEXT="Create MINT Identity Management - Incident - Updated pull of Multiple BE for vegetable crops - LIne and Stable Variety Code&#xa;MINT SUPPORT USRE&#xa;​+1 other&#xa;​&#xa;​&#xa;Gardiner Michele USNM;&#xa;​&#xa;McMillen Michael USRE;&#xa;​&#xa;Peddireddy Vijaya Bhaskar Reddy USRE;&#xa;​&#xa;Danthuluri Pavan Kumar USRE;&#xa;​&#xa;Kosuri Rao USRE;&#xa;​&#xa;Rachko Siarhei (ext) USRE&#xa;​&#xa;Hi Help Desk Agent,&#xa;&#xa;Please initiate a help desk ticket for the following incident and dispatch it to SYN-GLOB-RDIT-IDENTITY-SUPPORT Group as stated below.&#xa;&#xa;Submitter user login: Gardimi1 &#xa;Submitter Email Address: Michele.Gardiner@syngenta.com &#xa;Submitter Name: Michele Gardiner &#xa;Request Title: MINT- Identity Management - Incident - Updated pull of Multiple BE for vegetable crops - LIne and Stable Variety Code &#xa;Description: In planning time allocation for the SME of the vegetable crops for aligning BE BID to Line and Variety information, would it be possible to provide the list of Stable LIne Code with multiple BE BID assigned. Please identity the year of the first and last batch. It is also requested to have an initial list of Stable Variety code with multiple BE for this planning session. Vegetable crops are Broccoli, Brussels Sprouts, Cabbage, Cauliflower, Chinese Cabbage, Cucumber, Endive, Lettuce, Spinach, Melon, Bush Bean, Pea, Snap Pea, Okra, Sweet Corn, Tomato, Peppers, Melon, Squash and Watermelon. Michael McMillen will be leading the task for MBE Clean up in vegetable.  The previous request (INC1697999) worked well.  If the data pull could be completed by June 30th would be appreciated.  &#xa;Number of Users Impacted: 51-100 &#xa;Priority: P3 &#xa;Crop: Broccoli&#xa;&#xa;Please include the below list of users when ticket is created. &#xa;MIchael.McMillen@syngenta.com" ID="ID_1962113201" CREATED="1716869106915" MODIFIED="1716869114698"/>
</node>
</node>
</node>
</node>
<node TEXT="Get Material Actions from Breeders" FOLDED="true" POSITION="bottom_or_right" ID="ID_214722856" CREATED="1737399262804" MODIFIED="1737399284733">
<node TEXT="Located Here: C:\Users\u581917\Syngenta\MINT Identity Gap Analysis &amp; Resolution - MBE Clean up" ID="ID_897173080" CREATED="1737399757257" MODIFIED="1737399845898" LINK="file:/C:/Users/u581917/Syngenta/MINT%20Identity%20Gap%20Analysis%20&amp;%20Resolution%20-%20MBE%20Clean%20up"/>
<node TEXT="For Each Crop" FOLDED="true" ID="ID_1501269749" CREATED="1720478216265" MODIFIED="1720478238865">
<font BOLD="true"/>
<node TEXT="Setup Crop in Spirit" FOLDED="true" ID="ID_1859340245" CREATED="1717448339547" MODIFIED="1717448346212">
<node TEXT="Add MBE Traits" FOLDED="true" ID="ID_1496675336" CREATED="1719372814528" MODIFIED="1719372834188">
<node TEXT="Need" FOLDED="true" ID="ID_705473371" CREATED="1719372818502" MODIFIED="1719372820975">
<node TEXT="broccoli" ID="ID_546799376" CREATED="1719456015590" MODIFIED="1719456017310"/>
<node TEXT="Spinach" ID="ID_1213983188" CREATED="1719372821227" MODIFIED="1719372824306"/>
</node>
</node>
<node TEXT="Build MBE Groupings" FOLDED="true" ID="ID_1616556231" CREATED="1717448347173" MODIFIED="1717617727067">
<node TEXT="Line" FOLDED="true" ID="ID_1926392492" CREATED="1717448354391" MODIFIED="1717448355591">
<node TEXT="reference" FOLDED="true" ID="ID_1801482721" CREATED="1717448513999" MODIFIED="1717448516058">
<node FOLDED="true" ID="ID_933349316" CREATED="1717444174451" MODIFIED="1717444174451" LINK="https://syngenta.sharepoint.com/:x:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task/INC16979999_MBE_stable_line_code.xlsx?d=w3eaa2b4b5ac646cba166f843e5f379ca&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=MNh6pg"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/TransitionData/Shared%20Documents/02_Multiple%20BE%20Task/INC16979999_MBE_stable_line_code.xlsx?d=w3eaa2b4b5ac646cba166f843e5f379ca&amp;csf=1&amp;web=1&amp;e=MNh6pg">INC16979999_MBE_stable_line_code.xlsx</a>
  </body>
</html>
</richcontent>
<node TEXT="about" FOLDED="true" ID="ID_682908551" CREATED="1717445954149" MODIFIED="1717445963268">
<node TEXT="source for MBE Groupings" ID="ID_1249226081" CREATED="1717445963882" MODIFIED="1717445972598"/>
</node>
<node TEXT="origianl line code sheet" FOLDED="true" ID="ID_885140380" CREATED="1717444178138" MODIFIED="1717444197288">
<node TEXT="crop mane" ID="ID_851306498" CREATED="1717444199051" MODIFIED="1717444201916"/>
<node TEXT="create_year_of last batch" FOLDED="true" ID="ID_135774650" CREATED="1717444239664" MODIFIED="1717444252655">
<node TEXT="2017 cutoff date" ID="ID_1979090234" CREATED="1717444254344" MODIFIED="1717444265916"/>
</node>
</node>
<node TEXT="working line code" FOLDED="true" ID="ID_568174176" CREATED="1717444542487" MODIFIED="1717444548645">
<node TEXT="$ concat divider" ID="ID_68404411" CREATED="1717444549212" MODIFIED="1717444554145"/>
</node>
<node TEXT="SQL" FOLDED="true" ID="ID_287613" CREATED="1717444723026" MODIFIED="1717444726196">
<node TEXT="Crop code is 4 CHAR, (trailing space)" ID="ID_678460398" CREATED="1717444729144" MODIFIED="1717444769199"/>
</node>
<node TEXT="Summary" FOLDED="true" ID="ID_716784668" CREATED="1717444773445" MODIFIED="1717444776659">
<node TEXT="Name = Spirit Names (vs ID names)" ID="ID_1508296839" CREATED="1717444831793" MODIFIED="1717444846513"/>
</node>
<node TEXT="Line Pepper" FOLDED="true" ID="ID_261853326" CREATED="1717444878628" MODIFIED="1717444883865">
<node TEXT="Data pull from Spirit Line Table" ID="ID_1661535649" CREATED="1717444885616" MODIFIED="1717444937143"/>
</node>
<node TEXT="ASAP" FOLDED="true" ID="ID_179434782" CREATED="1717444588500" MODIFIED="1717444592678">
<node TEXT="create index" ID="ID_39826223" CREATED="1717444594685" MODIFIED="1717444600545"/>
</node>
</node>
</node>
<node TEXT="Open &quot;Line {Crop}&quot; Sheet" FOLDED="true" ID="ID_961190636" CREATED="1717448607419" MODIFIED="1717448646154">
<node TEXT="reference" FOLDED="true" ID="ID_1738819727" CREATED="1717453255382" MODIFIED="1717453257500">
<node ID="ID_1415010570" CREATED="1717448583961" MODIFIED="1717448583961"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table border="0" cellpadding="0" cellspacing="0" width="130" style="width: 98pt">
      <tr height="19" style="height: 14.4pt">
        <td height="19" class="xl66" width="130" style="height: 14.4pt; width: 98pt">
          <a href="#'LIne Pepper'!A1">LIne Pepper</a>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Filter by &quot;Has MBE&quot;" ID="ID_1663454002" CREATED="1717448733332" MODIFIED="1717448749509"/>
<node TEXT="Select Line Code" ID="ID_1078108563" CREATED="1717448750942" MODIFIED="1717448758442"/>
<node TEXT="CP into new Sheet &quot;MBE Lines {Crop} {Date}" ID="ID_875023255" CREATED="1717448759314" MODIFIED="1717448829408"/>
<node TEXT="Change header to chain" FOLDED="true" ID="ID_1937789359" CREATED="1717453150388" MODIFIED="1717453158205">
<node TEXT="LINE:LINCD" ID="ID_1243102511" CREATED="1717453179690" MODIFIED="1717453179690"/>
</node>
</node>
<node TEXT="Import into Spirit" FOLDED="true" ID="ID_1031842057" CREATED="1717453195805" MODIFIED="1717453201213">
<node TEXT="Save Grouping" ID="ID_738256747" CREATED="1717453203303" MODIFIED="1717453209072"/>
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\MBE\MBE Status by Spirit Crop.xlsx" ID="ID_90016621" CREATED="1717609143688" MODIFIED="1717609147588" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/MBE/MBE%20Status%20by%20Spirit%20Crop.xlsx"/>
</node>
</node>
<node TEXT="Variety" ID="ID_1655417134" CREATED="1717448356217" MODIFIED="1717448358639"/>
</node>
<node TEXT="Build MBE Profiles" FOLDED="true" ID="ID_434125119" CREATED="1717617705534" MODIFIED="1717617722034">
<node TEXT="Line" FOLDED="true" ID="ID_1559873706" CREATED="1719337708125" MODIFIED="1719337710358">
<node TEXT="CLNST" FOLDED="true" ID="ID_1187289531" CREATED="1719337690714" MODIFIED="1719337694968">
<node TEXT="General folder" ID="ID_572245367" CREATED="1719372513717" MODIFIED="1719372517315"/>
</node>
<node TEXT="CLNRK" ID="ID_1172257351" CREATED="1719337723076" MODIFIED="1719337727451"/>
<node TEXT="CLNUR" ID="ID_1314474188" CREATED="1719337728001" MODIFIED="1719337732608"/>
<node TEXT="INCNO" ID="ID_1388454321" CREATED="1719337733866" MODIFIED="1719337739199"/>
</node>
<node TEXT="MAT" FOLDED="true" ID="ID_1624453897" CREATED="1719336217060" MODIFIED="1719337716544">
<node TEXT="LINCD" ID="ID_1436420844" CREATED="1719371494943" MODIFIED="1719371532391"/>
<node TEXT="FPARM:LINCD" ID="ID_1462775205" CREATED="1719371549110" MODIFIED="1719374011356"/>
<node TEXT="MANUL" ID="ID_275034208" CREATED="1719371488890" MODIFIED="1719371494236"/>
<node TEXT="POLTP" ID="ID_523300765" CREATED="1719371756053" MODIFIED="1719371758963"/>
<node TEXT="MATID" ID="ID_1550032646" CREATED="1719336222088" MODIFIED="1719336223405"/>
<node TEXT="FPARM:MATID" ID="ID_1882741964" CREATED="1719371549110" MODIFIED="1719371589370"/>
<node TEXT="BEBID" ID="ID_1004851370" CREATED="1719336224339" MODIFIED="1719336233503"/>
<node TEXT="FPARM:BEBID" ID="ID_1281967601" CREATED="1719371549110" MODIFIED="1719371635083"/>
<node TEXT="SLBID" ID="ID_1457394819" CREATED="1719582005584" MODIFIED="1719582027806"/>
<node TEXT="LGBID" ID="ID_1871728520" CREATED="1719460891372" MODIFIED="1719460915141"/>
<node TEXT="FPARM:LGBID" ID="ID_1251396813" CREATED="1719371549110" MODIFIED="1719582043771"/>
</node>
</node>
</node>
<node TEXT="Update and Send Tracking Spreadsheet to SME" FOLDED="true" ID="ID_889857755" CREATED="1719940298605" MODIFIED="1720479415729">
<node TEXT="reference" FOLDED="true" ID="ID_1885478222" CREATED="1720480492155" MODIFIED="1720480497624">
<node TEXT="C:\Users\u581917\Syngenta\Transition Data - Documents\02_Multiple BE Task" FOLDED="true" ID="ID_744331944" CREATED="1720480583205" MODIFIED="1720480587705" LINK="file:/C:/Users/u581917/Syngenta/Transition%20Data%20-%20Documents/02_Multiple%20BE%20Task">
<node TEXT="updated using" ID="ID_1236058475" CREATED="1720480589999" MODIFIED="1720480619509" LINK="#ID_1906448401"/>
</node>
</node>
<node TEXT="Line" FOLDED="true" ID="ID_244220994" CREATED="1719950696232" MODIFIED="1719950697487">
<node TEXT="INC16979999_MBE_stable_line_code.xlsx" FOLDED="true" POSITION="bottom_or_right" ID="ID_1431234292" CREATED="1720807683350" MODIFIED="1720807683351" LINK="../../Users/u581917/Syngenta/Transition%20Data%20-%20Documents/02_Multiple%20BE%20Task/INC16979999_MBE_stable_line_code.xlsx">
<node ID="ID_1340056092" CREATED="1719940311919" MODIFIED="1719940311919"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table border="0" cellpadding="0" cellspacing="0" width="124" style="width: 94pt">
      <tr height="60" style="height: 45.0pt">
        <td height="60" class="xl65" width="62" style="height: 45.0pt; width: 47pt">
          see working line code&#xa0;
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="VH" FOLDED="true" ID="ID_1800624190" CREATED="1719950699461" MODIFIED="1719950700772">
<node TEXT="update columns" FOLDED="true" ID="ID_903442940" CREATED="1720807618286" MODIFIED="1720807621653">
<node TEXT="2024_11_January_VH__SPIRITreview.xlsx" FOLDED="true" ID="ID_812347320" CREATED="1720807601458" MODIFIED="1720807601458" LINK="../../Users/u581917/Syngenta/Transition%20Data%20-%20Documents/02_Multiple%20BE%20Task/2024_11_January_VH__SPIRITreview.xlsx">
<node TEXT="Most Info" FOLDED="true" ID="ID_747536014" CREATED="1720807653400" MODIFIED="1720807656556">
<node TEXT="Year Variety record last changed" ID="ID_476998532" CREATED="1720804502062" MODIFIED="1720804502062"/>
</node>
</node>
<node TEXT="Year of First Batch        Year of Most Recent Batch" FOLDED="true" ID="ID_1743437188" CREATED="1720804482279" MODIFIED="1720804482279">
<node TEXT="INC16979999_stable_variety_code_with_multiple_BE_and_last_and_first_batches.xlsx" FOLDED="true" ID="ID_1709268982" CREATED="1720803902533" MODIFIED="1720803902534" LINK="../../Users/u581917/Syngenta/Transition%20Data%20-%20Documents/02_Multiple%20BE%20Task/INC16979999_stable_variety_code_with_multiple_BE_and_last_and_first_batches.xlsx">
<node TEXT="MinMaxYr" ID="ID_210123180" CREATED="1720804087581" MODIFIED="1720804091981"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Build MBE Cleanup Partnership by Crop" FOLDED="true" ID="ID_1178880202" CREATED="1717436503177" MODIFIED="1719444211867">
<font BOLD="true"/>
<node TEXT="next" FOLDED="true" POSITION="bottom_or_right" ID="ID_542540691" CREATED="1718375917258" MODIFIED="1718375918618">
<node TEXT="Pepper" ID="ID_1498622743" CREATED="1718375881411" MODIFIED="1719245582969">
<font BOLD="true"/>
</node>
<node TEXT="Cabbage" ID="ID_1752391854" CREATED="1718375886492" MODIFIED="1718375888900"/>
</node>
<node TEXT="goal: takeover meetings starting on what date?" FOLDED="true" ID="ID_1160214762" CREATED="1718060742879" MODIFIED="1718080291957">
<icon BUILTIN="help"/>
<node TEXT="Currently run by Michele" ID="ID_1806105197" CREATED="1718060719410" MODIFIED="1718060724826"/>
</node>
<node TEXT="Setup meeting with crop SME" FOLDED="true" ID="ID_550316745" CREATED="1716910610407" MODIFIED="1719445879438">
<node TEXT="Time required" FOLDED="true" ID="ID_1353976308" CREATED="1719441299091" MODIFIED="1719441302865">
<node TEXT="1h" ID="ID_761058578" CREATED="1719441303690" MODIFIED="1719441356928"/>
</node>
<node TEXT="Check In" FOLDED="true" ID="ID_631834330" CREATED="1719442998259" MODIFIED="1719443003953">
<node TEXT="Email" FOLDED="true" ID="ID_1805796466" CREATED="1719440000582" MODIFIED="1719440002706">
<node TEXT="Hi Xiaoguang," ID="ID_580365030" CREATED="1719440003458" MODIFIED="1719440792381"/>
<node TEXT="I hope you&apos;re having a great week so far. Would you have time next week to discuss the MBE Cleanup project and go over the process for aligning hybrids/varieties? I&apos;d also like to get your input on a shared file location so that we can work on this together. An hour between 9 am - 12 pm your time would work for my schedule if you have a slot available." ID="ID_1692214555" CREATED="1719440009934" MODIFIED="1719440763615"/>
<node TEXT="Best Regards," ID="ID_1748342401" CREATED="1719440767278" MODIFIED="1719440771222"/>
<node TEXT="Michael" ID="ID_558612883" CREATED="1719440773509" MODIFIED="1719440775642"/>
</node>
</node>
<node TEXT="Schedule Meeting" FOLDED="true" ID="ID_1313997841" CREATED="1719443018743" MODIFIED="1719443024558">
<node TEXT="Invite other interested shareholders" ID="ID_1588945938" CREATED="1719443025351" MODIFIED="1719443032603"/>
</node>
</node>
<node TEXT="Meeting Prep" FOLDED="true" ID="ID_1320414242" CREATED="1719444301463" MODIFIED="1719444314832">
<node TEXT="Update presentation" FOLDED="true" ID="ID_1104666750" CREATED="1719443044073" MODIFIED="1719443048317">
<node TEXT="Location" FOLDED="true" ID="ID_1690766651" CREATED="1719444243365" MODIFIED="1719444278367">
<node ID="ID_1543648621" CREATED="1719444279737" MODIFIED="1719444279737" LINK="https://syngenta.sharepoint.com/:f:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Individual%20Crop%20Onboarding?csf=1&amp;amp;web=1&amp;amp;e=91ZwEO"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/MBE%20cleanup/Individual%20Crop%20Onboarding?csf=1&amp;web=1&amp;e=91ZwEO">Individual Crop Onboarding</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Worksheet" FOLDED="true" ID="ID_1904967206" CREATED="1719444317812" MODIFIED="1719444322977">
<node TEXT="Broccoli SME -" POSITION="bottom_or_right" ID="ID_1751710309" CREATED="1718375889272" MODIFIED="1719901760786">
<icon BUILTIN="yes"/>
</node>
</node>
<node TEXT="Practice" ID="ID_75036459" CREATED="1719445817963" MODIFIED="1719445820648"/>
</node>
<node TEXT="During meeting" FOLDED="true" ID="ID_637232253" CREATED="1717441682903" MODIFIED="1717441685843">
<node TEXT="Share presentation" ID="ID_180046607" CREATED="1717436519183" MODIFIED="1717441678638"/>
<node TEXT="Provide training to SME" FOLDED="true" ID="ID_1302404517" CREATED="1717441452701" MODIFIED="1717441490496">
<node TEXT="explain user guide" ID="ID_1604288276" CREATED="1718060869042" MODIFIED="1718060892239" LINK="#ID_1058723170"/>
</node>
<node TEXT="Ask how workload will be divided" FOLDED="true" ID="ID_1147476479" CREATED="1717436081821" MODIFIED="1719444366125">
<node TEXT="By Crop, then Breeding Group" ID="ID_1363994142" CREATED="1717436089767" MODIFIED="1717436108147"/>
</node>
<node TEXT="see when the low season is, or time available to work on it" ID="ID_1510896819" CREATED="1718041377918" MODIFIED="1719444389059"/>
<node TEXT="Ask when would be a good time to follow-up" ID="ID_56693287" CREATED="1718041266318" MODIFIED="1718041279233"/>
<node TEXT="Offer support" ID="ID_1375594264" CREATED="1718041281267" MODIFIED="1718041283991"/>
</node>
<node TEXT="After meeting" FOLDED="true" ID="ID_1294394096" CREATED="1717441693698" MODIFIED="1717441696212">
<node TEXT="Get shared access to key files" FOLDED="true" ID="ID_1082118198" CREATED="1717436563616" MODIFIED="1717437927614">
<node TEXT="Located on each Crops Teamspace" ID="ID_1983860610" CREATED="1717436579791" MODIFIED="1717436589292"/>
<node TEXT="offer immediate support" ID="ID_1701611853" CREATED="1718041307206" MODIFIED="1718080213104"/>
<node TEXT="Squash" ID="ID_407106187" CREATED="1718042881373" MODIFIED="1718042909044">
<icon BUILTIN="yes"/>
<icon BUILTIN="freemind_butterfly"/>
</node>
<node TEXT="Watermelon" ID="ID_1546279485" CREATED="1718042881373" MODIFIED="1718042890771">
<icon BUILTIN="yes"/>
<icon BUILTIN="freemind_butterfly"/>
</node>
</node>
</node>
</node>
<node TEXT="Prioritize Lines / VHs to fix" FOLDED="true" ID="ID_940727793" CREATED="1720478437045" MODIFIED="1720493488376">
<font BOLD="true"/>
<node TEXT="Find lines that are in active trials" FOLDED="true" ID="ID_2607579" CREATED="1720493489750" MODIFIED="1720804926286" VGAP_QUANTITY="3 pt" COMMON_HGAP_QUANTITY="14 pt">
<node TEXT="" ID="ID_1416805613" CREATED="1720798455212" MODIFIED="1720804927078"/>
</node>
</node>
<node TEXT="Assign ALL Materials to Respective BG In Spirit" FOLDED="true" ID="ID_1855787081" CREATED="1719849270810" MODIFIED="1720480257099">
<node TEXT="Not all users can change ALL" ID="ID_561379855" CREATED="1719849282958" MODIFIED="1719849293578"/>
</node>
<node TEXT="Fix Lines / VHs (Prepare Userguide)" FOLDED="true" ID="ID_1631054848" CREATED="1716908501517" MODIFIED="1720491416719">
<icon BUILTIN="yes"/>
<font SIZE="14" BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_1078098553" CREATED="1718060985119" MODIFIED="1718060986929">
<node TEXT="2024_Biological Entity Discussion_Squash.pptx" POSITION="bottom_or_right" ID="ID_946822301" CREATED="1718062213593" MODIFIED="1718062213593" LINK="../../Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Crop/Squash/2024_Biological%20Entity%20Discussion_Squash.pptx"/>
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\Crop\Watermelon\MBE\MBE resolution watermelon GMT20240522-140322_Recording_1920x1080.mp4" ID="ID_957776869" CREATED="1718061096412" MODIFIED="1718061102426" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Crop/Watermelon/MBE/MBE%20resolution%20watermelon%20GMT20240522-140322_Recording_1920x1080.mp4"/>
<node TEXT="MBE Squash GMT20240531-140054_Recording_gallery_1920x1080.mp4" POSITION="bottom_or_right" ID="ID_1738512556" CREATED="1718062180124" MODIFIED="1718062180125" LINK="../../Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Crop/Squash/MBE%20Squash%20GMT20240531-140054_Recording_gallery_1920x1080.mp4"/>
</node>
<node TEXT="Open Spreadsheet for Crop" ID="ID_639289168" CREATED="1717167786581" MODIFIED="1717167801554"/>
<node TEXT="In Spirit" FOLDED="true" ID="ID_872933169" CREATED="1716908373326" MODIFIED="1720479518638">
<node TEXT="Open surviving MBE Grouping and Apply Profile" FOLDED="true" ID="ID_1838057116" CREATED="1716417064816" MODIFIED="1720481201842">
<node TEXT="ref" FOLDED="true" ID="ID_1288989327" CREATED="1720492587553" MODIFIED="1720492589342">
<node TEXT="png-240530-121832551-13540179899499993673.png" ID="ID_639361269" CREATED="1717096713920" MODIFIED="1717096713920">
<hook URI="DataStewardshipAnalyst_files/png-240530-121832551-13540179899499993673.png" SIZE="0.51194537" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Line" FOLDED="true" ID="ID_573914718" CREATED="1716510249679" MODIFIED="1720481113396">
<font BOLD="true"/>
<node TEXT="Spirit Profile:   Crop &gt; MINT .." FOLDED="true" ID="ID_1611583520" CREATED="1716505186711" MODIFIED="1716906821459">
<node TEXT="Identity Management" ID="ID_723005507" CREATED="1716906822256" MODIFIED="1716906828555"/>
<node TEXT="MBE" ID="ID_1416560877" CREATED="1716906828962" MODIFIED="1716906830801"/>
</node>
</node>
<node TEXT="Variety" FOLDED="true" ID="ID_599309414" CREATED="1720481093476" MODIFIED="1720481097919">
<font BOLD="true"/>
<node TEXT="Open Varieties window" FOLDED="true" ID="ID_626435999" CREATED="1717097197491" MODIFIED="1717097211990">
<node TEXT="Open latest MBE grouping:" FOLDED="true" ID="ID_1581623832" CREATED="1717097138104" MODIFIED="1717097598922">
<node TEXT="MINT .. Identity Management ..VH MBE Review 2024_Jan" ID="ID_740625183" CREATED="1717097410472" MODIFIED="1717097410474"/>
</node>
<node TEXT="Apply Profile:" FOLDED="true" ID="ID_1029242873" CREATED="1717097298681" MODIFIED="1717097333505">
<node TEXT="VH  w Parent IM BID" FOLDED="true" ID="ID_980745309" CREATED="1717097605109" MODIFIED="1717097621464">
<node TEXT="GNA Record info" ID="ID_1319239091" CREATED="1717097333507" MODIFIED="1717097341358"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="For Set to Address, Change CLNST to Start" ID="ID_189791567" CREATED="1720493529086" MODIFIED="1720493566545"/>
<node TEXT="Investigate" FOLDED="true" ID="ID_183577000" CREATED="1718062266301" MODIFIED="1720481422342">
<font BOLD="true"/>
<node TEXT="Clarify exact process of resolving MBEs by cause" FOLDED="true" ID="ID_187705823" CREATED="1716869664974" MODIFIED="1716873705602">
<icon BUILTIN="yes"/>
<node TEXT="for each cause, what are the rules / action taken to assign an existing BE BID" ID="ID_1586140274" CREATED="1716873465371" MODIFIED="1716873567033"/>
<node TEXT="show example of each cause / fix" ID="ID_525277193" CREATED="1720481437965" MODIFIED="1720481458686"/>
</node>
<node TEXT="Stable Line Code" FOLDED="true" ID="ID_602793530" CREATED="1716871547393" MODIFIED="1716871636310">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_152840157" CREATED="1716871669309" MODIFIED="1716871678641">
<node TEXT="Every Line Code in Identity will have a BE BID inherited to its progeny when self or sib pollinated." ID="ID_482408539" CREATED="1716871547393" MODIFIED="1716871547393"/>
<node TEXT="A line code is intended to have a single BE BID." ID="ID_1384458974" CREATED="1716871547394" MODIFIED="1716871547394"/>
</node>
<node TEXT="Choose Line with CLNST = Start" ID="ID_875595685" CREATED="1720493608026" MODIFIED="1720493648344"/>
<node TEXT="Change CLNST to InPrg" ID="ID_1443219014" CREATED="1720493344660" MODIFIED="1720493686786"/>
<node TEXT="View Associated Materials" FOLDED="true" ID="ID_955499935" CREATED="1720481318526" MODIFIED="1720492763491">
<font BOLD="true"/>
<node TEXT="No Materials?" ID="ID_689987670" CREATED="1720493736456" MODIFIED="1720493755261"/>
<node TEXT="Materials" FOLDED="true" ID="ID_777900531" CREATED="1720493755781" MODIFIED="1720493760695">
<font BOLD="true"/>
<node TEXT="Apply Profile:" FOLDED="true" ID="ID_127040706" CREATED="1720492491290" MODIFIED="1720492497421">
<node TEXT="ref" FOLDED="true" ID="ID_837059716" CREATED="1720492616317" MODIFIED="1720492617482">
<node TEXT="png-240530-121832551-13540179899499993673.png" ID="ID_1286670155" CREATED="1717096713920" MODIFIED="1717096713920">
<hook URI="DataStewardshipAnalyst_files/png-240530-121832551-13540179899499993673.png" SIZE="0.51194537" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Sort by MATID" ID="ID_907818215" CREATED="1720492479940" MODIFIED="1720492490329"/>
</node>
</node>
</node>
<node TEXT="Stable Variety Code" FOLDED="true" ID="ID_719506716" CREATED="1716871547394" MODIFIED="1716871634973">
<font BOLD="true"/>
<node TEXT="Sort By VHNO" ID="ID_205872408" CREATED="1717097679651" MODIFIED="1717097688775"/>
<node TEXT="Fix: Multiple VHNO for one VHNM (VHNM is the same, but VHNO differs)" FOLDED="true" ID="ID_1231903579" CREATED="1717435245149" MODIFIED="1718082087622">
<font BOLD="true"/>
<node TEXT="goal: Each VHNM has the same VHNO" ID="ID_14572543" CREATED="1718080608624" MODIFIED="1718080637557"/>
<node TEXT="Notes:" FOLDED="true" ID="ID_1959705181" CREATED="1717098045251" MODIFIED="1717098052558">
<node TEXT="VHNO" FOLDED="true" ID="ID_1060926903" CREATED="1716906926874" MODIFIED="1716906933324">
<node TEXT="Key Identifier For The Variety Grid in SPIRIT" ID="ID_1856900808" CREATED="1717601901946" MODIFIED="1717601915295"/>
<node TEXT="for newly created Stable Variety Code" FOLDED="true" ID="ID_1919327056" CREATED="1717601923801" MODIFIED="1717601932235">
<node TEXT="BE BID (EWA#) used to create the variety record is being assigned by IM to this" ID="ID_1440132770" CREATED="1717601932248" MODIFIED="1717602322439"/>
<node TEXT="Defaults to STGCD 3" ID="ID_1353359119" CREATED="1716906976229" MODIFIED="1716906984742"/>
<node TEXT="BGPCD: ALL" ID="ID_1079611620" CREATED="1716906985722" MODIFIED="1716906992724"/>
</node>
<node TEXT="for Friday records created prior to July 2023" FOLDED="true" ID="ID_845381671" CREATED="1717601966255" MODIFIED="1717601977681">
<node TEXT="this was assigned by the user with the variety record created directly in SPIRIT" ID="ID_1353779949" CREATED="1717601978852" MODIFIED="1717602015257"/>
</node>
</node>
</node>
<node TEXT="Sort by VHNM" ID="ID_1763552614" CREATED="1717435339679" MODIFIED="1717435348149"/>
<node TEXT="Pull VHNM out to filter" FOLDED="true" ID="ID_890986090" CREATED="1718080943239" MODIFIED="1718080969916">
<node TEXT="Identify VHNM with &gt;1 items" ID="ID_898766643" CREATED="1718080971048" MODIFIED="1718081091457"/>
</node>
<node TEXT="View Associated Materials for both" FOLDED="true" ID="ID_253683173" CREATED="1717435744331" MODIFIED="1717435759562">
<node TEXT="if Variety has no materials (possibly duplicate)" FOLDED="true" ID="ID_201237512" CREATED="1716907035032" MODIFIED="1716907295774">
<node TEXT="check to see if it is a duplicate" FOLDED="true" ID="ID_1710103531" CREATED="1716907269103" MODIFIED="1717098402978">
<node TEXT="Query the Variety Name" FOLDED="true" ID="ID_621980713" CREATED="1717097968138" MODIFIED="1717097987570">
<node TEXT="VH:VHNM" ID="ID_1486895582" CREATED="1717097988446" MODIFIED="1717097997857"/>
<node TEXT="rationale" FOLDED="true" ID="ID_1017236944" CREATED="1717098006419" MODIFIED="1717098008123">
<node TEXT="variety name is used in stable variety code" ID="ID_998871433" CREATED="1717097840738" MODIFIED="1717097887277"/>
<node TEXT="can&apos;t import for variety name" ID="ID_1287138517" CREATED="1717097929834" MODIFIED="1717097933913"/>
</node>
</node>
</node>
<node TEXT="Sort by STBVDC" FOLDED="true" ID="ID_883658731" CREATED="1717098520808" MODIFIED="1717098537585">
<node TEXT="stable variety code" ID="ID_1807019009" CREATED="1717098538048" MODIFIED="1717098542218"/>
</node>
<node TEXT="View Associated Materials for the duplicate VH" FOLDED="true" ID="ID_1215614098" CREATED="1717098574204" MODIFIED="1717098603041">
<node TEXT="Identify the cause of duplication" FOLDED="true" ID="ID_144886780" CREATED="1717099488247" MODIFIED="1717099494430">
<node TEXT="Augusta- Watermelon" FOLDED="true" ID="ID_1860958822" CREATED="1717099256570" MODIFIED="1717099263952">
<node TEXT="New material was created which created a new (duplicate) variety record" FOLDED="true" ID="ID_1659689110" CREATED="1717099267073" MODIFIED="1717099410650">
<node TEXT="-11:49" ID="ID_1709873548" CREATED="1717099314008" MODIFIED="1717099328359"/>
<node TEXT="Would creating new materials continue to create new varieties?" FOLDED="true" ID="ID_1885834963" CREATED="1717099340154" MODIFIED="1717099373338">
<icon BUILTIN="yes"/>
<node TEXT="" ID="ID_499400460" CREATED="1717099378432" MODIFIED="1717099378432"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Fix: Delete duplicate variety" FOLDED="true" ID="ID_247525075" CREATED="1717104424158" MODIFIED="1717624636231">
<node TEXT="document" FOLDED="true" ID="ID_1531335524" CREATED="1716907040469" MODIFIED="1716907244880">
<node TEXT="REMRK" FOLDED="true" ID="ID_56356808" CREATED="1716907252925" MODIFIED="1716907261163">
<node TEXT="&quot;duplicate record deleted May 2024&quot;" ID="ID_1105026319" CREATED="1716907331828" MODIFIED="1716907354296"/>
</node>
</node>
<node TEXT="delete Variety" ID="ID_467743691" CREATED="1716907245253" MODIFIED="1716907365690"/>
</node>
</node>
</node>
</node>
<node TEXT="Choose Variety with CLNST = Start" ID="ID_460671930" CREATED="1720493608026" MODIFIED="1720493673921"/>
<node TEXT="Change CLNST to InPrg" ID="ID_672617050" CREATED="1720493344660" MODIFIED="1720493686786"/>
<node TEXT="View Associated Materials" FOLDED="true" ID="ID_1382491418" CREATED="1720481318526" MODIFIED="1720492782859">
<font BOLD="true"/>
<node TEXT="No associated materials" FOLDED="true" ID="ID_1275854840" CREATED="1717095023851" MODIFIED="1720492954764">
<node TEXT="if Variety has no materials (possibly duplicate)" FOLDED="true" ID="ID_658240932" CREATED="1716907035032" MODIFIED="1716907295774">
<node TEXT="check to see if it is a duplicate" FOLDED="true" ID="ID_487785777" CREATED="1716907269103" MODIFIED="1717098402978">
<node TEXT="Query the Variety Name" FOLDED="true" ID="ID_1206672065" CREATED="1717097968138" MODIFIED="1717097987570">
<node TEXT="VH:VHNM" ID="ID_1722736677" CREATED="1717097988446" MODIFIED="1717097997857"/>
<node TEXT="rationale" FOLDED="true" ID="ID_1858541272" CREATED="1717098006419" MODIFIED="1717098008123">
<node TEXT="variety name is used in stable variety code" ID="ID_425515242" CREATED="1717097840738" MODIFIED="1717097887277"/>
<node TEXT="can&apos;t import for variety name" ID="ID_1599849203" CREATED="1717097929834" MODIFIED="1717097933913"/>
</node>
</node>
</node>
<node TEXT="Sort by STBVDC" FOLDED="true" ID="ID_514932213" CREATED="1717098520808" MODIFIED="1717098537585">
<node TEXT="stable variety code" ID="ID_547625180" CREATED="1717098538048" MODIFIED="1717098542218"/>
</node>
<node TEXT="View Associated Materials for the duplicate VH" FOLDED="true" ID="ID_1241947068" CREATED="1717098574204" MODIFIED="1717098603041">
<node TEXT="Identify the cause of duplication" FOLDED="true" ID="ID_398364796" CREATED="1717099488247" MODIFIED="1717099494430">
<node TEXT="Augusta- Watermelon" FOLDED="true" ID="ID_1752534244" CREATED="1717099256570" MODIFIED="1717099263952">
<node TEXT="New material was created which created a new (duplicate) variety record" FOLDED="true" ID="ID_351572702" CREATED="1717099267073" MODIFIED="1717099410650">
<node TEXT="-11:49" ID="ID_1077493679" CREATED="1717099314008" MODIFIED="1717099328359"/>
<node TEXT="Would creating new materials continue to create new varieties?" FOLDED="true" ID="ID_344548815" CREATED="1717099340154" MODIFIED="1717099373338">
<icon BUILTIN="yes"/>
<node TEXT="" ID="ID_250491204" CREATED="1717099378432" MODIFIED="1717099378432"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Fix: Delete duplicate variety" FOLDED="true" ID="ID_1686328532" CREATED="1717104424158" MODIFIED="1717624636231">
<node TEXT="document" FOLDED="true" ID="ID_1964765363" CREATED="1716907040469" MODIFIED="1716907244880">
<node TEXT="REMRK" FOLDED="true" ID="ID_1500309162" CREATED="1716907252925" MODIFIED="1716907261163">
<node TEXT="&quot;duplicate record deleted May 2024&quot;" ID="ID_1124221349" CREATED="1716907331828" MODIFIED="1716907354296"/>
</node>
</node>
<node TEXT="delete Variety" ID="ID_1052822068" CREATED="1716907245253" MODIFIED="1716907365690"/>
</node>
</node>
</node>
<node TEXT="Materials" FOLDED="true" ID="ID_1987393997" CREATED="1720492932339" MODIFIED="1720492987972">
<font BOLD="true"/>
<node TEXT="Apply Profile: MAT w STVBC parent" ID="ID_947223144" CREATED="1717106561987" MODIFIED="1717106582256"/>
<node TEXT="Sort by MATID" ID="ID_1339669583" CREATED="1720492479940" MODIFIED="1720492490329"/>
<node TEXT="Identify Materials with different BE BID from the first" FOLDED="true" ID="ID_908103245" CREATED="1716907411217" MODIFIED="1720493098871">
<font BOLD="true"/>
<node TEXT="if there are many materials" FOLDED="true" ID="ID_1287916396" CREATED="1720493122091" MODIFIED="1720493158768">
<node TEXT="" ID="ID_905488611" CREATED="1720493160650" MODIFIED="1720493160650"/>
</node>
<node TEXT="Manually Added" ID="ID_1641393217" CREATED="1717631910252" MODIFIED="1717631915837">
<font BOLD="true"/>
</node>
<node TEXT="ACQFL" FOLDED="true" ID="ID_1079612634" CREATED="1718083457544" MODIFIED="1718083463771">
<node TEXT="Aquired Flag" ID="ID_383651395" CREATED="1718083467493" MODIFIED="1718083471578"/>
</node>
<node TEXT="If Materials have differing:" FOLDED="true" ID="ID_738763935" CREATED="1717634043504" MODIFIED="1718083324091">
<font BOLD="true"/>
<node TEXT="LBGBID" FOLDED="true" ID="ID_1700397774" CREATED="1717631967264" MODIFIED="1718082987654">
<font BOLD="true"/>
<node TEXT="Sort by LBGBID" FOLDED="true" ID="ID_167193631" CREATED="1718082219545" MODIFIED="1718082232742">
<node TEXT="should have a single LBGBID" ID="ID_469365409" CREATED="1717633988232" MODIFIED="1718083008651"/>
</node>
<node TEXT="" ID="ID_1301894430" CREATED="1718083344241" MODIFIED="1718083344241"/>
</node>
<node TEXT="BEBID" ID="ID_1303026608" CREATED="1717634020190" MODIFIED="1717634039141"/>
<node TEXT="SLBID" FOLDED="true" ID="ID_953727310" CREATED="1717106446883" MODIFIED="1718083016878">
<font BOLD="true"/>
<node TEXT="causes" FOLDED="true" ID="ID_1840605951" CREATED="1717107747742" MODIFIED="1717621920870">
<node TEXT="Check POLTP" FOLDED="true" ID="ID_1143643537" CREATED="1717621424787" MODIFIED="1717621679769">
<font BOLD="true"/>
<node TEXT="Open" FOLDED="true" ID="ID_1696292069" CREATED="1717621434164" MODIFIED="1717621460676">
<font BOLD="true"/>
<node TEXT="creates New LBGBID" ID="ID_1030588869" CREATED="1717621438932" MODIFIED="1717621453878"/>
<node TEXT="Fix: Change to Self" ID="ID_1487302253" CREATED="1717621503220" MODIFIED="1717621513118"/>
</node>
</node>
<node TEXT="if one doesn&apos;t contain the SLBID, then it wasn&apos;t created with the same parent" FOLDED="true" ID="ID_1414207954" CREATED="1717106879790" MODIFIED="1717106912729">
<node TEXT="Case: WDLH21-0007, Watermelon" FOLDED="true" ID="ID_1919594374" CREATED="1717108067983" MODIFIED="1717108099643">
<node TEXT="X mat not created with stable line" ID="ID_1347375329" CREATED="1717114170311" MODIFIED="1717114211001"/>
</node>
</node>
<node TEXT="Review Parents" FOLDED="true" ID="ID_555911608" CREATED="1717107967625" MODIFIED="1717437206099">
<font BOLD="true"/>
<node TEXT="If Material has no parents" FOLDED="true" ID="ID_1899477633" CREATED="1717437038993" MODIFIED="1717632903136">
<font BOLD="true"/>
<node TEXT="Commercial Check" ID="ID_1416690864" CREATED="1717437381612" MODIFIED="1717437404128"/>
<node TEXT="Assign earliest BE BID from to Materials" FOLDED="true" ID="ID_1164032968" CREATED="1717437405299" MODIFIED="1717437661459">
<node TEXT="Document" ID="ID_1316994425" CREATED="1717437686450" MODIFIED="1717437691568"/>
<node TEXT="example" FOLDED="true" ID="ID_1838336356" CREATED="1717437536625" MODIFIED="1717437538317">
<node TEXT="Ayesha, watermelon" FOLDED="true" ID="ID_1410877929" CREATED="1717437531452" MODIFIED="1717437545890">
<node TEXT="-50:35" ID="ID_1361397619" CREATED="1717437662474" MODIFIED="1717437670328"/>
<node TEXT="Align under BE BID of EWA1200000196" ID="ID_1885896891" CREATED="1717437715050" MODIFIED="1717437722275"/>
</node>
</node>
</node>
</node>
<node TEXT="View Associated Parent Materials" FOLDED="true" ID="ID_853299977" CREATED="1717106932274" MODIFIED="1717106963258">
<node TEXT="Remove unaffected materials" FOLDED="true" ID="ID_1565519795" CREATED="1717107546782" MODIFIED="1717107633084">
<node TEXT="Case: WDLH21-0007, Watermelon" FOLDED="true" ID="ID_903440271" CREATED="1717108067983" MODIFIED="1717108099643">
<node TEXT="-18:15" ID="ID_247236017" CREATED="1717113809816" MODIFIED="1717113815213"/>
<node TEXT="male parents for both: BEBID: EWA1200006077" ID="ID_1696733382" CREATED="1717108106997" MODIFIED="1717108149375"/>
<node TEXT="Assign" ID="ID_457312042" CREATED="1717114928766" MODIFIED="1717114945934"/>
</node>
</node>
<node TEXT="Parent BEBIDs needs to be the same to give the progeny the same BEBID" ID="ID_133650414" CREATED="1717108176041" MODIFIED="1717114305827" LINK="#ID_1483925928">
<font ITALIC="true"/>
</node>
<node TEXT="Review Relationship of Parents that have differing BEBIDs" FOLDED="true" ID="ID_363171290" CREATED="1717108852215" MODIFIED="1717115168392">
<node TEXT="Query MAterials with Line code" ID="ID_337609461" CREATED="1717114319408" MODIFIED="1717114334080"/>
</node>
</node>
<node TEXT="Should have:" FOLDED="true" ID="ID_956785590" CREATED="1717633883547" MODIFIED="1717633888768">
<node TEXT="Parent BEBID = Child BEBID" ID="ID_1890183241" CREATED="1717633632905" MODIFIED="1717633854015">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="Issue" FOLDED="true" ID="ID_1547480275" CREATED="1717434225353" MODIFIED="1717633536084">
<font BOLD="true"/>
<node TEXT="Parent with Missing or mismatched LINCD" FOLDED="true" ID="ID_1084117836" CREATED="1717436210496" MODIFIED="1717436377148">
<node TEXT="Affected variety female parent not same BID as progeny of other female" ID="ID_1798037965" CREATED="1717434240071" MODIFIED="1717434287586"/>
<node TEXT="Fix" FOLDED="true" ID="ID_1125034139" CREATED="1717115169444" MODIFIED="1717115172282">
<node TEXT="Assign Linecode from Linecoded Material to BE without it" FOLDED="true" ID="ID_1788469367" CREATED="1717115173454" MODIFIED="1717433287185">
<node TEXT="Does assigning linecode change BID? Would that lead to an MBE with the line?" ID="ID_368074012" CREATED="1717433362042" MODIFIED="1717436260539">
<icon BUILTIN="help"/>
</node>
<node TEXT="Document" FOLDED="true" ID="ID_316867951" CREATED="1717433293011" MODIFIED="1717433298214">
<node TEXT="-20:54" ID="ID_848463535" CREATED="1717433305873" MODIFIED="1717433309826"/>
</node>
</node>
<node TEXT="Reprocess Variety" ID="ID_1647069393" CREATED="1717433509519" MODIFIED="1717433518018"/>
</node>
</node>
<node TEXT="Parent BEBID != Child BEBID" FOLDED="true" ID="ID_1702878028" CREATED="1717633544710" MODIFIED="1717633791053">
<font BOLD="true"/>
<node TEXT="Fix?" ID="ID_526198460" CREATED="1717633573099" MODIFIED="1717633576379"/>
</node>
<node TEXT="Incorrect Male Parent" FOLDED="true" ID="ID_749036629" CREATED="1717434425865" MODIFIED="1717434435950">
<node TEXT="23WMHS09824&#xa;22WMH509127" FOLDED="true" ID="ID_1163593436" CREATED="1717434376771" MODIFIED="1717434413825">
<node TEXT="-32:55" ID="ID_98652698" CREATED="1717434671348" MODIFIED="1717434678453"/>
</node>
<node TEXT="Fix" FOLDED="true" ID="ID_394809843" CREATED="1717434305739" MODIFIED="1717434314592">
<node TEXT="Remove variety NHNO from mislabeled materials" FOLDED="true" ID="ID_1144569494" CREATED="1717434315708" MODIFIED="1717434562312">
<node TEXT="Material..Properies" ID="ID_79780043" CREATED="1717434745687" MODIFIED="1717434755077"/>
<node TEXT="-33:20" ID="ID_923670180" CREATED="1717434711364" MODIFIED="1717434720599"/>
</node>
<node TEXT="Document" ID="ID_76727758" CREATED="1717434830483" MODIFIED="1717434832949"/>
<node TEXT="Refresh grid" ID="ID_1338791425" CREATED="1717434856566" MODIFIED="1717434859646"/>
<node TEXT="View Varieties..associated materials to confirm" ID="ID_1902375155" CREATED="1717434860840" MODIFIED="1717434879205"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="FPARM:MMT:BEBID" ID="ID_988318851" CREATED="1717634053842" MODIFIED="1717634078613"/>
<node TEXT="POLTP" FOLDED="true" ID="ID_651414052" CREATED="1720666127471" MODIFIED="1720666130777">
<node TEXT="how does POLTP affect inheriutance of BE BID" FOLDED="true" ID="ID_1404342614" CREATED="1717211856886" MODIFIED="1719249982968">
<icon BUILTIN="yes"/>
<icon BUILTIN="button_ok"/>
<attribute NAME="WhenDone" VALUE="2024-06-24" OBJECT="org.freeplane.features.format.FormattedDate|2024-06-24T13:26-0400|yyyy-MM-dd"/>
<node TEXT="does mixing create a new BE?" ID="ID_1857772434" CREATED="1717213173605" MODIFIED="1717213415112" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/Spirit/ImportExport/MBE%20Squash.xlsx"/>
</node>
</node>
</node>
<node TEXT="confirm multiple BE" ID="ID_514498604" CREATED="1717104506609" MODIFIED="1717104514779"/>
<node TEXT="CRSNO (cross #) differs: doesn&apos;t seem to affect BE BID" ID="ID_532494871" CREATED="1716907423950" MODIFIED="1717632179587">
<font BOLD="false"/>
</node>
<node TEXT="check CRTDT  (create date)" FOLDED="true" ID="ID_725587405" CREATED="1716907466580" MODIFIED="1716907499497">
<node TEXT="If pre Identity Management (Date &lt; ?)" FOLDED="true" ID="ID_485949388" CREATED="1716907524388" MODIFIED="1717106276649"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      MBE is the Result of Migration
    </p>
  </body>
</html></richcontent>
<node TEXT="MANUL = checked (Manually generated)" FOLDED="true" ID="ID_951079019" CREATED="1717104580341" MODIFIED="1717106124889">
<node TEXT="No Parent Identifiers" FOLDED="true" ID="ID_1527782450" CREATED="1716907559872" MODIFIED="1716907564490">
<node TEXT="Action" FOLDED="true" ID="ID_347059921" CREATED="1716907643207" MODIFIED="1717106107862">
<font BOLD="true"/>
<node TEXT="Align under single BE (first one by creation date)" FOLDED="true" ID="ID_201667923" CREATED="1716907573765" MODIFIED="1716907683457">
<node TEXT="In file 2024_Watermelon_VH_MBEissue.xlsx" FOLDED="true" ID="ID_1874851033" CREATED="1716907687939" MODIFIED="1717105785437">
<node TEXT="Edit Sheet: Status of Action, Column: Action Required" FOLDED="true" ID="ID_52207326" CREATED="1716907754352" MODIFIED="1716907889420">
<node TEXT="Align to BE BID (chosen BEBID)" ID="ID_1443819238" CREATED="1716907711291" MODIFIED="1716907780360"/>
</node>
</node>
</node>
</node>
<node TEXT="ref" FOLDED="true" ID="ID_1841291917" CREATED="1717105685876" MODIFIED="1717105687941">
<node TEXT="-13:20" ID="ID_1404712117" CREATED="1717105688640" MODIFIED="1717105698674"/>
<node TEXT="WTC9155, Watermelon" ID="ID_1571226761" CREATED="1717105932896" MODIFIED="1717105944996"/>
</node>
</node>
</node>
</node>
<node TEXT="WDLH21-0007" ID="ID_1930510953" CREATED="1717106303060" MODIFIED="1717106333010"/>
</node>
</node>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1403224563" CREATED="1716871659449" MODIFIED="1716871661427">
<node TEXT="VHNO" FOLDED="true" ID="ID_1526697139" CREATED="1716906926874" MODIFIED="1716906933324">
<node TEXT="Key Identifier For The Variety Grid in SPIRIT" ID="ID_689642339" CREATED="1717601901946" MODIFIED="1717601915295"/>
<node TEXT="for newly created Stable Variety Code" FOLDED="true" ID="ID_481405688" CREATED="1717601923801" MODIFIED="1717601932235">
<node TEXT="BE BID (EWA#) used to create the variety record is being assigned by IM to this" ID="ID_1663999014" CREATED="1717601932248" MODIFIED="1717602322439"/>
<node TEXT="Defaults to STGCD 3" ID="ID_730819714" CREATED="1716906976229" MODIFIED="1716906984742"/>
<node TEXT="BGPCD: ALL" ID="ID_741317334" CREATED="1716906985722" MODIFIED="1716906992724"/>
</node>
<node TEXT="for Friday records created prior to July 2023" FOLDED="true" ID="ID_1967033842" CREATED="1717601966255" MODIFIED="1717601977681">
<node TEXT="this was assigned by the user with the variety record created directly in SPIRIT" ID="ID_735095636" CREATED="1717601978852" MODIFIED="1717602015257"/>
</node>
</node>
<node TEXT="When two stable BE BID are crossed, a BE BID is assigned. This BE BID is not considered stable but whenever those same two BE BID are used, the BE BID assigned from the first instance will be given to the new batch generated." FOLDED="true" ID="ID_187315711" CREATED="1716871547395" MODIFIED="1716871547395">
<node TEXT="A Stable Variety Code is intended to have a single BE BID." ID="ID_15493073" CREATED="1716871547396" MODIFIED="1716871547396"/>
</node>
<node TEXT="VH Records" FOLDED="true" ID="ID_383973750" CREATED="1716871293036" MODIFIED="1716871297699">
<node TEXT="• Not all variety/hybrids in SPIRIT will be assigned a Stable Variety Code" FOLDED="true" ID="ID_35718568" CREATED="1716871345590" MODIFIED="1716871345590">
<node TEXT="- No material ids/batches exist for the variety record" ID="ID_409714270" CREATED="1716871345590" MODIFIED="1716871345590"/>
<node TEXT="- Variety Name exists for multiple BE BID and not migrated in June 2023" ID="ID_156621029" CREATED="1716871345591" MODIFIED="1716871357156"/>
</node>
<node TEXT="• Variety Records in SPIRIT have multiple variety number" FOLDED="true" ID="ID_1341845707" CREATED="1716871345592" MODIFIED="1716871345592">
<node TEXT="- Created prior to migration" ID="ID_1696666356" CREATED="1716871345592" MODIFIED="1716871345592"/>
</node>
</node>
<node TEXT="what happens after reprocessing" FOLDED="true" ID="ID_1515003849" CREATED="1716907010880" MODIFIED="1720481252357">
<node TEXT="VHNO" FOLDED="true" ID="ID_65755413" CREATED="1716906926874" MODIFIED="1716906933324">
<node TEXT="Key Identifier For The Variety Grid in SPIRIT" ID="ID_1441711134" CREATED="1717601901946" MODIFIED="1717601915295"/>
<node TEXT="for newly created Stable Variety Code" FOLDED="true" ID="ID_1802832584" CREATED="1717601923801" MODIFIED="1717601932235">
<node TEXT="BE BID (EWA#) used to create the variety record is being assigned by IM to this" ID="ID_331445689" CREATED="1717601932248" MODIFIED="1717602322439"/>
<node TEXT="Defaults to STGCD 3" ID="ID_554415198" CREATED="1716906976229" MODIFIED="1716906984742"/>
<node TEXT="BGPCD: ALL" ID="ID_1709655526" CREATED="1716906985722" MODIFIED="1716906992724"/>
</node>
<node TEXT="for Friday records created prior to July 2023" FOLDED="true" ID="ID_92837821" CREATED="1717601966255" MODIFIED="1717601977681">
<node TEXT="this was assigned by the user with the variety record created directly in SPIRIT" ID="ID_682545941" CREATED="1717601978852" MODIFIED="1717602015257"/>
</node>
</node>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_112231332" CREATED="1716908257746" MODIFIED="1716908259993">
<node TEXT="Review of Variety/Hybrid records in SPIRIT" FOLDED="true" ID="ID_457685533" CREATED="1716873129722" MODIFIED="1716873129722">
<node TEXT="• Are there differences in the Variety Name and/or Variety Number for the same variety" FOLDED="true" ID="ID_701401971" CREATED="1716873129722" MODIFIED="1716873129722">
<node TEXT="e.g. Charleston Grey and Charleston Gray; Baowei 728 and Baowei728" ID="ID_1284274807" CREATED="1716873129723" MODIFIED="1716873129723"/>
</node>
<node TEXT="• New variety record created due to a programming issue with creation of new batch of the variety" FOLDED="true" ID="ID_546203100" CREATED="1716873129724" MODIFIED="1716873129724">
<node TEXT="New record created with a different VHNO value" ID="ID_401286620" CREATED="1716873129724" MODIFIED="1716873129724"/>
<node TEXT="e.g, IW3291and EWA1700000180" ID="ID_1688770264" CREATED="1716873129725" MODIFIED="1716873129725"/>
</node>
<node TEXT="• Items to consider" FOLDED="true" ID="ID_1960121474" CREATED="1716873129725" MODIFIED="1716873129725">
<node TEXT="- Does the Parent Lines have multiple BE issues?" ID="ID_975136999" CREATED="1716873129726" MODIFIED="1716873129726"/>
<node TEXT="- Review status of materials where parent materials exist or do not exist?" ID="ID_1713372786" CREATED="1716873129726" MODIFIED="1716873129726"/>
<node TEXT="- Did the materials when created have Line Code (or Stable Line BE BID)?" ID="ID_1240571522" CREATED="1716873129726" MODIFIED="1716873129726"/>
</node>
</node>
</node>
</node>
<node TEXT="CMS" FOLDED="true" ID="ID_181015777" CREATED="1717095073516" MODIFIED="1717095077012">
<node TEXT="Link CMS/Maintainer pairs (if any required)​" ID="ID_19667659" CREATED="1716417064821" MODIFIED="1716417064821"/>
</node>
</node>
<node TEXT="Document Fix" FOLDED="true" ID="ID_130194029" CREATED="1717437825587" MODIFIED="1720481397027">
<font BOLD="true"/>
<node TEXT="Spirit Trait" ID="ID_146709739" CREATED="1717437835312" MODIFIED="1717437842681"/>
</node>
<node TEXT="Submit Ticket" FOLDED="true" ID="ID_904462256" CREATED="1720479124363" MODIFIED="1720481398774">
<font BOLD="true"/>
<node TEXT="Reprocess MBE progeny to correct lineage" ID="ID_1465656435" CREATED="1716417064822" MODIFIED="1716417064822"/>
</node>
</node>
</node>
<node TEXT="Follow up Email" ID="ID_402850224" CREATED="1719247470988" MODIFIED="1719247478920"/>
<node TEXT="Follow up meeting with Each Crop" FOLDED="true" ID="ID_1919800719" CREATED="1718041219469" MODIFIED="1718060917805">
<node TEXT="Check progress" ID="ID_352696963" CREATED="1718060918775" MODIFIED="1718060921969"/>
<node TEXT="See what assistance I can offer" ID="ID_1640677902" CREATED="1718060922575" MODIFIED="1718060927625"/>
</node>
</node>
</node>
<node TEXT="Submit Tickets" FOLDED="true" POSITION="bottom_or_right" ID="ID_1037141831" CREATED="1737399286281" MODIFIED="1737399295144">
<node TEXT="Sent" ID="ID_111094061" CREATED="1737399349780" MODIFIED="1737399355788"/>
<node TEXT="Done" ID="ID_270729487" CREATED="1737399356733" MODIFIED="1737399358358"/>
</node>
<node TEXT="Fix POLTP Materials" FOLDED="true" POSITION="bottom_or_right" ID="ID_567054336" CREATED="1737399899623" MODIFIED="1737400114227">
<node TEXT="Email" FOLDED="true" ID="ID_888237854" CREATED="1737399926305" MODIFIED="1737400051108">
<icon BUILTIN="closed"/>
<node ID="ID_895782187" CREATED="1737400060957" MODIFIED="1737400060957"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span class="JdFsz" title="Exceptions: Spirit-IM Database Communication" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-weight: 600; font-size: 12px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; margin-top: 0px; margin-right: 8px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(255, 255, 255); display: inline; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: pre-wrap; background-color: rgb(41, 41, 41);">Exceptions: Spirit-IM Database Communication</span>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="key collaborators" FOLDED="true" POSITION="bottom_or_right" ID="ID_651861070" CREATED="1715792310715" MODIFIED="1716871693848">
<font BOLD="true"/>
<node TEXT="Michele" ID="ID_1136374115" CREATED="1715792317896" MODIFIED="1715792319671"/>
<node TEXT="Mary-Aude" ID="ID_680027716" CREATED="1715792320300" MODIFIED="1715792325313"/>
<node TEXT="Subject Matter Experts (SME)" FOLDED="true" ID="ID_397488560" CREATED="1715615209374" MODIFIED="1717180593273">
<node ID="ID_1755527244" CREATED="1719329940913" MODIFIED="1719329940913" LINK="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/SME_Veg.xlsx?d=w288b88c947644caaa8760fd2b7e3d6e2&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=mypdiq"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/MBE%20Clean%20up/SME_Veg.xlsx?d=w288b88c947644caaa8760fd2b7e3d6e2&amp;csf=1&amp;web=1&amp;e=mypdiq">SME_Veg.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_882346901" CREATED="1739385764667" MODIFIED="1739386869096"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20&amp;%20Trait%20Data%20Stewardship/Identity%20and%20Trait%20Data%20Stewardship%20Notebook/Tools/Phenome/PoC%20Admin.one#Phenome%20PoC&amp;section-id={46369BCD-23FD-47EB-9162-25ABFA823F7C}&amp;page-id={B62DD056-DBD0-49C2-8062-3D8383FA0D1E}&amp;end">Phenome PoC</a>
  </body>
</html>
</richcontent>
<font BOLD="false"/>
<node TEXT="#Do" ID="ID_1392382818" CREATED="1739386869916" MODIFIED="1739386872593"/>
</node>
<node ID="ID_55742030" CREATED="1739386352676" MODIFIED="1739386359564"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20&amp;%20Trait%20Data%20Stewardship/Identity%20and%20Trait%20Data%20Stewardship%20Notebook/Projects/Hollar%20Aquisition.one#section-id={F7133B4E-5651-4B53-BC77-49932CC8151F}&amp;end">Hollar Aquisition</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1095091380" CREATED="1739387362570" MODIFIED="1739387362570" LINK="https://syngenta.service-now.com/nav_to.do?uri=incident.do%3Fsys_id=1ab5ab4893c7da10499336158aba1038%26sysparm_stack=incident_list.do%3Fsysparm_query=active=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table border="0" cellpadding="0" cellspacing="0" width="175" style="width: 131pt">
      <tr height="21" style="height: 15.95pt">
        <td height="21" class="xl65" width="175" style="height: 15.95pt; width: 131pt">
          <a href="https://syngenta.service-now.com/nav_to.do?uri=incident.do%3Fsys_id=1ab5ab4893c7da10499336158aba1038%26sysparm_stack=incident_list.do%3Fsysparm_query=active=true" title="https://syngenta.service-now.com/nav_to.do?uri=incident.do%3Fsys_id=1ab5ab4893c7da10499336158aba1038%26sysparm_stack=incident_list.do%3Fsysparm_query=active=true">INC19527422&#xa0;</a>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Feedback Needed" ID="ID_750718730" CREATED="1738693560103" MODIFIED="1743191660230">
<node TEXT="Email" ID="ID_2822912" CREATED="1739385931297" MODIFIED="1739385937064">
<node ID="ID_1595131072" CREATED="1739385995657" MODIFIED="1739386108687"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://syngenta-my.sharepoint.com/personal/michael_mcmillen_syngenta_com/Documents/Michael%20@%20Syngenta/Administrative.one#Performance%20Management&amp;section-id={11EFB485-4AAE-4CC0-9E52-F47693B4E2C4}&amp;page-id={4AF87400-9A02-4347-94FE-7049ABE8FE74}&amp;end">Performance Management</a>&#xa0;&#xa0;(<a href="https://syngenta-my.sharepoint.com/personal/michael_mcmillen_syngenta_com/_layouts/OneNote.aspx?id=%2Fpersonal%2Fmichael_mcmillen_syngenta_com%2FDocuments%2FMichael%20%40%20Syngenta&amp;wd=target%28Administrative.one%7C11EFB485-4AAE-4CC0-9E52-F47693B4E2C4%2FPerformance%20Management%7C4AF87400-9A02-4347-94FE-7049ABE8FE74%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
<attribute NAME="Due" VALUE="2/28/25" OBJECT="org.freeplane.features.format.FormattedDate|2025-02-28T00:00-0500|date"/>
</node>
<node TEXT="" ID="ID_731027306" CREATED="1739385944123" MODIFIED="1739385944123"/>
</node>
</node>
<node TEXT="Ticket" ID="ID_593010211" CREATED="1743191630606" MODIFIED="1743191637782"/>
<node TEXT="Projects/ Issues" FOLDED="true" ID="ID_364120320" CREATED="1715792157623" MODIFIED="1716402984382">
<font BOLD="true"/>
<node TEXT="(transferred) Identity Management Native Trait Tracing" FOLDED="true" ID="ID_128952482" CREATED="1720625733122" MODIFIED="1721064399222">
<icon BUILTIN="list"/>
<node TEXT="Roadmap for Trait Identity" FOLDED="true" ID="ID_1720072479" CREATED="1720626084789" MODIFIED="1720626114098">
<icon BUILTIN="yes"/>
<node TEXT="Veronique" ID="ID_1782020164" CREATED="1720626117932" MODIFIED="1720626120613"/>
</node>
<node TEXT="Our needs for trait tracking" FOLDED="true" ID="ID_1695834605" CREATED="1720625819140" MODIFIED="1720625840566">
<node TEXT="Inheritance of Traits" ID="ID_338128910" CREATED="1720625911287" MODIFIED="1720625917868"/>
<node TEXT="Will trait identity be replacing Spirit Functionality?" ID="ID_1145575804" CREATED="1720625923303" MODIFIED="1720625940869"/>
<node TEXT="Trait Identity Development" ID="ID_982839570" CREATED="1720625943827" MODIFIED="1720625979606"/>
</node>
</node>
<node ID="ID_1161490158" TREE_ID="ID_1622150356">
<node POSITION="bottom_or_right" ID="ID_290423127" TREE_ID="ID_114744824">
<node ID="ID_801716730" TREE_ID="ID_1675819868">
<node ID="ID_1576381228" TREE_ID="ID_1648023656"/>
</node>
<node ID="ID_616230295" TREE_ID="ID_1412138084"/>
<node ID="ID_1568994390" TREE_ID="ID_1072168160"/>
<node ID="ID_966144387" TREE_ID="ID_1341593430">
<node ID="ID_1263638451" TREE_ID="ID_808644064">
<node ID="ID_1320769111" TREE_ID="ID_697389802">
<node ID="ID_1608346581" TREE_ID="ID_1354736803">
<node ID="ID_270586709" TREE_ID="ID_678094443"/>
</node>
<node ID="ID_206136117" TREE_ID="ID_903065207">
<node ID="ID_524214489" TREE_ID="ID_953611565"/>
<node ID="ID_1828517460" TREE_ID="ID_833166916">
<node ID="ID_1430282979" TREE_ID="ID_921225547"/>
</node>
</node>
<node ID="ID_433796133" TREE_ID="ID_1662138357">
<node ID="ID_1317392659" TREE_ID="ID_1101783268"/>
</node>
<node ID="ID_716072077" TREE_ID="ID_486709957">
<node ID="ID_1470042527" TREE_ID="ID_1212162815"/>
</node>
<node ID="ID_1902226201" TREE_ID="ID_52691862">
<node ID="ID_957850721" TREE_ID="ID_544182708"/>
</node>
<node ID="ID_1201759632" TREE_ID="ID_172122378">
<node ID="ID_1326515237" TREE_ID="ID_755416123"/>
</node>
<node ID="ID_945302878" TREE_ID="ID_371305537">
<node ID="ID_948964424" TREE_ID="ID_63474697"/>
</node>
</node>
</node>
<node ID="ID_104629466" TREE_ID="ID_174708495">
<node ID="ID_613678447" TREE_ID="ID_925903416">
<node ID="ID_1581955294" TREE_ID="ID_593329032">
<node ID="ID_1036841317" TREE_ID="ID_77858093">
<node ID="ID_137690797" TREE_ID="ID_677264525"/>
</node>
<node ID="ID_1733008482" TREE_ID="ID_96781328"/>
<node ID="ID_1799082128" TREE_ID="ID_282277003">
<node ID="ID_262520399" TREE_ID="ID_589795323"/>
</node>
<node ID="ID_608277819" TREE_ID="ID_756918018">
<node ID="ID_1680296355" TREE_ID="ID_808664725"/>
</node>
</node>
</node>
<node ID="ID_953593882" TREE_ID="ID_200062557">
<node ID="ID_1311203030" TREE_ID="ID_810293878">
<node ID="ID_223085446" TREE_ID="ID_1802550515">
<node ID="ID_1342570755" TREE_ID="ID_1073372178"/>
<node ID="ID_1171911251" TREE_ID="ID_329644166"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_438154368" TREE_ID="ID_272257328">
<node ID="ID_1385028386" TREE_ID="ID_1587337136"/>
<node ID="ID_1231401470" TREE_ID="ID_1959167635">
<node ID="ID_1895771352" TREE_ID="ID_407346657"/>
</node>
</node>
<node ID="ID_1910174044" TREE_ID="ID_1408649453">
<node ID="ID_477282032" TREE_ID="ID_1184426261"/>
<node ID="ID_646207302" TREE_ID="ID_475619557">
<node ID="ID_1637239299" TREE_ID="ID_1485955406">
<node ID="ID_410443348" TREE_ID="ID_646470016"/>
<node ID="ID_3027401" TREE_ID="ID_1980597006"/>
</node>
<node ID="ID_1979775969" TREE_ID="ID_262901420">
<node ID="ID_912577343" TREE_ID="ID_69251967">
<node ID="ID_1223490024" TREE_ID="ID_1166759573"/>
<node ID="ID_1478693374" TREE_ID="ID_549145544"/>
</node>
<node ID="ID_1544522887" TREE_ID="ID_1282218650"/>
</node>
</node>
<node ID="ID_1937273033" TREE_ID="ID_1898749700">
<node ID="ID_883940117" TREE_ID="ID_323593953"/>
</node>
<node ID="ID_923003790" TREE_ID="ID_691041826">
<node ID="ID_103833784" TREE_ID="ID_342750978"/>
<node ID="ID_1459507940" TREE_ID="ID_1786702686"/>
<node ID="ID_1630552640" TREE_ID="ID_1406902311"/>
<node ID="ID_817146336" TREE_ID="ID_1547054781"/>
<node ID="ID_436047249" TREE_ID="ID_1712828479"/>
<node ID="ID_747372527" TREE_ID="ID_1353643406"/>
</node>
<node ID="ID_1916122925" TREE_ID="ID_1024079353"/>
<node ID="ID_1895377012" TREE_ID="ID_875516056"/>
<node ID="ID_1715430378" TREE_ID="ID_1274719821">
<node ID="ID_1513034949" TREE_ID="ID_1892173623"/>
<node ID="ID_781812957" TREE_ID="ID_1519293086"/>
</node>
<node ID="ID_1759708349" TREE_ID="ID_400525641">
<node ID="ID_1291598172" TREE_ID="ID_865910132">
<node ID="ID_696668368" TREE_ID="ID_1763882610"/>
<node ID="ID_1403653055" TREE_ID="ID_618601487"/>
</node>
<node ID="ID_1402557050" TREE_ID="ID_470697690"/>
<node ID="ID_1336284563" TREE_ID="ID_310521887">
<node ID="ID_924349741" TREE_ID="ID_1816164398"/>
</node>
</node>
<node ID="ID_1700670257" TREE_ID="ID_1677756188">
<node ID="ID_168898613" TREE_ID="ID_219441470"/>
</node>
</node>
<node ID="ID_1763971865" TREE_ID="ID_762186699">
<node ID="ID_494818719" TREE_ID="ID_177909570">
<node ID="ID_284871025" CONTENT_ID="ID_1587337136"/>
</node>
<node ID="ID_1695031634" TREE_ID="ID_1561940335"/>
<node ID="ID_1039779950" TREE_ID="ID_1542116123"/>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_451355525" TREE_ID="ID_1040425489">
<node ID="ID_520546966" TREE_ID="ID_494101793">
<node ID="ID_1371959203" TREE_ID="ID_1295222821">
<node ID="ID_893838199" TREE_ID="ID_1618255624"/>
</node>
<node ID="ID_39466326" TREE_ID="ID_1548640473">
<node ID="ID_599316466" TREE_ID="ID_1090012634">
<node ID="ID_554434687" TREE_ID="ID_1684723252">
<node ID="ID_949007439" TREE_ID="ID_1966496053"/>
<node ID="ID_1674887307" TREE_ID="ID_1709065880"/>
<node ID="ID_1955316492" TREE_ID="ID_962153682">
<node ID="ID_215669272" TREE_ID="ID_593315971">
<node ID="ID_1314280363" TREE_ID="ID_22481248">
<node ID="ID_1974225661" TREE_ID="ID_1815961243">
<node ID="ID_1603040916" TREE_ID="ID_289985125">
<node ID="ID_344113725" TREE_ID="ID_329660836"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_307379817" TREE_ID="ID_544294901"/>
<node ID="ID_543038745" TREE_ID="ID_1266636964"/>
<node ID="ID_1126566437" TREE_ID="ID_1441941811">
<node ID="ID_398576707" TREE_ID="ID_1186863893">
<node ID="ID_195702026" TREE_ID="ID_69076925"/>
<node ID="ID_879525545" TREE_ID="ID_799495607">
<node ID="ID_820781487" TREE_ID="ID_1334307869"/>
<node ID="ID_1441236510" TREE_ID="ID_1518032914"/>
</node>
</node>
</node>
<node ID="ID_1862133048" TREE_ID="ID_1469909171">
<node ID="ID_860931892" TREE_ID="ID_1344370561">
<node ID="ID_1643038338" TREE_ID="ID_748030573"/>
</node>
</node>
<node ID="ID_152566388" TREE_ID="ID_1833454613"/>
<node ID="ID_1684956330" TREE_ID="ID_985163255">
<node ID="ID_1898936401" TREE_ID="ID_1799732326"/>
</node>
</node>
<node ID="ID_1203761735" TREE_ID="ID_799257618"/>
<node ID="ID_398218670" TREE_ID="ID_1864885996">
<node ID="ID_1759409566" TREE_ID="ID_1076220124"/>
</node>
</node>
<node ID="ID_864889207" TREE_ID="ID_23613990">
<node ID="ID_1477131987" TREE_ID="ID_539142152"/>
</node>
</node>
<node ID="ID_188407292" TREE_ID="ID_107100276">
<node ID="ID_991888925" TREE_ID="ID_1811884828"/>
</node>
<node ID="ID_962384848" TREE_ID="ID_181676330">
<node ID="ID_404200730" TREE_ID="ID_1521256150">
<node ID="ID_902973684" TREE_ID="ID_1087094263"/>
<node ID="ID_403733308" TREE_ID="ID_429216299"/>
</node>
</node>
<node ID="ID_737382477" TREE_ID="ID_1087320689">
<node ID="ID_1692390168" TREE_ID="ID_925461297"/>
<node ID="ID_674106810" TREE_ID="ID_1890446112">
<node ID="ID_362658920" TREE_ID="ID_133893544"/>
</node>
<node ID="ID_1653286930" TREE_ID="ID_1947488786">
<node ID="ID_1494146774" TREE_ID="ID_769403582">
<node ID="ID_757809371" TREE_ID="ID_1678051479"/>
</node>
</node>
<node ID="ID_437086864" TREE_ID="ID_928199408">
<node ID="ID_554144509" TREE_ID="ID_1638248557"/>
</node>
<node ID="ID_940390207" TREE_ID="ID_680698101">
<node ID="ID_1538083884" TREE_ID="ID_1571758653"/>
<node ID="ID_366179870" TREE_ID="ID_357314509"/>
<node ID="ID_764089024" TREE_ID="ID_1511699442">
<node ID="ID_211273825" TREE_ID="ID_1065125409"/>
</node>
</node>
<node ID="ID_1787313874" TREE_ID="ID_1944674053">
<node ID="ID_196668931" TREE_ID="ID_1583631948"/>
</node>
<node ID="ID_939242789" TREE_ID="ID_574066061">
<node ID="ID_1036919832" TREE_ID="ID_1603368068">
<node ID="ID_1283577492" TREE_ID="ID_1236581485">
<node ID="ID_1361614763" TREE_ID="ID_783623084"/>
<node ID="ID_127181507" TREE_ID="ID_38855085"/>
</node>
</node>
</node>
</node>
<node ID="ID_113446212" TREE_ID="ID_1662442903">
<node ID="ID_1895160772" TREE_ID="ID_789628824">
<node ID="ID_1909366913" TREE_ID="ID_758758514">
<node ID="ID_709171790" TREE_ID="ID_1038143854"/>
</node>
<node ID="ID_1771971896" TREE_ID="ID_1980403210">
<node ID="ID_345185070" TREE_ID="ID_1726625690">
<node ID="ID_530823710" TREE_ID="ID_1295678317"/>
<node ID="ID_740582434" TREE_ID="ID_1249155642">
<node ID="ID_1071567705" TREE_ID="ID_79733480"/>
<node ID="ID_832908071" TREE_ID="ID_206468509">
<node ID="ID_254605777" TREE_ID="ID_1768050153"/>
</node>
</node>
<node ID="ID_899748992" TREE_ID="ID_790142568">
<node ID="ID_659189080" TREE_ID="ID_736496220"/>
</node>
<node ID="ID_1911455992" TREE_ID="ID_698994150">
<node ID="ID_1657133491" TREE_ID="ID_689608680"/>
<node ID="ID_499514381" TREE_ID="ID_1713139331"/>
</node>
<node ID="ID_428205167" TREE_ID="ID_1057213635">
<node ID="ID_1961631738" TREE_ID="ID_1732163526"/>
<node ID="ID_1348873022" TREE_ID="ID_475536648">
<node ID="ID_1470572738" TREE_ID="ID_1471466774"/>
</node>
</node>
<node ID="ID_758081706" TREE_ID="ID_1243899754">
<node ID="ID_608963127" TREE_ID="ID_1638996376"/>
<node ID="ID_1390487573" TREE_ID="ID_1812462462"/>
<node ID="ID_172460800" TREE_ID="ID_1696504647"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1147442098" TREE_ID="ID_1726625690">
<node ID="ID_827251546" TREE_ID="ID_1295678317"/>
<node ID="ID_1215617816" TREE_ID="ID_1249155642">
<node ID="ID_1019782582" TREE_ID="ID_79733480"/>
<node ID="ID_1386565814" TREE_ID="ID_206468509">
<node ID="ID_1989407932" TREE_ID="ID_1768050153"/>
</node>
</node>
<node ID="ID_464151020" TREE_ID="ID_790142568">
<node ID="ID_952672498" TREE_ID="ID_736496220"/>
</node>
<node ID="ID_840427449" TREE_ID="ID_698994150">
<node ID="ID_146338751" TREE_ID="ID_689608680"/>
<node ID="ID_732054652" TREE_ID="ID_1713139331"/>
</node>
<node ID="ID_1068556682" TREE_ID="ID_1057213635">
<node ID="ID_805503453" TREE_ID="ID_1732163526"/>
<node ID="ID_366024093" TREE_ID="ID_475536648">
<node ID="ID_701890643" TREE_ID="ID_1471466774"/>
</node>
</node>
<node ID="ID_1262504979" TREE_ID="ID_1243899754">
<node ID="ID_1914578442" TREE_ID="ID_1638996376"/>
<node ID="ID_294359760" TREE_ID="ID_1812462462"/>
<node ID="ID_1602495120" TREE_ID="ID_1696504647"/>
</node>
</node>
<node ID="ID_292255927" TREE_ID="ID_915190982">
<node ID="ID_1286462167" TREE_ID="ID_1215247997"/>
</node>
<node ID="ID_1143953342" TREE_ID="ID_370640114">
<node POSITION="bottom_or_right" ID="ID_1259063881" TREE_ID="ID_1130267107"/>
<node POSITION="bottom_or_right" ID="ID_716873304" TREE_ID="ID_1778360976">
<node ID="ID_484530674" TREE_ID="ID_1705238931">
<node ID="ID_296899559" TREE_ID="ID_1141854625"/>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_1654603622" TREE_ID="ID_139133939">
<node ID="ID_1403406202" TREE_ID="ID_110367319">
<node ID="ID_629768663" TREE_ID="ID_181410077"/>
</node>
<node ID="ID_1374938106" TREE_ID="ID_421891300">
<node ID="ID_1966983654" TREE_ID="ID_1904347377">
<node ID="ID_807641184" TREE_ID="ID_208760073"/>
</node>
</node>
<node ID="ID_1507066657" TREE_ID="ID_1091931019">
<node ID="ID_875147854" TREE_ID="ID_1228513810"/>
</node>
</node>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_1501375717" TREE_ID="ID_1357766553">
<node ID="ID_1278039680" TREE_ID="ID_788309612"/>
</node>
<node POSITION="bottom_or_right" ID="ID_904424499" TREE_ID="ID_1129945756">
<node ID="ID_520421475" TREE_ID="ID_1592678049"/>
<node ID="ID_734544940" TREE_ID="ID_1668918675"/>
</node>
<node POSITION="bottom_or_right" ID="ID_816667384" TREE_ID="ID_741790450">
<node POSITION="bottom_or_right" ID="ID_19622163" TREE_ID="ID_441111747">
<node ID="ID_1625265374" TREE_ID="ID_1239255670"/>
<node ID="ID_1190007946" TREE_ID="ID_1400433292"/>
<node ID="ID_386047759" TREE_ID="ID_211451090">
<node ID="ID_831384248" TREE_ID="ID_530385201">
<node ID="ID_931638760" TREE_ID="ID_1350846327"/>
</node>
<node ID="ID_1612746900" TREE_ID="ID_79235655"/>
<node ID="ID_849663299" TREE_ID="ID_588124249">
<node ID="ID_727449369" TREE_ID="ID_372715237"/>
</node>
<node ID="ID_164238125" TREE_ID="ID_492682643"/>
<node ID="ID_1053208909" TREE_ID="ID_770048968"/>
<node ID="ID_1905158460" TREE_ID="ID_877354798"/>
<node ID="ID_1491199368" TREE_ID="ID_1819306437"/>
</node>
<node ID="ID_1127379655" TREE_ID="ID_1386950334">
<node ID="ID_239770092" TREE_ID="ID_162454548">
<node ID="ID_375803962" TREE_ID="ID_945260664"/>
</node>
</node>
<node ID="ID_647774959" TREE_ID="ID_1194745404">
<node ID="ID_1906448401" TREE_ID="ID_1665457409">
<node ID="ID_58332095" TREE_ID="ID_1204210680">
<node ID="ID_995057174" TREE_ID="ID_1962113201"/>
</node>
</node>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_473322046" TREE_ID="ID_214722856">
<node ID="ID_877812564" TREE_ID="ID_897173080"/>
<node ID="ID_1835328500" TREE_ID="ID_1501269749">
<node ID="ID_978463914" TREE_ID="ID_1859340245">
<node ID="ID_361241058" TREE_ID="ID_1496675336">
<node ID="ID_1648839586" TREE_ID="ID_705473371">
<node ID="ID_340146247" TREE_ID="ID_546799376"/>
<node ID="ID_1642137501" TREE_ID="ID_1213983188"/>
</node>
</node>
<node ID="ID_940601440" TREE_ID="ID_1616556231">
<node ID="ID_898440152" TREE_ID="ID_1926392492">
<node ID="ID_1428274545" TREE_ID="ID_1801482721">
<node ID="ID_310170803" TREE_ID="ID_933349316">
<node ID="ID_1277465106" TREE_ID="ID_682908551">
<node ID="ID_1718380363" TREE_ID="ID_1249226081"/>
</node>
<node ID="ID_1055344266" TREE_ID="ID_885140380">
<node ID="ID_123374036" TREE_ID="ID_851306498"/>
<node ID="ID_692019592" TREE_ID="ID_135774650">
<node ID="ID_1903334573" TREE_ID="ID_1979090234"/>
</node>
</node>
<node ID="ID_1458963129" TREE_ID="ID_568174176">
<node ID="ID_256908309" TREE_ID="ID_68404411"/>
</node>
<node ID="ID_1311916798" TREE_ID="ID_287613">
<node ID="ID_1276885353" TREE_ID="ID_678460398"/>
</node>
<node ID="ID_1091789787" TREE_ID="ID_716784668">
<node ID="ID_474459077" TREE_ID="ID_1508296839"/>
</node>
<node ID="ID_61735167" TREE_ID="ID_261853326">
<node ID="ID_448086169" TREE_ID="ID_1661535649"/>
</node>
<node ID="ID_1348433971" TREE_ID="ID_179434782">
<node ID="ID_1521350229" TREE_ID="ID_39826223"/>
</node>
</node>
</node>
<node ID="ID_887840328" TREE_ID="ID_961190636">
<node ID="ID_710293728" TREE_ID="ID_1738819727">
<node ID="ID_1130515212" TREE_ID="ID_1415010570"/>
</node>
<node ID="ID_1660452265" TREE_ID="ID_1663454002"/>
<node ID="ID_538627988" TREE_ID="ID_1078108563"/>
<node ID="ID_1062470341" TREE_ID="ID_875023255"/>
<node ID="ID_1682721082" TREE_ID="ID_1937789359">
<node ID="ID_285277949" TREE_ID="ID_1243102511"/>
</node>
</node>
<node ID="ID_1827712759" TREE_ID="ID_1031842057">
<node ID="ID_1752055538" TREE_ID="ID_738256747"/>
<node ID="ID_1701756319" TREE_ID="ID_90016621"/>
</node>
</node>
<node ID="ID_913455429" TREE_ID="ID_1655417134"/>
</node>
<node ID="ID_683465237" TREE_ID="ID_434125119">
<node ID="ID_1582646190" TREE_ID="ID_1559873706">
<node ID="ID_253298240" TREE_ID="ID_1187289531">
<node ID="ID_1421949514" TREE_ID="ID_572245367"/>
</node>
<node ID="ID_1392360846" TREE_ID="ID_1172257351"/>
<node ID="ID_914646784" TREE_ID="ID_1314474188"/>
<node ID="ID_399119879" TREE_ID="ID_1388454321"/>
</node>
<node ID="ID_1740750846" TREE_ID="ID_1624453897">
<node ID="ID_1214770189" TREE_ID="ID_1436420844"/>
<node ID="ID_473226633" TREE_ID="ID_1462775205"/>
<node ID="ID_1441164140" TREE_ID="ID_275034208"/>
<node ID="ID_568477481" TREE_ID="ID_523300765"/>
<node ID="ID_1330956488" TREE_ID="ID_1550032646"/>
<node ID="ID_1007657740" TREE_ID="ID_1882741964"/>
<node ID="ID_73858942" TREE_ID="ID_1004851370"/>
<node ID="ID_143483265" TREE_ID="ID_1281967601"/>
<node ID="ID_423976939" TREE_ID="ID_1457394819"/>
<node ID="ID_664467831" TREE_ID="ID_1871728520"/>
<node ID="ID_1478565127" TREE_ID="ID_1251396813"/>
</node>
</node>
</node>
<node ID="ID_1865642058" TREE_ID="ID_889857755">
<node ID="ID_1600463687" TREE_ID="ID_1885478222">
<node ID="ID_1884516711" TREE_ID="ID_744331944">
<node ID="ID_328624315" TREE_ID="ID_1236058475"/>
</node>
</node>
<node ID="ID_1488521154" TREE_ID="ID_244220994">
<node POSITION="bottom_or_right" ID="ID_938668018" TREE_ID="ID_1431234292">
<node ID="ID_960279791" TREE_ID="ID_1340056092"/>
</node>
</node>
<node ID="ID_480562052" TREE_ID="ID_1800624190">
<node ID="ID_1236623813" TREE_ID="ID_903442940">
<node ID="ID_1988789398" TREE_ID="ID_812347320">
<node ID="ID_1970814004" TREE_ID="ID_747536014">
<node ID="ID_240191225" TREE_ID="ID_476998532"/>
</node>
</node>
<node ID="ID_1886520006" TREE_ID="ID_1743437188">
<node ID="ID_676857005" TREE_ID="ID_1709268982">
<node ID="ID_1556465142" TREE_ID="ID_210123180"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1885750237" TREE_ID="ID_1178880202">
<node POSITION="bottom_or_right" ID="ID_395495382" TREE_ID="ID_542540691">
<node ID="ID_293506623" TREE_ID="ID_1498622743"/>
<node ID="ID_1653581674" TREE_ID="ID_1752391854"/>
</node>
<node ID="ID_528797634" TREE_ID="ID_1160214762">
<node ID="ID_1972949866" TREE_ID="ID_1806105197"/>
</node>
<node ID="ID_1503199104" TREE_ID="ID_550316745">
<node ID="ID_1308558163" TREE_ID="ID_1353976308">
<node ID="ID_990850765" TREE_ID="ID_761058578"/>
</node>
<node ID="ID_1093096033" TREE_ID="ID_631834330">
<node ID="ID_1847122585" TREE_ID="ID_1805796466">
<node ID="ID_644506911" TREE_ID="ID_580365030"/>
<node ID="ID_327007697" TREE_ID="ID_1692214555"/>
<node ID="ID_1442373636" TREE_ID="ID_1748342401"/>
<node ID="ID_658239744" TREE_ID="ID_558612883"/>
</node>
</node>
<node ID="ID_382082318" TREE_ID="ID_1313997841">
<node ID="ID_1035296111" TREE_ID="ID_1588945938"/>
</node>
</node>
<node ID="ID_1853237883" TREE_ID="ID_1320414242">
<node ID="ID_169646039" TREE_ID="ID_1104666750">
<node ID="ID_1223109273" TREE_ID="ID_1690766651">
<node ID="ID_1708561574" TREE_ID="ID_1543648621"/>
</node>
</node>
<node ID="ID_769490687" TREE_ID="ID_1904967206">
<node POSITION="bottom_or_right" ID="ID_1364671361" TREE_ID="ID_1751710309"/>
</node>
<node ID="ID_99961366" TREE_ID="ID_75036459"/>
</node>
<node ID="ID_201428930" TREE_ID="ID_637232253">
<node ID="ID_1045096899" TREE_ID="ID_180046607"/>
<node ID="ID_1918519014" TREE_ID="ID_1302404517">
<node ID="ID_487137945" TREE_ID="ID_1604288276"/>
</node>
<node ID="ID_1817662117" TREE_ID="ID_1147476479">
<node ID="ID_1635372193" TREE_ID="ID_1363994142"/>
</node>
<node ID="ID_998738788" TREE_ID="ID_1510896819"/>
<node ID="ID_612907575" TREE_ID="ID_56693287"/>
<node ID="ID_32719035" TREE_ID="ID_1375594264"/>
</node>
<node ID="ID_565664656" TREE_ID="ID_1294394096">
<node ID="ID_331852587" TREE_ID="ID_1082118198">
<node ID="ID_677394233" TREE_ID="ID_1983860610"/>
<node ID="ID_1402531752" TREE_ID="ID_1701611853"/>
<node ID="ID_205707579" TREE_ID="ID_407106187"/>
<node ID="ID_583671671" TREE_ID="ID_1546279485"/>
</node>
</node>
</node>
<node ID="ID_1839880837" TREE_ID="ID_940727793">
<node ID="ID_643514722" TREE_ID="ID_2607579">
<node ID="ID_1364316619" TREE_ID="ID_1416805613"/>
</node>
</node>
<node ID="ID_470437164" TREE_ID="ID_1855787081">
<node ID="ID_66353748" TREE_ID="ID_561379855"/>
</node>
<node ID="ID_1058723170" TREE_ID="ID_1631054848">
<node ID="ID_617553445" TREE_ID="ID_1078098553">
<node POSITION="bottom_or_right" ID="ID_1534340579" TREE_ID="ID_946822301"/>
<node ID="ID_1625741644" TREE_ID="ID_957776869"/>
<node POSITION="bottom_or_right" ID="ID_1343806772" TREE_ID="ID_1738512556"/>
</node>
<node ID="ID_1230359477" TREE_ID="ID_639289168"/>
<node ID="ID_896270900" TREE_ID="ID_872933169">
<node ID="ID_863727268" TREE_ID="ID_1838057116">
<node ID="ID_1388732517" TREE_ID="ID_1288989327">
<node ID="ID_1805811441" TREE_ID="ID_639361269"/>
</node>
<node ID="ID_1397117815" TREE_ID="ID_573914718">
<node ID="ID_1414509165" TREE_ID="ID_1611583520">
<node ID="ID_1525857295" TREE_ID="ID_723005507"/>
<node ID="ID_909897996" TREE_ID="ID_1416560877"/>
</node>
</node>
<node ID="ID_672511229" TREE_ID="ID_599309414">
<node ID="ID_341168429" TREE_ID="ID_626435999">
<node ID="ID_553775390" TREE_ID="ID_1581623832">
<node ID="ID_869079475" TREE_ID="ID_740625183"/>
</node>
<node ID="ID_1647478813" TREE_ID="ID_1029242873">
<node ID="ID_928512944" TREE_ID="ID_980745309">
<node ID="ID_1449900103" TREE_ID="ID_1319239091"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1943935448" TREE_ID="ID_189791567"/>
<node ID="ID_576842514" TREE_ID="ID_183577000">
<node ID="ID_793831842" TREE_ID="ID_187705823">
<node ID="ID_1967901531" TREE_ID="ID_1586140274"/>
<node ID="ID_1723416021" TREE_ID="ID_525277193"/>
</node>
<node ID="ID_747210939" TREE_ID="ID_602793530">
<node ID="ID_1129147502" TREE_ID="ID_152840157">
<node ID="ID_768343390" TREE_ID="ID_482408539"/>
<node ID="ID_1024146678" TREE_ID="ID_1384458974"/>
</node>
<node ID="ID_216350827" TREE_ID="ID_875595685"/>
<node ID="ID_1654628137" TREE_ID="ID_1443219014"/>
<node ID="ID_1937276930" TREE_ID="ID_955499935">
<node ID="ID_1837998167" TREE_ID="ID_689987670"/>
<node ID="ID_1812490437" TREE_ID="ID_777900531">
<node ID="ID_1104468339" TREE_ID="ID_127040706">
<node ID="ID_1750578206" TREE_ID="ID_837059716">
<node ID="ID_1032476395" TREE_ID="ID_1286670155"/>
</node>
</node>
<node ID="ID_1087748910" TREE_ID="ID_907818215"/>
</node>
</node>
</node>
<node ID="ID_130078814" TREE_ID="ID_719506716">
<node ID="ID_1144201799" TREE_ID="ID_205872408"/>
<node ID="ID_1548676116" TREE_ID="ID_1231903579">
<node ID="ID_1990042916" TREE_ID="ID_14572543"/>
<node ID="ID_1221121273" TREE_ID="ID_1959705181">
<node ID="ID_1096182610" TREE_ID="ID_1060926903">
<node ID="ID_1617327346" TREE_ID="ID_1856900808"/>
<node ID="ID_170787480" TREE_ID="ID_1919327056">
<node ID="ID_1955680648" TREE_ID="ID_1440132770"/>
<node ID="ID_495110062" TREE_ID="ID_1353359119"/>
<node ID="ID_1982848249" TREE_ID="ID_1079611620"/>
</node>
<node ID="ID_463344851" TREE_ID="ID_845381671">
<node ID="ID_49247234" TREE_ID="ID_1353779949"/>
</node>
</node>
</node>
<node ID="ID_1350574592" TREE_ID="ID_1763552614"/>
<node ID="ID_924511511" TREE_ID="ID_890986090">
<node ID="ID_1749995297" TREE_ID="ID_898766643"/>
</node>
<node ID="ID_695978284" TREE_ID="ID_253683173">
<node ID="ID_652724898" TREE_ID="ID_201237512">
<node ID="ID_1699664486" TREE_ID="ID_1710103531">
<node ID="ID_1174216948" TREE_ID="ID_621980713">
<node ID="ID_1205851448" TREE_ID="ID_1486895582"/>
<node ID="ID_478630139" TREE_ID="ID_1017236944">
<node ID="ID_221409377" TREE_ID="ID_998871433"/>
<node ID="ID_1938994893" TREE_ID="ID_1287138517"/>
</node>
</node>
</node>
<node ID="ID_913683130" TREE_ID="ID_883658731">
<node ID="ID_145596088" TREE_ID="ID_1807019009"/>
</node>
<node ID="ID_500213764" TREE_ID="ID_1215614098">
<node ID="ID_801561357" TREE_ID="ID_144886780">
<node ID="ID_1956488160" TREE_ID="ID_1860958822">
<node ID="ID_1433475901" TREE_ID="ID_1659689110">
<node ID="ID_995393673" TREE_ID="ID_1709873548"/>
<node ID="ID_154161296" TREE_ID="ID_1885834963">
<node ID="ID_1184407023" TREE_ID="ID_499400460"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1466969891" TREE_ID="ID_247525075">
<node ID="ID_305574390" TREE_ID="ID_1531335524">
<node ID="ID_766578973" TREE_ID="ID_56356808">
<node ID="ID_1197813954" TREE_ID="ID_1105026319"/>
</node>
</node>
<node ID="ID_687752454" TREE_ID="ID_467743691"/>
</node>
</node>
</node>
</node>
<node ID="ID_1171144252" TREE_ID="ID_460671930"/>
<node ID="ID_1017054297" TREE_ID="ID_672617050"/>
<node ID="ID_1748786004" TREE_ID="ID_1382491418">
<node ID="ID_645071821" TREE_ID="ID_1275854840">
<node ID="ID_1796415507" TREE_ID="ID_658240932">
<node ID="ID_272690794" TREE_ID="ID_487785777">
<node ID="ID_898466948" TREE_ID="ID_1206672065">
<node ID="ID_1438782218" TREE_ID="ID_1722736677"/>
<node ID="ID_585098699" TREE_ID="ID_1858541272">
<node ID="ID_1917842104" TREE_ID="ID_425515242"/>
<node ID="ID_1804049364" TREE_ID="ID_1599849203"/>
</node>
</node>
</node>
<node ID="ID_527087950" TREE_ID="ID_514932213">
<node ID="ID_1153971264" TREE_ID="ID_547625180"/>
</node>
<node ID="ID_35727768" TREE_ID="ID_1241947068">
<node ID="ID_1347891261" TREE_ID="ID_398364796">
<node ID="ID_1523537609" TREE_ID="ID_1752534244">
<node ID="ID_132393945" TREE_ID="ID_351572702">
<node ID="ID_138550495" TREE_ID="ID_1077493679"/>
<node ID="ID_1584418129" TREE_ID="ID_344548815">
<node ID="ID_1152732584" TREE_ID="ID_250491204"/>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_745145121" TREE_ID="ID_1686328532">
<node ID="ID_1640270831" TREE_ID="ID_1964765363">
<node ID="ID_1792048944" TREE_ID="ID_1500309162">
<node ID="ID_1700965707" TREE_ID="ID_1124221349"/>
</node>
</node>
<node ID="ID_1423384105" TREE_ID="ID_1052822068"/>
</node>
</node>
</node>
<node ID="ID_883552362" TREE_ID="ID_1987393997">
<node ID="ID_337967156" TREE_ID="ID_947223144"/>
<node ID="ID_1836228141" TREE_ID="ID_1339669583"/>
<node ID="ID_862881478" TREE_ID="ID_908103245">
<node ID="ID_1447961272" TREE_ID="ID_1287916396">
<node ID="ID_243564002" TREE_ID="ID_905488611"/>
</node>
<node ID="ID_254118182" TREE_ID="ID_1641393217"/>
<node ID="ID_166649048" TREE_ID="ID_1079612634">
<node ID="ID_1195505215" TREE_ID="ID_383651395"/>
</node>
<node ID="ID_597250264" TREE_ID="ID_738763935">
<node ID="ID_1723100378" TREE_ID="ID_1700397774">
<node ID="ID_550643036" TREE_ID="ID_167193631">
<node ID="ID_1876497063" TREE_ID="ID_469365409"/>
</node>
<node ID="ID_23041019" TREE_ID="ID_1301894430"/>
</node>
<node ID="ID_1273057548" TREE_ID="ID_1303026608"/>
<node ID="ID_1034398837" TREE_ID="ID_953727310">
<node ID="ID_136843344" TREE_ID="ID_1840605951">
<node ID="ID_489931973" TREE_ID="ID_1143643537">
<node ID="ID_602598431" TREE_ID="ID_1696292069">
<node ID="ID_169474302" TREE_ID="ID_1030588869"/>
<node ID="ID_186855962" TREE_ID="ID_1487302253"/>
</node>
</node>
<node ID="ID_663887037" TREE_ID="ID_1414207954">
<node ID="ID_1550924977" TREE_ID="ID_1919594374">
<node ID="ID_846735814" TREE_ID="ID_1347375329"/>
</node>
</node>
<node ID="ID_806551260" TREE_ID="ID_555911608">
<node ID="ID_1787785944" TREE_ID="ID_1899477633">
<node ID="ID_489320156" TREE_ID="ID_1416690864"/>
<node ID="ID_482404206" TREE_ID="ID_1164032968">
<node ID="ID_816095425" TREE_ID="ID_1316994425"/>
<node ID="ID_473035099" TREE_ID="ID_1838336356">
<node ID="ID_383792833" TREE_ID="ID_1410877929">
<node ID="ID_1350720726" TREE_ID="ID_1361397619"/>
<node ID="ID_1742978191" TREE_ID="ID_1885896891"/>
</node>
</node>
</node>
</node>
<node ID="ID_126975621" TREE_ID="ID_853299977">
<node ID="ID_175788765" TREE_ID="ID_1565519795">
<node ID="ID_898027658" TREE_ID="ID_903440271">
<node ID="ID_276477547" TREE_ID="ID_247236017"/>
<node ID="ID_1675306687" TREE_ID="ID_1696733382"/>
<node ID="ID_1074025482" TREE_ID="ID_457312042"/>
</node>
</node>
<node ID="ID_1750892559" TREE_ID="ID_133650414"/>
<node ID="ID_734381637" TREE_ID="ID_363171290">
<node ID="ID_621952588" TREE_ID="ID_337609461"/>
</node>
</node>
<node ID="ID_378626080" TREE_ID="ID_956785590">
<node ID="ID_354946704" TREE_ID="ID_1890183241"/>
</node>
<node ID="ID_57126417" TREE_ID="ID_1547480275">
<node ID="ID_614520428" TREE_ID="ID_1084117836">
<node ID="ID_1195448888" TREE_ID="ID_1798037965"/>
<node ID="ID_80941694" TREE_ID="ID_1125034139">
<node ID="ID_355457300" TREE_ID="ID_1788469367">
<node ID="ID_1273245667" TREE_ID="ID_368074012"/>
<node ID="ID_1449054927" TREE_ID="ID_316867951">
<node ID="ID_1406502045" TREE_ID="ID_848463535"/>
</node>
</node>
<node ID="ID_1459343728" TREE_ID="ID_1647069393"/>
</node>
</node>
<node ID="ID_947781646" TREE_ID="ID_1702878028">
<node ID="ID_348488484" TREE_ID="ID_526198460"/>
</node>
<node ID="ID_911087793" TREE_ID="ID_749036629">
<node ID="ID_1577526432" TREE_ID="ID_1163593436">
<node ID="ID_255099897" TREE_ID="ID_98652698"/>
</node>
<node ID="ID_417338782" TREE_ID="ID_394809843">
<node ID="ID_1735362485" TREE_ID="ID_1144569494">
<node ID="ID_1150759118" TREE_ID="ID_79780043"/>
<node ID="ID_186307714" TREE_ID="ID_923670180"/>
</node>
<node ID="ID_1276505460" TREE_ID="ID_76727758"/>
<node ID="ID_1435635583" TREE_ID="ID_1338791425"/>
<node ID="ID_915651542" TREE_ID="ID_1902375155"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node ID="ID_1041646579" TREE_ID="ID_988318851"/>
<node ID="ID_777325844" TREE_ID="ID_651414052">
<node ID="ID_190706660" TREE_ID="ID_1404342614">
<node ID="ID_673809127" TREE_ID="ID_1857772434"/>
</node>
</node>
</node>
<node ID="ID_617386010" TREE_ID="ID_514498604"/>
<node ID="ID_890507412" TREE_ID="ID_532494871"/>
<node ID="ID_1699528353" TREE_ID="ID_725587405">
<node ID="ID_199370822" TREE_ID="ID_485949388">
<node ID="ID_520335569" TREE_ID="ID_951079019">
<node ID="ID_1021313435" TREE_ID="ID_1527782450">
<node ID="ID_275464987" TREE_ID="ID_347059921">
<node ID="ID_491996376" TREE_ID="ID_201667923">
<node ID="ID_908967756" TREE_ID="ID_1874851033">
<node ID="ID_1119363457" TREE_ID="ID_52207326">
<node ID="ID_1057918441" TREE_ID="ID_1443819238"/>
</node>
</node>
</node>
</node>
<node ID="ID_678504489" TREE_ID="ID_1841291917">
<node ID="ID_1711327752" TREE_ID="ID_1404712117"/>
<node ID="ID_899560729" TREE_ID="ID_1571226761"/>
</node>
</node>
</node>
</node>
<node ID="ID_1915700188" TREE_ID="ID_1930510953"/>
</node>
</node>
</node>
</node>
<node ID="ID_322621098" TREE_ID="ID_1403224563">
<node ID="ID_150022116" TREE_ID="ID_1526697139">
<node ID="ID_368330238" TREE_ID="ID_689642339"/>
<node ID="ID_1992118719" TREE_ID="ID_481405688">
<node ID="ID_1900700846" TREE_ID="ID_1663999014"/>
<node ID="ID_1282412751" TREE_ID="ID_730819714"/>
<node ID="ID_721073564" TREE_ID="ID_741317334"/>
</node>
<node ID="ID_1696253409" TREE_ID="ID_1967033842">
<node ID="ID_374736520" TREE_ID="ID_735095636"/>
</node>
</node>
<node ID="ID_1483925928" TREE_ID="ID_187315711">
<node ID="ID_1943111982" TREE_ID="ID_15493073"/>
</node>
<node ID="ID_450374903" TREE_ID="ID_383973750">
<node ID="ID_197222648" TREE_ID="ID_35718568">
<node ID="ID_244993415" TREE_ID="ID_409714270"/>
<node ID="ID_1603632270" TREE_ID="ID_156621029"/>
</node>
<node ID="ID_1082971786" TREE_ID="ID_1341845707">
<node ID="ID_199752515" TREE_ID="ID_1696666356"/>
</node>
</node>
<node ID="ID_1159621111" TREE_ID="ID_1515003849">
<node ID="ID_1833591438" TREE_ID="ID_65755413">
<node ID="ID_754450574" TREE_ID="ID_1441711134"/>
<node ID="ID_563238527" TREE_ID="ID_1802832584">
<node ID="ID_1740099712" TREE_ID="ID_331445689"/>
<node ID="ID_168637737" TREE_ID="ID_554415198"/>
<node ID="ID_502218309" TREE_ID="ID_1709655526"/>
</node>
<node ID="ID_1684449502" TREE_ID="ID_92837821">
<node ID="ID_1516135967" TREE_ID="ID_682545941"/>
</node>
</node>
</node>
</node>
<node ID="ID_6426010" TREE_ID="ID_112231332">
<node ID="ID_668256123" TREE_ID="ID_457685533">
<node ID="ID_1109813516" TREE_ID="ID_701401971">
<node ID="ID_405643441" TREE_ID="ID_1284274807"/>
</node>
<node ID="ID_119031750" TREE_ID="ID_546203100">
<node ID="ID_1392136835" TREE_ID="ID_401286620"/>
<node ID="ID_788516114" TREE_ID="ID_1688770264"/>
</node>
<node ID="ID_529587769" TREE_ID="ID_1960121474">
<node ID="ID_154775959" TREE_ID="ID_975136999"/>
<node ID="ID_398485678" TREE_ID="ID_1713372786"/>
<node ID="ID_969882896" TREE_ID="ID_1240571522"/>
</node>
</node>
</node>
</node>
<node ID="ID_141736055" TREE_ID="ID_181015777">
<node ID="ID_1578014274" TREE_ID="ID_19667659"/>
</node>
</node>
<node ID="ID_126186193" TREE_ID="ID_130194029">
<node ID="ID_1147137561" TREE_ID="ID_146709739"/>
</node>
<node ID="ID_1161205144" TREE_ID="ID_904462256">
<node ID="ID_1931260912" TREE_ID="ID_1465656435"/>
</node>
</node>
</node>
<node ID="ID_178545232" TREE_ID="ID_402850224"/>
<node ID="ID_466838381" TREE_ID="ID_1919800719">
<node ID="ID_1078487074" TREE_ID="ID_352696963"/>
<node ID="ID_1744694885" TREE_ID="ID_1640677902"/>
</node>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_681622" TREE_ID="ID_1037141831">
<node ID="ID_616076401" TREE_ID="ID_111094061"/>
<node ID="ID_1018489558" TREE_ID="ID_270729487"/>
</node>
<node POSITION="bottom_or_right" ID="ID_1369877973" TREE_ID="ID_567054336">
<node ID="ID_1985052182" TREE_ID="ID_888237854">
<node ID="ID_596246984" TREE_ID="ID_895782187"/>
</node>
</node>
</node>
<node POSITION="bottom_or_right" ID="ID_565822510" TREE_ID="ID_651861070">
<node ID="ID_1131285468" TREE_ID="ID_1136374115"/>
<node ID="ID_1101716792" TREE_ID="ID_680027716"/>
<node ID="ID_1989879097" TREE_ID="ID_397488560">
<node ID="ID_792537580" TREE_ID="ID_1755527244"/>
</node>
</node>
</node>
<node TEXT="(transferred)Embryo Rescue Trial" FOLDED="true" ID="ID_156389705" CREATED="1716238042957" MODIFIED="1721063830278">
<icon BUILTIN="list"/>
<node TEXT="issue" FOLDED="true" ID="ID_1079326107" CREATED="1716929871684" MODIFIED="1716929874087">
<node TEXT="ref" FOLDED="true" ID="ID_821607352" CREATED="1716930091749" MODIFIED="1716930093836">
<node TEXT="Michele 5/28 Meeting" ID="ID_382500966" CREATED="1716930097984" MODIFIED="1716930640028"/>
</node>
<node TEXT="new functionality in IM to have every pollination has to have PMID" ID="ID_29584172" CREATED="1716929874660" MODIFIED="1716929903518"/>
<node TEXT="when you create a trial in spirit, submit to tmr, get PMID" FOLDED="true" ID="ID_1694584925" CREATED="1716929904043" MODIFIED="1716929926748">
<node TEXT="also geneateds for subplot ids" ID="ID_106681611" CREATED="1716929927431" MODIFIED="1716929937865"/>
</node>
<node TEXT="when you don&apos;t send to IM (no submit to TMR)" FOLDED="true" ID="ID_1368828794" CREATED="1716929940563" MODIFIED="1716929965740">
<node TEXT="no registed seed" ID="ID_250901014" CREATED="1716929968211" MODIFIED="1716929974980"/>
<node TEXT="cant force 3rd party to register seed" ID="ID_1274999857" CREATED="1716929979867" MODIFIED="1716929996369"/>
</node>
<node TEXT="fast turnaround" ID="ID_1156949162" CREATED="1716929998228" MODIFIED="1716930004079"/>
<node TEXT="if from 3rd party, needs to be planted" ID="ID_1011002816" CREATED="1716930015053" MODIFIED="1716930043202"/>
<node TEXT="all trials need a MTLOC" FOLDED="true" ID="ID_423314238" CREATED="1716930592181" MODIFIED="1716930617220">
<font BOLD="true"/>
<node TEXT="3P_ Third party locations" FOLDED="true" ID="ID_251148367" CREATED="1716930662922" MODIFIED="1716930678841">
<node TEXT="Type: ThirdParty" FOLDED="true" ID="ID_47571977" CREATED="1716930737074" MODIFIED="1716930747452">
<node TEXT="MM Location search" ID="ID_1488672598" CREATED="1716930748081" MODIFIED="1716930754142"/>
</node>
<node TEXT="Type: Syngenta or Remote needed to submit TMR" ID="ID_872507643" CREATED="1716930764442" MODIFIED="1716930800798"/>
</node>
<node TEXT="field mapping for locations" FOLDED="true" ID="ID_416285608" CREATED="1716930046404" MODIFIED="1716930059494">
<node TEXT="Location ..MINT Location MTLOC" FOLDED="true" ID="ID_536716514" CREATED="1716930145595" MODIFIED="1716930159208">
<node TEXT="Location" FOLDED="true" ID="ID_1296167974" CREATED="1716930444099" MODIFIED="1716930462884">
<node TEXT="RC Row, Assign to MINT" ID="ID_346404763" CREATED="1716930463978" MODIFIED="1716930484549"/>
</node>
</node>
</node>
</node>
<node TEXT="manual planting date added only when at third party" FOLDED="true" ID="ID_1364713061" CREATED="1716931431617" MODIFIED="1716931473357">
<node TEXT="" ID="ID_1469982127" CREATED="1716931490577" MODIFIED="1716931490577"/>
</node>
<node TEXT="combining materials registered with unregistered" FOLDED="true" ID="ID_1703998394" CREATED="1716930812596" MODIFIED="1716930836943">
<node TEXT="two ways to adress" FOLDED="true" ID="ID_1803603682" CREATED="1716930843658" MODIFIED="1716930896161">
<node TEXT="1 Submit TMR" ID="ID_1497600827" CREATED="1716930896886" MODIFIED="1716930906309"/>
<node TEXT="filing packets or nor" FOLDED="true" ID="ID_675853676" CREATED="1716931148273" MODIFIED="1716931227578">
<node TEXT="If filling all packets, submit to TMR" ID="ID_1593304091" CREATED="1716930978874" MODIFIED="1716931015090"/>
<node TEXT="If some of them are not filled" ID="ID_306490391" CREATED="1716931016587" MODIFIED="1716931035450"/>
<node TEXT="case not filling packets" FOLDED="true" ID="ID_1207339794" CREATED="1716930915082" MODIFIED="1716930942567">
<node TEXT="Location is assigned" ID="ID_1668879090" CREATED="1716930943337" MODIFIED="1716930964342"/>
</node>
</node>
</node>
</node>
<node TEXT="solution" FOLDED="true" ID="ID_138831069" CREATED="1716931274930" MODIFIED="1716931278978">
<node TEXT="As we spoke earlier on Tuesday regarding the request for send unfilled plot (due the no registration) I failed to mention it is only for locations assigned to Third Party Field Areas." ID="ID_1674759132" CREATED="1718138709827" MODIFIED="1718138709827"/>
<node TEXT="Anastasiia Ponomareva from Material Management is working on this task.  It has been transferred to the Material Management queue. At this time, It is unclear if a JIRA exists." ID="ID_626011789" CREATED="1718138709827" MODIFIED="1718138709827"/>
<node TEXT="requesting creation of PM_ID" ID="ID_179538280" CREATED="1716931247048" MODIFIED="1716931271241"/>
<node TEXT="produce two trials" ID="ID_609200064" CREATED="1716931324136" MODIFIED="1716931382489">
<font ITALIC="true"/>
</node>
<node TEXT="register plants (not possible currently)" ID="ID_564631628" CREATED="1718124866942" MODIFIED="1718124908044">
<font BOLD="true"/>
</node>
</node>
<node TEXT="workaround" FOLDED="true" ID="ID_505097405" CREATED="1716931281071" MODIFIED="1716931285640">
<node TEXT="virtually fill packets" ID="ID_33833177" CREATED="1716931285818" MODIFIED="1716931295115"/>
<node TEXT="send unfilled plot" ID="ID_1597576365" CREATED="1718124373709" MODIFIED="1718124407186"/>
<node TEXT="preregister a series of placeholder materials" ID="ID_306949642" CREATED="1718124513024" MODIFIED="1718124557612"/>
</node>
</node>
<node TEXT="PMTID?" ID="ID_466418894" CREATED="1716912857701" MODIFIED="1716912860863"/>
<node TEXT="PPLST" FOLDED="true" ID="ID_1648086556" CREATED="1716931555530" MODIFIED="1716932463414">
<font BOLD="true"/>
<node TEXT="Plot Planting Status" ID="ID_1027286925" CREATED="1716931625102" MODIFIED="1716931723674">
<font BOLD="true"/>
</node>
<node TEXT="Assigned to Plot record only" ID="ID_1478311477" CREATED="1716931677441" MODIFIED="1716931692164"/>
<node TEXT="H:" FOLDED="true" ID="ID_1818979660" CREATED="1716931797366" MODIFIED="1716931798970">
<node TEXT="Harvest" ID="ID_1320352572" CREATED="1716931824104" MODIFIED="1716931827137"/>
</node>
<node TEXT="P: Packeted" ID="ID_1211303889" CREATED="1716931828376" MODIFIED="1716931832905"/>
<node TEXT="N:" ID="ID_1440909548" CREATED="1716931799817" MODIFIED="1716931801713"/>
<node TEXT="E: Emptied (filled, but emptied)" ID="ID_1605035815" CREATED="1716931835410" MODIFIED="1716931851584"/>
<node TEXT="D: Discarded" ID="ID_104989497" CREATED="1716931852111" MODIFIED="1716931883996"/>
<node TEXT="Null: ?" ID="ID_667285813" CREATED="1716931884712" MODIFIED="1716931889793"/>
</node>
<node TEXT="CONID" FOLDED="true" ID="ID_1965682053" CREATED="1716932465118" MODIFIED="1716932470291">
<node TEXT="search for in MM" ID="ID_1559901313" CREATED="1716932470840" MODIFIED="1716932478969"/>
</node>
<node TEXT="PMID" FOLDED="true" ID="ID_1017455082" CREATED="1716932485191" MODIFIED="1716932499878">
<font BOLD="true"/>
<node TEXT="when movi" ID="ID_514340750" CREATED="1716932935550" MODIFIED="1716994968830"/>
<node TEXT="when plant form changes, new pmid" ID="ID_1202931528" CREATED="1716932685880" MODIFIED="1716932703199"/>
<node TEXT="subdivided" ID="ID_1154133453" CREATED="1716932703678" MODIFIED="1716932725849"/>
</node>
<node TEXT="Family" FOLDED="true" ID="ID_630985615" CREATED="1716932131521" MODIFIED="1716932133474">
<node ID="ID_1089583295" CREATED="1716932881833" MODIFIED="1716932881833" LINK="https://jcra.ncsu.edu/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://jcra.ncsu.edu/">JC Raulston Arboretum | Free Botanic Garden in Raleigh, North Carolina. Open every day | North Carolina State University</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_57091818" CREATED="1716932410926" MODIFIED="1716932410926" LINK="https://www.ncagr.gov/divisions/marketing/farmers-markets-agricultural-centers/state-farmers-market-raleigh"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ncagr.gov/divisions/marketing/farmers-markets-agricultural-centers/state-farmers-market-raleigh">State Farmers Market - Raleigh | NC Agriculture</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Done" FOLDED="true" ID="ID_549063171" CREATED="1743191368386" MODIFIED="1743191374203">
<node TEXT="Miriam" ID="ID_545278697" CREATED="1739809474483" MODIFIED="1739809478750"/>
<node TEXT="PMTID Vegetable table for PLANT project" FOLDED="true" ID="ID_1036078944" CREATED="1739800583756" MODIFIED="1739800583756">
<node TEXT="#email" ID="ID_275263372" CREATED="1739800596359" MODIFIED="1739800598988"/>
<node TEXT="Hallie" ID="ID_20340285" CREATED="1739800554900" MODIFIED="1739800556705"/>
<node ID="ID_632068588" CREATED="1739804399292" MODIFIED="1739804399292"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="onenote:https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20&amp;%20Trait%20Data%20Stewardship/Identity%20and%20Trait%20Data%20Stewardship%20Notebook/Tools/Spirit/Functions.one#Trials&amp;section-id={03BEB155-1C84-44AC-84D4-CFD8BED87742}&amp;page-id={E4DE6036-8F81-47D4-A31E-3CECB971F9CF}&amp;object-id={6A749270-4697-4E27-9632-D844FD30D4E8}&amp;14">PMTID</a>&#xa0;&#xa0;(<a href="https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/_layouts/OneNote.aspx?id=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2FIdentity%20and%20Trait%20Data%20Stewardship%20Notebook&amp;wd=target%28Tools%2FSpirit%2FFunctions.one%7C03BEB155-1C84-44AC-84D4-CFD8BED87742%2FTrials%7CE4DE6036-8F81-47D4-A31E-3CECB971F9CF%2F%29">Web view</a>)
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Reference" ID="ID_4195244" CREATED="1738682538696" MODIFIED="1738682541656">
<node TEXT="Tools" FOLDED="true" ID="ID_935991593" CREATED="1715618538613" MODIFIED="1716184511508">
<node TEXT="transferred" POSITION="bottom_or_right" ID="ID_80946078" CREATED="1721066773527" MODIFIED="1721066775357">
<node TEXT="Identity Management" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_75647595" CREATED="1715656345229" MODIFIED="1734445071836">
<icon BUILTIN="list"/>
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_132438635" CREATED="1715656955450" MODIFIED="1715656957468">
<node TEXT="access" FOLDED="true" ID="ID_705119422" CREATED="1716480579619" MODIFIED="1718130225398">
<node TEXT="MINT Identity Management link is https://identity.mint.syngentadigitalapps.com/home" POSITION="bottom_or_right" ID="ID_607970742" CREATED="1716480582220" MODIFIED="1716506696414" LINK="https://identity.mint.syngentadigitalapps.com/home"/>
<node TEXT="MINT Identity Management Stage(training) is https://stage-identity.mint.syngentadigitalapps.com/" POSITION="bottom_or_right" ID="ID_286977357" CREATED="1716506707929" MODIFIED="1716506747674" LINK="https://stage-identity.mint.syngentadigitalapps.com/"/>
<node TEXT="MINT Identity Management Test (QA) is  https://test-identity.mint.syngentadigitalapps.com/home" POSITION="bottom_or_right" ID="ID_595645489" CREATED="1716506810128" MODIFIED="1716506810128" LINK="https://test-identity.mint.syngentadigitalapps.com/home"/>
</node>
<node ID="ID_469923435" CREATED="1719515163290" MODIFIED="1719515163290" LINK="https://syngenta.sharepoint.com/sites/seeds-rd-academy/SitePages/MINT-Identity-Management.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/seeds-rd-academy/SitePages/MINT-Identity-Management.aspx">MINT Identity Management</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="IM User Guide (need to be on VPN to Access)" FOLDED="true" ID="ID_660594956" CREATED="1715792951004" MODIFIED="1716587897020">
<font BOLD="true"/>
<node ID="ID_315436402" CREATED="1716588242569" MODIFIED="1716588242569" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/index.htm#t=Sorting_Results.htm&amp;amp;rhsearch=model%20begins"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/index.htm#t=Sorting_Results.htm&amp;rhsearch=model%20begins">Identity Management User Guide</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="good for using the application" ID="ID_821421677" CREATED="1716588140425" MODIFIED="1716588148017"/>
<node TEXT="not neccessarily up to date" ID="ID_1761087535" CREATED="1715792980921" MODIFIED="1715793041424"/>
<node ID="ID_1589623540" CREATED="1716586670966" MODIFIED="1716586670966" LINK="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx">MINT Communications - All Documents</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Previous User Guide (Word Doc) good for reference" FOLDED="true" ID="ID_972954735" CREATED="1716586763698" MODIFIED="1716588156692" LINK="https://syngenta.sharepoint.com/:w:/r/sites/MINTHome/MINT%20Communications/Source/ID/Identity_Management_User_Guide.docx?d=w71b7e7d6a1a64fcb8208808b7f015ec8&amp;csf=1&amp;web=1">
<node ID="ID_541430087" CREATED="1716586555806" MODIFIED="1716586555806" LINK="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx?RootFolder=%2Fsites%2FMINTHome%2FMINT%20Communications%2FSource%2FID&amp;amp;FolderCTID=0x01200073B9282FDFEC464D80A575F26499A993"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx?RootFolder=%2Fsites%2FMINTHome%2FMINT%20Communications%2FSource%2FID&amp;FolderCTID=0x01200073B9282FDFEC464D80A575F26499A993">ID - All Documents</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Local Copy_ Identity Management User Guide 2022.docx" ID="ID_997854256" CREATED="1716600931262" MODIFIED="1716600951474" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Identity%20Management/Local%20Copy_%20Identity%20Management%20User%20Guide%202022.docx"/>
</node>
<node ID="ID_547863989" CREATED="1716587367999" MODIFIED="1716587376975" LINK="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx?RootFolder=%2Fsites%2FMINTHome%2FMINT%20Communications%2FQuickRefGuides%2FFinal%20English%20PDFs&amp;amp;FolderCTID=0x01200073B9282FDFEC464D80A575F26499A993&amp;amp;View=%7BF1CE9F96%2D3E80%2D4E23%2DBF5F%2D5C5994F99BCA%7D"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx?RootFolder=%2Fsites%2FMINTHome%2FMINT%20Communications%2FQuickRefGuides%2FFinal%20English%20PDFs&amp;FolderCTID=0x01200073B9282FDFEC464D80A575F26499A993&amp;View=%7BF1CE9F96%2D3E80%2D4E23%2DBF5F%2D5C5994F99BCA%7D">Quick Ref GuidesFinal English PDFs - All Documents</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_544981966" CREATED="1716587614972" MODIFIED="1716587614972" LINK="https://syngenta.sharepoint.com/sites/VEGMINT/Identity%20Management/Forms/Theme.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/VEGMINT/Identity%20Management/Forms/Theme.aspx">Identity Management - Theme</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1559734624" CREATED="1716584843149" MODIFIED="1716584855159" LINK="https://www.syngentalms-ag.com/learn/course/2842/play/4988:1052/getting-started-with-identity-management"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.syngentalms-ag.com/learn/course/2842/play/4988:1052/getting-started-with-identity-management">Syngenta's Learning Management System: Getting Started With Identity Management </a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1901535" CREATED="1716219426060" MODIFIED="1716577990026" LINK="https://eu.degreed.com/learning/search?term=identity%20management%20&amp;amp;orgId=10037"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://eu.degreed.com/learning/search?term=identity%20management%20&amp;orgId=10037">identity management - Search | Degreed (Learning Edge)</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1676877843" CREATED="1716575500185" MODIFIED="1716575500185" LINK="https://syngenta.sharepoint.com/:p:/r/sites/ChinaCornMintProjectTeam/_layouts/15/Doc.aspx?sourcedoc=%7B89995E4A-30D3-4D0B-BA38-83AB0DA5040E%7D&amp;amp;file=MINT%20Standard%20Presentation.pptx&amp;amp;action=edit&amp;amp;mobileredirect=true&amp;amp;DefaultItemOpen=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/ChinaCornMintProjectTeam/_layouts/15/Doc.aspx?sourcedoc=%7B89995E4A-30D3-4D0B-BA38-83AB0DA5040E%7D&amp;file=MINT%20Standard%20Presentation.pptx&amp;action=edit&amp;mobileredirect=true&amp;DefaultItemOpen=1">MINT Standard Presentation.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Release Notes" ID="ID_791090102" CREATED="1716219642357" MODIFIED="1716219645690"/>
<node TEXT="Plant Breeding" ID="ID_1771635221" CREATED="1715657741789" MODIFIED="1715657749413" LINK="freeplane:/%20/M:/My%20Drive/My%20Google%20Docs/MindMaps/Leafy%20Breeding.mm#ID_659356658"/>
<node TEXT="Traits" FOLDED="true" ID="ID_1939796915" CREATED="1718724313418" MODIFIED="1718902655578">
<font BOLD="true"/>
<node TEXT="Batch Pedigree" FOLDED="true" ID="ID_288848358" CREATED="1717775026991" MODIFIED="1717775034393">
<node TEXT="ref" FOLDED="true" ID="ID_776895282" CREATED="1717777393600" MODIFIED="1717777395068">
<node ID="ID_1844166244" CREATED="1719587845152" MODIFIED="1719587845152" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/_layouts/15/Doc.aspx?sourcedoc=%7B08561399-90EE-43A6-9977-9BD9B5EF635D%7D&amp;amp;file=Batch%20Pedigree%20Calculation%20presentation.pptx&amp;amp;action=edit&amp;amp;mobileredirect=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/_layouts/15/Doc.aspx?sourcedoc=%7B08561399-90EE-43A6-9977-9BD9B5EF635D%7D&amp;file=Batch%20Pedigree%20Calculation%20presentation.pptx&amp;action=edit&amp;mobileredirect=true">Batch Pedigree Calculation presentation.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_592942499" CREATED="1717777397157" MODIFIED="1717777397157" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/ID%20Attributes%20Store/Batch%20Pedigree/Batch%20Pedigree%20Calculation%20presentation.pptx?d=w0856139990ee43a699779bd9b5ef635d&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=OohIIv"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/ID%20Attributes%20Store/Batch%20Pedigree/Batch%20Pedigree%20Calculation%20presentation.pptx?d=w0856139990ee43a699779bd9b5ef635d&amp;csf=1&amp;web=1&amp;e=OohIIv">Batch Pedigree Calculation presentation.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1290008182" CREATED="1718982797037" MODIFIED="1718982797037" LINK="https://syngenta.sharepoint.com/sites/MINTIdentityGapAnalysisResolution/_layouts/15/stream.aspx?id=%2Fsites%2FMINTIdentityGapAnalysisResolution%2FShared%20Documents%2FGeneral%2FID%20Attributes%20Store%2FBatch%20Pedigree%2FBatch%20Pedigree%20Rules%20walkthrough%20by%20Andrei%20%2D%207th%20June%202024%2Emp4&amp;amp;referrer=StreamWebApp%2EWeb&amp;amp;referrerScenario=AddressBarCopied%2Eview%2E9faacee5%2Dc440%2D4ed1%2D80d4%2D2129a80986d7"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/MINTIdentityGapAnalysisResolution/_layouts/15/stream.aspx?id=%2Fsites%2FMINTIdentityGapAnalysisResolution%2FShared%20Documents%2FGeneral%2FID%20Attributes%20Store%2FBatch%20Pedigree%2FBatch%20Pedigree%20Rules%20walkthrough%20by%20Andrei%20%2D%207th%20June%202024%2Emp4&amp;referrer=StreamWebApp%2EWeb&amp;referrerScenario=AddressBarCopied%2Eview%2E9faacee5%2Dc440%2D4ed1%2D80d4%2D2129a80986d7">Batch Pedigree Rules walkthrough by Andrei - 7th June 2024.mp4</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Meeting 6/7" ID="ID_1122072840" CREATED="1717775035276" MODIFIED="1717775040850"/>
</node>
<node TEXT="Source" ID="ID_1504175312" CREATED="1719577998549" MODIFIED="1719579933605"/>
</node>
<node TEXT="Country of Origin" FOLDED="true" ID="ID_1306074169" CREATED="1718724326071" MODIFIED="1718724330471">
<node TEXT="country of origin as defined by Identity Management. Country of origin is the country where the “genes” in the germplasm were found.  It is not the country where the seed was grown harvested.  In identity Management, there is a field/trait for country and state of harvest.  This country of origin, country of harvest and state/province of harvest is not communicated to Material Management for acquired materials.  The critical information that should be used for where seed was produced is the Harvest country and Harvest location." ID="ID_251719051" CREATED="1718724323938" MODIFIED="1718724323938"/>
<node TEXT="I would be cautious in using creation country or Country of Origin as accurate.  This has been a difficult trait for the personnel creating manual adds to understand.  It should also be noted that many external (manual adds) are created before the seed has been received or the packaging does not include the country where the seed was produced." ID="ID_1147324356" CREATED="1718724323938" MODIFIED="1718724323938"/>
</node>
</node>
<node TEXT="about" FOLDED="true" ID="ID_212186736" CREATED="1716568957000" MODIFIED="1716568959928">
<node TEXT="SoT (Source of Truth) for Germplasm Identity" FOLDED="true" ID="ID_739152727" CREATED="1716568960780" MODIFIED="1716568995391">
<node TEXT="eventually a trailing database will be the source of truth for trialing" ID="ID_991151616" CREATED="1716568996794" MODIFIED="1716569035258" LINK="https://syngenta.sharepoint.com/:p:/r/sites/AppliedGeneticsVF/Shared%20Documents/General/Identity%20%26%20Trait%20Data%20Stewardship/onboarding%20materials%20%26%20resources/Germplasm%20Identity-%20Attribute%20migration%202023%20comms%20deck%20final.pptx?d=wab918de24d9b483ab452667716d9e6c8&amp;csf=1&amp;web=1&amp;e=eeC0QV&amp;nav=eyJzSWQiOjIxNDczNzM3MzIsImNJZCI6OTQ4MDg0NDQ5fQ"/>
</node>
<node TEXT="Identity Management (IM) – Web based application that manages the Identity components of many R&amp;D breeding activities –" FOLDED="true" ID="ID_201188359" CREATED="1715656875866" MODIFIED="1715656875866">
<node TEXT="Create Batches, Advance to Stable, Demotion" ID="ID_161990961" CREATED="1715656875866" MODIFIED="1715656875866"/>
<node TEXT="Assign Name (Early Stage Name, Stable Line Code, Stable Variety Code)" ID="ID_1315945018" CREATED="1715656875866" MODIFIED="1715656875866"/>
</node>
<node TEXT="stores and connects lineage and relationships" ID="ID_1393068494" CREATED="1716584926284" MODIFIED="1716584967938"/>
<node TEXT="search for identity information" ID="ID_671064014" CREATED="1716584932661" MODIFIED="1716584937869"/>
<node TEXT="record changes in identity" ID="ID_709064512" CREATED="1716584938555" MODIFIED="1716584942391"/>
<node TEXT="Access identity data" ID="ID_693335892" CREATED="1716584943206" MODIFIED="1716584946677"/>
<node TEXT="access Material Management data" FOLDED="true" ID="ID_1059813178" CREATED="1716584947594" MODIFIED="1716584961326">
<node TEXT="Identity Management Components" FOLDED="true" ID="ID_1406742285" CREATED="1716601777114" MODIFIED="1716601849880">
<font BOLD="true"/>
<node TEXT="Identity Management consists of multiple interrelated components:" FOLDED="true" POSITION="bottom_or_right" ID="ID_597347404" CREATED="1716601777114" MODIFIED="1716602061157">
<font BOLD="false"/>
<node TEXT="Identity Management application" FOLDED="true" ID="ID_1748086134" CREATED="1716601777115" MODIFIED="1716602066819">
<font BOLD="true"/>
<node TEXT="The Identity Management application is a user interface that displays in a web browser. The application not only integrates all of the Identity Management components and serves as the main user interface for the Identity Management functionality, but it also provides powerful Search features." ID="ID_1063693532" CREATED="1716601777116" MODIFIED="1716601777116"/>
</node>
<node TEXT="Identity Database" FOLDED="true" ID="ID_1860094247" CREATED="1716601777115" MODIFIED="1716602068157">
<font BOLD="true"/>
<node TEXT="The Identity database is initially populated with data extracted from the Syngenta Strategic Program for the Integration of Research Information Technologies (SPIRIT) database." ID="ID_644764345" CREATED="1716601777116" MODIFIED="1716601777116"/>
<node TEXT="This system enables Identity Management to access identity and relationship data for all MINT biological materials. The migrated data can then support keyword searching for SPIRIT database records while enabling MINT users to identify biological materials with a greater degree of ease and accuracy." ID="ID_1242622611" CREATED="1716601777117" MODIFIED="1716601777117"/>
<node TEXT="Understand data connections to SPIRIT and Identity" ID="ID_839655370" CREATED="1716186377476" MODIFIED="1716602738443">
<icon BUILTIN="unchecked"/>
</node>
</node>
<node TEXT="Identity Rules Engine" FOLDED="true" ID="ID_356661053" CREATED="1716601777116" MODIFIED="1716602054210">
<font BOLD="true"/>
<node TEXT="The Rules Engine application determines how to update the Identity Database with new records in response to user activities. For example, when a Material Management user registers biological material in inventory, the Rules Engine updates the database to include the appropriate Batch, BE, and LBG." FOLDED="true" ID="ID_1635086419" CREATED="1716601777118" MODIFIED="1716601777118">
<node TEXT="dictates the guidelines for how material identity is updated based on operations performed on materials" ID="ID_1153736033" CREATED="1716583820927" MODIFIED="1716583846652"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Rules" FOLDED="true" ID="ID_1291746762" CREATED="1718902312837" MODIFIED="1718902318635">
<font BOLD="true"/>
<node ID="ID_1878048849" CREATED="1718902315719" MODIFIED="1718902315719" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/Files%20From%20Drew/Last%206%20months/MINT%20New%20Hybrid%20Crop%20onboarding%20deck%20-%20Copy.pptx?d=w77eec601f9bd4ae3bc5d96b32ca8b780&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=pET00o"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/Files%20From%20Drew/Last%206%20months/MINT%20New%20Hybrid%20Crop%20onboarding%20deck%20-%20Copy.pptx?d=w77eec601f9bd4ae3bc5d96b32ca8b780&amp;csf=1&amp;web=1&amp;e=pET00o">MINT New Hybrid Crop onboarding deck - Copy.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1118756691" CREATED="1718902621820" MODIFIED="1718902621820" LINK="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/Files%20From%20Drew/Last%206%20months/MINT%20Identity%20Business%20Rules%20-%20Copy.pptx?d=wa0b846c342dd405f801b5e89b748678f&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=HqcEdm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/MINTIdentityGapAnalysisResolution/Shared%20Documents/General/Files%20From%20Drew/Last%206%20months/MINT%20Identity%20Business%20Rules%20-%20Copy.pptx?d=wa0b846c342dd405f801b5e89b748678f&amp;csf=1&amp;web=1&amp;e=HqcEdm">MINT Identity Business Rules - Copy.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Key Concepts" FOLDED="true" ID="ID_1112205048" CREATED="1716574882854" MODIFIED="1716598510677">
<font BOLD="true"/>
<node TEXT="Identifiers" FOLDED="true" ID="ID_1158474549" CREATED="1716574886379" MODIFIED="1716575121412">
<font BOLD="true"/>
<node TEXT="System identifiers - unique and universal" FOLDED="true" ID="ID_860369339" CREATED="1716575041852" MODIFIED="1716575041852">
<node TEXT="long" ID="ID_1207785705" CREATED="1716584229639" MODIFIED="1716584235241"/>
<node TEXT="b1656c8a-83b4-487f-b83a-039daef724b9" ID="ID_257069376" CREATED="1716584261349" MODIFIED="1716584291725"/>
<node TEXT="GUID, UUID" ID="ID_1510726452" CREATED="1717445005688" MODIFIED="1717445014395"/>
</node>
<node TEXT="Alternate identifiers - shortened versions of system identifiers to aid recall" FOLDED="true" ID="ID_458498780" CREATED="1716575041852" MODIFIED="1716575041852">
<node TEXT="ALTID" ID="ID_1934683229" CREATED="1716584239185" MODIFIED="1716584242362"/>
<node TEXT="maps directly to the system identifier" ID="ID_964404377" CREATED="1716584242978" MODIFIED="1716584257500"/>
<node TEXT="CNCCZXV053513" ID="ID_1312061927" CREATED="1716584297535" MODIFIED="1716584308129"/>
</node>
<node TEXT="Business identifiers (BID) - flexible, more user friendly IDs containing material attributes" FOLDED="true" ID="ID_1570671803" CREATED="1716575041854" MODIFIED="1716584338312">
<node TEXT="embeds crop and material specific information" ID="ID_1824290855" CREATED="1716584349670" MODIFIED="1716584368023"/>
<node TEXT="serves as a replacement for Material ID and Material Lot ID" ID="ID_701209083" CREATED="1716584573977" MODIFIED="1716584611833"/>
<node TEXT="png-240524-135948343-10664812837113779764.png" ID="ID_1207067533" CREATED="1716584389775" MODIFIED="1716584389775">
<hook URI="DataStewardshipAnalyst_files/png-240524-135948343-10664812837113779764.png" SIZE="0.4601227" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Relationships" FOLDED="true" ID="ID_261686168" CREATED="1716574890773" MODIFIED="1716575121414">
<font BOLD="true"/>
<node TEXT="Exist among materials across all levels of the model and can be scientifically based or user defined" ID="ID_1222795289" CREATED="1716575062222" MODIFIED="1716575062222"/>
</node>
<node TEXT="Diversity" FOLDED="true" ID="ID_876339542" CREATED="1716574893778" MODIFIED="1716575121414">
<font BOLD="true"/>
<node TEXT="The level of variability in the genetic makeup of a group of materials" ID="ID_948521230" CREATED="1716575073212" MODIFIED="1716575073212"/>
</node>
<node TEXT="Inheritance (and Grouping)" FOLDED="true" ID="ID_1129693638" CREATED="1716574959516" MODIFIED="1716575121414">
<font BOLD="true"/>
<node TEXT="Inheritance of characteristics passed from parent to child (biological inheritance)" ID="ID_862209322" CREATED="1716575087014" MODIFIED="1716575087014"/>
<node TEXT="Inheritance by virtue of grouping" ID="ID_1167457367" CREATED="1716575087014" MODIFIED="1716575087014"/>
</node>
<node TEXT="Selection" FOLDED="true" ID="ID_1701475902" CREATED="1716574897773" MODIFIED="1716575121414">
<font BOLD="true"/>
<node TEXT="The practice of picking a subset of materials in a group in order to &quot;use&quot; them differently" ID="ID_1994674185" CREATED="1716575096443" MODIFIED="1716575102580"/>
</node>
</node>
<node TEXT="Identity Domain Model" FOLDED="true" ID="ID_1412159038" CREATED="1715792775025" MODIFIED="1716602269492">
<icon BUILTIN="messagebox_warning"/>
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_968606123" CREATED="1716574910011" MODIFIED="1716574912190">
<node ID="ID_418286001" CREATED="1716574913170" MODIFIED="1716577914036" LINK="https://www.syngentalms-ag.com/learn/course/2840/play/4984:1050/domain-model"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.syngentalms-ag.com/learn/course/2840/play/4984:1050/domain-model">Syngenta's Learning Management System: Domain Model </a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1755605847" CREATED="1716577958401" MODIFIED="1716577966611" LINK="https://www.syngentalms-ag.com/learn/course/2841/play/4986:1051/domain-model-in-action"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.syngentalms-ag.com/learn/course/2841/play/4986:1051/domain-model-in-action">Syngenta's Learning Management System: Domain Model In Action </a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1974610368" CREATED="1716574924202" MODIFIED="1716574924202" LINK="https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2Fonboarding%20materials%20%26%20resources%2FMINT%20Domain%20Model%2Epdf&amp;amp;parent=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2Fonboarding%20materials%20%26%20resources"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/AppliedGeneticsVF/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2Fonboarding%20materials%20%26%20resources%2FMINT%20Domain%20Model%2Epdf&amp;parent=%2Fsites%2FAppliedGeneticsVF%2FShared%20Documents%2FGeneral%2FIdentity%20%26%20Trait%20Data%20Stewardship%2Fonboarding%20materials%20%26%20resources">Applied Data Science V&amp;F - MINT Domain Model.pdf</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="definitions" FOLDED="true" ID="ID_1630600902" CREATED="1715656866840" MODIFIED="1715656954061">
<node TEXT="acquired material" FOLDED="true" ID="ID_1777237174" CREATED="1715794116630" MODIFIED="1715794144292">
<node TEXT="no parentage" ID="ID_1022667433" CREATED="1715794148054" MODIFIED="1715794166170"/>
</node>
</node>
</node>
<node TEXT="about" FOLDED="true" ID="ID_780339788" CREATED="1716574768661" MODIFIED="1716574771343">
<node TEXT="Genetic Identity And History" ID="ID_1249262126" CREATED="1716008771117" MODIFIED="1716569243763">
<font ITALIC="true"/>
</node>
<node TEXT="" ID="ID_710013045" CREATED="1716574817855" MODIFIED="1716574817855">
<hook NAME="FirstGroupNode"/>
</node>
<node TEXT="creates four distinct levels of identity" ID="ID_268499597" CREATED="1716574779576" MODIFIED="1716574784782"/>
<node TEXT="creates lineage to relationships between materials" ID="ID_186130810" CREATED="1716574784793" MODIFIED="1716574790154"/>
<node TEXT="reflects the execution of business rules" ID="ID_1440911300" CREATED="1716574790166" MODIFIED="1716574795172"/>
<node TEXT="" ID="ID_1223649803" CREATED="1716574817848" MODIFIED="1716574817854">
<hook NAME="SummaryNode"/>
<hook NAME="AlwaysUnfoldedNode"/>
<node TEXT="enables track and trace of biological materials" ID="ID_1808341424" CREATED="1716574817857" MODIFIED="1716574824582"/>
</node>
<node TEXT="Domain Model" FOLDED="true" ID="ID_483793446" CREATED="1716574500131" MODIFIED="1716574515573">
<node TEXT="way of describing concepts related to a specific area of knowledge or business" ID="ID_257355237" CREATED="1716574515576" MODIFIED="1716574522235"/>
<node TEXT="the concepts can include both data and the rules applied to the data" ID="ID_1581257604" CREATED="1716574523126" MODIFIED="1716574537600"/>
<node TEXT="the model describes how the concepts and rules relate to each other" ID="ID_495934589" CREATED="1716574537613" MODIFIED="1716574543969"/>
</node>
<node TEXT="Impact" FOLDED="true" ID="ID_1786569745" CREATED="1715658820346" MODIFIED="1715658961132">
<node TEXT="Alignment of the Identity records in organized Lineage-Based Groups" FOLDED="true" ID="ID_1277397180" CREATED="1715658839778" MODIFIED="1715658839778">
<node TEXT="reference" FOLDED="true" ID="ID_462393718" CREATED="1715658899795" MODIFIED="1715658902155">
<node TEXT="Lineage Based Group (LBG) (Population):" FOLDED="true" ID="ID_1278822994" CREATED="1715656875882" MODIFIED="1715793084868">
<node TEXT="A genetic grouping of Biological Entities with the same Lineage" ID="ID_1466568607" CREATED="1715658877956" MODIFIED="1715658877956"/>
<node TEXT="Starts with P" FOLDED="true" ID="ID_879181666" CREATED="1715793224773" MODIFIED="1715793245930">
<node TEXT="Next Crop" FOLDED="true" ID="ID_1975416759" CREATED="1715793246354" MODIFIED="1715793250513">
<node TEXT="LE" ID="ID_1857758635" CREATED="1715793251211" MODIFIED="1715793252703"/>
<node TEXT="SW" FOLDED="true" ID="ID_1557033214" CREATED="1715793253834" MODIFIED="1715793256027">
<node TEXT="Sweet Corn" ID="ID_19439368" CREATED="1715793256756" MODIFIED="1715793259842"/>
</node>
<node TEXT="TM" ID="ID_1596979461" CREATED="1715793269200" MODIFIED="1715793271936"/>
</node>
<node TEXT="Next Year 21" ID="ID_1443103664" CREATED="1715793306929" MODIFIED="1715793315231"/>
</node>
</node>
</node>
<node TEXT="Stable Line Code" ID="ID_1985150154" CREATED="1715658839778" MODIFIED="1715658839778"/>
<node TEXT="Stable Variety Code" ID="ID_1610197736" CREATED="1715658839778" MODIFIED="1715658839778"/>
<node TEXT="When possible to have Lineage Based Groups representing the unique genetic combination" ID="ID_1170865717" CREATED="1715658839778" MODIFIED="1715658839778"/>
</node>
<node TEXT="Provide stable and consistent identification for data mining" ID="ID_455628037" CREATED="1715658839778" MODIFIED="1715658839778"/>
<node TEXT="Provide stable and consistent identification for data analyses" ID="ID_466006327" CREATED="1715658839782" MODIFIED="1715658839782"/>
<node TEXT="Provide stable identification that links to Product Management Database/SAP" ID="ID_1602429938" CREATED="1715658839782" MODIFIED="1715658839782"/>
</node>
</node>
<node TEXT="diagrams" FOLDED="true" ID="ID_764417577" CREATED="1716009542130" MODIFIED="1716009564810">
<node TEXT="png-240517-221926265-961926207691863745.png" ID="ID_1918511267" CREATED="1716009569901" MODIFIED="1716009569901">
<hook URI="DataStewardshipAnalyst_files/png-240517-221926265-961926207691863745.png" SIZE="0.44345897" NAME="ExternalObject"/>
</node>
<node TEXT="png-240517-221948638-868423753823963603.png" ID="ID_1492816021" CREATED="1716009590675" MODIFIED="1716009590675">
<hook URI="DataStewardshipAnalyst_files/png-240517-221948638-868423753823963603.png" SIZE="0.44280443" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Structure (Model Level)" FOLDED="true" ID="ID_1578128684" CREATED="1715787636867" MODIFIED="1716569161458" LINK="#ID_1492816021">
<font BOLD="true"/>
<node TEXT="Lineage Based Group (LBG):" FOLDED="true" ID="ID_377934074" CREATED="1715656875882" MODIFIED="1716569074903">
<font BOLD="true"/>
<node TEXT="Differentiator" FOLDED="true" ID="ID_1054621707" CREATED="1716008849580" MODIFIED="1716008853777">
<node TEXT="Degree Of Genetic Variation" FOLDED="true" ID="ID_1214042725" CREATED="1716008853782" MODIFIED="1716008861207">
<node TEXT="Differentiator Types" FOLDED="true" ID="ID_1959197773" CREATED="1716008879386" MODIFIED="1716008885409">
<node TEXT="LBG TYPE (Stable) Line/Family:" FOLDED="true" ID="ID_488987031" CREATED="1716008885410" MODIFIED="1716008945577">
<node TEXT="subset of the genetic variation of a Population, ring fenced by the Material Owner" ID="ID_367436041" CREATED="1716008945582" MODIFIED="1716008960785"/>
<node TEXT="LBG TYPE Elite Line:" FOLDED="true" ID="ID_274257614" CREATED="1716008885410" MODIFIED="1716009010425">
<node TEXT="subset of the genetic variation of a (Stable) Line/Family; defined and fixed trait combination/genotype, established by the Material Owner" ID="ID_243362960" CREATED="1716009029649" MODIFIED="1716009393935"/>
</node>
</node>
</node>
</node>
<node TEXT="Material Owner (SPD)" FOLDED="true" ID="ID_1600737785" CREATED="1716009431748" MODIFIED="1716009441992">
<node ID="ID_1043281962" CREATED="1716009441998" MODIFIED="1716009484564"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="font-weight: bold;">Person </span><span style="font-weight: normal;">declaring LBG type </span>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Types" FOLDED="true" ID="ID_1552402270" CREATED="1717772283050" MODIFIED="1717772287247">
<font BOLD="true"/>
<node TEXT="LBG TYPE Population:" FOLDED="true" ID="ID_1588052469" CREATED="1716575182378" MODIFIED="1716576655406">
<font BOLD="true"/>
<node TEXT="In SPIRIT, population is referred to as Genetic Affiliation (GNA)" FOLDED="true" ID="ID_716235385" CREATED="1716575738010" MODIFIED="1716575778237">
<node TEXT="until new materials are created entirely in MINT, GNA information about a materials parents is the most important determining factor used in placing materials in LBGs" ID="ID_108800264" CREATED="1716576120676" MODIFIED="1716576180363"/>
</node>
<node TEXT="about" FOLDED="true" ID="ID_48194143" CREATED="1716575799909" MODIFIED="1716575801981">
<node TEXT="highest level of LBG" ID="ID_246167015" CREATED="1716575306399" MODIFIED="1716575308962">
<font BOLD="false"/>
</node>
<node TEXT="a grouping of materials with similar attributes" ID="ID_563946532" CREATED="1716575642033" MODIFIED="1716575646799"/>
<node TEXT="created typically by crossing two different materials" ID="ID_837721481" CREATED="1716575658429" MODIFIED="1716575697670"/>
<node TEXT="could consist of plant materials or DNA vectors" ID="ID_1228305607" CREATED="1716575702119" MODIFIED="1716575734667"/>
<node TEXT="A genetic grouping of Biological Entities with the same Lineage" FOLDED="true" ID="ID_1936583772" CREATED="1715658877956" MODIFIED="1715658877956">
<node TEXT="represents complete genetic variation of a combination" ID="ID_1845939162" CREATED="1716008901184" MODIFIED="1716008909600"/>
</node>
</node>
<node TEXT="Naming" FOLDED="true" ID="ID_1284161411" CREATED="1716576572073" MODIFIED="1716576575769">
<node TEXT="Starts with P" FOLDED="true" ID="ID_1162546997" CREATED="1715793224773" MODIFIED="1715793245930">
<node TEXT="Next Crop" FOLDED="true" ID="ID_1941062310" CREATED="1715793246354" MODIFIED="1715793250513">
<node TEXT="LE" ID="ID_1019019974" CREATED="1715793251211" MODIFIED="1715793252703"/>
<node TEXT="SW" FOLDED="true" ID="ID_12819922" CREATED="1715793253834" MODIFIED="1715793256027">
<node TEXT="Sweet Corn" ID="ID_1890807625" CREATED="1715793256756" MODIFIED="1715793259842"/>
</node>
<node TEXT="TM" ID="ID_759110559" CREATED="1715793269200" MODIFIED="1715793271936"/>
</node>
<node TEXT="Next Year 21" ID="ID_847149405" CREATED="1715793306929" MODIFIED="1715793315231"/>
</node>
</node>
<node TEXT="Family" FOLDED="true" ID="ID_1079130662" CREATED="1716575807236" MODIFIED="1716575811570">
<font BOLD="true"/>
<node TEXT="user determined grouping of a subset of germplasm in a population" FOLDED="true" ID="ID_600995189" CREATED="1716575823196" MODIFIED="1716575836886">
<node TEXT="typically a breeder" ID="ID_1088475573" CREATED="1716575837589" MODIFIED="1716575841203"/>
</node>
<node TEXT="so that a subset of plants showing desirable traits can be managed separately from the overall Population" ID="ID_1820934114" CREATED="1716575905613" MODIFIED="1716575929956"/>
<node TEXT="this represents work towards developing a stable line" ID="ID_152677708" CREATED="1716575934980" MODIFIED="1716575952865"/>
</node>
<node TEXT="Stable Line" FOLDED="true" ID="ID_60293310" CREATED="1716575962113" MODIFIED="1716575971768">
<font BOLD="true"/>
<node TEXT="ref" FOLDED="true" ID="ID_1296674622" CREATED="1717773674529" MODIFIED="1717773675588">
<node ID="ID_451755156" TREE_ID="ID_972954735">
<node ID="ID_921980372" TREE_ID="ID_541430087"/>
<node ID="ID_1339340822" TREE_ID="ID_997854256"/>
</node>
</node>
<node TEXT="definition" FOLDED="true" ID="ID_73257347" CREATED="1717773748561" MODIFIED="1717773750597">
<node TEXT="clearly defined and largely unchanging lines that are maintained by selfing, sib-mating, or clonal propagation" FOLDED="true" ID="ID_1121552040" CREATED="1716575979852" MODIFIED="1716576019788">
<node TEXT="the consistent genetics of the stable line mean that when you self it, you create progeny that are identical to the parent" ID="ID_1745142567" CREATED="1716576819488" MODIFIED="1716576838579"/>
</node>
<node TEXT="doubled haploids are declared to be Stable Lines" ID="ID_409861068" CREATED="1716576036435" MODIFIED="1716576059066"/>
</node>
<node TEXT="Advancing Stable Lines from BEs" FOLDED="true" ID="ID_1361475257" CREATED="1717773798172" MODIFIED="1717773973581">
<node TEXT="Name the Stable Line" FOLDED="true" ID="ID_674718391" CREATED="1717773828387" MODIFIED="1717773845042">
<node TEXT="cannot edit the name after you name it" ID="ID_1437437809" CREATED="1717773883964" MODIFIED="1717773888317"/>
</node>
<node TEXT="IM" FOLDED="true" ID="ID_295379364" CREATED="1717773847161" MODIFIED="1717773866649">
<node TEXT="creates a Stable Line Identifier" ID="ID_802486287" CREATED="1717773868106" MODIFIED="1717773880855"/>
<node TEXT="sets default values:" ID="ID_797095780" CREATED="1717773894745" MODIFIED="1717773957495"/>
</node>
</node>
<node TEXT="Demoting Stable Lines" FOLDED="true" ID="ID_1368000614" CREATED="1717774004304" MODIFIED="1717774018568">
<node TEXT="can you demote a Stable Line and Advance back one generation?" FOLDED="true" ID="ID_1536351700" CREATED="1717774026282" MODIFIED="1717774060163">
<icon BUILTIN="help"/>
<node TEXT="If you advance a stable line will all progeny belong to that line?" ID="ID_498867447" CREATED="1717774069416" MODIFIED="1717774103313"/>
</node>
</node>
<node TEXT="Naming" FOLDED="true" ID="ID_324935608" CREATED="1717443459546" MODIFIED="1717443462353">
<node TEXT="VH:VHNO  (SPIRIT) variety number is independent of PMD Variety Number.  It is the key identifier for the variety grid in SPIRIT.  For new created Stable Variety Code,  the BE BID used to create the variety record is now being assigned as the SPIRIT VHNO value. Variety records created prior to July 2023 will use the VHNO value assigned (or edited) by the user with the variety record created directly in SPIRIT." ID="ID_1076604066" CREATED="1717443463592" MODIFIED="1717443463592"/>
</node>
<node TEXT="also determined by a person" ID="ID_716410277" CREATED="1716575972966" MODIFIED="1716575978656"/>
</node>
<node TEXT="Early Stage Name?" ID="ID_1739905457" CREATED="1717776317307" MODIFIED="1717776327428"/>
</node>
</node>
<node TEXT="Biological Entity (BE):" FOLDED="true" ID="ID_1867596891" CREATED="1715656875882" MODIFIED="1716574617774">
<font BOLD="true"/>
<node TEXT="about" FOLDED="true" ID="ID_1666578541" CREATED="1716576869755" MODIFIED="1716576871305">
<node TEXT="A general term for the basic (conceptual) entity that must be captured for Track and Trace.  This organism represents a distinct set of genetics within a Lineage-Based group and has a distinct Lineage and pedigree." ID="ID_1336973111" CREATED="1715658787963" MODIFIED="1715658787964"/>
<node TEXT="the most important classification in the Domain Model because it is used to derive and build multiple material identities and relationships" ID="ID_922040624" CREATED="1716576873628" MODIFIED="1716576889587"/>
</node>
<node TEXT="types" FOLDED="true" ID="ID_120617690" CREATED="1716576385649" MODIFIED="1716576388762">
<node TEXT="plant materials" ID="ID_246119030" CREATED="1716576388777" MODIFIED="1716576391173"/>
<node TEXT="DNA vectors" ID="ID_1992527993" CREATED="1716576391197" MODIFIED="1716576396581"/>
</node>
<node TEXT="must be directly or indirectly related to a Population LBG" FOLDED="true" ID="ID_107717949" CREATED="1716576434346" MODIFIED="1716576446950">
<node TEXT="may also be related to a Family LBG" ID="ID_1082394492" CREATED="1716576450152" MODIFIED="1716576459915"/>
</node>
<node TEXT="can be associated with multiple batches" ID="ID_670152482" CREATED="1716576490967" MODIFIED="1716576496041"/>
</node>
<node TEXT="Biological Entity Business Identifier (BE BID)" FOLDED="true" ID="ID_112483096" CREATED="1715657022671" MODIFIED="1716569080400">
<font BOLD="true"/>
<node TEXT="starts with an E" ID="ID_538566930" CREATED="1715960620649" MODIFIED="1715960624725"/>
<node TEXT="generated from" FOLDED="true" ID="ID_1840932618" CREATED="1715787800727" MODIFIED="1715787804010">
<node TEXT="Stable Line Code" ID="ID_150346908" CREATED="1715787805112" MODIFIED="1715787815204"/>
<node TEXT="Stable Variety Code" ID="ID_1862995566" CREATED="1715787816275" MODIFIED="1715787821232"/>
</node>
<node TEXT="Each BE assigned owner" FOLDED="true" ID="ID_377199244" CREATED="1715959792463" MODIFIED="1715959800020">
<node TEXT="Spirit Breeding Group Name" FOLDED="true" ID="ID_1445265629" CREATED="1715959896817" MODIFIED="1715959914089">
<node TEXT="has 1 owner" ID="ID_453391934" CREATED="1715960002895" MODIFIED="1715960007248"/>
</node>
<node TEXT="bg_owner" ID="ID_38651243" CREATED="1715959917378" MODIFIED="1715959920257"/>
</node>
<node TEXT="Biological Entity Business Identifier (BE BID)" FOLDED="true" ID="ID_719231290" CREATED="1715657022671" MODIFIED="1715657039522">
<node TEXT="Biological Entity (BE):" FOLDED="true" ID="ID_1785969431" CREATED="1715656875882" MODIFIED="1715658787961">
<node TEXT="Displayed in Spirit" ID="ID_1788264051" CREATED="1715792749860" MODIFIED="1715792767046"/>
<node TEXT="A general term for the basic (conceptual) entity that must be captured for Track and Trace.  This organism represents a distinct set of genetics within a Lineage-Based group and has a distinct Lineage and pedigree." ID="ID_383929276" CREATED="1715658787963" MODIFIED="1715658787964"/>
</node>
<node TEXT="definition" ID="ID_1349356483" CREATED="1715658753155" MODIFIED="1715658755960"/>
<node TEXT="primary indicator of the germplasm background" ID="ID_1503425545" CREATED="1715657040386" MODIFIED="1715657045168"/>
<node TEXT="Stable Line Code" FOLDED="true" ID="ID_1401710156" CREATED="1715657089672" MODIFIED="1715657089672">
<node TEXT="Every Line Code in Identity will have a BE BID inherited to its progeny when self or sib pollinated." ID="ID_144644247" CREATED="1715657089672" MODIFIED="1715657089672"/>
<node TEXT="A line code is intended to have a single BE BID" FOLDED="true" ID="ID_1816767734" CREATED="1715657089672" MODIFIED="1715657822486">
<node TEXT="1 to 1 relationship" ID="ID_1302169293" CREATED="1715657826514" MODIFIED="1715657837400"/>
</node>
</node>
<node TEXT="Stable Line Code Indicator" FOLDED="true" ID="ID_1246071789" CREATED="1715795279878" MODIFIED="1715795290095">
<node TEXT="Y when line is stable" FOLDED="true" ID="ID_1600201531" CREATED="1715795290883" MODIFIED="1715795308732">
<node TEXT="Example" FOLDED="true" ID="ID_503171553" CREATED="1715795313723" MODIFIED="1715795315871">
<node TEXT="DHs" ID="ID_1412982818" CREATED="1715795309401" MODIFIED="1715795311489"/>
</node>
</node>
</node>
<node TEXT="Early Stage Name" FOLDED="true" ID="ID_1260355562" CREATED="1715795359544" MODIFIED="1715795366393">
<node TEXT="ABBRC" ID="ID_1467924390" CREATED="1715795367240" MODIFIED="1715795375134"/>
</node>
<node TEXT="Stable Variety Code (Hybrid or F1 Code)" FOLDED="true" ID="ID_1019875378" CREATED="1715657089672" MODIFIED="1715657971441">
<node TEXT="not neccessarily a stable line" ID="ID_657256343" CREATED="1715795389268" MODIFIED="1715795465649"/>
<node TEXT="Hybrid Intent" FOLDED="true" ID="ID_1649481988" CREATED="1715795479208" MODIFIED="1715795482810">
<node TEXT="will be used for evaluation" ID="ID_462180283" CREATED="1715795483411" MODIFIED="1715795509263"/>
</node>
<node TEXT="Breeding Start Intent" ID="ID_1509381798" CREATED="1715795510708" MODIFIED="1715795559569"/>
<node TEXT="When two stable BE BID are crossed, a BE BID is assigned.  This BE BID is not considered stable but whenever those same two BE BID are used, the BE BID assigned from the first instance will be given to the new batch generated." ID="ID_263611292" CREATED="1715657089672" MODIFIED="1715657089672"/>
<node TEXT="A Stable Variety Code is intended to have a single BE BID." ID="ID_1354442955" CREATED="1715657089677" MODIFIED="1715657089677"/>
</node>
</node>
</node>
<node TEXT="Physical Identity" FOLDED="true" ID="ID_1860277092" CREATED="1716569257083" MODIFIED="1716569331647">
<font BOLD="false" ITALIC="true"/>
<node TEXT="Batch" FOLDED="true" ID="ID_1613532057" CREATED="1715787861486" MODIFIED="1716569085466">
<font BOLD="true"/>
<node TEXT="Batch – A homogeneous group of physical material that is known to be produced under uniform conditions in one location at one time" FOLDED="true" ID="ID_1214945860" CREATED="1715656875882" MODIFIED="1715656875882">
<node TEXT="hybrid or line harvest" ID="ID_1408109048" CREATED="1715658170936" MODIFIED="1715658197936"/>
</node>
<node TEXT="serves as the bridge between conceptual and physical identity" FOLDED="true" ID="ID_1913283826" CREATED="1716577433546" MODIFIED="1716577441348">
<node TEXT="point of intersection between the Material Management and Identity Management Applications" FOLDED="true" ID="ID_999901429" CREATED="1716583574960" MODIFIED="1716583586921">
<node TEXT="example" FOLDED="true" ID="ID_746056240" CREATED="1716583645954" MODIFIED="1716583649113">
<node TEXT="mixing from two BEs indifferent LBGs requires the creation of a new LBG, BE, and Batch" ID="ID_22976628" CREATED="1716583649115" MODIFIED="1716583684709"/>
<node TEXT="determined by the Identity Rules Engine" ID="ID_1877015349" CREATED="1716583705960" MODIFIED="1716583714124"/>
</node>
</node>
<node TEXT="enables Material Management to handle the physical aspects of each material in MINT inventory" ID="ID_1342397043" CREATED="1716583741359" MODIFIED="1716583761361"/>
</node>
<node TEXT="Physical Material (PM)" FOLDED="true" ID="ID_1377449579" CREATED="1716008780567" MODIFIED="1716569131008">
<font BOLD="true"/>
<node TEXT="physical instance of a biological material (Batch) that has a quantity and exists at a location at any given time" ID="ID_67027737" CREATED="1716577043162" MODIFIED="1716577101694"/>
<node TEXT="must be associated with a container" ID="ID_1065944883" CREATED="1716577132776" MODIFIED="1716577182965"/>
<node TEXT="MINT traces a genetic identity of Physical Materials all the way up the model, with identifiers for Batch, BE, and LBG" ID="ID_19392774" CREATED="1716577501561" MODIFIED="1716577551566"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Using The Domain Model To Find Answers To Key Questions" FOLDED="true" ID="ID_1248861443" CREATED="1716583979967" MODIFIED="1716583994924">
<node TEXT="png-240524-135316210-6387210673873725037.png" ID="ID_417744985" CREATED="1716583997983" MODIFIED="1716583997983">
<hook URI="DataStewardshipAnalyst_files/png-240524-135316210-6387210673873725037.png" SIZE="0.3374578" NAME="ExternalObject"/>
</node>
</node>
</node>
<node ID="ID_360722682" CREATED="1719515123838" MODIFIED="1719515123838"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="font-family: Segoe UI, Segoe UI Web(West European), -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 18px; font-style: normal; font-weight: 400; line-height: 1.4em; color: rgb(51, 51, 51); margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(250, 250, 250)">
      <h4 id="what-is-mint-identity-management" style="font-family: var(--fontFamilyCustomFont1000, var(--fontFamilyBase)); color: rgb(51, 51, 51); font-size: 20px; line-height: 1.4em; margin-top: 0px; margin-right: 0px; margin-bottom: 12px; margin-left: 0px; font-weight: 600">
        What is MINT Identity Management?
      </h4>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1134273341" CREATED="1719515123840" MODIFIED="1719515123840"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="font-family: Segoe UI, Segoe UI Web(West European), -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; color: rgb(51, 51, 51); font-size: 18px; font-weight: 400; line-height: 1.4em; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-style: normal; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(250, 250, 250)">
      Identity Management is a system that stores and connects lineage and relationships for materials created and used by Syngenta R&amp;D. It provides a way to describe and trace changes in identity throughout product development.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="definition" FOLDED="true" ID="ID_1497610581" CREATED="1719515210846" MODIFIED="1719515212662">
<node TEXT="Identity Management is a system that stores and connects lineage and relationships for materials created and used by Syngenta R&amp;D. It provides a way to describe and trace changes in identity throughout product development." ID="ID_1267765184" CREATED="1719515214360" MODIFIED="1719515214360"/>
</node>
</node>
<node TEXT="Development" FOLDED="true" ID="ID_1598793618" CREATED="1716902313900" MODIFIED="1717770624561">
<node TEXT="Monthly Demo" ID="ID_1696092536" CREATED="1734445098553" MODIFIED="1734445108026"/>
<node TEXT="Traits" FOLDED="true" ID="ID_477274342" CREATED="1717772141436" MODIFIED="1717772145381">
<node TEXT="New Rules, Approach" FOLDED="true" ID="ID_1118994084" CREATED="1717772145795" MODIFIED="1717772153003">
<node TEXT="Jeff Bottoms" ID="ID_1223526405" CREATED="1717772154193" MODIFIED="1717772157144"/>
</node>
</node>
<node TEXT="ref" FOLDED="true" ID="ID_77505559" CREATED="1717770609474" MODIFIED="1717770610559">
<node ID="ID_1955316049" CREATED="1717770328265" MODIFIED="1717770328265" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TraitIdentity-CoreTeam/Shared%20Documents/3_Core%20team%20space/1.%20Org%20-%20WoW%20-%20Contacts/Germplasm%20and%20Trait%20Identity%20Program_v5.pptx?d=w8be43074dcc943cda3bdad2d26d8ae09&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=mIxeSO"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TraitIdentity-CoreTeam/Shared%20Documents/3_Core%20team%20space/1.%20Org%20-%20WoW%20-%20Contacts/Germplasm%20and%20Trait%20Identity%20Program_v5.pptx?d=w8be43074dcc943cda3bdad2d26d8ae09&amp;csf=1&amp;web=1&amp;e=mIxeSO">Germplasm and Trait Identity Program_v5.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1345738560" CREATED="1716902319735" MODIFIED="1716902319735" LINK="https://syngenta.sharepoint.com/:f:/r/sites/AnalyticsDataSciences/Shared%20Documents/General/Programs/Program%20-%20DS%20-%20Germplasm%20%26%20Trait%20Identity?csf=1&amp;amp;web=1&amp;amp;e=4ihLte"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:f:/r/sites/AnalyticsDataSciences/Shared%20Documents/General/Programs/Program%20-%20DS%20-%20Germplasm%20%26%20Trait%20Identity?csf=1&amp;web=1&amp;e=4ihLte">Program - DS - Germplasm &amp; Trait Identity</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Core SME play a major role in the projects" FOLDED="true" ID="ID_1177480478" CREATED="1717771206121" MODIFIED="1717771206121">
<node TEXT="Represent Identity stakeholders, collecting and explaining the needs." ID="ID_1692563179" CREATED="1717771206121" MODIFIED="1717771206121"/>
<node TEXT="Collaborate with Identity scrum team to help define a suitable solution." ID="ID_1809818827" CREATED="1717771206123" MODIFIED="1717771206123"/>
<node TEXT="Test / validate the solution when appropriate (can involve other stakeholders as well)." ID="ID_47268281" CREATED="1717771206124" MODIFIED="1717771206124"/>
<node TEXT="Support stakeholders in the adoption of Identity domain model." ID="ID_77102961" CREATED="1717771206125" MODIFIED="1717771206125"/>
<node TEXT="When support tickets are created, depending on the topic, the Identity team could ask some help." ID="ID_548648521" CREATED="1717771206126" MODIFIED="1717771206126"/>
<node TEXT="ref" FOLDED="true" ID="ID_1606040501" CREATED="1717771224786" MODIFIED="1717771225628">
<node ID="ID_1347509024" CREATED="1717770328265" MODIFIED="1717770328265" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TraitIdentity-CoreTeam/Shared%20Documents/3_Core%20team%20space/1.%20Org%20-%20WoW%20-%20Contacts/Germplasm%20and%20Trait%20Identity%20Program_v5.pptx?d=w8be43074dcc943cda3bdad2d26d8ae09&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=mIxeSO"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TraitIdentity-CoreTeam/Shared%20Documents/3_Core%20team%20space/1.%20Org%20-%20WoW%20-%20Contacts/Germplasm%20and%20Trait%20Identity%20Program_v5.pptx?d=w8be43074dcc943cda3bdad2d26d8ae09&amp;csf=1&amp;web=1&amp;e=mIxeSO">Germplasm and Trait Identity Program_v5.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Gathering Requirements" FOLDED="true" ID="ID_1098837313" CREATED="1717770336466" MODIFIED="1717770341525">
<node FOLDED="true" ID="ID_519189237" CREATED="1717770312035" MODIFIED="1717770312035" LINK="https://syngenta.sharepoint.com/:x:/r/sites/TraitIdentity/Shared%20Documents/1_REQUIREMENT%20gathering/Identity%20requirement%20gathering.xlsx?d=w5015014697db469c9afe2967200441df&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=TbvmNd"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/TraitIdentity/Shared%20Documents/1_REQUIREMENT%20gathering/Identity%20requirement%20gathering.xlsx?d=w5015014697db469c9afe2967200441df&amp;csf=1&amp;web=1&amp;e=TbvmNd">Identity requirement gathering.xlsx</a>
  </body>
</html>
</richcontent>
<node TEXT="Core SME" ID="ID_1937581234" CREATED="1717770498220" MODIFIED="1717770501234"/>
</node>
</node>
</node>
<node TEXT="Functions" ID="ID_416828541" CREATED="1716217529967" MODIFIED="1721051501181">
<font SIZE="16" BOLD="true"/>
<node TEXT="reference" FOLDED="true" POSITION="bottom_or_right" ID="ID_54409896" CREATED="1716588674273" MODIFIED="1716588676538">
<node TEXT="MINT Identity Functionality Slides" FOLDED="true" ID="ID_1481985283" CREATED="1716588888328" MODIFIED="1716588912936" LINK="https://syngenta.sharepoint.com/:b:/r/sites/Test614/Shared%20Documents/MINT%20Identity/Training%20and%20Guidelines/Identity_Functionality_QRGs_final.pdf?csf=1&amp;amp;web=1&amp;amp;e=YPWh4T">
<node ID="ID_1727577091" CREATED="1716588918721" MODIFIED="1716589055253" LINK="https://www.syngentalms-ag.com/learn/course/2708/play/3829/mint-identity-functionality-english-gl"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.syngentalms-ag.com/learn/course/2708/play/3829/mint-identity-functionality-english-gl">Syngenta's Learning Management System: MINT Identity Functionality Demo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1885649382" CREATED="1716614533641" MODIFIED="1716614533641" LINK="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/Forms/AllItems.aspx">MINT Communications - All Documents</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Adding New Materials" POSITION="bottom_or_right" ID="ID_1562108714" CREATED="1716585807990" MODIFIED="1721051618560">
<font BOLD="true"/>
<node TEXT="Connecting with parentage" FOLDED="true" ID="ID_1208896794" CREATED="1721049524468" MODIFIED="1721049615527">
<icon BUILTIN="yes"/>
<font ITALIC="true"/>
<node TEXT="Maintainer Line Assignment" ID="ID_931855080" CREATED="1721049651301" MODIFIED="1721049659688"/>
<node TEXT="?Virtual Cross" ID="ID_1564813230" CREATED="1721049662332" MODIFIED="1721049667349"/>
</node>
<node TEXT="Bulk Manually Adding Identity (acquired materials)" FOLDED="true" ID="ID_437589937" CREATED="1715958763289" MODIFIED="1717429907590">
<font BOLD="true"/>
<node TEXT="Reference" FOLDED="true" ID="ID_1934659080" CREATED="1716482756286" MODIFIED="1716482759757">
<node TEXT="Meeting 5/23 Michele" ID="ID_274056494" CREATED="1716480313466" MODIFIED="1716480323800"/>
<node FOLDED="true" ID="ID_1424626565" CREATED="1716481991882" MODIFIED="1716481991882" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/_layouts/15/Doc2.aspx?action=edit&amp;amp;sourcedoc=%7Ba4ebfc5b-3f27-4b54-b8c5-3e7c20e8cb65%7D&amp;amp;wdOrigin=TEAMS-MAGLEV.teamsSdk_ns.rwc&amp;amp;wdExp=TEAMS-TREATMENT&amp;amp;wdhostclicktime=1716481791865&amp;amp;web=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/_layouts/15/Doc2.aspx?action=edit&amp;sourcedoc=%7Ba4ebfc5b-3f27-4b54-b8c5-3e7c20e8cb65%7D&amp;wdOrigin=TEAMS-MAGLEV.teamsSdk_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1716481791865&amp;web=1">Manual_Adds_Guidelines_IdentityManagement_V1.pptx</a>
  </body>
</html>
</richcontent>
<node ID="ID_467274526" CREATED="1716482342597" MODIFIED="1716482342597" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/Shared%20Documents/21_Training%20Resources/Manual_Adds_Guidelines_IdentityManagement_V1.pptx?d=wa4ebfc5b3f274b54b8c53e7c20e8cb65&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=2jgjXW&amp;amp;nav=eyJzSWQiOjM0MSwiY0lkIjozNjkyOTU1MTAyfQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/Shared%20Documents/21_Training%20Resources/Manual_Adds_Guidelines_IdentityManagement_V1.pptx?d=wa4ebfc5b3f274b54b8c53e7c20e8cb65&amp;csf=1&amp;web=1&amp;e=2jgjXW&amp;nav=eyJzSWQiOjM0MSwiY0lkIjozNjkyOTU1MTAyfQ">Manual_Adds_Guidelines_IdentityManagement_V1.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="13" OBJECT="java.lang.Long|13" FOLDED="true" ID="ID_625592757" CREATED="1716482379986" MODIFIED="1716482380644">
<node TEXT="MINT identifier when identity exists (e.g.: Biological Entity BID) ​" ID="ID_1874547055" CREATED="1716482393391" MODIFIED="1716482393391"/>
<node TEXT="Variety name/ accession number/ Line code​" ID="ID_879166819" CREATED="1716482393391" MODIFIED="1716482393391"/>
<node TEXT="Seed Production Identifiers (e.g: SAP Lot, SAP Batch, Lot ID)​" ID="ID_1004444103" CREATED="1716482393394" MODIFIED="1716482393394"/>
<node TEXT="GARF ID* (one per acquisition per supplier per crop)​" ID="ID_12871717" CREATED="1716482393395" MODIFIED="1716482393395"/>
<node TEXT="e.g.: commercial purchase or material transfer agreement (MTA)​" ID="ID_828649825" CREATED="1716482393396" MODIFIED="1716482393396"/>
<node TEXT="Country of germplasm origin​" FOLDED="true" ID="ID_1842082559" CREATED="1716482393397" MODIFIED="1716482393397">
<node TEXT="where genes are coming from" FOLDED="true" ID="ID_597209586" CREATED="1716482429957" MODIFIED="1716482450338">
<node TEXT="unknown usually" ID="ID_1245938022" CREATED="1716482450954" MODIFIED="1716482455685"/>
</node>
</node>
<node TEXT="Provider of the physical seeds/plants (supplier)​" FOLDED="true" ID="ID_289897606" CREATED="1716482393397" MODIFIED="1716482393397">
<node TEXT="Company that you are purchasing from" ID="ID_888160089" CREATED="1716482398050" MODIFIED="1716482428421"/>
</node>
<node TEXT="Country (and state if United States) of harvest location​" FOLDED="true" ID="ID_214444058" CREATED="1716482393398" MODIFIED="1716482393398">
<node TEXT="United States need State as well" ID="ID_1052028965" CREATED="1716482467220" MODIFIED="1716482480146"/>
</node>
<node TEXT="Material Owner (Syngenta ID known in MINT Identity)​" FOLDED="true" ID="ID_1698144666" CREATED="1716482393399" MODIFIED="1716482393399">
<node TEXT="batch and BE" ID="ID_1213656894" CREATED="1716482483105" MODIFIED="1716482501674"/>
<node TEXT="if get request, who should be owner" ID="ID_1439527206" CREATED="1716482534761" MODIFIED="1716482550898"/>
<node TEXT="if blank, ownership is assumed to" ID="ID_1958140172" CREATED="1716482504432" MODIFIED="1716482534152"/>
</node>
<node TEXT="GM status (Y/N) and genes​" FOLDED="true" ID="ID_1987582557" CREATED="1716482393399" MODIFIED="1716482393399">
<node TEXT="" ID="ID_871830414" CREATED="1716482555528" MODIFIED="1716482555528"/>
</node>
<node TEXT="​" ID="ID_1041810795" CREATED="1716482393400" MODIFIED="1716482393400"/>
<node TEXT="*not required if an internal acquisition (Obtained from Syngenta Entity acquisition type)​" ID="ID_1165045118" CREATED="1716482393401" MODIFIED="1716482393401"/>
<node TEXT="​" ID="ID_324596737" CREATED="1716482393402" MODIFIED="1716482393402"/>
</node>
</node>
<node TEXT="https://refdata.cloud.syngenta.org/RDWebGUI/view/XRDTree.aspx" ID="ID_147819462" CREATED="1716483022706" MODIFIED="1716483022706" LINK="https://refdata.cloud.syngenta.org/RDWebGUI/view/XRDTree.aspx"/>
<node TEXT="Creator" FOLDED="true" ID="ID_347633313" CREATED="1716482149161" MODIFIED="1716482151994">
<node TEXT="one for each crop" ID="ID_1007757494" CREATED="1716482152824" MODIFIED="1716482157810"/>
<node TEXT="need list" ID="ID_685150091" CREATED="1716482158833" MODIFIED="1716482162194"/>
</node>
<node TEXT="Provider" FOLDED="true" ID="ID_1514161432" CREATED="1715958782581" MODIFIED="1715958807750">
<node TEXT="Identitity of seed isn&apos;t in IM" FOLDED="true" ID="ID_1238339662" CREATED="1715958910021" MODIFIED="1715958936650">
<node TEXT="From outside of the System" ID="ID_233560666" CREATED="1715958850579" MODIFIED="1715958875680"/>
</node>
<node TEXT="If populated, was added manually." ID="ID_1389213198" CREATED="1715959048370" MODIFIED="1715959073156"/>
<node TEXT="Created Date" FOLDED="true" ID="ID_1223416360" CREATED="1715959076721" MODIFIED="1715959080717">
<node TEXT="When created in IM" ID="ID_1250984281" CREATED="1715959081194" MODIFIED="1715959088278"/>
</node>
<node TEXT="Companies" ID="ID_388568878" CREATED="1715958808086" MODIFIED="1715958849309"/>
</node>
<node TEXT="Training" ID="ID_1036431348" CREATED="1716929681202" MODIFIED="1717003211330" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Identity%20Management/Bulk%20Manually%20Adding%20Identity/Training">
<icon BUILTIN="yes"/>
<icon BUILTIN="button_ok"/>
<attribute NAME="WhenDone" VALUE="2024-05-29" OBJECT="org.freeplane.features.format.FormattedDate|2024-05-29T13:20-0400|yyyy-MM-dd"/>
</node>
</node>
<node TEXT="Type of Acquistion" FOLDED="true" ID="ID_981700785" CREATED="1716482723257" MODIFIED="1716482729857">
<node TEXT="Each combination needs it&apos;s own template" ID="ID_313487823" CREATED="1716482698520" MODIFIED="1716482716295"/>
<node TEXT="Bio Material Category" FOLDED="true" ID="ID_1072057378" CREATED="1716482835865" MODIFIED="1716482844195">
<node TEXT="Subtype of crop" FOLDED="true" ID="ID_825616453" CREATED="1716482845146" MODIFIED="1716482853562">
<node TEXT="https://refdata.cloud.syngenta.org/RDWebGUI/view/XRDTree.aspx" FOLDED="true" ID="ID_576064438" CREATED="1716483022706" MODIFIED="1716483022706" LINK="https://refdata.cloud.syngenta.org/RDWebGUI/view/XRDTree.aspx">
<node TEXT="Connections:" ID="ID_1209732626" CREATED="1716483062402" MODIFIED="1716483112931"/>
<node TEXT="png-240523-095142329-13144843949896353937.png" ID="ID_424064920" CREATED="1716483103345" MODIFIED="1716483103345">
<hook URI="DataStewardshipAnalyst_files/png-240523-095142329-13144843949896353937.png" SIZE="0.31413612" NAME="ExternalObject"/>
</node>
</node>
</node>
</node>
<node TEXT="GM Material" ID="ID_1135385763" CREATED="1716483143968" MODIFIED="1716483150706"/>
</node>
<node TEXT="Display Provider List" FOLDED="true" ID="ID_1204511761" CREATED="1716483165956" MODIFIED="1716483299578">
<node TEXT="notes" FOLDED="true" ID="ID_414250354" CREATED="1716483200855" MODIFIED="1716483202658">
<node TEXT="its a mess" ID="ID_660783275" CREATED="1716483203354" MODIFIED="1716483207393"/>
</node>
<node TEXT="List of Companies" ID="ID_1987815418" CREATED="1716483187330" MODIFIED="1716483199366"/>
<node TEXT="Admins can create providers" ID="ID_1925606572" CREATED="1716483215903" MODIFIED="1716483230105"/>
<node TEXT="Export" ID="ID_689516619" CREATED="1716483235873" MODIFIED="1716483239023"/>
</node>
<node TEXT="Suggested Generation Codes" ID="ID_1075726856" CREATED="1716483412825" MODIFIED="1716483420371"/>
<node TEXT="Download Template" FOLDED="true" ID="ID_1998312491" CREATED="1716483462456" MODIFIED="1716483468374">
<node TEXT="Get template to add materials" FOLDED="true" ID="ID_1979296447" CREATED="1716483500400" MODIFIED="1716483509965">
<node TEXT="Populate" FOLDED="true" ID="ID_1879946249" CREATED="1716483558632" MODIFIED="1716483611179">
<node ID="ID_409816956" CREATED="1716483652496" MODIFIED="1716483659909" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/Shared%20Documents/21_Training%20Resources/Manual_Adds_Guidelines_IdentityManagement_V1.pptx?d=wa4ebfc5b3f274b54b8c53e7c20e8cb65&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=UglyFl&amp;amp;nav=eyJzSWQiOjMxOCwiY0lkIjozMTIyMzU5Nzd9"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/Shared%20Documents/21_Training%20Resources/Manual_Adds_Guidelines_IdentityManagement_V1.pptx?d=wa4ebfc5b3f274b54b8c53e7c20e8cb65&amp;csf=1&amp;web=1&amp;e=UglyFl&amp;nav=eyJzSWQiOjMxOCwiY0lkIjozMTIyMzU5Nzd9">Manual_Adds_Guidelines_IdentityManagement_V1.pptx, 16</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="keep headers the same, (can change order)" ID="ID_1175854989" CREATED="1716483845544" MODIFIED="1716483875506"/>
<node TEXT="LBG ID" FOLDED="true" ID="ID_1525587386" CREATED="1716483912399" MODIFIED="1716483922569">
<node TEXT="same if came" ID="ID_403470646" CREATED="1716483922968" MODIFIED="1716483937738"/>
</node>
<node TEXT="OPQ" FOLDED="true" ID="ID_1410144392" CREATED="1716483940391" MODIFIED="1716483945345">
<node TEXT="Leave blank when creating" ID="ID_355849962" CREATED="1716483946224" MODIFIED="1716483960649"/>
<node TEXT="Can change later, Breeder or self" ID="ID_1273569069" CREATED="1716483962503" MODIFIED="1716484063482"/>
<node TEXT="Stable" ID="ID_548237964" CREATED="1716483990440" MODIFIED="1716484032170"/>
</node>
<node TEXT="Intent" FOLDED="true" ID="ID_1975494066" CREATED="1716484319418" MODIFIED="1716484321650">
<node TEXT="especially wne creating new BE or Popluation" ID="ID_56724044" CREATED="1716484323256" MODIFIED="1716484339665"/>
</node>
<node TEXT="Hybrid Alias" FOLDED="true" ID="ID_1770810620" CREATED="1716484308736" MODIFIED="1716484313362">
<node TEXT="Leave Blank" ID="ID_589416871" CREATED="1716484314008" MODIFIED="1716484317684"/>
</node>
</node>
</node>
</node>
<node TEXT="Upload" FOLDED="true" ID="ID_810936033" CREATED="1716483513088" MODIFIED="1716483518625">
<node TEXT="Upload filled out template" ID="ID_827330732" CREATED="1716483519251" MODIFIED="1716483528203"/>
</node>
</node>
</node>
<node TEXT="Creating New Providers" ID="ID_1436567038" CREATED="1721050036074" MODIFIED="1721050046053">
<font BOLD="true"/>
</node>
<node TEXT="Change Owner Delegates" FOLDED="true" ID="ID_7640278" CREATED="1715959719517" MODIFIED="1715959726385">
<node TEXT="Manage Users" ID="ID_1994260164" CREATED="1715959715097" MODIFIED="1715959718805"/>
<node TEXT="Delegates" FOLDED="true" ID="ID_1764885059" CREATED="1715959743673" MODIFIED="1715959748207">
<node TEXT="can manage materials possessed by Owner" FOLDED="true" ID="ID_1794618829" CREATED="1715959748531" MODIFIED="1715959779205">
<node TEXT="promote to Stable Line Code" ID="ID_864228426" CREATED="1715960085176" MODIFIED="1715960092644"/>
<node TEXT="attribute editing" FOLDED="true" ID="ID_815540827" CREATED="1715960093238" MODIFIED="1715960118868">
<node TEXT="pedigree" ID="ID_45333603" CREATED="1715960119287" MODIFIED="1715960124515"/>
<node TEXT="gencd" ID="ID_632523703" CREATED="1715960124872" MODIFIED="1715960127186"/>
</node>
</node>
</node>
</node>
<node TEXT="Stabilize And Demote" ID="ID_1427700920" CREATED="1716217610598" MODIFIED="1716217614757"/>
<node TEXT="Edit Batch, BE and LBG attributes" ID="ID_1342064883" CREATED="1716217616694" MODIFIED="1716217633285"/>
<node TEXT="Search .. Search Criteria" FOLDED="true" POSITION="bottom_or_right" ID="ID_1276858032" CREATED="1715794078662" MODIFIED="1715959455466">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_916357097" CREATED="1715959485877" MODIFIED="1716598610930">
<node TEXT="User Guide Page" ID="ID_1426155594" CREATED="1716598588468" MODIFIED="1716599094460" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/Searching_for_a_MINT_Item.htm"/>
<node ID="ID_1183318627" CREATED="1716595831138" MODIFIED="1716595843123" LINK="https://www.syngentalms-ag.com/learn/course/3384/play/7861:1331/identity-management-search-functions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.syngentalms-ag.com/learn/course/3384/play/7861:1331/identity-management-search-functions">Syngenta's Learning Management System: Identity Management Search Functions </a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="not case sensitive" ID="ID_1792883371" CREATED="1715959491625" MODIFIED="1715960986737"/>
<node TEXT="separator: ," ID="ID_1650491585" CREATED="1715960995418" MODIFIED="1715961003326"/>
</node>
<node TEXT="about" FOLDED="true" ID="ID_1427526522" CREATED="1716595866986" MODIFIED="1716595869115">
<node TEXT="looking for information regarding lineage, relationships and genetics" ID="ID_1128941957" CREATED="1716595869118" MODIFIED="1716595916478"/>
</node>
<node TEXT="Build Search" FOLDED="true" ID="ID_1164086284" CREATED="1716599019407" MODIFIED="1716599024499">
<font BOLD="true"/>
<node TEXT="syntax" FOLDED="true" ID="ID_1190124399" CREATED="1716599369202" MODIFIED="1716599371566">
<node TEXT="wildcard" ID="ID_1273223910" CREATED="1716599372483" MODIFIED="1716599374809"/>
</node>
<node TEXT="Type" FOLDED="true" ID="ID_691610322" CREATED="1715794085197" MODIFIED="1715794088605">
<node TEXT="changes view based on type" ID="ID_1299057560" CREATED="1715794089288" MODIFIED="1715794109380"/>
</node>
<node TEXT="Creation Operation" FOLDED="true" ID="ID_48387881" CREATED="1715795643018" MODIFIED="1715795648609">
<node TEXT="" ID="ID_642449694" CREATED="1715795651461" MODIFIED="1715795651461"/>
</node>
<node TEXT="Creation Engine" FOLDED="true" ID="ID_634943963" CREATED="1715795678383" MODIFIED="1715795685896">
<node TEXT="Half Sib (not Supported)" ID="ID_1828758319" CREATED="1715795686869" MODIFIED="1715795718809"/>
</node>
<node TEXT="Created Date" FOLDED="true" ID="ID_444946055" CREATED="1715959183960" MODIFIED="1715959188911">
<node TEXT="from Spirit" FOLDED="true" ID="ID_817523346" CREATED="1715959207560" MODIFIED="1715959211729">
<node TEXT="Material Creation Date" ID="ID_599358885" CREATED="1715959212395" MODIFIED="1715959217684"/>
<node TEXT="note" FOLDED="true" ID="ID_1746592036" CREATED="1715959341815" MODIFIED="1715959343215">
<node TEXT="for Migrated materials, all sent over on the same" ID="ID_1058414172" CREATED="1715959343907" MODIFIED="1715959364283"/>
</node>
</node>
</node>
<node TEXT="Synonyms" FOLDED="true" ID="ID_1751758950" CREATED="1715959385407" MODIFIED="1715959389591">
<node TEXT="Useful for migrated materials, and MATIDS" ID="ID_1777173879" CREATED="1715959390268" MODIFIED="1715959403017"/>
</node>
<node TEXT="Creation Operator" FOLDED="true" ID="ID_1100317303" CREATED="1715959509057" MODIFIED="1715959524344">
<node TEXT="manual adds" ID="ID_1573587430" CREATED="1715959531669" MODIFIED="1715959590859"/>
</node>
<node TEXT="Relationship" ID="ID_1679708684" CREATED="1715959594595" MODIFIED="1715959603318"/>
<node TEXT="Owner" FOLDED="true" ID="ID_1945814315" CREATED="1715959603695" MODIFIED="1715959605427">
<node TEXT="Select, and hover to see delegates in table" ID="ID_1426466060" CREATED="1715959696629" MODIFIED="1715960330108"/>
</node>
<node TEXT="Hybrid Alias" FOLDED="true" ID="ID_383380541" CREATED="1715960389246" MODIFIED="1715960394013">
<node TEXT="don&apos;t recommend users use" ID="ID_580241660" CREATED="1715960407639" MODIFIED="1715960420724"/>
<node TEXT="meant for functionality that cant be susta" ID="ID_1237535741" CREATED="1715960394738" MODIFIED="1715960406776"/>
</node>
<node TEXT="Intent" FOLDED="true" ID="ID_122566243" CREATED="1715960421675" MODIFIED="1715960426131">
<node TEXT="BE and Batch" ID="ID_338331748" CREATED="1715960724022" MODIFIED="1715960729014"/>
<node TEXT="intended to be used for hybrid crops" ID="ID_377973423" CREATED="1715960443333" MODIFIED="1715960586134"/>
<node TEXT="if idenetity creating meant for evaluation purposes" ID="ID_569090999" CREATED="1715960426526" MODIFIED="1715960442479"/>
<node TEXT="can check only one at a time" ID="ID_1137894418" CREATED="1715960926157" MODIFIED="1715960934555"/>
<node TEXT="boxes" FOLDED="true" ID="ID_809692545" CREATED="1715960475521" MODIFIED="1715960480391">
<node TEXT="Any" ID="ID_965031523" CREATED="1715960481916" MODIFIED="1715960520492"/>
<node TEXT="None" ID="ID_1373034648" CREATED="1715960520812" MODIFIED="1715960522579"/>
<node TEXT="Hybrid Only" FOLDED="true" ID="ID_1211475088" CREATED="1715960523555" MODIFIED="1715960527427">
<node TEXT="evaluation" ID="ID_913987008" CREATED="1715960563190" MODIFIED="1715960570520"/>
<node TEXT="Breeding start empty" ID="ID_563502689" CREATED="1715960680595" MODIFIED="1715960687471"/>
</node>
<node TEXT="All Hybrid" FOLDED="true" ID="ID_880819461" CREATED="1715960688712" MODIFIED="1715960693382">
<node TEXT="All" ID="ID_201434808" CREATED="1715960694080" MODIFIED="1715960716928"/>
<node TEXT="Hybrtid only, Breeding start" ID="ID_1342221559" CREATED="1715960806416" MODIFIED="1715960815327"/>
<node TEXT="Both" ID="ID_1576498658" CREATED="1715960815828" MODIFIED="1715960818712"/>
</node>
<node TEXT="Unknown" FOLDED="true" ID="ID_408805100" CREATED="1715960865498" MODIFIED="1715960869471">
<node TEXT="asigned U" ID="ID_761385392" CREATED="1715960870250" MODIFIED="1715960874522"/>
</node>
</node>
<node TEXT="" ID="ID_443855122" CREATED="1715960823400" MODIFIED="1715960823400"/>
</node>
<node TEXT="Stable Line Cd" FOLDED="true" ID="ID_897879799" CREATED="1715960751187" MODIFIED="1715960757211">
<node TEXT="Assigned at BE level, visable at batch level" ID="ID_1533566688" CREATED="1715960765706" MODIFIED="1715960778962"/>
<node TEXT="Ind: Indicator" FOLDED="true" ID="ID_203065663" CREATED="1715960967975" MODIFIED="1715961039820">
<node TEXT="use box" FOLDED="true" ID="ID_1151496029" CREATED="1715961048069" MODIFIED="1715961175158">
<node TEXT="Ind Only" FOLDED="true" ID="ID_1374085311" CREATED="1715961154522" MODIFIED="1715961178351">
<node TEXT="no Stable Line Code" ID="ID_1055659025" CREATED="1715961179035" MODIFIED="1715961186449"/>
</node>
<node TEXT="Yes" FOLDED="true" ID="ID_1129814864" CREATED="1715961187606" MODIFIED="1715961189874">
<node TEXT="Stable Line Indicator" ID="ID_1608929977" CREATED="1715961190686" MODIFIED="1715961205996"/>
</node>
</node>
</node>
</node>
<node TEXT="Stable Variety Code" FOLDED="true" ID="ID_241637353" CREATED="1715960757597" MODIFIED="1715961212281">
<node TEXT="separator: |" ID="ID_1276864864" CREATED="1715961277903" MODIFIED="1715961284050"/>
<node TEXT="assignment of Hybrid name" FOLDED="true" ID="ID_531642581" CREATED="1715961213937" MODIFIED="1715961223149">
<node TEXT="have a variety record in Spirit" ID="ID_500108516" CREATED="1715961230945" MODIFIED="1715961251450"/>
</node>
<node TEXT="Assigned at BE level, visable at batch level" ID="ID_723318375" CREATED="1715960765706" MODIFIED="1715960778962"/>
</node>
<node TEXT="Earl Stage Name" FOLDED="true" ID="ID_120295517" CREATED="1715961324656" MODIFIED="1715961329390">
<node TEXT="assign a value at BE level" FOLDED="true" ID="ID_1061058827" CREATED="1715961330005" MODIFIED="1715961343407">
<node TEXT="can be stable or not" ID="ID_206449632" CREATED="1715961352326" MODIFIED="1715961357681"/>
<node TEXT="Used as ABBRC" ID="ID_1183375378" CREATED="1715961361954" MODIFIED="1715961397902"/>
</node>
<node TEXT="? Alias for breeders" ID="ID_1093377584" CREATED="1715961541031" MODIFIED="1715961551349"/>
<node TEXT="cant put in certain characters" ID="ID_1881207730" CREATED="1715961471783" MODIFIED="1715961491798"/>
</node>
</node>
<node TEXT="Search Results" FOLDED="true" ID="ID_603404318" CREATED="1716599146238" MODIFIED="1716599151458">
<font BOLD="true"/>
<node TEXT="Sort" FOLDED="true" ID="ID_474292203" CREATED="1716599030844" MODIFIED="1716599641922" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/Sorting_Results.htm">
<font BOLD="true"/>
<node TEXT="Default is sorted by Type" ID="ID_131216195" CREATED="1716599036497" MODIFIED="1716599056264"/>
<node TEXT="click header to sort by that identifier" FOLDED="true" ID="ID_858901144" CREATED="1716599057113" MODIFIED="1716599071122">
<node TEXT="click multiple headers to have multiple layers of sorting" ID="ID_1612004578" CREATED="1716599071880" MODIFIED="1716599088683"/>
</node>
<node TEXT="click Clear Sort Order to return to the default order" ID="ID_1044188734" CREATED="1716599113025" MODIFIED="1716599128680"/>
</node>
<node TEXT="Filter" FOLDED="true" ID="ID_144485201" CREATED="1716599159476" MODIFIED="1716599652920" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/Filtering_the_Search_Results.htm">
<font BOLD="true"/>
<node TEXT="click checkboxes for items" ID="ID_1393959801" CREATED="1716599185719" MODIFIED="1716599190524"/>
<node TEXT="click Filter" ID="ID_1667451318" CREATED="1716599191143" MODIFIED="1716599199334"/>
<node TEXT="Note: if export, will only include shown items" ID="ID_1290940524" CREATED="1716599200383" MODIFIED="1716599483695"/>
<node TEXT="remove grouping by running the search again (click Search)" ID="ID_1932443496" CREATED="1716599445484" MODIFIED="1716599463472"/>
</node>
<node TEXT="Group" FOLDED="true" ID="ID_593479179" CREATED="1716599236471" MODIFIED="1716599241489">
<font BOLD="true"/>
<node TEXT="when results are less than 1000" ID="ID_1946162719" CREATED="1716599243657" MODIFIED="1716599338361"/>
<node TEXT="click checkbox next to item" ID="ID_1601597066" CREATED="1716599279089" MODIFIED="1716599285751"/>
<node TEXT="click Group Results" FOLDED="true" ID="ID_1615712723" CREATED="1716599286238" MODIFIED="1716599290619">
<node TEXT="select identifier" ID="ID_1032462612" CREATED="1716599291119" MODIFIED="1716599323696"/>
</node>
<node TEXT="click + and - to show and hide groups" ID="ID_723473726" CREATED="1716599399369" MODIFIED="1716599428524"/>
<node TEXT="remove grouping by running the search again (click Search)" ID="ID_655871667" CREATED="1716599445484" MODIFIED="1716599463472"/>
</node>
<node TEXT="Customize The Search Results Columns" ID="ID_1985382139" CREATED="1716599549328" MODIFIED="1716599597541" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/Customizing_the_Search_Results.htm">
<font BOLD="true"/>
</node>
</node>
<node TEXT="Manage Searches (Save Searches)" ID="ID_1639530631" CREATED="1716599668643" MODIFIED="1716599733207" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/identity-management/Managing_Searches.htm">
<font BOLD="true"/>
</node>
</node>
<node TEXT="Tracing Identity" POSITION="bottom_or_right" ID="ID_1020694019" CREATED="1716899892851" MODIFIED="1716899906592">
<icon BUILTIN="yes"/>
</node>
<node TEXT="Help" FOLDED="true" POSITION="bottom_or_right" ID="ID_1420021554" CREATED="1716585984781" MODIFIED="1716585987027">
<node TEXT="Release Notes" ID="ID_210156122" CREATED="1716585987434" MODIFIED="1716585997579"/>
</node>
<node TEXT="Team Manager Submits MINT Production Support Tickets (Bubble with ? in it, top right)" FOLDED="true" POSITION="bottom_or_right" ID="ID_300530644" CREATED="1716481039979" MODIFIED="1718036441832">
<node TEXT="previous process" FOLDED="true" ID="ID_553680065" CREATED="1718036443437" MODIFIED="1718036451869">
<node TEXT="Michele submits ticket" ID="ID_1459124427" CREATED="1718036452151" MODIFIED="1718036459881"/>
</node>
<node TEXT="Region &gt; Global for All Veg Crops" ID="ID_26964451" CREATED="1716481217266" MODIFIED="1716481278691"/>
<node TEXT="Description for used for documentation, not seen" ID="ID_1694451040" CREATED="1719340236812" MODIFIED="1719340375632"/>
<node TEXT="Scenario" FOLDED="true" ID="ID_775441813" CREATED="1716481285154" MODIFIED="1716481287522">
<node TEXT="Add manual adds" FOLDED="true" ID="ID_574959325" CREATED="1716481101809" MODIFIED="1716481106677">
<node TEXT="need Role Type of add BM and material owner" FOLDED="true" ID="ID_464577502" CREATED="1716481106803" MODIFIED="1716481319097">
<node TEXT="BM: Biological Material" ID="ID_1283280150" CREATED="1716481368866" MODIFIED="1716481378204"/>
</node>
<node ID="ID_626212198" CREATED="1716481984558" MODIFIED="1716481984558" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/_layouts/15/Doc2.aspx?action=edit&amp;amp;sourcedoc=%7Ba4ebfc5b-3f27-4b54-b8c5-3e7c20e8cb65%7D&amp;amp;wdOrigin=TEAMS-MAGLEV.teamsSdk_ns.rwc&amp;amp;wdExp=TEAMS-TREATMENT&amp;amp;wdhostclicktime=1716481791865&amp;amp;web=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/_layouts/15/Doc2.aspx?action=edit&amp;sourcedoc=%7Ba4ebfc5b-3f27-4b54-b8c5-3e7c20e8cb65%7D&amp;wdOrigin=TEAMS-MAGLEV.teamsSdk_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1716481791865&amp;web=1">Manual_Adds_Guidelines_IdentityManagement_V1.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Breeding Process (use cases)" FOLDED="true" ID="ID_446551958" CREATED="1716585076321" MODIFIED="1716588556884">
<font BOLD="true"/>
<node TEXT="Create Variation" FOLDED="true" ID="ID_1412686352" CREATED="1716585082056" MODIFIED="1716585089308">
<node TEXT="navigate, compare, and visualize attributes" ID="ID_218307120" CREATED="1716585089310" MODIFIED="1716585112714"/>
<node TEXT="understand what was created" ID="ID_145497021" CREATED="1716585101501" MODIFIED="1716585119525"/>
</node>
<node TEXT="Stabilize Variation" FOLDED="true" ID="ID_99884294" CREATED="1716585128629" MODIFIED="1716585134554">
<node TEXT="analyze information" ID="ID_1145079763" CREATED="1716585134556" MODIFIED="1716585141026"/>
</node>
<node TEXT="Select And Scale Target Candidate" FOLDED="true" ID="ID_1583051843" CREATED="1716585141934" MODIFIED="1716585147295">
<node TEXT="advance Stable Lines" ID="ID_1376518648" CREATED="1716585147297" MODIFIED="1716585176592"/>
<node TEXT="Name Stable Lines" ID="ID_177030621" CREATED="1716585150910" MODIFIED="1716585234792"/>
<node TEXT="group BEs into Families" ID="ID_1247399153" CREATED="1716585153511" MODIFIED="1716585368496"/>
</node>
<node TEXT="Transfer" FOLDED="true" ID="ID_1298400802" CREATED="1716585375158" MODIFIED="1716585378814">
<node TEXT="Handing Ownership From R&amp;D To Production And Supply" ID="ID_1746124370" CREATED="1716585383237" MODIFIED="1716585406946"/>
</node>
</node>
<node TEXT="Regular Meetings" FOLDED="true" ID="ID_1851396890" CREATED="1715656449154" MODIFIED="1716391699470">
<font BOLD="true"/>
<node TEXT="Identity Monthly Demo" FOLDED="true" ID="ID_390993784" CREATED="1715656454689" MODIFIED="1715656821971">
<font BOLD="true"/>
<node TEXT="Purpose" FOLDED="true" ID="ID_1182016153" CREATED="1715656540336" MODIFIED="1715656543549">
<node TEXT="changes in Identity Management" ID="ID_246529049" CREATED="1715656545434" MODIFIED="1715656551850"/>
<node TEXT="changes in MINT" ID="ID_317452608" CREATED="1715617656873" MODIFIED="1715617696783"/>
<node TEXT="Aparna" ID="ID_178062517" CREATED="1715617564607" MODIFIED="1715617569730"/>
<node TEXT="for all crops" ID="ID_1314722903" CREATED="1715617584097" MODIFIED="1715617588719"/>
</node>
<node TEXT="organized by Vadlani Aparna (ext) USRE aparna.vadlani@syngenta.com" ID="ID_1606645450" CREATED="1715656461870" MODIFIED="1715656489111" LINK="mailto:aparna.vadlani@syngenta.com"/>
</node>
<node TEXT="Identity Product Owner meetings" FOLDED="true" ID="ID_1388793759" CREATED="1715656454689" MODIFIED="1715656823544">
<font BOLD="true"/>
<node TEXT="MINT Identity Product Owner Team" ID="ID_521088040" CREATED="1713132387540" MODIFIED="1715617427835"/>
<node TEXT="organized by Ribiere Veronique FRSS veronique.ribiere@syngenta.com" ID="ID_800876600" CREATED="1715656513878" MODIFIED="1715656518484" LINK="mailto:veronique.ribiere@syngenta.com"/>
</node>
<node TEXT="6/7/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-06-07T03:00-0400|date" FOLDED="true" ID="ID_1367391024" CREATED="1717769021607" MODIFIED="1717769024879">
<node TEXT="" ID="ID_1381059546" CREATED="1717769026744" MODIFIED="1717769026744"/>
</node>
</node>
<node TEXT="issues" FOLDED="true" ID="ID_790594456" CREATED="1719341109525" MODIFIED="1719341111435">
<node TEXT="subplots being discarded on creation" ID="ID_1369928154" CREATED="1719341111695" MODIFIED="1719341121520"/>
<node TEXT="Connection to Spirit" FOLDED="true" ID="ID_1322106463" CREATED="1716899757871" MODIFIED="1716899763039">
<node TEXT="copied into a table" FOLDED="true" ID="ID_681245329" CREATED="1716900805056" MODIFIED="1716900822604">
<node TEXT="not always updated with line codes" ID="ID_1801365646" CREATED="1716900861798" MODIFIED="1716900871984"/>
</node>
<node TEXT="moving toward data lake" ID="ID_1849773235" CREATED="1716900811095" MODIFIED="1716900816465"/>
</node>
</node>
</node>
<node TEXT="Refdata" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_961592090" CREATED="1716903375926" MODIFIED="1731789128851">
<node TEXT="access" FOLDED="true" ID="ID_1745748989" CREATED="1717084104310" MODIFIED="1717084106195">
<node ID="ID_887547437" CREATED="1717084107554" MODIFIED="1717084116562" LINK="https://refdata.cloud.syngenta.org/RDWebGUI/view/XRDTree.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://refdata.cloud.syngenta.org/RDWebGUI/view/XRDTree.aspx">RefData (need VPN)</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1710137687" CREATED="1717084049145" MODIFIED="1717084051760">
<node TEXT="about" FOLDED="true" ID="ID_148065083" CREATED="1717084284742" MODIFIED="1717084286219">
<node TEXT="RefData (&quot;Cross-Reference Data&quot;, &quot;XRD&quot;) is used for sharing controlled vocabulary in Syngenta." ID="ID_615213443" CREATED="1717084289602" MODIFIED="1717084289602"/>
<node ID="ID_653455255" CREATED="1717084052755" MODIFIED="1717084052755" LINK="https://syngenta.sharepoint.com/sites/rdata"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/rdata">RefData - Home</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Denodo (Snowflake) Seeds R&amp;D Data Lake" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_983106073" CREATED="1715618542320" MODIFIED="1731789128871">
<icon BUILTIN="list"/>
<node TEXT="reference" FOLDED="true" ID="ID_719041546" CREATED="1717011850282" MODIFIED="1717011852308">
<node TEXT="versus snowflake" FOLDED="true" ID="ID_1819578783" CREATED="1717013785678" MODIFIED="1717013789309">
<node ID="ID_188803911" CREATED="1717013790325" MODIFIED="1717013790325" LINK="https://stackshare.io/stackups/denodo-vs-snowflake"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://stackshare.io/stackups/denodo-vs-snowflake">Denodo vs Snowflake | What are the differences?</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="about" FOLDED="true" ID="ID_1557782240" CREATED="1717012252091" MODIFIED="1717012254108">
<node ID="ID_1068256056" CREATED="1717012258701" MODIFIED="1717012258701" LINK="https://syngenta.sharepoint.com/sites/pegasysdata/SitePages/What-is-the-Seeds-R&amp;amp;D-Data-Lake-.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/pegasysdata/SitePages/What-is-the-Seeds-R&amp;D-Data-Lake-.aspx">What is the Seeds R&amp;D Data Lake?</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_926829357" CREATED="1717013178327" MODIFIED="1717013178327" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo.aspx">Denodo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="training" FOLDED="true" ID="ID_289859661" CREATED="1717014099876" MODIFIED="1717014101506">
<node ID="ID_484300129" CREATED="1717014102288" MODIFIED="1717014102288" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo.aspx">Denodo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Mint Tables" FOLDED="true" ID="ID_343130769" CREATED="1718305059407" MODIFIED="1718305062462">
<node TEXT="MINT_ITG_Create_Identity_Request" ID="ID_1919066689" CREATED="1718304738419" MODIFIED="1718305108069"/>
<node TEXT="MINT_ITG_Landing_CreateIdentity" ID="ID_897022603" CREATED="1718304738419" MODIFIED="1718304980944"/>
<node TEXT="Create_Identity_Log_GUID" ID="ID_283224858" CREATED="1718305131384" MODIFIED="1718305149336"/>
<node TEXT="MINT_ITG_Landing_Publish_Identity" FOLDED="true" ID="ID_1192295525" CREATED="1718304738419" MODIFIED="1718304953146">
<node TEXT="published to Spirit" ID="ID_1909673572" CREATED="1718304988803" MODIFIED="1718304999908"/>
</node>
</node>
<node TEXT="locating spirit tables" FOLDED="true" ID="ID_1173773443" CREATED="1717013537878" MODIFIED="1717014967834">
<font BOLD="true"/>
<node ID="ID_1985199643" CREATED="1717013545750" MODIFIED="1717013602127"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      The naming convention for Data Lake is to append the source system identifier to the table name; for SPIRIT, this is <span style="font-weight: bold;">_sp.</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1309198269" CREATED="1717013545750" MODIFIED="1717013608927"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      These are displayed through Denodo as Reporting Views, with the prefix <span style="font-weight: bold;">rv_</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_262563810" CREATED="1717013545754" MODIFIED="1717013617480"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      So, for example, the SPIRIT 'address' table is accessible as: <span style="font-weight: bold;">rv_address_sp</span>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1906674262" CREATED="1717014299897" MODIFIED="1717014299897" LINK="https://syngenta.sharepoint.com/sites/insights-enablement"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/insights-enablement">SSBI - Home</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_505734956" CREATED="1719317886350" MODIFIED="1719317886350" LINK="https://syngenta.eu.alationcloud.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.eu.alationcloud.com/">Home | Alation</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="access" FOLDED="true" ID="ID_1798916179" CREATED="1717011854082" MODIFIED="1717697041865">
<font BOLD="true"/>
<node TEXT="SQL Server Management Studio" FOLDED="true" ID="ID_1450437644" CREATED="1718830143567" MODIFIED="1718830149305">
<node TEXT="install" FOLDED="true" ID="ID_1079819862" CREATED="1718989585863" MODIFIED="1718989587581">
<node ID="ID_1974695930" CREATED="1718827722226" MODIFIED="1718827722226" LINK="https://learn.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver16&amp;amp;redirectedfrom=MSDN#download-ssms"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://learn.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver16&amp;redirectedfrom=MSDN#download-ssms">Download SQL Server Management Studio (SSMS) - SQL Server Management Studio (SSMS) | Microsoft Learn</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Server" FOLDED="true" ID="ID_1893635196" CREATED="1718989692719" MODIFIED="1718989694775">
<node TEXT="Global" FOLDED="true" ID="ID_1953972918" CREATED="1718828558840" MODIFIED="1718828561072">
<node TEXT="USAEDWSPRGLP1" FOLDED="true" ID="ID_502547247" CREATED="1718828574313" MODIFIED="1718828574313">
<node TEXT="USAEDWSPRGLP1.SyngentaAWS.ORG" ID="ID_1153175193" CREATED="1715922132306" MODIFIED="1720804588720"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      For Citrix, use full name
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Queries" FOLDED="true" ID="ID_486741425" CREATED="1718229238961" MODIFIED="1718989652953">
<node TEXT="reference" FOLDED="true" ID="ID_1023874593" CREATED="1718989818956" MODIFIED="1718989822662">
<node TEXT="keep quieries &lt;10 min" ID="ID_955308666" CREATED="1718916767999" MODIFIED="1718916779431"/>
<node TEXT="Export" FOLDED="true" ID="ID_1513728549" CREATED="1718989854753" MODIFIED="1718989856755">
<node TEXT="pull" FOLDED="true" ID="ID_431368610" CREATED="1717447162225" MODIFIED="1717447163968">
<node TEXT="format worksheet as text before pasting in" FOLDED="true" ID="ID_935734073" CREATED="1717447090211" MODIFIED="1717447127917">
<node TEXT="date format will not work properly" ID="ID_1490772727" CREATED="1717447246395" MODIFIED="1717447254994"/>
</node>
</node>
</node>
</node>
<node TEXT="USE SpiritDev" FOLDED="true" ID="ID_1667628312" CREATED="1718914909297" MODIFIED="1718989720526">
<node TEXT="dbo" FOLDED="true" ID="ID_747238605" CREATED="1718914906964" MODIFIED="1718914908427">
<node TEXT="dbo.Material" ID="ID_329004142" CREATED="1718914944574" MODIFIED="1718914960796"/>
</node>
<node TEXT="PK" FOLDED="true" ID="ID_595188928" CREATED="1718914967444" MODIFIED="1718914969251">
<node TEXT="Primary Key" ID="ID_315804905" CREATED="1718914981831" MODIFIED="1718914985588"/>
</node>
<node TEXT="FK" FOLDED="true" ID="ID_1655163960" CREATED="1718914987378" MODIFIED="1718914990099">
<node TEXT="Foreign Key" ID="ID_1339386250" CREATED="1718914990373" MODIFIED="1718914998330"/>
</node>
<node TEXT="bit" FOLDED="true" ID="ID_1419377191" CREATED="1718914999916" MODIFIED="1718915003601">
<node TEXT="yes,no" ID="ID_990163738" CREATED="1718915003861" MODIFIED="1718915006358"/>
</node>
<node TEXT="LID" FOLDED="true" ID="ID_412434044" CREATED="1718915024152" MODIFIED="1718915028432">
<node TEXT="Lookup Table" FOLDED="true" ID="ID_343473909" CREATED="1718915028662" MODIFIED="1718915032994">
<node TEXT="Defined values" ID="ID_1894534220" CREATED="1718915033476" MODIFIED="1718915038759"/>
</node>
</node>
<node TEXT="Line_GUID" FOLDED="true" ID="ID_1285347806" CREATED="1718915069325" MODIFIED="1718915081859">
<node TEXT="use this" ID="ID_57147745" CREATED="1718915082394" MODIFIED="1718915084664"/>
<node TEXT="not Line#_" ID="ID_570057588" CREATED="1718915085024" MODIFIED="1718915124513"/>
</node>
<node TEXT="flowers" FOLDED="true" ID="ID_1532070322" CREATED="1718915125393" MODIFIED="1718915127547">
<node TEXT="pedigree tail" ID="ID_1211510056" CREATED="1718915128089" MODIFIED="1718915132253"/>
</node>
<node TEXT="sugarbeets" FOLDED="true" ID="ID_1418969272" CREATED="1718915133408" MODIFIED="1718915136459">
<node TEXT="" ID="ID_948472542" CREATED="1718915137133" MODIFIED="1718915137133"/>
</node>
<node TEXT="Business_Area_LID" FOLDED="true" ID="ID_416990626" CREATED="1718916584335" MODIFIED="1718916606899">
<node TEXT="use to lookup multiple crops" ID="ID_525999223" CREATED="1718916607733" MODIFIED="1718916657882"/>
</node>
</node>
<node TEXT="ref" FOLDED="true" ID="ID_1221071132" CREATED="1718229297904" MODIFIED="1718229298890">
<node TEXT="has Last_Chg_Date" ID="ID_1760676210" CREATED="1717446344510" MODIFIED="1717446438987"/>
<node TEXT="Design Query in Editor" ID="ID_1840497501" CREATED="1718915204281" MODIFIED="1718915214723"/>
<node TEXT="(nolock)" ID="ID_1889557480" CREATED="1718915596246" MODIFIED="1718916310582"/>
</node>
<node TEXT="Scripts" FOLDED="true" ID="ID_151061771" CREATED="1718114658097" MODIFIED="1718989771357">
<node TEXT="Range / Row Coordinates" FOLDED="true" ID="ID_983185122" CREATED="1718114672284" MODIFIED="1718114699742">
<node TEXT="Here is the script that Janet provided for the SQL for range/row coordinates." FOLDED="true" ID="ID_1307267649" CREATED="1718114701476" MODIFIED="1718114701476">
<node TEXT="From: Yanney Janet USCL &lt;janet.yanney@syngenta.com&gt;" ID="ID_1755291739" CREATED="1718114701476" MODIFIED="1718114701476" LINK="mailto:janet.yanney@syngenta.com"/>
<node TEXT="Sent: Tuesday, June 11, 2024 7:07 AM" ID="ID_1630089492" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="To: Gardiner Michele USNM &lt;michele.gardiner@syngenta.com&gt;" ID="ID_427453290" CREATED="1718114701476" MODIFIED="1718114701476" LINK="mailto:michele.gardiner@syngenta.com"/>
<node TEXT="Subject: Min-Max Comparisons SQL" ID="ID_979422198" CREATED="1718114701476" MODIFIED="1718114701476"/>
</node>
<node TEXT="Finding where plot 8 row/range coordinates do not update to remap coordinates:" ID="ID_1480822077" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="This is set up for UNPLT &gt;1 as it was primarily used for our YG locations with 2,4 and 8 UNPLT.  It may need to be tweeked if you are checking on UNPLT=1" ID="ID_694726247" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="--2024" ID="ID_1069453417" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="--added more comparisons - works to find when row does not update properly" ID="ID_1417012137" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="select location_guid, l.code as loccd, rs.code as rstcd" ID="ID_234221790" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="into #LocList" ID="ID_1682889188" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="from" ID="ID_1935054876" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="location l" ID="ID_289728561" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="left join research_station rs on rs.research_station_guid=l.research_station_guid" ID="ID_498980889" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="where (rs.code like &apos;US%&apos; or rs.code like &apos;CA%&apos;)" ID="ID_1318483593" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="and begin_date=&apos;01/01/2024&apos;" ID="ID_1404453879" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="--and rs.code = &apos;UScl&apos;" ID="ID_1517376919" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="--only change here is trial_id like" ID="ID_91854149" CREATED="1718114701476" MODIFIED="1718114701476"/>
<node TEXT="--This gets the Experiments" ID="ID_506793970" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="select tr.crop_guid, tr.trial_experiment_guid,experiment_trial_no, trial_id," ID="ID_389182053" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="bg.code,trial_crop_type_lid,stage_lid,Year, tr.trial_guid, pa.code as placd, loccd, rstcd," ID="ID_1457539296" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="pa.Last_Chg_Date [PA:LCD], pa.Last_Chg_User [PA:LCU]" ID="ID_1605134362" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="into #ExperimentDiane" ID="ID_123632141" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="From  #loclist l, trial_core tc, trial tr" ID="ID_1311190816" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="Join breeding_group bg on tr.breeding_group_guid = bg.breeding_group_guid" ID="ID_214021014" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="left join planting_area pa on pa.planting_area_guid=tr.planting_area_guid" ID="ID_1879838249" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="Where  l.location_guid=tr.location_guid and tc.trial_core_guid=tr.trial_core_guid and" ID="ID_1091629322" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="tc.crop_guid = &apos;B79D32C9-7850-41D0-BE44-894EC95AB285&apos;" ID="ID_107788596" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--for soybeans but I don&apos;t know if all the rules are the same for them" ID="ID_1527310860" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--tc.crop_guid =&apos;6C9085C2-C442-48C4-ACA7-427C4760B642&apos;" ID="ID_209494268" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="and (trial_id like &apos;24su%&apos;)" ID="ID_1305871983" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="and (trial_mapped = &apos;true&apos;)" ID="ID_1125293996" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--This gets the entries for the Experiments (in the combined results)" ID="ID_1754305471" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="Select trial_entry_relationship_Guid,e.trial_ID, e.Experiment_trial_no,m.Abbr_code,te.entry_no, pedigree," ID="ID_1336802250" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="e.trial_guid, ca.exclude_from_analysis, placd, m.material_id, loccd, rstcd, ted.no_units_per_plot as UNPLT, [PA:LCD],[PA:LCU]" ID="ID_94637385" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="into #EntriesDiane" ID="ID_1386725083" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="From #ExperimentDiane e" ID="ID_982122457" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="Join trial ca with (nolock) on ca.trial_ID = e.trial_ID and ca.crop_guid=e.crop_guid" ID="ID_1346863831" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="join trial_entry te with (nolock) on te.trial_core_guid = ca.trial_core_guid" ID="ID_999610237" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="Join Material m with (nolock) on m.Material_guid = te.material_guid and m.crop_guid=&apos;B79D32C9-7850-41D0-BE44-894EC95AB285&apos;" ID="ID_800622664" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="join trial_entry_relationship ter with (nolock) on ter.trial_guid=ca.trial_guid and ter.trial_entry_guid=te.trial_entry_guid" ID="ID_1989541839" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="join trial_entry_defaults ted with (nolock)on ted.Trial_Entry_Defaults_GUID=ca.Trial_Entry_Defaults_GUID" ID="ID_591578726" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--two different where statements - I run this same query for both min/max and starting/ending differences." ID="ID_929150525" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--This gets the entry results as well" ID="ID_1746509623" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="Select placd, e.trial_id, e.entry_no, min_range, min_row,max_range, max_row, starting_range," ID="ID_1634044457" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="starting_row, ending_range, ending_row, p.plot_subplot_id, material_id, abbr_code, p.barcode, p.status_lid as PSSST,p.Planting_Status_LID as PPLST," ID="ID_1600330588" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="p.exclude_from_analysis, p.remark, loccd, rstcd, p.Sub_Plot_Type_LID, p.last_chg_date [PSS:LCD], p.last_chg_user [PSS:LCU],[PA:LCD],[PA:LCU],UNPLT" ID="ID_1549914006" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="From #EntriesDiane e" ID="ID_917205968" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="join plot_subplot p with(nolock) on e.trial_entry_relationship_guid=p.trial_entry_relationship_guid" FOLDED="true" ID="ID_186812258" CREATED="1718114701492" MODIFIED="1718114701492">
<node TEXT="and e.trial_guid=p.trial_guid" ID="ID_171959155" CREATED="1718114701492" MODIFIED="1718114701492"/>
</node>
<node TEXT="--use this to find the mapper on all the plots" ID="ID_893844261" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--and e.trial_id LIKE (&apos;22SU%8C02&apos;) AND PLACD = &apos;102N&apos;" ID="ID_19146479" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--and UNPLT = 4" ID="ID_1799703269" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="and" ID="ID_112779031" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="(" ID="ID_716677255" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="(min_range&lt;&gt;max_range)" ID="ID_738286135" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="--or (min_row&lt;&gt;max_row)" ID="ID_1755180341" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or ((min_row + 3 != max_row) and unplt = 4)" ID="ID_298476211" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or ((min_row + 7 != max_row) and unplt = 8)" ID="ID_305939508" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or ((min_row + 1 != max_row) and unplt = 2)" ID="ID_244705965" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or ((min_row !=starting_row) and (min_row !=ending_row))" ID="ID_87705788" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (starting_range&lt;&gt;ending_range)" ID="ID_819610459" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (starting_range = &apos;0&apos;)" ID="ID_741042802" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (min_range = &apos;0&apos;)" ID="ID_427009113" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (min_range is null)" ID="ID_437311103" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (starting_range is null)" ID="ID_576831170" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (ending_range is null)" ID="ID_1026996642" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (min_range &lt;&gt; starting_range)" ID="ID_740684579" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (min_row &lt; 0)" ID="ID_862230229" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (starting_range &lt;0)" ID="ID_213292162" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT="or (ending_range &lt;0)" ID="ID_1718925513" CREATED="1718114701492" MODIFIED="1718114701492"/>
<node TEXT=")" ID="ID_1123376343" CREATED="1718114701507" MODIFIED="1718114701507"/>
<node TEXT="--where min_row &lt;&gt; starting_row and p.unit_per_plot = &apos;1&apos;" ID="ID_1357830138" CREATED="1718114701507" MODIFIED="1718114701507"/>
<node TEXT="and Sub_plot_Type_LID is null" ID="ID_1686860801" CREATED="1718114701507" MODIFIED="1718114701507"/>
<node TEXT="order by loccd, placd, min_range, min_row, e.trial_id, p.plot_subplot_id" ID="ID_329587139" CREATED="1718114701507" MODIFIED="1718114701507"/>
<node TEXT="Drop table #ExperimentDiane" ID="ID_1158757346" CREATED="1718114701507" MODIFIED="1718114701507"/>
<node TEXT="Drop table #EntriesDiane" ID="ID_838589701" CREATED="1718114701507" MODIFIED="1718114701507"/>
<node TEXT="drop table #loclist" ID="ID_1465242169" CREATED="1718114701507" MODIFIED="1718114701507"/>
</node>
</node>
</node>
</node>
<node TEXT="Denodo" FOLDED="true" ID="ID_1417220212" CREATED="1717178415507" MODIFIED="1718989621890">
<font BOLD="true"/>
<node TEXT="e-mail" FOLDED="true" ID="ID_1174167664" CREATED="1717082575531" MODIFIED="1717082577962">
<node TEXT="web interfaces (need to be on VPN)" FOLDED="true" ID="ID_1868535499" CREATED="1717011880078" MODIFIED="1717014634314">
<node ID="ID_1506026443" CREATED="1717014652502" MODIFIED="1717014706721" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo-Environments.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo-Environments.aspx">Denodo Environments (use Design Studio, Prod)</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="You have been granted data access through Denodo.  You can either use web interfaces, or a JDBC query tool like DBeaver." ID="ID_683094105" CREATED="1717011871939" MODIFIED="1717011871939"/>
<node TEXT="Please see here for more info:  https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo.aspx" ID="ID_779041036" CREATED="1717011871942" MODIFIED="1717011871942" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo.aspx"/>
<node TEXT="In particular, see the FAQs, as well as:" FOLDED="true" ID="ID_364990922" CREATED="1717011871942" MODIFIED="1717011871942">
<node ID="ID_1786554176" CREATED="1717014182344" MODIFIED="1717014182344" LINK="https://syngenta.sharepoint.com/:b:/r/sites/insights-enablement/Shared%20Documents/What%20is%20DV_1323516678.pdf?csf=1&amp;amp;web=1&amp;amp;e=cbdvhK"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_xparagraph" style="margin-right: 0in; margin-left: 0.75in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-bottom: 0in; text-indent: -0.25in; vertical-align: baseline">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Symbol; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">·</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 7pt; line-height: inherit; font-family: Times New Roman, serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span><a href="https://syngenta.sharepoint.com/:b:/r/sites/insights-enablement/Shared%20Documents/What%20is%20DV_1323516678.pdf?csf=1&amp;web=1&amp;e=cbdvhK" data-auth="NotApplicable" data-linkindex="6" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline"><span class="x_MsoSmartlink" data-ogsc="" data-ogsb="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: blue; text-decoration: underline; background-color: rgb(243, 242, 241); background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">What is Data Virtualization?</span></a><span class="x_xeop" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1983389245" CREATED="1717014182347" MODIFIED="1717014182347" LINK="https://prod.denodo.syngentadigitalapps.com/denodo-design-studio/#/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_xparagraph" style="margin-right: 0in; margin-left: 0.75in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-bottom: 0in; text-indent: -0.25in; vertical-align: baseline">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Symbol; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">·</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 7pt; line-height: inherit; font-family: Times New Roman, serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span><a href="https://prod.denodo.syngentadigitalapps.com/denodo-design-studio/#/" data-auth="NotApplicable" data-linkindex="7" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 11pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; text-decoration: underline;">Visit the Denodo Design Studio</span></a><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10.5pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;"> (note&#xa0;</span><span data-ogsc="black" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">that&#xa0;</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10.5pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">host at login should be //localhost:9999/)&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_293529226" CREATED="1717014182352" MODIFIED="1717014182352" LINK="https://syngenta.alationcloud.com/data/116/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_xparagraph" style="margin-right: 0in; margin-left: 0.75in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-bottom: 0in; text-indent: -0.25in; vertical-align: baseline">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Symbol; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; text-decoration: none;">·</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 7pt; line-height: inherit; font-family: Times New Roman, serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; text-decoration: none;">&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span><a href="https://syngenta.alationcloud.com/data/116/" data-auth="NotApplicable" data-linkindex="8" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline;">Visit the Alation Data Catalog</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 11pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; text-decoration: underline;">&#xa0;</span></a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_236454270" CREATED="1717014182357" MODIFIED="1717014182357" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo-Environments.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_xparagraph" style="margin-right: 0in; margin-left: 0.75in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-bottom: 0in; text-indent: -0.25in; vertical-align: baseline">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Symbol; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">·</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 7pt; line-height: inherit; font-family: Times New Roman, serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span><a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Denodo-Environments.aspx" data-auth="NotApplicable" data-linkindex="9" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline;">Details about Denodo environments</span></a><span class="x_xeop" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1750127637" CREATED="1717014182369" MODIFIED="1717014182369" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/How-to-Set-Up-JDBC-Tools-for-Denodo.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_xparagraph" style="margin-right: 0in; margin-left: 0.75in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-bottom: 0in; text-indent: -0.25in; vertical-align: baseline">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Symbol; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">·</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 7pt; line-height: inherit; font-family: Times New Roman, serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span><a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/How-to-Set-Up-JDBC-Tools-for-Denodo.aspx" data-auth="NotApplicable" data-linkindex="10" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline;">How to Set Up JDBC Tools for Denodo</span></a><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10.5pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">​​​​​​​&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1829756966" CREATED="1717014182374" MODIFIED="1717014182374" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Connecting-Python-to-Denodo.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_xparagraph" style="margin-right: 0in; margin-left: 0.75in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-bottom: 0in; text-indent: -0.25in; vertical-align: baseline">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Symbol; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">·</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 7pt; line-height: inherit; font-family: Times New Roman, serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;</span><a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Connecting-Python-to-Denodo.aspx" data-auth="NotApplicable" data-linkindex="11" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(70, 120, 134); text-decoration: underline;">Connecting Python to Denodo</span></a><span class="x_xeop" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Login is by your email.address@syngenta.com, using  your Syngenta windows/network password." ID="ID_1096789434" CREATED="1717011871948" MODIFIED="1717011871948" LINK="mailto:email.address@syngenta.com"/>
<node TEXT="Note that, for Seeds Data Lake, the data of interest is generally accessible from the &apos;managed&apos; schema Reporting Views (prefixed with rv_).    Only Reporting Views can be queried.  Other view types (bv_, etc) appear to enable lineage reporting, but cannot be directly queried." ID="ID_990202511" CREATED="1717011871949" MODIFIED="1717011871949"/>
<node TEXT="If you need further assistance, please file a ticket through Service Now with the subject CREATE, and ask to route to: SYN-DATAOPS-SUPPORT" ID="ID_1274901822" CREATED="1717011871950" MODIFIED="1717011871950"/>
<node TEXT="Thanks," ID="ID_1947630796" CREATED="1717011871951" MODIFIED="1717011871951"/>
<node TEXT="Bill Burtle" ID="ID_400413802" CREATED="1717011871952" MODIFIED="1717011871952"/>
<node TEXT="Senior Platform Manager, Data Enablement" ID="ID_1539722232" CREATED="1717011871953" MODIFIED="1717011871953"/>
<node TEXT="Syngenta Seeds R&amp;D: Data, Engineering and Analytics" ID="ID_1414812656" CREATED="1717011871953" MODIFIED="1717011871953"/>
</node>
</node>
<node TEXT="dBeaver" FOLDED="true" ID="ID_376249005" CREATED="1717169961972" MODIFIED="1718989873829">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_1854449614" CREATED="1717178427453" MODIFIED="1717178429280">
<node ID="ID_846970888" CREATED="1717696975409" MODIFIED="1717696975409" LINK="https://teams.microsoft.com/l/team/19%3Ad80dce3063174c7fa567a78cef691f58%40thread.tacv2/conversations?groupId=1e0a17ff-b980-4dcd-abb1-a6b1a7e2bab8&amp;amp;tenantId=06219a4a-a835-44d5-afaf-3926343bfb89"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://teams.microsoft.com/l/team/19%3Ad80dce3063174c7fa567a78cef691f58%40thread.tacv2/conversations?groupId=1e0a17ff-b980-4dcd-abb1-a6b1a7e2bab8&amp;tenantId=06219a4a-a835-44d5-afaf-3926343bfb89">BDA group multiple topics including Dbeaver | General | Microsoft Teams</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="install" FOLDED="true" ID="ID_932691906" CREATED="1717173772090" MODIFIED="1717173773911">
<node ID="ID_1578650247" CREATED="1717173774695" MODIFIED="1717173774695" LINK="https://dbeaver.io/download/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://dbeaver.io/download/">Download | DBeaver Community</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_622020002" CREATED="1717178431864" MODIFIED="1717178431864" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/How-to-Set-Up-JDBC-Tools-for-Denodo.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/How-to-Set-Up-JDBC-Tools-for-Denodo.aspx">How to Set Up JDBC Tools for Denodo</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="connect to mint tables" FOLDED="true" ID="ID_1562829172" CREATED="1717169997287" MODIFIED="1717170011756">
<node ID="ID_952055659" CREATED="1717170370978" MODIFIED="1717170370978"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span data-ogsc="rgb(31, 73, 125)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">Hi Michael,</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_481464973" CREATED="1717170370979" MODIFIED="1717170370979"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span data-ogsc="rgb(31, 73, 125)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">Please use the following connection details for Germplasm Identity production read-only replica database:</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_369690631" CREATED="1717170370984" MODIFIED="1717170370984"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <b>&#xa0;</b>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1701818947" CREATED="1717170370987" MODIFIED="1717170370987"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <b>Host</b>:&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;<span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: inherit; line-height: inherit; font-family: Courier New; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">mint-prod01-read1.ch0cjlki1lxz.us-east-1.rds.amazonaws.com</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_418535162" CREATED="1717170370993" MODIFIED="1717170370993"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <b>Port</b>:&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;<span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: inherit; line-height: inherit; font-family: Courier New; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">5432</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1774960106" CREATED="1717170370998" MODIFIED="1717170370998"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <b>Database</b>:&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;&#xa0;<span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: inherit; line-height: inherit; font-family: Courier New; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">mintp</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_572860463" CREATED="1717170371001" MODIFIED="1717170371001"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span data-ogsc="rgb(31, 73, 125)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_902979744" CREATED="1717170371005" MODIFIED="1717170371005"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table class="x_MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="275" style="font-style: normal; font-weight: 400; font-size: 15px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; color: rgb(0, 0, 0); letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); width: 206pt; margin-left: 0.25pt">
      <tr style="height: 15pt">
        <td width="128" nowrap="" valign="bottom" data-ogsb="rgb(191, 191, 191)" style="white-space: normal !important; width: 96pt; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(191, 191, 191) !important; padding-top: 0in; padding-bottom: 0in; padding-right: 5.4pt; padding-left: 5.4pt; height: 15pt">
          <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif">
            <b><span data-ogsc="black" style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">User Name</span></b>
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1944069891" CREATED="1717170371006" MODIFIED="1717170371006"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table class="x_MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="275" style="font-style: normal; font-weight: 400; font-size: 15px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; color: rgb(0, 0, 0); letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); width: 206pt; margin-left: 0.25pt">
      <tr style="height: 15pt">
        <td width="147" nowrap="" valign="bottom" data-ogsb="rgb(191, 191, 191)" style="white-space: normal !important; width: 110pt; border-left-style: none; border-left-width: medium; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(191, 191, 191) !important; padding-top: 0in; padding-bottom: 0in; padding-right: 5.4pt; padding-left: 5.4pt; height: 15pt">
          <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif">
            <b><span data-ogsc="black" style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">Password</span></b>
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1810989997" CREATED="1717170371007" MODIFIED="1717170371007"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table class="x_MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="275" style="font-style: normal; font-weight: 400; font-size: 15px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; color: rgb(0, 0, 0); letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); width: 206pt; margin-left: 0.25pt">
      <tr style="height: 15pt">
        <td width="128" nowrap="" valign="top" style="white-space: normal !important; width: 96pt; border-top-style: none; border-top-width: medium; padding-top: 0in; padding-bottom: 0in; padding-right: 5.4pt; padding-left: 5.4pt; height: 15pt">
          <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif">
            sco_read
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1348563821" CREATED="1717170371008" MODIFIED="1717170371008"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table class="x_MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="275" style="font-style: normal; font-weight: 400; font-size: 15px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; color: rgb(0, 0, 0); letter-spacing: normal; text-align: start; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); width: 206pt; margin-left: 0.25pt">
      <tr style="height: 15pt">
        <td width="147" nowrap="" valign="top" style="white-space: normal !important; width: 110pt; border-top-style: none; border-top-width: medium; border-left-style: none; border-left-width: medium; padding-top: 0in; padding-bottom: 0in; padding-right: 5.4pt; padding-left: 5.4pt; height: 15pt">
          <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif">
            readonly123
          </p>
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1044435472" CREATED="1717170371008" MODIFIED="1717170371008"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span lang="UK" data-ogsc="rgb(31, 73, 125)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1101514674" CREATED="1717170371012" MODIFIED="1717170371012"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span data-ogsc="rgb(31, 73, 125)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">This account has read-only permissions to all tables and views in schemas</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">&#xa0;</span><span lang="UK" data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">sco_mntid</span><span data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">,</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">&#xa0;</span><span lang="UK" data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">sco_mnt</span><span data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">mm,</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">&#xa0;</span><span lang="UK" data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">sco_mnt</span><span data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">r</span><span lang="UK" data-ogsc="black" data-ogsb="rgb(240, 216, 168)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 10pt; line-height: inherit; font-family: Consolas; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black; background-image: initial; background-position: initial; background-repeat: repeat; background-attachment: scroll; background-color: rgb(240, 216, 168) !important;">d</span>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_166558257" CREATED="1717170371015" MODIFIED="1717170371015"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-size: 11pt; font-family: Calibri, sans-serif; color: rgb(0, 0, 0); font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span data-ogsc="rgb(31, 73, 125)" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(31, 73, 125) !important;">&#xa0;</span>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Bel Pramel" FOLDED="true" ID="ID_37399384" CREATED="1717170214630" MODIFIED="1717170221023">
<node TEXT="denodo" ID="ID_1720653158" CREATED="1717170245167" MODIFIED="1717170247516"/>
</node>
</node>
<node TEXT="MINT read-only" FOLDED="true" ID="ID_1932902057" CREATED="1717082633985" MODIFIED="1718989839792">
<font BOLD="true"/>
<node TEXT="Please use the following connection details for Germplasm Identity production read-only replica database:" ID="ID_40801382" CREATED="1717082605797" MODIFIED="1717082605797"/>
<node TEXT="Host:                   " FOLDED="true" ID="ID_144827582" CREATED="1717082605798" MODIFIED="1717082661999">
<node TEXT="mint-prod01-read1.ch0cjlki1lxz.us-east-1.rds.amazonaws.com" ID="ID_1893469080" CREATED="1717082662001" MODIFIED="1717082662005"/>
<node TEXT="jdbc:vdb://mint-prod01-read1.ch0cjlki1lxz.us-east-1.rds.amazonaws.com:5432/mintp" ID="ID_632944246" CREATED="1717178273875" MODIFIED="1717178951037"/>
</node>
<node TEXT="Port: 5432" ID="ID_1591750346" CREATED="1717082605799" MODIFIED="1717082673366"/>
<node TEXT="Database:mintp" ID="ID_71695403" CREATED="1717082605800" MODIFIED="1717082680576"/>
<node TEXT="User Name" FOLDED="true" ID="ID_1519568129" CREATED="1717082605800" MODIFIED="1717082605800">
<node TEXT="sco_read" ID="ID_212165903" CREATED="1717082605801" MODIFIED="1717082605801"/>
</node>
<node TEXT="Password" FOLDED="true" ID="ID_340384660" CREATED="1717082605801" MODIFIED="1717082605801">
<node TEXT="readonly123" ID="ID_290654599" CREATED="1717082605801" MODIFIED="1717082605801"/>
</node>
<node TEXT="This account has read-only permissions to all tables and views in schemas sco_mntid, sco_mntmm, sco_mntrd" ID="ID_610715548" CREATED="1717082605801" MODIFIED="1717082605801"/>
<node TEXT="Thanks," FOLDED="true" ID="ID_506349864" CREATED="1717082605801" MODIFIED="1717082605801">
<node TEXT="Bohdan" ID="ID_295680205" CREATED="1717082605802" MODIFIED="1717082605802"/>
</node>
</node>
</node>
</node>
<node TEXT="Excel" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_399341259" CREATED="1715793983780" MODIFIED="1731789128883">
<node TEXT="ASAP Utilities" ID="ID_1978336083" CREATED="1715793988236" MODIFIED="1715793992172"/>
<node TEXT="Convert Spirit Export Date Time to Actual Date Time" FOLDED="true" ID="ID_881192411" CREATED="1716780705552" MODIFIED="1716780726510">
<node TEXT="Select Date Column" ID="ID_1977527918" CREATED="1716780727573" MODIFIED="1716780735962"/>
<node TEXT="Data .. Text To Columns" ID="ID_195422830" CREATED="1716780736542" MODIFIED="1716780749881"/>
<node TEXT="Column Data Format" FOLDED="true" ID="ID_1901573987" CREATED="1716780771656" MODIFIED="1716780776711">
<node TEXT="Date .. MDY" ID="ID_1275320751" CREATED="1716780801943" MODIFIED="1716780812198"/>
</node>
</node>
<node TEXT="Heirarchy viewer" FOLDED="true" ID="ID_1821129478" CREATED="1719362123546" MODIFIED="1719362129675">
<node TEXT="build heirarchy from Parents" ID="ID_1522251683" CREATED="1719363319962" MODIFIED="1719363350918"/>
<node TEXT="copy values into new sheet" ID="ID_1495775476" CREATED="1719363351465" MODIFIED="1719363360679"/>
<node TEXT="export as csv" ID="ID_1143989792" CREATED="1719363361105" MODIFIED="1719363376744"/>
<node TEXT="remove leading commas" ID="ID_198766683" CREATED="1719363363204" MODIFIED="1719363372262"/>
<node TEXT="open in excel" ID="ID_453268965" CREATED="1719363378012" MODIFIED="1719363410630"/>
<node TEXT="add headers" ID="ID_1452406529" CREATED="1719363410941" MODIFIED="1719363414514"/>
<node TEXT="sort byt columns left to right" ID="ID_1198041983" CREATED="1719363414842" MODIFIED="1719363425228"/>
<node TEXT="conditional format to hide duplicates" ID="ID_436297895" CREATED="1719363425487" MODIFIED="1719363435280"/>
<node TEXT="&apos;=IFERROR(IF(VLOOKUP(P2,$P$2:$Q$83,2,FALSE)=0,P2,VLOOKUP(P2,$P$2:$Q$83,2,FALSE)),P2)" FOLDED="true" ID="ID_1760900738" CREATED="1719362130967" MODIFIED="1719362151450">
<node TEXT="copies id to left when not found" ID="ID_995007633" CREATED="1719362155574" MODIFIED="1719362167719"/>
</node>
</node>
</node>
<node TEXT="PMD" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1580193360" CREATED="1717600542517" MODIFIED="1731789128897">
<node TEXT="reference" FOLDED="true" ID="ID_1726763758" CREATED="1717600704544" MODIFIED="1717600707860">
<node ID="ID_1090164836" CREATED="1717600708745" MODIFIED="1717600708745" LINK="https://syngenta.sharepoint.com/:p:/r/sites/PMDVeg/_layouts/15/Doc.aspx?sourcedoc=%7BD9431814-9E07-42D8-B3E5-3CC38CBD46D8%7D&amp;amp;file=PMD%20Welcome%20kit%20for%20new%20users%20-%20Vegetables.pptx&amp;amp;action=edit&amp;amp;mobileredirect=true&amp;amp;DefaultItemOpen=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/PMDVeg/_layouts/15/Doc.aspx?sourcedoc=%7BD9431814-9E07-42D8-B3E5-3CC38CBD46D8%7D&amp;file=PMD%20Welcome%20kit%20for%20new%20users%20-%20Vegetables.pptx&amp;action=edit&amp;mobileredirect=true&amp;DefaultItemOpen=1">PMD Welcome kit for new users - Vegetables.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="access" FOLDED="true" ID="ID_1379706651" CREATED="1717600546898" MODIFIED="1717600548886">
<node ID="ID_289622660" CREATED="1717600550271" MODIFIED="1717600550271" LINK="https://pmdveg.syngenta.org/#/home"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://pmdveg.syngenta.org/#/home">Product Management Database</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Tableau Data visualization" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_48240834" CREATED="1716186377476" MODIFIED="1731789128913" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Tableau.aspx">
<node TEXT="reference" FOLDED="true" ID="ID_1055984902" CREATED="1717015128096" MODIFIED="1717015129714">
<node ID="ID_516606426" CREATED="1717015130514" MODIFIED="1717015130514" LINK="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Training_and_Enablement.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/insights-enablement/SitePages/Training_and_Enablement.aspx">Training &amp; Enablement</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="TOPS - replacement for Spirit" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_160030449" CREATED="1715618588047" MODIFIED="1731789128926"/>
<node TEXT="EZCapture" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1479878970" CREATED="1716186377489" MODIFIED="1731789128937">
<node TEXT=" Goal" FOLDED="true" ID="ID_1028606255" CREATED="1716187714762" MODIFIED="1716187721526">
<node TEXT="More nice to have to understand data flow and connections" ID="ID_1455428233" CREATED="1716186377491" MODIFIED="1716186377491"/>
</node>
<node TEXT="Gaining access" FOLDED="true" ID="ID_249818979" CREATED="1715922430474" MODIFIED="1715922454702">
<node TEXT="Click the following link to request EZCapture Access.  Underlined blue font are links. Click on them while holding down the CTRL key on your keyboard." ID="ID_532505316" CREATED="1715922456559" MODIFIED="1715922483312" LINK="https://app.smartsheet.com/b/form/a212770280814142bce38f458618ab85"/>
</node>
</node>
<node TEXT="Laas and DaaS" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1646910832" CREATED="1715618610855" MODIFIED="1731789128944">
<node TEXT="Lineage As A Service" ID="ID_1399560376" CREATED="1715618618530" MODIFIED="1721066902967"/>
<node TEXT="Data As A Service" ID="ID_89195695" CREATED="1721066904152" MODIFIED="1721066907266"/>
</node>
<node TEXT="TOPS- demos from functionalities developed for field crops" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1180507100" CREATED="1716186377482" MODIFIED="1731789128950">
<node TEXT="https://syngenta.sharepoint.com/sites/demovegrep/SitePages/VF_DSET_Engagement_Workshop_10JULY_2023.aspx" ID="ID_826908727" CREATED="1716186377484" MODIFIED="1716186377484" LINK="https://syngenta.sharepoint.com/sites/demovegrep/SitePages/VF_DSET_Engagement_Workshop_10JULY_2023.aspx"/>
<node TEXT="https://syngenta.sharepoint.com/sites/demovegrep/SitePages/Experimental-Design---Veg-Representatives-Shared-Space.aspx" ID="ID_107670743" CREATED="1716186377486" MODIFIED="1716186377486" LINK="https://syngenta.sharepoint.com/sites/demovegrep/SitePages/Experimental-Design---Veg-Representatives-Shared-Space.aspx"/>
<node TEXT="https://syngenta.sharepoint.com/sites/demovegrep/_layouts/15/stream.aspx?id=%2Fsites%2Fdemovegrep%2FExpDesign%20Documents%2FTOPS%5FAs%20Is%5FDEMO%5FSession%5FApril%2017%5F2024%2Emp4&amp;nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D&amp;referrer=StreamWebApp%2EWeb&amp;referrerScenario=AddressBarCopied%2Eview%2Eb415342a%2D382f%2D4f88%2Daf7b%2D88de54528d13" ID="ID_1047062748" CREATED="1716186377487" MODIFIED="1716186377487" LINK="https://syngenta.sharepoint.com/sites/demovegrep/_layouts/15/stream.aspx?id=%2Fsites%2Fdemovegrep%2FExpDesign%20Documents%2FTOPS%5FAs%20Is%5FDEMO%5FSession%5FApril%2017%5F2024%2Emp4&amp;nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D&amp;referrer=StreamWebApp%2EWeb&amp;referrerScenario=AddressBarCopied%2Eview%2Eb415342a%2D382f%2D4f88%2Daf7b%2D88de54528d13"/>
</node>
<node TEXT="Other Tools" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1215233246" CREATED="1716219746077" MODIFIED="1731789128958">
<node FOLDED="true" ID="ID_172753810" CREATED="1716219782454" MODIFIED="1716220231850" LINK="mailto:Youssef.HADDAD@syngenta.com"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      &#xa0;links to the tools developed by HADDAD Youssef FRSS&#xa0;<a href="mailto:Youssef.HADDAD@syngenta.com">Youssef.HADDAD@syngenta.com</a>: (Martina Call 25.05.2023)
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1659123863" CREATED="1716219782455" MODIFIED="1716219782455" LINK="http://147.167.198.65:8514/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li value="1" style="margin-top: 0; margin-bottom: 0; vertical-align: middle">
        <span style="font-family: Calibri; font-size: 11.0pt; font-weight: normal; font-style: normal;">Trial Quality Tool:&#xa0; </span><a href="http://147.167.198.65:8514/"><span style="font-family: Calibri; font-size: 11.0pt;">http://147.167.198.65:8514/</span></a>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="Trial Quality Tool" FOLDED="true" ID="ID_58774615" CREATED="1716220168275" MODIFIED="1716220168275">
<node TEXT="Nice tool to get an overview about trial quality, variation, what can be combined or should be excluded/kept separate for analysis" ID="ID_11022360" CREATED="1716220168277" MODIFIED="1716220168277"/>
<node TEXT="Would be nice to see also the description of the columns to select" ID="ID_1159461133" CREATED="1716220168277" MODIFIED="1716220168277"/>
<node TEXT="Would be nice to get the list of outlier, perhaps with BARCD as identifier to be able to easy “exclude from analysis” in Spirit" ID="ID_1462902300" CREATED="1716220168277" MODIFIED="1716220168277"/>
<node TEXT="Can we get a summary view, like a report # or % of trials with CV &lt; defined thresholds, or number of trial/plots excluded from analysis (some KPI summarized in a report)" ID="ID_1029930305" CREATED="1716220168277" MODIFIED="1716220168277"/>
</node>
</node>
<node FOLDED="true" ID="ID_1177137276" CREATED="1716219782456" MODIFIED="1716219782456" LINK="http://147.167.198.65:8516/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-top: 0; margin-bottom: 0; vertical-align: middle">
        <span style="font-family: Calibri; font-size: 11.0pt;">Population overview:&#xa0; <a href="http://147.167.198.65:8516/">http://147.167.198.65:8516/</a></span>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="Population overview" FOLDED="true" ID="ID_399822788" CREATED="1716220168277" MODIFIED="1716220168277">
<node TEXT="Visualization tool for comparing populations for a given trait" ID="ID_945171400" CREATED="1716220168278" MODIFIED="1716220168278"/>
<node TEXT="Good tool to compare performance of group of materials versus checks, can show the value of different populations" ID="ID_771163698" CREATED="1716220168278" MODIFIED="1716220168278"/>
<node TEXT="Do you have a s well a guideline for that?" ID="ID_1829640451" CREATED="1716220168278" MODIFIED="1716220168278"/>
<node TEXT="Would it be possible to compare two different populations?" ID="ID_382579147" CREATED="1716220168278" MODIFIED="1716220168278"/>
<node TEXT="Can we use also something different as identifier for a population (same female or male, CRSNO/LBG,…), not just a trial what is most probably a mix of pop/hybrids?" ID="ID_28454813" CREATED="1716220168278" MODIFIED="1716220168278"/>
</node>
</node>
<node FOLDED="true" ID="ID_1655611399" CREATED="1716219782457" MODIFIED="1716219782457" LINK="http://147.167.198.65:8515/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li lang="de" style="margin-top: 0; margin-bottom: 0; vertical-align: middle">
        <span style="font-family: Calibri; font-size: 11.0pt;">Pipeline tool :&#xa0; <a href="http://147.167.198.65:8515/">http://147.167.198.65:8515/</a></span>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="Pipeline Tool" FOLDED="true" ID="ID_1256353394" CREATED="1716220168278" MODIFIED="1716220168278">
<node TEXT="Guideline would be helpful for this" ID="ID_430225294" CREATED="1716220168279" MODIFIED="1716220168279"/>
<node TEXT="Would be nice to see also the description of the columns to select" ID="ID_1376226571" CREATED="1716220168279" MODIFIED="1716220168279"/>
<node TEXT="Nice visualization, we need to check how it will look like for early stage with more entries, I like the visibility of the significance level" ID="ID_145996773" CREATED="1716220168279" MODIFIED="1716220168279"/>
<node TEXT="Can we also get a report for that, for example showing # of hybrid/varieties meeting all TPP criteria (something comparable with fieldcrops, what I put as example in the PPP I shared with you)" FOLDED="true" ID="ID_727938372" CREATED="1716220168279" MODIFIED="1716220168279">
<node TEXT="Would be needed for all, but also as % of advanced hybrids per stage" ID="ID_577391771" CREATED="1716220168279" MODIFIED="1716220168279"/>
</node>
<node TEXT="Can you make the visualization perhaps also interactive or allow some additional filter, for example" FOLDED="true" ID="ID_1918132257" CREATED="1716220168279" MODIFIED="1716220168279">
<node TEXT="Show only hybrids better or equal to check XYZ for traits XYZ?" ID="ID_435895374" CREATED="1716220168279" MODIFIED="1716220168279"/>
<node TEXT="That can help during selection process" ID="ID_132090549" CREATED="1716220168279" MODIFIED="1716220168279"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1410020848" CREATED="1716219782458" MODIFIED="1716219782458" LINK="http://147.167.198.65:8517/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li value="4" lang="de" style="margin-top: 0pt; margin-bottom: 8pt; vertical-align: middle; color: #133F8B">
        <span style="font-family: Calibri; font-size: 11.0pt; font-weight: normal; font-style: normal; color: #133F8B;">Pipeline breeding tool:&#xa0; </span><a href="http://147.167.198.65:8517/"><span style="font-family: Calibri; font-size: 11.0pt;">http://147.167.198.65:8517/</span></a>
      </li>
    </ul>
  </body>
</html>
</richcontent>
<node TEXT="Breeding Pipeline Tool" FOLDED="true" ID="ID_64514621" CREATED="1716220168279" MODIFIED="1716220168279">
<node TEXT="Complement to the other one" ID="ID_355878524" CREATED="1716220168280" MODIFIED="1716220168280"/>
<node TEXT="Can be used to generate easy KPI versus checks for reviews or reports" ID="ID_1845101292" CREATED="1716220168280" MODIFIED="1716220168280"/>
</node>
</node>
<node TEXT="General comments" FOLDED="true" ID="ID_1362283668" CREATED="1716220168275" MODIFIED="1716220168275">
<node TEXT="Easy to use" ID="ID_394988512" CREATED="1716220168275" MODIFIED="1716220168275"/>
<node TEXT="Very fast" ID="ID_1692680808" CREATED="1716220168275" MODIFIED="1716220168275"/>
<node TEXT="Nice, that always same input file can be used, just export from Spirit" ID="ID_1241339813" CREATED="1716220168275" MODIFIED="1716220168275"/>
<node TEXT="Would it perhaps possible to create/store some user defined templates/selections, that independent from the dataset, the user can have even faster always the same analysis and visualization?" ID="ID_877716697" CREATED="1716220168275" MODIFIED="1716220168275"/>
<node TEXT="Are the tools connected? Would be great if we can run the quality check and use the cleaned data for the next tools (population overview and pipeline tool)" ID="ID_1249619210" CREATED="1716220168275" MODIFIED="1716220168275"/>
</node>
</node>
</node>
<node TEXT="transferred Material Management" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_716576727" CREATED="1715656336997" MODIFIED="1731789128965">
<icon BUILTIN="list"/>
<richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      Material Management (MM) – Web based application that manages the inventory and shipping components of many R&amp;D activities
    </p>
  </body>
</html></richcontent>
<node TEXT="transfered" FOLDED="true" ID="ID_965000506" CREATED="1721064239798" MODIFIED="1721064242799">
<node TEXT="Approving Access" FOLDED="true" ID="ID_817938126" CREATED="1720633107209" MODIFIED="1720633212763">
<icon BUILTIN="yes"/>
<font BOLD="true"/>
<node TEXT="On Thursday, I will be in vacation till Tuesday, July 30th, so as discussed, you will be able to approve the MINT Access for Material Management.&#xa;&#xa; &#xa;&#xa;The roles can be 3:&#xa;&#xa;Material Operator&#xa;Material Custodian&#xa;Material Transaction Authorizer&#xa; &#xa;&#xa;All other authorizations for MINT MM will wait my return.&#xa;&#xa; &#xa;&#xa;How to approve ?&#xa;&#xa;All MINT user can be Material_Operator, and I pay attention to be sure that Germplasm employee have only the role of Material_Operator&#xa;Only the MINT users who need to discard and/or receive shipment can have the role of Material_Custodian&#xa;Material_Transaction_Authorizer is only approved for the seeds shipment coordinators (who needs to approve shipments)&#xa;You get a mail:&#xa;&#xa; =&gt; Click on “View Requests”&#xa;&#xa; =&gt;In the column “Status”, for the new request, instead of  “approved”, you will have  to approve and Panneau &quot;coche rouge&quot; interdiction - adhésif to decline.&#xa;&#xa; &#xa;&#xa;What do you need to pay attention ?&#xa;&#xa;If an user requests a role by himself, I check with his manager (using outlook) to make sure that he can get access to MINT&#xa;I assign only the role of Material_Operator OR Material_Custodian&#xa;The roles are not crop specific for Material Management, so, it is not require to place a request for each crop, only 1 is enough&#xa; &#xa;&#xa; &#xa;&#xa;FYI, the access for Identity Management are managed directly with the Germplasm heads.&#xa;&#xa; &#xa;&#xa;If you have questions, you ‘re welcome,&#xa;&#xa; &#xa;&#xa;Thank you again to manage this activity for me,&#xa;&#xa; &#xa;&#xa;Marie-Aude" FOLDED="true" ID="ID_920626642" CREATED="1720633114648" MODIFIED="1720633143379">
<node TEXT="mint mm approve 1.png" ID="ID_1332933264" CREATED="1720633173247" MODIFIED="1720633173247">
<hook URI="DataStewardshipAnalyst_files/mint%20mm%20approve%201.png" SIZE="0.63761955" NAME="ExternalObject"/>
</node>
<node TEXT="mint mm approve 2.png" ID="ID_817439892" CREATED="1720633188265" MODIFIED="1720633188265">
<hook URI="DataStewardshipAnalyst_files/mint%20mm%20approve%202.png" SIZE="0.27322406" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Support for remote BTSs" FOLDED="true" ID="ID_1217196088" CREATED="1718722410101" MODIFIED="1718722429595">
<node ID="ID_810111652" CREATED="1718722446319" MODIFIED="1718722446319" LINK="https://syngenta-my.sharepoint.com/:x:/r/personal/ayelet_manor_syngenta_com/Documents/Documents/Biological%20Operations%20personnel%20to%20support%20BTSs%20MM%20activities.xlsx?d=w1b8632eeeb77433eb375c8da52b4b17e&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=VolMEd"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta-my.sharepoint.com/:x:/r/personal/ayelet_manor_syngenta_com/Documents/Documents/Biological%20Operations%20personnel%20to%20support%20BTSs%20MM%20activities.xlsx?d=w1b8632eeeb77433eb375c8da52b4b17e&amp;csf=1&amp;web=1&amp;e=VolMEd">Biological Operations personnel to support BTSs MM activities.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_1052490155" CREATED="1715656898238" MODIFIED="1715656899865">
<node TEXT="accessing" FOLDED="true" ID="ID_274842904" CREATED="1716506636977" MODIFIED="1716506639683">
<node TEXT="MINT Material Management Link is https://material.mint.syngentadigitalapps.com/home" ID="ID_420367714" CREATED="1716480582213" MODIFIED="1716506679080" LINK="https://material.mint.syngentadigitalapps.com/home"/>
<node TEXT="MINT Material Management Stage(Training) is https://stage-material.mint.syngentadigitalapps.com/home" ID="ID_1908148374" CREATED="1716506720726" MODIFIED="1716506771102" LINK="https://stage-material.mint.syngentadigitalapps.com/home"/>
<node TEXT="MINT Material Management Test https://test-material.mint.syngentadigitalapps.com/home" ID="ID_835431881" CREATED="1716506788311" MODIFIED="1716506788311" LINK="https://test-material.mint.syngentadigitalapps.com/home"/>
</node>
<node TEXT="User Guide" FOLDED="true" ID="ID_1624641747" CREATED="1716219527122" MODIFIED="1716219538314">
<node ID="ID_1753910754" CREATED="1716603170483" MODIFIED="1716603200094" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/material-management/index.htm#t=Material_Management_User_Guide.htm&amp;amp;rhsearch=%22location%20model%22"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/material-management/index.htm#t=Material_Management_User_Guide.htm&amp;rhsearch=%22location%20model%22">Material Management User Guide (VPN needed)</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Release Notes" FOLDED="true" ID="ID_991224053" CREATED="1716219538925" MODIFIED="1716219543911">
<node TEXT="Release notes provide information on recent changes that have been completed in the application.  The release notes cover fixes and enhancement that have been released." ID="ID_1726023201" CREATED="1716219553494" MODIFIED="1716219553494"/>
</node>
<node TEXT="Training" FOLDED="true" ID="ID_755054420" CREATED="1716219492677" MODIFIED="1716219495848">
<node ID="ID_1053884122" CREATED="1716219496678" MODIFIED="1716219496678" LINK="https://eu.degreed.com/learning/search?term=material%20management%20&amp;amp;orgId=10037"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://eu.degreed.com/learning/search?term=material%20management%20&amp;orgId=10037">material management - Search | Degreed</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Click Name to Check Rights" ID="ID_302452914" CREATED="1716480958755" MODIFIED="1716614119970">
<icon BUILTIN="freemind_butterfly"/>
</node>
</node>
<node TEXT="development" FOLDED="true" ID="ID_621261628" CREATED="1720793016551" MODIFIED="1720793018728">
<node TEXT="Business Opportunity Canvas.pptx" FOLDED="true" POSITION="bottom_or_right" ID="ID_900070960" CREATED="1720793036678" MODIFIED="1720793036680" LINK="../../Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/MINT/MM/Development/Business%20Opportunity%20Canvas.pptx">
<node TEXT="Attached you will find a “Business Opportunity Canvas”. Please work with project or local teams to get this filled out for any Mint MM enhancements you feel will bring value to the business. If possible please fill these out to the best of your ability by July 26th for us to try and get them approved in the next SOW." ID="ID_1375086747" CREATED="1720793063538" MODIFIED="1720793063538"/>
<node TEXT="Regards," ID="ID_967154153" CREATED="1720793063538" MODIFIED="1720793063538"/>
<node TEXT="Benjamin C. Selvig" ID="ID_836286613" CREATED="1720793063544" MODIFIED="1720793063544"/>
<node TEXT="Technology Implementation Manager" ID="ID_1448863192" CREATED="1720793063544" MODIFIED="1720793063544"/>
</node>
</node>
<node TEXT="Location Model" FOLDED="true" ID="ID_1669125364" CREATED="1716602082111" MODIFIED="1716602272773">
<icon BUILTIN="messagebox_warning"/>
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_1431013746" CREATED="1716602176301" MODIFIED="1716602179386">
<node TEXT="About The Location Model" ID="ID_1159613376" CREATED="1716602180653" MODIFIED="1716602191033" LINK="https://us.com.syngenta.mint.nonprod.mint-docs.mint.syngentaaws.org/material-management/About_the_Location_Hierarchy.htm?rhsearch=%22location%20model%22&amp;rhhlterm=%22location%20model%22"/>
<node TEXT="QuickRefGuides/MM_Model_Locations_QRG.pub" ID="ID_1012226987" CREATED="1716602204254" MODIFIED="1716602214440" LINK="https://syngenta.sharepoint.com/sites/MINTHome/MINT%20Communications/QuickRefGuides/MM_Model_Locations_QRG.pub"/>
</node>
<node TEXT="Structure" FOLDED="true" ID="ID_491437145" CREATED="1716602229189" MODIFIED="1716602306902">
<node TEXT="Regions" FOLDED="true" ID="ID_625651555" CREATED="1716602317698" MODIFIED="1716602999017">
<font BOLD="true"/>
<node TEXT="Territories" FOLDED="true" ID="ID_310703160" CREATED="1716602326828" MODIFIED="1716602999019">
<font BOLD="true"/>
<node TEXT="Countries" FOLDED="true" ID="ID_1149113041" CREATED="1716602330680" MODIFIED="1716602999019">
<font BOLD="true"/>
<node TEXT="Center" FOLDED="true" ID="ID_1246668649" CREATED="1716602345345" MODIFIED="1716602999020"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      have owners but not custodians
    </p>
  </body>
</html></richcontent>
<font BOLD="true"/>
<node TEXT="Site" FOLDED="true" ID="ID_1579703645" CREATED="1716602353868" MODIFIED="1716603307887"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      have owners but not custodians
    </p>
    <p>
      require receiving addresses, along with next level down&#xa0;
    </p>
  </body>
</html></richcontent>
<font BOLD="true"/>
<node TEXT="" ID="ID_5087524" CREATED="1716602940651" MODIFIED="1716602940651">
<hook NAME="FirstGroupNode"/>
</node>
<node TEXT="Buildings" FOLDED="true" ID="ID_849253339" CREATED="1716602858686" MODIFIED="1716602999020">
<font BOLD="true"/>
<node TEXT="Rooms" ID="ID_1342470103" CREATED="1716603357193" MODIFIED="1716603360989"/>
</node>
<node TEXT="Field Areas" ID="ID_1730708880" CREATED="1716602863900" MODIFIED="1716602999020">
<font BOLD="true"/>
</node>
<node TEXT="Enclosures" ID="ID_1346798052" CREATED="1716602866058" MODIFIED="1716602999020">
<font BOLD="true"/>
</node>
<node TEXT="" ID="ID_1936079216" CREATED="1716602940635" MODIFIED="1716602940649">
<hook NAME="SummaryNode"/>
<hook NAME="AlwaysUnfoldedNode"/>
<node TEXT="highest level at which you can store containers" ID="ID_1464570039" CREATED="1716602940661" MODIFIED="1716602976669"/>
<node TEXT="assigned custodians" FOLDED="true" ID="ID_1266735542" CREATED="1716602984241" MODIFIED="1716602988272">
<node TEXT="responsible for the physical materials at their locations" ID="ID_1668824538" CREATED="1716603045464" MODIFIED="1716603051677"/>
<node TEXT="locations below that level can be assigned custodians, but is not required" FOLDED="true" ID="ID_427445563" CREATED="1716603030448" MODIFIED="1716603042663">
<node TEXT="if no custodian is specified, locations inherit the custodian assigned to the location next higher up in the hierarchy" ID="ID_1447055025" CREATED="1716603064637" MODIFIED="1716603080273"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="TRANSFERRED Mint (both MM and IM)" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1651923794" CREATED="1716187245816" MODIFIED="1731789128968">
<icon BUILTIN="list"/>
<node TEXT="transferred" FOLDED="true" ID="ID_452256183" CREATED="1721065611076" MODIFIED="1721065612956">
<node TEXT="Create Location" FOLDED="true" ID="ID_109824497" CREATED="1720451370898" MODIFIED="1720451377874">
<node ID="ID_1205457127" CREATED="1720448782820" MODIFIED="1720448782820" LINK="https://syngenta.sharepoint.com/sites/VEGMINT/Vegetable%20MINT%20General%20Information/Forms/Theme.aspx?CT=1720448679541∨=OWA-NT-Mail&amp;amp;CID=74bd3bcc-05ae-a567-76da-ab3bcf13d670"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/VEGMINT/Vegetable%20MINT%20General%20Information/Forms/Theme.aspx?CT=1720448679541∨=OWA-NT-Mail&amp;CID=74bd3bcc-05ae-a567-76da-ab3bcf13d670">Vegetable MINT: General Information - Theme</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Add Location GMT20240708-143234_Recording_1920x1080.mp4" POSITION="bottom_or_right" ID="ID_176367860" CREATED="1720632923039" MODIFIED="1720632923040" LINK="../../Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/MINT/Add%20Location%20GMT20240708-143234_Recording_1920x1080.mp4"/>
</node>
</node>
<node FOLDED="true" ID="ID_276422269" CREATED="1720450982381" MODIFIED="1720450982381" LINK="https://reporting.mint.syngentadigitalapps.com/#/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://reporting.mint.syngentadigitalapps.com/#/">MINT Reports</a>
  </body>
</html>
</richcontent>
<node TEXT="This is a application that provides some information access not possible in Identity management, Material Management and Location Management Service" ID="ID_426925501" CREATED="1720665572106" MODIFIED="1720665572106"/>
<node TEXT="I most often use Materials Mix to identify the components of a Mix (especially when the Mix has over 50 components). The Location component provides an easy method to determine the address assigned to the location without have to create a shipment record." ID="ID_426709127" CREATED="1720665572107" MODIFIED="1720665572107"/>
<node TEXT="mint reports.png" ID="ID_588642136" CREATED="1720665599933" MODIFIED="1720665599933">
<hook URI="DataStewardshipAnalyst_files/mint%20reports.png" SIZE="0.45836517" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="User Access" FOLDED="true" ID="ID_102641699" CREATED="1717002320701" MODIFIED="1717002323889">
<node TEXT="requests" FOLDED="true" ID="ID_751812723" CREATED="1717002343214" MODIFIED="1717002345848">
<node TEXT="need" FOLDED="true" ID="ID_1195940148" CREATED="1717171462011" MODIFIED="1717171465195">
<node TEXT="Approvals" ID="ID_1755660690" CREATED="1717171465848" MODIFIED="1720568999799">
<icon BUILTIN="yes"/>
<icon BUILTIN="bookmark"/>
</node>
</node>
</node>
<node TEXT="controlled by Roles and Permissions" FOLDED="true" ID="ID_1866098525" CREATED="1716585551888" MODIFIED="1716585560369">
<node TEXT="Roles" FOLDED="true" ID="ID_1015494410" CREATED="1716585597570" MODIFIED="1716585600270">
<node TEXT="Material Identity Reader" FOLDED="true" ID="ID_901550840" CREATED="1716585602629" MODIFIED="1716585609692">
<node TEXT="read-only access" ID="ID_1522303809" CREATED="1716585620973" MODIFIED="1716585623922"/>
</node>
<node TEXT="Material Owner" FOLDED="true" ID="ID_1845470944" CREATED="1716585609705" MODIFIED="1716585629356">
<node TEXT="Nearly total access" ID="ID_1060955614" CREATED="1716585638123" MODIFIED="1716585641913"/>
<node TEXT="Accountable for genetic information accuracy" ID="ID_1691926931" CREATED="1716585642384" MODIFIED="1716585647791"/>
</node>
<node TEXT="Identity Add Bm" FOLDED="true" ID="ID_162973015" CREATED="1716585612309" MODIFIED="1716585632513">
<node TEXT="ability to add identity" ID="ID_917524989" CREATED="1716585655934" MODIFIED="1716585660923"/>
<node TEXT="must also be material owner" ID="ID_822959735" CREATED="1716585660934" MODIFIED="1716585672713"/>
</node>
<node TEXT="Identity Process Lead" FOLDED="true" ID="ID_1545783865" CREATED="1716585615308" MODIFIED="1716585632514">
<node TEXT="manage exceptions and overrides" ID="ID_1533493533" CREATED="1716585674122" MODIFIED="1716585690737"/>
</node>
</node>
</node>
</node>
<node TEXT="Location Management Service Application" ID="ID_1514282331" CREATED="1716187366990" MODIFIED="1716187386802" LINK="https://lms.mint.syngentadigitalapps.com"/>
<node TEXT="MINT Reporting Application" ID="ID_1820024314" CREATED="1716187408598" MODIFIED="1716187423970" LINK="https://reporting.mint.syngentadigitalapps.com/"/>
<node TEXT="MINT Support Application" ID="ID_1054493798" CREATED="1716187408602" MODIFIED="1716187440709" LINK="https://app-support.mint.syngentaaws.org/contactsupport.html"/>
</node>
<node TEXT="Spirit" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_404420456" CREATED="1715656333709" MODIFIED="1731789128969">
<node TEXT="transferred" FOLDED="true" POSITION="bottom_or_right" ID="ID_119453446" CREATED="1721066522399" MODIFIED="1721066524307">
<node TEXT="reference" FOLDED="true" ID="ID_1880494067" CREATED="1715656886720" MODIFIED="1715656888599">
<node TEXT="about" FOLDED="true" ID="ID_1933875207" CREATED="1717012498080" MODIFIED="1717012500186">
<node FOLDED="true" ID="ID_123976685" CREATED="1717012501120" MODIFIED="1717012501120" LINK="https://syngenta.sharepoint.com/:p:/r/sites/pegasysdata/_layouts/15/Doc.aspx?sourcedoc=%7B11A2394B-1B91-4A2A-8BD1-62A323AD05CD%7D&amp;amp;file=SPIRIT_Overview%20SBI%2014%20Aug%202009.pptx&amp;amp;action=edit&amp;amp;mobileredirect=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/pegasysdata/_layouts/15/Doc.aspx?sourcedoc=%7B11A2394B-1B91-4A2A-8BD1-62A323AD05CD%7D&amp;file=SPIRIT_Overview%20SBI%2014%20Aug%202009.pptx&amp;action=edit&amp;mobileredirect=true">SPIRIT_Overview SBI 14 Aug 2009.pptx</a>
  </body>
</html>
</richcontent>
<node TEXT="Pedigree Structure" ID="ID_829826724" CREATED="1717012564274" MODIFIED="1717012567886"/>
</node>
<node TEXT="SPIRIT – Application that support trialing activities and data collection with interaction to both IM and MM" ID="ID_1934724811" CREATED="1715656875866" MODIFIED="1715656875866"/>
</node>
<node ID="ID_724405630" CREATED="1716010756945" MODIFIED="1716010756945" LINK="https://syngenta.sharepoint.com/sites/GLseSPIRIT/SPIRIT%20Documentation/Forms/By%20Tool.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/GLseSPIRIT/SPIRIT%20Documentation/Forms/By%20Tool.aspx">SPIRIT Documentation - By Tool</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="SPIRIT" ID="ID_518091113" CREATED="1716186377463" MODIFIED="1716186884738" LINK="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/Forms/Productive_view.aspx">
<font BOLD="true"/>
</node>
<node TEXT="Spirit Identity Model" FOLDED="true" ID="ID_1964516480" CREATED="1717628268910" MODIFIED="1717628283403">
<node TEXT="Genetic Affiliation" FOLDED="true" ID="ID_1973827875" CREATED="1717629950216" MODIFIED="1717629983780">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_1764701490" CREATED="1717629963177" MODIFIED="1717629965071">
<node ID="ID_291238386" CREATED="1717629966473" MODIFIED="1717630293554"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      A genetic affiliation is the ancestry name (the first part of the <a href="spirit.chm::/Appendix/pedigree_algorithm.htm">pedigree</a>) of one or more materials.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="It represents an" FOLDED="true" ID="ID_1522761654" CREATED="1717630293556" MODIFIED="1717630293559">
<node TEXT="accession," ID="ID_1452650859" CREATED="1717630266375" MODIFIED="1717630273761"/>
<node TEXT="the result of a cross-pollination or a" FOLDED="true" ID="ID_1261833384" CREATED="1717630273762" MODIFIED="1717630279969">
<node TEXT="Pollination" FOLDED="true" ID="ID_442447956" CREATED="1717628291002" MODIFIED="1717628330225">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_1520376579" CREATED="1717628315120" MODIFIED="1717628319410">
<node TEXT="A combination of one or more plots or plot sub-samples with the goal of making new Material." ID="ID_1687576174" CREATED="1717628322069" MODIFIED="1717628322069"/>
<node TEXT="With these plots or plot sub-samples an action is carried out according to different techniques to produce new genetic Material. Pollinations apply to all types of crosses and inbreeding." ID="ID_155495427" CREATED="1717628322069" MODIFIED="1717628322069"/>
<node TEXT="Also, vegetative propagation is regarded as a specific type of pollination. Although the new material is genetically identical to the material from which it comes, it is treated as new material. The result will always be new material with a unique material code." ID="ID_1490229396" CREATED="1717628322075" MODIFIED="1717628322075"/>
</node>
<node TEXT="CRSNO (Cross Number)" FOLDED="true" ID="ID_1429798914" CREATED="1717626107815" MODIFIED="1717630187476">
<font BOLD="true"/>
<node TEXT="Unique identification within this crop of this genetic affiliation for the user." ID="ID_226636052" CREATED="1717629840137" MODIFIED="1717629840137"/>
</node>
<node TEXT="Material" FOLDED="true" ID="ID_1059367452" CREATED="1717628284172" MODIFIED="1717628328482">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_1957177136" CREATED="1717628300289" MODIFIED="1717628350446">
<node TEXT="A unit of germplasm that is identified separate from other units of germplasm." ID="ID_300939543" CREATED="1717628352255" MODIFIED="1717628352255"/>
<node TEXT="The tangible manifestation of Material usually is a material lot. It generally has the same parents originating from the same pollination and the same selection or it can be a competitor&apos;s Variety, proprietary Variety or material coming from external sources (accessions)." ID="ID_572043784" CREATED="1717628352255" MODIFIED="1717628352255"/>
<node TEXT="In some instances, Material may be combined; this would result in a newly identified Material. Different Material can be aggregated based on genealogy to constitute a Line or a population." ID="ID_1207971987" CREATED="1717628352256" MODIFIED="1717628352256"/>
</node>
<node TEXT="Material Lot" FOLDED="true" ID="ID_1963679251" CREATED="1717628381408" MODIFIED="1717628919408">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_848004431" CREATED="1717628386571" MODIFIED="1717628388424">
<node TEXT="A quantity of a certain material which share common characteristics, such as seed size, quality, and treatment. A material lot can be seeds or plants." ID="ID_806033352" CREATED="1717628390448" MODIFIED="1717628390448"/>
<node TEXT="A Material Lot may be stored in only one Seed Store. A synonym for Material Lot is fraction." ID="ID_33713183" CREATED="1717628390448" MODIFIED="1717628390448"/>
</node>
</node>
<node TEXT="Collections" FOLDED="true" ID="ID_1868208326" CREATED="1717629055272" MODIFIED="1717629059960">
<font BOLD="true"/>
<node TEXT="Line" FOLDED="true" ID="ID_53591570" CREATED="1717628574866" MODIFIED="1717628577532">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_44878539" CREATED="1717628578145" MODIFIED="1717628580994">
<node TEXT="A collection of one or more materials which are genetically similar due to their identical genetic origin. A line is obtained by initial selfing, optionally followed by restricted intermating. The number of generations and the specific inbreeding procedure are not relevant to be able to define materials as a line. A line can be developed into a commercially sold variety and/or a parent line for a hybrid. At a specific fixation or stability level a line might be coded." ID="ID_617703108" CREATED="1717628582241" MODIFIED="1717628582241"/>
</node>
<node TEXT="Lines can be created independently from material and do not require and association with a material to exist. However, materials added to the list of materials associated with the line are what represent the line in the breeding process." ID="ID_479670806" CREATED="1717629323464" MODIFIED="1717629323464"/>
</node>
<node TEXT="Variety/Hybrid" FOLDED="true" ID="ID_1534392162" CREATED="1717629000665" MODIFIED="1717629071886">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_963874975" CREATED="1717629012378" MODIFIED="1717629014666">
<node TEXT="A collection of identical material(s) that is the outcome of the breeding process and that is created because of its possible commercial potential. It may be the result of selection, or inbreeding, or crossing two or more Production Lines, or of blending Variety, or of crossing a Production Line with a hybrid." ID="ID_91235125" CREATED="1717629019856" MODIFIED="1717629019856"/>
<node TEXT="Variety" FOLDED="true" ID="ID_305268433" CREATED="1717628720001" MODIFIED="1717629078133">
<font BOLD="false"/>
<node TEXT="definition" FOLDED="true" ID="ID_1694410632" CREATED="1717628726964" MODIFIED="1717628749208">
<node TEXT="A genetically unique botanical germplasm. It can be the result/outcome of research processes. A variety must be distinct, unique and stable to be admitted by national and international authorities. A variety always belongs to one Species." ID="ID_996073962" CREATED="1717628750897" MODIFIED="1717628750897"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="material from biotechnology." ID="ID_686010402" CREATED="1717630279970" MODIFIED="1717630286957"/>
</node>
<node TEXT="It is used as a starting point for breeding." ID="ID_1887789874" CREATED="1717630286958" MODIFIED="1717630286960"/>
<node ID="ID_118891674" CREATED="1717629966473" MODIFIED="1717630357837"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Every Material is related to exactly one Genetic Affiliation.
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
</node>
<node TEXT="GNAGD" FOLDED="true" ID="ID_1455230581" CREATED="1717629882894" MODIFIED="1717629882894">
<node TEXT="Genetic Affiliation GUID" ID="ID_1357387581" CREATED="1717629882894" MODIFIED="1717629882894"/>
<node TEXT="System primary key for this genetic affiliation." ID="ID_523585290" CREATED="1717629882895" MODIFIED="1717629882895"/>
</node>
</node>
</node>
</node>
<node TEXT="Trait Codes and Table Structure" FOLDED="true" ID="ID_1686544908" CREATED="1716509610767" MODIFIED="1717012800910">
<node TEXT="reference" FOLDED="true" ID="ID_1942579659" CREATED="1716509737489" MODIFIED="1716509739907">
<node TEXT="Full List of SPIRIT System Trait Summary Tables (Entities)" FOLDED="true" ID="ID_575890474" CREATED="1716509754152" MODIFIED="1716509754152">
<node TEXT="SPIRIT Help &gt; SPIRIT Traits &gt; Fixed Trait Tables" ID="ID_1234059419" CREATED="1716509758364" MODIFIED="1716509817032"/>
</node>
<node ID="ID_1431805168" CREATED="1717012809700" MODIFIED="1717012809700" LINK="https://syngenta.sharepoint.com/:x:/r/sites/pegasysdata/_layouts/15/Doc.aspx?sourcedoc=%7B3334F073-3AD9-4869-9684-76A6C1BBD26B%7D&amp;amp;file=SPIRIT%20Tables%20Structure.xlsx&amp;amp;action=default&amp;amp;mobileredirect=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/pegasysdata/_layouts/15/Doc.aspx?sourcedoc=%7B3334F073-3AD9-4869-9684-76A6C1BBD26B%7D&amp;file=SPIRIT%20Tables%20Structure.xlsx&amp;action=default&amp;mobileredirect=true">SPIRIT Tables Structure.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="MBE" FOLDED="true" ID="ID_761031439" CREATED="1719458378311" MODIFIED="1719458380569">
<node TEXT="reference" FOLDED="true" ID="ID_548066895" CREATED="1719458394342" MODIFIED="1719458395925">
<node TEXT="MBE" FOLDED="true" ID="ID_1968138006" CREATED="1716906551813" MODIFIED="1716906554666">
<node TEXT="png-240528-072915893-5027925773507581255.png" ID="ID_1247456375" CREATED="1716906556923" MODIFIED="1716906556923">
<hook URI="DataStewardshipAnalyst_files/png-240528-072915893-5027925773507581255.png" SIZE="0.73170733" NAME="ExternalObject"/>
</node>
<node TEXT="png-240528-073038620-1558905544054481071.png" ID="ID_1007829063" CREATED="1716906640069" MODIFIED="1716906640069">
<hook URI="DataStewardshipAnalyst_files/png-240528-073038620-1558905544054481071.png" SIZE="0.74812967" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="identity traits.csv" POSITION="bottom_or_right" ID="ID_1708064913" CREATED="1719458433984" MODIFIED="1719458433984" LINK="../../Users/u581917/OneDrive%20-%20Syngenta/Documents/Spirit/ImportExport/identity%20traits.csv"/>
</node>
</node>
<node TEXT="VH: Variety/Hybrid" FOLDED="true" ID="ID_1443523676" CREATED="1716509614881" MODIFIED="1717602096770">
<font BOLD="true"/>
<node TEXT="VHNO" FOLDED="true" ID="ID_144318368" CREATED="1716906926874" MODIFIED="1716906933324">
<node TEXT="Key Identifier For The Variety Grid in SPIRIT" ID="ID_852897437" CREATED="1717601901946" MODIFIED="1717601915295"/>
<node TEXT="for newly created Stable Variety Code" FOLDED="true" ID="ID_1579863223" CREATED="1717601923801" MODIFIED="1717601932235">
<node TEXT="BE BID (EWA#) used to create the variety record is being assigned by IM to this" ID="ID_483215800" CREATED="1717601932248" MODIFIED="1717602322439"/>
<node TEXT="Defaults to STGCD 3" ID="ID_799748081" CREATED="1716906976229" MODIFIED="1716906984742"/>
<node TEXT="BGPCD: ALL" ID="ID_1482041655" CREATED="1716906985722" MODIFIED="1716906992724"/>
</node>
<node TEXT="for Friday records created prior to July 2023" FOLDED="true" ID="ID_317599701" CREATED="1717601966255" MODIFIED="1717601977681">
<node TEXT="this was assigned by the user with the variety record created directly in SPIRIT" ID="ID_543010118" CREATED="1717601978852" MODIFIED="1717602015257"/>
</node>
</node>
</node>
<node TEXT="Stable Variety Code" FOLDED="true" ID="ID_1737089902" CREATED="1718819359389" MODIFIED="1718819369371">
<node TEXT="When Identity Management assumed role of variety creation, the user is to select a BE BID and assign a Stable Variety Code through Edit BE Attribute function in Identity Management.  A BE BID can only have one Stable Variety Code and a Stable Variety Code not used again.  The exception occurred during data migration in June 2023.  Some crops made the decision to allow BE BID to have multiple Stable Variety Code." ID="ID_948396856" CREATED="1718819372232" MODIFIED="1718819372232"/>
<node TEXT="It is important to remember that the orientation of parents does not create a new BE BID.  Parent A by Parent B  and Parent B by Parent A will have the same BE BID assigned when the both parents are stable lines.  This is an issue is some crops that need to maintain unique variety name for both combinations." ID="ID_647439243" CREATED="1718819372232" MODIFIED="1718819372232"/>
<node TEXT="The user has the ability of the material grid to create a new variety record through importing.  This is not approved method and should not be trained." FOLDED="true" ID="ID_1608265538" CREATED="1718819372235" MODIFIED="1718819372235">
<node TEXT="stable variety code .png" ID="ID_991937777" CREATED="1718819416025" MODIFIED="1718819416025">
<hook URI="DataStewardshipAnalyst_files/stable%20variety%20code%20.png" SIZE="0.45558086" NAME="ExternalObject"/>
</node>
</node>
</node>
</node>
<node TEXT="Breeding Groups" FOLDED="true" ID="ID_783890460" CREATED="1717544563607" MODIFIED="1717544567827">
<node TEXT="not aligned regarding Rights And Roles" FOLDED="true" ID="ID_61782862" CREATED="1717544576092" MODIFIED="1717544584072">
<node TEXT="each breeding group can have different rights associated with each role type" ID="ID_441016320" CREATED="1717544584810" MODIFIED="1717544608867"/>
<node TEXT="" ID="ID_1622664684" CREATED="1717544617112" MODIFIED="1717544617112"/>
</node>
</node>
<node TEXT="Training" FOLDED="true" ID="ID_1781883058" CREATED="1715923120303" MODIFIED="1715923124164">
<node TEXT="There are many SPIRIT training on CORTEX under SPIRIT Training Material including short videos under: “Type of material : 11_Training videos” (see links below)." FOLDED="true" ID="ID_1152280369" CREATED="1715923138493" MODIFIED="1715923201805" LINK="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/Forms/Productive_view.aspx">
<node ID="ID_1832564569" CREATED="1716218204245" MODIFIED="1716218204245" LINK="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/Forms/Productive_view.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/Forms/Productive_view.aspx">SPIRIT_Training_material - Productive_view</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1258195121" CREATED="1716218335733" MODIFIED="1716218335733" LINK="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/Forms/Productive_view.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 6pt; margin-bottom: 0pt; font-size: 11.0pt">
        <a href="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/Forms/Productive_view.aspx"><span style="font-family: Aptos; background-color: #302F2F; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">SPIRIT Training Material</span></a><span style="font-family: Aptos; color: #686868;">&#xa0;link&#xa0;</span><span style="font-weight: bold; font-family: Aptos; color: #686868;">(please bookmark)!</span><span style="font-family: Aptos; color: #686868;">&#xa0;This site is on the cloud.</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Installation" FOLDED="true" ID="ID_928774389" CREATED="1716218246425" MODIFIED="1716218250210">
<node FOLDED="true" ID="ID_1134985731" CREATED="1716218335720" MODIFIED="1716232794295">
<icon BUILTIN="checked"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 6pt; margin-bottom: 0pt; color: #686868">
      <span style="font-weight: bold; font-style: italic; font-family: Aptos; font-size: 11.0pt;">PC: Find and run from Company Portal to set it up, please see install for setting it up.</span>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1796339380" CREATED="1716218335720" MODIFIED="1716218335720"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li value="1" style="margin-top: 0; margin-bottom: 0; vertical-align: middle; color: #686868">
        <span style="font-family: Aptos; font-size: 11.0pt; font-weight: normal; font-style: normal;">Link for the&#xa0;</span>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_568409139" CREATED="1716218335722" MODIFIED="1716218335722" LINK="https://syngenta.sharepoint.com/:b:/s/BAUSERNETWRK/tsp/ES579Qm9WlNGk9Kz8oEf2SIBe4rX5WLsBFhXX08pnSAO-Q"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-size: 11.0pt">
        <a href="https://syngenta.sharepoint.com/:b:/s/BAUSERNETWRK/tsp/ES579Qm9WlNGk9Kz8oEf2SIBe4rX5WLsBFhXX08pnSAO-Q"><span style="font-family: Aptos; background-color: #302F2F; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">&#xa0;SPIRIT 20 Installation Guide</span></a><span style="font-family: Aptos; color: #686868;">&#xa0;and&#xa0;</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1524208249" CREATED="1716218335723" MODIFIED="1716218335723" LINK="https://syngenta.sharepoint.com/:b:/s/BAUSERNETWRK/tsp/EetnRB4j-CFCnpbf-vMIou8BuNjFT9PAb9soK_wljDgjAQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-size: 11.0pt">
        <a href="https://syngenta.sharepoint.com/:b:/s/BAUSERNETWRK/tsp/EetnRB4j-CFCnpbf-vMIou8BuNjFT9PAb9soK_wljDgjAQ"><span style="font-family: Aptos; background-color: #302F2F; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">&#xa0;SPIRIT 20 Common issues handbook</span></a><span style="font-family: Aptos; color: #686868;">. Both are available on the CORTEX site.</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_64869879" CREATED="1716218335724" MODIFIED="1716218335724"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Aptos; font-size: 11.0pt; color: #686868">
        Error message at right is normal; The program has patches (dls to run SPIRIT); to get, open and close SPIRIT 3 times.
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Citrix" FOLDED="true" ID="ID_713959864" CREATED="1716218253605" MODIFIED="1716232737797">
<icon BUILTIN="checked"/>
<node TEXT="Install CITRIX Workspace 1911 on your PC, using Company Portal" FOLDED="true" ID="ID_1489726175" CREATED="1716232252909" MODIFIED="1716232322614">
<node TEXT="add account" FOLDED="true" ID="ID_1543057974" CREATED="1716232326346" MODIFIED="1716232330388">
<node TEXT="https://syngentavdiprod.cloud.com/Citrix/StoreWeb/#/home" ID="ID_1281655661" CREATED="1716232347654" MODIFIED="1716232356673" LINK="https://syngentavdiprod.cloud.com/"/>
</node>
</node>
<node TEXT="Map X Drive" FOLDED="true" ID="ID_820788408" CREATED="1716232365159" MODIFIED="1716232369579">
<node ID="ID_1718578405" CREATED="1716218335726" MODIFIED="1716232389212"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0pt; margin-bottom: 6pt; font-family: Aptos; font-size: 11.0pt; color: #686868">
        Citrix requires an X drive and I did a ticket on your behalf. This request is not yet processed.
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Support" FOLDED="true" ID="ID_1251596500" CREATED="1716232396549" MODIFIED="1716232399405">
<node ID="ID_1254713410" CREATED="1716218335727" MODIFIED="1716232407003" LINK="mailto:Satheesh.Sundharam@syngenta.com%20"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0pt; margin-bottom: 6pt; font-family: Aptos; font-size: 11.0pt">
        <span style="color: #686868;">If the access has issues, please do a Citrix Ticket rather than a SPIRIT one, Attn: CITRIX Team member &quot;</span><a href="mailto:Satheesh.Sundharam@syngenta.com%20">Satheesh.Sundharam@syngenta.com&#xa0;</a><span style="color: #686868;">&quot;.</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_242906465" CREATED="1716218335730" MODIFIED="1716232135439" LINK="https://syngentavdiprod.cloud.com/Citrix/StoreWeb/#/apps/all/static/All/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0pt; margin-bottom: 6pt; font-size: 11.0pt">
        <a href="https://syngentavdiprod.cloud.com/Citrix/StoreWeb/#/apps/all/static/All/"><span style="font-family: Aptos;">Citrix Workspace-SPIRIT over Citrix link Feb2024</span></a><span style="font-family: Aptos; color: #490773;">&#xa0;,&#xa0;</span><span style="font-family: Aptos; color: #686868;">this link&#xa0;</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
</node>
<node ID="ID_1417521506" CREATED="1716218335732" MODIFIED="1716218335732" LINK="https://syngenta.sharepoint.com/:b:/s/BAUSERNETWRK/tsp/EYbGg8MpBWZOvjV-Bg5Rh7kB3771H1HiRwdlQlIJ9Om3WQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0pt; margin-bottom: 6pt; font-size: 11.0pt">
        <a href="https://syngenta.sharepoint.com/:b:/s/BAUSERNETWRK/tsp/EYbGg8MpBWZOvjV-Bg5Rh7kB3771H1HiRwdlQlIJ9Om3WQ"><span style="font-family: Aptos; background-color: #302F2F; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">&#xa0;SPIRIT - CITRIX Setup User Guide</span></a><span style="font-family: Aptos; color: #686868;">&#xa0;is currently under revision so only partially accurate.</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Test installation" FOLDED="true" ID="ID_1613610340" CREATED="1716236289840" MODIFIED="1716236315894">
<icon BUILTIN="checked"/>
<node TEXT="open spirit" ID="ID_416973203" CREATED="1716236297216" MODIFIED="1716236302758"/>
<node TEXT="run report" ID="ID_1876480138" CREATED="1716236302775" MODIFIED="1716236305789"/>
<node TEXT="save into X drive" ID="ID_916628374" CREATED="1716236305804" MODIFIED="1716236311394"/>
</node>
</node>
</node>
<node TEXT="Set up, Recommended formats" FOLDED="true" ID="ID_773357226" CREATED="1716218335735" MODIFIED="1716236432756">
<node ID="ID_681504325" CREATED="1716218335735" MODIFIED="1716218335735" LINK="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/User%20Options%20in%20SPIRIT.docx?d=w4237f07de3c6427cbe4fff2cf6e06779&amp;amp;csf=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 6pt; margin-bottom: 0pt">
        <span style="font-family: Times New Roman; font-size: 12.0pt; color: #686868;">Link to&#xa0;</span><a href="https://syngenta.sharepoint.com/sites/BAUSERNETWRK/tsp/SPIRIT_Training_material/User%20Options%20in%20SPIRIT.docx?d=w4237f07de3c6427cbe4fff2cf6e06779&amp;csf=1"><span style="font-family: Times New Roman; font-size: 12.0pt; background-color: #302F2F; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">User Options Document</span></a><span style="font-family: Aptos; font-size: 11.0pt; color: #364D7B;">&#xa0;</span><span style="font-family: Times New Roman; font-size: 12.0pt; color: #686868;">(there is also a video for topic)</span><span style="font-family: Times New Roman; font-size: 12.0pt; color: #195093;">.&#xa0;</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1545160435" CREATED="1716218335737" MODIFIED="1716218335737"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 6pt; margin-bottom: 0pt">
        <span style="font-family: Aptos; font-size: 11.0pt; color: #759061;">This is typical Corn and Soy user option for Plot ID</span><span style="font-family: Aptos; font-size: 11.0pt; color: #195093;">&#xa0;</span><span style="font-family: Times New Roman; font-size: 12.0pt; color: #686868;">for PD but special projects should check with your</span><span style="font-family: Times New Roman; font-size: 12.0pt; color: #759061;">&#xa0;</span><span style="font-family: Times New Roman; font-size: 12.0pt; color: #686868;">manager/colleagues for&#xa0;</span><span style="font-family: Times New Roman; font-size: 12.0pt; color: #759061;">correct set up.</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_408250885" CREATED="1716218335738" MODIFIED="1716218335738"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 6pt; margin-bottom: 0pt; font-family: Aptos; font-size: 11.0pt; color: #779163">
        <span style="background-color: #323200; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">your user option is the same for every crop membership</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1781456365" CREATED="1716218335748" MODIFIED="1716218335748"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in">
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQUAAADcCAYAAAB50LTCAAAAAXNSR0IArs4c6QAAIABJREFUeF7s3Qe4ZVdZ//F9EwiE0EWUJoi9IEWagFiwgUBCEZDeURQQpAgIUkVERBQQpCiEJIRAAgEBAQWVIihNpSlFitJCDwRS5v6fzyLf+W8uM/cOmTl37p0553lmzrnn7L3KW35vWe9ae+WY445dvdCFLjR9+pOfmi5ykYtMZ55+xnT44YdPXz311Omwww6bzjrrrMlrx/h/mlZXvvl9ZfXsH5ZvSwosKXBAUGAFKFzgAheYvvj5L0zeT/vKVwcYfP2006bznve806GHHroEhQOC1ctJLCmwZxRYOfbYY1fPc57zTGeeeebkHSjwFPzt/Stf+co3tZSnsGfNL69aUmBJge1GgZWXv/zlq1//+td3hgpf++pp0/nOd74RNpz73OfeGT40sSUobDcWL8e7pMC3R4GVF7/4xauf+tSnpu/4ju8YXsFpp502PITTTz99AIJQYvlaUmBJgYOHAivHHHPM6ic/+cnpile84sRj2LFjx3T4EeebzjrjzOn0M8+Yph2rI7m4TCgePEKxnOnBTYGVk1/y0tUvf/nL01E3vcm0srIy7ZhWp/Mefr7pkGmazthx1nTuQw4dKw/+9jp78WGaWnXY+cXBTcjl7JcUOFAosHL0c5+3Kql4xzvfaej5WdPqtDKtjM87ph3TIWfDQboPHMbnJSgcKDKwnMeSAt9EgZXnP+/oVbmD29zuttN0iDjhkKHvZ0xnTYdOh05nrp45ra6uTuc55NzTV75y6nTBI84/re7YMR2ycrbvsDKN33kZp5xyynSxi11sZ3LykEMOGasYEpZe5SvmI/D7uc51rtHG/FphjPsH/qx+A4G8f+1rXxt5ju7R7/K1pMCSArunAJ1RXtCLHtFFCwq7eq0851nPHsVLR97kqOlLp355uuCFLjx96OMfmS50kQtPFzjigtMhZwcMVG/HjjOn8xxyrp2ewmdPOWXkH2r8v//7v6cLX/jC03d+53eOvhrMGWecMf6myCnx5z//+Um/rXL43XUBiIH7DTgAi11NQA7EMurytaTAkgK7pgA9U5TY+9w4/+///u90qUtd6ltuXHnx8S9cPXPHjgEKq4ceMn3hS1+cbnuH20+Xudxlpytc6YrTRS54oeknf/Inp4td5KLTxS9ysUkp09esUJz38G80tjIND+Gzn/3sUPgvfelLw1u4zGUu8/8Ln3Z8ox4SOlFy4PC5z31ugEerG3kbrgMC/g4ggIW23ed+n5cewlINlhTYMwq85S1vmS53ucsNvVSMyFj/+7//+/RDP/RDwzCvfa2cdMKLVj99yikjp3DoYYdNn/3C56YrXOVK09WvcY3psMPPOxpw4+lfPW26/33uO135ileaDjvk0JF3OOP006dzH3bY9I53vmMoq04AxCc+8Ynp+7//+0eFZMovFPiv//qv6dRTT51+4id+YvrqV786EIzCu4eSf/d3f/dYAfniF784xnnxi198vPe79lynrSot94wsy6uWFDh4KfD+979/+sxnPjOMO715+9vfPnT6B37gB4ah3SUofO4LX5jufNe7TF8/68zpk5/9zPTIxzx6uus97j694lWvHFb7wx/80PS2t7x1etQjHjnd8iY3H97C10/72lBQv7/nfe+dvvd7v3fUOnhBoUte8pLjnXt/xBFHjO8/+tGPjut/5md+ZrIMetGLXnT62Mc+NoCHovMuPvKRjwzvgadw/vOffwya96Ht7/u+79vpIQAhgLIMHw5eYV/OfGMKqDeiT5/+9KenD3/4w0PXLnGJS0w/+IM/uDMX+C2gcPKJJw1P4S53u+t06tdOm97/oQ9Mzzvm+dPjHvv46bOnfm66wPkvMH3owx+aXnTc8dNVr3yV6cjr33AnKJxH8mJ1dXrHu945QgGWnhK/6U1vGp7Cv/3bv00///M/PwAAGEApyky5//Vf/3W69KUvPRDMvQBGuPC+971v+tEf/dFRPPV///d/AwxMiJcA2Uo+rg0xNibP8oolBQ4+CswT9i9/+cuHh37DG95w6OnuChNXjj/6mNVTPvfZ6Z73vtdkP+THPvOJ6SEPf9j04Ic+ZLrcpS9/NhV3TM965jOm97/vfdND7/+g6TKXuOT0tVO/MhT5POc73/TRj310UhUpHGC5Wf8f+7EfGwr+Pd/zPcP9l/30m9yD+Ob1r3/9CCMoPI+BsktS/ud//ud0pStdaeQfeA1XvepVpw984AOjr8te9rI792UAmGVe4eAT8uWMvz0KMJ4S9v/xH/+xM6n48Y9/fPrhH/7h4Slc8IIX/Nbw4YTjXrB6xllnTbe41S2nHYesTKd+/bTpbve4+3TJS11qutBFLzJc/yNveKPpTW984/S0pzx1ut+97jMddcMbTYeuTtN5jzhiJB3Pe77DR75ALkBHJTBe/epXDzDgCQAH+QTxzdWudrXpve9973SVq1xles973jMAAHKpqgQkwggl1/ILwAI4KL3mQSzDhW9PKJZXLynw1re+dejPFa5whUEMHjidEkIU8s+ptHLM0c9fPfTc55pucYtbTNPZa/7WCj75qU9O73znO0fS8B3veMeI669zrWtNN7jBDabLXOrSo3jprDPPnFYOPeQblZBnrzCUAOQdfOhDHxqK75VVX7tysLT2S6FdUmBxFGCIGVaheaF3+Tjv8nbfklM4+uijR2UQUKiOIEW1csC1VwYtFpGxrAiCW1In8yKj7mX9hQas/hwQFjf9ZctLCiwpsJYCQgf6udb48uiBwq5W8VaOO+64VVl8oMA1nxcQ6WCeqKhD1wQg8+tL/lVt2Jbsuaew3uclS5cUWFJg/1Ng5YQTTljlBdzqVrfauRQIXVq/ZPFlKSFK5cahjut817X+7t61Jcq7m+oyfNj/QrAcwYFPgXS3ma6ndysvfOELVyUIb3nLW45lv/Vea72GtTXV5RV2FU4c+GRfznBJga1LAaAwN+rrgsKJJ564apnwyCOPHCsNbuQVVFNgFaAkRYe4+rvv1BOs7bCwY35Iyxyp5p+XnsLWFaTlyLY/BRjo+YbCefg+XyCYz3ScvGRlQUEDIKDkFL7PNiK1YsATkCeQR/D7/LTn+TV5DJUk63DtwPo7r2L7k385gyUFth4F5ka3z7sz0DtDi+c97xvnKfzar/3azs0SlJ2yyjUABWECRZeIDCxafaiIaF5pyEPwfQfCzgFhLTgsQWHrCdJyRAcOBeYbCOegkHe/K/0bOQXK/6u/+qs7yx7bspxSCyusdwIHFVA6co+CiJKNGp8nHNv1mNewOzLzOrRjwEIV79ZOvUtyFtL4jRdT8VIg1bZqy6fGoKrS2IzFu+u/8IUvTN/1Xd812gd4rZjwevJmeEfzUuw2ghmD79vm7e9WaVxjrHOvZ77lu/Xhln+iK1rMQzTjUM3ZPnf9Gaex9Zu5RA9zbz989NdmG8VyC11X4rdxBda1Yd6uNxfXRG/9eu1qw8ycl9rTx5xXrULNk1pobjk7+mtfX/rdKI/lvsarP7kvffJwGS1tt5O2PoxB2+203V0f2tEG+SGH5FtZvu98Xnua+YEDF7ufyQAFEwcKhL1NTimd3xA64XMN4UmBCg1CngQf8zYSqPmwKHwbp8pj+F2NhP4xqL4JoJfv246NofoLWDCV4JX7IDQUy9/VfavsatOV8XZvABCo+N68AhHjLFab51P63D4OCtD4Asl5ebbvjAfg5oF5N1f9oTG6tPLTuH0XmPrN5/gTAAXSxtL93df4XBNABg7mWCUp+nYWxnpKhS/aNr7mFyhHp2iB3q71fbK1nqK1zk4e8RStonNtGaf+gIA2xzmjhx++08tdr31z1Y570Tt6aRPoaOdge+0WFBAes1tm9BnhMTTCJTAVR2SZ+j0rsh5Ry0106Ip+fWY5MYxV6GTp9oLPrZ/vMNB9WTf9YajCqzwa4OJv1/hN6bVxV2KtHdcQDlu2zU1Fp8+8DH0kNB38kqIn+NGq+aNX35XA9Z3r+76Ebp4R5QQKvJssJEWgVITXuFIq7YwH95x94G7K7xq/zQG8lSP9GEugEfAQfm2hQYBT2xsp1dhaf/rpO2tafMY/bZmPv/FRQptiV0mn6nUjpQto8BFdyAa64JM2C213l6PaVXHOfD7zRJzP1dYYc6eCHXSgcPzxx+8MH+aeQqCAiZQIIzDYZ4Qu1xDhIn4ubN7ERuED5RhPqPriF3e6egkVxQjB9ad/AttxbITOZ9YhV929DpMwTkJUKOF7AphSGbd+524yhaGAhBxYvOpVrxrX3/jGNx5hSeCUq+368ix5TN5TvMKA+W9zAUMjbRlXCpwrbA+IXaHmgDbN2fjQwT0+u6855C1po8Ns8MV1vkND15QwRntAQznRr+d9NK+1YcCulCP3u1Uo8/ngBz84dsKWmzK+Oe0p+nga2dke33pKF7ihgfF5x198Dbx2nkJ+NrBpL7DbKGeFlnmCgMzcVeLao3PNa15zj8Z4oIHGygte8IKdoEDxEWUeKhA6QoPBPTEKUwnT3ELl7uaaErxcyo0sTbFbuQXCov2UnrueJe278hkEhQUyTvc4Eo5lz0JpK8ESN/rNPSxOsTcBMl5gUMhhPjZ02f15l7vcZVxrH4ixooU2tEtIs/aFVOU9cutzqfMO0KMwZh5TNyf0/ru/+7vp2te+9ti04prCCwJsEwtemUNhUn0XspkP0CmGL/nbnI0hDy/vz5hyzdeGiLvjYcagfA9eoNu1rnWt6fKXv/xQ3vpB3+huPHl468lHnh6+mCv+44G/80TnIRJ+oxc6FOZtFJ6gESPi3Rht7jvppJOm3/iN3/i2QuADBRwGKBA0S5JrQaF9Diw2xpYAbDtm5c65gKH3vK5hI6RO2N1T/xhOaCgXZmmjA1sLCShrSvbjP/7jY/OVnZiBh3MabNF2bwkpAkmgWGFKY1dmoQhhJkTznMg//dM/DVC44x3vOIQZHRwmY97GmCVdO/8qQANKY4gOZYNLNOaia1s7aAxonv3sZ4+zKMytMCUPoP7cY8wdSkMh9JmFLtlGmXxHcctRFC7MD9ulcPMQJO9lPWGnfMalL7RF97/5m78ZOSpb4AFxYQ/eNI68nDLiu+ujBGJz0A9+khfehv59Nw8Dy0PoC43We6FtMqXdPKenPvWp02/+5m8Or+Rge429Dx28MAcFhCAUWXyETwAl6P7nf/5nuF2YwiJ0AGQuYVnfjcKHklTe3/3udw/6U4RiuxTPGDt34YUvfOHkwAiCYsOVMxecw3Dzm998AAFBMkZtsKreob/togSJwl35ylce5zNc//rXH4e9EF6v9m1Q4te97nXjnrve9a7jd0ImF/HGN75xgBB6OcVGn97NFU0IWha7/IG2S766DsjlafFe/J077P4nP/nJ0y/+4i9OP/IjPzKEfm5ZnVfh0M0AjTfhgBttdGK2vnzOwvq7UM/YgKB99cZuTs6swFOgZzzGkje4kXufV+F64PmMZzxjOuqoo4aXg2++p3DOCgR0eRXGuxEotDpEPpwcRM4CbvKiXcBmDPjpcJ9WNbQvJFjvhacBF5kN7J/ylKdMt7nNbXYeCXgwAcOGoIABXu2BQLh3vetd0xve8IYhAF7cXP9KDlbDsJGX4N6Ez+c///M/H8y9973vPd4xnABRfu9cO9bsBS94wRCM3/qt35pe9KIXTf/wD/8wrn/a0542/cu//MsAAjmAO9zhDtMzn/nMIUgveclLJpafRwQg1GVwEV1H+VgUymoOrbbIKfhe+GAseRLGqQ0xP6ve/FnKQpESiuZVXgTtWubtsFug8wu/8As7cyOE0r36YG0BZGdLAEX0+vu///txqhVrr+1f+qVfmq5+9avvTJzm4Rmz+ZkXy0zBKmUHeID1EY94xACrk08+eYDyr/zKr4zzLsxD+xvF/YUoHfulHzS/0Y1uNBSqFRMeF6D7vd/7vTEOvxUWradwLb0CF/xylB8gQ7/HPvaxg/7GKYdxjWtcY4BoZ3m2MrNe+8byile8Yhg25w0Yp7k/5znPmX7913/94AQF4QPCY2JuaO5X8arfeyy97ygfZXnIQx6yM+uc5XGgg3iSAks4cdW5317QlyW69a1vPRh6s5vdbFgSx7ex2ISU4FNYikBBMd87Afdi1f7iL/5iAAFlBEysNGZKDDnRybUU+e53v/sYq/GccMIJ42AXHgKLeLvb3W6cRkPBbAYjsKztbW972+E56NeRcdoFLoSd8AGGP/qjPxpW8KY3venEa3EQ5mMe85jpla985bheYtK9zqh0/b3uda+RuPI7wPI7MKNQcgdcVeNzEpU5mNOLX/ziEd7wguYAaWz3uMc9Bg1/+qd/engMwPfoo48eY9cPwAZ+Ttch3ACD0FN8XsB1rnOdQdM//uM/Hlb8nve853S3u91t+v3f//1hjX/2Z392etjDHjZAz/kZ6FWsbTyADM21Z4wstP6NCQADNEBrPngRwDz4wQ8eQI7mZMq9ckDof9xxxw1ZQFd89b3cBGst8QfseTaUGK39TpnNHy8dSurlHFDfBcrOAhHSAAzXkE8ey+1vf/vR7tve9rbBP3MVLuRh4TG64Nc8z1IoF9Bs5OlsdQ+jpdxW8dBk5BTWAwWTzrVlxSgOZjgxiYWi3ISM8DzwgQ8cKO3QVvewPKwgZdIZRYPsnbtIEYEGgQBEFJ4gY5iXxJ57/SthRTiBi/tucpObDKE2Jm0Bob/+678eQnHf+953CCZGs9DAgsAjgr/vdKc7Tc9//vNHOzwTc2LtuLedAfGa17xmKPmd73znoaju098DHvCA4SlQMPT5wz/8wyHoLCRlCVQoUHUWBNMRdVx/AKNAhqtLiQnfy172stH+L//yLw8l0xaasoAYRvFZfMBtvOYGyL3e/OY3T0984hMHKAA+ioX2aEkBjMepVf/4j/84aAwkjIUnhK6U5a/+6q8GkD7rWc/aWbTjNzE1ugBA3hbwBlglT81LP5QRWDMW6Eo2KFrLp+iOjo985COnJz3pSaN/Sp73gzcAkZzwboAJgDEPwIrufpM3kgC83/3uN+YvjEMr/f3O7/zOAGP04E0AfcaKDOoL7QAcGqO7JWcAiEZkGLgYv37IpPEan1eJ2wMFDOZg1apeObwNQaHkIcZUyXj88ccPZlO8E088cTDh537u54bFY1URnjIRagLH6ojxEb68hRiWclFmQkrgMJ7wUlhA1apEbmDJTorPkwAeFcE84QlPGEznlbAO3GMCxJuhhP4mwJQY4wGKMMT4WCyuKcAyZspqLH6n1Kwo4TIOFlbMjJCuZeHRBmDqgyBx7QEaa+OdEhPSpz/96eNeHhFL7tg6AsmTkOcAljamUSDJOr/zBgqjMNIcteM3iupFkTs6/7Wvfe0AKb8BG0AMSM2Rp4Lx2gQ87qGkQhKKwjX/7d/+7TFnn/EMLVhSilpVK2XHc8oWcDMCf/AHfzDAgQeBNsCosNM40fHP/uzPpoc//OEDrIGHczx4MwzJQx/60KHg5hDQo53x2MXLo+Rl4TlgYpD8jufGxIvFI8qNX49//ONHH955ReYhPHK9PBH54pUKKwGSOZsHT8gc5KiEOQeyp4CnDAWdINMjEb6Rp0BAKThhDDVZUFYHI7wTOi4gt5UF0AF3D3oLFzCE217iiisLBFimLOLznve8MTiWmqAQZte3pFgyCyOFDsZFKH3PanPDWSwuJ+X+kz/5k8FYIMCCYrzrZMQBkbYpsHGx3q7VpjheH5TAmCg7ASq29k4p0YLSucZ8KakEJHAEPjwQROYBASfKot1WU7Qv/mUJKQ8gZaEosyPsfvd3f3f0q12M86rGwFzldXglhJ9C8ZJYTm78da973WEx0RKv/E7oX/rSlw7FEbbxQCgAUAKI6GXcgIyF9s/4gYcxAhPt3+c+9xnAwcv4qZ/6qcEn9wFpSm1cwMe1+mhFhHEhBxQSCAjtjjnmmKF4gJXnyaBIGOtbu+hi7gwIXuMTWpobQwJ4gAJeFhIZszkDb94YugodAEvFSQyP/nzH89EnfqJ9qxv4CjCM5UAHBQBMjrxGrdJGoECoKxEmRFxmAEEwe8oMcNDwP//zPw93VMKmAiTXc2kxkyWlQBhMiFknVh2CYxDB5Um4H2JRoNx9DCUg3FkK5m9KwZrpOxe77DHrbaKsL5AgZITUi8vpXmNhCQg0ASJcFEio4DMviMCzPJXOGp84FF0IpjnriyKz7vpkBQkbywMAKQLBFiKw2IAJTQAoF5Y11o55EGDjpaiUG20DxCokZcsBo7kSZv1wh7UHmN0vdDFHCgqAxPdAC9PF7C1rogsLzBKbKyWiCKw1nsgBGBtwxR/j1RblxzvjpfhkBEigJTpwy821lRbyQBHJA/5JoKKJOQNQISErDiiBGSAyBoYFrfVPmY1VX8Acz8mR0A/YATA8ISf47ntAyBvED31qU//Gh//mamwAB73RlJz/6Z/+6eAbeVsLCmSoXMJ2zykA0ZbFK3nfEBSqJKOEBIiisl4tFSEQ4elvgktI5BZ8T4B5C4g9X2nQLqZgJMWmjF4EszX8at3LYLueN6F9/QGgEqAEwfiAj4liMhDgCmJ8VYh+0zdFQQz5h3ID+jVO7VMeSmzMrJnvKpyqmhNN9A8UuNGUsI1bLDAlymLpz4uAGwOvoHElxO7Nm5JMoyQApFivJUz3tYNVm+hSMrbwrKXJltmqfKSk5okGPJeWSf1dFSjPb14e3jHg1RbgEWVO4auE1CcF4glYwSinUs0JGpAHY0VXY6oUmucBAKqgbaWk1QXzRO9qM1h0/7Tpmh5/5nd9AGP0lNDlgfjc6pFrOsXYnNBczoEcmJvveFxWH8jueqCw1ROJG42PcTB3+lep+oagQKgQGbMIXMTFCIpf8QuGYRJh8s6ChfAxs+o611Cgkok+IzxF6XDYCqYq2KnCsfjdZNrDQLDcT9jch6lcT8CQQFc+7DrfmRcBKHnIO2g3qHffyw2w/CyXufoOuLTk1+e8FW2XEPRenQDB9Rs6Jow9JwNNvNBzvlcBXTvqHk2qMVhbyVeewVxd7xXi+66lP9+jIRAwbjxAL+NA/znINDbzBXYExju6RM+WXgFD9DAHAM4dZzi035K267SHN67HM/M1FrKSV+h+gFBWvGVR75KRlLQ8hbZ9rhK1PJT7/Zs/QJVcaNM8exyh3/HGtZX4o50Xb4IH198HaqIR3XmQEtfoMKpbNwofXNRuNowhaBiDufPCGEKDwJWXFkNjmHv8RrG0lZVISSiM77lqFDUGBUAVLuUhECjKVVhDWF1Tdp6iEUCCAMy0316AynwJo9+y3vplXaq9CAAqwtI+60hh2hyV9ao4h8IACMpgDAlSZeO+N2cKxSoRSu1XNo7WCW0g1b3+NudqDiqzNjevlBPdC40oMxqgu3eAEPC4T9uNudLtKkIruTa3inuyzv4GQGSgCk1tNaaqKl2nP22bVysW5IY8tNQNeMlJXkyVoOZV0RV+tRJSGFmlKgDWVzUYLR/rN+/FfMpT5A3wKrUv9AIAvk8mKoVvK/ncW5iHDNs9fBB+yadJAlcPtGJDFCWTja+6EKFKkmEggiRQeQRZgMpcqzLDCO0k1BhHmap5T4Grh8fIMtgpDUITkrau5n208656Cn23m813WVMCYNyFNCkAoZuXGTeGauVb5cilruKueg0glBIJewizMfgHwBqzd4Lpe+NgmYCJvym2a1MS9MhKGpvfgcV85UXIxAqbX1WmKVAVn1Xv4YO20TXr77fAxxzKv7TMS0HbRu66cjF+R7vmlUxUrlzYUsVlCpK8mK/xUsz2eAQMubV7UuC2kQu8/H33FEje8SZgC2zRXr2H1TC5o/RhQ1Co9FZDBL3dhhQvV5lQtzMR84GAxF3lu+3iowDuz/3LKhG2chBZL9cQyixYguf3tswCs9z6ttO2SqDtNnDlObi3uCnw0ka7ItviW14BCOm3WoN26AWUlLvSa8Qvuz0PIarI1E4AVi6ioiQAYAwsFXpXTl5iUcyXF1Z+oc075lmBUOCFB4UKFFfb2kWbQBw/S8IGhuUSsu6FXPoot2Sec+/LnAofon1JzIDA/QGtz3kC5l85+FKxF0OBhYBCAkOoY653fxMaAo65BJlwAIP5VuhWASiYaymY77RbeNAuvZJbuX2tn/o7z6S4x2QLRwoPQrrI6xrKoZ+AKBDRV3FtLnU5kPpKOShry2TtkuT5+D1rmxXNK/G38RB6/Zh/rn+nV+U2d34EukTnQi7jlyzl3pY7aXyVPwt7zI+1FzpQSnyIJ/hUArKt7yXd/Ib+5Rx6qG/J43hlLnjGBQ988Mf8O5zGWDMeyYS/s1LG3djnBVmLUYdlq4WV5Vj2maeQJfLOKmImgcFcAkMYy6YTTkJXXNy2YoMhSOI+7XCnU8oGTMFahyekhHWe7W+DVFaora6FCHkwWeuqtErEUc52DRp7KxoJOqXVdjmDSqyN3Vh4Qu2716bxUO5c5RSvOLlt48bTakeJMXN1fe41sGg1pk1Wvptn2s2n6sDCu5Q5z6NkWisRhUuFdtrQt1cuvb/No6eBVV5uPJScd6j96J53Nt+h6R6v4nG89Uo+Ek7096oEeam2i6fAQjwFDCY48xyDqRBe/4qnS6oRWEJYrEiICFcuY1tRW/7yfbG7zywR8OHKWscm4Cmktks6es9KVwbdFt1OccoqJZTG2Mv4sn6FN9ov3krxjcMc23ZNsCkBBUjIi8NZTuP3zgvwfW3qK3c8ABFeyae0UoOeriumD8TMSwLRWLRXDqKEpvV/SUV/ixH1KxFIcYEW+hl/Zer672nflF+4p339BD4tKxtPdDaejsVrPb9l5oAN3YzTfQClpGO5hHIwJVUBx/K1OAosDBSqT+84LX9zb20uKVZWhahwRuERT0BWkzAWf7q3I7nsQzBYqxg2K1nTV6RTjEtw/N4+d8Ai+aZUWDEK4XetYhPCS/j0x8WnkECGsHH7CXoWM3eegBZytL2a0hB+bRB0HgNFK48TRXWgAAAgAElEQVSimKZtubnGlYZSJEDRobHGV/we4JiD+QDYchvGTDks3wVyxm5uvleBiW6Vh+dxBY4U2zKdsmWvlkjLbxgTwOQF4IVxut535gYQAsHyICVHo1mAjo8tEyvewuey/eUO8kKaczUk2jafVitc13et7ixOLQ7ulhcCCgS45TmMJdhifAKr0k3Jrzp+JblKltWmU3DXFEuWIyBY9k2oFOycAMtCqvvUzeunZRGlyMqQ3atkWiWbegF9KGcmrNZWVbkRflWRFFpMbZytALR2ncBSvrLxeRi54wjo3hJgufcss0o/FtV3HewaGLi+ZT9gRAlbYss7MY48CHPSt30ZyqpVJKqytFHI8phssFJeS0UAAg+UFxtHRTralTdQOmw/BXAGICV3y9kAKN/jW6Ggvo1de4DFZi47L9EReJmnV+FSQJXnZbu1gi6grp3qCkoatnSJLnOPQ38AAy/Wnt1xcKvu4ma/EFBIUVqSrDaAYBE4Jb1KQv1t9xqr5R6lwVxZdejKYllDSmGDCitsM5VSWfdScFuc1d9TbCWp6s7tvVcSrYjo2GOPna53veuNzzbU2HPxt3/7t2O7r/uFGsZIUXgVqgkpFAUEGJXUKsulwKwdUNNmu+R4OCrgKJZSYJ6QUl0uPsUAGNpmdSka8KtMmoIoAukQFn9TKmW3Aan7Vfu5X4m3PRk2CAEyyqLoxzxtcKLs2rY5TGWd+1qRUWkJHJRW24SmelB/ynmVkpurLcfGqhTdHH3PG7JvAcC1GQzt0Bkt8QutjNl47DI0Tu/A2u5LtLHnwxK2UEKpM35RcjzxamOREmv0B9z4T0ZaQi1Xs/QUFgcIhc37PNHYioEOKFOxYi40AbELjbCwNoRJeTEPQKzL5SSkD3rQg4ZlZwVZRIrhOgLLKnJlrf1TQILKe9AeQWTNbFABOEDBvnxK7SwDQOIFVDqvn0USWhBO4zQOSkCAla8a66Mf/eidrjPBZaG18Zd/+ZfDC6qyUumtzVsVOwEDlrQ8h7Hxemzuuv/97z+AABhRQEoqm28eQgtj1W5b0dX8owvvAhgKd+wcBZxoBCxsLDJfG5XMxfbkDpEFQOjilCMKDWTkBgBAYYBrgDUPi3IbE0tt/MbmM1C0FZkHYH+AceA1IPA3YDE+QE/AjAHwo7OQjrLjoaVTNAcQxgGsAANAsHEpDw0wADh8wDPz1Cc6oJ+2/cZ4AJ5WrMpv4Vf8KMlZ7gZTW/b0uSrKtuvzdoROtV3C1zv6VgPT99u9OGkhngLr1lJT6+H+LtPMkj3ucY8bTKQYLDeB9A4QuJnyD+Jim1BYQgqvtp+QEhiKgfHakagjdPrgXhMKFvu5z33u8B4oeLv07K4DSATcjjuAwhPQn3egI44FACy+UOdRj3rU8CJ8VgrNumlProJlZkXzJIyH0MuVAApeD6ttXpVs230JrHxvvITbdmT78QGKuVA4ygUc/GZ8lBRA6KOQBeDaHcl74gFQfptyHF7ivANCqw00JLTCKtcKx3hPwAkNjF/eBnix6ASjkm05BXOynR2Njd/OUmGMttCNIlBA4Zo8CiC1j4HFBzK2ZpsDD8FWb+MzB/M3J4esoBGe4ZGx2nAFDNrK3X4D3iYeVUth7MKvgIBSozXapMi+M6dyR34DMiW3KX4VmeZSYVd7WqqMLXneypT3VtMChSpGF2vPF9f6QkChGFDjHRUG0REN4x1s4YAP6EtgCTWBIcS8AGABTCSmCBbLBhQog/sxQSjBFa5isQInngXLZu++nALrL9dAWL0kKd3HWthlh/mWRVk+22Ddy4IJCWwXBgQEFxCxiiystimCnX2sibnZgcezkLugFACh5KM+W1ZlQeebg1hobjyQAXrccp4HmugTUHon9ASXt8N7oAiEj9ehsow3Zb6U31Zs/ci5uAfAACEeixUGuyUpobar4uRd8DZ4X8I7HlLLxGoevMyNZaeM6Meq21UoXKO87qfwlFdI4Tvb442fd9hKCKDQDrBxvoW2AAEaMhzmCNi1xesroek7czAnVh7tKxGv7qFSdqDRio1+eSGAotWmamFKapf09U7x0YX3Um0L+RTSzetbzE/bxtBeE+OaeyCLU93FtbwQUAiRKQLiYyrlq6SYpbVlFkNYftt3O2mZkhNwzHMNy8xl5jK2StHZCwSd9SQklMp1wIGwUkoWBsCwWmJ5LmfgwDqy8Cw9JXU9r8Q1hIJFpRiEiUBTptxaKwCE1ZhZc1uWuf7AgCIBF14Eb6St1uhgvhTBPACLa83PmHOHWW5bjbXLahsjgGJteVByGpQePf0jjOjlNzSSc3EP2gjH0NH3vBB8AGrmJf+Riy8MoqSUwLzchw+SlujiHvcCTp4U4LVD0XyFecKQzoykNOYCTPFPbsj8XGeuwEK/kqDAFyCbG68E0DkIBSjwKAC0+80BzSkqQEHr8lbVQqBlhVEtQes3GjEk1b2w7jwq7bQTFej2XbtOKXcyC2AqxCsRrH19AgXv1YDMl7UXp7qLa3khoGC4hKNqweJhDGzHXAU/BIFS+s1niIwpVRFyCTEHQzG2Qp+2SOuDEofuFdhg8Hz1oBUKlobQdMZDhVWUwAtD2+RiHNqnVF4sBQvUwTGEgeK7xmfKRDA6M2C+Pbet3m0KMz4C1ypL5dXGTGirEqyeAd2AXFWSFUpR5EqrCbbrCDD6UVb9GGPeW7UeKVY7MBsrS2kOwIwH4zXfOYg/xtpKCT5XWzGP54EtXuinLbaAWA6oCkxj0pfx80Z4C2hvzLwbtEH7vIL4oz99Ed5WjnxXf9HA9T6juT7RynjNsSIr75Tdd2jmWv1pGy/cZ5zkhVdW1WmrJO038d5Gqu2eCF0IKFR8gphtsOn8AGFAm2VYbRYKaHBNq5BDcPdRYAJDmAhz1oHyEQbCmuC6pmU+1xEAFhNjxcPFjwGFaygesCCELKK6AszlxrouK0tJCQ4FIrwEVftyDsZQ4Q1lbOmQkBlTfRM2c6F8QMW8zUG7QET23vxLgvnNPa5nTdG0B+JmiVgnoFnpePOgtIDAdebX4SxoiNb66HSgSo4D4SodXZOlRKti6LZtUxbXBgrz3FE7EtGKZ2Gu+uGF+K7akgqwjLNl08Arz8U8LL2aExlCL54NuvqN9wJIeIfmSiHxpkfFuU9YxePwyrWPhr3HY78DxMC5AjL9VstRMjJQQzvg5u958dnibPliW14IKCSkFJHwEALMwUwMEs/KHVgC44aqWeBSU1JCV5aewLkP41kRyTuuOdeTAFCIhBqKtyzmHkwSoxMGdRDGQtAhvt+409rndnvJbQgRCIX+JcIqRNJXnk1Le4RYuIGAhFK7HTILWKriowTAwPXGS8gIt2Se8QmdHOgh7pa7aKXAqsD8uCuKJpzI0qNVx6G7zlzaIAVk5DGqNjQuQs7Kc7+9jKUDaNqclDdTXYY+Cbx2KyM3fsJffoC7D9zNaQ7SeVHaMmZA7gWU4mtnbmjbHAC83yuH14/QCShIcmrLcqzwSp0FnliKBRDus9JhXG3EMnYyJ0fjPv0yFMZiTECUTPgerciQe8gAOUQ3YIH/QjRhVOBMRgAFmvJ+XJvh0PZ2fi0EFIrDcsMwXUdZUYlGCkDpHEBKuTDT0hSCit1ZFeg/X36SfJN0JAwQWZJLws81VggAh7wCQSAgEpMSlZKNgEKeQI5AJaU8AQWRiyhZ537C5TdKadxic/cRGhbb9wSUIGqrcyI6rNMcjZ8Vlx/QHtBg+YCTugJjlJS0CsIjkJmXpGv5k4KJqd0LbHgxFMS8zEVtg3GI08XlaCUHIYGo355I5W/tWzmhzC0lUjJ0Mx/XAAeAChzE+wDUygI+orVxmCslcqqTlR1g1/mL+pecpDyuc3yZlaMs6HzTm5yCOUn2lo+w4gJEFURRaH17b/UGPfDeuIVEll6t6kgUU2orUVaZKL856lfCFU8YBedAAl78BGDyFzwJgFwCV//yMXmKlNpYy5EwROo+0MS40Nh8eZcA2DsZ8/1ySfLsR4pX4QdJW94hTG1lztWkNBgsY847oLwEnlCzltUpAAdLdpJafmd5ZN0tgfkNOOQ6E25LbCofWXLKpR/uqeQWgSH8FJEgEG6KzmJYxSBIFLZaAsosIQj9AZazJfVJkSgNJfO7efJ2KDUL734AA4x4S4TFKguvILeSUBFy9RLmQIgILdBkcYAjAKL4PCifJe3aH8LrMF5jryrTXM3L2CT30LDaAfTXjpCIMqATMNYey+eUa6BFSdGHglMqYMor46VReMuDFEg7LDWFoHSUAT0tm1Igy5z6BBpWFnh3lB5QCFlYXmDgAFX88jIe4/e3ebkO6ErG4j1gYzyMi8I5wBUwWL40D16e6lgyZXyWZnkEaAoEgAVZazUEIFhSbUUMz6xQ4SEa4huaus5v+K0eBZ/12VJo1anmx5MQTkoCk7sSmIAIsPbE8sq7K59vSdRYjc/72voJNJoDTfe6FoCX/0hG1oZ9hXwlp0vO7s6bWYingBDFoDo2CBOhRL5XsOMf5lMqz34gUFYJWAKMhNpAQXWcycg+AwRCzIoobMEggswyE2LKb5kQcQEDJZVlFwqoviP81vDVSRiHdwLA01AApGYCwwkoxbacxuKw7MAJMAADYwdQeRtWU1hGymB1wDp+KxvAgUAROnOidOarHBs4ElZtERpWyvx8T8iMW+jlWHJCwRuyjGjuxkXxhDxtigIS5gRE8EC/aCUMQGtHwnPTKRhlMxcgyu0ve8+DM05AqFaDZ0MZhAkAjpeALoAOzVI0ymiu+IXm6GhuVpd4QUDQ/ZadKRO333eWHdHfvZ2cTWbkQfDXWIAnhTVOAm7Z1lyEEAwDfgAFxVoAk/eHBuRO7YW+rFIJGV3fjkueJvDhlQFTIUYPyiGP2qB0VkPw2Fi1jdflxYAvwEQrnq0zMsl6zxFlsAqnAUwbBVvarKahnbtVEpasn1/XtXhbcn0OFpSZjrmuTWQ+z8Gm8zbWC28WAgoNrgRVYURZZ64cpJeEolgyzZReMRGlUR8g94BR/qaM3G8WgLKyWD7LB7D44joxnmQlIQYO2kc4jITklBLD3QMgJAEJEjDh8nLlhQWYzSIRMMuY2iM4PA7Cqz+WUz6AVcB8TOJxUMqenwCUWGwCQqApNouhLYJDiHgIlLqnIPXsCFbV/fPnNbKgwh4uM1fW/RSdC4/OQAh4mS9lMV4KysPSB7ef0rkfKPEAKKzveSiBLeBl3QGO8fFYKCVr24oAwcrS+8zdF2YZg3aENsAdWKnDoJz64I4DE/wUCpEHHpqxdGIW2gCEkqNAwRzkoVJoHgEgZQy0w4hQeN4K7wVo9KxSPLFkzAvpEYHoTJHRHT+ETmiDTu4jOxSc92SMjAl5ZFB4Wo4h850lW8DH0+H9GLPfyE/7SVoVA/idRwnY8My/taDQpq+UvRW8OVik+K28aQPIVw7u+/6li+4PSFo63VRPoWqxNr002HYaQmiJRq6w9XxuOW8A8xETYmMKBeaKsW4EAmL34BMCRli5+oSQAhJQ1o+wewEJSM7yQ2mMZemU8HKBKZprWANj6qEhxi2+pZRcQkotlJALIeTi1B5LBtRYPJ4EgXKdPQjGIjQgdOZKyc0RMBgHYeVqc415NwCIhWWh0cm6PwDk4nYOJAWmbISVsmoXOLLyBJyXYj4Ar/oMysgrAWg+G6t7eRT+dr8xAUe01iY6tyvSb+akZgBN0BKI8oYoFmDibfAe3IP2gIVyA339oheFMVfXegEcXh5LLsygmBQdsADrHuyCjkI442NlGQReCxA2bx6T+eofDeVHKI220A6QCnEAF7qTTbwjL9rjiQF3Ywdo2hduUfSe3kXRgRPDwzhJfpLNyp/R2rUVqTEsQmGgiH7kSfuFBRnHFD6vIJCYW+q1HoS/K9kud+c7n1sV8U7xWyEyz0ILXstGxVUL8RRaw20wUAxRqjVovZiyd76CiRpsJz2bGGtlYsVoJloeobVy17HWFK7TniNW23Expux3W3kht/v0WWGKfrTv/vYKFK8RgNayqy+o77Y/t5RF0MqsmxerkjvX0pt7O+OwSj3W0hj02fZj9DFv7RBmljAadVKxtgg+hW0fQGvubfNuBSKhMnfCjFdZJWOONxTOnP3dWn60cl2HyAJOYzP2liL9XaUhnmuLldRWsXYnUTc//KsuxOdOqKLY2tZONSXoxbP0rv9Opdan73KRS263RwEtOpujpU+0y5q2s7e8mLaM3fetcvVYgVZSXKvfHnenb3TAB3OoihLNvCp1X8991wa+9C+wyKvwe2XuWf/yDnNPY+5l5JmszVnsahwLAYUINi8WIaQ6w0yWrzMHWKuUmlBgvL+5vxihDQTuEJRCEQpIML1aWkMEGWqMb2kLUBDA1tMpPSETlggnOvehk4SqwmSRKTeFhvqIz0L6zmfuJqusrc5BIAT66TCZlvH0aRxZ8Gr5OwW68tmAg6C5xxxYzPkhtcIZiuUfWvSMCsoTTbMSaFhogSYpGg8NzVqiNY6WDb23vEmAK4jCC+DaTle86jh87QYI6N/SqXe0NxdgFkCav7/JREVULVNGfwBIAf2tTaAQgOAVpQ4o2jSFL4DS9/hUEZixGkc8CDB7ypY+WlLu0QHzPQ/oqU/y1SE0DIM5GId5VZNhrMKQeK8v3hKalx+ofLpYnwzPE4+59/OQYf7Z73jfd94zxNW5GG86V8GccVbEt+k5BQOu8pCAGxSh5XqJAyUXuZHcrYTFIMuaErxONvZdBSQEnDLkAhGcqiQrIkLwefWaa7IwhESYwFXl9mov0HBNgmaZT5IrZRYvy8TPqwIJWsJIKbj6vADxqjAgxlfg0rMChB9CHi4674V17wg67VA8wsr6mBsQlVSTfDR+7r+YmfC3AuG6TmiiGBiv/gOACJVyNyvI6fAadDXvqhiNvyIdfAMEBJDiatNYCLx/5mVOHdPv+oTTfCg0l1v7eCPfIdfjezkL8oBWXmiZAWiJsENnzKuq0caDb805MEFPNJfw9ALawLaipyo2Oyqu2pPqLdrMZF7kFI8AJBoZX6dlm6exVdlJ+Spll68BLnJY+CBkxEs8w4de2ijmz0sLMLLSWf7e1+YUzMs9gQDZIK+djoUWFerpT7t5FYUauwOGhXgKGs0d1HHHb1nuEXuJZyXqxJSExkRMMPcd830nFsVMk8E8Qsn6ABzCWumpyVdR1hOU5BwIHSF0vyQUZhoXlxMgZekt1WlX3YK+xZvWpCW3ELunJlMuWWjjMm7Cw+rJRssPiHsl0gheB7jwhMTJlFyNgYy9+7Vp/HIbmMZzCUDMXQKL4GRVCRZhsxwnKw4U5BYokXGgH4AlrOYCEOQAjEdehNXoGZ7aNsf2CvQsA4AtB8PKogm6Wo6TmCTcljBdaz76l/fRPwHt2R65vNqQu6AoYnLJU6smlWBXNEShuN7aqaqwlRt9oSN5cg2L672t8pQW3ymt8MnqlWQiOWtPBcuN7+41ZklJCgOYyAe5aqMYY0A+GAHtoVkVpcaNZj3Ru30t7jV2bZExsiDfILciNyZfggYStZSWfPJCK+tv5zC58zvZJjPmHNCbY95fVarmTLk7YzOPl+zgVZ6mufotDwHdW6LcVFCgMNUnmEQxumQTZSMkkkmEuyU5yMyaEGyuGGUg9BghuUhYLRla3qJ0MuESdJJDLfVgOiWQCWYpCQaEluyTfSb0LHMKK6mmLYUwFMC9mCphB7woL8HDJCsmEogY1clGkpZCC2Mr0VnoYPwYLwmqPX1IYEnQYRALQ8BYOIJgFYH3hG6UQbuWZCmyxBZgA6aAVPKM8FtlsMzXEWuUn1U3XoyXkJOcNH90RjvjlwT0mxUE/QIfCcdieWABhCgQhRI2FXLogweAp5KPAMnqAe9BQtAcA3LWWsIPWJp/BU3mSHDxiUJZegXSlLlH1vMk8N/SrL6MH/BQMsZB3Qnl0i+ZQUvKZ5XJagPLbnkVQFIgCUl80KZrFap5x3O/A23yqF/zAKhtokInSi6UpGwSzp21IAlN6dCFF4hOPDm8B+LmZjyABm+01UOMAYv+8VrilPwCF4lPPOchSqaTLbqB3tUaoDNgM+6eoyqRygs2Z6BuLsaJZvhesrPS7k0FBZ0Vk5XIgbqsF7ecK86N5y0QSO/cPsKEWVYjEFalGkGQ4TcR1sb2ZddRdoLLOmBUG5oohLVkvxPEiqQoBIEgwFDYsiKXnNKz2BimX/cS5moJiokxGGNZapYMIzFVBl7ogFmY4HpK7X7WBgBQbAJsORPDWRIgxTKZJ2UxHi6iVYd2PloaoyiA1MoIMMN495i75U/r/gpxjEt/AAqoAiwVooDEPI0ZEJUTQU9AByQpEA+G4lia9bc5qGeg1ITS+IA6EOMxABbfscRWNyiSvvDVi2WjhP62lGcuT3jCEwaQARlAgTbAi8dhbK5XsESZgWsP3bVEjY8E23ZwMgFAgQrDkOIIBSkXwKSkPL8ssesAtfGw4HiCpzw09I4PwInSA2FLv5QOMJknGaWc+O0+KygU0sqG+4GXmgneDLBkRMgwY2aMljPxE4iTH9eYD+Nl9YQsMY6Wm61c4YnVqDw8NLYEa154pT99+Y4M97BlS/uW83lmvDUgwTAAtWpaNj2nQNEpSVnUipYILcKYHCQz6BKFiAPlCJN7oRsAMAnLfSaEQJU5UwbtsHCUGZMonnfXYRIhq9aho8m46AhJKPWP0QSIxeGW+iwWpLQEidtJODAbYPFQKGE78oyzpUOuM88DIhNo8zWmaiJYMqBBwAk1QKLExmhe/lagBJSMV/+daemzOgreTvOjPPIzQMU8ynQTXJbNPAEwi0M5AAABlLdQq0H4AJG/Ka05mptxAw8hkWIpgMI70W5P36Z87jG3ajBYeTwDIvo2985JIJyWKoEXHhszjxI9KCKvDJBpg1ICJl4Rb0WYx/2mqMIuMoSP/lEAbjvFAKiuBRr6QxuyQUY605OiAUPAxDLjJzDXJ68J79AYL8gkz44CUmIea7kPPPM9YwIgzZPR0765Cyt4HgyJ3/AAiOTeA1ZjNp8KssgM4OL98lx51IAfYAJOYwDKDF9nd/A8eFto3aHFgAdItFRPpoF8q2D7bUkyIGi5x0CgLutogkCBwJb8YAkJDLeIAJg8onDxuIQBDML6zCVjVVhrkyZc/mbpCRSG+R6j20rL7SUcXDSM5PpJCmICK0S5Jc9YWu4jxlF+rhwrSBkJDFSH8pgOnY2TsgATQMVzcS2vAPhQQArFTQUixkkZ/UZgxHlCBX2yqgSWi8xyVHUIwNCO9+Ma9PG3+RMkwNkmJPShyPrNrSeo3FZgoaYBfSiCaykFa6RmhDeFPqwb/qAPBSBowIoy83i0Q+kosjAMsFBG9MIzdKFg6IA2wNq9wBYodLwZ0NUHupm3sM+78ZoTDw/PABaZMkZg0EG8lKKSZcYEmAkthBTG5d19eFxBGPDgelMUNG53I9AF7JQJncma8Rhv4QmFxO+WSimteZIn80Q/Vhmv0btwjtfGg/GO/63WkE9eNHDjAfB2/C73oO+26wN935mDa8wLwDAavAu/AZdWuNCsBxLRLfLWSl4b4DY1fEBkIJAi6xzhuDuIRJANntsmUcJFbbNRh1VgcIDSnn/CT2kRo0e4tyW7GoXqGHzfakYJGe+tOmjbODGvdXCC7b6I1jZj4/RdSTKC09FoBBfj2r1YDQGG+B6Ka7OMOWForRpYGVNnMaCN36qJYC1qw1wIjzFrS5vzmvp2OBqjz+4z5vb2E2zg0zZvPDGWaiP8DUwJP8AwR5ax5TjKSxBbsTBW18QbPPFZMVKJWH2bQ09j7tHtxl/yzBjNxSu5qVakmoOy4W1/b6VoXtijr5KdaFCIN3/ytbm6jiy29DrP7pNXL/PiWVFAcyYzQJqyG5s29FH443P5hxJ5lRf7noy1RKk9dCdbATqaast8yI18i3e6gMesPjlBn2jVsfvCZjTsHBI0ayWPt+K+TjLLOBrTpocPBlL1IoY2yLwCg0Wo4j2xMiQ0aQKU4lICTCCAGMa6IAYi+q2Elfa5rIiMaMX2mKV/REMQjPIdr0L/CI6onfnnO/1VvELIMVl7Lff0SHJ9+7418JYnAxtKmQIbuzFgOoEAbOaJHtrzfVtwxcnmj4bVWnQgaWc8VLrccpTxtgJD+AhTNQvGoP8STWhH4JpHBUr6wo8eAFuilAL51xbwjqI3ZvOoTqMDVcWvrjGeTjYq863fnh1RUVibirRjnB1rpm1jMS60RI/OQpzXlAQYrjMnvI2fxt32erLh71YuWnZEQzRAn9po0xIZ0ycaVvTlvaI4NGHMzMHnVnEyBNVc6NM1xhCQA1FzqpYkwEQ3XiVPiLXnBbSFnpwzGlUqmk/gTA79q+weLclv2+qNBbBHh00HharkqiQDEIQVAwlISitpBtGFDdWFYygBMfFCEPfEmKx1wgTNMSYEbp3d/drCBIKqb64uF7a1aFZxfuafMSJ0h6toE5ExGYEJY4UjVYaZqzlwK81Lv/5RSmM0BspQrQWmYljjS2DQSB+E2Ms1riUsHfdu3ITYdeZJabIgrJi23GOMHWACQIQDrvM9MCMYQIkQB4LuM5cUwtiNAV8aT9WW1ZDkzSXsFJ5yaIvn1jIbmupbm9G4IjTX6LeH4VZV2TmWVbEG6trqpK7oHXCTEzQgI8AlJY/f1S3kaZEdxqgCKn0AQ69WzIyzk7jybPFSW3hgvOYFQNyrTwYATSg+WcKnakCADJpKJFZUl/FCA/yqdkYf8/ob4zRnfVRtiR6FBT1prCIx3xt/SfgACf82HRSqyKqICMFaSgmtCZBkG+EUoxN0E6gmXVJF8oTVNAkoFyoT5NaWxfjyE5JdrtOe5B2Ly3phIEHRH6FhkRGrU5AIfoqr/6r+MIRXov8Sp0CqSjJzdK05YlRViLmevjfXHuemH8KF4X1njBQWbTCckBGiXHvtY37FRbJxm3oAACAASURBVMafxdQP5ucuajvhTJEIJoA1Pn12LBtFNLbWq/VdOxXReK8U3Oceb0ehzCXQaP08EPN3IV0FNAFgTwurMtA9ZCNLXQ1/5cGUKW9Sv2gz331q/Obit8qdO82KorUsrr3+TrHNvzL8ABKdC0nMr8NzjM/Yo1H1I9oyvsrlkwO/F2ZU5l3YFcBqM0/SPCqldn08cI3fAEkFfWhgLsmIeRf+Gn/jaQOfv9HHeBjHjpvbdFDI5TNpA/aioAYmXoXQlJ6lsrvNxCRgJPZkqCm5LLzEjOsktGR1JQ6t1UoYukZmlxDK3EvU2CILDWWsKT+mUzrJPMuA4v9c2ix+1hHTcs2qMtsd4apBr8oM0f2rVDVL47oq17qnGNbfVX4mCKwO8OqsvxSTIlSzn0BQKPdTHIpFINv3kEtd7XsFRc3H94V05pB1c10gsp7QRCf9zNsOLHKv1zVHyx+3LAUWUtFIyCpPrk6d8PaAFasLKvlksWWKLUMpZpJVp/Cug9KEHUjI6lptkHm2HZhiWA5zre+AgxoGSzwQsgM6LNmx9j07kQdRWS/rldUj5JRDu/ONMhuBwhz9Q3f3BAABgu8qNfU5T6rkpevN1XvWrVChHIm2/FboUel2IYc28xxcNy+L3RUgBVh4xeIV7pREW09iuzaLrq0qSs0zb2fLSv1yYJsfPlRnzerk9hH6nn1oKVDsae2dEjt9yZowN98ynuSK8wwsY1kWU/Ci7qBQwbKP5TSgYDlK2xSaF8CrUFnWMeKSmEIPYQBvhNAT3ISfQLdxi2BTupKj61FuvhklIMhjKMwo1PB7v+mPK0hx/c5LyKWjTGjA4vOQvNCpDH2W2fXlUDpnMC8FDZrP3Irn/ZRzKembi1xmvrGuN/ey9HMAnHtXe0K/pV5uXQosxFMg8GWRs4qElwBy83kJFL8abdWHqhat4ase41W4T6igDNSaMo8CqHQgi6ShYhxr6NbYeRnApgpI6+OO6VJ8Yi3XZhxJO9fLIQCS4vO8BO9+K6u/kWK0mlHoEAhURhoQzJdn9Yk2aOSf0Ml3JaXKWBuDcKsDQl3jbyDSKkFuf0tVbRKaeyYlfedKG2iVoAIoPpf3KI7f3fxdp42W2bTdZqutK+rLke0pBRYCCu3YogwSdp1y3JKNrCuBlhQSR4uh28g0Vw7CVnKtpCVL2JZb1pLFkwTShlClJamy/ZRcpRkAykIXT8+XS32e715bj4AlgMpHtCRYCamx5lK3+65t1RTJ9cZavsV88qrMSV4kZUajtiPn8uvHd+aERuiNLmjg/vpofnk1hTjzFRH8aWkWLY1jo4q3VoXQuNxIK0wlxfZUAJfXbT0KLAQUuMG8AhZMzFuWlQC2hRUpgEVbnQkjq0lxfU9wW54TK7e+znISvI4zZ1ElE9uEQwmr7AJCZZ07+IQQA5q2K4vZW4Mm7OUy1mNVfZQfMDZKj5jAznz1QckAhJfP+i4JV2GOJSdzLtNfDkFb7jUX4U9LUdESIOi3reHVWJQwLYdhbim59oy9OgafjUubhVRtCd/IS9JPeYTCoJKWGyVqt54aLEc0p8BCQKGlEUrQdljCx7rZEGX1QdJP6TBlZd1yoQkor0HGneBTLklG99t40vIKoaRI8gcUXJmpeJxl1RbBbFmI0rWkOS8ecb/r9KUf/bpnHjPvSlzyKLLEeQEUXFtifjUQEp7lLlKUEnFyHe1ua7mo2nT7OixXulYIpSZeqBHI9sSm+ZOthUXmE5i4d27FAySKbDOV8l5AI0+Ddr6fg9t6agIEyuEI9cwRH9Gw0GSpZtuXAgsBhdzV8glV/xFCrrw9BmrrFRJV4EQgCZecgV2TFDnBpvh2N1qmLDzoRCDLkK5rc1X78gFDZZ36aDs3S6gf7jaLKfSwc45Aq5WvUnI9lpasKzRwb8et249gjJTUBi8eT9a9nAMQsXHIJiPLrLnv7pN7sXwq0QrgJGAVdwFI3lEPpfHZfgn1+sCsdW79tXZfmFTytFoRbaGpqjmAo2S7Q2AqHlpv/vpCgx6w4+/Kp/W9fG1vCiwEFFpLn2fo50tktpPazmuzjgIlu/FUBEo4EnS73iQR7YmwGkFZhBdWHLxbfrTZRzUaYbSRiMDbuSeB6XAUy5A2q1iWtOmEZ9KBsHbOST4CGt6Ha1luuwbVRlAs22p9th+el+F6YMULMFYAQmEpnDoIG3qMQc2EDTf60K7lVRtdbPRyP8sqKWpjEOvq4BWWW42G+goMsWXZ7jkeFOUVQgAD8zcmtAQoQLIdolZbKLgNRGiILoBV4tb9Ng5RWF6GDT3o6h2tbTayLAyQ7b4DYjbzdBo0oNSmDTpKcG2wMTcAb5+DzUuSvcaoXXPtIJyWbefLtNtbZQ780e8XUCC8dupRFlYwZVeToGqRlRQy2IlHKRwUoiyUYNqY4mARisQq+11FGoup/sEqQ7sSK8ahqNrquHK74NryqwjKiohlUcub2qL4PRiGAgh3eALGRuD9zUOxBZpimQfgcg9lVqpqxYTi+FvfFBlY2LYLjCyz2tHJY6FcQglLrUBGhac8CdDkbQAsACI0AaLVBwAv4zN+24/VbAhbFHp5WeWx00/ehncmxyJfo4AMmLTF2vXOOkAnQGoZlDdhDIUH5qIsXU2I3wG/8E9IqN7E2M2N1wWAeEU8iHIPALNVivIsB756bc8ZLgwU5uvicy/BZ+cTsFAErwdpcONVN/pdIRPF51GwqISQReIJWGpktVlpAqu82W8AQ40CpegpR4SYklE+XgLAoKzOC3ANDwU48Cx4Ep0VwEth9SyD8jQABWUUjojxEc341U4AI2cO5BX4jVtOOfRtqdXyaWc1CJlsdGGZO2q+ZzCquKTAvCg0UgUKAPTRcxuEYD5rjxfCmgMF4RhwRU+HnlBIxVzmxmNAO4lec3H4hzMGgIE2HFTjOnRCTwoM/Cphpth2PxqLfrRhDpRfrQlgsx1eCGfZt9APLwOGlmk3WtnYnmp0YI16IaCQJZgDA7L1N0XjqrL+FJzlIjQsD8vNPRcmUBbCyBJTVFaRK+x0IJabYpuA2Ju7b8+8+FptgheLL9kHZCgOt5gLTBkADdAQBrByrLnQAwgZPwUVllBO7zwXVrezBSiSdiXqjFNMzrL35KB2wZmz3AUrDQg6psvv1QaYs2IlSsa7ATjm6OVvLr3yZ9cLnXxnvnIBQhL1GehBqc0TOKBTW2opMzrIF+jXNUIlwCVZCYR4SX6j7EDNeNxXTQSQBIpo2vMtAaSEKG+Gxwao8ER9iOuBhfmaf5uX2rV5YKnRgTWbhYBCViFSrV2iIigEkOASGNab683Ks/68Bq46d59lYYVaTqvgyHXAg5BWOMM11g43u802rd273r82Q5m4XIGxABKKrT3WVSzfRpYON2Udtd1KQ4VDhJ2XwL3vrATXtLTKwwBorDTFAQ6WVdvJxlvqNB3fW4kAWJSrcmXXUnrj4nVQLEA2Py+iXX0ttbLyFSHlqaGFttpei96d/ms+bck2D+NoJ6A2O+fCASBWK4Rx7kdzNEBLqyc8Lv0ChZKW5uW7ysiXS5ZbG0T2Cyi0vVgCyythaaux79q55jMByyMoxu3kGgDCShNKlrpzBNpaWv0AJXWvV7URViJY3baccn0pHmE2Rgrb1uV2T1Isv/FO/AYM2urdsxg6N4BiFf+bY7sB28lG0TpQRDuUEpj1PAH3mh+FRSuK3sYoNHFth62gHW8CqAE593oBluodWh42f8DQ6dYBKzqYV/tDAEg78HhAxmoc6AOY5lupfY4X5pq3WLgwX2VagsJBCApra9/nG3KQw+8UkjBSsk6WIcg9XqytyVlI91TU5DoCSilZJseEdUx47mlufHv5CWW7ERN6fXRoawepdA6B+1hI/VIm13bwh/5bZjSPNitRMi60fiiUa6oP8HfVg80dEHSikX7QwzXAwau6A7/5ngfRwR8U2/0t++qLsvJ2AjLj8j0FrfbCnNBCOIGefjdufVFqcwOeAVznV/itk43Mxb9CILTTvrkYEyCqiAoA6GOeaFyCwhIUdu4ajBRlpCle2307NYaL7rsO02D1CDklJ4hZe4LMOgoVOiyEAHcMG+Fvi2/bijsDwDgqm27rMXAi0Cxw9QSu6Xz/7qGcxleFYsewJfSdyUBBeRra62CZHvPWKUtClp7c5LcOGqE0xtzv7ZOgsK5pTwWPpFLyjlqj6BVldT5A4UO7Mo3HdZ3O0xOotBUI+q0Tf1zfyoF34JW3lTdRVaOx4iV6VseRh+JevF+uPixBYWtTYDm6JQWWFPgmCiwkp7A2fFjSfEmBJQW2DwWWoLB9eLUc6ZICm0KBJShsCpmXnSwpsH0osASF7cOr5UiXFNgUCixBYVPIvOxkSYHtQ4ElKGwfXi1HuqTAplBgCQqbQuZlJ0sKbB8KLAQUNipOUYWnGKkqPkU2PW6sx61VBangpcNWeuCI9hXWKMlVIKNwSBGNohqFO52M1AlBHY/WHoJOJOqMwdpv7//avRvbh51bY6QVcClgwhvFTD2fU8GVIqz5ztlG3enTa0++WlsR26Gx2mmbe4+5a2+Hku+e/OS7npPRaVzrUWq5pP6NzYv+zU8E77EN9vM4p8PRAT1bZOX4449fRVwnLWNMD1bp+PSNQMF1mOjejmKrLBhAYOD8ISrtlcDIBK4j14BCpb7uq5S5E6EJpOpAjCagru2A1V2BQt9tDfXamqNYq6RrRwkMVF6q6vQeOFT6nNKvPYK+8ue1u2y1Py+NDtTxtCpNbfdcSDwnT3hNDvAfeFTtuiyzXl+u5ieA7zNQ2MjS+r1HbLP4HRmeslZqGzLNp1CZbVYfo7XlpeSYdQAM7UnQlon11KU2Ss0tVdeEeltTFbfOqDYCBbRFf3sjelRZezA6NLaTpeceYfSfy098misyOZk/+LVnKzIyAKUHr5IRZdfGACAqqd/oTAfjOJhfCwkfNgIFjOtAU+89uNVnm4EoulfK2uPIfNfx6dX38zg6ibide8ChZyvYA2ETEUEhPDyLdhAmaHMhz2U6mIVib+fece/tCqWcPWi1A1jW62NPwLldsl2L59rmwXbMPADqAbl5iQBio3MkD3ZPYiGewkYxGebZyGRTE8YBAoy09dm98+PQ22g0P3yU0BEKm6V4GtrTVk/oZRV8h7mdHkQIgQHA6XkLcyu1Nq7dW8U4kO/fyJLiDxrL+dhshXc2fuFZj74rPJwDcxu95uEFOsan3vGx7dmMgxBBO3kJeK+NnsqtjZ5m3rkOBzJ/9sXc9nlOYSNQIDB2EPYUJFbEP2coSBC1K7InHrX1N8a3RbmH1s53OhISim8nInDpyHcWpF165Q3mh4n6Lc9kI/d4XxB9O7exEShQSB6cfBFXHzDwGoA4y53AzT2CeTixFhTmwOCzNrTl7Ag7ZDu+vwNjvPMO2wJeTgF/25K/TDSuL4H7HBQ2UipMcvipo89YdycTOVHYQaOOAnNsmXMSfO5wE212wlInKPnOcWDOX3TWgGzota997QE4jnkDBM5ZADT6JET6dBRcVsnk2yrddxsJ/XZW6M0YOxB3qK4Tnh375h1/nJHJU+jx6NHbmPIcvPMC8iAC8vnfvEp/O47OUXnOhnBorNO6GAHH1zmZytkSrgMiDtp1crcTrTptfDNosR37AOCbDgpQ3DmCjgM/8sgjx8GnDl9lXSQNCZTjzj0QljL7niB0ZqAzCooNWSMnOzsh2QGnHYeOGcCBy0ogCYv7HFjq1Oi1T1DKUyg/sR2ZuVlj3sgT5PU5GdohrxK/Ttd2BqazJ3tCFuDoWZTGzatr6VBIOPfqSjjnWbhX2OkMCmdUMgaAgezoB6/rB//JgXMonWHZMzLWo9XBnlMIlPfpkiRmEwzMdP4gy+A7wsT1d3Q4a+1wVKcRO5pdPsFTpC1juZ5LaHBOPOYZsDYAwmGhTh72jxeA+Q4+5QE4wBSAOHbdUeTCD6cSO/pcaAJ4OubNcxIcwupodH3yKjrstCXOzVKyrdYPpcODTpeKf9479l1YAKTxt2w+peX68/AcxutQWJ6b53MAbZ95iI7T9ztvTntOuMYj/OA18gAIJM/CYbx4KQfleRlOj3aSN9kwBs/IoOwO3fXYAGPyvaeV8yKcaUkeHLDLS+CNWiZ1+ndnS+qrJ1vNV6W2Gl/21XgKwwuj6SqeowEPvRzNPgWFzvzTqCPEWfMOGcUI7rznCzj405Hkjhxn+SkmofDYNAIgOcXiCBGc/MzqQHoTcH9Ll6wDYXnyk588LAVB4oEQCIeM+p5QEUruKw/F31xMpxb3qDjtlp/YVwzYju106Kskb4nfcgF45vtWhDyzAtAD4F6stofWBByO2KOQPDX3U1jP/ui5FYAcjxkJYN9BsWQFMDk1G08ZCM+vePaznz3GAADIiaP2nfjtHcg7mt9TthgZ+QwHAJMrTzUHTjwHz+AALPIPjb1allantiPv9mTMwm6ynk5WBCbHBxSqAdqnoECocscxmyBkeQgTpquI4jJiKob3UFpWxhHtwIIb+ZSnPGUosycwARiMVFHFbWwZSrjhGZUEUd7Aw2Q8PcmzDgiAo9mBhlUOQKM9DzDx/ARHpRsHgiAGQTzYY07KMffu8DLPjcID/QDZ+Zg90q5EHiV7znOeM7w2Vh3gO9Zfm3ggthc+ShI6Qp9w8gR5DSw60CCoPLgTTzxxPKjGw3MYhWte85pD4Vt2dJy8500ABSECL+RlL3vZWLFgAHgR7vXZUfTGblzaYJxcV9EdEDMWgHMgv3gI8a9HKtI19KZ/aLTPcwrz+NxR4Nx8AoGRBlTSj0eA0VYM5AP8zuWkoJ6SZJDcTcyC9oSPdbc64SlPWSxAQKgIGqHjil71qlcduQmWw+PnCAX3FDE8jYkXwUuQu+hZkH4TqxrHwfyiKBR7bjHQFdjz2NDJb3gJoHveBfeTZccvD+1xPeUD4HgOpCUefa8PiUDP0tSex92xUqpkPf9D0tDTw4AE4PDOkPAS5id2SyB6Cpd8AiASjspheAIW4OfJ4D3w1/5rXvOa4bm6Dih0uK02zdnfG9XZbHfZAHyBYR4DUPCPTlQGsE89hYQJs1kSglTxEE+BV0DhMUs4UHKQcmYhHKLKo8CkTkHGTALVUeOtVZug71geqxmub4kLwHRqMlDxYik6yZkQ+8yV9RI+bJRI2+5CsdH4S7Z28CoeAAV8BfBZUrwEyJaGJY/Rzb1A3h6H9rGgLU9DLI8/EoGu1X6nReOT6ytsw4dqT4QBlFmOQRjg5Tp9MhBkyMsYtYGfgTtl97kHD/vNGLXdad3kz6sqWZ7DgfxKN6ok9s44ozlPgU7sc09Bo6ERS8LlZD0wpNJTAoL4nWzcCc4JjfgTsw2WELI03gkoJfe97/I+CAgB69h4gmCSPaRFhaMkU4+HT3iho3sISRlx1x7MrzL/+NVJzPiCPiwJUG0PiudRCsnQv6w9nvTE71xV9BVKChHQPANQBSJ+zB9eoy9KK/SUkwA+HsIrZCQ3CW61LPNq1qy/Nhigjtrv+ZbVvfRcjhJuxnyghw7kOm+oDYN4DDTRW8J2Xkuyz/c+aBAolFNA8Hl5M6WWCMI4KE+weAPFsD5roweXlICSHGolgzDF3I5wr9zV5AlwT17qWHhCUYFL9fI9rKXH0x/MoBAQoAkQx48eKsuSBMR+m3sK8wKwjnovdgUIVn/aJQlw8JMiornrGIj2SjAiHVtPeHtaFl4zKG2Ea+OT+91DxsgN/rovD9U9wIG8aKtnVfTYAErRzt0DvU6l6mDvhYHmX05hIUuSFLm693IKPXuB4AQMBgX5CUVhg98wjUtqHVrcF3pjMoHUVpucQnf99QAXCg1oCBBA8BsB9F3brCuJ5SVoK6+jEuuDGRTaeh5NKQleUORizpQdKAgHKFQ8L2FHyCgomkd3bQTeJfW01bMi5kVKAT+vsRoV/Pd9ituzPvwOCNrzQtkZGatMPUvEvX5Pjvw99xADjgM9fGwXKprhWRWo+GWVqIWCfZpTaMmDcEgUshDlGfyGMWJBwsSVBABc/QSnJAiGYxAGBzRZLr8RLhPztGhtYj7Pw/ftkgQG/jYWIJH1MOFiWm1XGOP7nhMJZAiOe7MkucbFsnkp2kXcQKYHqxSftxHI/cbTWnHglLDPl/YWBUyFd3kElXfrL0FoU1P0ZsULH+YPw7EiJGGI3mWy0YsiF7oBbnyYG4b2ILS0GBjr3/0U3P3konM0KmQzXrzmQTIqrvOdeZEHbXXehvYLD+eAUv4DKOhTP3MZ0I72q3vozI0AybXoUSiSgjFowKjwFk3nINYS76J4q9088nIjxtgY8LW5lFPw3dxTWEiicSNQIFQlfygBZhMCVgWxKVplrxEvBrTs1R4JTMUEYQIB6SGwhFK7PaINIaqYc60XICGs2uLWlvfgXRgjYSLo2iA4+sn9RFC/FTO31tthIlmy+f6KsvbamjPHuPzmO8rSk5kWJTjoYh79K25srIRpb0DBXCiHpB/6ohW6+K6NSfXRHPVd4ti4svgEFH8oLcC3KkEWKLgx4o0Xmcmz8TseSyzLhZC1ACvwxgPyUqWsceFDe2SMFZi5pvM4Mh7F5Sl8Sbn42xI3XpKD9luQEX8DjEW+ksGALxBonOX79gsoIAJPwbJTsQvCGgxUBwiuwbhO56n2wO8BQwmv4n/MMzGKz8sgONqdhyYYoy2/YU6lsmXJMaWaCW4jIdKf61rdqCqTYHceQ8+mBByYq1/X9SDXFC4BymOo9iEw8e6aYmL0ac6LTnQCvKoP0alE2xwk9gYU5l6ZuXDh8YDi9VDePKbmH+8KS/AnRfZdLn0eF8uGl2iIz3hAPtCw3IC2yynhoevcwwDxUgP5HhAcOOIhI2HVjIyZT/KVJxUwzD3CZCrLnIfaKkfA1/kfiwIG88m78h5/8wiNLz2sknPTPAVMevvb3z5AoTgVUauYC8EQNmsZKBRKmFT1CNrzmUC53uQoNMtKEDBPGTNmuxYR2kLdysX8Kcw+Z7EJAuIlKIDBOFMeAl340dqu31ryCqBcg+Ctxed+Fz5lLczTvcbf8lrA6ftFvihQVq2t5fhirLnxewMK+MM6AwOhhXnlzgtDeITmn2te5aT+yQTQaizlCigSYMFfvDBuvMrA5LEBBTwQUnSoivvaSs3r8AIMXo0Bz4yjMMi9eQjzGNzctLWWv8aNhtpDO/czGubqM9lMZjc6z2Fved95JNWNVLZvbOnFfgMFRCinkHuMcIil4AWCcgvbAl08iIhZ0VycrIUJFmbMLXVZbQLgn7/do20K6z59+px1BCQEIbfV953c5F4K29kLHRJi/D1Kvn375T5cXyys3ZSckBSv5428+c1vHvsGMNCY5om23L+9FY7d3V/FWtaPm2ypVlUgJc5Ct4Rszt9OTiHlQsMSvHiKDp28VOhV0tnfxlO+wNiFC2QIn/CzGpfmxbrhQW5/vM/Ta1mz6sx5mDavddGecXQgj7G4J6CnxMaFL67JO0Ufc8od105/K7e39wKAkYmWeY2ppddF8benfhcO6k8NjxoP3s9+8xRazip8yC1EHESyH+GJT3ziWOpSlmpjC4WcZ48JUpuritFbxnz1q189ypStq9rcZPs04da2Wnl7HhDHUifrgFkES62Cz8ZnD4RrWJVcS9VwKiIx87rXve74XaJU0Y77EBR4tYGKUNZH8XOhQ9Y4YfFeYur1r3/9mLvNPoFX51MuekPWPGTIUyDw6FBRz954Cmj72Mc+dpSam9Nxxx03NiBRasDpu2iYRc6jKpmoQhVQ2ikLkOx1ycu8xS1uMd3gBjcYHiNriKbmxHNQFu2z9mzEMhb1LgBEyEduVEFSDpvrAJjf8brVE/wrn5B1LURtjb/l1xQsYGgsZNKGL5WTtdG9+lnkK28l7ydwx18eF1nfL55CoFD40IoCYvqOMrCWUNfmmFe96lVDSVgxg29rNGaUsJJ7IFTiQWXOlN+eCCXQyqNtrKL4D3rQg0a9PIQUU1ZBZzOM/RFPf/rTx/cEAzP1y4KpulMSDaww1Zhf9KIXjT6UzRIqbnAhgvuV0VYpSXihsWVY3kzWP6YQisIiVsRczaNXcTblWeSrE40JTzGyMXaOYtbunHoK6GCfATrf6EY3Gnyy98S8rFagSztc8xT1Ld/gGt6K0mZh553vfOcRhti/8IAHPGDw365Hexp4fmTF7174DCz0BczxpZ2QAMN39sHYhwGMKMdrX/va0QbQAiTGQYbwyhjtwAUu5AWw+E7NBbmd87ew0P3mQH7ca1/GfPm01aZF8pdxKizSTyszebTxfNMTjbsDBQTiWj3pSU8amWQ731iBRzziEdMrXvGK6U1vetOwDvYsFAsSBJbD4SsUhyKxQjbb2CDDG3E/4aOQrLdKOwrKylNsbdjn4B4HchTT25zDOyAo7373u8d5C/7pB9MBFkUGUq41Zlu0WSN/27VHWAETZbve9a43LJciH0JKEP0r1NAWa8wbATDG3FJaB5AsUmDmbZd4Kh4PGFodOaegYI6UliLa6wCsHaJjo9sb3vCGofT2OFBGfQBbpcy2vwMGSg8EgDFeEXLvtsG7h1IaM8W229GeCPy090U/FJzXyf332XkbAYHxOL9Dn8DPhjsGiawAMiBGttxvsx4P9GY3u9lIhqvVwF9981B5oOTEP7IaqJAbBo83SDZartyM5chd8bfaj1bwCtU2FRQMbC0o+K5MKAUnHDYtERSIb7MK5rDUNsTc85733FmHjYGUB0MBih2RlJMAUE4hgU03rARBtJkKQx2mol6ea8h68QYIlX5tiGKJCCzrYVON6kt9UHruI2ZjqoId4MMNNi7be0uiAQsC67QfbetLBad7CxXMnfDP8yq29xI8QjvPIRTnLxoY5v3M3cz63ZvwAR0puPDMpjQKxXuzIYpHR+nwD5/QCc+chQC05TVSWjxHS3Uo+CAkNC6AwhO89a1vPby6StyFo0bJBgAAIABJREFUnhTwxje+8QhJbcUG6njMyHgBhwc+8IFD5sijHbXAWf/kyUEw+MszAG54Sh54HzwIoAEQhADG3pp+LnsJdV4CWbWpC1js75dxFpa2yrLfQWEePti9dvLJJw+lFR9y3xH+mGOOGQxxAItTe7hqbWChrKwCl10+gnXlHXDjIDJ33E7LEnm8D0LJEthSi4HAA6JTct4B95LwiH/tvmQJgFKHtcgViFHtsCPE9usTEkJlRx5hNUauLkBj6YEb8GmJrOWpALG1dBt8uM4UY75MmVAtWogAVB6BzyVc90XxEgvOagNKPEJPISMFxl9KDwBsYW8tnUVGSzymxMIM4MGC8x58R16Mj9flNzzjoQntykUI53iS+O/wFnS2UxMPgQeQ4N3xLHh2dl+y+Le5zW0G2Kjos3Wb18jbZHQAhlyEfBVw0Y5/+pwvUTYXvzE6xgIUcuG9Z7X3N383Pacw9xR2lWgUIiC60IFrD5XFjlxG39vabOMMxZJMlFOg+ECDAnHnAAkmUnIChwGApKw2BWaZKK4+gIfEkoy/sxqc7iPud5QXKwQ8EIoAAy0WipBSXDGl+3k4wAGgcGkBBKE1XqAgR2B7trAB4AgTKEjZ7JZX21pMMB38QVAKIRYtLLW/1iOZL02WVT+n4QN+Ok0LkAsLuPf44dwMvEJb1pZy89p4gmTihBNOGN4TWSA3wgUWHVgLLYEvkGV5xer+GSPAkF2n/HJGeSR+46FQTJYef0466aRhkLSrb16CRKMcl/AUP4EZ44JP2gVgwgEy19jJDvBv9aSEI7oCC9cDNp5l+lCtzGbwuCXSahTKF5G1/bb6EPMChYokWtLrDD1ErNS5DTYsud+5nZSxAiF19sDCbxSqunVMsEWbkmJku+IIG3SvqIVSApiOggc6GMdlFQ6wGMbA/dVWeyU6W6DTglku43Jt/8yhTLZxlmj0XcmnSmONl4cCWIRKvq9sezMEZld9zIVmb5ckWcp2q/psnsDbZzkfisWqUnY8xBNyUYk6fvseTdugRn7w0W9VPBpzlYcdHd8SIL4IASUHta/ttlgzFH4H3ACMXAg9hJhyTxLOeKQ/f+OPOfRYAXNwfYVq1Sxoh+K7T1jMUAEyr7mSbjaP0WzLgkJZ2M7jFwoYcKcedb4Ct701acKESZUaIyjCN0nErkCknXmYwuJUAON6fWqDQmO0dgGL3zC3jG0CB9QIQfsrWlI1h6rvCG2FVO3G025LTlkGfxfP+Y5ASTQSSPmIYjvtBp6LFJysR95C1ZQVWEXjc+opAE90AKwt0bUMBqjF5oCnRwZWC1LhGN66F696opfcDXobO752dDxwLvwpzseLFCGAiq9ChsqmA+PyARVCZQzwp+Vb/bUcrS3X6rfw1t+tGrkfKDCIvJlCjIBh0SFEemZ8GSLGqf73S06h9fm1G6IaLKVoWa/nA2BkR3thEoUsKx5jKK+KNgICKNrxRsgIW9V42mYx2rvQoR8EyItQUWbC17KS/t1PoHP39e8fsGmHXZt1siTuR2yg4j7jMP+ea9hSVdakmn8nEwEuybJ5ojFGLhIU1rZd5Vv5jCo2zykoUEQ8QSNzREO0b8WHhcZHtOqgXnRxPfDGr6x15erGrA08K9RCc7LAwnv5XN2CMWgb33gIeBgwF2LiOZDWjt8ZC/SfLw2XJKTw5YfKDegrEDfOQAIgCkEtS8phtDFpM3k672vuKQSEm55T2B0ohJgEhgvZLrQKWdp+S6EoG4ZYViI8wMP9a70CjK2+nYtYiS2h8LffAcQ8+9rSjGsIWAmiFDYByI0uoWRc2q8Cs4KWVioq26bktZnVnRe3YIiaCeDlgNnqAvIUNsOSNNaAt2Uqf7eL8pyCAouO5vrIhcdj37XHBF/8w9/4k3uOxrn9eIEvreaQGTkb42wnZnTLI9Mu0CFjhZp+A0Ztr275NZnLS6iqEQ99ZxzkxfXkoDMbMnApV95eoaKDYYSmzoysOpcsZKUXCRAVSVVE5z2jFH+3DChECAPDaASk+JUEY9B8sw7LoipMsgeRJQmtKMhQQ/XcUEJFaGSntYnxkoQSgJYaxZDt+SewAKddmYg1T77E9Crs2iZsvMZJuI2LsAMV+YnO9qsU2jzbvdc+hvnmHeNlRYCCmgzvldFW7bdIoSnGDbC8V98feO3NkqT22u053wqOX53aDdzlcSzbCRXQ0TKtxLKl5Z78RJk7E0MxFKAXVqgDsdIjeez+FC5lxVe8xKsMSTtie9QgfhofoGmjXPsTCqXwA5i07Tr+RKdccqCQHOG9uQEFS5h5SwHPoj2H8i6742+02tQlSYOqTsEyoOx9xGspbD2hLw6yrGPJiQBQbCsFEjeWo7woeok8jEB8TLOsKAN99NFHj+Uq69advVghyaKVbr32Fy0Uezu3jVYfKvHG5/l5Cu7bk2pMFhc/AYdVH6tJViuAuuU/IZXlRjxjKPIEKDMAsNqgbgTvhZzuATiSkjyR/V0XsNX5W2VjHjGA4xF1RiMARPM8e3wOYOimRLwVJfpYjm3l+OOPXyUYlgQpWUKEGLmlewMKBgO5WQ5lqNabWRT1BpZ47JPgBUB+QqMvyUmVcoqiLG+pirMu7jq1ECbdeQltUNpb5Tmn9wPGrfzaqKJxb0HB3HlalFwizlKyZV78soSokpGH54XHHa/nHhbYic5kwQoOD6OTwMlAicf9Sd+tzt9Cxm0FCpW+WjdWGVaFGgGy9q2ugFVQxdj6NE8BorEa6hAUmSic4WUoRmk7bbsp96fQhLz7cwwb9b1e+LC3oND5B8IA3pySaN6foiJegPJxy8SUXriglkNdgRf+qgUhE46FZ93UNcyXUffEW9lo/nvz+1bnb5u5thUocF86G0GhiYISVoVFUfrKSih+4Sr6BxgIheIiS0EEjGtKgMScBIjFEZuW1d4bph/o9xLqRYICiy9JiGcqGSuHBuL2pgB0uwuFBzwD1t+18kDyCo9//ONH0k8xG34KKa1AWOLuKPcDnUd7O7+W2Ftp2vLhQwdS8BRUCrIeXEuxjCo3GfvWigmKLLNXG2qUSRMo5bQEjoCZNEFi5TqEYm8Je07vr47hnN6/6PsqFd/d6sPeegoEUrJVdaMKRA8FUpas+hGI27dSrQCrVsm4cFLiGdjLG5AJYwEmvA6vDopdNI3Wa3+r8xfgbztQaBmSx+BZkoBATXon9BBacabMvu/kH7wqUHEfDwKoKF+V6OxRZ/MDMfaX4Gx19xJdFukpSAbz5Agmq688GY9a4sXbDmzl4kogWwEQSkguCz8AFiNglcnORbzvsYD7O6bf6vzdluEDJcd0ym8vBAHiGhKaNu7IQnMpK2vu9Nwq6LyrVe+RZgjRcwYqsd5foNCy2f7qf6N+K8hZlKfQyVXCOaXOrL6lyh72WoFNJy130Cm+tUVZ2ABcyAXA7/yNKkw3muMif9/q/AWa285TsIohIZiwVP0YAvvddwCh6rSOVuuhIYClct4SWwRp0Ydm7omwbXX3ctHhg/njm9yC1SvLk0qPW7Gq0Aa/Kblwr6Kxjjbr3g6CdS+QUL9S5eKe8GIR12x1/u6X8GFe0ahOwUEn87rrNrbM3cgSgZjb5iCg0DFplc3mdrbPATiwOJWqVsikD94CsAAGneVXqao+eA8Erh2CBEruwVjFpvoUzxpDR3x1jyVSy52dE6ldgmruLJf7bYzqMWs8HO0bt5UTuRKlsJTB+MwVkHUS7yKEdd6meaBRR8jxqMTz3HHj39PwQVGZ8x078NR9lf9WCdozMoCNsKCCtcrO25RUqTCPoIrCjuRDWyCB39HZNXjU80Pan1BBkusrbEJ/ryo30TpZwLP6zPCQm57hUWGXdo3HtcZgvJ092fH1Hc6jfsJuS3PMGAmF8HfRZ3Dqh0ybq8/GxqNyiIxVnf1yHNt6oIAxJZpU9QGMXkpT20hD2XqACCXyNyvf6kEFTpjXk48RuycSVx5LaAgGQWzHpN+Ahxi0EuUKXjAaQbVpObOzDhoz0CCYaiI60sv4vMp858EYm+IeikYJja1aCQkzGXNnChAy/ZYnWXQdhfmhpfmjQzsSVQgmTHsDCuYavQE28CGY6IZvaK4fPPW91SPzl0syLjTqegrf2Z0Um3zgI5oJGRJwypycVIXYIbzojBf+dcgruQBmQkwKA5iAdpvtqmT1rh9hTiFKhols9LRqYOD+iul6ErpzHICkOVWEteicA9qhJ4NU7UbvLdfu9zLn+RHvlMcAbStVyaZ02We7BStxtvxIkHpIbDvlOp+f5YF4FNXhKhJVmGxJUgUjK91JvD2oFjFYKcQqxDCWHvyCaXYuSkzOlZyQOv6LJXTyElCyxOlvhTNKcgm7V7mKNuX4zmYceRFbvgkFIWQ9gAKBMvasq/fQfZGeQnmX+kA3gAA80b4twHuSU9iVpwAcVaOaG+VQTOYzhUFbPGkrdXtP2vXY0XsK1gCIk5rULZABZyLgD68GH9vJmgVHd0qvjXbi+sy44KMCKX9LauZNkKG2xlvl4kEAcfQAPmoieuhxW+czPBRLu4E9YMA/fVhZ4SUrtiu5jZ55yYvkb3tnHDDj5CugR+7Ug5Bb9NhvoIAA80NWKolkPSkvZeFiKku2rMRiYVJuWTsNEZnQ+FvxkmO2ZJyhNxdeLYOy2Hvc4x7jqLYsTTsUCak2CRYhJDyEMpeSALECTtrpwMt2XXavpTP38GyMXybc3wqpCIs+ew5BDK8s198BR0eHCR/065QgTEwBFyks87bbaaiMnNJZ7lP7kUu9N54C0GelFB/hk6Iz/CWQrLU+0B7AElh8bZeq6kTA4R5KZi+EJWhLluoRnOjUuRfAHQjkFbbDlMdptaJQ1PftvDRvY/Deszzw2gnPlJv3gLd4iidKefXncwVw6BhvO426I+M7ZxMQUkj3zzdLLfp492SNnAFB+kdHAJ0VvB4nsN9AAcMMCmMxhqBRAIdUIJbzCTHcqTyKUlgslkFdQcdnIb6DVKGb+gMlzn5TxESpWG1WBcrbkWbPAyvleC312YQPShJIwoZ5iqAcswbJneGobfE9V54Vx1DWgbWgMARW2873ozjmcuyxx451dQKmYhIoUCxAx+t53eteN7wDwulEKePmcTjtRx+8EoBjTb7NVsWai3YvUx68QAf0B1JOlaJIPSTnnHoK2rB/QY0IugEEYM5rUMFIHvCPkUB7HgBekgd7ISipAjXyg+dce9c4S5N3SXnL1ZAlVrnVKe05Z5En5gg1BoQ1J182n+EJhXcykvCQpwcwnM7EqgN99HHSFx67vxO2FMaREzKBR7wkpzI5xUtZvZCTVwxYyKBrzVP7Xq3qLJq/+Mpz5kWr5TBGc+NBZ3D3CygQjLmn0CAIAoKpP1CpWCLwqKOOGsqvMIWCU2q/O8LLvZhenMaa8DQoGQuCCZAQ0wi4NjDU2YsAAVMpYllpaMkrAAKsCkFCOMIWiAlPXGffhDE7l9EpSQqloLATggk7hTcX752yU76DoLgucBAfc315R7wb/SrR9Zof8rpZ3oJ9IpSHRaYcNhl14M3eego2NxFCPKS05kkxHcGHN1x4PLcRCvD7XNmyz4Cfx6E69WpXu9qw7MJM/MULlh0IMyJkiJtfUlsSmIL25HJeJNpTCF4ekNA+GVADA4Qc2koe7OfxMmbFbzw5+28AEiVjCIA3EDNO+Qq0IhMAn/Hx2RiExuY9L5Yjy4veGm/8+kEvOkM3VH+aI57st/Ch5aWUzCA7LIUVxUDKyyvgxhkwRjvYk0WmjLKl3HPeAIFlbaGuWngTbXOMAhj3O6NAG0pnIaR2KBuhavusv4EHgaPEBIPlcIAqKyY5RcD0gfF+43Y5LMM/lsQSmrP+5AvcB4UJIE+EwLAy/uYCs2TAi3JolwJyJ505iDn6yYqUhF10ohFo8aBYOMledGQReVB++3aWJHeVU0BTriuvDYBTJp4RbwF/gQNF4S0yAEBb3wADbQCUTVEstmt4CU5vFhoCDhui8BcQUzyrJngMaG2kkvsB8PjL6+ORtdNWyAIEHv7wh4/wxW8MALBRXk3WyK6+8A4YoFOJR7KgKM74bd4CPoUQQAUo+Bt4kH0eSLsmWz5fNCiYOz3pnBFyhabo3ircfvMUCh+4VF6BAk8BYTHWpiYuN+FgQSgEywEAZKV9R3C9xHasN0Jzy6ExACA0qttMmtXmXYjdKB4rwdXktSCIeJEyWj3QVqcAeacokpmEBYgABULN7SMY1Ut0/h8Xze/AglBignu0A1zkSixLURK/Y5REGcFxirBrWKLN3mo7t1bmBoCBL+BFG6+98RTMi/vPS6KgypjxBS30jb6SXnJFLBlaUCS84nLzEvPI8tAYDtY97wDt5UOMmbI5/p3VRkvyBJTNjczIPQEbSg/MOx2LLPBohEtADJ+Mr+PZeJb4y0PkmeqTFyBXwCD0PAhgBJgAD9DQp3nwNswTLRkj49H2ZrzIoYQ8/SGvvGmARweqA9lS5ykQPMwry+1zG14IDBebULDmXD3M9zv3rINZ3MuStE5N0VgtMb/7CAJQwYySiohTdpgwEkTg0OPRtcdqASHE0zcBYv2NWShCkIyjuLzDWACGsQMGbRpP6+Z+0682fc+VFctDdPkHINJS5WacBUDw/aueIIFt2/u3s/qwq/MUShBX09H5legDiHlUVSKyuPI3FE2s3slHVTXy1IRfwNpveGV8Qh+5CQBE6TpEFa/NraVj9Ox5EJ2G1RmgQBp/8QQveEytbFUnkUV1r7H7nXx2dJu5+a5lyp5gJj8GFHhLufMdwrJZuzjJFf7g6/9r725WJCm+Po47V+NSwbWiaxHdieBduBZvQBRcuFNhQEEGR3EnXoG4cOHeW5mHT/F8h6Doruj/ZGdndncWNNVVlS+Rcc75xXkPc9jeqNF/V6BQFMJgizbUiQlx6riMMPXXi4lNMEIjei3UXY8wBzZ5pGkcZW91zTr6EtQAw/GFxvzvesXri7nnJ8j5lpe+pKbOcR3/m/CAa2xqEUMECtTm/Alb+BVGcEALn8cy5EBv3GB2VhDVyuha/k8TMnd1ROq3nI3o41g+Hlqa3x3L3Gqn6ELJQIcwOxbwt/LhJ/NvNa9920ifHHwl9+RjSoMtvybalXnpc+n0VmAAUGjRb8bjPS0DjzKRLS40phEU7kJLaJHJHC2l2fOWiHfn5kOMhaGu6ryECB1T6aZJr/lDQtXuyBDd/xCdoCM8xkEIK3cNXDErNLR6YAomwZjnjXhloFlZMGGt4BLgQlUEI8HPzs4WNPb6PKZqe6aiK628qemBYGPxrLz9xshLXzadz8XM12Se4ubG15j6332XgsKY+5/24Z74wTyN/RRqtpozztyVuuw7QFAPjFLX0QwtCim6h//d12oe8J4DcyZsPpvySbw719j8oUPA5l6uE78EJMaZNoNmzVn1OMwHWY2iD5lid6UhpJG4b/esZqhcmN2BQhNatdZ5iAZhgIAVgneaU9E5fAhyEYBEeysQMExW81eOLE5H1xQnL2btWiZGCBKQlKbaitKKWKVeDFX9RKo2IUrFb/wJVoJs/B2f085731lpqHUYiK+hcu4YzvXWfCW0zftV7zf1KVxlPiQgaWlphM2F5yf4AEGCTW3x0UujFZ/roF1zXUJJveew5JxmgokK4AmmCPUYeAhxA360QcNRw/Nd4d80iAQIfwXiJUEl9DnJcwgHHHiv3AXvwKE8BZoVs0i4vGs3lrUdjbUIcF+8avw1lLWwGuPuQCF7fDQjRqL43gRzSIo1i3VzIppozivvhRirM+BcYpeKc3MKmgQMRH0T1uIUkrfAqcbxmV2FQBGp/xPKbFDvmREYrTi+/0dgwDQ+x1wJdkLXfTI1/I5ImUI+d+01QeG6aze+tLeb5Clc6tHYfKaFBA6uX7IYBySacPSJFAhLMyXKDqxHo3NEGkQNLAy86ZyQRZpEhYCG6+q8lck2grrnjmYjyKftAbEiM4RpBLXmbFTFyw40RgtTdTSBX3Ua1fiYj1KQ16Rvi+6osY2mRDy6K59CqllC1IBTMRGEw46zUJiQoLPPhBgJNiYzuZA6wbXCUyGFoSTB8B3wLFt5aA881zYTFfFgeiBYTN+qmL8iwIiZvWfSjPbyqH6b6JiqlXJkyK7R+RiqFScHms/GtbaHetRERkCMUUuyeVVQyKFbIZFnTmV37+bH73I5+Fc8t9CucKPfcxiWmt5qbVs/SVbSpkUpaJLCh8KKeENegGgTUDF+zzcKR6Zg5t+oUYyCM4KA/xN0z1E6ezuP9V10c23A5llHjSc/ydrO5Pw2nm0cq+fINNqdpmCwBp6TcfQlEAx+Ax5eoR6aAlDg+ReXlubqgTwc1dM7RqilulCmLEFea/FxK4s/8WseYVpHDVtC1NTCJqrvs8nSBvIVpO6OvoMR+UcfxGirx6CtFpA630Xmyl3UPlwFCiNAt3K+Kig0X6M/Ia0wwbO68jd9/fXXJ6HmB5IMJtwsfNaiICdEqjRfEZMPyPMVCf8Jtwll23CYpoDe2v9LRCMMVcKO2lt+pEB+dDLmXCa0aTVpO40/La9VdjRHnJPjEY+4V/U82fKOX9t8yLfl+UvlH6MpOZR3pSlgjFCcmRDSRsScTpq2shuZAJw28hEwgVXFak+TwDxWCastOzNNAUjIV6AtUDflEkhsshrRInLApGY2kamHBN5vCUhqp88YLmZJmEfnY57ozIiRCVzfilIb7UKzPseoa/sUzn0450zq9yU+hcyP0bzKadu1zSGnoGQkiUO1z5OIhnaFmyUByUHwOyAB8PwHkr5kI9IOJEVJDpNnIEFM7sJoxxdVML9Fmnrm0YxM0wsQ0DrQiB/yNyT8gIrpUKl1zkr8ndABCPStvDrf0VomRD6unKfJWw7VHM27AoVx9ayunZpI/SfcBJ6wI7LkF6uJlE0JT1YTDIVxHFN8ulwHNilm4VjkuJJdiGEk53AySouWR9BKYsIIP+KaLISD7sYCsBAzb3cazdpe5BkonNuKt81cS0Ghakirv2eJrs0bWqOBbECp6MAeQMhalOxTIxzClL/FmNo1mtbAR2SXajuKK/hxHnDg2AMiaX8EIfU/cMjhSDiFst2jkuq6gt/2nI7X25q+aWvoEYBv3ri16AJCl+XlHbEJK2CwmktGkgVnpS8zDYMhIBNDjBoD1pQ14S0shOgxKNPB9WSnZctjOgwS82X35kAqVOh4hPS7Y4HGmq/zlfz8Xmurn0tBYXTGmX9C7r0VyvWtrEw8Ph7mAZXfMUC+3ptVVHp+C4CkJ8fUcq2QteOAimxFaefMizb/aeenmskAAdcwRtfJ14Pm+YDWXsm3pu8uQaHS5vIOMALEwuzZ1HXVQVyEJJjUbseWbyACARCcI5mFGgdYAoW0D8THFIjuHRPl6GujU/cv865QE6ByvxKrfL4Lm3BNwLnJtZeCQuZRqnX1AOgSbQBuqntqLboQyBx4NWcpNbdOTiUxOd7/VrxKnX3X+M8jD/mIcsT53fmZFUUe1tbEbkKDtY8ZzWTzsrmm0I7SkL+9HRESw8RQbeaJaG1EWy8CPgUaQ511YjoTSeiFpeQieFirhpwGAELDsNI7xjmYA3CM/RxdoxBSLd1Gh9VM9bsNYm69kiwFBQJfT0VzmePO3LTbE6BHW2BcXL0FIeEsuuR3Y0I3AFJlrYUAGNSXkU/JNf3lq8p8yH42tvgnkMBHxjjmoNwGHa+7xtb03aWmgOjZbnmoMUShOYwiEYUJUVUhwUW8PPgluETYPPolITmfb4L2UG0DIQdIjqn3nyiHMfg+raQxmbzREZUTqVDbWowzA561V7KloEAgRxOnbDq0RIuccOZxbFyChkwNgos+gMNclJyWKVL6M3r6jkZSRKsdr9ETHQFLTtNWx9Lg8ZMFpDZwpdi735qvrem7S1Ag0EKMQo2pjnWH4T1GtNKXCaIog5WeoHNQYYTyEtiRXhqdsDsLK9JCHJ/j0n0IvYQoDsdUUAKWZlB+e70SnRPD5T0uXv2QmWYpKFjZFR3JDykkhr5Cjcrhx/6YFgcO5XozOj4fDqGXsIRXOI/rYxDo0BjQF4j4TvISGos+4KGqXtGsVHh0TygJf4lSxtEu5jV7XYvGByhcseu0SUEw3mbZZ9RAWkEdm2uMWmdl0Qe9CQh6rbsAAJTXPAJxJcF4URP9hrHq7Gxl8VmVHo0D0dXKS5+uMMpvKix9No4KdOrW7HMr01rM0nVnjsSZ+rl0fEtBgZACU5EifRoAuVRkmagAg1ZI1Qf2aG+rOM5kSUdW7SICFg8grtpQDQF6lkYsvbn2cQA7xyUgdx4tJB+U++ER85rGGT0tPsaEb6p0pDGs+dqavrvUFBAAkTCCVNX61v3xxx8nxhFSIsgSlwg7QKjbkhVAlqPVA5BUdIWR5cQ7VzILhpMBqZ2XZCa15BhJPb7VSiKUSISWa/VatMLQSKTcSoLxEgfHJLQL7bzye6zJNEVBrrtHdvJaY1gKCsZHgGlvogEAgd1vXgE2oVf2rAdGO4l/8MEHp7oFACIpSShZfwXCK/Qo0uSzJDS0wx/+pynSIDRDsdBIe37nnXdOPRpErDRpsZDIV3GORDdha7kOkthkUDrOePHaXfRQ3Jq+uwSFwkESiTCMFGRaAHWTH0BHJsTCSDLX/C9pyW+SmYQppbdKfQYc8u8RXe26PAS1D1Z7TGAV0MgFOkuG0nhFoxMAYRWT+IRRJcVoiiL+rWFGW9tb8RRYybQDTIBopv4tFVZjNn5ONO9WXsJBPTYHQApDA7CKfjyr1bFsyyVjWAoKxkID0CsiAGAWCj/WOUuPROO12tP2JJ3R3GgK5hsvKJpCYyAhXyWQV2Fq8fCbbkcApQ2H1bnoy8C5rNhM7wvz6frREU+hL3OG5qCDktZr+AEvrh1ypu3Qco3f85rv9i/BpyJi2tXpKYL2pfTn+F5C287dXfSB/ccWRAy57Iim/pwwQ2wYnBn1AAAdm0lEQVSNN+UVMB+sEASftoCIhFqDDcLvXREUVdSKpAzZyl/H5TYdJfCEin1Ky3CsFGkrv7ZfnFOSm4AUUwXASLEmlDQRqdM0GufV2PM2CHPdNWgjAFGxUD0FraC0I3PgZTVs34PSqvPeLzUvloJCzWVkkUpOEgGS0kyDK3OR2t5+HehIEyMIktSAgDoVwO1PWzOmJr5wHmHnIJa4BFjQx7muR1OgAVo8AL4cCDSkMciCBC5S3ZkctEl84Dv3w0eAbG1HY5mTNCCVlDQV4yGowEFtB+CyYOYkzblck6Gl/Lc7UOjhrfbUPszMbtRjke2v0IX6SIi10IKmVkarDUeSVQRgaJFFcDEdgrf1PCZyXC3F/cbmlCpNZXUdoIO5rAwYS7qtyjvMi1GYIghhjATQtTREsfKtzTQIbkUlRJ6xhqqETZ2+VVBBUG3LzRlgrcHL1qBACK1u6KTvorkjgDpo8d1Q4f2PBlb1IgUSmGg/Ndxl5pWoBLBpCoTfHHhePMAMoPlZVWlVUtnRSx9O3zEDzRNtkyYAVCws5ggQ0SKZJRYpwFOuylKhu3R+uRpAgaanWezY3BVQ0PjMY+nVY0HebZiPuwOFkpfKXPTeZqPUJ6shJsJABMIktLtTnmGmAHUzB1OVeFQsTkSTicEICtMEE2BO16k230pLg0AkzGI1xmg5M4ELPwcNhA3sWtRW5635qrEH21eZN60B4wNNYEWjAmCeg6rpvZZzt6FiLtUUylQdzSz0rVGqFdnLXJpzYyfQ6FQSmZoHWqPfmSNMvMwmZhSewSuFlPEU+tKmim7gFX94Q2GVY4GM84GJ8TA5leWb4zIpa8m+Fo0zr2g6XvxdwCEABPLmEB9Wm5MTvQrUpWPbHSiw4whhewmOYSIEbSt6D559h1AEAAhQ9+uq5FwThanqyVjPgxp0uIZz3M93JrzQF+Yqw811Kkxyb0ziMzXOOe6BsdbWFNoRS+2GMdGc2LxAgqr5/fffnwARYY2/5B7PRDCWriRLQaEIEHq0pbx5JPyluJcpao7TctDS2PONeBbnlQzlepl0+MSxeKWIhs+lK1d4VnQpISo6IaoEnCwg/ETAFMiY77Xpa04AIBPV/Wor3xgLuXuGqhvxqD+0MYdLX7sDBYxAOGuxRjWiGVgVvKomK3GFUAMBKieB4TyqrTa/gYktu82qEOP53/G19aq60XXHVNfq22PGEp7KovNuvDHk2vXwxfaZOp6Vt13DGCE7TrZ6DcQklfMWhpuFvGYMtRQUjKOOWObKKmx1BqgEAk3qjFyiGOGnNjs3kxGI0yaiIUEeG/eib0JD+P1W78TqVupzUTk30LD64j3nO77y5jZ/ZUKs+arvAvr6n6aQH6b7VrCXBlwxV3k4S8e3S1CAzlTCuh57yJwtGAmjW9152zEOQnII0TD0VCAYGKxEo8wKgOIFGFzfNQFGySwlxpRVZ9L9VgFNGZGIYuKszBjIZ8cCh7W90zXp4K1n79ppiQNNhyIC5pmNt7E3nmo0loLWUlAgoOhLoI3XePzRatDR/+OuSUw2KyenoggQPw4hydQz53WkSqA4FZl+NeQ15vYARX9jKDJTjUOfW2SiuXu5Lj6L15YK3aXzjQc/CZvSeDhDz4HI85SyjQ/Lpg3clo5vd6BgUjCCHICq1+QXcPJxoOnEg1AmjbefUFoxeaY5IGkUPMjeOZYwmVAihrLKABpOq6odTSgBqhcixkwFM/E0iSr0ap6KaP6AEnAq575OxkuJcul8z+6efBqiKZi9BKxq8wEeYXGsufR9K/DSlW4pKDgfsMkhMG4qPhWZH0gSEm2Hjc9vINPR3ANfQgsQ0FwGIz8KYEQHfh2t+AgRM4KzmCbh2gS67EbzmuC4nmv7nRA4xrzVPg0fVHkJgPCTeTena77qt8FHhIY0wFKyMx1q0mKMo8lwW014dgcK2ZxCVhKLEEpkADGFBGXCMQvkC7D5CLiyZ+YDD7KkFceZIExXqrSJlE/QBqT5Dtwv7+6WPRBvymhbJ7csBQX0MOdChex22g5AkBsgJCyqYrs69AVkVUECfCAI8IWqzQNtw++Y2LESojhfx+5OmYzGfVtCc1NavcpxW9PXmHcHCgZkYoT4xKQ12ZDOKjYrww1QMAd42oXfILit16wKklWo00KZtAxNNfzO3hTi0rmnbbNSp61aaQaZDa9CzLs6Z+YTWBpynD3HUlAw1wSZgxQ9AL5dojhshQDljaCXcGuNPggzTZDfQURAXgoNCACIQFnJaY4WEpqC67tPjsmeKWafPeOWv29N312CQmqdeLQ/vgJMUuiR0xEDSS5qy2+aAoDwGXhgFsAivwE4MD/kNZR8Qu2nJmISDDe2plo7I3Epw83Gt/cqSXREG8KNvhKwaHlowplIaxB2ZupRn2uUw5xg5wsXylCkGTiPEFkM/C63gE+AL4EpUQ+O/EjuuzT6spR+s/O3pu8uQYGXN0ceBmBfcgZijrLcSvDwHadVpc5WE99JesEQKuxoBhKRtHmXQ4DxMA1Q8KoRa46mg2kus+1STSF13kqfw5ddz8fDbEjg86yjY2XUHMlMRiBP6KUCEyJ8wqSkJYhkcGCiL4BEz1qsuebape0zoZ/9foDCFVWSiGlFyOtLyKn1OYMQuk1aMGifc7g1qRXXcDRyAGII1/I552Lqpev4uw/q5cw8mKmfM6ac/X4boEDzE0ZGo6oTA4HuLyxZ41t04fdB9/JL/E5b8GdRwC9tgIvGAUCg4Lr5M2bPuOXvW9N3l5oCZx9VkjlAjUzFrztOrdPZjTEKs6F+e46r4Wtx5piwLtGFlhAgIXKf+8A0WzKsey8FhSIlNU1Bz0wEK7zv0a1mO2hC2/Nd6n9dlOvtSPtTy9C2f0U4auOHJ8o/WRqS3Xr+7+L+u3M0ltnWwzMnMJIVgQZBk7DyJ8BpFB6kNM8yEctBcC1qpc9pB47PlxAwzFD6Lggyu8dsjHvXFDwfWpY16nnKFPV/ey/6PzMyQS6fxG+1egcQtc6jLdaBC51jbufdl+jD1vTdpaZA4Hmgpep6cR6VlIPIZaZhilp5YQqaBUbgP8Bk4ryqKx3HwSjPQQGMa/jL9GgSfFc7t5lgbvn71jbnUk3B6v3tt9++TFHWpwBYAwpRBIsCeo6Ncgk1/xCNQDKPOeBY5ISWjyBPgX9BDkP1DGkL0TmNc+08g6W8sTV9dwkKhF5MWrmq4h5hKNoB9bHiF63alMpSKwGGl01DmBsq79QF2BEIs3BOckyqnhPywnwmHqDU3TdfA00Eg1ptMkHq5it0pleDuvuyKkuHdn0mzFgMlc3rWMU1VN/2oVjKOGuen1ASUPMJYKtBGNV4z16G5/+yFT36CiGr1xBeVrxFkEtpNveSziQy+c6cope0X/tJylEACCoblUHTAI2Vk1ljHosJXrFIiFIZoxwI+SmujV8qSfY8QKLkICFvfzSOvrNIeeGH/FQWD/SlpfieZoq+hdPXpM/s2lWdoh0aeY2OVmOtMK5CK0BtXvK97c58IKiIp2+BeLQH4FkGEJhHLrhwlgIgRKINKJkts1ACixp8oS7NM/IVYDIZckBB7wOhTZVosuO8xLn1RfCdiIdzmS5KZkU45EX4TkxdToS0W95u46OFaB0n25Lgy0LjHceItZUvc26mHs6Ivvbv5hENRGiUjFuJ5XuYawCdALwqKJh/TKjNmj4G7oO+hF50Qe8KSWY0CGXOQECIGZgQfvkrIhBAQSIbxm6f0BrLOE+eg4VDZELGK37Ro0OEQ7Wk5ivOUwXp2QCMZj00UxmRtBDz4Fxj87sFhsZSfY3EufYYMbba0K9No0vXt4iRn6Jrng3PivaYK93GMr3wpu+AI4CzuAVuu9oMJqazo49OOZimJhgEEUNYee0xSIDlIlgVCCKhlxRjRadOioOX34DRgAkNAsPUyqsVHeBgMtoEJiXEPOTyISrNpoG4vt4M8iEgMKco5pKqS4ORTCNubsLHqEaFWEvTjNdmOM/tz7wAW6aXecRUFVXV3ONVNIUqV80zcJbRKF1ZkpnryScB2ISYRmDO0ddOXughE9IxFgkC3YvGIVQJdPCQ7FbFYtLBlbajlWxJ57gezYIpwuTIaS0T1vUlVRXVwCu0Efxjq0GA4Ds0b/MYgOV1F417Z/T37MDby6KGbp7b4qdBS31EgJn5Lt2/zN78OLsChfL3NdtQBow4mp3osCQvnsBbgRFJLrx6CAVB1H6g8Omnn56OIchWfkwI4Qm8NFrX0UhDyqyYuBXBPaXPIr4SbExEhTVB2oFREWVEYlD3hbZWHSBl1XEtTT9oDEAoUMg+zIHW5iQzwm75OxOKBmSOCBAtQZEZEyszYgkoUNcxoxXfdm6AhxZHC7PS0xS80xIJNdrLanUeU4L5ppcmE9PKblyiDmgNvGh5fBbABk30vPC7/zE6GtEm68uIngCEeQicAAKAoaFIikNfC4hsSQuR1RTwmyN0BaBtX9ceIFvSbyw1J/CeQe0PufAZEBs7WpbdW/dyclCPhl2BAkFix0Jt/gHCbp9I5gAkptqxSQk0QaUeIrzvCa9zZLopJy52Tc2jORBkDFYkwmrO/LACYhTIz/dAjUVwjkmaiImSi28Fw1yy7oxF7j5TwvnMC0U5Vh2MjrH9DtSAi0lOPduSaWb3Nn6amJWcXeo5CW/5HUvNB4zIZtctiWlmXoA1O59JQvWnotdtm53LJ2Clt9LR9vgwgDXg9z0AANC6aNEk0YxvAUAAD+af1Z0mYbV3T3Tz2XnujWYVGqEzXohuFhXAhb4ABmiYD05t17Ey52NYO6N0Rr/8AoXmvZMf/AlEPaf6IN97lnxnFVsBld35FKoVL05tgAau6QQBI+DsJA9lxdJaC9JRA6nybSRDRcTcfnMOwtdoxT2gu5oKrdz8YTTXoA1gSIxEKKixVMbAyLiADY3DddvByLH8ElYzDAVUgE5l3PVK3JppZkxlvBqnUjmrYrQy11TGMy3RFGK4emSkOdBM/EbNxdht5AvczSnaN6+VSxNoNK/dWjYyATXPtD7PU/Mb16ER1I6PgAAN1yXgtAIvtMRvrm0RqOU/fwRN0IJkfPVPbA/RwuKzOV7z95rBkA/8z2zF68xdLevwMr5t+0O/J0vMjQrMdqcpECgqG0Yk1FCMQGPSWm1xptTRtko6BAMYhBo4mKASXEpYogW4VpPi4Z1fTQWCuX9MSwB8NsGYqt2lIqwJL5RZth2V0iqGMf0PhMq/yP5ckzGWXDuvu7FrcCo9nGpOy6kfxRJQMB+Yj7bAZ0CwOMXykNMK8oQbC02xgjVzH13Rr2gIIXfdWvlZxWlvOTWLOuCdtqTDS+1I5Vh0MY58TGW4+q0U+Exbz+/egAFw4AH8WmLdkvlfeq5npkl7lvwrtCNA65k4cM255x8XYHNOVsbMXs/jWTffSxIzEi7qPsT2YIiKKX1fmMX/mAEz+cMsVLk8qzl+MJaHp8rTFjCjz/VPcJxrOw+ztrKbJGMpbOW46iJKEHINgOJYjhv/t6WZsXlh1kp289gvJfya5xOsWpybL5+Zc565SMoSUCj8a26zfwlrQFDLtPZ0dO+S1nJsYlLMi1Y5yvCJc9Iw0XjcT7ScFrQADATdAuF8dMM79YEsTyKfkGfnfBbixA/AhElhUXIP16hvxdrJYzPamy/z6s+Y8b0FislsMSwMT+D9n0+mhDLzd+fmQ23CCAvmg7AmMgSfPfTx+7ozMGPqAAH9rOAEFh39LzqQnVpOCSbjXxlbm637BI/76jPz9CbJUYATUAJOCyXTGt0BTKUB+KTomhn3u3sDSw2SRAx9Pi3aP//88wuILURXwlGVcVZaSNaKy+azEqVeQ+EjN33/TJ3DFK1qGgrcgUKb+Xpvs5rCsACjlmn7f8r7OcJZHswM9IFGJlPyS5so78aspJ3fGiiMSEatyaFhpWmb8PtJjocx6hlTVY6c7em9BKIiLWYC0KMnAMlPg9kO0F+XT26iCVwaQYIeH1QjhLa1qrt1UKi7EeYaG6RirCro1p224+qXZmDGVBgCrSowovWlJnZu5co0xNTM8byDAvudATTMsQvQoyV6jz61WzUfqo4LgdzI6lFV20y92e90PoyRzTQFwD2WMSfstIAa21aynKlQg9GqWB/GTD3Mp7iKvkB/pO+tawqpmxUTtUEmdbMV52FO98N4qsJUmQ+Vn3u6tIYqTmtCWrFTnu2HMRP7fIqZpncTR6RjRvrSDKNvmsOtago5oqwq7JRSZ30+nFD7ZLRxVPkUEvyReYBA4B5jYZ7MiM7Z/1Pe3xHONL2ZJs50APy1F8jHkEYYDW8VFIqBFu+tTNlnXurslvtLlvs98hnToF80BOKYBhB4zzwYu2ObjZyLOR3v9wzte/Q30QQuPUFt7LxH33YlK9r0P5sPv/766wuJINJVSySifsQY3WDfU3uM7j7PwDmwjateJs1Wzzeu5GNIr+9ne0FuvWiOcxs4mMu+l7Oi1Ly+I/Icnvz4448vrBy2MSv5wYO0W272yVZEOe77sGdgrEyNUV8m0Tx5cvJbbfkaQSkgGIFi1m166/GPAND8jkChmA0oaHgj6/g090+fPn1BTVSuWeiKxtCL7+B4HTOw5gyMKzCGrRjN/6XJr3n/S9fOFu+Ycx/AbNGc+QzWfq5zLexcc1BUpmeJUm3uAArCk99///0FP4E6eC8PKWtRdpvKRZlvx+uYgbuYgasEaCZ0a49r1GRe5V5bmw8zTUXNEllXaq6eha/wlOZMG/jwww9PgGASoAVA0DGnSrtXmZDjnGMGZjPQjl9pB44fsy9nTD27/tq/zzSBrX0i55rC+XgBAZkn/7Wne/LDDz+8cKAOL0ABIHgQxKJBHJrC2mz1uK+P9wqDjnkvMe/WEZDzsOxVTtGZ+bElhQPVc4fpaA5xLmoz8DKc+fz58xdUBo0xfak4ipNRTkJ9+7d8qOPeD3sG0k6p2SVN5SX3vnUuzHn5/bmzbgZas+Sktal7DgrnzlJ+BJaCcdab48mzZ89e6C2gShIQlL5c9dXW6s/ak3Zcf9sZqKaGmYo5E7JKe2fe/bVHH/+PYDBqC8rML722lp8RFM4BweeKGquNOWlr56XTZbiNSRFrT/xx/cc7A+3zoHmvVmo01ZqmlGh1aXY0bgEcVGCNSsbEKyCDn21Rp0GLxU9nKLYzr7tjZ47MoiHJA6GxutqWQHmyfpg1+B13xKJtl0aen2TMEygXwzGuZ/xCgl7VM7iu+1msNYURAKhJTbuweb72uPD8ZaOONUuX5k8jZI2LNaBxzVNa9AEKj1cg9/DkCYRWchqzelV0R9hnLfYJVz6wCruAie8KrWt3pncEoQIMBFCLegI3a7dXSN71UrEJHBAjRLpaXwKFc/MhLSP7vY7MrmG8NCWNcAi433xvPjQ1qpdl/U4aTyUITC3nej5t59xrFv346aefXnv77bdPjXNfFjkeoLAH0Xi8YyBYhEyT1Y8++ugkqBVx1ZPw0uyUaEeI2ueifox1PiZoHOYEpmxd74Rsti1djVEJonMIGqHTzl5/UW3qL4HCpTR0v1XubBzVK5iPzCYt52g5tBD30dTWcxi7dnP5AAGI8QCWqmLbCfzS/HmOd99999Tc9qWj8QCFxyuQe3hyIECIJdBoxY4xCXr9OsZEuqvGS5io1lZNwsTGrxNRAm8ldYwGqATP5/p7zkKeAZNxBSi+s8cJ4bSP6sx8uKr2oBBsAAjUlBs41v8BhLlxX3PStotME2Ooctlv9TBtWz1AwiSYpRTYg8UmOzbv8TpFWw5Q2INoPN4xWAExdKCQ/d3+iTP1vu392N1eVket+3UJk8JrkxoC5n8b5fz555+nrQFsE0AgZ9GDNJAKy1wL+NiiT7s6m+HMzIcRFMYydcJOwG2XB2BsU2C7O+FBfRat/p6/bRD4MDR3dZ5jpAwYA9PIi2nErJFe4J51yb7EXTbiAQo2ZsrZeIDC45XHXTx5beBsFGTfUczcSu+3mXpvtaxtHAG3vZy9RZgi1GnXtXWgFdEGK/Ujbdfs2fXzCbR1QCv206dPT2Bg491LoEDQ0gryAXhGYODPJkoSiN5///3T3iQ6onP85Yistb1nAUYAwLstDICGP+BQirKdsZ49e3YyIThTc15eR2z7VtpEya5p7ul+ByjsQjQe7yAIiNXOJi9tHlyWI1CYORoxMYG1KhIQgGCjGrugczB+8803py3vmCZffvnla5988slp9SVUTI2ZpnASkv9fdTM1jNfOZQDGPqUzn0K+iEABtY2X4BJgWoEqxZysxu857KTFAQjQOBppOMoRPIcmyvwZgMWeqO5h1zSOQzur0S5uEg6lKdiGDygA1wMUHq8s7ubJMS7hEn2wPVqOuXp1zIS25Burp5bmtiT87bffTvuW/v3336cKQFsTSs5j/9Mg+BQ4HtndM02hUKQJKzwJBGzYYv8Le57OzIdyLkrQcq02Brb/J0H87LPPTuPxDDY2IvjqEmgNtlU0P/bNtPuVZ6FZCIsyF9oUxj4RgAcgtq/JLM/DjmoHKOxGHI6BJGicfra+ExrD1FZ8L8I0C6k5pg1V/G/fUFvIff755ye1+osvvjiBAnCgLbiPTWp59QnOrB+CcZS7A0Acb7zffffd6d3WbuUEWK1rp28swGLMyBzzFAI/4OI4vgkbwNiF66+//jqVMjMtXFt40Y7ujrHhD43ARs1MJQAAIDgV7eHAN2NszBbPN8sIFX147733Trkc5voU1j0cjYdwbjkDmJdw2WTWilVYjIoOIDj6Lr2o9FRlwiIxiYPx+fPnJ+Fkh/MnEFAbE+sZQnsghDa/pZ6796VX3YsCKe+cgoTZGGkfdTn3WztCA48A4jw1egxTElzjBTzOsbEuYPM8TIQ33njjtddff/20c7Z72kPTs3CoAjnneCbCLKwoQvHxxx+fgJL/gTZz6UVTsVclUHjp8zhAYUuROO5tBoTirOAcgXnkS2CamQ9juI73noC1WTFQ4FWXFEVAaCBCkwSJA47ZMltJW/2BT9mPzuNotIrbVZtA0iIcQxhdv92gR6E8BwfPTqsRGWEycDhyFLLv7aYu2gCUZGAyd2gSchMcTwuSAQrwmBmuzXwAcuYBaABJY730SlMQksy8OTSFQy43nQFRAE4/UQKhMYJVivC4Sl8aJEEgOP6ECp3nj7/Bqs5BZxX1fwJMwEsjvnRtwkYTMC7X9E7QrNpWZWZKzs4KCstp8P11eRYBBKei63pmxxN+K3caCXABZObJSg5ACbvPBD9BBgTOdyzAA043yQhlajAfzM9hPmwqCsfNm4ESif7555+To5FwVENQw9lLsxXjV8BXtKJdx51bk+F6hWB+6jpbfdaDtHYCCXrCSphcl0+hWoXRZMjXMauSbPdoIEFrGXMPRCX4PlwD8AEDvxdtaffs6iYK5bqWY/JrXJo/IcnMhwMUDrncxQwAAMJFU3jzzTdfJutg0EKTlwZKEAk2MLDyy1os96EqQMcUFvQdtZxpAZByal53j8yHIg+lJotw0BpsFZ/2UaZhtQlX7aB23tegcnFmBk2HZiG/QG2G33xPK2gnb3NizJ03lp6faz6j0/a65+OoBArMh5rbHObDLkTjcQ+Csy21/7///nvpXMyrPwMFgmPFJYSEh8Cwrzkd+RJK/KGKE1wrrFW5YqRL1y/5KN8FUKCes+Pd46uvvnpZXeg5hAyNAWCcR05yona/PtNYAJnxykcotTkgK98AiHkW93V9GoJnEXmoojSTpc8zn4xcDqDAfEjbOkDhccvj5k9fP4VffvnlZDakMhMI3v1ZaTMBEklgLhCAnGsYnPYAMKy+rk1YgQfBYoN7n9U+uA4gcVwb8Ep6Ytu/9dZbp2hAdr2Iwb///nsSVPduF2iTfFUvA9+7NjBhJrQjOGBgJpw7OQEShybNRGt2xVGA07MZj/MyV4wV6I2ayVXEBkYKokQ4zN+pcesRfdhcLh71AIrdp57Xkm1szbbnCQI6jT07vrTmMfS412e4qmDqAIW9UuuRjOvU1OPJk2v/Zhl5W09TK/N1z7D38V81fwcobM1Vj/z+Cc11CT4z7/3W0zeaH1c1R52ZJ1uP/ypt5gCFraly3P80A9fZvntXwc+B4Nx3cJM06i1Z4Kp5/z/Ts5/QdyEI9gAAAABJRU5ErkJggg==" width="260" height="219"/>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Useful Resources (add the Links below to your Internet favorites)" FOLDED="true" ID="ID_667607279" CREATED="1716218516692" MODIFIED="1716218516692">
<node ID="ID_1479955119" CREATED="1716218335733" MODIFIED="1716218335733" LINK="https://syngenta.sharepoint.com/sites/GLseSPIRIT"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 6pt; margin-bottom: 0pt; font-size: 11.0pt">
        <a href="https://syngenta.sharepoint.com/sites/GLseSPIRIT"><span style="font-family: Aptos; background-color: #302F2F; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null;">SPIRIT Global SharePoint</span></a><span style="font-family: Aptos; color: #686868;">&#xa0;link houses some crop specific documentation and custom Crystal Reports</span><span style="font-family: Aptos; color: #364D7B;">&#xa0;</span><span style="font-family: Aptos; color: #686868;">(including MINT standard labels)</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1374966478" CREATED="1716218335734" MODIFIED="1716218335734" LINK="http://spiritweb.syngentaaws.org/default.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <p style="margin-top: 6pt; margin-bottom: 0pt; font-size: 11.0pt">
        <a href="http://spiritweb.syngentaaws.org/default.aspx"><span style="font-family: Aptos;">SPIRITWEB</span></a><span style="font-family: Aptos; color: #686868;">&#xa0;link, save it as a favorite. SPIRITWEB is a Web application that provides some automated reports and predefined queries.</span>
      </p>
    </ul>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Gaining rights" FOLDED="true" ID="ID_1030780755" CREATED="1715922329487" MODIFIED="1715922335341">
<node TEXT="Contact Michele" ID="ID_959065574" CREATED="1715922336122" MODIFIED="1715922342037"/>
</node>
</node>
<node TEXT="Accessing" FOLDED="true" ID="ID_1745520591" CREATED="1716011992707" MODIFIED="1716012005788">
<node TEXT="Spirit Server Names" FOLDED="true" ID="ID_1324911722" CREATED="1715921721279" MODIFIED="1716236827934">
<node TEXT="reference" FOLDED="true" ID="ID_1478961502" CREATED="1716236830556" MODIFIED="1716236833009">
<node ID="ID_1983136768" CREATED="1718828552712" MODIFIED="1718828552712" LINK="https://syngenta.sharepoint.com/:p:/r/sites/AnalyticsDataSciences/Shared%20Documents/General/Programs/Program%20-%20DS%20-%20Trialing%20%26%20Operations%20(Digital)/Trialing%20Platform%20-%20Vendor%20Transition/KT%20Sessions/SPIRIT/Session06_17-04-2024_DB%20Structure/Database%20Structure.pptx?d=wcd8f5094f0744b52a1ee52de70df6814&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=6VauqL"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/AnalyticsDataSciences/Shared%20Documents/General/Programs/Program%20-%20DS%20-%20Trialing%20%26%20Operations%20(Digital)/Trialing%20Platform%20-%20Vendor%20Transition/KT%20Sessions/SPIRIT/Session06_17-04-2024_DB%20Structure/Database%20Structure.pptx?d=wcd8f5094f0744b52a1ee52de70df6814&amp;csf=1&amp;web=1&amp;e=6VauqL">Database Structure.pptx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1892946507" CREATED="1716236848227" MODIFIED="1716236848227" LINK="https://syngenta.sharepoint.com/:x:/r/sites/SeedsTrialingPlatform/Shared%20Documents/General/Vendor%20Transition/SPIRIT%20Documentation/SPIRIT%20Architecture/SPIRIT%20Servers.xlsx?d=w22c6ec06c61e4b36a449de469d48bd5f&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=Uads7v&amp;amp;nav=MTVfe0NDMjk0M0YwLTlCNDktNDA5Qi1CMDI3LTAyMzYzMUQ2NTI5Nn0"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/SeedsTrialingPlatform/Shared%20Documents/General/Vendor%20Transition/SPIRIT%20Documentation/SPIRIT%20Architecture/SPIRIT%20Servers.xlsx?d=w22c6ec06c61e4b36a449de469d48bd5f&amp;csf=1&amp;web=1&amp;e=Uads7v&amp;nav=MTVfe0NDMjk0M0YwLTlCNDktNDA5Qi1CMDI3LTAyMzYzMUQ2NTI5Nn0">SPIRIT Servers.xlsx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="if servers are unavailable, try restarting spirit" ID="ID_559001222" CREATED="1716508311178" MODIFIED="1716508328555">
<icon BUILTIN="messagebox_warning"/>
</node>
<node ID="ID_865856436" TREE_ID="ID_1953972918">
<node ID="ID_1121054402" TREE_ID="ID_502547247">
<node ID="ID_780731188" TREE_ID="ID_1153175193"/>
</node>
</node>
<node TEXT="NA &amp; LATAM:" FOLDED="true" ID="ID_1255349365" CREATED="1715921861694" MODIFIED="1715922171117">
<node TEXT="USAEDWSPRRGP2" FOLDED="true" ID="ID_1074320321" CREATED="1715922171118" MODIFIED="1717688546170">
<font BOLD="true"/>
<node TEXT=".SyngentaAWS.ORG" ID="ID_151066871" CREATED="1715922132306" MODIFIED="1716233556065">
<arrowlink DESTINATION="ID_151066871"/>
<richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      For Citrix, use full name
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node TEXT="EAME &amp; APAC (Asia, Europe, and Africa )" FOLDED="true" ID="ID_838442059" CREATED="1715922219505" MODIFIED="1718377457929">
<node TEXT="DEAWDWSPRRGP2" FOLDED="true" ID="ID_1635916250" CREATED="1715922235488" MODIFIED="1715922235488">
<node TEXT=".SyngentaAWS.ORG" ID="ID_1925362594" CREATED="1715922132306" MODIFIED="1716231943263"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      For Citrix, use full name
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node TEXT="Staging (Training )" FOLDED="true" ID="ID_352143175" CREATED="1716236967043" MODIFIED="1716507736679">
<node TEXT="USAEDWSPRRGS2" FOLDED="true" ID="ID_1385591634" CREATED="1715922322093" MODIFIED="1715922326717">
<node TEXT="USAEDWSPRRGS2.SyngentaAWS.ORG" ID="ID_148188974" CREATED="1715922322093" MODIFIED="1716504978319"/>
</node>
<node FOLDED="true" ID="ID_1219575497" CREATED="1716237064003" MODIFIED="1716237068030"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table width="271" style="width: 203pt">
      <tr height="19" style="height: 14.25pt">
        <td width="271" height="19" style="width: 203pt; height: 14.25pt">
          MSSQLSERVER@USAEDWMNTGLT1
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT=".SyngentaAWS.ORG" ID="ID_1653266713" CREATED="1715922132306" MODIFIED="1716231943263"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      For Citrix, use full name
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node TEXT="Test (QA), interacts with Identity Management and Material Management" FOLDED="true" ID="ID_1813025389" CREATED="1716236973780" MODIFIED="1720794292502">
<node FOLDED="true" ID="ID_1926716851" CREATED="1716236977993" MODIFIED="1716236977993"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <table width="271" style="width: 203pt">
      <tr height="19" style="height: 14.25pt">
        <td width="271" height="19" style="width: 203pt; height: 14.25pt">
          USAEDWSPRGLT1
        </td>
      </tr>
    </table>
  </body>
</html>
</richcontent>
<node TEXT=".SyngentaAWS.ORG" ID="ID_785387069" CREATED="1715922132306" MODIFIED="1716231943263"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      For Citrix, use full name
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Local" FOLDED="true" ID="ID_1283646848" CREATED="1716012006810" MODIFIED="1716012008284">
<node TEXT="Start Menu, Spirit" ID="ID_267137855" CREATED="1716236340874" MODIFIED="1716236350147"/>
</node>
<node TEXT="Remote Citrix" FOLDED="true" ID="ID_269665499" CREATED="1718108535594" MODIFIED="1718727498954">
<node TEXT="Replacement" FOLDED="true" ID="ID_1967981617" CREATED="1718108547055" MODIFIED="1718108550590">
<node TEXT="Access" FOLDED="true" ID="ID_52614431" CREATED="1718730858445" MODIFIED="1718730864278">
<node ID="ID_1027326772" CREATED="1719410773267" MODIFIED="1719410773267" LINK="https://myapplications.microsoft.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://myapplications.microsoft.com/">My Apps</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1870100832" CREATED="1719421210067" MODIFIED="1719421210067" LINK="https://www.microsoft365.com/apps?auth=2&amp;amp;home=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.microsoft365.com/apps?auth=2&amp;home=1">Apps | Microsoft 365</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1879067989" CREATED="1719598205208" MODIFIED="1719598205208" LINK="https://syngenta.sharepoint.com/:w:/r/sites/EnablementSystemsOperationsCommunications-GlobalTrialingPlatform-Spirit/Shared%20Documents/SPIRIT%20Appstream%20Connection%20Guide.docx?d=wef327dd8eb174908a952899a838d6317&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=hvLCKI"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:w:/r/sites/EnablementSystemsOperationsCommunications-GlobalTrialingPlatform-Spirit/Shared%20Documents/SPIRIT%20Appstream%20Connection%20Guide.docx?d=wef327dd8eb174908a952899a838d6317&amp;csf=1&amp;web=1&amp;e=hvLCKI">SPIRIT Appstream Connection Guide.docx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Testing" FOLDED="true" ID="ID_919337985" CREATED="1718108551379" MODIFIED="1718108555186">
<node TEXT="Share CR" ID="ID_848796708" CREATED="1719500446500" MODIFIED="1719500454195">
<icon BUILTIN="yes"/>
</node>
<node ID="ID_447225014" CREATED="1718733103946" MODIFIED="1718733103946" LINK="https://syngenta.sharepoint.com/:x:/r/sites/EnablementSystemsOperationsCommunications-GlobalTrialingPlatform-Spirit/Shared%20Documents/Spirit%20Appstream%20Testing%20Tracker.xlsx?d=wce29f38fd0f048968457249f7b561d2b&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=iaPved"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:x:/r/sites/EnablementSystemsOperationsCommunications-GlobalTrialingPlatform-Spirit/Shared%20Documents/Spirit%20Appstream%20Testing%20Tracker.xlsx?d=wce29f38fd0f048968457249f7b561d2b&amp;csf=1&amp;web=1&amp;e=iaPved">Spirit Appstream Testing Tracker.xlsx</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Install notes" FOLDED="true" ID="ID_1059458388" CREATED="1718731003375" MODIFIED="1718731006849">
<node TEXT="don&apos;t seem to need the AWS Appstream app installed locally to access" ID="ID_682725294" CREATED="1718731007415" MODIFIED="1718731019350"/>
</node>
<node TEXT="Tests" FOLDED="true" ID="ID_915913722" CREATED="1718728470887" MODIFIED="1718728509103">
<node TEXT="1. Verify the Versions List." ID="ID_666700371" CREATED="1718728512564" MODIFIED="1718728512564"/>
<node TEXT="2. Verify the User Options functionality." ID="ID_1161135568" CREATED="1718728512564" MODIFIED="1718728512564"/>
<node TEXT="3. Verify the Breeding goals functionality." ID="ID_598015465" CREATED="1718728512565" MODIFIED="1718728512565"/>
<node TEXT="4. Verify the Material Breding Goals functionality." ID="ID_96116898" CREATED="1718728512566" MODIFIED="1718728512566"/>
<node TEXT="5. Verify the Show/Hide Column functionality." ID="ID_1907877300" CREATED="1718728512566" MODIFIED="1718728512566"/>
<node TEXT="6. Verify the Display as functionality." ID="ID_450404406" CREATED="1718728512567" MODIFIED="1718728512567"/>
<node TEXT="7. Verify the Materials functionality." ID="ID_1260207578" CREATED="1718728512567" MODIFIED="1718728512567"/>
<node TEXT="8. Verify the Trial Entries functionality." ID="ID_195484670" CREATED="1718728512568" MODIFIED="1718728512568"/>
<node TEXT="9. Verify the Genetic affiliations functionality." ID="ID_137858467" CREATED="1718728512568" MODIFIED="1718728512568"/>
<node TEXT="10. Verify the Lines functionality." ID="ID_1335044269" CREATED="1718728512569" MODIFIED="1718728512569"/>
<node TEXT="11. Verify the Verities functionality." ID="ID_1307738202" CREATED="1718728512569" MODIFIED="1718728512569"/>
<node TEXT="12. Verify the Experiment creation &amp; Edit functionality." ID="ID_1257475690" CREATED="1718728512570" MODIFIED="1718728512570"/>
<node TEXT="13. Verify the Trial Creation &amp; Edit functionality." ID="ID_87905877" CREATED="1718728512570" MODIFIED="1718728512570"/>
<node TEXT="14. Verify the Append existing flex traits functionality." ID="ID_256359011" CREATED="1718728512571" MODIFIED="1718728512571"/>
<node TEXT="15. Verify the Submit local Analysis functionality." ID="ID_1447365490" CREATED="1718728512571" MODIFIED="1718728512571"/>
<node TEXT="16. Verify the Locations Creation functionality." ID="ID_13560369" CREATED="1718728512571" MODIFIED="1718728512571"/>
<node TEXT="17. Verify the Plots functionality." ID="ID_1437583413" CREATED="1718728512572" MODIFIED="1718728512572"/>
<node TEXT="18. Verify the Combined Analysis functionality." ID="ID_849847459" CREATED="1718728512572" MODIFIED="1718728512572"/>
<node TEXT="19. Verify the Submit Combined Analysis Locally functionality." ID="ID_1341071472" CREATED="1718728512572" MODIFIED="1718728512572"/>
<node TEXT="20. Verify the Pollinations functionality." ID="ID_421016211" CREATED="1718728512573" MODIFIED="1718728512573"/>
<node TEXT="21. Verify the Pollinations Creator functionality." ID="ID_979666349" CREATED="1718728512574" MODIFIED="1718728512574"/>
<node TEXT="22. Verify the Refresh functionality." ID="ID_465480999" CREATED="1718728512574" MODIFIED="1718728512574"/>
<node TEXT="23. Verify the Import functionality." ID="ID_1706179087" CREATED="1718728512575" MODIFIED="1718728512575"/>
<node TEXT="24. Verify the Export functionality." ID="ID_180578547" CREATED="1718728512575" MODIFIED="1718728512575"/>
<node TEXT="25. Verify the Copy to clipboard functionality." ID="ID_1237444640" CREATED="1718728512575" MODIFIED="1718728512575"/>
<node TEXT="26. Verify the Aggregate functions." ID="ID_609490055" CREATED="1718728512576" MODIFIED="1718728512576"/>
<node TEXT="27. Verify the Crystal Reports functionality." ID="ID_212644988" CREATED="1718728512576" MODIFIED="1718728512576"/>
<node TEXT="Field Reports" FOLDED="true" ID="ID_321147460" CREATED="1718733902182" MODIFIED="1718733906347">
<node TEXT="Working" ID="ID_654302305" CREATED="1718733906807" MODIFIED="1718733909752"/>
</node>
</node>
<node TEXT="Long Login Process" ID="ID_1877238641" CREATED="1718727604069" MODIFIED="1718727610242"/>
<node TEXT="Clicked Dual Monitor" FOLDED="true" ID="ID_1658245296" CREATED="1718727507478" MODIFIED="1718727516711">
<node TEXT="Froze" ID="ID_743648182" CREATED="1718727517061" MODIFIED="1718727519146"/>
</node>
<node TEXT="Import / Export" ID="ID_539755083" CREATED="1718727641059" MODIFIED="1718727646312"/>
<node TEXT="Crystal Reports" FOLDED="true" ID="ID_322749855" CREATED="1718727946126" MODIFIED="1718727952333">
<node TEXT="pointed to folder, restarted" FOLDED="true" ID="ID_116264080" CREATED="1718727953087" MODIFIED="1718727960881">
<node TEXT="took 5 mins to Load Crystal Reports Service" ID="ID_1825432247" CREATED="1718727961686" MODIFIED="1718728248362"/>
</node>
<node TEXT="Run Report" FOLDED="true" ID="ID_1059104452" CREATED="1718728263364" MODIFIED="1718728271741">
<node TEXT="Slow" ID="ID_257214109" CREATED="1718728272516" MODIFIED="1718728275594"/>
<node TEXT="crystal report error.png" ID="ID_1561627290" CREATED="1718728319242" MODIFIED="1718728319242">
<hook URI="DataStewardshipAnalyst_files/crystal%20report%20error.png" SIZE="1.0" NAME="ExternalObject"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Citrix Web" FOLDED="true" ID="ID_630849" CREATED="1716012012636" MODIFIED="1716012017461">
<node ID="ID_1335771397" CREATED="1716231845764" MODIFIED="1716231845764" LINK="https://syngentavdiprod.cloud.com/Citrix/StoreWeb/#/home"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngentavdiprod.cloud.com/Citrix/StoreWeb/#/home">Citrix Workspace</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Citrix Reciever" FOLDED="true" ID="ID_1030309764" CREATED="1716012008658" MODIFIED="1716232101001">
<node TEXT="Start Menu, Citrix" ID="ID_1023894435" CREATED="1716236360765" MODIFIED="1716236368546"/>
<node TEXT="System Tray" ID="ID_397543411" CREATED="1716236353760" MODIFIED="1716236359127"/>
</node>
</node>
</node>
<node TEXT="Goals" FOLDED="true" ID="ID_1309796880" CREATED="1716187115484" MODIFIED="1716187117491">
<node TEXT="Need to understand SPIRIT identifier versus MINT identifier" ID="ID_1007434027" CREATED="1716186377464" MODIFIED="1716186377464"/>
<node TEXT="Data structure, traits for different crops" ID="ID_1428372575" CREATED="1716186377465" MODIFIED="1716186377465"/>
<node TEXT="What is created in what tool, what is visible for the user, what is editable" ID="ID_858588749" CREATED="1716186377466" MODIFIED="1716186377466"/>
<node TEXT="What are the rules" ID="ID_1149275110" CREATED="1716186377466" MODIFIED="1716186377466"/>
</node>
<node TEXT="Profiles / Groupings" FOLDED="true" ID="ID_392662860" CREATED="1716223979060" MODIFIED="1716226554478">
<node TEXT="Crop" FOLDED="true" ID="ID_471244129" CREATED="1716226479844" MODIFIED="1716226487378">
<node TEXT="MINT" FOLDED="true" ID="ID_412109184" CREATED="1716226488083" MODIFIED="1716226491403">
<node TEXT="MBE" FOLDED="true" ID="ID_934859555" CREATED="1716226491937" MODIFIED="1716226496268">
<node TEXT="Issues" ID="ID_658484648" CREATED="1716226519963" MODIFIED="1716226521346"/>
</node>
<node TEXT="Identity" ID="ID_150038329" CREATED="1716223982325" MODIFIED="1716226516733"/>
</node>
</node>
<node TEXT="$2023 standards" FOLDED="true" ID="ID_178196252" CREATED="1716226169232" MODIFIED="1716226181739">
<node TEXT="good starting profiles" ID="ID_729094155" CREATED="1716226184793" MODIFIED="1716226190512"/>
</node>
<node ID="ID_1443069053" TREE_ID="ID_1968138006">
<node ID="ID_975753186" TREE_ID="ID_1247456375"/>
<node ID="ID_1068165395" TREE_ID="ID_1007829063"/>
</node>
<node TEXT="Profiles without user defined Traits can be added Cross Crop" ID="ID_356087017" CREATED="1718918687810" MODIFIED="1718918705333"/>
</node>
<node TEXT="Queries" FOLDED="true" ID="ID_358101172" CREATED="1716775952034" MODIFIED="1716775958684">
<node TEXT="wildcards" ID="ID_832790658" CREATED="1718081720691" MODIFIED="1718081723193"/>
<node TEXT="traits" FOLDED="true" ID="ID_1168949424" CREATED="1717087991692" MODIFIED="1717087994669">
<node TEXT="material" FOLDED="true" ID="ID_444038547" CREATED="1717088127989" MODIFIED="1717088129693">
<node TEXT="MINT" FOLDED="true" ID="ID_1395928016" CREATED="1717088076670" MODIFIED="1717088082160">
<node TEXT="Batch BE BID" FOLDED="true" ID="ID_1171662540" CREATED="1717088119748" MODIFIED="1717088123284">
<node TEXT="MAT:MMT:BEBID" ID="ID_962787539" CREATED="1717088110330" MODIFIED="1717088110330"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Tracing Lineage" FOLDED="true" ID="ID_220441455" CREATED="1716775959734" MODIFIED="1716777048306">
<font BOLD="true"/>
<node TEXT="By LBG BID Population" FOLDED="true" ID="ID_712538173" CREATED="1716778263617" MODIFIED="1716778280668">
<node TEXT="Material .. Mint Material Trait" FOLDED="true" ID="ID_340478163" CREATED="1716778437278" MODIFIED="1716778453586">
<node TEXT="Batch LBG BID" FOLDED="true" ID="ID_1075239419" CREATED="1716778298961" MODIFIED="1716778305519">
<node TEXT="LBGBID" ID="ID_1298831997" CREATED="1716778470828" MODIFIED="1716778480507"/>
</node>
</node>
</node>
<node TEXT="By Material ID Lineage Chain" FOLDED="true" ID="ID_914008483" CREATED="1716777171280" MODIFIED="1716778260303">
<node TEXT="Female Parent Material .. Material Traits .. Material ID" FOLDED="true" ID="ID_709562048" CREATED="1716777112916" MODIFIED="1716777392693">
<node TEXT="MAT:FPARM:MATID" ID="ID_1523540076" CREATED="1716777108026" MODIFIED="1716777108031"/>
</node>
<node TEXT="Female Parent Material .. Female Female Parent .. Material Traits .. Material ID" FOLDED="true" ID="ID_162527050" CREATED="1716777112916" MODIFIED="1716777430465">
<node TEXT="MAT:FPARM:FFPAR:MATID" ID="ID_481936922" CREATED="1716777088771" MODIFIED="1716777108023"/>
</node>
</node>
<node TEXT="Using Hierarchy Viewer" FOLDED="true" ID="ID_1410279501" CREATED="1716777050552" MODIFIED="1716777257605">
<node ID="ID_1391006919" CREATED="1716777214424" MODIFIED="1716777214424" LINK="https://syngenta.sharepoint.com/:w:/r/sites/GLseSPIRIT/_layouts/15/Doc.aspx?sourcedoc=%7B3B526A00-A444-43DF-882B-B1056525CC73%7D&amp;amp;file=Crib%20Sheet_Hierarchy%20view%20(To%20find%20parents).docx&amp;amp;action=default&amp;amp;mobileredirect=true&amp;amp;DefaultItemOpen=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:w:/r/sites/GLseSPIRIT/_layouts/15/Doc.aspx?sourcedoc=%7B3B526A00-A444-43DF-882B-B1056525CC73%7D&amp;file=Crib%20Sheet_Hierarchy%20view%20(To%20find%20parents).docx&amp;action=default&amp;mobileredirect=true&amp;DefaultItemOpen=1">Crib Sheet_Hierarchy view (To find parents).docx</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1554568974" CREATED="1717012705294" MODIFIED="1717012705294" LINK="https://syngenta.sharepoint.com/:p:/r/sites/pegasysdata/Shared%20Documents/spirit-info/SPIRIT_Overview%20SBI%2014%20Aug%202009.pptx?d=w11a2394b1b914a2a8bd162a323ad05cd&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=IkIgTO&amp;amp;nav=eyJzSWQiOjg0NSwiY0lkIjowfQ"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/pegasysdata/Shared%20Documents/spirit-info/SPIRIT_Overview%20SBI%2014%20Aug%202009.pptx?d=w11a2394b1b914a2a8bd162a323ad05cd&amp;csf=1&amp;web=1&amp;e=IkIgTO&amp;nav=eyJzSWQiOjg0NSwiY0lkIjowfQ">SPIRIT_Overview SBI 14 Aug 2009.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="GNA" ID="ID_1656797868" CREATED="1716906866306" MODIFIED="1717084005257"/>
</node>
<node TEXT="Functions" FOLDED="true" ID="ID_1651854126" CREATED="1715923114921" MODIFIED="1715923117358">
<node TEXT="Import" FOLDED="true" ID="ID_1174552682" CREATED="1719852752811" MODIFIED="1719852754966">
<node TEXT="Example Task" ID="ID_598920707" CREATED="1731088741346" MODIFIED="1731089321536">
<attribute NAME="Start" VALUE="11/8/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-11-08T00:00-0500|date"/>
<attribute NAME="Due" VALUE="11/8/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-11-08T00:00-0500|date"/>
<attribute NAME="Last Action " VALUE="11/8/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-11-08T00:00-0500|date"/>
</node>
<node TEXT="Alternate to query" FOLDED="true" ID="ID_1048237193" CREATED="1719852755846" MODIFIED="1719852770245">
<node TEXT="important as updates to new records, not as new records" ID="ID_1696447054" CREATED="1719852772413" MODIFIED="1719852784228"/>
</node>
</node>
<node TEXT="Calculate Traits works at the trial level" ID="ID_943903510" CREATED="1718227913053" MODIFIED="1718227926271"/>
<node TEXT="PMID" FOLDED="true" ID="ID_1517796231" CREATED="1718205746929" MODIFIED="1718205886812">
<node TEXT="PSS_RECTP" FOLDED="true" ID="ID_1501726006" CREATED="1718205895927" MODIFIED="1718205926768">
<node TEXT="Plot type" ID="ID_790352928" CREATED="1718205927381" MODIFIED="1718205932138"/>
<node TEXT="1: Plot" ID="ID_166238312" CREATED="1718205933014" MODIFIED="1718205935464"/>
<node TEXT="2: Sub" ID="ID_1373349025" CREATED="1718205935691" MODIFIED="1718205939750"/>
</node>
</node>
<node TEXT="used to create pollination records" FOLDED="true" ID="ID_297996254" CREATED="1715796216307" MODIFIED="1715796234485">
<node TEXT="gets sent to IM" FOLDED="true" ID="ID_1917951110" CREATED="1715796326226" MODIFIED="1715796331220">
<node TEXT="rules engine in IM understands relationships" ID="ID_813764131" CREATED="1715796235340" MODIFIED="1715796298292"/>
<node TEXT="creates BE," ID="ID_32984533" CREATED="1715796313022" MODIFIED="1715796324193"/>
<node TEXT="sends back to Spirit" ID="ID_543509047" CREATED="1715796336182" MODIFIED="1715796353717"/>
</node>
</node>
<node TEXT="Export" FOLDED="true" ID="ID_1279089365" CREATED="1716233570661" MODIFIED="1716233573561">
<node TEXT="Citrix" FOLDED="true" ID="ID_605498537" CREATED="1716233575498" MODIFIED="1716233578200">
<node TEXT="use Client to save on Local HD" ID="ID_1732237176" CREATED="1716233579418" MODIFIED="1716233593267"/>
</node>
</node>
<node TEXT="Crystal Reports" FOLDED="true" ID="ID_615731716" CREATED="1716898204339" MODIFIED="1716898212490">
<node TEXT="editing" FOLDED="true" ID="ID_1589206032" CREATED="1716898218563" MODIFIED="1716898221187">
<node TEXT="use alternative report" FOLDED="true" ID="ID_628251055" CREATED="1716899410860" MODIFIED="1716899416390">
<node TEXT="Bartender" ID="ID_1079487872" CREATED="1716899417354" MODIFIED="1716899421656"/>
<node TEXT="rationale" FOLDED="true" ID="ID_1974015747" CREATED="1716899426680" MODIFIED="1716899429741">
<node TEXT="need purchased version" ID="ID_684879479" CREATED="1716898328300" MODIFIED="1716898342433"/>
<node TEXT="typically not worth it" ID="ID_200445882" CREATED="1716899397936" MODIFIED="1716899407288"/>
</node>
</node>
</node>
</node>
<node TEXT="Make Trials" FOLDED="true" ID="ID_1906239772" CREATED="1718918506966" MODIFIED="1718918510047">
<node TEXT="Troubleshooting" FOLDED="true" ID="ID_1484643947" CREATED="1718918510693" MODIFIED="1718918517366">
<node TEXT="User Settings" FOLDED="true" ID="ID_472975080" CREATED="1718918533568" MODIFIED="1718918537870">
<node TEXT="Plot Number of Prefix Chars" ID="ID_71690507" CREATED="1718918517917" MODIFIED="1718918530094"/>
</node>
</node>
</node>
</node>
<node TEXT="Administrative" FOLDED="true" ID="ID_970236971" CREATED="1719943931857" MODIFIED="1719943938358">
<node TEXT="Add Traits" FOLDED="true" ID="ID_1845440988" CREATED="1718223072471" MODIFIED="1718223774630">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_179900547" CREATED="1718810960850" MODIFIED="1718810963112">
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\Tools\Spirit\Add Trait\Add Trait GMT20240612-200214_Recording_2628x1366.mp4" ID="ID_380153223" CREATED="1718810966490" MODIFIED="1718810973548" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Spirit/Add%20Trait/Add%20Trait%20GMT20240612-200214_Recording_2628x1366.mp4"/>
</node>
<node TEXT="Complete template" FOLDED="true" ID="ID_938167800" CREATED="1718223184870" MODIFIED="1718224361810">
<node TEXT="Align with existing Traits in Spirit" FOLDED="true" ID="ID_931099752" CREATED="1718224364108" MODIFIED="1718224376448">
<node TEXT="Sort with existing" ID="ID_1311362505" CREATED="1718224430436" MODIFIED="1718224442442"/>
</node>
</node>
<node TEXT="challenge request" ID="ID_137631392" CREATED="1718223106867" MODIFIED="1718810933627"/>
<node TEXT="Notes" FOLDED="true" ID="ID_159157998" CREATED="1718223235432" MODIFIED="1718223237029">
<node TEXT="Sorted by Trait Name" ID="ID_1651767687" CREATED="1718223215616" MODIFIED="1718223234310"/>
<node TEXT="Inheritance" ID="ID_1789405206" CREATED="1718223267774" MODIFIED="1718223297522"/>
<node TEXT="Strict" FOLDED="true" ID="ID_1014531657" CREATED="1718223297956" MODIFIED="1718223301091">
<node TEXT="Limits values to a set or range" FOLDED="true" ID="ID_1271871394" CREATED="1718223301093" MODIFIED="1718223313128">
<node TEXT="Turns red if out of range, no save" ID="ID_1217546696" CREATED="1718223314933" MODIFIED="1718223390744"/>
</node>
<node TEXT="Yellow if in range when not strict" ID="ID_1796382535" CREATED="1718223327012" MODIFIED="1718223350405"/>
</node>
</node>
<node TEXT="Make Lookup table first" FOLDED="true" ID="ID_728233782" CREATED="1718223251272" MODIFIED="1718224100428">
<node TEXT="about" FOLDED="true" ID="ID_844015080" CREATED="1718223865318" MODIFIED="1718223867028">
<node TEXT="can be assigned to multiple traits" ID="ID_462322100" CREATED="1718224105418" MODIFIED="1718224126258"/>
<node TEXT="text or int" ID="ID_137381512" CREATED="1718223258508" MODIFIED="1718223261299"/>
</node>
<node TEXT="In Spirit .." FOLDED="true" ID="ID_1957505323" CREATED="1718223871800" MODIFIED="1718223876875">
<node TEXT="Lookup Tables Window" FOLDED="true" ID="ID_63713499" CREATED="1718223877612" MODIFIED="1718223885674">
<node TEXT="Add Record" FOLDED="true" ID="ID_1120179524" CREATED="1718223898607" MODIFIED="1718223908281">
<node TEXT="Use Request_" ID="ID_1055820832" CREATED="1718223910587" MODIFIED="1718223925259"/>
<node TEXT="Proerties" FOLDED="true" ID="ID_629006725" CREATED="1718224053079" MODIFIED="1718224057762">
<node TEXT="Data Type" FOLDED="true" ID="ID_59453970" CREATED="1718223934189" MODIFIED="1718223940084">
<node TEXT="Integer" FOLDED="true" ID="ID_690537425" CREATED="1718223940522" MODIFIED="1718223944011">
<node TEXT="useful for Analysis" ID="ID_515002949" CREATED="1718223953807" MODIFIED="1718223962982"/>
</node>
</node>
<node TEXT="Code is what is used" ID="ID_1997899702" CREATED="1718223714977" MODIFIED="1718223721638"/>
<node TEXT="Name is stored in table (not seen in UI)" ID="ID_1060381505" CREATED="1718223687456" MODIFIED="1718224019840"/>
<node TEXT="SRTNO: Sort order" ID="ID_1941177737" CREATED="1718224021184" MODIFIED="1718224032041"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="With Formulas, can use Staging to test first" FOLDED="true" ID="ID_916756114" CREATED="1718225033635" MODIFIED="1718227682838">
<node TEXT="Save Calculation" ID="ID_720576827" CREATED="1718227080964" MODIFIED="1718227133176"/>
<node TEXT="Logout of Spirit" ID="ID_1314979840" CREATED="1718227133864" MODIFIED="1718227142483"/>
<node TEXT="Log back in to test" ID="ID_1027496645" CREATED="1718227142801" MODIFIED="1718227148985"/>
</node>
<node TEXT="Trait Definitions" FOLDED="true" ID="ID_997952438" CREATED="1718224160117" MODIFIED="1718224512773">
<font BOLD="true" ITALIC="true"/>
<node TEXT="Add Traits" FOLDED="true" ID="ID_308780269" CREATED="1718224523897" MODIFIED="1718224533643">
<node TEXT="DTYP" FOLDED="true" ID="ID_500250701" CREATED="1718224566444" MODIFIED="1718224571284">
<node TEXT="2: Numeric" ID="ID_805391602" CREATED="1718224571853" MODIFIED="1718224579687"/>
<node TEXT="Must match Lookup Table, if used" ID="ID_1315028533" CREATED="1718224928826" MODIFIED="1718224936488"/>
<node TEXT="Once saved, cant change" ID="ID_47073624" CREATED="1718225866742" MODIFIED="1718225876198"/>
</node>
<node TEXT="Description: Change in Properties" ID="ID_950404287" CREATED="1718225975476" MODIFIED="1718225988753"/>
<node TEXT="USEST" FOLDED="true" ID="ID_623917235" CREATED="1718224655502" MODIFIED="1718224659385">
<node TEXT="Do last, locks other traits" ID="ID_1682760617" CREATED="1718225823252" MODIFIED="1718225853832"/>
<node TEXT="Checked if used for analysis" ID="ID_1161681968" CREATED="1718224659813" MODIFIED="1718224666788"/>
<node TEXT="Can be added later" ID="ID_1792878705" CREATED="1718225857733" MODIFIED="1718225862478"/>
</node>
<node TEXT="UOMTP" FOLDED="true" ID="ID_1186164242" CREATED="1718224729190" MODIFIED="1718224737581">
<node TEXT="Once saved, cant change" ID="ID_136417659" CREATED="1718225866742" MODIFIED="1718225876198"/>
<node TEXT="%: 23" ID="ID_1584134121" CREATED="1718224738065" MODIFIED="1718224746689"/>
</node>
<node TEXT="UOM: PERC" FOLDED="true" ID="ID_1060513236" CREATED="1718224749227" MODIFIED="1718224760456">
<node TEXT="Once saved, cant change" ID="ID_1575468058" CREATED="1718225866742" MODIFIED="1718225876198"/>
</node>
<node TEXT="LKUP: Lookup Flag" ID="ID_603616468" CREATED="1718224837844" MODIFIED="1718224851435"/>
<node TEXT="LKTSL: Choose" ID="ID_639241534" CREATED="1718224851862" MODIFIED="1718224923734"/>
</node>
</node>
</node>
<node TEXT="Add Location" FOLDED="true" ID="ID_1581277872" CREATED="1719943948362" MODIFIED="1719943952549">
<node TEXT="Update process" ID="ID_1738826793" CREATED="1720665339159" MODIFIED="1721055020348">
<icon BUILTIN="yes"/>
<attribute NAME="When" VALUE="7/9/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-07-09T00:00-0400|date"/>
</node>
<node TEXT="done" FOLDED="true" ID="ID_1161237807" CREATED="1720665333359" MODIFIED="1720665336590">
<node TEXT="We added a new 3rd party address to the &apos;TO Location Model LATAM”" FOLDED="true" ID="ID_444256147" CREATED="1719943987732" MODIFIED="1720665367065">
<icon BUILTIN="yes"/>
<icon BUILTIN="button_ok"/>
<attribute NAME="WhenDone" VALUE="2024-07-10" OBJECT="org.freeplane.features.format.FormattedDate|2024-07-10T22:36-0400|yyyy-MM-dd"/>
<node TEXT="1735 Austin Road" ID="ID_836384258" CREATED="1719943987732" MODIFIED="1719943987732"/>
<node TEXT="CA 92243" ID="ID_868919456" CREATED="1719943987733" MODIFIED="1719943987733"/>
<node TEXT="El Centro" ID="ID_1687054840" CREATED="1719943987733" MODIFIED="1719943987733"/>
<node TEXT="CA" ID="ID_439110575" CREATED="1719943987734" MODIFIED="1719943987734"/>
<node TEXT="Could you please generate a new Location ID for this address?" ID="ID_1912132264" CREATED="1719943987734" MODIFIED="1719943987734"/>
</node>
</node>
</node>
<node TEXT="Managing User Activities" ID="ID_407150669" CREATED="1715958574241" MODIFIED="1717538627335">
<font BOLD="true"/>
</node>
<node TEXT="Training" FOLDED="true" ID="ID_1396463508" CREATED="1719257401681" MODIFIED="1719257650651">
<node TEXT="Import Export" FOLDED="true" ID="ID_1816839234" CREATED="1719257659031" MODIFIED="1719257701034">
<node TEXT="6/24/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-06-24T03:00-0400|date" FOLDED="true" ID="ID_206273762" CREATED="1719257651593" MODIFIED="1719257654084">
<node TEXT="Martin Costa" ID="ID_1309663170" CREATED="1719257704260" MODIFIED="1719257712111"/>
</node>
</node>
</node>
<node TEXT="Add New / Change User in Spirit and MINT" FOLDED="true" ID="ID_1735529139" CREATED="1717523725234" MODIFIED="1720632591112">
<font SIZE="16" BOLD="true"/>
<node TEXT="reference" FOLDED="true" POSITION="bottom_or_right" ID="ID_1770302616" CREATED="1717524124583" MODIFIED="1717524126409">
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\Tools\Spirit\Add User and Rights GMT20240604-151608_Recording_2628x1446.mp4" ID="ID_648645953" CREATED="1717524142805" MODIFIED="1717524147638" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Spirit/Add%20User%20and%20Rights%20GMT20240604-151608_Recording_2628x1446.mp4"/>
<node ID="ID_1968913931" CREATED="1717597499929" MODIFIED="1717597499929" LINK="https://syngenta.sharepoint.com/:w:/r/sites/SeedsTrialingPlatform/Shared%20Documents/General/Vendor%20Transition/SPIRIT%20Documentation/SPIRIT%20User%20Access%20Guide/SPIRIT%20New%20User%20Access%20Process%20Model%202021.docx?d=w54915e9a817b4b9787fd338dff64f60f&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=blghec"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:w:/r/sites/SeedsTrialingPlatform/Shared%20Documents/General/Vendor%20Transition/SPIRIT%20Documentation/SPIRIT%20User%20Access%20Guide/SPIRIT%20New%20User%20Access%20Process%20Model%202021.docx?d=w54915e9a817b4b9787fd338dff64f60f&amp;csf=1&amp;web=1&amp;e=blghec">SPIRIT New User Access Process Model 2021.docx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Open User Access Log.xlsx" POSITION="bottom_or_right" ID="ID_83564327" CREATED="1717693841767" MODIFIED="1717693856352" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Spirit/Access/User%20Access%20Log.xlsx"/>
<node TEXT="Need:" FOLDED="true" ID="ID_1336703735" CREATED="1717523856791" MODIFIED="1719339368854">
<font BOLD="true"/>
<node TEXT="User ID" ID="ID_1660240290" CREATED="1717523930718" MODIFIED="1717523937352"/>
<node TEXT="User ID in Refdata" ID="ID_135846464" CREATED="1717523940518" MODIFIED="1717523951503"/>
<node TEXT="Get Crop Owner approval" FOLDED="true" ID="ID_786715448" CREATED="1717523973156" MODIFIED="1718139765608">
<node TEXT="Crop Owner List" FOLDED="true" ID="ID_553982289" CREATED="1717696852668" MODIFIED="1718140305185">
<font BOLD="true"/>
<node TEXT="Lettuce, Brassicas" FOLDED="true" ID="ID_155953523" CREATED="1718140285096" MODIFIED="1718140293956">
<node TEXT="Martina Gunnemann" ID="ID_832714364" CREATED="1718139873973" MODIFIED="1718139873973"/>
</node>
<node TEXT="Solanaceae" FOLDED="true" ID="ID_1171287424" CREATED="1718140069625" MODIFIED="1718140074177">
<node TEXT="Marcel Prins" ID="ID_1396929875" CREATED="1718139919560" MODIFIED="1718139919560"/>
</node>
<node TEXT="Wheat" FOLDED="true" ID="ID_419689984" CREATED="1718140308104" MODIFIED="1718140316035">
<node TEXT="Sandra Solle" ID="ID_596909722" CREATED="1718141483909" MODIFIED="1718141483909"/>
</node>
<node TEXT="Sunflower" FOLDED="true" ID="ID_1711986472" CREATED="1718140316653" MODIFIED="1718140321069">
<node TEXT="Sandra Solle" ID="ID_489929233" CREATED="1718141486486" MODIFIED="1718141486486"/>
</node>
</node>
</node>
<node TEXT="delegate of who in IM" FOLDED="true" ID="ID_1383765899" CREATED="1717608195523" MODIFIED="1717608201950">
<node TEXT="Need at least 1 for MO" ID="ID_942976578" CREATED="1719339544261" MODIFIED="1719339656965"/>
<node TEXT="Cross Delegate within Breeding Group" ID="ID_485604580" CREATED="1719339957866" MODIFIED="1719339970650"/>
</node>
<node TEXT="Breeding Group Membership with Roles" FOLDED="true" ID="ID_1155709279" CREATED="1717608210461" MODIFIED="1718139815270">
<node TEXT="reference" FOLDED="true" ID="ID_402226983" CREATED="1718139777653" MODIFIED="1718139780831">
<node TEXT="http://spiritweb.syngentaaws.org/default.aspx" ID="ID_768797348" CREATED="1718139797158" MODIFIED="1718139797158" LINK="http://spiritweb.syngentaaws.org/default.aspx"/>
</node>
<node TEXT="Roles" ID="ID_147967684" CREATED="1717523937947" MODIFIED="1717608223022"/>
</node>
</node>
<node TEXT="Add user to Spirit" FOLDED="true" POSITION="bottom_or_right" ID="ID_12158405" CREATED="1717521890145" MODIFIED="1717523959754">
<node TEXT="reference" FOLDED="true" ID="ID_1937937692" CREATED="1717597496595" MODIFIED="1717597498650">
<node ID="ID_844913170" CREATED="1717597499929" MODIFIED="1717597499929" LINK="https://syngenta.sharepoint.com/:w:/r/sites/SeedsTrialingPlatform/Shared%20Documents/General/Vendor%20Transition/SPIRIT%20Documentation/SPIRIT%20User%20Access%20Guide/SPIRIT%20New%20User%20Access%20Process%20Model%202021.docx?d=w54915e9a817b4b9787fd338dff64f60f&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=blghec"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:w:/r/sites/SeedsTrialingPlatform/Shared%20Documents/General/Vendor%20Transition/SPIRIT%20Documentation/SPIRIT%20User%20Access%20Guide/SPIRIT%20New%20User%20Access%20Process%20Model%202021.docx?d=w54915e9a817b4b9787fd338dff64f60f&amp;csf=1&amp;web=1&amp;e=blghec">SPIRIT New User Access Process Model 2021.docx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Need Crop owner approval for adding to crop only" FOLDED="true" ID="ID_1711944486" CREATED="1717523581697" MODIFIED="1717523597225">
<node TEXT="not needed for adding to BG" ID="ID_384003930" CREATED="1717523597605" MODIFIED="1717523605735"/>
</node>
<node FOLDED="true" ID="ID_1378129646" CREATED="1717688719864" MODIFIED="1718214148041"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Add to <span style="text-decoration: underline;">both</span>&#xa0;Production and Staging Environments
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node TEXT="Add to all Production crops and at least main crop in stage" FOLDED="true" ID="ID_226278491" CREATED="1718225518205" MODIFIED="1718225613652">
<node TEXT="Email once done" ID="ID_734074281" CREATED="1718225579429" MODIFIED="1718225586555"/>
<node TEXT="Add the rest later" ID="ID_1417456866" CREATED="1718225587006" MODIFIED="1718225593035"/>
</node>
<node TEXT="Create Person Record" FOLDED="true" ID="ID_652401308" CREATED="1717540061873" MODIFIED="1717540078529">
<font BOLD="true"/>
<node TEXT="reference" FOLDED="true" ID="ID_222221621" CREATED="1717545477912" MODIFIED="1717545479889">
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\Tools\Spirit\Add User and Rights GMT20240604-151608_Recording_2628x1446.mp4" ID="ID_1254377139" CREATED="1717545514040" MODIFIED="1717545520489" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Spirit/Add%20User%20and%20Rights%20GMT20240604-151608_Recording_2628x1446.mp4"/>
<node TEXT="C:\Users\u581917\OneDrive - Syngenta\Documents\DSA\Tools\Spirit\Add User Part 2 GMT20240604-172615_Recording_2628x1366.mp4" ID="ID_1097503594" CREATED="1717545527013" MODIFIED="1717545530958" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/DSA/Tools/Spirit/Add%20User%20Part%202%20GMT20240604-172615_Recording_2628x1366.mp4"/>
</node>
<node TEXT="Toolkit .. Support Tools .. People" FOLDED="true" ID="ID_719755357" CREATED="1717538677106" MODIFIED="1717538808121">
<node TEXT="query on login for New User and Replacing User" FOLDED="true" ID="ID_991564552" CREATED="1717538829128" MODIFIED="1718143651965">
<node TEXT="Make sure New user doesn&apos;t already exist" ID="ID_4617347" CREATED="1717538809709" MODIFIED="1718143660205"/>
</node>
<node TEXT="Add user" FOLDED="true" ID="ID_1672045415" CREATED="1717538842343" MODIFIED="1717538849765">
<node TEXT="paste login ID under LOGIN" ID="ID_1755800461" CREATED="1717538870132" MODIFIED="1717538881969"/>
<node TEXT="Create a CODE" FOLDED="true" ID="ID_1570383335" CREATED="1717538883362" MODIFIED="1717538899303">
<node TEXT="use three letter characters (no numbers)" ID="ID_1457056618" CREATED="1717539108700" MODIFIED="1717539123548"/>
<node TEXT="check to see that another user is an designed the CODE" FOLDED="true" ID="ID_837658850" CREATED="1717538899308" MODIFIED="1717538912352">
<node TEXT="query on new CODE" ID="ID_735519828" CREATED="1717538914324" MODIFIED="1717538930775"/>
</node>
<node TEXT="try first letter of first name, and first two letters of last name" ID="ID_1607390204" CREATED="1717539173904" MODIFIED="1717539204735"/>
</node>
<node TEXT="paste in first name, last name" ID="ID_1633353133" CREATED="1717539553143" MODIFIED="1717539561154"/>
<node TEXT="MSTSL" FOLDED="true" ID="ID_1998653200" CREATED="1717539561748" MODIFIED="1717539637862">
<node TEXT="Material Store Selector" FOLDED="true" ID="ID_1589891826" CREATED="1717539638615" MODIFIED="1717539642972">
<node TEXT="Default Store for the site" ID="ID_1080574220" CREATED="1717539679383" MODIFIED="1717539684738"/>
<node TEXT="USWD1" ID="ID_1428609726" CREATED="1717539667753" MODIFIED="1717539671321"/>
</node>
</node>
<node TEXT="RSTSL" FOLDED="true" ID="ID_1862381059" CREATED="1717539694334" MODIFIED="1717539702276">
<node TEXT="Research Station Selector" FOLDED="true" ID="ID_383661314" CREATED="1717539703503" MODIFIED="1717539706970">
<node TEXT="USWD" ID="ID_1566388178" CREATED="1717539707879" MODIFIED="1717539710103"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="For Each Crop" FOLDED="true" ID="ID_755027791" CREATED="1718214065945" MODIFIED="1718214432820">
<font ITALIC="true"/>
<node TEXT="Create Record for User in Crop Login" FOLDED="true" ID="ID_1480576102" CREATED="1717540150998" MODIFIED="1717540285984">
<font BOLD="true"/>
<node TEXT="Toolkit .. Support Tools .. Crop Logins" FOLDED="true" ID="ID_1485395405" CREATED="1717538677106" MODIFIED="1717691521325">
<node TEXT="Query new user CODE to ensure that user doesn&apos;t already exist in crop, and CODE of person that this user is replacing" FOLDED="true" ID="ID_1475630037" CREATED="1717692853592" MODIFIED="1718133206199">
<node TEXT="LOGIN:PERSN:CODE" ID="ID_782574432" CREATED="1718133162188" MODIFIED="1718133162188"/>
</node>
<node TEXT="Setup Profile (first time in Crop only)" FOLDED="true" ID="ID_438638425" CREATED="1717541898420" MODIFIED="1717692337397">
<font ITALIC="true"/>
<node TEXT="Edit Columns" FOLDED="true" ID="ID_1742253926" CREATED="1717540297449" MODIFIED="1718137673982">
<node TEXT="User Login" ID="ID_937365624" CREATED="1717540458774" MODIFIED="1717540458774"/>
<node TEXT="Last Name" ID="ID_1524406168" CREATED="1717540458774" MODIFIED="1717540458774"/>
<node TEXT="First Name" ID="ID_5079032" CREATED="1717540458780" MODIFIED="1717540458780"/>
<node TEXT="Person Selector" ID="ID_727975226" CREATED="1717540458783" MODIFIED="1717540458783"/>
<node TEXT="Code" ID="ID_445442546" CREATED="1717540458784" MODIFIED="1717540458784"/>
<node TEXT="Breeding Group Seledor" ID="ID_85692746" CREATED="1717540458785" MODIFIED="1717540458785"/>
<node TEXT="Grant Data Colledion" ID="ID_1067525963" CREATED="1717540458787" MODIFIED="1717540458787"/>
<node TEXT="Grart field Map" ID="ID_1409049451" CREATED="1717540458788" MODIFIED="1717540458788"/>
<node TEXT="Grant Inventory" ID="ID_1999566240" CREATED="1717540458789" MODIFIED="1717540458789"/>
<node TEXT="Grant Trial Anaysis" ID="ID_334595526" CREATED="1717540458790" MODIFIED="1717540458790"/>
<node TEXT="Location Create/Delete" ID="ID_384069277" CREATED="1717540458792" MODIFIED="1717541509140"/>
<node TEXT="Location Update" ID="ID_617844917" CREATED="1717540458793" MODIFIED="1717540458793"/>
<node TEXT="Grant Security" ID="ID_1598408554" CREATED="1717540458794" MODIFIED="1717540458794"/>
<node TEXT="Support Table Modfy" ID="ID_1438130736" CREATED="1717540458795" MODIFIED="1717540458795"/>
<node TEXT="Mail Stop" ID="ID_1885346211" CREATED="1717540458796" MODIFIED="1717540458796"/>
<node TEXT="Material Store Code" FOLDED="true" ID="ID_848955221" CREATED="1717540458800" MODIFIED="1717540458800">
<node TEXT="Person .. Material Store .." ID="ID_1905700176" CREATED="1718131252952" MODIFIED="1718131270500"/>
</node>
<node TEXT="Research Station Code" ID="ID_1432709702" CREATED="1717540458801" MODIFIED="1717540458801"/>
<node TEXT="Crop Administrator" ID="ID_1019716980" CREATED="1717540458802" MODIFIED="1718131304712"/>
</node>
<node TEXT="Change Width of Columns for CODE and right to be just the width of the column name" ID="ID_1527708218" CREATED="1717541737805" MODIFIED="1717541876533"/>
<node TEXT="New Profile:" FOLDED="true" ID="ID_1210002394" CREATED="1718131334908" MODIFIED="1718137980933">
<node TEXT="Crop Login - Add User" ID="ID_1590955249" CREATED="1718131387535" MODIFIED="1718137973988"/>
</node>
<node TEXT="set as default profile" ID="ID_1074563235" CREATED="1717540454346" MODIFIED="1717541884129"/>
<node TEXT="SAVE PROFILE!" ID="ID_6514711" CREATED="1717541885138" MODIFIED="1718134689746"/>
</node>
<node TEXT="Add User Record" FOLDED="true" ID="ID_1686411130" CREATED="1717541954134" MODIFIED="1718137561441">
<node TEXT="CODE = {user code}" ID="ID_1145721856" CREATED="1717541960797" MODIFIED="1717541987184"/>
<node TEXT="BGPSL = (default)" FOLDED="true" ID="ID_342339135" CREATED="1717542059077" MODIFIED="1717693071866">
<node TEXT="Breeding Group" ID="ID_229594262" CREATED="1717542108246" MODIFIED="1717542112069"/>
<node TEXT="TO (space): Trial Officer" ID="ID_36829028" CREATED="1717542240575" MODIFIED="1717542261837"/>
</node>
<node TEXT="for Read Only, stop there" ID="ID_1078437632" CREATED="1717542274135" MODIFIED="1717542288863"/>
<node TEXT="Add Authorizations:" ID="ID_355148762" CREATED="1717542290764" MODIFIED="1717542300466"/>
<node TEXT="Save" ID="ID_26600526" CREATED="1717542394517" MODIFIED="1717542396789"/>
</node>
</node>
</node>
<node TEXT="Give Breeding Group Authorizations" FOLDED="true" ID="ID_636201940" CREATED="1717542439340" MODIFIED="1717542449136">
<font BOLD="true"/>
<node TEXT="Examine existing user authorizations" FOLDED="true" ID="ID_1241895779" CREATED="1717544077640" MODIFIED="1717544089750">
<node TEXT="in Stage, can see what existing user is assigned" FOLDED="true" ID="ID_490943365" CREATED="1717542545509" MODIFIED="1717542570861">
<node TEXT="Person, query existing user" ID="ID_1127904158" CREATED="1717542574005" MODIFIED="1717542584138"/>
<node TEXT="Add to Person Grid" ID="ID_1402417601" CREATED="1717542620812" MODIFIED="1717542627246"/>
</node>
<node TEXT="Method 1 (easier): Transfer authorizations from existing to new user" FOLDED="true" ID="ID_962151479" CREATED="1717544108486" MODIFIED="1717544447677">
<font BOLD="true"/>
<node TEXT="Highlight Users" ID="ID_911583503" CREATED="1717542627892" MODIFIED="1717542633298"/>
<node TEXT="Open Properties pages" FOLDED="true" ID="ID_505278267" CREATED="1717542634047" MODIFIED="1717542682519">
<node TEXT="Groups And Roles" FOLDED="true" ID="ID_60879528" CREATED="1717542689324" MODIFIED="1717542692782">
<node TEXT="First Time Only" FOLDED="true" ID="ID_1092773441" CREATED="1717543404078" MODIFIED="1717543581701">
<font ITALIC="true"/>
<node TEXT="Add Breeding Group Name Column" ID="ID_1328058980" CREATED="1717543409340" MODIFIED="1717543417332"/>
</node>
<node TEXT="copy cells under BGPSL and ROLSL" ID="ID_92594064" CREATED="1717543584621" MODIFIED="1717543792942"/>
<node TEXT="Paste into new user Properties window" ID="ID_1913093976" CREATED="1717543793374" MODIFIED="1717543815439"/>
<node TEXT="OK for both Properties Windows" ID="ID_1106676294" CREATED="1717543817416" MODIFIED="1717543828220"/>
<node TEXT="Save" ID="ID_270807229" CREATED="1717543829196" MODIFIED="1717543831068"/>
</node>
</node>
</node>
<node TEXT="Method 2 (confirms role in breeding group ): Add Authorizations Directly To Breeding Groups" FOLDED="true" ID="ID_970114290" CREATED="1717544329953" MODIFIED="1717695455476">
<font BOLD="true"/>
<node TEXT="Toolkit .. Support Tools .. Breeding Groups" FOLDED="true" ID="ID_1940172352" CREATED="1717538677106" MODIFIED="1717544486859">
<node TEXT="Query for needed breeding groups" FOLDED="true" ID="ID_1849456578" CREATED="1717544491071" MODIFIED="1717544505764">
<node TEXT="Add to Breeding Groups Window" ID="ID_879400993" CREATED="1717544643178" MODIFIED="1717544651189"/>
</node>
<node TEXT="View Properties For Each Breeding Group" FOLDED="true" ID="ID_1125388827" CREATED="1717544662715" MODIFIED="1717544672585">
<node TEXT="Rights And Roles" FOLDED="true" ID="ID_1135715727" CREATED="1717544675260" MODIFIED="1717544680181">
<node TEXT="Setup Default Profile (First Time Only)" FOLDED="true" ID="ID_1126104784" CREATED="1717544829243" MODIFIED="1717695597030">
<font ITALIC="true"/>
<node TEXT="Security Role Selector" ID="ID_1038148850" CREATED="1717544858211" MODIFIED="1717544864997"/>
<node TEXT="Security Role Traits .. Security Role Name " ID="ID_396859441" CREATED="1717544794323" MODIFIED="1717544814540"/>
<node TEXT="Code" ID="ID_1066342002" CREATED="1717544871749" MODIFIED="1717544876322"/>
<node TEXT="Access Rights Traits .. Name" ID="ID_1058007419" CREATED="1717544733802" MODIFIED="1717544848692"/>
</node>
<node TEXT="Sort by ROLSL" ID="ID_220585894" CREATED="1717544698915" MODIFIED="1717544719145"/>
</node>
<node TEXT="Members" FOLDED="true" ID="ID_1064648895" CREATED="1717544506115" MODIFIED="1717545234013">
<node TEXT="New Record" FOLDED="true" ID="ID_1822350842" CREATED="1717545268795" MODIFIED="1717545288366">
<node TEXT="ROLSL = {role}" ID="ID_901508509" CREATED="1717545294357" MODIFIED="1717545310060"/>
<node TEXT="CODE = {user code}" ID="ID_403667375" CREATED="1717545310639" MODIFIED="1717545323393"/>
<node TEXT="rest should auto-populate" ID="ID_1654461033" CREATED="1717545396582" MODIFIED="1717545424430"/>
</node>
</node>
<node TEXT="Close Property Page" ID="ID_30760497" CREATED="1717545433088" MODIFIED="1717545443045"/>
<node TEXT="Save" ID="ID_56436622" CREATED="1717545443502" MODIFIED="1717545445030"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Support ticket to the Spirit queue  to document the new user and the approvals for this new user" FOLDED="true" ID="ID_369399511" CREATED="1718292654886" MODIFIED="1718292693085">
<node TEXT="Attach Approvals" ID="ID_1286794000" CREATED="1718293274344" MODIFIED="1718293282737"/>
<node TEXT="This should include the request for the user to be added the SPIRIT distribution List (DL)." FOLDED="true" ID="ID_1947153139" CREATED="1718292705264" MODIFIED="1718292706911">
<node TEXT="Example" FOLDED="true" ID="ID_1481192320" CREATED="1718293252474" MODIFIED="1718293254513">
<node TEXT="From: Gardiner Michele USNM &lt;michele.gardiner@syngenta.com&gt;" ID="ID_764825229" CREATED="1718293256199" MODIFIED="1718293256199" LINK="mailto:michele.gardiner@syngenta.com"/>
<node TEXT="Sent: Thursday, May 16, 2024 6:55 PM" ID="ID_280650798" CREATED="1718293256199" MODIFIED="1718293256199"/>
<node TEXT="To: Syngenta Employee Services &lt;syngenta@service-now.com&gt;" ID="ID_1138437540" CREATED="1718293256200" MODIFIED="1718293256200" LINK="mailto:syngenta@service-now.com"/>
<node TEXT="Cc: McMillen Michael USRE &lt;michael.mcmillen@syngenta.com&gt;" ID="ID_1497817188" CREATED="1718293256201" MODIFIED="1718293256201" LINK="mailto:michael.mcmillen@syngenta.com"/>
<node TEXT="Subject: Create - SYN-NA-SPIRIT Michael McMillen (u581917) is a new member of the Applied Genetics team as a Data Stewardship Analyst." ID="ID_1476543642" CREATED="1718293256201" MODIFIED="1718293256201"/>
<node TEXT="Michael McMillen (u581917) is a new member of the Applied Genetics team as a Data Stewardship Analyst.  Michael has been given the crop administration role in vegetable crops for SPIRIT.   Michele Gardiner (gardimi1) will be retiring in 2024 and Michael will be assuming many of Michele&apos;s current activities.  Attached is the approval/request from Michael’s line manager." ID="ID_820516945" CREATED="1718293256202" MODIFIED="1718293256202"/>
<node TEXT="Please provide SPIRIT thru CITRIX access, an X Drive if necessary.  IT appears that Michael does have the membership in the SPIRIT distributions list." ID="ID_41293888" CREATED="1718293256203" MODIFIED="1718293256203"/>
<node TEXT="Regards," ID="ID_1697905507" CREATED="1718293256204" MODIFIED="1718293256204"/>
</node>
</node>
</node>
<node TEXT="You will also need to create a support ticket to request CITRIX account and X drive." FOLDED="true" ID="ID_1140987262" CREATED="1718292717125" MODIFIED="1718292720031">
<node TEXT="INFRA-AWS-CITRIX?" ID="ID_232867893" CREATED="1718311913547" MODIFIED="1718311968705"/>
<node TEXT="For CITRIX Access Issues, Kindly contact CITRIX Team." ID="ID_1537905749" CREATED="1718312020420" MODIFIED="1718312020420"/>
<node TEXT="CITRIX Team member “Satheesh.Sundharam@syngenta.com “." ID="ID_1828697944" CREATED="1718312020420" MODIFIED="1718312020420" LINK="mailto:Satheesh.Sundharam@syngenta.com"/>
<node TEXT="Here is the queue that needs to use (as best I know) for  SYN-GLOBAL-AWSCITRIX-SUPPORT" ID="ID_1301683117" CREATED="1718312020420" MODIFIED="1718312020420"/>
</node>
<node TEXT="Send Onboarding Email (see Template)" FOLDED="true" ID="ID_24445179" CREATED="1717523987349" MODIFIED="1718379823825">
<node TEXT="Allan" ID="ID_1516149945" CREATED="1718256499021" MODIFIED="1718378706043">
<icon BUILTIN="yes"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="button_ok"/>
<attribute NAME="When" VALUE="6/13/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-06-13T00:00-0400|date"/>
<attribute NAME="WhenDone" VALUE="2024-06-14" OBJECT="org.freeplane.features.format.FormattedDate|2024-06-14T11:25-0400|yyyy-MM-dd"/>
</node>
</node>
</node>
<node TEXT="Add user to MINT" FOLDED="true" POSITION="bottom_or_right" ID="ID_415290647" CREATED="1719338814698" MODIFIED="1719338820000">
<node TEXT="Line Manager needs to be responsible for" FOLDED="true" ID="ID_1836703073" CREATED="1720626872989" MODIFIED="1720626908164">
<node TEXT="Leads" ID="ID_1964743291" CREATED="1720626892127" MODIFIED="1720626904982"/>
<node TEXT="Create Guide for Crop Head" FOLDED="true" ID="ID_1191006411" CREATED="1719339884821" MODIFIED="1720626429698">
<icon BUILTIN="yes"/>
<node TEXT="Screen shots" ID="ID_1147919782" CREATED="1720626974842" MODIFIED="1720626980822"/>
<node TEXT="Correct Access" ID="ID_1358228969" CREATED="1720626981758" MODIFIED="1720626986886"/>
</node>
</node>
<node TEXT="Move to Teams" ID="ID_1437541946" CREATED="1719339889896" MODIFIED="1719339894386"/>
<node TEXT="Roles" FOLDED="true" ID="ID_219489009" CREATED="1719338969326" MODIFIED="1719338971287">
<node TEXT="Material Owner" ID="ID_1592850490" CREATED="1719338983293" MODIFIED="1719340142463"/>
<node TEXT="MIR" FOLDED="true" ID="ID_804941203" CREATED="1719338985118" MODIFIED="1719338987199">
<node TEXT="No Crop Neccessary" ID="ID_999086849" CREATED="1719338989993" MODIFIED="1719339003552"/>
<node TEXT="Only for documenting" ID="ID_1231149606" CREATED="1719339006047" MODIFIED="1719339016736"/>
<node TEXT="Germ Compliance Team" ID="ID_948110772" CREATED="1719339020185" MODIFIED="1719339025728"/>
</node>
<node TEXT="ID Add BM" FOLDED="true" ID="ID_1934074119" CREATED="1719339043953" MODIFIED="1719339056342">
<node TEXT="Allows Bulk Manual Add Identity" ID="ID_1540881248" CREATED="1719339057078" MODIFIED="1719339099478"/>
<node TEXT="Limit access Add BM" FOLDED="true" ID="ID_706018405" CREATED="1719338727172" MODIFIED="1719339108187">
<font BOLD="true"/>
<node TEXT="Only if neccessary" ID="ID_1163199813" CREATED="1719338898264" MODIFIED="1719338903095"/>
<node TEXT="Train First before Add BM" FOLDED="true" ID="ID_430587196" CREATED="1719338829612" MODIFIED="1719338897392">
<node TEXT="Create Training Material to Share" ID="ID_1979966048" CREATED="1720626440979" MODIFIED="1721055020348">
<icon BUILTIN="yes"/>
<attribute NAME="When" VALUE="7/10/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-07-10T00:00-0400|date"/>
</node>
</node>
<node TEXT="Consolidate" ID="ID_823663534" CREATED="1720627243919" MODIFIED="1720627272751">
<icon BUILTIN="help"/>
</node>
</node>
</node>
<node TEXT="ID Process Lead" FOLDED="true" ID="ID_1790558400" CREATED="1719339178243" MODIFIED="1719339184781">
<node TEXT="Linit Access" ID="ID_486728174" CREATED="1719339219100" MODIFIED="1719339224950"/>
<node TEXT="allows overide exceptions" ID="ID_1775769345" CREATED="1719339185591" MODIFIED="1719339216286"/>
</node>
</node>
<node ID="ID_11444056" TREE_ID="ID_706018405">
<node ID="ID_628180338" TREE_ID="ID_1163199813"/>
<node ID="ID_1207345676" TREE_ID="ID_430587196">
<node ID="ID_573362717" TREE_ID="ID_1979966048"/>
</node>
<node ID="ID_684604154" TREE_ID="ID_823663534"/>
</node>
<node TEXT="Team Manager adds User to MINT" FOLDED="true" ID="ID_340756567" CREATED="1718229516068" MODIFIED="1718229527314">
<node TEXT="Team Manager Submits MINT Production Support Tickets (Bubble with ? in it, top right)" FOLDED="true" ID="ID_862532811" CREATED="1716481039979" MODIFIED="1718036441832">
<node TEXT="previous process" FOLDED="true" ID="ID_1466471977" CREATED="1718036443437" MODIFIED="1718036451869">
<node TEXT="Michele submits ticket" ID="ID_962807128" CREATED="1718036452151" MODIFIED="1718036459881"/>
</node>
<node TEXT="Region &gt; Global for All Veg Crops" ID="ID_353952582" CREATED="1716481217266" MODIFIED="1716481278691"/>
<node TEXT="Description for used for documentation, not seen" ID="ID_714260965" CREATED="1719340236812" MODIFIED="1719340375632"/>
<node TEXT="Scenario" FOLDED="true" ID="ID_1649995591" CREATED="1716481285154" MODIFIED="1716481287522">
<node TEXT="Add manual adds" FOLDED="true" ID="ID_976087933" CREATED="1716481101809" MODIFIED="1716481106677">
<node TEXT="need Role Type of add BM and material owner" FOLDED="true" ID="ID_124258690" CREATED="1716481106803" MODIFIED="1716481319097">
<node TEXT="BM: Biological Material" ID="ID_423465980" CREATED="1716481368866" MODIFIED="1716481378204"/>
</node>
<node ID="ID_1135377434" CREATED="1716481984558" MODIFIED="1716481984558" LINK="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/_layouts/15/Doc2.aspx?action=edit&amp;amp;sourcedoc=%7Ba4ebfc5b-3f27-4b54-b8c5-3e7c20e8cb65%7D&amp;amp;wdOrigin=TEAMS-MAGLEV.teamsSdk_ns.rwc&amp;amp;wdExp=TEAMS-TREATMENT&amp;amp;wdhostclicktime=1716481791865&amp;amp;web=1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/:p:/r/sites/TransitionData/_layouts/15/Doc2.aspx?action=edit&amp;sourcedoc=%7Ba4ebfc5b-3f27-4b54-b8c5-3e7c20e8cb65%7D&amp;wdOrigin=TEAMS-MAGLEV.teamsSdk_ns.rwc&amp;wdExp=TEAMS-TREATMENT&amp;wdhostclicktime=1716481791865&amp;web=1">Manual_Adds_Guidelines_IdentityManagement_V1.pptx</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="X Team" FOLDED="true" POSITION="bottom_or_right" ID="ID_1575588546" CREATED="1719413423726" MODIFIED="1719413426217">
<node TEXT="Spirit Support Team request" ID="ID_1530992503" CREATED="1719413426456" MODIFIED="1719413437556"/>
</node>
</node>
</node>
</node>
<node TEXT="Troubleshooting" FOLDED="true" POSITION="bottom_or_right" ID="ID_1699861213" CREATED="1716217998375" MODIFIED="1716218002465">
<node TEXT="Login" FOLDED="true" ID="ID_76974230" CREATED="1719947595771" MODIFIED="1719947597700">
<node TEXT="Run Group Policy Update" ID="ID_547897846" CREATED="1719947603007" MODIFIED="1719947612101"/>
<node TEXT="Restart" ID="ID_25472181" CREATED="1719947612799" MODIFIED="1719947615200"/>
</node>
<node TEXT="Poor Performance:" FOLDED="true" ID="ID_179774948" CREATED="1718225208122" MODIFIED="1718225245735">
<node TEXT="Close Spirit" FOLDED="true" ID="ID_1323773770" CREATED="1718225248334" MODIFIED="1718225254592">
<node TEXT="Clear Cache in local folder" ID="ID_367422188" CREATED="1718225245738" MODIFIED="1718225273040"/>
</node>
<node TEXT="Reset Window Arrnagement" FOLDED="true" ID="ID_288501220" CREATED="1718225299239" MODIFIED="1718225308404">
<node TEXT="Sets Spirit factory settings" ID="ID_1642725972" CREATED="1718225309258" MODIFIED="1718225318963"/>
</node>
</node>
<node TEXT="Material Creation" FOLDED="true" ID="ID_1875661426" CREATED="1716218016285" MODIFIED="1716218016285">
<node TEXT="1. 3rd Party &amp; Interim Trial exception is totally removed while creating Material from Pollination." ID="ID_1884891462" CREATED="1716218016285" MODIFIED="1716218016285"/>
<node TEXT="2. TMR Trial Rule for Material Creation: TMR Trial should follow the full MINT process to be used as parent for pollination before create Material." FOLDED="true" ID="ID_1106374221" CREATED="1716218016285" MODIFIED="1716218016285">
<node TEXT="a. Trial Fulfillment." ID="ID_147942170" CREATED="1716218016285" MODIFIED="1716218016285"/>
<node TEXT="b. Plant Trial or Some Plot." FOLDED="true" ID="ID_100215235" CREATED="1716218016285" MODIFIED="1716218016285">
<node TEXT="i.      After you plant the plots, you need to wait few hours before use the plot, during this time MINT will response back to SPIRIT and update the PPLST to H, and get the PM_ID" ID="ID_1649552479" CREATED="1716218016285" MODIFIED="1716218016285"/>
<node TEXT="ii.      After PPLST updated to H the system will automatically send the Subplot and the Sub subplot for the updated plots and it should take few more hours to send each level and once response received PM_ID will be added to the Subplot. Then you will be able to use those subplots for pollinations" ID="ID_1790269279" CREATED="1716218016285" MODIFIED="1716218016285"/>
</node>
</node>
<node TEXT="3. None TMR Trial Rule for Material Creation:" FOLDED="true" ID="ID_1268029979" CREATED="1716218016285" MODIFIED="1716218016285">
<node TEXT="a. For none TMR trial you should set the Plant Date on the Trial Level, then SPIRIT will automatically send the root plot to MINT and within few hours MINT should send the response to SPIRIT with the PM_ID and this should take few hours to complete." ID="ID_1334052747" CREATED="1716218016285" MODIFIED="1716218016285"/>
<node TEXT="b. Once PM_ID received on the root level, system will automatically send the Subplot and the Sub subplot for the updated plots and it should take few more hours to send each level and once response received PM_ID will be added to the Subplot. Then you will be able to use those subplots for pollinations." ID="ID_1685516856" CREATED="1716218016285" MODIFIED="1716218016285"/>
</node>
</node>
<node TEXT="Show/hide &amp; Query tool issue :" FOLDED="true" ID="ID_1563782770" CREATED="1716218016285" MODIFIED="1716218016285">
<node TEXT="• If you face an error while opening Query tool or Show / hide tools, clear the cache folder" FOLDED="true" ID="ID_873201662" CREATED="1716218016286" MODIFIED="1716218016286">
<node TEXT="○ If you are using Local SPIRIT navigate to SPIRIT folder “C:\Program Files (x86)\Syngenta\SPIRIT\” and delete the folder “Cache”" ID="ID_556910106" CREATED="1716218016286" MODIFIED="1716218016286"/>
<node TEXT="○ If you are using SPIRIT CITRIX navigate to X drive folder “X:\” and delete the folder “Cache”" ID="ID_1018171218" CREATED="1716218016286" MODIFIED="1716218016286"/>
</node>
</node>
<node TEXT="R issue :" FOLDED="true" ID="ID_1675378060" CREATED="1716218016286" MODIFIED="1716218016286">
<node TEXT="• If you receive this error &quot;Trial ************** failed to commit because R could not be started&quot;," ID="ID_1829335274" CREATED="1716218016286" MODIFIED="1716218016286"/>
<node TEXT="This might be happening because there is another higher version of R installed on your computer and conflicts with the version that is installed automatically with SPIRIT (R version 3.0.2)." ID="ID_1436970477" CREATED="1716218016286" MODIFIED="1716218016286"/>
<node TEXT="If there is no other version installed on your computer, then please repair SPIRIT using the bat files found in C:\Program Files (x86)\Syngenta\SPIRIT\CommonFixes, and try again." ID="ID_285028125" CREATED="1716218016286" MODIFIED="1716218016286"/>
</node>
<node TEXT="Crystal Reports" FOLDED="true" ID="ID_1928314913" CREATED="1719947669210" MODIFIED="1719947669210">
<node TEXT="If reports are missing, change directory and restart" ID="ID_1386317309" CREATED="1719947669210" MODIFIED="1719947669210"/>
<node TEXT="Make sure Message window is visible" ID="ID_305359507" CREATED="1719947669211" MODIFIED="1719947669211"/>
</node>
</node>
</node>
<node TEXT="Data Catalog" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_145631734" CREATED="1719411525020" MODIFIED="1731789128970">
<node ID="ID_729315876" CREATED="1719411546006" MODIFIED="1719411587589"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 12pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">Welcome to the&#xa0;</span><a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/" data-linkindex="0" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">Syngenta Data Catalog</span></a><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 12pt; line-height: inherit; font-family: inherit; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">, where you can find, understand, trust, govern, use, and reuse data.</span>
    </p>
    <p class="x_MsoPlainText" aria-hidden="true" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      &#xa0;
    </p>
    <ul type="disc" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-top: 0in">
      <li class="x_MsoPlainText">
        <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: inherit; line-height: inherit; font-family: Segoe UI Emoji, sans-serif, serif, EmojiFont; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">🚪</span>&#xa0;Visit the&#xa0;<b><a data-auth="NotApplicable" href="https://help.alation.com/" data-linkindex="1" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span data-ogsc="rgb(68, 114, 196)" style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(68, 114, 196) !important;">Alation Help Center</span></a><span style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(68, 114, 196) !important;">&#xa0;</span></b>and click the SIGN UP button to gain access to:
      </li>
      <ul type="disc" style="margin-top: 0in">
        <li class="x_MsoPlainText">
          <b>Alation University:</b>&#xa0;&#xa0;self-paced videos for learning the Alation Data Intelligence platform. Earn Brilliance Badges to ‘show what you know’ once you complete the associated Alation courses and pass a short exam.
        </li>
      </ul>
    </ul>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-left: 58.5pt">
      The “<b><span style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(237, 125, 49);">Data Catalog Basics</span></b>” course is highly recommended for all catalog users.
    </p>
    <ul type="disc" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-top: 0in">
      <ul type="disc" style="margin-top: 0in">
        <li class="x_MsoPlainText">
          <b>Community</b>: interact and engage with other Alation customers, employees, and selected partners through discussions, Q&amp;A, blogs, and events.&#xa0;
        </li>
        <li class="x_MsoPlainText">
          <b>Documentation:</b>&#xa0;full documentation for all parts of the Alation product.
        </li>
        <li class="x_MsoPlainText">
          <b>Developer APIs:&#xa0;</b>library of Alation public restful APIs, including full documentation, instructions on how to use, and some ‘recipes’ that illustrate use cases.
        </li>
        <li class="x_MsoPlainText">
          <b>Knowledge Base:</b>&#xa0;created by Alation engineers as they support and use the product. Contains information for troubleshooting, workarounds, error messages, best practices, and other real-time issue handling.&#xa0;
        </li>
        <li class="x_MsoPlainText">
          <b>Alation Ideation Portal:&#xa0;</b>a dedicated space where you can share your ideas, vote on existing requests, and collaborate with other users.
        </li>
      </ul>
    </ul>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-left: 40.5pt">
      <b>&#xa0;</b>
    </p>
    <ul type="disc" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-top: 0in">
      <li class="x_MsoPlainText">
        <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: inherit; line-height: inherit; font-family: Segoe UI Emoji, sans-serif, serif, EmojiFont; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">🏁</span>&#xa0;Complete the steps in&#xa0;<b><a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/article/1550/" data-linkindex="2" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">Get Started!</span></a></b>&#xa0;
      </li>
    </ul>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-left: 4.5pt">
      <b>&#xa0;</b>
    </p>
    <ul type="disc" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-top: 0in">
      <li class="x_MsoPlainText" style="margin-bottom: 12pt">
        <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 16pt; line-height: inherit; font-family: Segoe UI Emoji, sans-serif, serif, EmojiFont; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">☕</span>&#xa0;The<span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(197, 90, 17) !important;">&#xa0;</span><b><a data-auth="NotApplicable" href="https://syngenta.alationcloud.com/article/2403/" data-linkindex="3" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span data-ogsc="rgb(132, 60, 12)" style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: rgb(132, 60, 12) !important;">Data Coffee Breaks</span></a></b>&#xa0;page allows you to register for up-coming brief webinars on data-related topics. Watch recordings and view Q&amp;A from past sessions.
      </li>
      <li class="x_MsoPlainText" style="line-height: 17.25px">
        <span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: inherit; font-variant: inherit; font-weight: normal; font-size: 14pt; line-height: 21.4667px; font-family: Segoe UI Emoji, sans-serif, serif, EmojiFont; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">❗</span>&#xa0;By creating an Alation account, you will have Read access to query the<b>&#xa0;SmartMart</b>&#xa0;database.&#xa0;<b>You will receive an email containing your database credentials</b>&#xa0;<b>within 24 hours after creating your account</b>.
      </li>
    </ul>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-left: 22.5pt; line-height: 17.25px">
      <b><span data-ogsc="red" style="font-weight: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">**</span>&#xa0;If you do not receive the email after&#xa0;<u>24 hours</u></b>, submit a ticket to the D&amp;A Service Center (<i>see instructions on the&#xa0;<a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/data/56/" data-linkindex="4" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="font-style: normal; border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">SmartMart Data Source</span></a>&#xa0;page</i>).
    </p>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-left: 22.5pt; line-height: 17.25px">
      Note that some HR and Finance data contain sensitive information requiring additional privileges - see&#xa0;<a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/article/2063/" data-linkindex="5" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">Gaining Access to MIO Database Objects</span></a>.
    </p>
    <ul type="disc" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-top: 0in">
      <ul type="disc" style="margin-top: 0in">
        <li class="x_MsoPlainText">
          Find the&#xa0;<a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/glossary/8/" data-linkindex="6" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">Managed Information Objects (MIO)</span></a>&#xa0;Data Products,<span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span><span data-ogsc="black" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">database views optimized for reporting and analytics.</span>
        </li>
        <li class="x_MsoPlainText">
          Subscribe to the&#xa0;<a data-auth="NotApplicable" href="https://videos.syngenta.com/channel/Data+Exploration+and+Visualization/138232861/subscribe" data-linkindex="7" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">“Data Exploration and Visualization” video channel</span></a>&#xa0;for videos based on Syngenta’s Data Catalog and SmartMart.
        </li>
      </ul>
    </ul>
    <p class="x_MsoPlainText" aria-hidden="true" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-left: 58.5pt; line-height: 17.25px">
      &#xa0;
    </p>
    <ul type="disc" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); margin-top: 0in">
      <li class="x_MsoPlainText" style="margin-bottom: 12pt">
        Check out&#xa0;<a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/article/1630/" data-linkindex="8" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">All Data Sources Available in the Catalog</span></a><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span><span data-ogsc="black" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">including</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span>those that are private&#xa0;<span data-ogsc="black" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">and how</span><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">&#xa0;</span>to&#xa0;<span data-ogsc="black" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; color: black;">request access to them</span>.
      </li>
      <li class="x_MsoPlainText" style="line-height: 22.5px">
        Use the&#xa0;<a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/" data-linkindex="9" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">Homepage</span></a>&#xa0;as a resource for important Alerts regarding maintenance, known issues, upcoming events, tips, etc. concerning the Data Catalog.
      </li>
    </ul>
    <p class="x_MsoPlainText" aria-hidden="true" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      &#xa0;
    </p>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      If you have colleagues who need accounts, send them the&#xa0;<a data-auth="NotApplicable" href="https://syngenta.alationcloud.com/" data-linkindex="10" data-ogsc="" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-variant: normal; font-weight: normal; font-size: inherit; line-height: normal; font-family: SansSerif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline;">Alation Data Catalog URL</span></a>&#xa0;to initiate the registration process.
    </p>
    <p class="x_MsoPlainText" aria-hidden="true" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      &#xa0;
    </p>
    <p class="x_MsoNormal" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      We hope the Data Catalog helps you in your work.&#xa0;Let us know if you have questions or suggestions, or if you have a specific use case for the catalog that you would like to discuss.
    </p>
    <p class="x_MsoNormal" aria-hidden="true" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      &#xa0;
    </p>
    <p class="x_MsoPlainText" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      Best regards,
    </p>
    <p class="x_MsoNormal" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      Sharon and Sue
    </p>
    <p class="x_MsoNormal" aria-hidden="true" style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 15px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)">
      &#xa0;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Architecture" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1623501277" CREATED="1718897618198" MODIFIED="1731789128970">
<node TEXT="reference" FOLDED="true" ID="ID_223973021" CREATED="1718897621697" MODIFIED="1718897623303">
<node ID="ID_274485386" CREATED="1718897624373" MODIFIED="1718897624373" LINK="https://syngenta.sharepoint.com/sites/AnalyticsDataSciences/Shared%20Documents/Forms/AllItems.aspx?FolderCTID=0x01200020841FE99306DD4DBB1B7A3CD57158AC&amp;amp;id=%2Fsites%2FAnalyticsDataSciences%2FShared%20Documents%2FGeneral%2FPrograms%2FProgram%20%2D%20DS%20%2D%20Trialing%20%26%20Operations%20%28Digital%29%2FTrialing%20Platform%20%2D%20Vendor%20Transition%2FSpirit%20KT%20Documentation%2FSPIRIT%20Architecture"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/AnalyticsDataSciences/Shared%20Documents/Forms/AllItems.aspx?FolderCTID=0x01200020841FE99306DD4DBB1B7A3CD57158AC&amp;id=%2Fsites%2FAnalyticsDataSciences%2FShared%20Documents%2FGeneral%2FPrograms%2FProgram%20%2D%20DS%20%2D%20Trialing%20%26%20Operations%20%28Digital%29%2FTrialing%20Platform%20%2D%20Vendor%20Transition%2FSpirit%20KT%20Documentation%2FSPIRIT%20Architecture">DEA - Seeds R&amp;D - SPIRIT Architecture - All Documents</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="User Documentation" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_1593588919" CREATED="1718303138912" MODIFIED="1731789128971">
<node TEXT="Delete Trial" FOLDED="true" ID="ID_1082409312" CREATED="1718303250304" MODIFIED="1718303259427">
<node TEXT="No if sent to TMR" ID="ID_229512904" CREATED="1718303260434" MODIFIED="1718303271999"/>
<node TEXT="Wait if want to remake" ID="ID_1610043532" CREATED="1718303272992" MODIFIED="1718303311664"/>
</node>
<node ID="ID_1475506258" CREATED="1719514920105" MODIFIED="1719514920105" LINK="https://syngenta-my.sharepoint.com/:w:/r/personal/michele_gardiner_syngenta_com/Documents/Physical%20Material%20ID.docx?d=w3d2bfae3424442eeae65fffa9272475a&amp;amp;csf=1&amp;amp;web=1&amp;amp;e=zHBX1c"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta-my.sharepoint.com/:w:/r/personal/michele_gardiner_syngenta_com/Documents/Physical%20Material%20ID.docx?d=w3d2bfae3424442eeae65fffa9272475a&amp;csf=1&amp;web=1&amp;e=zHBX1c">Physical Material ID.docx</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_876865427" CREATED="1716010615506" MODIFIED="1731789128971" LINK="https://syngenta.sharepoint.com/_layouts/15/sharepoint.aspx?&amp;amp;login_hint=michael.mcmillen@syngenta.com"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/_layouts/15/sharepoint.aspx?&amp;login_hint=michael.mcmillen@syngenta.com">SharePoint</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Red Shift" LOCALIZED_STYLE_REF="AutomaticLayout.level,3" FOLDED="true" ID="ID_227707494" CREATED="1719412128923" MODIFIED="1731789128972">
<node ID="ID_505792269" CREATED="1719412133799" MODIFIED="1719412133799" LINK="https://syngenta.eu.alationcloud.com/data/56/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Dear McMillen Michael USRE,</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Your Redshift user has been created successfully.</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Redshift URL: rs-db-prod.smartmart.syngentaaws.org</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Username: u581917</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Password: 34uTv4f%VpZ</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Please keep your login credentials secure.</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">If you need any support, please create a request in SNOW</span><br style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);"/><span style="color: rgb(0, 0, 0); font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; font-size: 14.6667px; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">Details can be found here&#xa0;</span><a data-auth="NotApplicable" href="https://syngenta.eu.alationcloud.com/data/56/" data-linkindex="0" data-ogsc="" id="LPlnk377677" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-weight: 400; font-size: 14.6667px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255)"><span style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; font-style: normal; font-weight: 400; font-size: 14.6667px; line-height: inherit; font-family: Segoe UI, Segoe UI Web(West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; vertical-align: baseline; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255);">https://syngenta.eu.alationcloud.com/data/56/</span></a>
  </body>
</html>
</richcontent>
</node>
</node>
<node LOCALIZED_STYLE_REF="AutomaticLayout.level,3" ID="ID_1116303408" CREATED="1719413966647" MODIFIED="1731789128973" LINK="https://syngenta.sharepoint.com/sites/workapps/en"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.sharepoint.com/sites/workapps/en">Pages - mySyngenta ǀ Workapps</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Test" POSITION="top_or_left" ID="ID_1265013031" CREATED="1745527614429" MODIFIED="1745527614431" LINK="Life_Map.mm"/>
</node>
</map>
