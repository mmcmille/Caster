<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="Website Access" FOLDED="false" ID="ID_688584435" CREATED="1520105743090" MODIFIED="1703057124164" LINK="LifeMgmt.mm">
<icon BUILTIN="password"/>
<edge DASH="SOLID"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<hook NAME="MapStyle" background="#000000">
    <properties show_icon_for_attributes="true" show_note_icons="true" followedMapLastTime="0" followedTemplateLocation="file:/C:/GD_sync/My%20Google%20Docs/Administrative/MindMaps/LifeMgmt.mm" fit_to_viewport="false;"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" ID="ID_1901831083" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="oval" UNIFORM_SHAPE="true" TEXT_ALIGN="LEFT" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="24"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_800897947" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" NUMBERED="false" FORMAT="STANDARD_FORMAT" TEXT_ALIGN="LEFT" TEXT_WRITING_DIRECTION="LEFT_TO_RIGHT" MAX_WIDTH="120 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#808080" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="AUTO" VGAP_QUANTITY="2 pt" COMMON_HGAP_QUANTITY="14 pt">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_800897947" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Arial" SIZE="9" BOLD="true" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#333333" WIDTH="3"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/html"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/html"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="11"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.tags">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge STYLE="hide_edge" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#1e3360" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#203868"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<icon BUILTIN="yes"/>
<edge COLOR="#333333"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" ID="ID_1608195484" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="22" BOLD="false" ITALIC="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="20" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="18" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="16" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<font BOLD="true"/>
<node POSITION="top_or_left" ID="ID_750041802" CREATED="1548258614916" MODIFIED="1597263027937" LINK="https://passwordsgenerator.net/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://passwordsgenerator.net/">Strong Random Password Generator</a>
  </body>
</html>
</richcontent>
<font SIZE="12"/>
</node>
<node TEXT="Syngenta" FOLDED="true" POSITION="bottom_or_right" ID="ID_296060685" CREATED="1520106000129" MODIFIED="1630993605796">
<font BOLD="false"/>
<node ID="ID_773619648" CREATED="1519763433885" MODIFIED="1537803885728"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Administrative
    </p>
  </body>
</html>
</richcontent>
<node TEXT="General Information" FOLDED="true" ID="ID_199974911" CREATED="1519763817534" MODIFIED="1519763825060">
<node FOLDED="true" ID="ID_1316718148" CREATED="1519763433899" MODIFIED="1536597948273"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Employee ID#:
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_814210848" CREATED="1536597949426" MODIFIED="1536597949426"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      08610841
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1567384469" CREATED="1536597949426" MODIFIED="1562164222736"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      8610841
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_91827694" CREATED="1519763434226" MODIFIED="1519763434226"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Phone/Fax
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1973089696" CREATED="1519763434229" MODIFIED="1519763434229"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      dial 9 for outside line, then 1- area code-#
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_610754027" CREATED="1519763433903" MODIFIED="1519763433903"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Hire Date: 10/12/09
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_319793898" CREATED="1519763433915" MODIFIED="1519763433915"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      U581917
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1256501387" CREATED="1519763433919" MODIFIED="1519763433919"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Organizational<span>&#160; </span>Chart
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_781325764" CREATED="1519763433923" MODIFIED="1519763433923" LINK="http://frihvwappwnlp01.prc.syngenta.org/EmpEcharts/EmployeeChart.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://frihvwappwnlp01.prc.syngenta.org/EmpEcharts/EmployeeChart.htm">http://frihvwappwnlp01.prc.syngenta.org/EmpEcharts/EmployeeChart.htm</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1898954223" CREATED="1519763433928" MODIFIED="1519763433928"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Document Management
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_584473686" CREATED="1557328109570" MODIFIED="1557328123477" LINK="http://seedsreliance.syngentaazure.org/rel_seedsprod/reliance?ETQ$CMD=CMD_OPEN_APP&amp;ETQ$APPLICATION_NAME=DOCWORK&amp;ETQ$SCREEN_WIDTH=1920"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://seedsreliance.syngentaazure.org/rel_seedsprod/reliance?ETQ$CMD=CMD_OPEN_APP&amp;ETQ$APPLICATION_NAME=DOCWORK&amp;ETQ$SCREEN_WIDTH=1920">Reliance - Document Management</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Vacation / Leave" FOLDED="true" ID="ID_1294508274" CREATED="1547234896244" MODIFIED="1547234901529">
<node TEXT="Fill out vacation form" ID="ID_1268430669" CREATED="1547234906388" MODIFIED="1547234920400"/>
<node FOLDED="true" ID="ID_754246011" CREATED="1519763433937" MODIFIED="1519763886896"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Leave Management
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Unum - Blake" ID="ID_1278386115" CREATED="1561560654599" MODIFIED="1561560660051"/>
<node ID="ID_1568074624" CREATED="1561560713913" MODIFIED="1561560713913" LINK="https://services.unum.com/CLMSTTS/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://services.unum.com/CLMSTTS/">UNUM CLAIMS</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Parental Leave" FOLDED="true" ID="ID_1285603410" CREATED="1555366253949" MODIFIED="1555366258119">
<node TEXT="Fill out form min 30 days before leave" FOLDED="true" ID="ID_913412784" CREATED="1555366259115" MODIFIED="1555366271628">
<node TEXT="Jul 12" ID="ID_57537197" CREATED="1555366288474" MODIFIED="1555366291474"/>
</node>
</node>
</node>
<node TEXT="Purchasing / Travel" FOLDED="true" ID="ID_414485566" CREATED="1541524280404" MODIFIED="1541524310026">
<node TEXT="Veronica&apos;s PCard" FOLDED="true" ID="ID_470144111" CREATED="1597344127195" MODIFIED="1597344136802">
<node TEXT="Veronica M Elias" ID="ID_394094913" CREATED="1597344267098" MODIFIED="1597344284789"/>
<node TEXT="4275338000696751" OBJECT="java.lang.Long|4275338000696751" ID="ID_1258342404" CREATED="1597344138525" MODIFIED="1597344349793"/>
<node TEXT="&apos;12/23" ID="ID_1766081845" CREATED="1597344176686" MODIFIED="1597344224670"/>
<node TEXT="&apos;096" ID="ID_375307000" CREATED="1597344199244" MODIFIED="1597344214116"/>
</node>
<node TEXT="Email Your Concur Receipts" FOLDED="true" ID="ID_240907803" CREATED="1532012618185" MODIFIED="1532012618185">
<node TEXT="Email receipt photos or PDF attachments to receipts@concur.com from your registered Syngenta email address (ex. firstname.lastname@syngenta.com). The next time you start an expense report, your receipts are in the mobile app or the desktop version, ready to be matched to the appropriate expense." ID="ID_787055589" CREATED="1532012618185" MODIFIED="1532012618185" LINK="mailto:receipts@concur.com"/>
</node>
<node TEXT="X PCard Expense Reports" ID="ID_866396107" CREATED="1541525480680" MODIFIED="1552316095245">
<font BOLD="true"/>
</node>
</node>
<node TEXT="Travel" FOLDED="true" ID="ID_558237230" CREATED="1524500051587" MODIFIED="1524500054907">
<node TEXT="Get Dates" ID="ID_1289892212" CREATED="1524500056883" MODIFIED="1524500060811"/>
<node TEXT="Book Flight" FOLDED="true" ID="ID_1279935504" CREATED="1541526587558" MODIFIED="1541526591152">
<node TEXT="San Jose" FOLDED="true" ID="ID_693953894" CREATED="1541526600072" MODIFIED="1541526602432">
<node TEXT="SJC" ID="ID_1508147361" CREATED="1541526592419" MODIFIED="1541526595735"/>
</node>
<node TEXT="Yuma" FOLDED="true" ID="ID_731285623" CREATED="1541526607295" MODIFIED="1541526609393">
<node TEXT="YUM" ID="ID_1495798922" CREATED="1541526596596" MODIFIED="1541526598510"/>
</node>
</node>
<node TEXT="Book Hotel" FOLDED="true" ID="ID_1469976256" CREATED="1524500062363" MODIFIED="1524500065639">
<node TEXT="Concur" ID="ID_443571237" CREATED="1524500068116" MODIFIED="1541524235876"/>
<node TEXT="Yuma" FOLDED="true" ID="ID_73826516" CREATED="1541525723456" MODIFIED="1541525725388">
<node TEXT="Holiday Inn Express &amp; Suites Yuma" ID="ID_882516635" CREATED="1568126773324" MODIFIED="1568126773324"/>
<node TEXT="2044 S Avenue 3E, Yuma, AZ 85365" ID="ID_1316528372" CREATED="1568126773324" MODIFIED="1568126773324"/>
</node>
<node TEXT="Preferences" FOLDED="true" ID="ID_208188003" CREATED="1541527268700" MODIFIED="1541527273814">
<node TEXT="Top Floor, end of hall room facing NE (away from I-8) if possible" ID="ID_553175422" CREATED="1541527275122" MODIFIED="1541527379374"/>
</node>
</node>
<node TEXT="Book Parking" ID="ID_31544449" CREATED="1568126654123" MODIFIED="1568126659322"/>
<node TEXT="Pack" FOLDED="true" ID="ID_1557696014" CREATED="1542142943777" MODIFIED="1542142947480">
<node TEXT="Checklist" FOLDED="true" ID="ID_103486523" CREATED="1543516313234" MODIFIED="1543516316639">
<node TEXT="Shoes" ID="ID_854260468" CREATED="1543516317519" MODIFIED="1543516320550"/>
<node TEXT="Sweater" ID="ID_1225813300" CREATED="1543516321619" MODIFIED="1543516329359"/>
<node TEXT="Jacket" ID="ID_1070703168" CREATED="1543516329795" MODIFIED="1543516333303"/>
</node>
<node TEXT="Baggage" FOLDED="true" ID="ID_909529724" CREATED="1542143731525" MODIFIED="1542143735378">
<node TEXT="You can carry on 1 bag and 1 personal item." FOLDED="true" ID="ID_170480474" CREATED="1542143737248" MODIFIED="1542143737248">
<node TEXT="personal item" FOLDED="true" ID="ID_804024258" CREATED="1542143789846" MODIFIED="1542143805708">
<node TEXT="Dimensions should not exceed 18 x 14 x 8 inches (45 x 35 x 20 cm )." ID="ID_1719032631" CREATED="1542143793022" MODIFIED="1542143793022"/>
</node>
<node TEXT="Carry-on" FOLDED="true" ID="ID_841512496" CREATED="1542143794777" MODIFIED="1542143812201">
<node TEXT="Shouldn’t exceed 22 x 14 x 9 inches / 56 x 36 x 23 centimeters (including handles and wheels)" ID="ID_413421214" CREATED="1542143821439" MODIFIED="1542143821439"/>
</node>
</node>
<node TEXT="Liquids, aerosols and gels in carry-on baggage" FOLDED="true" ID="ID_1486764330" CREATED="1542142951936" MODIFIED="1542142951936">
<node TEXT="There are limitations for travelling with liquids, aerosols and gels (LAGs) in your carry-on baggage. You are allowed to bring these items in your carry-on bag as long as:" ID="ID_717814698" CREATED="1542142951936" MODIFIED="1542142951936"/>
<node TEXT="The size of each LAG container does not exceed 3.4 oz (100ml). The limit is 1 (one) liter and 10 containers per passenger." ID="ID_1243692790" CREATED="1542142951951" MODIFIED="1542142951951"/>
</node>
</node>
</node>
<node TEXT="Holiday Inn" FOLDED="true" ID="ID_1651918795" CREATED="1543508315300" MODIFIED="1543508319160">
<node TEXT="Membership Number" FOLDED="true" ID="ID_169581378" CREATED="1543508319816" MODIFIED="1543508331552">
<node TEXT="252-783-086" ID="ID_446613342" CREATED="1543508332443" MODIFIED="1543508343746"/>
</node>
</node>
<node TEXT="Travel Card" ID="ID_1819648665" CREATED="1582842947467" MODIFIED="1582842954285">
<node TEXT="Bank Of America" ID="ID_1323413640" CREATED="1717623122771" MODIFIED="1717623128999">
<node ID="ID_1081817717" CREATED="1717624181794" MODIFIED="1717624181794" LINK="https://spacardportal.works.com/gar/login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://spacardportal.works.com/gar/login">Global Card Access - Login</a>
  </body>
</html>
</richcontent>
<node TEXT="bDRt8eRHbYbE$qr" ID="ID_773358921" CREATED="1717623460798" MODIFIED="1717623460798"/>
<node TEXT="mmcmillen_syn_travel" ID="ID_1968248802" CREATED="1717623435798" MODIFIED="1717623435798"/>
</node>
<node TEXT="Security Qs" ID="ID_546165427" CREATED="1717623471035" MODIFIED="1717624206582">
<node TEXT="Street" ID="ID_1815724893" CREATED="1717623480679" MODIFIED="1717623483826">
<node TEXT="Tradewinds" ID="ID_690065970" CREATED="1717623485627" MODIFIED="1717623492934"/>
</node>
<node TEXT="State Spouse" ID="ID_483879831" CREATED="1717623494323" MODIFIED="1717623498954">
<node TEXT="California" ID="ID_935793173" CREATED="1717623499879" MODIFIED="1717623513264"/>
</node>
<node TEXT="First Organization" ID="ID_382190196" CREATED="1717623514102" MODIFIED="1717623521508">
<node TEXT="Toastmasters" ID="ID_1127997709" CREATED="1717623522281" MODIFIED="1717623525613"/>
</node>
</node>
<node TEXT="pin" ID="ID_1713482173" CREATED="1717624091159" MODIFIED="1717624092339">
<node TEXT="4011" OBJECT="java.lang.Long|4011" ID="ID_570980304" CREATED="1717624150513" MODIFIED="1717624153080"/>
<node TEXT="old" ID="ID_343932610" CREATED="1717624155381" MODIFIED="1717624156597">
<node TEXT="6156" OBJECT="java.lang.Long|6156" ID="ID_1717003883" CREATED="1717624107132" MODIFIED="1717624111003"/>
</node>
</node>
<node TEXT="card" ID="ID_1645298491" CREATED="1717623153637" MODIFIED="1717623158592">
<node TEXT="5567509119527384" OBJECT="java.lang.Long|5567509119527384" ID="ID_1063663545" CREATED="1717623160176" MODIFIED="1717623183608"/>
</node>
</node>
<node TEXT="old" ID="ID_1499622580" CREATED="1717623109175" MODIFIED="1717623111584">
<node TEXT="4046588001416405" OBJECT="java.lang.Long|4046588001416405" ID="ID_659175860" CREATED="1582842955199" MODIFIED="1582842972711"/>
<node TEXT="&apos;02/25" ID="ID_137368860" CREATED="1582842973852" MODIFIED="1582842994613"/>
<node TEXT="521" OBJECT="java.lang.Long|521" ID="ID_463730042" CREATED="1582842995753" MODIFIED="1582843000508"/>
<node TEXT="4011" OBJECT="java.lang.Long|4011" ID="ID_1454990796" CREATED="1582843316798" MODIFIED="1582843318410"/>
<node TEXT="8312062683" OBJECT="java.lang.Long|8312062683" ID="ID_1919014657" CREATED="1582843244770" MODIFIED="1582843258482"/>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_1568022826" CREATED="1582843077829" MODIFIED="1582843080608"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_167659042" CREATED="1519763434232" MODIFIED="1524760158810"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Training
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Driving" FOLDED="true" ID="ID_394418553" CREATED="1524760132056" MODIFIED="1524760135687">
<node ID="ID_1576625816" CREATED="1524760139211" MODIFIED="1524760139211" LINK="https://www.alertdriving.com/trainee/index.php?module=HOME"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.alertdriving.com/trainee/index.php?module=HOME">Wheels, Inc. - Driver Training Login Page</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Regulatory (GM)" FOLDED="true" ID="ID_1258995572" CREATED="1524753780532" MODIFIED="1524753790321">
<node ID="ID_1814157117" CREATED="1519763434236" MODIFIED="1519763434236"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="file:///C:\..\T:\R&amp;T\CornSoya\Training\2017%20PDRAG-26%20Training%20Sheet.xlsx">2017 PDRAG-26 Training Sheet.xlsx</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1926386257" CREATED="1519763434244" MODIFIED="1519763434244"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="file:///C:\Users\u581917\OneDrive%20-%20Syngenta\Documents\Administrative\Regulatory%20Stewardship\Training\">Training</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_380543901" CREATED="1519763434240" MODIFIED="1519763434240" LINK="http://frgowappqmsp01/rel_prod/reliance?ETQ$SSO_LOGIN=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://frgowappqmsp01/rel_prod/reliance?ETQ$SSO_LOGIN=true">EtQ Reliance - Portal</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Safety" FOLDED="true" ID="ID_1116410222" CREATED="1522876298993" MODIFIED="1522876301906">
<node TEXT="JSAs" FOLDED="true" ID="ID_512894001" CREATED="1550076238891" MODIFIED="1550076243162">
<node TEXT="Review and Train on JSAs annually" ID="ID_690925775" CREATED="1550076252359" MODIFIED="1550076356706">
<icon BUILTIN="yes"/>
</node>
</node>
<node TEXT="Safety Observation Form" FOLDED="true" ID="ID_1337169352" CREATED="1522876304247" MODIFIED="1537825269661">
<node TEXT="SafetyObs 04-04-18.docx" ID="ID_124181981" CREATED="1522877496098" MODIFIED="1522877496099" LINK="file:/C:/Users/u581917/OneDrive%20-%20Syngenta/Documents/Administrative/Safety/SafetyObs%2004-04-18.docx"/>
</node>
<node TEXT="Submit safety observation" FOLDED="true" ID="ID_1629737520" CREATED="1537825270704" MODIFIED="1537825286739">
<node ID="ID_1231430788" CREATED="1519763433933" MODIFIED="1519763433933" LINK="http://reliance.syngentaazure.org/rel_prod/reliance?ETQ$CMD=CMD_OPEN_ETQ_HOMEPAGE"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://reliance.syngentaazure.org/rel_prod/reliance?ETQ$CMD=CMD_OPEN_ETQ_HOMEPAGE">EtQ Reliance - Home</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_484251432" CREATED="1547582784396" MODIFIED="1547582784396" LINK="http://reference/sites/policy/default.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://reference/sites/policy/default.aspx">Policies | mySyngenta</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1494004739" CREATED="1519763435856" MODIFIED="1519763435856"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Waste Management
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_16214149" CREATED="1519763435871" MODIFIED="1519763435871"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Motor Oil
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1086349285" CREATED="1519763435874" MODIFIED="1519763435874"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Autozone
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Health" FOLDED="true" ID="ID_1960592248" CREATED="1530892930395" MODIFIED="1530892936789">
<node ID="ID_1124796214" CREATED="1530892949545" MODIFIED="1530892949545" LINK="http://teamspace/ushealthservices/en/reaping%20rewards/Pages/Reaping_Rewards.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://teamspace/ushealthservices/en/reaping%20rewards/Pages/Reaping_Rewards.aspx">U.S. Health Services | mySyngenta</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1752136000" CREATED="1537205727903" MODIFIED="1537205740720" LINK="http://teamspace/ushealthservices/en/reaping%20rewards/Pages/Reaping_Rewards.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://teamspace/ushealthservices/en/reaping%20rewards/Pages/Reaping_Rewards.aspx">Home: U.S. Health Services | mySyngenta</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1401072277" CREATED="1537205898334" MODIFIED="1537205918857" LINK="http://teamspace/USHealthServices/en/Reaping%20Rewards/Pages/Physical_Exam%20Information.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://teamspace/USHealthServices/en/Reaping%20Rewards/Pages/Physical_Exam%20Information.aspx">Physical Exam Information</a>
  </body>
</html>
</richcontent>
<node TEXT="Contact Manuel Rodriguez at 1-800-867-0933 ext 2840 or mrodriguez@chr.com and provide him with the contact information for your physician." FOLDED="true" ID="ID_1678944791" CREATED="1539792801598" MODIFIED="1539792801598" LINK="mailto:mrodriguez@chr.com">
<node TEXT="US Healthworks, Gilroy, CA" ID="ID_738003182" CREATED="1539792805358" MODIFIED="1539792816575"/>
</node>
</node>
<node ID="ID_1247073790" CREATED="1519763433911" MODIFIED="1519763838462">
<icon BUILTIN="password"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      RR Health assesment pwd: syngenta1
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Shipping" FOLDED="true" ID="ID_1851026549" CREATED="1541012803812" MODIFIED="1541012806255">
<node TEXT="Recieving" ID="ID_1512767353" CREATED="1542746573095" MODIFIED="1542746580048"/>
</node>
<node TEXT="Communication" FOLDED="true" ID="ID_1497524945" CREATED="1542048959001" MODIFIED="1542048961828">
<node TEXT="BT Conferencing" FOLDED="true" ID="ID_1094930098" CREATED="1542670028535" MODIFIED="1542670037018">
<node TEXT="888.266.3096" ID="ID_1700416620" CREATED="1542670040923" MODIFIED="1542670040923"/>
</node>
<node TEXT="Teamspace" FOLDED="true" ID="ID_1808463832" CREATED="1548711455465" MODIFIED="1548711458845">
<node ID="ID_443819837" CREATED="1548711460168" MODIFIED="1548711460168" LINK="http://teamspace/sites/SVRDLET/default.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://teamspace/sites/SVRDLET/default.aspx">Home - Seeds Veg R&amp;D - Salads</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Wellness Champion" ID="ID_196366014" CREATED="1536597915683" MODIFIED="1537803885743">
<node ID="ID_1920960010" CREATED="1718129750957" MODIFIED="1718129750957" LINK="https://app.member.virginpulse.com/#/home"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://app.member.virginpulse.com/#/home">Virgin Pulse - Home</a>
  </body>
</html>
</richcontent>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_1584107378" CREATED="1718129650637" MODIFIED="1718129653430"/>
<node TEXT="Lucydog1*" ID="ID_897093991" CREATED="1718129661102" MODIFIED="1718129666090"/>
</node>
<node ID="ID_15272722" CREATED="1536597924895" MODIFIED="1536597924895" LINK="https://www.mywellsite.com/ip/default.aspx?site=syngenta"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mywellsite.com/ip/default.aspx?site=syngenta">Syngenta Wellbeing</a>
  </body>
</html>
</richcontent>
<node TEXT="8610841" OBJECT="java.lang.Long|8610841" ID="ID_1963839667" CREATED="1536598000135" MODIFIED="1536598007322"/>
<node TEXT="Lucydog1" ID="ID_514734436" CREATED="1536598007910" MODIFIED="1536598034494"/>
</node>
</node>
<node TEXT="Support" FOLDED="true" ID="ID_763395448" CREATED="1547740422673" MODIFIED="1547740425561">
<node TEXT="Update Breeder Support Calendar" ID="ID_576278333" CREATED="1547739874594" MODIFIED="1547739903563" LINK="file:/T:/SharedInformation/Shared/1-Group%20Schedules"/>
</node>
<node TEXT="Performance Management / Talent Development" FOLDED="true" ID="ID_1270671728" CREATED="1519242072765" MODIFIED="1551216854010" LINK="http://reference/sites/ykgz74s727/en/Pages/default.aspx">
<node ID="ID_1755780549" CREATED="1614296469705" MODIFIED="1614296469705" LINK="https://wd3.myworkday.com/syngenta/d/home.htmld"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://wd3.myworkday.com/syngenta/d/home.htmld">Home - Workday</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Talent Development policy" ID="ID_389261815" CREATED="1519833601544" MODIFIED="1519833639987" LINK="http://communication/sites/TalentDevelopment/en/Documents/TD-policy-final-28022012.pdf"/>
<node TEXT="Talent Review Process" ID="ID_893629131" CREATED="1519236900959" MODIFIED="1547049133887" LINK="http://communication/sites/TalentDevelopment/en/Pages/Employees.aspx">
<node TEXT="Annual Talent Review Cycle Overview of Process, Guidance and Tools" ID="ID_417257" CREATED="1519240249006" MODIFIED="1519833975835" LINK="Performance%20Management/Guide%20for%20Employees_Annual%20TR%20Cycle_20%20Feb.pptx">
<node TEXT="Purpose of Annual Talent Review Cycle" FOLDED="true" ID="ID_627940491" CREATED="1519661866996" MODIFIED="1519661866996">
<node TEXT="Identify and develop the people and organizational capabilities needed to drive future growth in line with our business strategy i.e. our talent strategy" ID="ID_1287528737" CREATED="1519661855477" MODIFIED="1519661855477"/>
<node TEXT="Mitigate business continuity risk with effective succession planning" ID="ID_843950698" CREATED="1519661855477" MODIFIED="1519661855477"/>
<node TEXT="Identify and assign career development opportunities for employees" ID="ID_1361105093" CREATED="1519661855483" MODIFIED="1519661855483"/>
<node TEXT="Ensure we are creating diverse teams and conversation" ID="ID_202337447" CREATED="1519661855484" MODIFIED="1519661855484"/>
<node TEXT="Apply a consistent methodology and process globally" ID="ID_1665123800" CREATED="1519661855484" MODIFIED="1519661855484"/>
</node>
<node TEXT="Talent Review Process: Employees Roles &amp; Responsibilities" ID="ID_1275453945" CREATED="1519662036648" MODIFIED="1519863450961">
<icon BUILTIN="yes"/>
<node TEXT="The employee is the owner of his/her own career and will need to discuss his/her career aspirations with the line manager before talent review (now recommended as part of goal setting discussion)." FOLDED="true" ID="ID_1700495843" CREATED="1519662459660" MODIFIED="1519662793710">
<icon BUILTIN="unchecked"/>
<node TEXT="A starting point of the conversation is your Employee Profile, which gives you an opportunity to share your work experience, education, accomplishments, mobility preferences and career goals." ID="ID_368911381" CREATED="1519238375025" MODIFIED="1519238375027"/>
<node TEXT="For a productive conversation, you must be prepared to talk about your career interests, strengths and development needs." ID="ID_409810702" CREATED="1519238411216" MODIFIED="1519238411226"/>
</node>
<node FOLDED="true" ID="ID_854062811" CREATED="1519662459663" MODIFIED="1519663242648" LINK="http://myworkplace.syngenta.org/irj/portal">
<icon BUILTIN="unchecked"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Complete/update <a href="http://myworkplace.syngenta.org/irj/portal">Employee Profile</a>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Your Employee Profile is your internal resume and is also relevant outside of the Talent Review process." ID="ID_1235066895" CREATED="1519238354901" MODIFIED="1519238354901"/>
</node>
<node TEXT="Complete Leadership &amp; Functional competency self-assessment in Employee Profile and bring this assessment to the career discussion" ID="ID_254216345" CREATED="1519662459667" MODIFIED="1519663182943">
<icon BUILTIN="unchecked"/>
</node>
<node FOLDED="true" ID="ID_1887257524" CREATED="1519662459671" MODIFIED="1519663318553" LINK="http://communication/sites/PerformanceManagement/en/Documents/EE_Career%20Discussion%20guide.pdf">
<icon BUILTIN="unchecked"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Initiate a conversation with your line manager to share your career goals, using the&#160; <a href="http://communication/sites/PerformanceManagement/en/Documents/EE_Career%20Discussion%20guide.pdf">Employee guide_Career Discussion</a>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="EE_Career Discussion guide.pdf" ID="ID_1438652200" CREATED="1519665889103" MODIFIED="1519665889103" LINK="EE_Career%20Discussion%20guide.pdf"/>
</node>
<node TEXT="Update your development goals and your leadership and functional competency assessment in Performance Management tool after inputs provided by your line manager during career discussion" ID="ID_437542418" CREATED="1519662459675" MODIFIED="1519663273331">
<icon BUILTIN="unchecked"/>
</node>
</node>
</node>
<node TEXT="The Talent Review process starts with the career discussion between you and your line manager." ID="ID_767703793" CREATED="1519238354901" MODIFIED="1519238411204"/>
</node>
<node ID="ID_1914025798" CREATED="1574366060588" MODIFIED="1574366060588" LINK="http://communication/sites/PerformanceManagement/en/Pages/Year-End-Review.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://communication/sites/PerformanceManagement/en/Pages/Year-End-Review.aspx">Year End Review</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="onboarding" FOLDED="true" ID="ID_325818700" CREATED="1714073803163" MODIFIED="1714073837702">
<node ID="ID_816747057" CREATED="1714077262393" MODIFIED="1714077262393" LINK="https://www.empforce.com/NewEmployee/ReviewPage.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.empforce.com/NewEmployee/ReviewPage.aspx">EMPFORCE - OnBoarding Tasks Review</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Michael.McMillen" ID="ID_706492040" CREATED="1714073838988" MODIFIED="1714073838988"/>
<node TEXT="favorite food: Fajitas" ID="ID_1175234597" CREATED="1714074329945" MODIFIED="1714074338349"/>
</node>
<node TEXT="https://myaccusourcedirect.com/" FOLDED="true" ID="ID_982265288" CREATED="1714077392746" MODIFIED="1714077392746" LINK="https://myaccusourcedirect.com/">
<node TEXT="mmcmillen" FOLDED="true" ID="ID_1880288871" CREATED="1714077425393" MODIFIED="1714077431671">
<node TEXT="FherA5S%]jgN^{T(a94C&amp;&gt;" ID="ID_835910148" CREATED="1714077466878" MODIFIED="1714077466878"/>
</node>
</node>
<node TEXT="Locations" FOLDED="true" ID="ID_1492977777" CREATED="1713459075973" MODIFIED="1713459085795">
<node TEXT="RTP" FOLDED="true" ID="ID_498964166" CREATED="1713459086968" MODIFIED="1713459089082">
<node TEXT="9 Davis Dr." ID="ID_195768632" CREATED="1713459154163" MODIFIED="1713459162285"/>
<node TEXT="Research Triangle Park, NC 27709" ID="ID_1811254251" CREATED="1713459163174" MODIFIED="1713459182377"/>
</node>
</node>
<node FOLDED="true" ID="ID_1870292109" CREATED="1519773107421" MODIFIED="1519773107421" LINK="http://www.cimis.water.ca.gov/Auth/Login.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://www.cimis.water.ca.gov/Auth/Login.aspx">CIMIS</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_643700129" CREATED="1519773107421" MODIFIED="1519773107421" LINK="mailto:mcmillen.michael.s@gmail.com"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      mcmillen.michael.s@gmail.com
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_303788525" CREATED="1519773107421" MODIFIED="1519773107421"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Dr0w$$@p
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Outlook" FOLDED="true" ID="ID_1248015155" CREATED="1690930333409" MODIFIED="1690930337405">
<node TEXT="Q1w1e1re" ID="ID_1304751332" CREATED="1690930360311" MODIFIED="1690930367924"/>
<node TEXT="Michael.McMillen@syngenta.com" ID="ID_1882887452" CREATED="1690930347685" MODIFIED="1690930347685" LINK="mailto:Michael.McMillen@syngenta.com"/>
</node>
<node FOLDED="true" ID="ID_1660904189" CREATED="1519763433965" MODIFIED="1597263027970">
<icon BUILTIN="password"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Computer
    </p>
  </body>
</html>
</richcontent>
<font BOLD="false"/>
<node TEXT="Login password" FOLDED="true" ID="ID_1797587400" CREATED="1680893542357" MODIFIED="1680893546521">
<node TEXT="Q1w1e1rw" ID="ID_1857148287" CREATED="1680893547397" MODIFIED="1680893553650"/>
</node>
<node FOLDED="true" ID="ID_27124368" CREATED="1519763434054" MODIFIED="1519763434054"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      WiFi:
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1639338898" CREATED="1519763434058" MODIFIED="1519763434058"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Syngenta
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1263871424" CREATED="1519763434061" MODIFIED="1519763434061"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      seed$4u!
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1186197036" CREATED="1519763434065" MODIFIED="1519763434065"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      s/N: 04z412511029
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_162823980" CREATED="1519763434070" MODIFIED="1519763434070"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Wep key: 3837574844
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1672718537" CREATED="1519763433981" MODIFIED="1519763433981"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      On wifi, need to connect to VPN in order to access intranet
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_294439673" CREATED="1519773107343" MODIFIED="1519773292014"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Training
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_552696540" CREATED="1695180433658" MODIFIED="1695180433658" LINK="https://www.360training.com/student-login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.360training.com/student-login">Student Log-In | 360training.com</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="FleetDefense" FOLDED="true" ID="ID_1815334225" CREATED="1693084336376" MODIFIED="1693084342690">
<node FOLDED="true" ID="ID_1147762088" CREATED="1693084355740" MODIFIED="1693084355740" LINK="https://login.fleetdefense.com/auth/realms/fleetdefense/protocol/openid-connect/auth?response_type=code&amp;client_id=AD-Fleet-Defense-LMS&amp;scope=openid%20profile%20email&amp;nonce=N64ea6a94c6e15&amp;response_mode=form_post&amp;resource=https%3A%2F%2Fgraph.windows.net&amp;state=21oz4DbZ8OTAAiU&amp;redirect_uri=https%3A%2F%2Ffd.fleetdefense.com%2Fauth%2Foidc%2F"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://login.fleetdefense.com/auth/realms/fleetdefense/protocol/openid-connect/auth?response_type=code&amp;client_id=AD-Fleet-Defense-LMS&amp;scope=openid%20profile%20email&amp;nonce=N64ea6a94c6e15&amp;response_mode=form_post&amp;resource=https%3A%2F%2Fgraph.windows.net&amp;state=21oz4DbZ8OTAAiU&amp;redirect_uri=https%3A%2F%2Ffd.fleetdefense.com%2Fauth%2Foidc%2F">Login to FleetDefense</a>
  </body>
</html>
</richcontent>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_654610973" CREATED="1693084377471" MODIFIED="1693084380132"/>
<node TEXT="Lucydog1" ID="ID_229363347" CREATED="1693084380555" MODIFIED="1693084383842"/>
</node>
</node>
<node FOLDED="true" ID="ID_1640242958" CREATED="1519763434013" MODIFIED="1519763434013"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Field Trial Compliance eLearning
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1447869265" CREATED="1519763434016" MODIFIED="1519763434016" LINK="http://www.complianceandglps.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://www.complianceandglps.com/">http://www.complianceandglps.com/</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1484529244" CREATED="1519763434020" MODIFIED="1519763434020"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Mmcmille
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_847725962" CREATED="1519763434025" MODIFIED="1519763434025"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Drow$$@p
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Windows Tablet" FOLDED="true" ID="ID_1978732415" CREATED="1690930312682" MODIFIED="1690930317488">
<node TEXT="Q1w1e1rw" ID="ID_1297927844" CREATED="1690930327629" MODIFIED="1690930375522"/>
</node>
<node TEXT="Android Tablet" FOLDED="true" ID="ID_1374425550" CREATED="1626725918864" MODIFIED="1626725922733">
<font BOLD="true"/>
<node TEXT="Password: Q1w1e1rr" ID="ID_808765408" CREATED="1690930294532" MODIFIED="1695092958411"/>
<node TEXT="Pin: 073083" ID="ID_406664288" CREATED="1690930294532" MODIFIED="1695093343717"/>
<node TEXT="Lock screen password" FOLDED="true" ID="ID_467649136" CREATED="1690930294535" MODIFIED="1690930294535">
<node TEXT="q123" ID="ID_714142282" CREATED="1690930294535" MODIFIED="1690930294535"/>
</node>
</node>
<node FOLDED="true" ID="ID_1382116890" CREATED="1519763434250" MODIFIED="1597263027957"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Travel / Expense Reports
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node TEXT="B of A" FOLDED="true" ID="ID_1373502567" CREATED="1690930449025" MODIFIED="1690930453844">
<node TEXT="MmcmillenBofA" ID="ID_602815251" CREATED="1690930455931" MODIFIED="1690930455931"/>
<node TEXT="Lucydog1" ID="ID_814639679" CREATED="1690930455933" MODIFIED="1690930455933"/>
<node TEXT="Pin: 4872" ID="ID_273487360" CREATED="1690930455934" MODIFIED="1690930455934"/>
</node>
<node FOLDED="true" ID="ID_1030258266" CREATED="1519763434129" MODIFIED="1597263027948" LINK="https://www.concursolutions.com/">
<icon BUILTIN="password"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.concursolutions.com/">Sign in to Concur | Concur Solutions</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_808383882" CREATED="1519763434133" MODIFIED="1597263027945"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      U581917@syngenta.com
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Qu8e5x2m" ID="ID_141307143" CREATED="1526925899758" MODIFIED="1597263027946"/>
<node TEXT="Mobile" FOLDED="true" ID="ID_1291363666" CREATED="1574267548520" MODIFIED="1597263027947">
<node TEXT="Company Code: JLE7XH" ID="ID_1578374422" CREATED="1574267556210" MODIFIED="1574267556210"/>
</node>
<node TEXT="Cost Center" FOLDED="true" ID="ID_1357293617" CREATED="1580238198760" MODIFIED="1597263027948">
<node TEXT="(RGCVE412) RGCVE412-Veg Ops - Salads" ID="ID_816704815" CREATED="1580238203309" MODIFIED="1580238203309"/>
</node>
</node>
<node FOLDED="true" ID="ID_437897695" CREATED="1519763434109" MODIFIED="1597263027955" LINK="https://home.cards.citidirect.com/CommercialCard/Cards.html?classic=2">
<icon BUILTIN="password"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://home.cards.citidirect.com/CommercialCard/Cards.html?classic=2">Citi&#174; Commercial Cards</a>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="mmcmillet" ID="ID_1279718033" CREATED="1526929306452" MODIFIED="1597263027951"/>
<node TEXT="Qu8e5x2r" ID="ID_1225540895" CREATED="1526931152129" MODIFIED="1601911243599"/>
<node TEXT="dusty" ID="ID_1118241246" CREATED="1530643288249" MODIFIED="1597263027953"/>
<node TEXT="7240 Adress" ID="ID_963782719" CREATED="1572109712002" MODIFIED="1597263027953"/>
<node TEXT="Travel Card Info" FOLDED="true" ID="ID_188726673" CREATED="1545067673733" MODIFIED="1597263027954">
<node TEXT="4046588001416405" OBJECT="java.lang.Long|4046588001416405" ID="ID_832292751" CREATED="1526927425318" MODIFIED="1526927427268"/>
<node TEXT="Travel Card (Blue -6405)" FOLDED="true" ID="ID_1117048840" CREATED="1530295049239" MODIFIED="1541525563211">
<node ID="ID_179983519" CREATED="1519773107374" MODIFIED="1519773107374"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Pin: 4011
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="4046588001416405" OBJECT="java.lang.Long|4046588001416405" ID="ID_1045905881" CREATED="1530295183381" MODIFIED="1551458801166"/>
<node TEXT=" 02/25" ID="ID_409808526" CREATED="1530295202300" MODIFIED="1607726348120"/>
<node TEXT="521" OBJECT="java.lang.Long|521" ID="ID_1252504046" CREATED="1530295226292" MODIFIED="1608054086543"/>
<node TEXT="Billing Address" FOLDED="true" ID="ID_1877116403" CREATED="1541525581678" MODIFIED="1541525590666">
<node TEXT="SYNGENTA" ID="ID_1946218800" CREATED="1526927713830" MODIFIED="1526927713830"/>
<node TEXT="7240 HOLSCLAW RD" ID="ID_408356090" CREATED="1526927713830" MODIFIED="1526927713830"/>
<node TEXT="GILROY CA 95020-8027" ID="ID_1665008692" CREATED="1526927713835" MODIFIED="1526927713835"/>
</node>
</node>
</node>
<node TEXT="PCARd Info" FOLDED="true" ID="ID_1731104175" CREATED="1583953845438" MODIFIED="1597263027955">
<node TEXT="New" FOLDED="true" ID="ID_1304242323" CREATED="1600279687156" MODIFIED="1600279688964">
<node TEXT="Veronica M. Elias" FOLDED="true" ID="ID_1767786519" CREATED="1583953899421" MODIFIED="1583953907256">
<node TEXT="veronica.elias@syngenta.com" ID="ID_1956540365" CREATED="1629837783978" MODIFIED="1629837796308"/>
<node TEXT="(408) 763-7128" ID="ID_511009569" CREATED="1629837851680" MODIFIED="1629837876626"/>
</node>
<node TEXT="visa" ID="ID_1489973994" CREATED="1629837454371" MODIFIED="1629837460864"/>
<node TEXT="4275338000696751" OBJECT="java.lang.Long|4275338000696751" ID="ID_1506359524" CREATED="1600279690201" MODIFIED="1600279797905"/>
<node TEXT="&apos;12/23" ID="ID_453024376" CREATED="1600279727587" MODIFIED="1600279730092"/>
<node TEXT="&apos;096" ID="ID_95040014" CREATED="1600279827209" MODIFIED="1600279838630"/>
<node TEXT="RBATL446" ID="ID_418061296" CREATED="1583953907746" MODIFIED="1583953913964"/>
<node TEXT="Address" FOLDED="true" ID="ID_588058324" CREATED="1629837526509" MODIFIED="1629837536115">
<node TEXT="2280 Hecker Pass Hwy" ID="ID_1733029423" CREATED="1629837609310" MODIFIED="1629837609310"/>
<node TEXT="Gilroy" ID="ID_127394269" CREATED="1629837612999" MODIFIED="1629837617056"/>
</node>
</node>
</node>
</node>
<node TEXT="Submitting" FOLDED="true" ID="ID_1331339175" CREATED="1545067648405" MODIFIED="1597263027956">
<node FOLDED="true" ID="ID_1850501367" CREATED="1519763434265" MODIFIED="1541525624240"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Submit once per month, due by 25th
    </p>
  </body>
</html>
</richcontent>
<node TEXT="File your monthly travel card claim in total to the statement no later than the 25th of each month." ID="ID_700765920" CREATED="1543250282004" MODIFIED="1543250282004"/>
<node TEXT="Ensure all detailed receipts have been attached. Payment confirmations are not acceptable receipts." ID="ID_329303519" CREATED="1543250282004" MODIFIED="1543250282004"/>
<node TEXT="If your report has an audit question, address the request immediately. The global T&amp;E audit team email address is sbs_ap_tne.br@syngenta.com" ID="ID_902623712" CREATED="1543250282004" MODIFIED="1543250282004" LINK="mailto:sbs_ap_tne.br@syngenta.com"/>
<node TEXT="The payment due date is listed on each statement and is the 8th of each month. Employees are to ensure the monthly claim has processed as Concur Processing Complete before the 8th of each month." ID="ID_8552546" CREATED="1543250282022" MODIFIED="1543250282022"/>
</node>
<node ID="ID_1199835876" CREATED="1519763434269" MODIFIED="1519763434269"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Attach statement
    </p>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1235712775" CREATED="1519763434144" MODIFIED="1519763434144"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Cost Center:
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1400589716" CREATED="1519763434147" MODIFIED="1541525461725"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      RGCVE412
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Veg Ops NA" ID="ID_856198097" CREATED="1543246745487" MODIFIED="1543246750904"/>
</node>
</node>
<node TEXT="Receipt Requirements" FOLDED="true" ID="ID_316427988" CREATED="1545067695409" MODIFIED="1597263027957">
<node TEXT="Airfare" FOLDED="true" ID="ID_384709640" CREATED="1545067706267" MODIFIED="1545067708735">
<node TEXT="Can use Concur receipt" ID="ID_946254555" CREATED="1545067710255" MODIFIED="1545067728393"/>
</node>
<node TEXT="Hotel - need from hotel" ID="ID_202129614" CREATED="1545067731034" MODIFIED="1545067744004"/>
</node>
</node>
<node TEXT="Online training" FOLDED="true" ID="ID_1148971554" CREATED="1562946848477" MODIFIED="1597263027958">
<node TEXT="https://www.bistrainer.com/" FOLDED="true" ID="ID_1755817313" CREATED="1611950396871" MODIFIED="1611950402633" LINK="https://www.bistrainer.com/">
<node TEXT="MMcMillen" ID="ID_301950872" CREATED="1562946866793" MODIFIED="1562946882075"/>
<node TEXT="Lucydog1" ID="ID_968210940" CREATED="1562946882842" MODIFIED="1562946886122"/>
</node>
<node FOLDED="true" ID="ID_1574979137" CREATED="1622226141337" MODIFIED="1622226141337" LINK="https://fd.fleetdefense.com/my/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://fd.fleetdefense.com/my/">Dashboard</a>
  </body>
</html>
</richcontent>
<node TEXT="Michael.McMillen@syngenta.com" ID="ID_1393475660" CREATED="1622226150269" MODIFIED="1622226153871"/>
<node TEXT="Lucydog1" ID="ID_1230538559" CREATED="1622226160054" MODIFIED="1622226176529"/>
</node>
</node>
<node TEXT="Physical" FOLDED="true" ID="ID_1249756523" CREATED="1520106104294" MODIFIED="1597263027963">
<node ID="ID_1563532961" CREATED="1519763434038" MODIFIED="1519763434038"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Gate Lock: 1020
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1557983610" CREATED="1519763434043" MODIFIED="1519763434043"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Old: 3325
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_776831861" CREATED="1519763434047" MODIFIED="1519763434047"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Lock Box on Door: 7240
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="ADP for benefits enrollment" FOLDED="true" ID="ID_1888815243" CREATED="1635258737713" MODIFIED="1635258776049" LINK="https://mybenefits.adp.com/">
<node TEXT="MMcMillen@SYNGENCROP" ID="ID_285066758" CREATED="1635259226508" MODIFIED="1635259239454"/>
<node TEXT="Lucydog1" ID="ID_1847266259" CREATED="1635259240361" MODIFIED="1635259248116"/>
</node>
<node TEXT="ADP" FOLDED="true" ID="ID_1913313084" CREATED="1521040886807" MODIFIED="1597263027967" LINK="https://www.adpdvs.com">
<node TEXT="mmcmillen" ID="ID_923483621" CREATED="1521040891393" MODIFIED="1521040894905"/>
<node TEXT="Lucydog1" ID="ID_1766355334" CREATED="1521041024204" MODIFIED="1521041027468"/>
<node TEXT="SQ" FOLDED="true" ID="ID_978712137" CREATED="1521040968833" MODIFIED="1521040971262">
<node TEXT="Dusty" ID="ID_36036708" CREATED="1521040972134" MODIFIED="1521040976372"/>
<node TEXT="mr2 blue" ID="ID_1274008547" CREATED="1521040976968" MODIFIED="1521040980049"/>
<node TEXT="Gilroy" ID="ID_1719057969" CREATED="1521040982899" MODIFIED="1521040985062"/>
<node TEXT="math" ID="ID_514714962" CREATED="1521040985668" MODIFIED="1521041003494"/>
</node>
</node>
<node TEXT="Wheels" FOLDED="true" ID="ID_1197987868" CREATED="1568069389512" MODIFIED="1597263027976">
<node FOLDED="true" ID="ID_1914813952" CREATED="1617660675370" MODIFIED="1617660675370" LINK="https://fd.fleetdefense.com/my/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://fd.fleetdefense.com/my/">Dashboard</a>
  </body>
</html>
</richcontent>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_1533349187" CREATED="1617660682759" MODIFIED="1617660684967"/>
<node TEXT="Lucydog1" ID="ID_1476098029" CREATED="1617660685631" MODIFIED="1617660690848"/>
</node>
<node FOLDED="true" ID="ID_105506847" CREATED="1577128719547" MODIFIED="1597263027975" LINK="https://auth.wheels.com/auth/Account/Login?ReturnUrl=%2Fauth%2Fconnect%2Fauthorize%2Fcallback%3Fclient_id%3Ddriverview%26redirect_uri%3Dhttps%253A%252F%252Fwww.wheels.com%252FDriverView%252FHome%252FScripts%252Foidc%252Flogin-complete.html%26response_type%3Did_token%2520token%26scope%3Dopenid%26state%3D080a3de5666d45faac0d0088fe25fbdd%26nonce%3D16d9679b98684dcfa54ac7b3655e698b"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://auth.wheels.com/auth/Account/Login?ReturnUrl=%2Fauth%2Fconnect%2Fauthorize%2Fcallback%3Fclient_id%3Ddriverview%26redirect_uri%3Dhttps%253A%252F%252Fwww.wheels.com%252FDriverView%252FHome%252FScripts%252Foidc%252Flogin-complete.html%26response_type%3Did_token%2520token%26scope%3Dopenid%26state%3D080a3de5666d45faac0d0088fe25fbdd%26nonce%3D16d9679b98684dcfa54ac7b3655e698b">Wheels Inc</a>
  </body>
</html>
</richcontent>
<node TEXT="Use Chrome" ID="ID_1534014955" CREATED="1603987527037" MODIFIED="1603987532131"/>
<node TEXT="mmcmille" ID="ID_1178903067" CREATED="1568069495203" MODIFIED="1568069495203"/>
<node TEXT="Lucydog2" ID="ID_231235763" CREATED="1569364070565" MODIFIED="1603987130661"/>
</node>
<node FOLDED="true" ID="ID_471485544" CREATED="1576014263578" MODIFIED="1597263027979" LINK="https://www.alertdriving.com/clients/Wheels"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoPlainText">
      <a href="https://www.alertdriving.com/clients/Wheels">https://www.alertdriving.com/clients/Wheels</a>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="sonic1716216" ID="ID_1127576938" CREATED="1576014302522" MODIFIED="1597263027977"/>
<node TEXT="Lucydog3" ID="ID_306239578" CREATED="1569364070565" MODIFIED="1597263027978"/>
</node>
</node>
<node TEXT="Iphone" FOLDED="true" ID="ID_1147646223" CREATED="1520108223814" MODIFIED="1597263027979">
<node TEXT="122987" ID="ID_1989063431" CREATED="1520108223814" MODIFIED="1520108223814"/>
</node>
<node TEXT="Mint" FOLDED="true" ID="ID_786896184" CREATED="1548258539314" MODIFIED="1597263027981">
<node TEXT="u581917" ID="ID_1606674692" CREATED="1548258541972" MODIFIED="1548258545130"/>
<node TEXT="&gt;6dmy9e.NVe{7qZC" ID="ID_1811540757" CREATED="1548258602902" MODIFIED="1548258602902"/>
</node>
<node TEXT="APHIS" FOLDED="true" ID="ID_1106949444" CREATED="1549559232713" MODIFIED="1597263027982">
<node ID="ID_233922409" CREATED="1551716541043" MODIFIED="1551716541043" LINK="https://www.eauth.usda.gov/Login/login.aspx?ZONE=Z2&amp;TRYIWA=TRUE&amp;TYPE=33554433&amp;REALMOID=06-29b9445e-5b6c-4a8c-b377-139d2e125c7e&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-PL00pavqS97cDi1RqFzNMQVoEFfpOsbCLGaqY9P7j6XCTS5TojyBTKx9Ok4KGGh%2b&amp;TARGET=-SM-https%3a%2f%2fpcit%2eaphis%2eusda%2egov%2fpcit%2fPCITInitServlet"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.eauth.usda.gov/Login/login.aspx?ZONE=Z2&amp;TRYIWA=TRUE&amp;TYPE=33554433&amp;REALMOID=06-29b9445e-5b6c-4a8c-b377-139d2e125c7e&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=-SM-PL00pavqS97cDi1RqFzNMQVoEFfpOsbCLGaqY9P7j6XCTS5TojyBTKx9Ok4KGGh%2b&amp;TARGET=-SM-https%3a%2f%2fpcit%2eaphis%2eusda%2egov%2fpcit%2fPCITInitServlet">eAuthentication</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="minnie.lin" ID="ID_612248039" CREATED="1549559270089" MODIFIED="1549559270089"/>
<node TEXT="$Gilroy3ast7" ID="ID_1355502129" CREATED="1549559244959" MODIFIED="1549559244959"/>
</node>
<node FOLDED="true" ID="ID_1663500230" CREATED="1524753817756" MODIFIED="1597263027983" LINK="https://myconduct-console.lrn.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://myconduct-console.lrn.com/">Syngenta myConduct</a>
  </body>
</html>
</richcontent>
<node TEXT="8610841" ID="ID_1851480512" CREATED="1524753897253" MODIFIED="1524753897253"/>
<node TEXT="syngenta3" ID="ID_1803726924" CREATED="1551809945285" MODIFIED="1551809951537"/>
</node>
<node TEXT="Office Wifi" FOLDED="true" ID="ID_1867852089" CREATED="1580831739960" MODIFIED="1597263027983">
<node TEXT="N0-W@rr1eS" ID="ID_759064178" CREATED="1580831745427" MODIFIED="1580831805675"/>
</node>
<node TEXT="Old PCard" FOLDED="true" ID="ID_488231548" CREATED="1583165858261" MODIFIED="1597263027984">
<node FOLDED="true" ID="ID_230287085" CREATED="1519763434105" MODIFIED="1538503418582"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      PCard -9427
    </p>
  </body>
</html>
</richcontent>
<node FOLDED="true" ID="ID_1438424809" CREATED="1519763434109" MODIFIED="1519763978450" LINK="https://home.cards.citidirect.com/CommercialCard/Cards.html?classic=2">
<icon BUILTIN="password"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://home.cards.citidirect.com/CommercialCard/Cards.html?classic=2">Citi&#174; Commercial Cards</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_1150602422" CREATED="1519763434112" MODIFIED="1519763434112"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      mmcmille
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1297064156" CREATED="1519763434118" MODIFIED="1522684133096"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Yu8e5x2k
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Human" ID="ID_1628023359" CREATED="1525444967659" MODIFIED="1525444970284"/>
<node TEXT="Dusty" ID="ID_574838448" CREATED="1522684184065" MODIFIED="1522684187417"/>
<node ID="ID_1512982740" CREATED="1519763434122" MODIFIED="1519763434122"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      PCard: -9427
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1652290015" CREATED="1541525658700" MODIFIED="1541525661854">
<node ID="ID_1538378302" CREATED="1519763434140" MODIFIED="1522685095471">
<icon BUILTIN="unchecked"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      PCard Report Title: PCard Month Year
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Attach reciepts" ID="ID_1913670046" CREATED="1522685056227" MODIFIED="1522685095476">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="Attach Statement" ID="ID_1287114558" CREATED="1522685064652" MODIFIED="1522685095476">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="Check receipts after done" ID="ID_1497953634" CREATED="1522685070923" MODIFIED="1522685095477">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="Submit" ID="ID_1763364245" CREATED="1522685085172" MODIFIED="1522685095477">
<icon BUILTIN="unchecked"/>
</node>
<node FOLDED="true" ID="ID_768993411" CREATED="1519763434151" MODIFIED="1519763434151"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      Key points required when creating and submitting Pcard transactions in Concur:
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_533523517" CREATED="1519763434154" MODIFIED="1519763434154"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      1. Reports must be submitted and approved within 10 business days from the billing statement cutoff date, the 28th of each month.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1231543664" CREATED="1519763434163" MODIFIED="1519763434163"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      3. Report title must follow this format: &#8220;Pcard+month+year.&#8221; If the report needs to be identified further for you records, employees can add anything after the year (see below example).
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1846845581" CREATED="1519763434159" MODIFIED="1519763434159" LINK="http://teamspace/sites/CPSBSFinSerC/P2P/Procurement%20Desk/USA%20files/How%20to%20register%20for%20Citibank%20statements%20online.docx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://teamspace/sites/CPSBSFinSerC/P2P/Procurement%20Desk/USA%20files/How%20to%20register%20for%20Citibank%20statements%20online.docx">2. Employees must register for online Citibank statement&#160;and request to go paperless.</a>
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1006195078" CREATED="1519763434166" MODIFIED="1519763434166"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      The month and year must be the statement date month &#8211; year (example: PCard December 2012 (abbreviations for the month can be used. Such as Pcard Dec 2012
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_512237153" CREATED="1519763434180" MODIFIED="1519763434180"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      4. The month and year in the report title must equal to the Citibank monthly statement date (as circled below)
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1688419945" CREATED="1519763434184" MODIFIED="1519763434184"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      5. The report total in Concur must always be an exact match to the Citibank statement even if the balance is a credit. At the bottom of your statement you will see &#8220;Total amount of memo items&#8221; this is the monthly balance you must match in Concur. (as circled below)
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_126034594" CREATED="1519763434189" MODIFIED="1519763434189"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      6. All receipts and the Citibank statement must be attached using the scanning option or a smartphone image in Concur. (see link below)
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1983672360" CREATED="1519763434194" MODIFIED="1519763434194"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      7. If you have fraud charges incurred on your card and reflected on the monthly statement, employees are still required to record the charges in total. When the credit corrections post at Citibank and appear in Concur, the employee will then record these to offset the fraud.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1124682916" CREATED="1519763434198" MODIFIED="1519763434198"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      8. Only 1 report a month for each card, for the total of the statement is to be recorded and approved in Concur within 10 business days.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1359623735" CREATED="1519763434202" MODIFIED="1519763434202"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      9. Reports returned from the audit team for corrections must be completed within 24 hours and resubmitted.
    </p>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1474718184" CREATED="1519763434206" MODIFIED="1519763434206" LINK="http://www.concurtraining.com/ls_rsrcs/CONCUR_EXP_EU_SIM_en-us_ReceiptStore.htm?pid=email&amp;elq_mid=5164&amp;elq_cid=524142"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="http://www.concurtraining.com/ls_rsrcs/CONCUR_EXP_EU_SIM_en-us_ReceiptStore.htm?pid=email&amp;elq_mid=5164&amp;elq_cid=524142">Use these links for Concur Simulation&#160;for interactive training, the Self Scanning Guide&#160;and Concur Pcard Guide&#160;to download Syngenta training materials.</a>
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Finance" POSITION="bottom_or_right" ID="ID_833047123" CREATED="1568180765415" MODIFIED="1597263028059">
<node TEXT="Management" ID="ID_1092693798" CREATED="1568180874822" MODIFIED="1637801546929">
<node ID="ID_1112123229" CREATED="1709852192230" MODIFIED="1709852192230" LINK="https://home.personalcapital.com/page/login/app#/dashboard"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://home.personalcapital.com/page/login/app#/dashboard">Empower - Dashboard</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1428680460" CREATED="1571166393293" MODIFIED="1571166397079"/>
<node TEXT="Lucydog1" ID="ID_1291004838" CREATED="1571166398030" MODIFIED="1571166401489"/>
</node>
<node FOLDED="true" ID="ID_1746685412" CREATED="1709853280426" MODIFIED="1709853286604" LINK="https://www.creditkarma.com/networth"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.creditkarma.com/networth">Intuit Credit Karma</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1125563475" CREATED="1603476658878" MODIFIED="1603476667235"/>
<node TEXT="Dr0w$$@p" ID="ID_585809222" CREATED="1603476662615" MODIFIED="1603476662618"/>
<node FOLDED="true" ID="ID_1426610282" CREATED="1568181083212" MODIFIED="1637801671970"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mint.intuit.com/overview.event">Mint</a>
  </body>
</html>
</richcontent>
<node ID="ID_1584534780" CREATED="1603476654632" MODIFIED="1603476654635"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Filtering
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://wwws.mint.com/transaction.event?startDate=05/01/2016&amp;endDate=07/31/2016">https://wwws.mint.com/transaction.event?startDate=05/01/2016&amp;endDate=07/31/2016</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Giving" FOLDED="true" ID="ID_136610644" CREATED="1668277403894" MODIFIED="1668277405830">
<node TEXT="EasyTithe" ID="ID_1516533443" CREATED="1668277412762" MODIFIED="1668277412762">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1777962182" CREATED="1668277412765" MODIFIED="1668277420697"/>
<node TEXT="Lucydog1" ID="ID_120387416" CREATED="1668277412765" MODIFIED="1668277412765"/>
<node ID="ID_936697520" CREATED="1668298984985" MODIFIED="1668298984985" LINK="https://www.svccchurch.com/giving"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.svccchurch.com/giving">Give Now — South Valley Community Church</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="stopped 7/13/24" ID="ID_1794272011" CREATED="1720874603789" MODIFIED="1720874613772"/>
</node>
</node>
<node TEXT="Banks and Credit Cards" ID="ID_997821575" CREATED="1568180985087" MODIFIED="1709839699599">
<node ID="ID_1297085452" CREATED="1570116275966" MODIFIED="1720874763692" LINK="https://www.chase.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="">Chase Bank - Credit Card, Mortgage, Auto, Banking Services</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<font ITALIC="true"/>
<node TEXT="1-800-935-9935" ID="ID_790304139" CREATED="1703058446370" MODIFIED="1703058461191"/>
<node TEXT="Michael" FOLDED="true" ID="ID_1927208236" CREATED="1585845982479" MODIFIED="1585845987659">
<node TEXT="831-524-8552" ID="ID_486292795" CREATED="1677180490130" MODIFIED="1677180625292"/>
<node TEXT="micromike777" ID="ID_164670537" CREATED="1578612802857" MODIFIED="1578612802857"/>
<node TEXT="n0tgn1h5aW" ID="ID_660537197" CREATED="1578612813731" MODIFIED="1578612813731"/>
<node TEXT="pin" FOLDED="true" ID="ID_667837217" CREATED="1709051922042" MODIFIED="1709051923471">
<node TEXT="4011" OBJECT="java.lang.Long|4011" ID="ID_1322215397" CREATED="1709051924548" MODIFIED="1709051928168"/>
</node>
</node>
<node TEXT="Monica" FOLDED="true" ID="ID_138869073" CREATED="1585846076604" MODIFIED="1585846079163">
<node TEXT="mnmcmillen1" ID="ID_1310425119" CREATED="1585846080271" MODIFIED="1585846086899"/>
<node TEXT="Lucydog1" ID="ID_365669753" CREATED="1585846121648" MODIFIED="1585846125533"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1191926373" CREATED="1585846157991" MODIFIED="1585846160950"/>
</node>
<node TEXT="Checking Info:" ID="ID_686732635" CREATED="1586537512161" MODIFIED="1586537512161">
<node TEXT="Routing #:" ID="ID_1587441254" CREATED="1586537512161" MODIFIED="1586537512161">
<node TEXT="322271627" ID="ID_1421952793" CREATED="1586537512193" MODIFIED="1586537512193"/>
</node>
<node TEXT="Account #:" ID="ID_1744948436" CREATED="1586537512193" MODIFIED="1586537512193">
<node TEXT="597957013" ID="ID_882743577" CREATED="1586537512194" MODIFIED="1586537512194"/>
</node>
</node>
<node TEXT="Credit Cards" FOLDED="true" ID="ID_1628709232" CREATED="1586537512194" MODIFIED="1586537512194">
<node TEXT="-8919 Chase Freedom (Closed)" ID="ID_1219788661" CREATED="1586537512194" MODIFIED="1586537512194"/>
<node TEXT="-9019 Slate" ID="ID_1053193757" CREATED="1586537512194" MODIFIED="1586537512194"/>
<node TEXT="-6485 Amazon Prime" FOLDED="true" ID="ID_962104962" CREATED="1586537512194" MODIFIED="1586537512194">
<node ID="ID_1610963006" CREATED="1713719366792" MODIFIED="1713719366792" LINK="https://www.amazon.com/b?ie=UTF8&amp;node=14770627011"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/b?ie=UTF8&amp;node=14770627011">Amazon.com: Prime Visa and Amazon Visa benefits: Credit &amp; Payment Cards</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="4147400154946485" OBJECT="java.lang.Long|4147400154946485" ID="ID_1453472382" CREATED="1610488018374" MODIFIED="1610488042039"/>
<node TEXT="5 â€“ 2 4" ID="ID_349233804" CREATED="1610488044429" MODIFIED="1610488050607"/>
<node TEXT="874" OBJECT="java.lang.Long|874" ID="ID_861544285" CREATED="1610488053117" MODIFIED="1610488066183"/>
</node>
</node>
</node>
<node TEXT="Wells Fargo" ID="ID_1447001428" CREATED="1586635625121" MODIFIED="1587571110820" LINK="https://connect.secure.wellsfargo.com/auth/login/present?origin=cob&amp;langPref=ENG">
<node TEXT="mcmillen_wf" ID="ID_1345376919" CREATED="1587570772711" MODIFIED="1587570882649"/>
<node TEXT="Lucydog2*" ID="ID_306118802" CREATED="1587570777100" MODIFIED="1701539922596"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1651994794" CREATED="1587570769351" MODIFIED="1587570771900"/>
<node TEXT="(831)524-8552" ID="ID_948952871" CREATED="1703055538724" MODIFIED="1703055546412"/>
<node TEXT="mortgage account number" FOLDED="true" ID="ID_1974040634" CREATED="1613593832900" MODIFIED="1613593836772">
<node TEXT="0602307977" ID="ID_549215132" CREATED="1613593841917" MODIFIED="1613593841917"/>
<node TEXT="Rate" FOLDED="true" ID="ID_1207275462" CREATED="1709853132750" MODIFIED="1709853135020">
<node TEXT="3.37" OBJECT="java.lang.Double|3.37" ID="ID_49155045" CREATED="1713476329903" MODIFIED="1713476332523"/>
</node>
</node>
<node FOLDED="true" ID="ID_1421614484" CREATED="1713719409499" MODIFIED="1713719658529" LINK="https://creditcards.wellsfargo.com/autograph-visa-credit-card/?RCTTST=RCTCTL1&amp;sub_channel=SEO&amp;vendor_code=DG"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://creditcards.wellsfargo.com/autograph-visa-credit-card/?RCTTST=RCTCTL1&amp;sub_channel=SEO&amp;vendor_code=DG">Rewards Credit Card | Wells Fargo Autograph℠</a>
  </body>
</html>
</richcontent>
<node TEXT="3x" FOLDED="true" ID="ID_442877618" CREATED="1713719427841" MODIFIED="1713719430146">
<node TEXT="restaurants" ID="ID_120256533" CREATED="1713719431054" MODIFIED="1713719434484"/>
<node TEXT="travel" ID="ID_994493824" CREATED="1713719434495" MODIFIED="1713719436482"/>
<node TEXT="gas" ID="ID_1116902204" CREATED="1713719436495" MODIFIED="1713719438276"/>
<node TEXT="transit" ID="ID_216778997" CREATED="1713719438284" MODIFIED="1713719441296"/>
<node TEXT="streaming" ID="ID_1595654992" CREATED="1713719441307" MODIFIED="1713719443510"/>
<node TEXT="phone plans" ID="ID_304443950" CREATED="1713719443520" MODIFIED="1713719446136"/>
</node>
</node>
<node TEXT="Credit Card due date 21st of month" FOLDED="true" ID="ID_1172914207" CREATED="1704483876794" MODIFIED="1704484106722">
<node TEXT="Rewards $415" ID="ID_237309637" CREATED="1704484345768" MODIFIED="1704484355194"/>
<node TEXT="Card number" FOLDED="true" ID="ID_1268967547" CREATED="1708122432626" MODIFIED="1708122440589">
<node TEXT="4147181446341673" OBJECT="java.lang.Long|4147181446341673" ID="ID_1048369677" CREATED="1708122440893" MODIFIED="1708122452620"/>
<node TEXT="12/27 expiration date" ID="ID_1807653892" CREATED="1708122453636" MODIFIED="1708122465712"/>
<node TEXT="867" OBJECT="java.lang.Long|867" ID="ID_641384170" CREATED="1708122468497" MODIFIED="1708122475216"/>
</node>
</node>
<node TEXT="contact" FOLDED="true" ID="ID_1660774108" CREATED="1713474766644" MODIFIED="1713474769708">
<node TEXT="Mortgage Customer Service" FOLDED="true" ID="ID_52467943" CREATED="1713474774864" MODIFIED="1713474774864">
<node TEXT="1-800-357-6675" ID="ID_286597852" CREATED="1713474774864" MODIFIED="1713474774864"/>
<node TEXT="Central Time" ID="ID_1089616247" CREATED="1713474774866" MODIFIED="1713474774866"/>
<node TEXT="Mon – Fri: 7 am - 10 pm" ID="ID_1662494244" CREATED="1713474774865" MODIFIED="1713474774865"/>
<node TEXT="Sat: 8 am - 2 pm" ID="ID_1499864716" CREATED="1713474774866" MODIFIED="1713474774866"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_1376652765" CREATED="1711987061303" MODIFIED="1711987061303" LINK="https://www.bankofamerica.com/credit-cards/manage-your-credit-card-account/?request_locale=en_US"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.bankofamerica.com/credit-cards/manage-your-credit-card-account/?request_locale=en_US">Credit Card Account Management with Bank of America</a>
  </body>
</html>
</richcontent>
<node TEXT="Monica CTA Visa -8929" FOLDED="true" ID="ID_1246772776" CREATED="1576858471216" MODIFIED="1668280798572">
<node TEXT="mnmcmillen" ID="ID_527054732" CREATED="1576858471216" MODIFIED="1576858471216"/>
<node TEXT="Dr0w442p" ID="ID_1605958283" CREATED="1576858471216" MODIFIED="1576858471216"/>
<node TEXT="Security Qs" FOLDED="true" ID="ID_1668172409" CREATED="1576858471216" MODIFIED="1576858471216">
<node TEXT="Salinas" ID="ID_203824032" CREATED="1576858471216" MODIFIED="1576858471216"/>
<node TEXT="Emily" ID="ID_1221162798" CREATED="1576858471216" MODIFIED="1576858471216"/>
<node TEXT="Lauren" ID="ID_1560045481" CREATED="1576858471216" MODIFIED="1576858471216"/>
</node>
<node TEXT="old card #" FOLDED="true" ID="ID_1274507721" CREATED="1668280783222" MODIFIED="1668280786669">
<node TEXT="-8708" OBJECT="java.lang.Long|-8708" ID="ID_32278145" CREATED="1668280788167" MODIFIED="1668280792128"/>
<node TEXT="mmcmillen777" ID="ID_374374737" CREATED="1576858471216" MODIFIED="1576858471216"/>
<node TEXT="dr0w554p" ID="ID_1621500876" CREATED="1576858471216" MODIFIED="1576858471216"/>
</node>
</node>
<node TEXT="Travel alert 866-266-0212" ID="ID_513537703" CREATED="1576858471216" MODIFIED="1576858471216"/>
</node>
<node TEXT="Lowe&apos;s Credit Card" FOLDED="true" ID="ID_94405055" CREATED="1714857470517" MODIFIED="1714857659799">
<node FOLDED="true" ID="ID_1654668433" CREATED="1715798933770" MODIFIED="1715798933770" LINK="https://www.synchrony.com/accounts/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.synchrony.com/accounts/">Synchrony Account Manager</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1598028984" CREATED="1715798819093" MODIFIED="1715798855120"/>
<node TEXT="Lucydog1" ID="ID_1020597913" CREATED="1715798855719" MODIFIED="1715798858505"/>
<node TEXT="Autopay on 2nd of each month" ID="ID_1318858845" CREATED="1715799163690" MODIFIED="1715799183919"/>
</node>
<node TEXT="Account Number" FOLDED="true" ID="ID_510030120" CREATED="1714857512373" MODIFIED="1714857512373">
<node TEXT="81924510233901" ID="ID_1488351500" CREATED="1714857512373" MODIFIED="1714857512373"/>
</node>
<node TEXT="Valid Thru" FOLDED="true" ID="ID_38098313" CREATED="1714857512373" MODIFIED="1714857512373">
<node TEXT="05/14/24" ID="ID_1411385578" CREATED="1714857512375" MODIFIED="1714857512375"/>
</node>
<node TEXT="Security Code" FOLDED="true" ID="ID_1048948698" CREATED="1714857512375" MODIFIED="1714857512375">
<node TEXT="129" ID="ID_1378442919" CREATED="1714857512376" MODIFIED="1714857512376"/>
</node>
<node TEXT="Credit Limit" FOLDED="true" ID="ID_1659001391" CREATED="1714857512377" MODIFIED="1714857512377">
<node TEXT="$13,000.00" ID="ID_1061309208" CREATED="1714857512378" MODIFIED="1714857512378"/>
</node>
</node>
<node TEXT="High Savings" FOLDED="true" ID="ID_1093225354" CREATED="1703058483994" MODIFIED="1703058489749">
<node FOLDED="true" ID="ID_450040497" CREATED="1668011579262" MODIFIED="1712764875432" LINK="https://www.ufbdirect.com/?utm_campaign=02462_DDU4_ufb_savings_nerdwallet_0422&amp;utm_medium=affiliate&amp;utm_source=nerdwallet&amp;click_id=3e4ce2cf56a04db39b1ea5568b64f6fc"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ufbdirect.com/?utm_campaign=02462_DDU4_ufb_savings_nerdwallet_0422&amp;utm_medium=affiliate&amp;utm_source=nerdwallet&amp;click_id=3e4ce2cf56a04db39b1ea5568b64f6fc">UFB Direct 5.25% onm 4/10/24</a>
  </body>
</html>
</richcontent>
<font ITALIC="true"/>
<node TEXT="balance" FOLDED="true" ID="ID_1126900381" CREATED="1713389712514" MODIFIED="1713389714609">
<node TEXT="64805" OBJECT="java.lang.Long|64805" ID="ID_695303818" CREATED="1713389715449" MODIFIED="1713389727146"/>
<node TEXT="4/17/24" OBJECT="org.freeplane.features.format.FormattedDate|2024-04-17T03:00-0400|date" ID="ID_437750614" CREATED="1713389727754" MODIFIED="1713389731311"/>
</node>
<node TEXT="mandmmcmillen" ID="ID_1131664578" CREATED="1668298143124" MODIFIED="1668298146233"/>
<node TEXT="Lucydog1*" ID="ID_1306319669" CREATED="1668298146797" MODIFIED="1668298151433"/>
<node TEXT="security word: human" ID="ID_1838585287" CREATED="1668298250013" MODIFIED="1668298280441"/>
<node TEXT="security questions" FOLDED="true" ID="ID_1700724032" CREATED="1670561619290" MODIFIED="1670561622744">
<node TEXT="Street" FOLDED="true" ID="ID_590158381" CREATED="1670561624059" MODIFIED="1670561625863">
<node TEXT="Tradewinds" ID="ID_763547592" CREATED="1670561626315" MODIFIED="1670561630382"/>
</node>
<node TEXT="elementary school" FOLDED="true" ID="ID_1958798237" CREATED="1670561645326" MODIFIED="1670561648123">
<node TEXT="Romoland" ID="ID_1800566552" CREATED="1670561649461" MODIFIED="1670561659341"/>
</node>
<node TEXT="pet" FOLDED="true" ID="ID_680807006" CREATED="1670561673900" MODIFIED="1670561676683">
<node TEXT="Dusty" ID="ID_368583898" CREATED="1670561677650" MODIFIED="1670561681533"/>
</node>
</node>
</node>
<node TEXT="Brilliant Bank 5.22% on 4/10/24" FOLDED="true" ID="ID_150196081" CREATED="1702397480100" MODIFIED="1713389547313" LINK="https://www.brilliant.bank/">
<icon BUILTIN="unchecked"/>
<node TEXT="balance" FOLDED="true" ID="ID_1249303329" CREATED="1713389752364" MODIFIED="1713389754654">
<node TEXT="25395" OBJECT="java.lang.Long|25395" ID="ID_940596639" CREATED="1713389806250" MODIFIED="1713389810653"/>
</node>
<node TEXT="-$8 loss/year" FOLDED="true" ID="ID_776842627" CREATED="1713305225703" MODIFIED="1713305250865">
<node TEXT="transfer to UFB" ID="ID_51893061" CREATED="1712765764765" MODIFIED="1712765776222"/>
</node>
<node TEXT="mandmmcmillen" ID="ID_1747605963" CREATED="1702397485832" MODIFIED="1702397491738"/>
<node TEXT="Lucydog1" ID="ID_647742863" CREATED="1702397492209" MODIFIED="1702397496046"/>
<node TEXT="info" FOLDED="true" ID="ID_587525123" CREATED="1702397524593" MODIFIED="1702397525773">
<node TEXT="Authorized Payment Amount: $25000" ID="ID_1669411791" CREATED="1702397540509" MODIFIED="1702397540509"/>
<node TEXT="Date Authorized: 12/12/2023" ID="ID_281058801" CREATED="1702397540509" MODIFIED="1702397540509"/>
<node TEXT="Expected Payment Date: 12/19/2023" ID="ID_386124180" CREATED="1702397540509" MODIFIED="1702397540509"/>
<node TEXT="Surge Money Market" ID="ID_1852904108" CREATED="1702397532328" MODIFIED="1702397532328"/>
<node TEXT="Account Number: 9700020805" ID="ID_1841171818" CREATED="1702397532328" MODIFIED="1702397532328"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_970247314" CREATED="1709839652647" MODIFIED="1709839664801" LINK="https://www.paypal.com/signin?country.x=US&amp;locale.x=en_US"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.paypal.com/signin?country.x=US&amp;locale.x=en_US">PayPal</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1456014741" CREATED="1570209103333" MODIFIED="1597263028042"/>
<node TEXT="pW@-cETdgm5^8NwS$G" ID="ID_1140590037" CREATED="1570209103333" MODIFIED="1597263028043"/>
<node TEXT="(831)524-8552" ID="ID_764079067" CREATED="1703056254781" MODIFIED="1703056260792"/>
</node>
<node FOLDED="true" ID="ID_1249375032" CREATED="1709839253607" MODIFIED="1709839263016" LINK="https://www.discover.com/online-banking/savings-account/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.discover.com/online-banking/savings-account/">Discover</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillensave" ID="ID_103993578" CREATED="1579110607118" MODIFIED="1579110607118"/>
<node TEXT="Lucydog1*" ID="ID_1711182514" CREATED="1579110607118" MODIFIED="1703055930109"/>
<node TEXT="7017238673" ID="ID_1826100034" CREATED="1579110607122" MODIFIED="1579110607122"/>
<node TEXT="old ID" FOLDED="true" ID="ID_1238108705" CREATED="1668277126310" MODIFIED="1668277128939">
<node TEXT="micromike777" ID="ID_1427045196" CREATED="1580050800877" MODIFIED="1580050800877"/>
<node TEXT="D reg" ID="ID_1086719632" CREATED="1580050800880" MODIFIED="1580050800880"/>
</node>
</node>
<node TEXT="Kohls" FOLDED="true" ID="ID_16055766" CREATED="1635862302087" MODIFIED="1635863289412" LINK="https://credit.kohls.com/eCustService/">
<node TEXT="Monica" FOLDED="true" ID="ID_92676463" CREATED="1635862308663" MODIFIED="1635862310714">
<node TEXT="098053579301" ID="ID_770430824" CREATED="1635862633747" MODIFIED="1635862633747"/>
<node TEXT="mnmcmillen" ID="ID_364152342" CREATED="1635862821139" MODIFIED="1635862821139"/>
<node TEXT="Lucydog1" ID="ID_283701124" CREATED="1635863553552" MODIFIED="1635863556957"/>
</node>
</node>
<node TEXT="Healthequity.com/WageWorks" FOLDED="true" ID="ID_383752181" CREATED="1668278611956" MODIFIED="1668278611956">
<node TEXT="Participant Login" FOLDED="true" ID="ID_878912648" CREATED="1668278611956" MODIFIED="1668278636183" LINK="https://participant.wageworks.com/home.aspx?ReturnUrl=%2F">
<node TEXT="mmcmille" ID="ID_1806023277" CREATED="1714527582004" MODIFIED="1714527582004"/>
<node TEXT="MzaVvR6r8-N;d$!j" ID="ID_1049695633" CREATED="1714527939184" MODIFIED="1714528096201"/>
</node>
<node TEXT="4231 9056 1189 3275" FOLDED="true" ID="ID_1327518271" CREATED="1668278611956" MODIFIED="1668278611956">
<node TEXT="Expiration:  01/27" ID="ID_1176286659" CREATED="1668278611956" MODIFIED="1668278611956"/>
<node TEXT="pin: 4552" ID="ID_818553751" CREATED="1668278611956" MODIFIED="1668278611956"/>
<node TEXT="312 security code" ID="ID_1964906243" CREATED="1714526958207" MODIFIED="1714526966165"/>
</node>
<node TEXT="Note: use credit at point-of-purchase" ID="ID_1137219376" CREATED="1668278611956" MODIFIED="1668278611956"/>
</node>
<node TEXT="archive" FOLDED="true" ID="ID_92925501" CREATED="1668277444974" MODIFIED="1709839618274">
<node FOLDED="true" ID="ID_1351034365" CREATED="1568181058228" MODIFIED="1570118463787"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.golden1.com/home/default">Golden 1 Credit Union | Home </a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen1" ID="ID_1078446206" CREATED="1570118427512" MODIFIED="1570118427512"/>
<node TEXT="dr0w$$@p" ID="ID_1625622814" CREATED="1570118427512" MODIFIED="1570118427512"/>
<node TEXT="Checking Acct#:" FOLDED="true" ID="ID_770102009" CREATED="1570118427512" MODIFIED="1570118427512">
<node TEXT="1718285" ID="ID_1247544034" CREATED="1570118427512" MODIFIED="1570118427512"/>
</node>
<node TEXT="Mortgage Acct#:" FOLDED="true" ID="ID_9353930" CREATED="1570118427512" MODIFIED="1570118427512">
<node TEXT="1453435230" ID="ID_498290847" CREATED="1570118427512" MODIFIED="1570118427512"/>
</node>
<node TEXT="Equity Loan" FOLDED="true" ID="ID_137653295" CREATED="1570118427528" MODIFIED="1570118427528">
<node TEXT="5.790%" ID="ID_183092120" CREATED="1570118427529" MODIFIED="1570118427529"/>
</node>
<node TEXT="Member Service Dept" FOLDED="true" ID="ID_459020472" CREATED="1570118427530" MODIFIED="1570118427530">
<node TEXT="1-888-908-8933" ID="ID_204303690" CREATED="1570118427533" MODIFIED="1570118427533"/>
<node TEXT="M-F 8a-6p PST" ID="ID_708280223" CREATED="1570118427534" MODIFIED="1570118427534"/>
</node>
</node>
<node TEXT="CitiBank BestBuy:" FOLDED="true" ID="ID_962685699" CREATED="1570208994888" MODIFIED="1597263028044">
<node TEXT="mmcmille" ID="ID_1095736258" CREATED="1570208994888" MODIFIED="1570208994888"/>
<node TEXT="BB0fhy74BB0fhy74" ID="ID_1157914418" CREATED="1570208994903" MODIFIED="1570208994903"/>
<node TEXT="877-560-1088 fraud dept investigations" ID="ID_687318596" CREATED="1570208994919" MODIFIED="1570208994919"/>
</node>
<node TEXT="BestBuy:" FOLDED="true" ID="ID_130268129" CREATED="1570208994919" MODIFIED="1597263028044">
<node TEXT="BB0fhy74BB0fhy74" ID="ID_1899962719" CREATED="1570208994919" MODIFIED="1570208994919"/>
</node>
<node TEXT="American Express" FOLDED="true" ID="ID_598595295" CREATED="1570208994935" MODIFIED="1597263028045">
<node TEXT="BlueCash Everyday -91002:" ID="ID_1319714907" CREATED="1570208994935" MODIFIED="1570208994935"/>
<node TEXT="mcmille77" ID="ID_393019435" CREATED="1570208994935" MODIFIED="1570208994935"/>
<node TEXT="C2:" ID="ID_554241703" CREATED="1570208994935" MODIFIED="1570208994935"/>
<node TEXT="mcmille777" ID="ID_403409537" CREATED="1570208994935" MODIFIED="1570208994935"/>
<node TEXT="Savings:" FOLDED="true" ID="ID_840332560" CREATED="1570208994935" MODIFIED="1570208994935">
<node TEXT="Mmcmille77" ID="ID_887054212" CREATED="1570208994935" MODIFIED="1570208994935"/>
<node TEXT="dr0w554p" ID="ID_554404772" CREATED="1570208994935" MODIFIED="1570208994935"/>
</node>
</node>
<node TEXT="Costco Citi Card" FOLDED="true" ID="ID_1299432155" CREATED="1570208994919" MODIFIED="1696304301441">
<icon BUILTIN="unchecked"/>
<node TEXT="mandmmcmillen" ID="ID_1754594887" CREATED="1570208994919" MODIFIED="1570208994919"/>
<node TEXT="Luckydog1" ID="ID_549218847" CREATED="1570208994919" MODIFIED="1570208994919"/>
</node>
</node>
</node>
<node TEXT="Property Management" ID="ID_1181342460" CREATED="1720641694573" MODIFIED="1720641700604">
<node ID="ID_93367095" CREATED="1720641715022" MODIFIED="1720641715022" LINK="https://mcdonaldinvestments.appfolio.com/oportal/users/log_in"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mcdonaldinvestments.appfolio.com/oportal/users/log_in">AppFolio Owner Portal</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_394240698" CREATED="1720641716916" MODIFIED="1720641725637"/>
<node TEXT="Lucydog1" ID="ID_542327551" CREATED="1720641726058" MODIFIED="1720641751104"/>
</node>
</node>
<node TEXT="Investing / Saving" FOLDED="true" ID="ID_1855746127" CREATED="1568180991869" MODIFIED="1637801196657">
<node ID="ID_1458736805" CREATED="1568181033041" MODIFIED="1634582415913"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://my.calpers.ca.gov/web/ept/public/systemaccess/login/username.html">my|CalPERS - Log In</a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            ?
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1809002417" CREATED="1571166741522" MODIFIED="1634582495839" LINK="https://www.troweprice.com/workplace/en/login.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.troweprice.com/workplace/en/login.html">T. Rowe Price - Workplace Retirement</a>
  </body>
</html>
</richcontent>
<node TEXT="mmcmille" ID="ID_1708978509" CREATED="1571166949543" MODIFIED="1571166949543"/>
<node TEXT="dr0w$$@p" ID="ID_449200129" CREATED="1571166949543" MODIFIED="1571166949543"/>
</node>
<node FOLDED="true" ID="ID_1164363454" CREATED="1570210807421" MODIFIED="1703056680012" LINK="https://logon.vanguard.com/logon"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://investor.vanguard.com/home/">Vanguard</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node FOLDED="true" ID="ID_21446479" CREATED="1585847026095" MODIFIED="1585847030103"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Michael
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="mmcmille" ID="ID_273659261" CREATED="1585847044071" MODIFIED="1585847044071"/>
<node TEXT="Luckydog730" ID="ID_236466956" CREATED="1585847059989" MODIFIED="1585847059989"/>
<node TEXT="8315248552" OBJECT="java.lang.Long|8315248552" ID="ID_120481683" CREATED="1703056687338" MODIFIED="1703056690751"/>
</node>
<node ID="ID_308213699" CREATED="1585847032333" MODIFIED="1585847036711"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            Roth IRA
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.5in; font-family: Calibri; font-size: 11.0pt">
            Acct #: 18025393
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.5in; font-family: Calibri; font-size: 11.0pt">
            VDADX Vanguard Dividend Appreciation Index Fund Admiral Shares
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.5in; font-family: Calibri; font-size: 11.0pt">
            VDIGX Vanguard Dividend Growth Fund Investor Shares
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            WB47683710
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            Brokerage
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.5in; font-family: Calibri; font-size: 11.0pt">
            Acct #: 88687161
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.5in; font-family: Calibri; font-size: 11.0pt">
            VWESX: Vanguard Long-Term Investment-Grade Fund Investor Shares
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1370944884" CREATED="1585847036727" MODIFIED="1585847672837"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Monica
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="mnmcmillen87" ID="ID_817120471" CREATED="1585847748692" MODIFIED="1585847748692"/>
<node TEXT="Lucydog87" ID="ID_417020999" CREATED="1585847777350" MODIFIED="1585847777350"/>
<node TEXT="Acct#: 10694236" ID="ID_1372751758" CREATED="1585847771266" MODIFIED="1585847771266"/>
</node>
<node ID="ID_86679395" CREATED="1570210810139" MODIFIED="1570210810154"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            &#160;
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.quantconnect.com/terminal/">QuantConnect </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="mailto:mcmillen.michael.s@gmail.com">mcmillen.michael.s@gmail.com </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            D4fGqyu[M/;8=D2V
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.quantopian.com/users/5a1dde26f8d2480018139bff">Quantopian </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            mcmillen.michael.s@gmail.com
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            D4fGqyu[M/;8=D2V
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.investopedia.com/accounts/login.aspx">Investopedia </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="mailto:mcmillen.michael.s@gmail.com">mcmillen.michael.s@gmail.com </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            mmcmille
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            9Q!_j24Y!^F&quot;MH6y
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.nadex.com/login?logout=true">Login | Nadex </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            mmcmillen
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Lucydog1
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_981662868" CREATED="1585847672853" MODIFIED="1585847676689"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            mnmcmillen87
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="DMV" FOLDED="true" ID="ID_1799343462" CREATED="1628528006319" MODIFIED="1628528008491">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_654371571" CREATED="1628528009374" MODIFIED="1628528057985"/>
<node TEXT="Lucydog1*" ID="ID_1991930937" CREATED="1628528059139" MODIFIED="1628528064037"/>
<node TEXT="Drivers License" FOLDED="true" ID="ID_394774358" CREATED="1680801915161" MODIFIED="1680802001900">
<node TEXT="Michael" FOLDED="true" ID="ID_1825168208" CREATED="1680802005638" MODIFIED="1680802007454">
<node TEXT="D4492574" ID="ID_1060946146" CREATED="1680802063306" MODIFIED="1680802063306"/>
<node TEXT="Issue Date" FOLDED="true" ID="ID_743966516" CREATED="1680802072941" MODIFIED="1680802077021">
<node TEXT="08/11/2021" ID="ID_464376624" CREATED="1680802077706" MODIFIED="1680802077706"/>
</node>
<node TEXT="Expiration Date" FOLDED="true" ID="ID_1095375291" CREATED="1680802095182" MODIFIED="1680802095182">
<node TEXT="07/30/2026" ID="ID_956368846" CREATED="1680802104944" MODIFIED="1680802104944"/>
</node>
</node>
<node TEXT="Monica" FOLDED="true" ID="ID_1844283588" CREATED="1680802007731" MODIFIED="1680802009371">
<node TEXT="D6595816" ID="ID_1582442255" CREATED="1680802121910" MODIFIED="1680804834994"/>
<node TEXT="Issue Date" FOLDED="true" ID="ID_1184539728" CREATED="1680802072941" MODIFIED="1680802077021">
<node TEXT="1/12/23" OBJECT="org.freeplane.features.format.FormattedDate|2023-01-12T03:00-0500|date" ID="ID_349154932" CREATED="1680804836802" MODIFIED="1680804845535"/>
</node>
<node TEXT="Expiration Date" FOLDED="true" ID="ID_708689979" CREATED="1680802095182" MODIFIED="1680802095182">
<node TEXT="12/29/27" OBJECT="org.freeplane.features.format.FormattedDate|2027-12-29T03:00-0500|date" ID="ID_1530428004" CREATED="1680804847639" MODIFIED="1680804854479"/>
</node>
</node>
</node>
</node>
<node TEXT="Tax" FOLDED="true" ID="ID_43012804" CREATED="1568180995666" MODIFIED="1637801179476">
<node TEXT="Income" FOLDED="true" ID="ID_370472223" CREATED="1587571837396" MODIFIED="1587571839463">
<node TEXT="Filing" FOLDED="true" ID="ID_246084517" CREATED="1623520210558" MODIFIED="1623520219370">
<node TEXT="Family Information" ID="ID_572933473" CREATED="1638164710225" MODIFIED="1638165237574" LINK="LifeMgmt.mm#ID_1688260899"/>
<node TEXT="IRS online account" FOLDED="true" ID="ID_413828583" CREATED="1623522925077" MODIFIED="1623522930211">
<node FOLDED="true" ID="ID_1741172535" CREATED="1623522977839" MODIFIED="1623522977839" LINK="https://sa.www4.irs.gov/eauth/pub/login.jsp?Data=VGFyZ2V0TG9BPUY%253D&amp;TYPE=33554433&amp;REALMOID=06-00029c6a-0543-17b0-89b8-163b0acf40c7&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=UOkC7yx4eMTO24FGxPfBRb5q3Mj3Xh3pyXfBEjYyHJ97nGCXu16wx5MzFHjfZmlG&amp;TARGET=-SM-https%3a%2f%2fsa%2ewww4%2eirs%2egov%2fola%2f"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sa.www4.irs.gov/eauth/pub/login.jsp?Data=VGFyZ2V0TG9BPUY%253D&amp;TYPE=33554433&amp;REALMOID=06-00029c6a-0543-17b0-89b8-163b0acf40c7&amp;GUID=&amp;SMAUTHREASON=0&amp;METHOD=GET&amp;SMAGENTNAME=UOkC7yx4eMTO24FGxPfBRb5q3Mj3Xh3pyXfBEjYyHJ97nGCXu16wx5MzFHjfZmlG&amp;TARGET=-SM-https%3a%2f%2fsa%2ewww4%2eirs%2egov%2fola%2f">Log In</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen" ID="ID_767799409" CREATED="1623523785264" MODIFIED="1623523785264"/>
<node TEXT="Lucydog1$" ID="ID_622796347" CREATED="1623523808687" MODIFIED="1623523897488"/>
</node>
<node TEXT="error code -9900" ID="ID_382903792" CREATED="1623524007463" MODIFIED="1623524021875"/>
</node>
<node TEXT="Federal" FOLDED="true" ID="ID_709993010" CREATED="1623520423340" MODIFIED="1623520427513">
<node TEXT="set up filing account" FOLDED="true" ID="ID_136718893" CREATED="1623520433994" MODIFIED="1623522943080">
<node FOLDED="true" ID="ID_1087528848" CREATED="1622182276551" MODIFIED="1622182276551" LINK="https://www.freefilefillableforms.com/#/fd/signin"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.freefilefillableforms.com/#/fd/signin">Sign In - Free File Fillable Forms</a>
  </body>
</html>
</richcontent>
<node TEXT="Minty_fresh" ID="ID_1357570613" CREATED="1622182285657" MODIFIED="1622182285657"/>
<node TEXT="JE.wExkpsB9Q_Np" ID="ID_1543452610" CREATED="1622182285657" MODIFIED="1622182285657"/>
</node>
<node TEXT="PIN" FOLDED="true" ID="ID_849107859" CREATED="1586539142499" MODIFIED="1586539154771">
<node TEXT="Mi" FOLDED="true" ID="ID_321926744" CREATED="1586539519350" MODIFIED="1586539521898">
<node TEXT="98345" OBJECT="java.lang.Long|98345" ID="ID_1156794260" CREATED="1586539156205" MODIFIED="1586539160179"/>
</node>
<node TEXT="Mo" FOLDED="true" ID="ID_665512522" CREATED="1586539525402" MODIFIED="1586539526851">
<node TEXT="90285" OBJECT="java.lang.Long|90285" ID="ID_260193842" CREATED="1586539161067" MODIFIED="1586539174125"/>
</node>
</node>
</node>
<node TEXT="get 1040 instructions from IRS Forms" FOLDED="true" ID="ID_299275024" CREATED="1623520401725" MODIFIED="1623520475915">
<node ID="ID_74447546" CREATED="1623520409804" MODIFIED="1623520409804" LINK="https://www.irs.gov/forms-instructions"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.irs.gov/forms-instructions">Forms &amp; Instructions | Internal Revenue Service</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Recovery Rebate Credit" FOLDED="true" ID="ID_857855420" CREATED="1623522815445" MODIFIED="1623522826460">
<node ID="ID_1187079692" CREATED="1623522827882" MODIFIED="1623522827882" LINK="https://www.irs.gov/newsroom/recovery-rebate-credit"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.irs.gov/newsroom/recovery-rebate-credit">2020 Recovery Rebate Credit | Internal Revenue Service</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="State" FOLDED="true" ID="ID_1611686510" CREATED="1623538156762" MODIFIED="1623538160594">
<node FOLDED="true" ID="ID_1450256219" CREATED="1586540764553" MODIFIED="1586540764553" LINK="https://webapp.ftb.ca.gov/MyFTBAccess/Login/AccessYourAccount"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://webapp.ftb.ca.gov/MyFTBAccess/Login/AccessYourAccount">MyFTB | Access Your Account | California Franchise Tax Board</a>
  </body>
</html>
</richcontent>
<node TEXT="Username" FOLDED="true" ID="ID_1181995429" CREATED="1638164165934" MODIFIED="1638164170462">
<node TEXT="mmcmillen" ID="ID_1966539417" CREATED="1568183616506" MODIFIED="1568183616506"/>
</node>
<node TEXT="Password" FOLDED="true" ID="ID_959376115" CREATED="1638164177789" MODIFIED="1638164181044">
<node TEXT="Lucydog2$" ID="ID_362295771" CREATED="1570806957065" MODIFIED="1638164412074"/>
</node>
<node TEXT="Email" FOLDED="true" ID="ID_698115116" CREATED="1638164220942" MODIFIED="1638164224890">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1483978562" CREATED="1586540253036" MODIFIED="1586540254557"/>
</node>
<node TEXT="Qs" FOLDED="true" ID="ID_1392647749" CREATED="1586540255539" MODIFIED="1586540316412">
<node TEXT="Salinas" ID="ID_500107364" CREATED="1586540317393" MODIFIED="1586540319313"/>
<node TEXT="Sonic" ID="ID_1453096391" CREATED="1586540319708" MODIFIED="1586540569648"/>
<node TEXT="Tradewinds" ID="ID_1479696333" CREATED="1586540572222" MODIFIED="1586540577178"/>
</node>
</node>
</node>
</node>
<node TEXT="old" FOLDED="true" ID="ID_1946789677" CREATED="1638164030323" MODIFIED="1638164032761">
<node ID="ID_297548780" CREATED="1568181017333" MODIFIED="1585843457573"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            H&amp;R Block
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="mailto:mcmillen.michael.s@gmail.com">mcmillen.michael.s@gmail.com </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Gw@!y4mui
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1666933601" CREATED="1585843457580" MODIFIED="1585843548519"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.freefilefillableforms.com/#/fd">Free File Fillable Forms</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="2018" OBJECT="java.lang.Long|2018" FOLDED="true" ID="ID_195854639" CREATED="1585843565471" MODIFIED="1585843568496">
<node TEXT="polkaking777" ID="ID_97414669" CREATED="1585843695464" MODIFIED="1585843695464"/>
<node TEXT="Lucydog1*" ID="ID_578641991" CREATED="1585843695464" MODIFIED="1585843695464"/>
</node>
<node TEXT="2019" OBJECT="java.lang.Long|2019" FOLDED="true" ID="ID_819423533" CREATED="1585843573413" MODIFIED="1585843576657">
<node TEXT="mmctax2019" ID="ID_219376120" CREATED="1585843658040" MODIFIED="1585843658040"/>
<node TEXT="Lucydog1*" ID="ID_318437945" CREATED="1585843695464" MODIFIED="1585843695464"/>
<node TEXT="PIN" FOLDED="true" ID="ID_335764494" CREATED="1586539142499" MODIFIED="1586539154771">
<node TEXT="Mi" FOLDED="true" ID="ID_1537855664" CREATED="1586539519350" MODIFIED="1586539521898">
<node TEXT="98345" OBJECT="java.lang.Long|98345" ID="ID_1899250467" CREATED="1586539156205" MODIFIED="1586539160179"/>
</node>
<node TEXT="Mo" FOLDED="true" ID="ID_610524496" CREATED="1586539525402" MODIFIED="1586539526851">
<node TEXT="90285" OBJECT="java.lang.Long|90285" ID="ID_1457646273" CREATED="1586539161067" MODIFIED="1586539174125"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Property" FOLDED="true" ID="ID_1201085481" CREATED="1587571846805" MODIFIED="1587571850602">
<node ID="ID_213312276" CREATED="1587571929999" MODIFIED="1587571929999" LINK="https://common2.mptsweb.com/mbc/sanbenito/tax/search#"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://common2.mptsweb.com/mbc/sanbenito/tax/search#">Search Page - MBC</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Social Security" FOLDED="true" ID="ID_829539463" CREATED="1570806531755" MODIFIED="1597263028047">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_186674610" CREATED="1570806821005" MODIFIED="1570806823241"/>
<node TEXT="ssmmcmillen" ID="ID_128813303" CREATED="1570806823913" MODIFIED="1570806929867"/>
<node TEXT="Lucydog1$" ID="ID_1941646046" CREATED="1570806957065" MODIFIED="1570806969534"/>
<node TEXT="Qs" FOLDED="true" ID="ID_305545676" CREATED="1570806982782" MODIFIED="1570806984070">
<node TEXT="Dusty" ID="ID_1419451955" CREATED="1570806985204" MODIFIED="1570806987443"/>
<node TEXT="Salinas" ID="ID_1773136498" CREATED="1570806988272" MODIFIED="1570807020308"/>
<node TEXT="mr2" ID="ID_1441814215" CREATED="1570807020716" MODIFIED="1570807022948"/>
</node>
</node>
<node TEXT="Insurance" FOLDED="true" ID="ID_818017343" CREATED="1592581833487" MODIFIED="1597263028058">
<node TEXT="Health Insurance / Enrollment Account Access" FOLDED="true" ID="ID_695562050" CREATED="1568182431384" MODIFIED="1597263028058">
<node TEXT="Anthem" FOLDED="true" ID="ID_1121308358" CREATED="1578066382426" MODIFIED="1703058950455" LINK="https://www.anthem.com/ca/login/">
<font BOLD="true"/>
<node TEXT="Info" FOLDED="true" ID="ID_1575360807" CREATED="1615909340939" MODIFIED="1615909344002">
<node TEXT="Blue Cross PPO" ID="ID_1260203533" CREATED="1615909345137" MODIFIED="1615909360306"/>
<node TEXT="Anthem" ID="ID_1866787622" CREATED="1615909361840" MODIFIED="1615909364993"/>
<node TEXT="PERS Select Basic" ID="ID_1539778041" CREATED="1615909366829" MODIFIED="1615909408446"/>
</node>
<node TEXT="Login" FOLDED="true" ID="ID_1362053039" CREATED="1578461991945" MODIFIED="1578461994633">
<node TEXT="mnmcmillen" ID="ID_412985138" CREATED="1578066475641" MODIFIED="1578066482004"/>
<node TEXT="Lucydog1" ID="ID_1711112887" CREATED="1578066482348" MODIFIED="1578066486606"/>
</node>
<node TEXT="Phone" FOLDED="true" ID="ID_331695465" CREATED="1703058931734" MODIFIED="1703058936609">
<node TEXT="2096027457" OBJECT="java.lang.Long|2096027457" ID="ID_1310734160" CREATED="1703058937559" MODIFIED="1703058940016"/>
<node TEXT="8315248552" OBJECT="java.lang.Long|8315248552" ID="ID_99451236" CREATED="1703058940534" MODIFIED="1703058942743"/>
</node>
<node TEXT="Member ID: CPR416W02086" ID="ID_1781405066" CREATED="1578461956804" MODIFIED="1615909656381"/>
<node TEXT="Group No: SB250G" ID="ID_67864525" CREATED="1615909676445" MODIFIED="1615909695491"/>
<node TEXT="Plan Code: 040" ID="ID_147764031" CREATED="1615909611018" MODIFIED="1615909623084"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_723507262" CREATED="1578066490700" MODIFIED="1578066492244"/>
<node TEXT="Security Qs" FOLDED="true" ID="ID_1934723470" CREATED="1578066522795" MODIFIED="1578066526393">
<node TEXT="Favorite Food: Pasta" ID="ID_257093802" CREATED="1703058758939" MODIFIED="1703058776836"/>
<node TEXT="Childhood Friend: Lauren" ID="ID_1732979146" CREATED="1578066614685" MODIFIED="1578066656584"/>
<node TEXT="First Job: Greenfield" ID="ID_1994309508" CREATED="1578066656968" MODIFIED="1578066744249"/>
</node>
</node>
<node FOLDED="true" ID="ID_1351640347" CREATED="1576082314679" MODIFIED="1597263028052" LINK="https://myhealth.stanfordhealthcare.org/Private#/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://myhealth.stanfordhealthcare.org/Private#/">MyHealth at Stanford</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1235296994" CREATED="1572911871324" MODIFIED="1572911874441"/>
<node TEXT="Lucydog1" ID="ID_831748224" CREATED="1572911875852" MODIFIED="1572911879392"/>
<node TEXT="=488.72+30" ID="ID_487336349" CREATED="1578458417795" MODIFIED="1578458537445"/>
</node>
<node FOLDED="true" ID="ID_1817977234" CREATED="1602882353570" MODIFIED="1634583937840" LINK="https://www.deltadentalins.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="text-align: justify">
      <a href="https://www.deltadentalins.com/">Delta Dental Insurance </a>
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Info" FOLDED="true" ID="ID_1117402430" CREATED="1612542703892" MODIFIED="1612542707415">
<node TEXT="Delta dental PPO" FOLDED="true" ID="ID_1536834076" CREATED="1612542775787" MODIFIED="1612542783630">
<node TEXT="Provided by Delta Dental of California" ID="ID_252817713" CREATED="1612542784330" MODIFIED="1612542805112"/>
</node>
<node TEXT="Enrollee ID" FOLDED="true" ID="ID_926449461" CREATED="1612542758271" MODIFIED="1612542758271">
<node TEXT="114388921001" ID="ID_1344104720" CREATED="1612542758271" MODIFIED="1612542758271"/>
</node>
<node TEXT="Group number" FOLDED="true" ID="ID_875881683" CREATED="1612542770953" MODIFIED="1612542770953">
<node TEXT="00604-00006" ID="ID_236055531" CREATED="1612542770953" MODIFIED="1612542770953"/>
</node>
</node>
<node TEXT="Monica" ID="ID_445783438" CREATED="1634583866767" MODIFIED="1634583866767"/>
<node TEXT="mandmmcmillen" ID="ID_1718822080" CREATED="1634583866767" MODIFIED="1634583866767"/>
<node TEXT="Lucydog1" ID="ID_1483925091" CREATED="1634583866769" MODIFIED="1634583866769"/>
</node>
<node ID="ID_846415134" CREATED="1702836757209" MODIFIED="1703057133626" LINK="https://www.geico.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.geico.com/">GEICO</a>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_975938052" CREATED="1672773399665" MODIFIED="1672773399665" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="E35jg7gki-d" ID="ID_1095287186" CREATED="1672773399665" MODIFIED="1672773399665"/>
<node TEXT="8315248552" OBJECT="java.lang.Long|8315248552" ID="ID_427133226" CREATED="1703057115973" MODIFIED="1703057118408"/>
<node TEXT="Add" ID="ID_187860397" CREATED="1672773399665" MODIFIED="1672773399665"/>
<node TEXT="Dependent Verification Services" FOLDED="true" ID="ID_151446454" CREATED="1672773399665" MODIFIED="1672773399665">
<node TEXT="&lt;https://www.adpdvs.com/dasClients/pages/das/empDashboard.jsf&gt;" ID="ID_1623659936" CREATED="1672773399665" MODIFIED="1672773399665" LINK="https://www.adpdvs.com/dasClients/pages/das/empDashboard.jsf"/>
</node>
</node>
<node TEXT="Safeco Insurance (Homeowners)" FOLDED="true" ID="ID_1660688533" CREATED="1581172853536" MODIFIED="1597263028057" LINK="https://customer.safeco.com/accountmanager/Login/login.aspx">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_474371008" CREATED="1581172878419" MODIFIED="1581172885516"/>
<node TEXT="Lucydog1" ID="ID_1147360766" CREATED="1581172886114" MODIFIED="1581172918574"/>
</node>
</node>
<node FOLDED="true" ID="ID_1375016837" CREATED="1568180998571" MODIFIED="1597263028058"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <h2 style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 14.0pt; color: #2E75B5">
            Auto
          </h2>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_796460259" CREATED="1568181008364" MODIFIED="1580995078690"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            Ford
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://owner.ford.com/tools/account/sign-in.html">Owner Login | Support | Official Ford Owner Site </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="mailto:mcmillen.michael.s@gmail.com">mcmillen.michael.s@gmail.com </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            dr0w$$@p
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1745907138" CREATED="1580995078699" MODIFIED="1580995506439"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.geico.com/">GEICO </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="mailto:mandmmcmillen@gmail.com">mandmmcmillen@gmail.com </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Micromike777
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            E35jg7gki-d
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            DMV:
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            mmcmille
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Reg
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Monica
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            mnmcmillen1
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            Lucydog1
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            Farmers:
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            mnmcmillen
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_1450169081" CREATED="1580995081892" MODIFIED="1603476045350"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .375in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.costco.com/warehouse-locations/gilroy-ca-760.html">Costco Tire </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            (408) 848-0708
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Location
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            7251 CAMINO ARROYO
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            GILROY, CA
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            95020-7340
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Hours:
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            Mon-Fri. 9:00am - 8:30pm
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            Sat. 8:30am - 6:00pm
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 1.125in; font-family: Calibri; font-size: 11.0pt">
            Sun. 9:00am - 6:00pm
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1140386122" CREATED="1608136516768" MODIFIED="1608136516768" LINK="https://www.costcotireappointments.com/login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.costcotireappointments.com/login">Costco | Login</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node FOLDED="true" ID="ID_1052321464" CREATED="1603476045356" MODIFIED="1603476048549"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.costcotireappointments.com/login">Costco | Create new account</a>
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1098012255" CREATED="1603476069907" MODIFIED="1603476069907" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="btJ8B?t;k@/haPGw" ID="ID_227359892" CREATED="1603476069907" MODIFIED="1603476069907"/>
</node>
</node>
<node TEXT="Home" FOLDED="true" ID="ID_1051769091" CREATED="1592582162989" MODIFIED="1597263028058">
<node FOLDED="true" ID="ID_989900290" CREATED="1592582280143" MODIFIED="1592582280143" LINK="https://customer.safeco.com/accountmanager/Login/login.aspx"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://customer.safeco.com/accountmanager/Login/login.aspx">Log in to your Safeco account</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_523038169" CREATED="1592582289699" MODIFIED="1592582293631"/>
<node TEXT="Lucydog1" ID="ID_1221012967" CREATED="1592582294189" MODIFIED="1592582299239"/>
</node>
</node>
</node>
<node TEXT="Home Improvement" FOLDED="true" ID="ID_1690871127" CREATED="1575409027962" MODIFIED="1597263028059">
<node FOLDED="true" ID="ID_558270490" CREATED="1575409030463" MODIFIED="1575409030463" LINK="https://shop.iccsafe.org/customer/account/create/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://shop.iccsafe.org/customer/account/create/">Create New Customer Account</a>
  </body>
</html>
</richcontent>
<node TEXT="pin  0730" ID="ID_1317564777" CREATED="1575409098955" MODIFIED="1575409118377"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1360767268" CREATED="1575409102447" MODIFIED="1575409124469"/>
<node TEXT="Lucydog1" ID="ID_214102530" CREATED="1575409125747" MODIFIED="1575409129829"/>
</node>
</node>
</node>
<node TEXT="Home" POSITION="bottom_or_right" ID="ID_426377522" CREATED="1717426793832" MODIFIED="1717426795777">
<node TEXT="RAM" FOLDED="true" ID="ID_6348525" CREATED="1718723738890" MODIFIED="1718723741792">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_253587504" CREATED="1717426806738" MODIFIED="1717426809131"/>
<node TEXT="Lucydog1" ID="ID_1807808282" CREATED="1717426809838" MODIFIED="1718724728613"/>
<node TEXT="831-206-2683" ID="ID_163002182" CREATED="1718724729163" MODIFIED="1718724736222"/>
</node>
<node FOLDED="true" ID="ID_432518367" CREATED="1717426805313" MODIFIED="1717426805313" LINK="https://bexleytrianglepark.securecafe.com/onlineleasing/bexley-at-triangle-park/oleapplication.aspx?propleadsource_155382=portal&amp;amp;stepname=Registration&amp;amp;myOlePropertyId=155382"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://bexleytrianglepark.securecafe.com/onlineleasing/bexley-at-triangle-park/oleapplication.aspx?propleadsource_155382=portal&amp;stepname=Registration&amp;myOlePropertyId=155382">Bexley at Triangle Park | Apartments in Cary, NC | RENTCafe</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_488764022" CREATED="1717426806738" MODIFIED="1717426809131"/>
<node TEXT="Lucydog123*" ID="ID_1162452968" CREATED="1717426809838" MODIFIED="1717426847961"/>
<node TEXT="8312062683" OBJECT="java.lang.Long|8312062683" ID="ID_1097792444" CREATED="1717426820390" MODIFIED="1717426822560"/>
<node TEXT="Apartment        1426CPD" ID="ID_1012258784" CREATED="1718725387041" MODIFIED="1718725387041"/>
<node TEXT="Address        " ID="ID_316302220" CREATED="1718725387041" MODIFIED="1718725395597">
<node TEXT="1426 Chinqua Pine Drive" ID="ID_1838093035" CREATED="1718725395598" MODIFIED="1718725395601"/>
<node TEXT="Cary, NC 27519-1849" ID="ID_962465238" CREATED="1718725387042" MODIFIED="1718725387042"/>
</node>
</node>
<node TEXT="Utilities" ID="ID_577104612" CREATED="1585843415346" MODIFIED="1597263028047">
<node TEXT="Duke" ID="ID_842909611" CREATED="1721326966262" MODIFIED="1721326968007">
<node ID="ID_573766456" CREATED="1721326968864" MODIFIED="1721326968864"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: rgb(105, 105, 105); font-family: NewsGothicBT-Roman, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-weight: 400; letter-spacing: 0.4px; text-align: left; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">910167359738</span>
  </body>
</html>
</richcontent>
</node>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1768516989" CREATED="1721327021195" MODIFIED="1721327021195" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="Lucydog1" ID="ID_1017873913" CREATED="1721327024969" MODIFIED="1721391713792"/>
</node>
<node FOLDED="true" ID="ID_1027860927" CREATED="1707170448319" MODIFIED="1707170464243" LINK="https://m.pge.com/#login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://m.pge.com/#login">Pacific Gas and Electric Company</a>
  </body>
</html>
</richcontent>
<node TEXT="mnmcmillen" ID="ID_1643531559" CREATED="1707170485562" MODIFIED="1707170485562"/>
<node TEXT="Lucydog1" ID="ID_220232085" CREATED="1707170479207" MODIFIED="1707170494624"/>
<node TEXT="autopay through checking account" ID="ID_906901118" CREATED="1707170580853" MODIFIED="1707170586739"/>
<node TEXT="account number" FOLDED="true" ID="ID_998624960" CREATED="1707163341219" MODIFIED="1707163347834">
<node TEXT="5293804089-7" ID="ID_719783373" CREATED="1707163347838" MODIFIED="1707169540050"/>
<node TEXT="9659 SS Last 4" ID="ID_1218313376" CREATED="1707169540918" MODIFIED="1707169553025"/>
<node TEXT="meter ID" FOLDED="true" ID="ID_432815864" CREATED="1707169690375" MODIFIED="1707169699765">
<node TEXT="1008369443" OBJECT="java.lang.Long|1008369443" ID="ID_982860795" CREATED="1707169701305" MODIFIED="1707169715111"/>
</node>
</node>
<node TEXT="Security questions" FOLDED="true" ID="ID_16828964" CREATED="1707169920135" MODIFIED="1707169923664">
<node TEXT="maiden name" FOLDED="true" ID="ID_1162185939" CREATED="1707169962908" MODIFIED="1707169966306">
<node TEXT="Foote" ID="ID_1373809850" CREATED="1707169966308" MODIFIED="1707169995897"/>
</node>
<node TEXT="Lucydog1" ID="ID_874403179" CREATED="1707170013191" MODIFIED="1707170017449"/>
</node>
<node TEXT="old account" FOLDED="true" ID="ID_1177846004" CREATED="1707170471086" MODIFIED="1707170473754">
<node TEXT="Monicaswain" ID="ID_6047476" CREATED="1707170031687" MODIFIED="1707170201593"/>
</node>
</node>
<node ID="ID_234264581" CREATED="1709839088251" MODIFIED="1709839088251" LINK="https://www.recology.com/bill-pay/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.recology.com/bill-pay/">Pay Your Bill Online | Recology</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_79567494" CREATED="1709839174600" MODIFIED="1709839191785" LINK="http://www.puwc.org/ebill.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="http://www.puwc.org/ebill.html">Water SSCWD Online Payment E-Billing</a>
  </body>
</html>
</richcontent>
<node TEXT="mcm0017" ID="ID_520731240" CREATED="1709839024852" MODIFIED="1709839024852"/>
<node TEXT="Lucydog1" ID="ID_351016938" CREATED="1709839024852" MODIFIED="1709839024852"/>
<node TEXT="Autopay expires 12/27" ID="ID_163685826" CREATED="1708122402248" MODIFIED="1708122496222">
<node TEXT="Wells Fargo" ID="ID_914733371" CREATED="1586635625121" MODIFIED="1587571110820" LINK="https://connect.secure.wellsfargo.com/auth/login/present?origin=cob&amp;langPref=ENG">
<node TEXT="mcmillen_wf" ID="ID_1289644619" CREATED="1587570772711" MODIFIED="1587570882649"/>
<node TEXT="Lucydog2*" ID="ID_1663198945" CREATED="1587570777100" MODIFIED="1701539922596"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1257014059" CREATED="1587570769351" MODIFIED="1587570771900"/>
<node TEXT="(831)524-8552" ID="ID_15137951" CREATED="1703055538724" MODIFIED="1703055546412"/>
<node TEXT="mortgage account number" FOLDED="true" ID="ID_745428148" CREATED="1613593832900" MODIFIED="1613593836772">
<node TEXT="0602307977" ID="ID_1590346476" CREATED="1613593841917" MODIFIED="1613593841917"/>
</node>
<node TEXT="Credit Card due date 21st of month" ID="ID_413636475" CREATED="1704483876794" MODIFIED="1704484106722">
<node TEXT="Rewards $415" ID="ID_693422853" CREATED="1704484345768" MODIFIED="1704484355194"/>
<node TEXT="Card number" ID="ID_1351885583" CREATED="1708122432626" MODIFIED="1708122440589">
<node TEXT="4147181446341673" OBJECT="java.lang.Long|4147181446341673" ID="ID_1616910859" CREATED="1708122440893" MODIFIED="1708122452620"/>
<node TEXT="12/27 expiration date" ID="ID_873861722" CREATED="1708122453636" MODIFIED="1708122465712"/>
<node TEXT="867" OBJECT="java.lang.Long|867" ID="ID_652096577" CREATED="1708122468497" MODIFIED="1708122475216"/>
</node>
</node>
</node>
</node>
<node TEXT="Account number" ID="ID_1586786216" CREATED="1708122525427" MODIFIED="1708122530103">
<node TEXT="35-02416-00" ID="ID_400621887" CREATED="1708122532067" MODIFIED="1708122532067"/>
</node>
</node>
<node TEXT="PureTalk" FOLDED="true" ID="ID_1104540539" CREATED="1670561158127" MODIFIED="1670561186816" LINK="https://www.puretalkusa.com/account/login">
<node TEXT="Lucydog1*" ID="ID_1523381738" CREATED="1670561158128" MODIFIED="1670561158128"/>
<node TEXT="Phones" FOLDED="true" ID="ID_1945200761" CREATED="1677180468312" MODIFIED="1677180471139">
<node TEXT="Michael" FOLDED="true" ID="ID_1241094141" CREATED="1677180472170" MODIFIED="1677180482972">
<node TEXT="831-524-8552" FOLDED="true" ID="ID_1805629173" CREATED="1677180490130" MODIFIED="1677180625292">
<node TEXT="voicemail" FOLDED="true" ID="ID_498693483" CREATED="1691964372356" MODIFIED="1691964377340">
<node TEXT="&apos;07301983" ID="ID_491032041" CREATED="1691965113371" MODIFIED="1691965143341"/>
<node TEXT="Delete 7" ID="ID_183902270" CREATED="1691965149699" MODIFIED="1691965214628"/>
</node>
<node TEXT=" unlocked and GSM compatible" ID="ID_739161650" CREATED="1701544223343" MODIFIED="1701544239827"/>
</node>
<node TEXT="old Verizon" FOLDED="true" ID="ID_606235837" CREATED="1709842458939" MODIFIED="1709842463016">
<node TEXT="831-206-2683" ID="ID_1245572237" CREATED="1677180483706" MODIFIED="1677180489563"/>
</node>
</node>
</node>
<node TEXT="Activated 7/7/22" ID="ID_183679590" CREATED="1670561158128" MODIFIED="1670561158128"/>
<node TEXT="Qs" ID="ID_1072101236" CREATED="1670561158128" MODIFIED="1670561158128"/>
<node TEXT="City spouse: Salinas" ID="ID_646839437" CREATED="1670561158128" MODIFIED="1670561158128"/>
<node TEXT="School 4th grade: Sherwood Elementary" ID="ID_1466140647" CREATED="1670561158128" MODIFIED="1670561158128"/>
<node TEXT="Childhood hero: Jesus" ID="ID_935371941" CREATED="1670561158128" MODIFIED="1670561158128"/>
</node>
<node ID="ID_1409017887" CREATED="1670545491780" MODIFIED="1670545491780" LINK="https://www.spectrum.net/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.spectrum.net/">Spectrum Account Sign-In &amp; Bill Pay | Spectrum</a>
  </body>
</html>
</richcontent>
<node TEXT="1561" OBJECT="java.lang.Long|1561" FOLDED="true" ID="ID_848149986" CREATED="1720641070350" MODIFIED="1720641072951">
<node TEXT="mmcmillen" ID="ID_338022140" CREATED="1670544883433" MODIFIED="1670544883433"/>
<node TEXT="Lucydog_1" ID="ID_1946486060" CREATED="1670544883433" MODIFIED="1670544883433"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_261528949" CREATED="1670544883446" MODIFIED="1670544883446" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="551133222" ID="ID_305904683" CREATED="1670544883451" MODIFIED="1670544883451"/>
<node TEXT="Foote" ID="ID_1338593909" CREATED="1670544883500" MODIFIED="1670544883500"/>
<node TEXT="Crestwood" ID="ID_1678641120" CREATED="1670544883520" MODIFIED="1670544883520"/>
<node TEXT="Salinas" ID="ID_262683066" CREATED="1670544883522" MODIFIED="1670544883522"/>
<node TEXT="Monica N McMillen" ID="ID_1936160094" CREATED="1670544883533" MODIFIED="1670544883533"/>
<node TEXT="mmcmillen" ID="ID_189087998" CREATED="1670545463993" MODIFIED="1670545463993"/>
<node TEXT="Lucydog1" ID="ID_530564589" CREATED="1670545463993" MODIFIED="1670545463993"/>
<node TEXT="8315248552" OBJECT="java.lang.Long|8315248552" ID="ID_1479458000" CREATED="1703056802731" MODIFIED="1703056807812"/>
<node TEXT="Fav pet" ID="ID_482961325" CREATED="1670545464001" MODIFIED="1670545464001"/>
<node TEXT="Snickers" ID="ID_1280071459" CREATED="1670545464004" MODIFIED="1670545464004"/>
<node TEXT="Recovery email" ID="ID_1821278018" CREATED="1670545464013" MODIFIED="1670545464013"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1247066315" CREATED="1670545464017" MODIFIED="1670545464017" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="Acct #: 8203110020461336" ID="ID_1458041558" CREATED="1670545464020" MODIFIED="1670545464020"/>
<node TEXT="mmcmillen@charter.net" ID="ID_431355072" CREATED="1576859338250" MODIFIED="1671474205961"/>
</node>
<node TEXT="1426" OBJECT="java.lang.Long|1426" FOLDED="true" ID="ID_39035602" CREATED="1720641081581" MODIFIED="1720641084728">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1584534960" CREATED="1720641093115" MODIFIED="1720641099956"/>
<node TEXT="Lucydog1" ID="ID_706487751" CREATED="1720641100697" MODIFIED="1720641103938"/>
<node TEXT="1st Pet" ID="ID_1159265427" CREATED="1720641114826" MODIFIED="1720641118794">
<node TEXT="Dusty" ID="ID_1687589999" CREATED="1720641119148" MODIFIED="1720641120899"/>
</node>
</node>
<node ID="ID_184617845" CREATED="1670545781269" MODIFIED="1670545781269" LINK="https://www.spectrum.net/support/internet/self-install-modem-replacement-swap?redirected=true"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.spectrum.net/support/internet/self-install-modem-replacement-swap?redirected=true">How to Replace an Internet Modem and/or Router | Spectrum Support</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="archive" FOLDED="true" ID="ID_43684107" CREATED="1709838987989" MODIFIED="1709838990077">
<node TEXT="Republic Wireless" FOLDED="true" ID="ID_415360671" CREATED="1573844581722" MODIFIED="1573844587944">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_854263668" CREATED="1573844588798" MODIFIED="1573844591680"/>
<node TEXT="Lucydog1" ID="ID_72017623" CREATED="1573844592260" MODIFIED="1573844595841"/>
<node ID="ID_710117203" CREATED="1573845290100" MODIFIED="1573845290100" LINK="https://help.republicwireless.com/hc/en-us/articles/115005961408-How-to-Transfer-Your-Number-to-Republic-Wireless"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://help.republicwireless.com/hc/en-us/articles/115005961408-How-to-Transfer-Your-Number-to-Republic-Wireless">How to Transfer Your Number to Republic Wireless &#8211; Republic Help</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1795378771" CREATED="1670545433273" MODIFIED="1670545433279"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div style="border-top-width: 100%; border-right-width: 100%; border-bottom-width: 100%; border-left-width: 100%">
      <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
        <div style="margin-top: 0in; margin-left: 0in; width: 6.109in">
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="https://www.att.com/olam/loginAction.olamexecute">(discontinued) myAT&amp;T Login - Bills Online &amp; Manage Your AT&amp;T Account </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Account: 137723260
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Pin: 0730
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Monica11115852
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            Lucydog1
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            <a href="mailto:michaelsmcmillen@att.net">michaelsmcmillen@att.net </a>
          </p>
          <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .75in; font-family: Calibri; font-size: 11.0pt">
            800.288.2020
          </p>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Travel" FOLDED="true" POSITION="top_or_left" ID="ID_1275676829" CREATED="1537210544597" MODIFIED="1597263027973">
<node TEXT="U-Haul" FOLDED="true" ID="ID_697940770" CREATED="1714861946841" MODIFIED="1714861946841">
<node ID="ID_1659627820" CREATED="1714862317725" MODIFIED="1714862317725" LINK="https://www.uhaul.com/Orders/Rental/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.uhaul.com/Orders/Rental/">My Rentals / Reservations | U-Haul</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1002259360" CREATED="1719432061078" MODIFIED="1719432063713"/>
<node TEXT="Lucydog1*" ID="ID_609207794" CREATED="1719432064335" MODIFIED="1719432256273"/>
<node TEXT="Moving Help" ID="ID_464033314" CREATED="1720639683285" MODIFIED="1720639686864">
<node TEXT="Order Details&#xa;Status: Reserved&#xa;Service Provider&#xa;GoMove Profile Image&#xa;Email: GoMove919@gmail.com&#xa;&#xa;Provider Name&#xa;GoMove&#xa;Provider Phone Number&#xa;(919) 410-3343&#xa;Address&#xa;Customer Address&#xa;1426 Chinqua Pine Dr&#xa;Customer City, State ∧ Postal Code&#xa;Cary, NC 27519&#xa;What to Expect&#xa;&#xa;ServiceInformation&#x9;Payment Code&#x9;Total&#xa;Date and Service Name&#xa;7/11/2024 - Load/Unload&#xa;Time of Day and Service Details&#xa;Morning - 4 hours 2 helpers&#xa;248144&#xa;Do not give out your Payment Code until your move is complete.&#xa;&#xa;Service Price&#xa;$360.00&#xa;&#xa;Refundable Handling Fee:&#x9;$5.95&#xa;Subtotal:&#x9;$365.95" ID="ID_1351896917" CREATED="1720639687519" MODIFIED="1720639690873"/>
<node TEXT="" ID="ID_1449066604" CREATED="1720640937160" MODIFIED="1720640937160"/>
</node>
</node>
<node TEXT="AAA" FOLDED="true" ID="ID_492194537" CREATED="1688926806930" MODIFIED="1688926808827">
<node TEXT="429                005                105393521                3" ID="ID_705493956" CREATED="1688926817864" MODIFIED="1688926817864"/>
<node TEXT="Monica McMillen" ID="ID_281705106" CREATED="1688926809602" MODIFIED="1688926815595"/>
</node>
<node TEXT="Hotels" FOLDED="true" ID="ID_224478334" CREATED="1679174624274" MODIFIED="1679174627195">
<node TEXT="Booking" FOLDED="true" ID="ID_791016874" CREATED="1679174627565" MODIFIED="1679174629961">
<node TEXT="Use Wells Fargo Autograph Card" ID="ID_395430206" CREATED="1713719750326" MODIFIED="1713719761107"/>
<node TEXT="Use AAA rate" ID="ID_591529271" CREATED="1713719761821" MODIFIED="1713719767407"/>
<node ID="ID_1057214067" CREATED="1679174943171" MODIFIED="1679174943171" LINK="https://www.priceline.com/?vrid=9cb65dfddfe46d76389f01bc39a9fe7d"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.priceline.com/?vrid=9cb65dfddfe46d76389f01bc39a9fe7d">Priceline.com - The Best Deals on Hotels, Flights and Rental Cars.</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Holiday Inn" FOLDED="true" ID="ID_1444048975" CREATED="1607023126182" MODIFIED="1607023132854">
<node ID="ID_1805176909" CREATED="1609776843506" MODIFIED="1609776843506" LINK="https://www.holidayinnexpress.com/rewardsclub/us/en/sign-in?fwdest=%2Frewardsclub%2Fus%2Fen%2Faccount-mgmt%2Fstaysevents"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.holidayinnexpress.com/rewardsclub/us/en/sign-in?fwdest=%2Frewardsclub%2Fus%2Fen%2Faccount-mgmt%2Fstaysevents">IHG&#160;|&#160;Login</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="IHG Rewards" FOLDED="true" ID="ID_426249178" CREATED="1607023133677" MODIFIED="1607023143827">
<node TEXT="252783086" OBJECT="java.lang.Long|252783086" ID="ID_332244391" CREATED="1607023145207" MODIFIED="1607023160857"/>
<node TEXT="Lucydog1" ID="ID_1252809851" CREATED="1713718468105" MODIFIED="1713718473016"/>
<node TEXT="32512 on 12/3/20" ID="ID_72624305" CREATED="1607023172839" MODIFIED="1607023188398"/>
</node>
</node>
<node TEXT="Hilton Honors" FOLDED="true" ID="ID_1347759143" CREATED="1537210560244" MODIFIED="1537210578541">
<node ID="ID_496300994" CREATED="1599760411903" MODIFIED="1599760411903" LINK="https://secure3.hilton.com/en/hh/customer/login/index.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://secure3.hilton.com/en/hh/customer/login/index.htm">Sign In - Hilton Honors</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="786192244" ID="ID_925403078" CREATED="1537210604802" MODIFIED="1537210612377"/>
<node TEXT="SILVER" ID="ID_897549090" CREATED="1537210612381" MODIFIED="1537210612383"/>
<node TEXT="Lucydog1" ID="ID_1330760791" CREATED="1537210730714" MODIFIED="1537210762981"/>
</node>
<node ID="ID_136092960" CREATED="1713718006712" MODIFIED="1713718006712" LINK="https://www.marriott.com/default.mi"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.marriott.com/default.mi">Marriott Bonvoy Hotels | Book Directly &amp; Get Exclusive Rates</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_10650845" CREATED="1688927705499" MODIFIED="1688927707652"/>
<node TEXT="Lucydog1" ID="ID_1655937238" CREATED="1688927723779" MODIFIED="1688927891684"/>
<node TEXT="Rewards Number" FOLDED="true" ID="ID_1348842516" CREATED="1688927709115" MODIFIED="1688927713284">
<node TEXT="593124290" ID="ID_1342841404" CREATED="1688927715068" MODIFIED="1688927715068"/>
</node>
<node TEXT="courtyard" ID="ID_1790608738" CREATED="1713717966153" MODIFIED="1713717968337"/>
</node>
<node TEXT="Wyndham Rewards" FOLDED="true" ID="ID_1500213452" CREATED="1719544876091" MODIFIED="1719544876091">
<node TEXT="member number" ID="ID_1609310073" CREATED="1719544884741" MODIFIED="1719544887201">
<node TEXT="503934004H" ID="ID_985161233" CREATED="1719544889248" MODIFIED="1719544889248"/>
</node>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1206619929" CREATED="1719544897145" MODIFIED="1719544905375"/>
</node>
</node>
<node TEXT="Flight" FOLDED="true" ID="ID_874452326" CREATED="1714788247844" MODIFIED="1714788249797">
<node TEXT="American Airlines" FOLDED="true" ID="ID_1034649638" CREATED="1551915469031" MODIFIED="1551915472976">
<node TEXT="2ER83W4" ID="ID_1202579652" CREATED="1551915665768" MODIFIED="1551915665768"/>
<node TEXT="Lucydog1" ID="ID_1309977134" CREATED="1551915688452" MODIFIED="1551915691333"/>
</node>
<node FOLDED="true" ID="ID_1396067944" CREATED="1578432036472" MODIFIED="1578432036472" LINK="https://www.southwest.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.southwest.com/">Southwest Airlines | Book Flights &amp; More - Wanna Get Away?</a>
  </body>
</html>
</richcontent>
<node TEXT="mmcmillenSW" ID="ID_1979191644" CREATED="1572231307927" MODIFIED="1572231307927"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1362268221" CREATED="1572231309639" MODIFIED="1572231374374"/>
<node TEXT="Lucydog1$" ID="ID_513707707" CREATED="1572109079955" MODIFIED="1572109140279"/>
</node>
<node TEXT="Delta" ID="ID_1692421174" CREATED="1714788257119" MODIFIED="1714788259639">
<node TEXT="mandmmcmillen" ID="ID_1246063986" CREATED="1714788260390" MODIFIED="1714788264571"/>
<node TEXT="Lucydog1" ID="ID_826043911" CREATED="1714788265011" MODIFIED="1714788306429"/>
<node TEXT="Security Qs" FOLDED="true" ID="ID_1836601789" CREATED="1714788307128" MODIFIED="1714788310899">
<node TEXT="First school: Romoland Elementary" ID="ID_374922101" CREATED="1714788311651" MODIFIED="1714788317218"/>
<node TEXT="First pet: Dusty" ID="ID_582324493" CREATED="1714788325341" MODIFIED="1714788374926"/>
</node>
</node>
</node>
<node FOLDED="true" ID="ID_359903797" CREATED="1519763434129" MODIFIED="1519763996624" LINK="https://www.concursolutions.com/">
<icon BUILTIN="password"/>
<richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      <a href="https://www.concursolutions.com/">Sign in to Concur | Concur Solutions</a>
    </p>
  </body>
</html>
</richcontent>
<node ID="ID_665812347" CREATED="1519763434133" MODIFIED="1526925875772"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      U581917@syngenta.com
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Mobile" FOLDED="true" ID="ID_451972131" CREATED="1574267548520" MODIFIED="1574267551331">
<node TEXT="Company Code: JLE7XH" ID="ID_1837968569" CREATED="1574267556210" MODIFIED="1574267556210"/>
</node>
</node>
<node TEXT="Car Rental" ID="ID_372504913" CREATED="1714412097691" MODIFIED="1714412100644">
<node ID="ID_940764093" CREATED="1714412109826" MODIFIED="1714412117110" LINK="https://travel.calstate.aaa.com/car/availability/results?pickup.location=Gilroy%2C%20California%2C%20United%20States&amp;dropoff.date=2024-07-08&amp;promotion.code=&amp;dropoff.location=Norman%20Y.%20Mineta%20San%20Jose%20International%20Airport%20(SJC)%2C%20San%20Jose%2C%20CA&amp;pickup.time=0800&amp;pickup.date=2024-07-08&amp;search-id=DXgyviImRCyg_YFHQ3bksQ&amp;dropoff.time=1030"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://travel.calstate.aaa.com/car/availability/results?pickup.location=Gilroy%2C%20California%2C%20United%20States&amp;dropoff.date=2024-07-08&amp;promotion.code=&amp;dropoff.location=Norman%20Y.%20Mineta%20San%20Jose%20International%20Airport%20(SJC)%2C%20San%20Jose%2C%20CA&amp;pickup.time=0800&amp;pickup.date=2024-07-08&amp;search-id=DXgyviImRCyg_YFHQ3bksQ&amp;dropoff.time=1030">AAA Car Results</a>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
</node>
<node TEXT="Hertz" FOLDED="true" ID="ID_1852288932" CREATED="1578431774008" MODIFIED="1578431799658" LINK="https://www.hertz.com/rentacar/reservation/">
<font BOLD="true"/>
<node TEXT="mmcmillenHertz" ID="ID_1126558324" CREATED="1572109634216" MODIFIED="1572109639501"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1857847691" CREATED="1572109077534" MODIFIED="1572109078796"/>
<node TEXT="Lucydog1$" ID="ID_1052853734" CREATED="1572109079955" MODIFIED="1572109140279"/>
</node>
<node TEXT="Budget" ID="ID_1795642725" CREATED="1720981735034" MODIFIED="1720981737419">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1178119844" CREATED="1720981949755" MODIFIED="1720981951980"/>
<node TEXT="X%9-3Pvv8Nu!kX2" ID="ID_445626042" CREATED="1720981952514" MODIFIED="1720981954290"/>
<node TEXT="reservations" ID="ID_1318959167" CREATED="1720982027304" MODIFIED="1720982029853">
<node ID="ID_730622673" CREATED="1720982030520" MODIFIED="1720982030520"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <span style="color: rgb(0, 0, 0); font-family: Nunito Sans, Calibri; font-size: 16px; font-style: normal; font-weight: 700; letter-spacing: normal; text-align: left; text-indent: 0px; text-transform: none; word-spacing: 0px; white-space: normal; background-color: rgb(255, 255, 255); display: inline !important; float: none;">04993632US0</span>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Six Flags" FOLDED="true" ID="ID_1866534304" CREATED="1607456949102" MODIFIED="1607456970926">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1390656341" CREATED="1607456973334" MODIFIED="1607456990535"/>
</node>
<node FOLDED="true" ID="ID_1619665630" CREATED="1709589689010" MODIFIED="1709589710254" LINK="https://rightwayparking.com/login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://rightwayparking.com/login">Rightway Parking</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1340299156" CREATED="1709589712368" MODIFIED="1709589714665"/>
<node TEXT="Lucydog1" ID="ID_885040866" CREATED="1709589718161" MODIFIED="1709590359586"/>
</node>
<node TEXT="Uber" ID="ID_675346292" CREATED="1714411175909" MODIFIED="1714411178513"/>
</node>
<node TEXT="Computer" POSITION="bottom_or_right" ID="ID_1865753528" CREATED="1520107513961" MODIFIED="1597263028011">
<node TEXT="Email" FOLDED="true" ID="ID_321419150" CREATED="1520107513961" MODIFIED="1597263028003">
<node TEXT="ISU" FOLDED="true" ID="ID_1246554494" CREATED="1520107513961" MODIFIED="1597263027997">
<node TEXT="mcmillen@iastate.edu" ID="ID_544344502" CREATED="1520107513961" MODIFIED="1520107513961" LINK="mailto:mcmillen@iastate.edu"/>
<node TEXT="dr0w$$@p" ID="ID_964388089" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="Google" FOLDED="true" ID="ID_1107045483" CREATED="1520107513961" MODIFIED="1713889148278"><richcontent TYPE="NOTE">
<html>
  <head>
    
  </head>
  <body>
    <p>
      login at least once every two years
    </p>
  </body>
</html></richcontent>
<node TEXT="Michael And Monica" ID="ID_1991798078" CREATED="1713889087388" MODIFIED="1713889092823">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_472825423" CREATED="1520107513961" MODIFIED="1597263027999" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="Lucydog1*" ID="ID_1258269992" CREATED="1585420903683" MODIFIED="1585420909651"/>
<node TEXT="2Do" FOLDED="true" ID="ID_1183400947" CREATED="1675623429837" MODIFIED="1675623434078">
<node TEXT="Install under this account" ID="ID_1250015603" CREATED="1675623564496" MODIFIED="1675623571907"/>
</node>
</node>
<node TEXT="Michael Mcmillan" FOLDED="true" ID="ID_675933679" CREATED="1713889104341" MODIFIED="1713889107874">
<node TEXT="Mcmillen.michael.s@gmail.com" FOLDED="true" ID="ID_1621112683" CREATED="1520107513961" MODIFIED="1597263028001" LINK="mailto:Mcmillen.michael.s@gmail.com">
<node TEXT="Lucydog1*" ID="ID_246711777" CREATED="1571931739822" MODIFIED="1597263028000"/>
</node>
</node>
<node TEXT="mmcmillen@csumb.edu" FOLDED="true" ID="ID_1866832881" CREATED="1691795824427" MODIFIED="1691795827803">
<node TEXT="login through monterrey account" ID="ID_848779875" CREATED="1691795934985" MODIFIED="1691795951342"/>
</node>
</node>
<node TEXT="Microsoft Account" ID="ID_603115965" CREATED="1520107513961" MODIFIED="1597263028003">
<node TEXT="michael.s.mcmillen@outlook.com" FOLDED="true" ID="ID_1683887355" CREATED="1520107513961" MODIFIED="1528127790077">
<node TEXT="Lucydog1" ID="ID_342169148" CREATED="1520107513961" MODIFIED="1520107513961"/>
<node ID="ID_1919846697" CREATED="1563602478152" MODIFIED="1563602478152" LINK="https://academy.microsoft.com/en-us/professional-program/tracks/data-science/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://academy.microsoft.com/en-us/professional-program/tracks/data-science/">Online Data Science Courses | Microsoft Professional Program</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1991953963" CREATED="1520107513961" MODIFIED="1559539164307">
<node TEXT="Lucydog5" ID="ID_1237146107" CREATED="1520107513961" MODIFIED="1561582735871"/>
</node>
<node TEXT="micromike777@hotmail.com" FOLDED="true" POSITION="bottom_or_right" ID="ID_484612204" CREATED="1520107513961" MODIFIED="1520229091720">
<node TEXT="Q1w1e1r1" ID="ID_1677343694" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="michael.mcmillen@syngenta.com" FOLDED="true" POSITION="bottom_or_right" ID="ID_444725583" CREATED="1691097515245" MODIFIED="1691097532863">
<node TEXT="Q1w1e1re" ID="ID_201550633" CREATED="1691097538429" MODIFIED="1691097542511"/>
</node>
</node>
</node>
<node TEXT="AI" FOLDED="true" ID="ID_1603462766" CREATED="1710193741548" MODIFIED="1710193743457">
<node FOLDED="true" ID="ID_367569298" CREATED="1710193871172" MODIFIED="1710193871172" LINK="https://huggingface.co/welcome"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://huggingface.co/welcome">Hugging Face – The AI community building the future.</a>
  </body>
</html>
</richcontent>
<node TEXT="McMillen-hf" ID="ID_1517239084" CREATED="1710193805369" MODIFIED="1710193847762"/>
<node TEXT="4NCDF.mAbLFj6w8" ID="ID_1202040117" CREATED="1710193776157" MODIFIED="1710193776157"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1992464003" CREATED="1710193813761" MODIFIED="1710193815767"/>
</node>
</node>
<node TEXT="Data" FOLDED="true" ID="ID_1719062182" CREATED="1710341377664" MODIFIED="1710341379396">
<node ID="ID_1709648579" CREATED="1710345735287" MODIFIED="1710345735287" LINK="https://public.tableau.com/app/profile/michael.mcmillen/vizzes"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://public.tableau.com/app/profile/michael.mcmillen/vizzes">Profile - michael.mcmillen | Tableau Public</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Oracle" FOLDED="true" ID="ID_808178146" CREATED="1705352802952" MODIFIED="1705352805578">
<node TEXT="Michael.S.McMillen@Outlook.com" ID="ID_1944778368" CREATED="1705352818428" MODIFIED="1705352821620"/>
<node TEXT="Lucydog1*" ID="ID_1993721559" CREATED="1705352822833" MODIFIED="1705352832027"/>
</node>
</node>
<node TEXT="Discord" FOLDED="true" ID="ID_1209323177" CREATED="1717698081746" MODIFIED="1717698085408">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_949680386" CREATED="1717698085416" MODIFIED="1717698088796"/>
<node TEXT="Lucydog123*" ID="ID_545016302" CREATED="1717698089628" MODIFIED="1717698115557"/>
</node>
<node TEXT="Dropbox" FOLDED="true" ID="ID_1011206130" CREATED="1544543797265" MODIFIED="1597263027986" LINK="https://www.dropbox.com/">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1681429413" CREATED="1544543803025" MODIFIED="1544549868265"/>
<node TEXT="Dr0w$$@p" ID="ID_1240723605" CREATED="1544549868749" MODIFIED="1544549905314"/>
</node>
<node TEXT="Ubuntu" FOLDED="true" ID="ID_689767047" CREATED="1590775799093" MODIFIED="1597263027988">
<node TEXT="mike" ID="ID_1267868497" CREATED="1590775805042" MODIFIED="1590775806364"/>
<node TEXT="pass" ID="ID_415086350" CREATED="1590775806809" MODIFIED="1590775808527"/>
</node>
<node TEXT="Clockify" FOLDED="true" ID="ID_972877496" CREATED="1585332430623" MODIFIED="1597263027990">
<node TEXT="michael.mcmillen@syngenta.com" FOLDED="true" ID="ID_1706183698" CREATED="1585421088180" MODIFIED="1585421090886">
<node TEXT="Lucydog1" ID="ID_1224963108" CREATED="1585332438700" MODIFIED="1585332442939"/>
</node>
<node TEXT="mcmillen.michael.s@gmail.com" FOLDED="true" ID="ID_1063111075" CREATED="1585421095269" MODIFIED="1585421100484">
<node TEXT="Gmail" ID="ID_159362404" CREATED="1585421103228" MODIFIED="1585421105577"/>
</node>
</node>
<node TEXT="PC Login" FOLDED="true" ID="ID_1157560438" CREATED="1520228807510" MODIFIED="1597263027992">
<node TEXT="Marks PC" FOLDED="true" ID="ID_1868081350" CREATED="1544733397767" MODIFIED="1544733401339">
<node TEXT="me" ID="ID_1785358814" CREATED="1544733402255" MODIFIED="1544733403683"/>
<node TEXT="password" ID="ID_1186041064" CREATED="1544733404024" MODIFIED="1544733407066"/>
</node>
<node TEXT="micromike777@hotmail.com" ID="ID_541014060" CREATED="1520107513961" MODIFIED="1520229086511"/>
<node TEXT="Lucydog1" ID="ID_1666665577" CREATED="1520228824122" MODIFIED="1520228827293"/>
</node>
<node TEXT="Github:" FOLDED="true" ID="ID_1176215417" CREATED="1520107513961" MODIFIED="1597263028004">
<node TEXT="mmcmille" ID="ID_869094594" CREATED="1520107513961" MODIFIED="1520107513961"/>
<node TEXT="39djD@4f" ID="ID_1746633309" CREATED="1520107513961" MODIFIED="1624126809220"/>
</node>
<node TEXT="Apps" FOLDED="true" ID="ID_954854610" CREATED="1520107715487" MODIFIED="1597263028005">
<node TEXT="Android" FOLDED="true" ID="ID_794519856" CREATED="1690930623570" MODIFIED="1690930626172">
<node TEXT="Very Fit" FOLDED="true" ID="ID_50052045" CREATED="1690930609537" MODIFIED="1690930617164">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_92949553" CREATED="1690930631966" MODIFIED="1690930635720"/>
</node>
<node TEXT="AIO" FOLDED="true" ID="ID_1664926954" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1306510996" CREATED="1520107513961" MODIFIED="1520107513961" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="password" ID="ID_1889718263" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
</node>
<node TEXT="My Kaspersky | Subscriptions" FOLDED="true" ID="ID_1513740755" CREATED="1690930582571" MODIFIED="1690930599116" LINK="https://my.kaspersky.com/MyLicenses#/details/e20f5d68-2533-475a-a596-5fa5ca15f767-862">
<node TEXT="Mcmillen.michael.s@gmail.com" ID="ID_1689095384" CREATED="1690930582571" MODIFIED="1690930582571" LINK="mailto:Mcmillen.michael.s@gmail.com"/>
<node TEXT="Lucydog1" ID="ID_622430938" CREATED="1690930582575" MODIFIED="1690930582575"/>
</node>
<node TEXT="Skype" ID="ID_1392091348" CREATED="1520107513961" MODIFIED="1542340582593"/>
<node TEXT="RollApp" FOLDED="true" ID="ID_361510322" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="Freeplane Online - Mind-mapping and Psychology App â€“ rollApp" ID="ID_495942227" CREATED="1520107513961" MODIFIED="1520107763158" LINK="https://www.rollapp.com/app/freeplane"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1780949642" CREATED="1520107513961" MODIFIED="1520868858786"/>
<node TEXT="dr0w$$@p" ID="ID_609301691" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="Digoo camera" ID="ID_1771960807" CREATED="1520107513961" MODIFIED="1520107513961"/>
<node TEXT="U-Cam" FOLDED="true" ID="ID_1694674598" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="Lucydog1" ID="ID_1291648986" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="Wunderlist" FOLDED="true" ID="ID_1254903769" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_1274354041" CREATED="1520107513961" MODIFIED="1597263035411" LINK="mailto:michael.mcmillen@syngenta.com">
<icon BUILTIN="help"/>
</node>
<node TEXT="Lucydog1" ID="ID_1219569668" CREATED="1520107513961" MODIFIED="1597263035412">
<icon BUILTIN="help"/>
</node>
</node>
<node TEXT="Ustvnow" FOLDED="true" ID="ID_301585087" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_189591694" CREATED="1520107513961" MODIFIED="1520107513961" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="Lucydog1" ID="ID_1862750891" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="MEmu" ID="ID_1357833880" CREATED="1608061861985" MODIFIED="1608061871388"/>
</node>
<node TEXT="USPS:" FOLDED="true" ID="ID_1588209877" CREATED="1520107513961" MODIFIED="1597263028006">
<node TEXT="shipping labels" ID="ID_787413762" CREATED="1692833973280" MODIFIED="1692833982934"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_596338249" CREATED="1520107513961" MODIFIED="1520107513961" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="Dr0w55@p12" ID="ID_1782784352" CREATED="1520107513961" MODIFIED="1520107513961" LINK="mailto:Dr0w55@p12"/>
</node>
<node TEXT="ADP:" FOLDED="true" ID="ID_1788028911" CREATED="1520107513961" MODIFIED="1597263028007">
<node TEXT="mmcmille" ID="ID_1971508610" CREATED="1520107513961" MODIFIED="1520107513961"/>
<node TEXT="reg" ID="ID_1344283808" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="WiFi Routers" ID="ID_1577595547" CREATED="1520107513961" MODIFIED="1597263028008">
<node TEXT="MonicaNell" FOLDED="true" ID="ID_1401624381" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="Login" FOLDED="true" ID="ID_91558831" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="admin" ID="ID_1957620919" CREATED="1520107513961" MODIFIED="1520107513961"/>
<node TEXT="Lucydog1" ID="ID_589482914" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
<node TEXT="Wifi" FOLDED="true" ID="ID_374434411" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="Lucydog1" ID="ID_665388752" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
</node>
<node TEXT="TP-Link" ID="ID_432454868" CREATED="1720751158469" MODIFIED="1720751205795">
<node TEXT="admin password" ID="ID_294945487" CREATED="1720751972127" MODIFIED="1720751975731">
<node TEXT="/PCWEzSX&amp;8c*32" ID="ID_1781459670" CREATED="1720751532377" MODIFIED="1720751532377"/>
</node>
<node TEXT="Config" ID="ID_13683457" CREATED="1720751945105" MODIFIED="1720751946961">
<node TEXT="M&amp;Ms_2G" ID="ID_993054641" CREATED="1720751947612" MODIFIED="1720751952563"/>
<node TEXT="M&amp;Ms_5G" ID="ID_479033105" CREATED="1720751947612" MODIFIED="1720751961313"/>
<node TEXT="Lucydog1" ID="ID_1355413322" CREATED="1720751953059" MODIFIED="1720751969524"/>
</node>
<node TEXT="Default config" ID="ID_1475567082" CREATED="1720751935234" MODIFIED="1720751939997">
<node TEXT="TP_Link_B425_5G" ID="ID_1257859312" CREATED="1720751220145" MODIFIED="1720751429295"/>
<node TEXT="20822156" OBJECT="java.lang.Long|20822156" ID="ID_1213108360" CREATED="1720751206516" MODIFIED="1720751219423"/>
</node>
</node>
</node>
<node TEXT="Ubuntu" FOLDED="true" ID="ID_1419969032" CREATED="1520107513961" MODIFIED="1597263028008">
<node TEXT="Michael" FOLDED="true" ID="ID_65306919" CREATED="1520107513961" MODIFIED="1520107513961">
<node TEXT="password" ID="ID_1728397163" CREATED="1520107513961" MODIFIED="1520107513961"/>
</node>
</node>
<node TEXT="Roccat Remote" FOLDED="true" ID="ID_1283463723" CREATED="1519945424842" MODIFIED="1597263028009">
<node ID="ID_1583408295" CREATED="1519945513953" MODIFIED="1519945513953" LINK="https://www.roccat.org/en-US/Products/Gaming-Software/Power-Grid/Store/Grids/Programs/Windows/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.roccat.org/en-US/Products/Gaming-Software/Power-Grid/Store/Grids/Programs/Windows/">ROCCAT&#174; &#8211; Set the Rules &#187; Power-Grid &#187; Store &#187; Store &#187; Grids &#187; Programs &#187; Windows</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="mmcmille" ID="ID_770768928" CREATED="1519945482589" MODIFIED="1519945488044"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_172679629" CREATED="1519945414011" MODIFIED="1519945418839"/>
<node TEXT="Roccat123" ID="ID_400788481" CREATED="1519945442107" MODIFIED="1519945458221"/>
</node>
<node TEXT="Arduino" FOLDED="true" ID="ID_1859972486" CREATED="1525975646590" MODIFIED="1597263028010">
<node TEXT="mmcmille" ID="ID_1182181893" CREATED="1525975663773" MODIFIED="1525975666175"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1966080454" CREATED="1525975652310" MODIFIED="1525975654008"/>
<node TEXT="Lucydog1" ID="ID_784072687" CREATED="1525975654758" MODIFIED="1525975662816"/>
</node>
<node TEXT="Games" FOLDED="true" ID="ID_177648202" CREATED="1520108223815" MODIFIED="1597263028010">
<node TEXT="Xbox" FOLDED="true" ID="ID_946810365" CREATED="1703783003716" MODIFIED="1703783006698">
<node TEXT="Microsoft" ID="ID_1618593501" CREATED="1703783195633" MODIFIED="1703783199380"/>
<node TEXT="zxsd777@hotmail.com" ID="ID_1203400508" CREATED="1703783007749" MODIFIED="1703783054963"/>
<node TEXT="Lucydog1" ID="ID_958592767" CREATED="1703783116095" MODIFIED="1703783119541"/>
</node>
<node TEXT="Steam" FOLDED="true" ID="ID_1008440390" CREATED="1520108223815" MODIFIED="1520108223815">
<node TEXT="polkaking777" ID="ID_260718754" CREATED="1520108223815" MODIFIED="1520108223815"/>
<node TEXT="Reg" ID="ID_733413492" CREATED="1520108223815" MODIFIED="1520108223815"/>
</node>
<node TEXT="Faeria" FOLDED="true" ID="ID_1629003451" CREATED="1520108223815" MODIFIED="1520108223815">
<node TEXT="MnMz" ID="ID_447695859" CREATED="1520108223815" MODIFIED="1520108223815"/>
<node TEXT="Lucky007" ID="ID_676632408" CREATED="1520108223815" MODIFIED="1520108223815"/>
</node>
<node TEXT="Dominion:" FOLDED="true" ID="ID_43681016" CREATED="1520108223815" MODIFIED="1520108223815">
<node TEXT="mnmmcmillen" FOLDED="true" ID="ID_1377057115" CREATED="1588088144020" MODIFIED="1588088152700">
<node TEXT="Lucydog1" ID="ID_1719342277" CREATED="1588088158742" MODIFIED="1588088164137"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1652720315" CREATED="1588088164809" MODIFIED="1588088167220"/>
</node>
<node TEXT="polkaking777" ID="ID_432977537" CREATED="1520108223815" MODIFIED="1520108223815"/>
<node TEXT="password1" ID="ID_1967339156" CREATED="1520108223815" MODIFIED="1520108223815"/>
</node>
<node TEXT="Uplay" FOLDED="true" ID="ID_503441237" CREATED="1589836726732" MODIFIED="1589836726732">
<node TEXT="McMillen.michael.s@gmail.com" ID="ID_1749135086" CREATED="1589836726735" MODIFIED="1589836726735" LINK="mailto:McMillen.michael.s@gmail.com"/>
<node TEXT="Lucydog1*" ID="ID_1026054435" CREATED="1589836726737" MODIFIED="1589836726737"/>
</node>
</node>
<node TEXT="Music" FOLDED="true" ID="ID_1810325756" CREATED="1520108223815" MODIFIED="1597263028011">
<node TEXT="KVR" FOLDED="true" ID="ID_1466629382" CREATED="1520108223816" MODIFIED="1520108223816">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1987581923" CREATED="1520108223816" MODIFIED="1520108223816" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="mmcmillen" ID="ID_1353574135" CREATED="1520108223816" MODIFIED="1520108223816"/>
<node TEXT="Mmcmillen1" ID="ID_484812004" CREATED="1520108223816" MODIFIED="1520108223816"/>
</node>
<node TEXT="Inspired Instruments/YRG:" FOLDED="true" ID="ID_675682463" CREATED="1520108223816" MODIFIED="1520108223816">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1962067988" CREATED="1520108223816" MODIFIED="1520108223816" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="Luckydog1" ID="ID_386758817" CREATED="1520108223816" MODIFIED="1520108223816"/>
</node>
<node TEXT="Pandora" FOLDED="true" ID="ID_1192473319" CREATED="1547585823669" MODIFIED="1547585826232">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_708371252" CREATED="1547586125265" MODIFIED="1547586127476"/>
</node>
</node>
<node TEXT="YouTube" FOLDED="true" ID="ID_1423189184" CREATED="1632322301993" MODIFIED="1632322305074">
<node TEXT="API key" FOLDED="true" ID="ID_1734613502" CREATED="1632322314111" MODIFIED="1632322322552">
<node TEXT="AIzaSyBc6g-MhKAuq_Xf6CWhhu7GDMjySdxQfgk" ID="ID_1664851380" CREATED="1632322323936" MODIFIED="1632322323936"/>
</node>
</node>
<node TEXT="adobe" FOLDED="true" ID="ID_1788269911" CREATED="1677963304040" MODIFIED="1677963305487">
<node TEXT="AdobeID is mcmillen.michael.s@gmail.com." ID="ID_1557534617" CREATED="1677963314055" MODIFIED="1677963314055" LINK="mailto:mcmillen.michael.s@gmail.com."/>
</node>
</node>
<node TEXT="iPhone" FOLDED="true" POSITION="bottom_or_right" ID="ID_1654188642" CREATED="1716314270652" MODIFIED="1716314337421">
<node TEXT="Passcode" FOLDED="true" ID="ID_312471408" CREATED="1716314350841" MODIFIED="1716314355001">
<node TEXT="258963" OBJECT="java.lang.Long|258963" ID="ID_83149689" CREATED="1716314355997" MODIFIED="1716314543214"/>
</node>
<node FOLDED="true" ID="ID_1692307154" CREATED="1550785021693" MODIFIED="1597263027993" LINK="https://www.icloud.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.icloud.com/">Apple ID iCloud</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_259089221" CREATED="1528383921170" MODIFIED="1528383923998"/>
<node TEXT="Dr0w554p" ID="ID_281885763" CREATED="1528383924733" MODIFIED="1528384075842"/>
<node TEXT="Apple ID Code" FOLDED="true" ID="ID_946862246" CREATED="1716316903369" MODIFIED="1716316910307">
<node TEXT="687175" OBJECT="java.lang.Long|687175" ID="ID_786742460" CREATED="1716316895477" MODIFIED="1716316902946"/>
</node>
</node>
</node>
<node TEXT="Online Shopping" FOLDED="true" POSITION="bottom_or_right" ID="ID_208622430" CREATED="1520107411264" MODIFIED="1597263028036">
<node TEXT="Panda Express" FOLDED="true" ID="ID_992666486" CREATED="1640570306919" MODIFIED="1640570311729">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1175773611" CREATED="1640570428749" MODIFIED="1640570440331"/>
<node TEXT="Lucydog1" ID="ID_1995588316" CREATED="1640570440578" MODIFIED="1640570443536"/>
</node>
<node TEXT="Supply.com" FOLDED="true" ID="ID_319085307" CREATED="1593388356823" MODIFIED="1597263028015">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_824839679" CREATED="1593388361988" MODIFIED="1597263028014"/>
<node TEXT="Lucydog1" ID="ID_1453977088" CREATED="1593388364337" MODIFIED="1597263028014"/>
</node>
<node TEXT="SupplyHouse" FOLDED="true" ID="ID_1616851475" CREATED="1593123803134" MODIFIED="1597263028017">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_242682351" CREATED="1593123811001" MODIFIED="1597263028016"/>
<node TEXT="Lucydog1" ID="ID_1556771681" CREATED="1593123813800" MODIFIED="1597263028017"/>
</node>
<node TEXT="Syngenta" FOLDED="true" ID="ID_321320134" CREATED="1562946211124" MODIFIED="1597263028017">
<node FOLDED="true" ID="ID_673123240" CREATED="1562946219008" MODIFIED="1562946219008" LINK="https://syngenta.accessperks.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://syngenta.accessperks.com/">Access Deals</a>
  </body>
</html>
</richcontent>
<node TEXT="the case-sensitive registration code is syngentaperks." ID="ID_474967612" CREATED="1562946244610" MODIFIED="1562946244610"/>
</node>
</node>
<node TEXT="Bestbuy" FOLDED="true" ID="ID_947436934" CREATED="1592719817678" MODIFIED="1597263028019">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_114954811" CREATED="1592719823050" MODIFIED="1597263028019"/>
<node TEXT="Lucydog1*" ID="ID_1004713462" CREATED="1592719826142" MODIFIED="1597263028019"/>
</node>
<node TEXT="Overstock" FOLDED="true" ID="ID_658835572" CREATED="1544567546086" MODIFIED="1597263028020">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_825709132" CREATED="1544567551477" MODIFIED="1544567553199"/>
<node TEXT="dr0w$$@p" ID="ID_1154870761" CREATED="1544567571843" MODIFIED="1544567574247"/>
</node>
<node TEXT="Amazon" ID="ID_401484026" CREATED="1542066982397" MODIFIED="1597263028023">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1192745059" CREATED="1542066986687" MODIFIED="1597263028023">
<node TEXT="Lucydog1" ID="ID_1203246180" CREATED="1562022958596" MODIFIED="1597263028023"/>
</node>
<node TEXT="Amazon Business" FOLDED="true" ID="ID_1637051420" CREATED="1532111016838" MODIFIED="1597263028023">
<node TEXT="Michael McMillen" ID="ID_1451581781" CREATED="1532111033934" MODIFIED="1532111040371"/>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_1863457021" CREATED="1532111041717" MODIFIED="1532111050275"/>
<node TEXT="Lucydog1" ID="ID_1969922752" CREATED="1532111051893" MODIFIED="1532111055683"/>
<node TEXT="Payment" FOLDED="true" ID="ID_1391981506" CREATED="1541448030058" MODIFIED="1541448032612">
<node TEXT="PCARD Arnett Young" FOLDED="true" ID="ID_43931771" CREATED="1541448034459" MODIFIED="1541448044745">
<node TEXT="4275 3300 0366 4688" ID="ID_296093242" CREATED="1541448046582" MODIFIED="1541448058029"/>
<node TEXT="exp 03/22" ID="ID_1531892164" CREATED="1541448058583" MODIFIED="1541448063245"/>
<node TEXT="RBATL446" ID="ID_14301665" CREATED="1541448064060" MODIFIED="1541448080978"/>
<node TEXT="726" OBJECT="java.lang.Long|726" ID="ID_1808272949" CREATED="1541448085134" MODIFIED="1541448086914"/>
<node TEXT="Address" FOLDED="true" ID="ID_1429399048" CREATED="1541519712041" MODIFIED="1541519715317">
<node TEXT="630 Townsend Dr." ID="ID_1522503406" CREATED="1541519700738" MODIFIED="1541519709642"/>
<node TEXT="Aptos, CA 95003" ID="ID_525041312" CREATED="1541519717052" MODIFIED="1541519724525"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Health" FOLDED="true" ID="ID_443380587" CREATED="1540569466080" MODIFIED="1597263028024">
<font BOLD="true"/>
<node TEXT="MindNutrition" FOLDED="true" ID="ID_1783792488" CREATED="1539118578441" MODIFIED="1539118652059">
<node ID="ID_771295987" CREATED="1539118585416" MODIFIED="1539118585416" LINK="https://mindnutrition-us.com/quick-order"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mindnutrition-us.com/quick-order">Order - Mind Nutrition USA</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1068800378" CREATED="1539118653075" MODIFIED="1539118656428"/>
<node TEXT="MindNutrition01" ID="ID_1204202994" CREATED="1539118657161" MODIFIED="1539118671692"/>
<node ID="ID_30285697" CREATED="1539121923891" MODIFIED="1539121923891" LINK="https://mindnutrition.com/profile/login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mindnutrition.com/profile/login">Make a new account - Mind Nutrition</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Liftmode" FOLDED="true" ID="ID_214336667" CREATED="1540569515592" MODIFIED="1540570656773" LINK="https://liftmode.com/customer/account/">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_675546870" CREATED="1540570460663" MODIFIED="1540570463128"/>
<node TEXT="Liftmode" ID="ID_982882686" CREATED="1540570463654" MODIFIED="1540570465601"/>
</node>
</node>
<node TEXT="Walmart" FOLDED="true" ID="ID_1643066796" CREATED="1520107411264" MODIFIED="1597263028024">
<font BOLD="false"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_215326477" CREATED="1520107411264" MODIFIED="1524767925361"/>
<node TEXT="Lucydog1" ID="ID_675461696" CREATED="1520107411264" MODIFIED="1520107411264"/>
</node>
<node TEXT="Kmart" FOLDED="true" ID="ID_77670361" CREATED="1571263267947" MODIFIED="1597263028025">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1385421210" CREATED="1571263272280" MODIFIED="1571263279748"/>
<node TEXT="Lucydog1" ID="ID_1176577908" CREATED="1571263280349" MODIFIED="1571263283528"/>
</node>
<node TEXT="Costco" FOLDED="true" ID="ID_145110741" CREATED="1520107411264" MODIFIED="1597263028026">
<font BOLD="false"/>
<node TEXT="canceled 11/5/23" ID="ID_1059618993" CREATED="1699200642786" MODIFIED="1699200651604"/>
<node FOLDED="true" ID="ID_1773979944" CREATED="1532457615394" MODIFIED="1532457615394" LINK="https://www.costco.com/LogonForm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.costco.com/LogonForm">Sign In</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_990361706" CREATED="1520107411264" MODIFIED="1532457630528"/>
<node TEXT="Lucydog1*" ID="ID_1164225771" CREATED="1589836763545" MODIFIED="1603476523091"/>
</node>
<node TEXT="Membership number:" FOLDED="true" ID="ID_894776102" CREATED="1532629186759" MODIFIED="1532629199807">
<node TEXT="111762430177" OBJECT="java.lang.Long|111762430177" ID="ID_741371476" CREATED="1532629200400" MODIFIED="1532629220102"/>
</node>
<node TEXT="Main account" FOLDED="true" ID="ID_279651825" CREATED="1520107411264" MODIFIED="1520107411264">
<node TEXT="Dr0w$$@p" ID="ID_666775798" CREATED="1520107411264" MODIFIED="1520107411264"/>
</node>
<node TEXT="Photo Center" FOLDED="true" ID="ID_366647549" CREATED="1520107411264" MODIFIED="1520107411264">
<node TEXT="Dr0w$$ap" ID="ID_674723355" CREATED="1520107411264" MODIFIED="1670474069668"/>
</node>
</node>
<node TEXT="Walgreens" FOLDED="true" ID="ID_1542727241" CREATED="1670479709138" MODIFIED="1670479712956">
<font BOLD="false"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1420714704" CREATED="1715182231831" MODIFIED="1715182234442"/>
<node TEXT="Lucydog1" ID="ID_1907581047" CREATED="1715182235864" MODIFIED="1715182238646"/>
<node TEXT="Christmas cards" FOLDED="true" ID="ID_528030522" CREATED="1670479713586" MODIFIED="1670479717355">
<node TEXT="use coupon code" ID="ID_1246135487" CREATED="1670479718351" MODIFIED="1670479722929"/>
</node>
</node>
<node TEXT="Target" ID="ID_119797003" CREATED="1520107411264" MODIFIED="1597263028028">
<font BOLD="false"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_522259866" CREATED="1520107411264" MODIFIED="1520107411264" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="Lucydog1" ID="ID_1205906629" CREATED="1520107411264" MODIFIED="1721768761225"/>
</node>
<node TEXT="Home Depot" FOLDED="true" ID="ID_679773552" CREATED="1589921219885" MODIFIED="1597263028030">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1861799907" CREATED="1589921225444" MODIFIED="1589921227610"/>
<node TEXT="dr0w$$@p" ID="ID_817044236" CREATED="1589921228301" MODIFIED="1589921233456"/>
</node>
<node TEXT="Ace Hardware" FOLDED="true" ID="ID_647909443" CREATED="1697910627748" MODIFIED="1697910632251">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_851255236" CREATED="1697910663102" MODIFIED="1697910666293"/>
<node TEXT="Lucydog1" ID="ID_534000114" CREATED="1697910667098" MODIFIED="1697910670493"/>
</node>
<node FOLDED="true" ID="ID_1266987872" CREATED="1714526919416" MODIFIED="1714857729874" LINK="https://www.lowes.com/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.lowes.com/">Lowe's Home Improvement</a>
  </body>
</html>
</richcontent>
<node TEXT="mandmmcmillen@gmail.com" FOLDED="true" ID="ID_458920138" CREATED="1589921225444" MODIFIED="1589921227610">
<node TEXT="Lucydog1" ID="ID_1643253791" CREATED="1686672604892" MODIFIED="1686672608975"/>
</node>
<node TEXT="mcmillen.michael.s@gmail.com" FOLDED="true" ID="ID_1606761180" CREATED="1597263105212" MODIFIED="1597263107548">
<node TEXT="Dr0w$$@p" ID="ID_294844119" CREATED="1597263108103" MODIFIED="1675825994943"/>
</node>
<node TEXT="Lumber and Building Materials" FOLDED="true" ID="ID_772917222" CREATED="1715271934740" MODIFIED="1715271950810">
<node TEXT="Associate:" FOLDED="true" ID="ID_1538265522" CREATED="1715272510769" MODIFIED="1715273304223">
<node TEXT="Jeff" ID="ID_1903490634" CREATED="1715273311107" MODIFIED="1715275514499"/>
</node>
</node>
<node ID="ID_1187114734" TREE_ID="ID_94405055">
<node ID="ID_1909109540" TREE_ID="ID_1654668433">
<node ID="ID_1547451149" TREE_ID="ID_1598028984"/>
<node ID="ID_939400685" TREE_ID="ID_1020597913"/>
<node ID="ID_1970339074" TREE_ID="ID_1318858845"/>
</node>
<node ID="ID_1750834873" TREE_ID="ID_510030120">
<node ID="ID_1615856528" TREE_ID="ID_1488351500"/>
</node>
<node ID="ID_110495961" TREE_ID="ID_38098313">
<node ID="ID_87070252" TREE_ID="ID_1411385578"/>
</node>
<node ID="ID_1989368664" TREE_ID="ID_1048948698">
<node ID="ID_860202675" TREE_ID="ID_1378442919"/>
</node>
<node ID="ID_825870374" TREE_ID="ID_1659001391">
<node ID="ID_1570616098" TREE_ID="ID_1061309208"/>
</node>
</node>
<node TEXT="20% coupon" FOLDED="true" ID="ID_921021439" CREATED="1714857487736" MODIFIED="1714857492373">
<node TEXT="471684242710343" ID="ID_56389722" CREATED="1714857548561" MODIFIED="1714857548561"/>
</node>
<node TEXT="Gift Certificate" FOLDED="true" ID="ID_1254603847" CREATED="1714526735189" MODIFIED="1714526741163">
<node TEXT="$9.25" FOLDED="true" ID="ID_11839288" CREATED="1714526894959" MODIFIED="1714526900807">
<node TEXT="6006491722004250052" OBJECT="java.lang.Long|6006491722004250052" FOLDED="true" ID="ID_1508897404" CREATED="1714526741178" MODIFIED="1714526793555">
<node TEXT="2930" OBJECT="java.lang.Long|2930" ID="ID_1303100493" CREATED="1714526793566" MODIFIED="1714526796394"/>
</node>
</node>
</node>
</node>
<node TEXT="Ebay" FOLDED="true" ID="ID_982961233" CREATED="1520107411264" MODIFIED="1597263028033">
<font BOLD="false"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1072615698" CREATED="1520107411264" MODIFIED="1597263028031"/>
<node TEXT="Lucydog1" ID="ID_428717408" CREATED="1520107411264" MODIFIED="1597263028032"/>
<node TEXT="dr0w$$@p" ID="ID_1879454648" CREATED="1520107513961" MODIFIED="1597263028032"/>
<node ID="ID_341778725" CREATED="1595795001972" MODIFIED="1597263028033" LINK="https://www.ebay.com/help/selling/getting-paid/cancelling-transaction?id=4136"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.ebay.com/help/selling/getting-paid/cancelling-transaction?id=4136">Cancel a transaction | eBay</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="newegg" FOLDED="true" ID="ID_75998777" CREATED="1590532253574" MODIFIED="1597263028033">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_938407447" CREATED="1590532280742" MODIFIED="1590532289553"/>
<node TEXT="dr0w$$@p" ID="ID_488748766" CREATED="1590532290827" MODIFIED="1590532906664"/>
</node>
<node TEXT="Gemplers" FOLDED="true" ID="ID_410172289" CREATED="1535142062081" MODIFIED="1597263028034" LINK="https://www.gemplers.com/">
<font BOLD="false"/>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_854612181" CREATED="1535142072729" MODIFIED="1535142079220"/>
<node TEXT="Lucydog1" ID="ID_203593507" CREATED="1535142065825" MODIFIED="1535142072179"/>
</node>
<node TEXT="Craigslist" FOLDED="true" ID="ID_70945999" CREATED="1536620007050" MODIFIED="1597263028034">
<font BOLD="false"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_32550342" CREATED="1536620013813" MODIFIED="1536620017765"/>
<node TEXT="Lucydog1*Lucydog1*" ID="ID_1705800592" CREATED="1536620236400" MODIFIED="1536620246554"/>
</node>
<node TEXT="Priceline" FOLDED="true" ID="ID_998675234" CREATED="1520108223815" MODIFIED="1597263028035">
<font BOLD="false"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_604305601" CREATED="1520108223815" MODIFIED="1627447246513"/>
<node TEXT="Tyid56!df9" ID="ID_1529027612" CREATED="1520108223815" MODIFIED="1520108223815"/>
</node>
<node TEXT="Banggood" FOLDED="true" ID="ID_1897990223" CREATED="1520107411264" MODIFIED="1597263028035">
<font BOLD="false"/>
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1761143837" CREATED="1520107411264" MODIFIED="1520107411264" LINK="mailto:mandmmcmillen@gmail.com"/>
<node TEXT="Luckydog01" ID="ID_725515973" CREATED="1520107411264" MODIFIED="1520107411264"/>
</node>
<node TEXT="Keepa" FOLDED="true" ID="ID_1350081643" CREATED="1540837071545" MODIFIED="1597263028035">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_532780185" CREATED="1540837113451" MODIFIED="1540837116683"/>
</node>
<node TEXT="UPS" FOLDED="true" ID="ID_912089586" CREATED="1544564916567" MODIFIED="1597263028036">
<node TEXT="user id" FOLDED="true" ID="ID_779311074" CREATED="1544565037116" MODIFIED="1544565040519">
<node TEXT="mmcmille" ID="ID_1266535592" CREATED="1544565042158" MODIFIED="1544565049568"/>
</node>
<node TEXT="Google Login" FOLDED="true" ID="ID_1067014941" CREATED="1544564928175" MODIFIED="1544564934899">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1819150983" CREATED="1544564937167" MODIFIED="1544564939187"/>
</node>
</node>
</node>
<node TEXT="Food" FOLDED="true" POSITION="bottom_or_right" ID="ID_1948529932" CREATED="1592242176809" MODIFIED="1597263028036">
<node TEXT="Little Ceasars" FOLDED="true" ID="ID_1364642990" CREATED="1592242180462" MODIFIED="1592242186282">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1739178447" CREATED="1592242187305" MODIFIED="1592242201965"/>
<node TEXT="Lucydog1" ID="ID_224049880" CREATED="1592242202572" MODIFIED="1592242206443"/>
</node>
</node>
<node TEXT="Products, Devices, Registration" POSITION="bottom_or_right" ID="ID_702013685" CREATED="1520107267330" MODIFIED="1597263028037">
<node TEXT="Eufy Clean" FOLDED="true" ID="ID_773408680" CREATED="1703873808576" MODIFIED="1703873813806">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1835460575" CREATED="1703873895857" MODIFIED="1703873906204"/>
<node TEXT="Lucydog1" ID="ID_162622831" CREATED="1703873908314" MODIFIED="1703874378011"/>
</node>
<node TEXT="Whirlpool" FOLDED="true" ID="ID_1049735437" CREATED="1520106458102" MODIFIED="1520107247396" LINK="http://www.whirlpool.com/">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_846593109" CREATED="1520106458102" MODIFIED="1520106458102" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="D reg" ID="ID_1696411066" CREATED="1520106458102" MODIFIED="1520106458102"/>
</node>
<node TEXT="M1Z camera" FOLDED="true" ID="ID_1910591377" CREATED="1520108112533" MODIFIED="1520108112533">
<node TEXT="Default password: 20160404" ID="ID_87458371" CREATED="1520108112533" MODIFIED="1520108112533"/>
<node TEXT="Current: Lucydog1" ID="ID_1008807075" CREATED="1520108112533" MODIFIED="1520108112533"/>
</node>
<node TEXT="U-Cam (Light Cameras)" FOLDED="true" ID="ID_1121661193" CREATED="1520108112533" MODIFIED="1520108146265">
<node TEXT="Setup: use Android phone" ID="ID_601859758" CREATED="1520108112533" MODIFIED="1520108125781">
<font BOLD="true"/>
</node>
<node TEXT="onvif" FOLDED="true" ID="ID_1578940868" CREATED="1554659169545" MODIFIED="1554659172016">
<node TEXT="view online with internet explorer browser" ID="ID_291868022" CREATED="1554659176245" MODIFIED="1554659190027"/>
<node ID="ID_12163414" CREATED="1554659589366" MODIFIED="1554659589366" LINK="https://hit-mob.com/ip-camera-viewer-ios/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://hit-mob.com/ip-camera-viewer-ios/">IP Camera Viewer &#8211; iOS &#171; Hit-Mob.com</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="McMillen.michael.s@gmail.com" ID="ID_1965688080" CREATED="1520108112533" MODIFIED="1520108112533" LINK="mailto:McMillen.michael.s@gmail.com"/>
<node TEXT="Lucydog1" ID="ID_54909857" CREATED="1520108112533" MODIFIED="1520108112533"/>
<node TEXT="Front Door" FOLDED="true" ID="ID_1829651644" CREATED="1574829074005" MODIFIED="1574829080885">
<node TEXT="02:0F:B5:C4:B8:C6" ID="ID_174815937" CREATED="1574829082773" MODIFIED="1574829084242"/>
<node TEXT="QSDK" ID="ID_1002615774" CREATED="1574829086499" MODIFIED="1574829092420"/>
</node>
<node TEXT="Login" FOLDED="true" ID="ID_1433151232" CREATED="1554659111010" MODIFIED="1554659114662">
<node TEXT="admin" ID="ID_1185796048" CREATED="1554659116967" MODIFIED="1554659155549"/>
<node TEXT="20160404" OBJECT="java.lang.Long|20160404" ID="ID_180444748" CREATED="1554659155985" MODIFIED="1554659159704"/>
</node>
</node>
<node TEXT="Aidens Cam" FOLDED="true" ID="ID_765758079" CREATED="1571755474525" MODIFIED="1571755480967">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_83310488" CREATED="1571755481910" MODIFIED="1571755488940"/>
<node TEXT="Lucydog1" ID="ID_18279297" CREATED="1571755489529" MODIFIED="1571755493526"/>
</node>
</node>
<node TEXT="Learning and Development" FOLDED="true" POSITION="bottom_or_right" ID="ID_1792008907" CREATED="1520107288721" MODIFIED="1597263028037">
<node TEXT="Data Sci Prog" FOLDED="true" ID="ID_1102310924" CREATED="1559539207636" MODIFIED="1559539215564">
<node ID="ID_1880875669" TREE_ID="ID_603115965">
<node ID="ID_782695958" TREE_ID="ID_1683887355">
<node ID="ID_428020410" TREE_ID="ID_342169148"/>
<node ID="ID_740312514" TREE_ID="ID_1919846697"/>
</node>
<node ID="ID_1010698192" TREE_ID="ID_1991953963">
<node ID="ID_1336259256" TREE_ID="ID_1237146107"/>
</node>
<node POSITION="bottom_or_right" ID="ID_1662922141" TREE_ID="ID_484612204">
<node ID="ID_227687949" TREE_ID="ID_1677343694"/>
</node>
<node ID="ID_277822895" TREE_ID="ID_444725583">
<node ID="ID_1499286984" TREE_ID="ID_201550633"/>
</node>
</node>
<node TEXT="edX" FOLDED="true" ID="ID_1436474102" CREATED="1525454794735" MODIFIED="1562079094047" LINK="https://courses.edx.org/dashboard#">
<font SIZE="12"/>
<node TEXT="Google+ account: mcmillen.michael.s@gmail.com" ID="ID_382529633" CREATED="1525454800414" MODIFIED="1525454816603"/>
<node TEXT="Certification" FOLDED="true" ID="ID_1447251529" CREATED="1561702055588" MODIFIED="1561702059344">
<node ID="ID_1984343714" CREATED="1561700372801" MODIFIED="1561700372801" LINK="https://medium.com/@benjaminobi/should-i-pursue-a-verified-certificate-for-a-massive-open-online-course-mooc-11d79da8853f"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://medium.com/@benjaminobi/should-i-pursue-a-verified-certificate-for-a-massive-open-online-course-mooc-11d79da8853f">Should I Pursue a Verified Certificate for a Massive Open Online Course (MOOC)?</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1922250226" CREATED="1561702021101" MODIFIED="1561702021101" LINK="https://www.edx.org/professional-certificate/harvardx-data-science"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edx.org/professional-certificate/harvardx-data-science">Data Science | edX</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1420508005" CREATED="1561702052568" MODIFIED="1561702052568" LINK="https://www.edx.org/microsoft-professional-program-data-science"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.edx.org/microsoft-professional-program-data-science">Microsoft Professional Program in Data Science | edX</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node ID="ID_864567686" CREATED="1539898725684" MODIFIED="1539898725684" LINK="https://repl.it/repls"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://repl.it/repls">Repl.it - Repls</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="TM website" FOLDED="true" ID="ID_884504468" CREATED="1520106458102" MODIFIED="1520106458102">
<node TEXT="1939" ID="ID_1285363311" CREATED="1520106458102" MODIFIED="1520106458102"/>
<node TEXT="dr0w554p" ID="ID_497486248" CREATED="1520106458102" MODIFIED="1520106458102"/>
</node>
<node TEXT="Education" FOLDED="true" ID="ID_557130315" CREATED="1520107974337" MODIFIED="1520107974337">
<node FOLDED="true" ID="ID_1500667926" CREATED="1709672446950" MODIFIED="1709672446950" LINK="https://eu.degreed.com/account/login"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://eu.degreed.com/account/login">Log In | Degreed</a>
  </body>
</html>
</richcontent>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1265016463" CREATED="1709672449860" MODIFIED="1709672454297"/>
<node TEXT="Lucydog1" ID="ID_903724434" CREATED="1709672455280" MODIFIED="1709672458104"/>
</node>
<node FOLDED="true" ID="ID_268791022" CREATED="1544630533122" MODIFIED="1544630533122" LINK="https://mycoast.cccd.edu/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://mycoast.cccd.edu/">https://mycoast.cccd.edu/</a>
  </body>
</html>
</richcontent>
<node TEXT="mmcmillen3" ID="ID_1789282819" CREATED="1544630785256" MODIFIED="1544810264721"/>
<node TEXT="Lucydogs123*" ID="ID_1507138414" CREATED="1544721495598" MODIFIED="1544721522169"/>
<node TEXT="Old Pwd" FOLDED="true" ID="ID_1330146530" CREATED="1544721525327" MODIFIED="1544721538724">
<node TEXT="Mm073083CCCD" ID="ID_1739020415" CREATED="1544630819935" MODIFIED="1544630819935"/>
</node>
<node TEXT="Student ID: C02778907" ID="ID_1471583611" CREATED="1544810581430" MODIFIED="1544810585352"/>
<node TEXT="Matriculation" FOLDED="true" ID="ID_525691101" CREATED="1544810363717" MODIFIED="1544810367792">
<node ID="ID_997749801" CREATED="1544810662993" MODIFIED="1544810662993" LINK="mailto:matriculation@coastline.edu"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="mailto:matriculation@coastline.edu" target="_blank" style="color: rgb(17, 85, 204); font-family: Arial, Helvetica, sans-serif; font-size: small; font-style: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; background-color: rgb(255, 255, 255)"><font color="rgb(17, 85, 204)" face="Arial, Helvetica, sans-serif" size="small">matriculation@coastline.edu</font></a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Telephone: (714) 241-6115" ID="ID_1024450822" CREATED="1544810678818" MODIFIED="1544810678818"/>
</node>
</node>
<node FOLDED="true" ID="ID_1014580131" CREATED="1677960781953" MODIFIED="1677960807680" LINK="https://www.parchment.com/u/order/track"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.parchment.com/u/order/track">Parchment Exchange - Leader in eTranscript Exchange</a>
  </body>
</html>
</richcontent>
<node TEXT="CSUMB" FOLDED="true" ID="ID_1784136637" CREATED="1698446009958" MODIFIED="1698446012607">
<node TEXT="mmcmillen@csumb.edu" ID="ID_997371316" CREATED="1698446013567" MODIFIED="1698446049761"/>
<node TEXT="Lucydog123*" ID="ID_336359890" CREATED="1698446015207" MODIFIED="1698446024569"/>
</node>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_642363043" CREATED="1544722536858" MODIFIED="1544722540255"/>
<node TEXT="Lucydog1" ID="ID_379827072" CREATED="1544722540795" MODIFIED="1544728135629"/>
<node TEXT="order transcripts" ID="ID_257093954" CREATED="1677960809803" MODIFIED="1677960816287"/>
</node>
<node TEXT="ISU" FOLDED="true" ID="ID_761708911" CREATED="1520107974337" MODIFIED="1544812663915">
<node TEXT="ID:" FOLDED="true" ID="ID_206881180" CREATED="1544812666135" MODIFIED="1544812667931">
<node TEXT="649088473" ID="ID_1797860767" CREATED="1520107974337" MODIFIED="1520107974337"/>
<node TEXT="64908847313" ID="ID_1784186968" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node TEXT="https://accessplus.iastate.edu/frontdoor/login.jsp" FOLDED="true" ID="ID_230458414" CREATED="1520107974337" MODIFIED="1520108028342" LINK="https://accessplus.iastate.edu/frontdoor/login.jsp">
<node TEXT="649088473" ID="ID_484883779" CREATED="1520107974337" MODIFIED="1520107974337"/>
<node TEXT="reg" ID="ID_1949194550" CREATED="1521128658592" MODIFIED="1521128660915"/>
</node>
<node TEXT="Email" FOLDED="true" ID="ID_879568378" CREATED="1544813075047" MODIFIED="1544813081379">
<node TEXT="mcmillen@iastate.edu" ID="ID_1195485658" CREATED="1520107974337" MODIFIED="1534955156578"/>
<node TEXT="" ID="ID_1874638931" CREATED="1544813086031" MODIFIED="1544813086031"/>
</node>
<node TEXT="Lib Pwd:" FOLDED="true" ID="ID_1323911090" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="Dr0w554p" ID="ID_539208230" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node TEXT="CyHire:" FOLDED="true" ID="ID_1367970161" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="eriHyC" ID="ID_1587636898" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node TEXT="Cybox" FOLDED="true" ID="ID_1189096937" CREATED="1575560684252" MODIFIED="1575560688039">
<node TEXT="Lucydog12" ID="ID_843016534" CREATED="1575560689018" MODIFIED="1575560692972"/>
<node TEXT="michael.mcmillen@syngenta.com" ID="ID_851317148" CREATED="1575560703651" MODIFIED="1575560713061"/>
</node>
</node>
<node TEXT="Arkansas" FOLDED="true" ID="ID_1561883403" CREATED="1680287460804" MODIFIED="1680287468839">
<node TEXT="Monica" FOLDED="true" ID="ID_1084548183" CREATED="1680287469691" MODIFIED="1680287472967">
<node TEXT="monica.mcmillen@smail.astate.edu" ID="ID_1202645954" CREATED="1680368854596" MODIFIED="1680368854596" LINK="mailto:monica.mcmillen@smail.astate.edu"/>
<node TEXT="Dr0w554p" ID="ID_1404752133" CREATED="1680367012818" MODIFIED="1680367076510"/>
<node TEXT="Codes go to" FOLDED="true" ID="ID_1980841063" CREATED="1680368921961" MODIFIED="1680368925710">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_999698111" CREATED="1680368926843" MODIFIED="1680368934685"/>
</node>
<node TEXT="Campus ID" FOLDED="true" ID="ID_1048816538" CREATED="1680368421102" MODIFIED="1680368423969">
<node TEXT="50637961" ID="ID_943048389" CREATED="1680368433766" MODIFIED="1680368433766"/>
</node>
<node TEXT="PIN" FOLDED="true" ID="ID_938749417" CREATED="1680368702050" MODIFIED="1680368704237">
<node TEXT="326213" ID="ID_1315482369" CREATED="1680368707359" MODIFIED="1680368707359"/>
</node>
<node ID="ID_1455185540" CREATED="1680368781296" MODIFIED="1680368781296" LINK="https://ssb-prod.ec.astate.edu/PROD/twbkwbis.P_GenMenu?name=bmenu.P_AdminMnu"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://ssb-prod.ec.astate.edu/PROD/twbkwbis.P_GenMenu?name=bmenu.P_AdminMnu">Student Records</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_261785585" CREATED="1680287561143" MODIFIED="1680287561143" LINK="https://sso2.astate.edu/authenticationendpoint/login.do?RelayState=https%3A%2F%2Fmy.astate.edu&amp;commonAuthCallerPath=%2Fsamlsso&amp;forceAuth=false&amp;passiveAuth=false&amp;tenantDomain=carbon.super&amp;sessionDataKey=63c01c25-861c-4589-8c67-ad13a2342b61&amp;relyingParty=https%3A%2F%2Fmy.astate.edu%2Fsaml%2Fmetadata&amp;type=samlsso&amp;sp=my.AState-Vapor-Prod+-+New&amp;isSaaSApp=false&amp;authenticators=BasicAuthenticator%3ALOCAL&amp;authFailure=true&amp;authFailureMsg=login.fail.message"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sso2.astate.edu/authenticationendpoint/login.do?RelayState=https%3A%2F%2Fmy.astate.edu&amp;commonAuthCallerPath=%2Fsamlsso&amp;forceAuth=false&amp;passiveAuth=false&amp;tenantDomain=carbon.super&amp;sessionDataKey=63c01c25-861c-4589-8c67-ad13a2342b61&amp;relyingParty=https%3A%2F%2Fmy.astate.edu%2Fsaml%2Fmetadata&amp;type=samlsso&amp;sp=my.AState-Vapor-Prod+-+New&amp;isSaaSApp=false&amp;authenticators=BasicAuthenticator%3ALOCAL&amp;authFailure=true&amp;authFailureMsg=login.fail.message">WSO2 Identity Server</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="CFA Institute" FOLDED="true" ID="ID_1680678242" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_608408050" CREATED="1520107974337" MODIFIED="1520107974337" LINK="mailto:mcmillen.michael.s@gmail.com"/>
<node TEXT="CFAInstitute1Â " ID="ID_1421896586" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node TEXT="FAO" FOLDED="true" ID="ID_1030771212" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="mmcmille" ID="ID_1960751947" CREATED="1520107974337" MODIFIED="1520107974337"/>
<node TEXT="dr0w$$@p" ID="ID_528613857" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node TEXT="NCBI" FOLDED="true" ID="ID_1319264471" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="mmcmille" ID="ID_1888663476" CREATED="1520107974337" MODIFIED="1520107974337"/>
<node TEXT="dr0w$$@p" ID="ID_1139581486" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
</node>
<node TEXT="Research" FOLDED="true" ID="ID_1903922945" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="ResearchGate" FOLDED="true" ID="ID_1368388188" CREATED="1520107974337" MODIFIED="1520108047182" LINK="https://www.researchgate.net/home">
<node TEXT="mcmillen@iastate.edu" ID="ID_1525632712" CREATED="1520107974337" MODIFIED="1534955156578"/>
<node TEXT="dr0w$$@p" ID="ID_1320102290" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
<node TEXT="APSIM" FOLDED="true" ID="ID_548642557" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1178685126" CREATED="1520107974337" MODIFIED="1520107974337" LINK="mailto:mcmillen.michael.s@gmail.com"/>
</node>
<node TEXT="JSTOR" FOLDED="true" ID="ID_208870008" CREATED="1520107974337" MODIFIED="1520107974337">
<node TEXT="mmcmille" ID="ID_1463055185" CREATED="1520107974337" MODIFIED="1520107974337"/>
<node TEXT="dr0w$$@p" ID="ID_254913158" CREATED="1520107974337" MODIFIED="1520107974337"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1982851318" CREATED="1520107974337" MODIFIED="1520107974337" LINK="mailto:mcmillen.michael.s@gmail.com"/>
</node>
<node TEXT="CIMIS" FOLDED="true" ID="ID_1592752232" CREATED="1520107974337" MODIFIED="1520108066639" LINK="http://www.cimis.water.ca.gov/Auth/Login.aspx">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1411852409" CREATED="1520107974337" MODIFIED="1538751772290"/>
<node TEXT="Dr0w$$@p" ID="ID_1958745432" CREATED="1520107974337" MODIFIED="1520107974337"/>
</node>
</node>
<node TEXT="Music" FOLDED="true" ID="ID_462673828" CREATED="1610319604083" MODIFIED="1610319607195">
<node TEXT="Guitar" FOLDED="true" ID="ID_1881889558" CREATED="1610319608402" MODIFIED="1610319610639">
<node TEXT="Uberchord" FOLDED="true" ID="ID_1433914792" CREATED="1610319672662" MODIFIED="1610319677665">
<node ID="ID_34044591" CREATED="1610319679418" MODIFIED="1610319679418" LINK="mailto:mcmillen.michael.s@gmail.com"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: 0in; font-family: Calibri; font-size: 11.0pt">
      mcmillen.michael.s@gmail.com
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Health" FOLDED="true" POSITION="bottom_or_right" ID="ID_397722909" CREATED="1576017974349" MODIFIED="1597263028059">
<node TEXT="Supercuts" FOLDED="true" ID="ID_148620133" CREATED="1679329271256" MODIFIED="1679329274341">
<node TEXT="mandmmcmillen@gmail.com" ID="ID_1207749187" CREATED="1679329331216" MODIFIED="1679329341911"/>
<node TEXT="Lucydog1" ID="ID_436065454" CREATED="1679329343240" MODIFIED="1679329346600"/>
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1397259327" CREATED="1684442198329" MODIFIED="1684442198329" LINK="mailto:mcmillen.michael.s@gmail.com"/>
</node>
<node TEXT="Supplement Direct" FOLDED="true" ID="ID_481383318" CREATED="1586636269541" MODIFIED="1586637029653" LINK="http://www.supplementdirect.com/">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_1678137234" CREATED="1586636288512" MODIFIED="1586636290855"/>
<node TEXT="Tx)MP)_&apos;=\p6?[Ck" ID="ID_1147798669" CREATED="1586636945049" MODIFIED="1586636945049"/>
</node>
<node TEXT="myFitnessPal" FOLDED="true" ID="ID_151594319" CREATED="1576017977603" MODIFIED="1576017984264">
<node TEXT="mcmillen.michael.s@gmail.com" ID="ID_542252606" CREATED="1576017985251" MODIFIED="1576017988069"/>
<node TEXT="Lucydog1" ID="ID_93777139" CREATED="1576017988645" MODIFIED="1576017992391"/>
</node>
</node>
<node TEXT="Teaching" FOLDED="true" POSITION="bottom_or_right" ID="ID_272392423" CREATED="1698690763516" MODIFIED="1698690765697">
<node TEXT="TeacherKit" FOLDED="true" ID="ID_102575125" CREATED="1698690766476" MODIFIED="1698690776622">
<node TEXT="mmcmillen@sbhsd.k12.ca.us" ID="ID_433262644" CREATED="1698690777859" MODIFIED="1698690782114"/>
<node TEXT="mmcmillen" ID="ID_1184593934" CREATED="1698690782578" MODIFIED="1698691185846"/>
</node>
</node>
</node>
</map>
