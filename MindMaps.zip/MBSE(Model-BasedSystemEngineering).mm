<map version="freeplane 1.11.5">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node TEXT="MBSE (Model -Based System Engineering )" FOLDED="false" ID="ID_1728748769" CREATED="1712274280292" MODIFIED="1712616350033" LINK="LifeMgmt.mm">
<edge DASH="SOLID"/>
<hook NAME="MapStyle" background="#171717" zoom="1.3">
    <properties show_icon_for_attributes="true" show_note_icons="true" allow_compact_layout="false" fit_to_viewport="false;" horizontal_layout="true"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="oval" UNIFORM_SHAPE="true" TEXT_ALIGN="LEFT" VGAP_QUANTITY="24 pt" TEXT_SHORTENED="true" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="24"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="default" ID="ID_800897947" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" NUMBERED="false" FORMAT="STANDARD_FORMAT" TEXT_ALIGN="LEFT" MAX_WIDTH="120 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="0 px" BORDER_COLOR_LIKE_EDGE="true" BORDER_COLOR="#808080" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="SOLID" CHILD_NODES_LAYOUT="AUTO" VGAP_QUANTITY="2 pt" COMMON_HGAP_QUANTITY="14 pt">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_800897947" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="Arial" SIZE="9" BOLD="true" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#333333" WIDTH="3"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/html"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/html"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="11"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<edge STYLE="hide_edge" COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" BACKGROUND_COLOR="#1e3360" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#203868"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<icon BUILTIN="yes"/>
<edge COLOR="#333333"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" COLOR="#8c7a73" BACKGROUND_COLOR="#191919" STYLE="bubble" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" BORDER_WIDTH="0 px" MIN_WIDTH="0 pt">
<font SIZE="9"/>
<edge COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="22" BOLD="false" ITALIC="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="20" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="18" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="16" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font NAME="Arial" SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,12" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,13" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,14" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,15" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,16" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,17" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,18" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,19" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,20" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,21" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,22" COLOR="#8c7a73" BACKGROUND_COLOR="#000000" BACKGROUND_ALPHA="0" STYLE="fork" SHAPE_VERTICAL_MARGIN="0 pt" TEXT_ALIGN="LEFT" MAX_WIDTH="400 pt" MIN_WIDTH="0 pt" VGAP_QUANTITY="0 pt" BORDER_WIDTH_LIKE_EDGE="true" BORDER_WIDTH="1 pt" BORDER_COLOR_LIKE_EDGE="true" BORDER_DASH_LIKE_EDGE="true" CHILD_NODES_LAYOUT="TOPTOBOTTOM_RIGHT_BOTTOM">
<font SIZE="12" BOLD="false"/>
<edge STYLE="horizontal" COLOR="#6a6a6a" WIDTH="1"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<node TEXT="definition" FOLDED="true" ID="ID_943930676" CREATED="1712616380879" MODIFIED="1712616385066">
<node TEXT="Model -based version of Systems Engineering" ID="ID_1471016458" CREATED="1712616387244" MODIFIED="1712616401778"/>
</node>
<node TEXT="learning" FOLDED="true" ID="ID_1235169096" CREATED="1712272112810" MODIFIED="1712272115844">
<node ID="ID_433970550" CREATED="1712241791851" MODIFIED="1712241791851" LINK="https://www.coursera.org/learn/modeling-feedback-systems"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/modeling-feedback-systems">Modeling of Feedback Systems | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1329320606" CREATED="1712419541338" MODIFIED="1712419541338" LINK="https://www.omgsysml.org/A_modeling_pattern_for_layered_system_interfaces-INCOSE%20IS15_paper-sarrel-shames.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.omgsysml.org/A_modeling_pattern_for_layered_system_interfaces-INCOSE%20IS15_paper-sarrel-shames.pdf">A_modeling_pattern_for_layered_system_interfaces-INCOSE IS15_paper-sarrel-shames.pdf</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1764328171" CREATED="1712245596357" MODIFIED="1712245596357" LINK="https://www.mdpi.com/2079-8954/11/8/429"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mdpi.com/2079-8954/11/8/429">Systems | Free Full-Text | Using the ARCADIA/Capella Systems Engineering Method and Tool to Design Manufacturing Systems—Case Study and Industrial Feedback</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_539888056" CREATED="1712275029095" MODIFIED="1712275029095" LINK="https://www.coursera.org/learn/introduction-mbse/home/week/1"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/home/week/1">Introduction to Model-Based Systems Engineering - An Introduction to Model-Based Systems Engineering - Week 1 | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="reference" FOLDED="true" ID="ID_146493847" CREATED="1624859661753" MODIFIED="1712242533335">
<node ID="ID_1046120086" CREATED="1712878225753" MODIFIED="1712878231052" LINK="https://sebokwiki.org/wiki/INCOSE_Systems_Engineering_Handbook"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sebokwiki.org/wiki/INCOSE_Systems_Engineering_Handbook">INCOSE Systems Engineering Handbook - SEBoK</a>
  </body>
</html>

</richcontent>
<font BOLD="true"/>
</node>
<node ID="ID_1160278403" CREATED="1712769166161" MODIFIED="1712784538244" LINK="https://sebokwiki.org/wiki/Model-Based_Systems_Engineering_(MBSE)"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://sebokwiki.org/wiki/Model-Based_Systems_Engineering_(MBSE)">Model-Based Systems Engineering (MBSE) - SEBoK</a>
  </body>
</html>
</richcontent>
<font BOLD="true"/>
</node>
<node TEXT="other" FOLDED="true" ID="ID_1305243519" CREATED="1712878244134" MODIFIED="1712878246266">
<node ID="ID_669266558" CREATED="1628659416425" MODIFIED="1628659416425" LINK="https://courses.corporatefinanceinstitute.com/collections?category=financial-modeling"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://courses.corporatefinanceinstitute.com/collections?category=financial-modeling">Financial Modeling Courses - Learn Online | CFI</a>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_835133746" CREATED="1632150841625" MODIFIED="1632150841625" LINK="https://www.amazon.com/Fifth-Discipline-Practice-Learning-Organization/dp/0385517254#customerReviews"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/Fifth-Discipline-Practice-Learning-Organization/dp/0385517254#customerReviews">The Fifth Discipline: The Art &amp; Practice of The Learning Organization: Senge, Peter M.: 8601420120846: Amazon.com: Books</a>
  </body>
</html>
</richcontent>
<node ID="ID_1682520413" CREATED="1632151697122" MODIFIED="1632151697122" LINK="https://www.peterkang.com/the-seven-learning-disabilities-from-the-fifth-discipline/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.peterkang.com/the-seven-learning-disabilities-from-the-fifth-discipline/">The Seven Learning Disabilities from The Fifth Discipline - Peter Kang</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_1453007055" CREATED="1632171191952" MODIFIED="1632171191952" LINK="https://www.mindtools.com/pages/article/newPPM_82.htm"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.mindtools.com/pages/article/newPPM_82.htm">Kotter's 8-Step Change Model - Change Management Tools from Mind Tools</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_376612157" CREATED="1632174066545" MODIFIED="1632174066545" LINK="https://www.amazon.com/TracFone-Rebel-Prepaid-Smartphone-Locked/dp/B08J5DCBQR/ref=sr_1_2?crid=2HZT9HAIHE0HV&amp;dchild=1&amp;keywords=unlock+smart+phones+on+sale+clearance+under+60&amp;qid=1632173734&amp;refinements=p_n_feature_thirteen_browse-bin%3A14674917011%2Cp_36%3A-7000%2Cp_n_feature_twelve_browse-bin%3A14674909011&amp;rnid=14674904011&amp;s=wireless&amp;sprefix=unlock+smart+phone%2Caps%2C271&amp;sr=1-2"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.amazon.com/TracFone-Rebel-Prepaid-Smartphone-Locked/dp/B08J5DCBQR/ref=sr_1_2?crid=2HZT9HAIHE0HV&amp;dchild=1&amp;keywords=unlock+smart+phones+on+sale+clearance+under+60&amp;qid=1632173734&amp;refinements=p_n_feature_thirteen_browse-bin%3A14674917011%2Cp_36%3A-7000%2Cp_n_feature_twelve_browse-bin%3A14674909011&amp;rnid=14674904011&amp;s=wireless&amp;sprefix=unlock+smart+phone%2Caps%2C271&amp;sr=1-2">Amazon.com: TracFone LG K31 Rebel 4G LTE Prepaid Smartphone (Locked) - Black - 32GB - Sim Card Included - CDMA : Cell Phones &amp; Accessories</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_383895167" CREATED="1657078938107" MODIFIED="1657078938107" LINK="https://www.wolfram.com/system-modeler/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.wolfram.com/system-modeler/">Wolfram System Modeler: Modeling, Simulation &amp; Analysis</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="terminology" FOLDED="true" ID="ID_1398219289" CREATED="1713046532804" MODIFIED="1713046537052">
<node TEXT="reference" ID="ID_1623128445" CREATED="1713046874605" MODIFIED="1713046876238">
<node ID="ID_1437286170" CREATED="1713046877284" MODIFIED="1713046877284" LINK="https://www.engineering.com/story/its-time-to-clean-up-our-model-based-problem"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.engineering.com/story/its-time-to-clean-up-our-model-based-problem">It's Time to Clean Up Our Model-Based Problem | Engineering.com</a>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="PLM: Product Lifecycle Management" ID="ID_538989402" CREATED="1713072666851" MODIFIED="1713072676202"/>
<node TEXT="IPDP: Integrated Product Development Process" ID="ID_698567379" CREATED="1713072693990" MODIFIED="1713072715184"/>
<node TEXT="Model-Based Definition (MBD) refers to 3D CAD models that provide specifications for a component or assembly without additional 2D engineering drawings.  These specifications include geometric dimensioning and tolerancing (GD&amp;T), bills of materials (BOMs), technical data packages (TDPs), engineering configurations, design intent, etc.  Collectively known as product manufacturing information (PMI), these data sets, their metadata, and their linked repositories contain the information to manufacture and inspect the product. Model-Based Definitions are also known as “digital product definitions.”" ID="ID_1677369061" CREATED="1713047064874" MODIFIED="1713047143831"/>
<node TEXT="Model-Based Design ( also MBD) is a mathematical and visual method of addressing problems in designing complex control, signal processing, embedded software, and communication systems.  In Model-Based Design, models are developed in simulation tools for rapid prototyping, software testing, verification, predictive analysis, and archiving. Model-Based Design is also a communication framework to represent shape, behavioral, and contextual information throughout the design process and development cycle." ID="ID_100047914" CREATED="1713047143836" MODIFIED="1713047143841"/>
<node TEXT="Model-Based Engineering (MBE) is the use of models as the authoritative definition of a product or system&apos;s baseline technical details.  Intended to be shared by everyone involved in a project, these models are integrated across full lifecycles and span all technical disciplines." ID="ID_1250881768" CREATED="1713047111278" MODIFIED="1713047111281"/>
<node TEXT="Model-Based Systems Engineering (MBSE) is a methodology to support system requirements, analysis, verification, and validation activities from conceptual design, throughout development and on into later lifecycle phases.  Like other components of MB x, engineers use these simulations to exchange information." ID="ID_1384149801" CREATED="1713047091229" MODIFIED="1713047162644"/>
<node TEXT="Model-Based Enterprise ( also MBE) refers to an organizational environment that leverages the model as a dynamic artifact in product development and decision-making.  The Model-Based Enterprise focuses on the management of lifecycle feedback to create follow-on products and their iterations and variants.  There is also a Model-Based Extended Enterprise, or MBEE." ID="ID_692118406" CREATED="1713047162646" MODIFIED="1713047196231"/>
<node TEXT="The overlaps and vagueness are obvious, which is why we use the collective abbreviation MBx" ID="ID_764671024" CREATED="1713047196232" MODIFIED="1713047201621"/>
</node>
<node POSITION="bottom_or_right" ID="ID_1064100236" CREATED="1657079038299" MODIFIED="1657079038299" LINK="https://learn.concord.org/building-models"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://learn.concord.org/building-models">Building Models | STEM Resource Finder</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="System" FOLDED="true" ID="ID_351838911" CREATED="1712291736974" MODIFIED="1712291744495">
<node TEXT="reference" FOLDED="true" ID="ID_460696258" CREATED="1712292221932" MODIFIED="1712292224139">
<node ID="ID_560913648" CREATED="1712292224966" MODIFIED="1712292224966" LINK="https://www.coursera.org/learn/introduction-mbse/supplement/sYKLO/an-introduction-to-systems-definition-and-an-example"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/supplement/sYKLO/an-introduction-to-systems-definition-and-an-example">An Introduction to Systems Definition and an Example | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="definitions" FOLDED="true" ID="ID_328064961" CREATED="1712291853118" MODIFIED="1712291857135">
<node TEXT="ISO/IEC/IEEE 15288 (Standard)" FOLDED="true" ID="ID_1340235142" CREATED="1712291886768" MODIFIED="1712291937922">
<node TEXT="combination of interacting elements organized to achieve one or more stated purposes." ID="ID_1902327127" CREATED="1712291921739" MODIFIED="1712291921739"/>
</node>
<node TEXT="this course" FOLDED="true" ID="ID_1364748636" CREATED="1712291904825" MODIFIED="1712291908935">
<node TEXT="construct of different elements when put together, produce results not obtainable by the elements alone. The value added by the system as a whole, beyond that contributed independently by the parts, is primarily created by the relationship among the interconnected parts." FOLDED="true" ID="ID_1551381890" CREATED="1712291900344" MODIFIED="1712291900344">
<node TEXT="Elements" FOLDED="true" ID="ID_109749968" CREATED="1712291972947" MODIFIED="1712292011331">
<font BOLD="true"/>
<node TEXT="include all things required to produce system-level results, such as: People, hardware, software, facilities, policies, and documents." ID="ID_1083503413" CREATED="1712291989349" MODIFIED="1712291989350"/>
</node>
<node TEXT="Results" FOLDED="true" ID="ID_1945346063" CREATED="1712291972947" MODIFIED="1712292007330">
<font BOLD="true"/>
<node TEXT="include system-level functions, behavior, and performance such as display measurements (function), transmitting data (function), transport items (function), and completing its cycle in less than 30 seconds (performance)." ID="ID_930364372" CREATED="1712292000950" MODIFIED="1712292000950"/>
</node>
<node TEXT="Value" FOLDED="true" ID="ID_1335931174" CREATED="1712292275424" MODIFIED="1712292281341">
<font BOLD="true"/>
<node TEXT="stems from the entire system as a whole which is created by the relationship among the interconnected parts." ID="ID_639840323" CREATED="1712292301943" MODIFIED="1712292301943"/>
</node>
</node>
</node>
</node>
<node TEXT="system context / operating environment" FOLDED="true" ID="ID_1802258904" CREATED="1712292355187" MODIFIED="1712292554050">
<node TEXT="operational environment is the context in which the device operates." ID="ID_1908266728" CREATED="1712292412152" MODIFIED="1712292412152"/>
<node TEXT="system boundary" FOLDED="true" ID="ID_190905385" CREATED="1712292362516" MODIFIED="1712292380917">
<node TEXT="operational boundary defines what belongs to the system and what does not. This includes the system functionality and the materials, energy, force, and information that the system exchanges with its environment." ID="ID_785812011" CREATED="1712292399550" MODIFIED="1712292399550"/>
</node>
<node TEXT="example" FOLDED="true" ID="ID_26211050" CREATED="1712292458933" MODIFIED="1712292461751">
<node TEXT="png_7221913626715232692.png" ID="ID_992229314" CREATED="1712292466406" MODIFIED="1712292466406">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_7221913626715232692.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Ultimately, to understand a system, you need to understand:" FOLDED="true" ID="ID_883584847" CREATED="1712292412152" MODIFIED="1712292412152">
<node TEXT="The ways in which it will be used" ID="ID_691509082" CREATED="1712292412154" MODIFIED="1712292412154"/>
<node TEXT="The environment in which it will operate" ID="ID_751838052" CREATED="1712292412154" MODIFIED="1712292412154"/>
<node TEXT="The knowledge, technologies, and methods used to make it." ID="ID_931128968" CREATED="1712292412155" MODIFIED="1712292412155"/>
</node>
</node>
<node TEXT="System Model" FOLDED="true" ID="ID_1728644624" CREATED="1619890410789" MODIFIED="1637730787510">
<node TEXT="definition" FOLDED="true" ID="ID_1460234392" CREATED="1624860792540" MODIFIED="1712273647852">
<node TEXT="reference" FOLDED="true" ID="ID_406982531" CREATED="1712273924466" MODIFIED="1712273926855">
<node ID="ID_989294281" CREATED="1712273921874" MODIFIED="1712273921874" LINK="https://www.coursera.org/learn/introduction-mbse/lecture/uUrCW/an-introduction-to-system-models"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/lecture/uUrCW/an-introduction-to-system-models">An Introduction to System Models | Coursera</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_369402541" CREATED="1712273577640" MODIFIED="1712273577640" LINK="https://link.springer.com/article/10.1007/s42452-019-1069-0"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://link.springer.com/article/10.1007/s42452-019-1069-0">Definition of a system model for model-based development | Discover Applied Sciences</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Definition 1, an abstract representation of a given set of aspects of a subject used to address given concerns following structured semantics." ID="ID_1736005320" CREATED="1712273821437" MODIFIED="1712273821437"/>
<node TEXT="Definition 2, a simplified version of a concept, phenomenon, relationship, structure, or system." ID="ID_591496675" CREATED="1712273821437" MODIFIED="1712273828457"/>
<node TEXT="Definition 3, a graphical, mathematical, or physical representation." ID="ID_1272861419" CREATED="1712273828459" MODIFIED="1712273828461"/>
<node TEXT="Definition 4, an abstraction of reality by eliminating unnecessary components." ID="ID_471943457" CREATED="1712273821440" MODIFIED="1712273821440"/>
</node>
<node TEXT="objective" FOLDED="true" ID="ID_523336648" CREATED="1712273874425" MODIFIED="1712273877821">
<node TEXT="facility understanding" ID="ID_140327538" CREATED="1712273877823" MODIFIED="1712273881409"/>
<node TEXT="aid in decision-making" FOLDED="true" ID="ID_1432602938" CREATED="1712273881421" MODIFIED="1712273884816">
<node TEXT="examine what if scenarios" ID="ID_1149547555" CREATED="1712273884830" MODIFIED="1712273889226"/>
</node>
<node TEXT="explain, control, and predict events" ID="ID_992862698" CREATED="1712273892454" MODIFIED="1712273903258"/>
</node>
<node TEXT="high versus low level models" FOLDED="true" ID="ID_574757464" CREATED="1712273960036" MODIFIED="1712273969795">
<node TEXT="high-level model: relatively simple or simplified model that supports basic analysis, decision-making, and communication" FOLDED="true" ID="ID_1180562102" CREATED="1712274140071" MODIFIED="1712274183611">
<node TEXT="Examples include mathematical models in the form of formulas, visual diagrams, and graphs" ID="ID_1393384097" CREATED="1712274140071" MODIFIED="1712274140071"/>
<node TEXT="High-level models present the system from different perspectives, including physical versus abstract and domain-specific versus domain-independent" ID="ID_903350948" CREATED="1712274140076" MODIFIED="1712274140076"/>
<node TEXT="High-level models present the system in different manners, including descriptive versus procedural, and formal versus informal" ID="ID_1925040052" CREATED="1712274140077" MODIFIED="1712274140077"/>
</node>
<node TEXT="low-level model: more complex and would support a more advanced analysis based on a more detailed representation" FOLDED="true" ID="ID_775132957" CREATED="1712274140073" MODIFIED="1712274171720">
<node TEXT="For example, a 3D CAD model of a system component would be considered a low-level model, which can precisely represent properties such as geometry" ID="ID_1308498366" CREATED="1712274140075" MODIFIED="1712274140075"/>
<node TEXT="Low-level models represent the system in a more detailed way" ID="ID_1994002213" CREATED="1712274140078" MODIFIED="1712274140078"/>
<node TEXT="They consist of the following five types" FOLDED="true" ID="ID_1470181532" CREATED="1712274140080" MODIFIED="1712274140080">
<node TEXT="First, domain-specific models" ID="ID_545006804" CREATED="1712274140080" MODIFIED="1712274140080"/>
<node TEXT="Second, computer-interpretable computational models" ID="ID_782321395" CREATED="1712274140080" MODIFIED="1712274140080"/>
<node TEXT="Third, human interpretable descriptive models" ID="ID_1296591460" CREATED="1712274140081" MODIFIED="1712274140081"/>
<node TEXT="Next, model supporting metadata" ID="ID_997955522" CREATED="1712274140081" MODIFIED="1712274140081"/>
<node TEXT="Finally, physical models" ID="ID_1447939005" CREATED="1712274140082" MODIFIED="1712274140082"/>
</node>
</node>
</node>
</node>
<node TEXT="System Architecture Model" FOLDED="true" ID="ID_754221836" CREATED="1712274140082" MODIFIED="1712275133069">
<node TEXT="A model that is at the core of MBSE" ID="ID_526956716" CREATED="1712275136050" MODIFIED="1712275143848"/>
<node TEXT="structured representation that focuses on:" ID="ID_204633152" CREATED="1712274140083" MODIFIED="1712274472555">
<node TEXT="Requirements: stakeholder needs, purposes, etc, the specification of black-box behavior and characteristics" ID="ID_1581486582" CREATED="1712274399264" MODIFIED="1712274543048"/>
<node TEXT="Behavior: what the system has to do to meet the requirements, transformations of inputs to outputs, state or mode-based behavioral differences, responses to incoming requests for services" ID="ID_1922890135" CREATED="1712274140083" MODIFIED="1712274543047"/>
<node TEXT="Structure: the components that produce the behavior, the components hierarchy" ID="ID_422847635" CREATED="1712274140084" MODIFIED="1712274543047"/>
<node TEXT="Properties: the performance and physical characteristics that constrain the structure and behavior" ID="ID_1753068707" CREATED="1712274140086" MODIFIED="1712274543046"/>
<node TEXT="Interconnections: the way the structural elements arrange and communicate to achieve the required behavior" ID="ID_606805365" CREATED="1712274140087" MODIFIED="1712274543044"/>
</node>
</node>
<node TEXT="System Architecture" FOLDED="true" ID="ID_1061328642" CREATED="1712275219154" MODIFIED="1712275223076">
<node TEXT="reference" FOLDED="true" ID="ID_1393133678" CREATED="1712275853519" MODIFIED="1712275855828">
<node ID="ID_421779167" CREATED="1712275856496" MODIFIED="1712275856496" LINK="https://www.coursera.org/learn/introduction-mbse/lecture/Ev0m5/an-introduction-to-system-architecture"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/lecture/Ev0m5/an-introduction-to-system-architecture">An Introduction to System Architecture | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="definitions (2)" FOLDED="true" ID="ID_51400903" CREATED="1712275322322" MODIFIED="1712275581268">
<node TEXT="product or a structured representation of the product line" FOLDED="true" ID="ID_694806974" CREATED="1712275320256" MODIFIED="1712275433907">
<node TEXT="That is domain and implementation agnostic" ID="ID_1976768730" CREATED="1712275320256" MODIFIED="1712275320256"/>
<node TEXT="As such, it is normally limited to a functional representation but supporting a logical organization" ID="ID_306562278" CREATED="1712275320258" MODIFIED="1712275320258"/>
<node TEXT="It aims at specifying the expected functional and non-functional capabilities across all disciplines as well as mapping all disciplines resulting artifacts" ID="ID_961273738" CREATED="1712275320259" MODIFIED="1712275320259"/>
</node>
<node TEXT="embodiment, allocation, and definition" FOLDED="true" ID="ID_1906495037" CREATED="1712275538017" MODIFIED="1712275552010">
<node TEXT="embodiment of concept" ID="ID_1897190337" CREATED="1712275320260" MODIFIED="1712275537043"/>
<node TEXT="The allocation of physical and informational function to the elements of form" ID="ID_1723628341" CREATED="1712275320261" MODIFIED="1712275566459"/>
<node TEXT="definition of relationships among the elements and with the surrounding context" ID="ID_1828003886" CREATED="1712275566459" MODIFIED="1712275566460"/>
<node TEXT="System architecture may consist of a functional architecture describing a view of its behavior, logical architecture or physical architecture depending on the level of abstraction and the contextual elements." ID="ID_1504537586" CREATED="1712287103155" MODIFIED="1712287103156"/>
<node TEXT="[*] Alai, S. (2019). Evaluating Arcadia/Capella vs. OOSEM/SysML for System Architecture Development. Master&apos;s thesis, Purdue University. https://doi.org/10.5703/1288284317071" ID="ID_615545829" CREATED="1712287068739" MODIFIED="1712287138949" LINK="https://doi.org/10.5703/1288284317071"/>
</node>
</node>
<node TEXT="Architecture uses two concepts to define a system: hierarchy and decomposition" FOLDED="true" ID="ID_346552075" CREATED="1712277388318" MODIFIED="1712278184915">
<node TEXT="A hierarchy is an arrangement in which grades are classes are ranked one above the other" ID="ID_1611424039" CREATED="1712275320273" MODIFIED="1712275320273"/>
<node TEXT="A decomposition is the division into smaller constituents" ID="ID_1068927525" CREATED="1712275320275" MODIFIED="1712275320275"/>
<node TEXT="In fact, hierarchy and decomposition are intimately connected concepts which are used together to understand engineering systems and manage their complexity" ID="ID_262137828" CREATED="1712275320276" MODIFIED="1712275320276"/>
<node TEXT="It should be mentioned that a system can have many hierarchical schemes and decompositions in terms of function and form" ID="ID_153828720" CREATED="1712275320277" MODIFIED="1712275320277"/>
<node TEXT="On the other hand, a system architecture model relies on a set of views to represent the multiple aspects of the system from its requirements, functions, and interfaces to its potential solutions" ID="ID_970973131" CREATED="1712275320278" MODIFIED="1712275320278"/>
</node>
<node TEXT="purpose" FOLDED="true" ID="ID_1367149273" CREATED="1712275320267" MODIFIED="1712278102930">
<node TEXT="To communicate a direction, this includes technology selection" ID="ID_1896126093" CREATED="1712275320269" MODIFIED="1712275320269"/>
<node TEXT="To partition the system into subsystems or functional groups" FOLDED="true" ID="ID_353533684" CREATED="1712275320270" MODIFIED="1712275320270">
<node TEXT="This would include the layout of subsystem physical components" ID="ID_806688089" CREATED="1712275320270" MODIFIED="1712275320270"/>
</node>
<node TEXT="To make subsystem assignments such as human resources or cost and reliability targets" ID="ID_1899936343" CREATED="1712275320271" MODIFIED="1712275320271"/>
<node TEXT="To create communication between subsystems" FOLDED="true" ID="ID_1855896937" CREATED="1712275320271" MODIFIED="1712275320271">
<node TEXT="This would include the interface of requirements between subsystems" ID="ID_1203758590" CREATED="1712275320272" MODIFIED="1712275320272"/>
</node>
<node TEXT="Finally, to track subsystem attributes" FOLDED="true" ID="ID_1396118923" CREATED="1712275320273" MODIFIED="1712275320273">
<node TEXT="For example, to optimize the cost and quality attributes of a system," ID="ID_307551615" CREATED="1712275320273" MODIFIED="1712277388317"/>
</node>
</node>
<node TEXT="Definition Process" ID="ID_240092416" CREATED="1712287481315" MODIFIED="1712287487336">
<node TEXT="developed as part of the system engineering process" ID="ID_395214649" CREATED="1712277536975" MODIFIED="1712277543687">
<node TEXT="reference" FOLDED="true" ID="ID_916550995" CREATED="1712277604872" MODIFIED="1712277607072">
<node ID="ID_846166555" CREATED="1712277610525" MODIFIED="1712277610525" LINK="https://www.coursera.org/learn/introduction-mbse/supplement/gUsBK/system-architecture-and-workflow"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/supplement/gUsBK/system-architecture-and-workflow">System Architecture and Workflow | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Proposed Workflow For Developing System Architecture" ID="ID_1331708632" CREATED="1712277587066" MODIFIED="1712278296929">
<node TEXT="Technical processes" ID="ID_353000141" CREATED="1712277618289" MODIFIED="1712277618289">
<node TEXT="reference" FOLDED="true" ID="ID_1498522596" CREATED="1713037207876" MODIFIED="1713037209585">
<node TEXT="From &lt;https://www.coursera.org/learn/introduction-mbse/supplement/KTXW2/technical-inputs-processes-and-outputs&gt;" ID="ID_618330355" CREATED="1713037119327" MODIFIED="1713037119327" LINK="https://www.coursera.org/learn/introduction-mbse/supplement/KTXW2/technical-inputs-processes-and-outputs"/>
</node>
<node TEXT="definition" FOLDED="true" ID="ID_1883717654" CREATED="1712768285064" MODIFIED="1712768287520">
<node TEXT=" The technical processes are used to define the requirements for a system, to transform the requirements into an effective product, to permit consistent reproduction of the product where necessary, to use the product to provide the required services, to sustain the provision of those services, and to dispose of the product when it is retired from service." ID="ID_1195327257" CREATED="1712768287523" MODIFIED="1712768375724"/>
</node>
<node TEXT="rationale" FOLDED="true" ID="ID_1151722327" CREATED="1712768379499" MODIFIED="1712768383106">
<node TEXT=" technical processes enable systems engineers to coordinate the interactions between engineering specialists, other engineering disciplines, system stakeholders and operators and manufacturing. They also address conformance with the expectations and legislative requirements of society. These processes lead to the creation of a sufficient set of requirements and resulting system solutions that address the desired capabilities within the bounds of performance, environment, external interfaces, and design constraints. Without the technical processes, the risk of project failure would be unacceptably high." ID="ID_688147641" CREATED="1712768418054" MODIFIED="1712768421555"/>
</node>
<node TEXT="(V Model)" ID="ID_110771347" CREATED="1712768915279" MODIFIED="1712768921728">
<node TEXT="Definition And Decomposition (downward)" ID="ID_824483640" CREATED="1712768503656" MODIFIED="1712768942923">
<node TEXT="Input, Process, Output explanation" FOLDED="true" ID="ID_1860344845" CREATED="1713039889750" MODIFIED="1713039938609">
<node TEXT="Input" FOLDED="true" ID="ID_899965081" CREATED="1712782859437" MODIFIED="1712782863162">
<node TEXT="definition" FOLDED="true" ID="ID_667962174" CREATED="1712963977323" MODIFIED="1712963984151">
<node TEXT="the source of information for the process" ID="ID_122697208" CREATED="1712783563670" MODIFIED="1712783563670"/>
</node>
<node TEXT="These could include an organization&apos;s strategic plan or project constraints" ID="ID_601065026" CREATED="1712783576662" MODIFIED="1712783576662"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_126956151" CREATED="1712782863172" MODIFIED="1712782874583">
<node TEXT="key activities such as establishing a strategy or nominating a major stakeholder." ID="ID_500249195" CREATED="1712783607845" MODIFIED="1712783607845"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_1422011947" CREATED="1712782875819" MODIFIED="1712782878804">
<node TEXT="process results" ID="ID_1438930091" CREATED="1712783633373" MODIFIED="1712783640569"/>
<node TEXT="The outputs could be a business or a mission analysis strategy, or the identification of a major stakeholder" ID="ID_1406385238" CREATED="1712783640580" MODIFIED="1712783675800"/>
</node>
</node>
<node TEXT="Business Or Mission Analysis Process" ID="ID_444763954" CREATED="1712277745967" MODIFIED="1712782677177">
<node TEXT="Objective" FOLDED="true" ID="ID_1067586936" CREATED="1712782822570" MODIFIED="1712782825616">
<node TEXT="Define" FOLDED="true" ID="ID_6656750" CREATED="1712782727763" MODIFIED="1712782766968">
<node TEXT="The business or mission problem or opportunity" ID="ID_1586870551" CREATED="1712782775192" MODIFIED="1712782784423"/>
</node>
<node TEXT="Characterize" FOLDED="true" ID="ID_1230948642" CREATED="1712782766977" MODIFIED="1712782769766">
<node TEXT="the solution space" ID="ID_1223603471" CREATED="1712782786203" MODIFIED="1712782790002"/>
</node>
<node TEXT="Determine" FOLDED="true" ID="ID_1534701656" CREATED="1712782769778" MODIFIED="1712782773204">
<node TEXT="Potential solution classes" ID="ID_1799546831" CREATED="1712782791779" MODIFIED="1712782795805"/>
</node>
</node>
<node TEXT="Input" FOLDED="true" ID="ID_1490697908" CREATED="1713037119272" MODIFIED="1713037119272">
<node TEXT="Organization strategic plan" ID="ID_1144253630" CREATED="1713037119273" MODIFIED="1713037119273"/>
<node TEXT="Concept of operations (ConOps)" ID="ID_1847639496" CREATED="1713037119273" MODIFIED="1713037119273"/>
<node TEXT="Source documents" ID="ID_191434022" CREATED="1713037119273" MODIFIED="1713037119273"/>
<node TEXT="Life cycle constraints" ID="ID_689949236" CREATED="1713037119273" MODIFIED="1713037119273"/>
<node TEXT="Project constraints" ID="ID_582810852" CREATED="1713037119273" MODIFIED="1713037119273"/>
<node TEXT="Stakeholder requirement traceability" ID="ID_354010233" CREATED="1713037119273" MODIFIED="1713037119273"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1870651886" CREATED="1713037119273" MODIFIED="1713037119273">
<node TEXT="Establish a strategy (including need and requirements) for business or mission analysis" ID="ID_182619252" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Define the problem or opportunity space" ID="ID_626382313" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Nominate major stakeholder" ID="ID_105124311" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Define preliminary Operational Concept (OpsCon) and life cycle concepts" ID="ID_130274828" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Establish a comprehensive set of alternative solution classes" ID="ID_52792567" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Evaluate and select the preferred solution class(es)" ID="ID_676253617" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Establish and maintain traceability of analysis results" ID="ID_507487330" CREATED="1713037119274" MODIFIED="1713037119274"/>
<node TEXT="Provide baseline information for configuration management" ID="ID_1870551444" CREATED="1713037119274" MODIFIED="1713037119274"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_1032064817" CREATED="1713037119274" MODIFIED="1713037119274">
<node TEXT="• Business or mission analysis strategy" ID="ID_1309562456" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="Major stakeholder identification" ID="ID_1101033240" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Preliminary life cycle concepts" ID="ID_1125149303" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Problem of opportunity statement" ID="ID_627094340" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Business requirements" ID="ID_133934414" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Alternative solution classes" ID="ID_1414958769" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Preliminary validation criteria" ID="ID_510333260" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Preliminary MOE needs" ID="ID_1648899999" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Preliminary MOE data" ID="ID_442582028" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Business requirements traceability" ID="ID_1053629703" CREATED="1713037119275" MODIFIED="1713037119275"/>
<node TEXT="• Business or mission analysis record" ID="ID_507120345" CREATED="1713037119275" MODIFIED="1713037119275"/>
</node>
</node>
<node TEXT="Stakeholder Needs &amp; Requirements Definition Process" FOLDED="true" ID="ID_1620001077" CREATED="1712277745967" MODIFIED="1712782689588">
<node TEXT="Objective" FOLDED="true" ID="ID_1824720708" CREATED="1712784170804" MODIFIED="1712784183417">
<node TEXT="to get every stakeholders point of view for every stage of the system life in order to consolidate a complete set of stakeholder requirements as exhaustively as possible" ID="ID_318677417" CREATED="1712784183419" MODIFIED="1712784200810"/>
</node>
<node TEXT="Input" FOLDED="true" ID="ID_207136173" CREATED="1713037119276" MODIFIED="1713037119276">
<node TEXT="Source documents" ID="ID_772442651" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Project constraints" ID="ID_450945949" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Major stakeholders&apos; identification" ID="ID_1363324851" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Preliminary life cycle concepts" ID="ID_382695744" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Problem or opportunity statement" ID="ID_1499923411" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Business requirements" ID="ID_604868444" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Alternative solution classes" ID="ID_1759823182" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Preliminary validation criteria" ID="ID_572093674" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Validated requirements" ID="ID_1035849418" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Preliminary MOE needs" ID="ID_787602325" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Preliminary MOE data" ID="ID_615485781" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Business requirements traceability" ID="ID_24159686" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Life cycle constraints" ID="ID_674300386" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="Stakeholder needs" ID="ID_334315789" CREATED="1713037119278" MODIFIED="1713037119278"/>
<node TEXT="System requirements traceability" ID="ID_1943464377" CREATED="1713037119278" MODIFIED="1713037119278"/>
</node>
<node TEXT="Process" ID="ID_966289999" CREATED="1713037119278" MODIFIED="1713037119278">
<node TEXT="Prepare for stakeholder needs and requirements definition" ID="ID_7575750" CREATED="1713037119279" MODIFIED="1713037119279"/>
<node TEXT="Define stakeholder needs" ID="ID_207995359" CREATED="1713037119279" MODIFIED="1713037119279"/>
<node TEXT="Develop the operational concept and other life cycle concepts" ID="ID_1334914913" CREATED="1713037119279" MODIFIED="1713037119279"/>
<node TEXT="Transform stakeholder needs into stakeholder requirements" ID="ID_1757302894" CREATED="1713037119279" MODIFIED="1713037119279"/>
<node TEXT="Analyze stakeholder requirements" ID="ID_1475508916" CREATED="1713037119279" MODIFIED="1713037119279"/>
<node TEXT="Manage the stakeholder needs and requirements definition" ID="ID_1425318229" CREATED="1713037119279" MODIFIED="1713037119279"/>
</node>
<node TEXT="Output" ID="ID_1256481000" CREATED="1713037119279" MODIFIED="1713037119279">
<node TEXT="• Stakeholder needs and requirements definition strategy" ID="ID_273513462" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• Life cycle concepts" ID="ID_1751207077" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="System function identification" ID="ID_450887267" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• Stakeholder requirements" ID="ID_806661922" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• Validation criteria" ID="ID_1911523199" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• MOE needs" ID="ID_354180518" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• MOE data" ID="ID_1599841708" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• Stakeholder requirements traceability" ID="ID_1107275081" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• Initial RVTM" ID="ID_878171202" CREATED="1713037119280" MODIFIED="1713037119280"/>
<node TEXT="• Stakeholder needs and requirements definition record" ID="ID_1540550705" CREATED="1713037119280" MODIFIED="1713037119280"/>
</node>
<node TEXT="Identify the stakeholders" FOLDED="true" ID="ID_1872356928" CREATED="1712785298924" MODIFIED="1712785304411">
<node TEXT="Stakeholder Identification Based On Lifecycle Stages" FOLDED="true" ID="ID_1774409027" CREATED="1712785157840" MODIFIED="1712785165995">
<node TEXT="png_16258019724354341339.png" ID="ID_1773664496" CREATED="1712785182073" MODIFIED="1712785182073">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_16258019724354341339.png" SIZE="0.70838255" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Identify stakeholder needs" ID="ID_1240720115" CREATED="1712785349206" MODIFIED="1712785397622">
<node TEXT="The technique you use to collect stakeholder requirements will need to fit the needs and constraints of your organization" ID="ID_814376728" CREATED="1712785436866" MODIFIED="1712785436866"/>
<node TEXT="Techniques to Collect Stakeholder Requirements" FOLDED="true" ID="ID_1088500900" CREATED="1712784969861" MODIFIED="1712784969861">
<node TEXT="• Structured brainstorming workshops" ID="ID_1327781266" CREATED="1712784969861" MODIFIED="1712784969861"/>
<node TEXT="• Interviews and questionnaires" ID="ID_1500725529" CREATED="1712784969863" MODIFIED="1712784969863"/>
<node TEXT="• Technical, operational, and/or strategy documentation review" ID="ID_1919565854" CREATED="1712784969864" MODIFIED="1712784969864"/>
<node TEXT="• Simulations and visualizations" ID="ID_1830394167" CREATED="1712784969864" MODIFIED="1712784969864"/>
<node TEXT="• Prototyping" ID="ID_1234130350" CREATED="1712784969864" MODIFIED="1712784969864"/>
<node TEXT="• Modeling" ID="ID_1758735016" CREATED="1712784969865" MODIFIED="1712784969865"/>
<node TEXT="• Feedback from verification and validation processes," ID="ID_1394072258" CREATED="1712784969865" MODIFIED="1712784969865"/>
<node TEXT="• Review of the outcomes from the system analysis process" ID="ID_1505609033" CREATED="1712784969867" MODIFIED="1712784969867"/>
<node TEXT="Quality function deployment (QED)" ID="ID_770975584" CREATED="1712784969867" MODIFIED="1712784969867"/>
<node TEXT="• Use case diagrams" ID="ID_510707641" CREATED="1712784969868" MODIFIED="1712784969868"/>
<node TEXT="• Activity diagrams" ID="ID_553106322" CREATED="1712784969869" MODIFIED="1712784969869"/>
<node TEXT="• Functional flow block diagrams" ID="ID_1571648730" CREATED="1712784969870" MODIFIED="1712784969870"/>
</node>
</node>
<node TEXT="Extract stakeholder requirements from the stakeholder needs" ID="ID_1884854823" CREATED="1712785287506" MODIFIED="1712785316901">
<node TEXT="requirements are supposed to be verifiable" ID="ID_744931529" CREATED="1712785464999" MODIFIED="1712785479202">
<node TEXT="diagram" FOLDED="true" ID="ID_1270622124" CREATED="1712785574746" MODIFIED="1712785577791">
<node TEXT="png_17241651999228783836.png" ID="ID_1517506007" CREATED="1712785580686" MODIFIED="1712785580686">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_17241651999228783836.png" SIZE="0.4608295" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="example" FOLDED="true" ID="ID_989664856" CREATED="1712785479204" MODIFIED="1712785514415">
<node TEXT="For example, let&apos;s look at the need to easily maneuver a car in order to park. What are some requirements from this need? Would a requirement be to increase drivability? Other requirements could include, decrease the effort for handling and assist the piloting. Now let&apos;s identify the stakeholder needs for the pulse oximeter. In this case, we can divide them into user and business needs. You can see a comprehensive list of user and business needs here. I&apos;ll just review a few. First, the user needs to know their pulse and blood oxygen levels, and to be alerted if their oxygen levels are abnormal. The business need would be to provide a portable system that is usable by youth up to 19 years of age and adults 20-110 years in the home health care environment. Another neat of the user is to use the device multiple times. The business need is to keep the cost or price below $200." ID="ID_1651825236" CREATED="1712785516051" MODIFIED="1712785516051"/>
</node>
</node>
</node>
</node>
<node TEXT="System Requirements Definition Process" ID="ID_246487485" CREATED="1712277745970" MODIFIED="1712776837397">
<node TEXT="reference" FOLDED="true" ID="ID_607848333" CREATED="1712859566471" MODIFIED="1712859568691">
<node ID="ID_18646887" CREATED="1712859569737" MODIFIED="1712859569737" LINK="https://www.coursera.org/learn/introduction-mbse/lecture/u7U6k/system-requirement-definition-process"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/lecture/u7U6k/system-requirement-definition-process">System Requirement Definition Process | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Objective" FOLDED="true" ID="ID_1054745468" CREATED="1712787911379" MODIFIED="1712787914215">
<node TEXT="This process aims at transforming the stakeholder user oriented view of desired capabilities into a technical view of a solution that meets the operational needs of the user" ID="ID_471132017" CREATED="1712788180442" MODIFIED="1712788180442"/>
<node TEXT="The purpose of the process is to use the information gathered from the other processes to map out or define key system requirements which will meet the user&apos;s needs" ID="ID_243192958" CREATED="1712788132260" MODIFIED="1712788132260"/>
</node>
<node TEXT="Input" FOLDED="true" ID="ID_726393070" CREATED="1713037119281" MODIFIED="1713037119281">
<node TEXT="Life cycle concepts" ID="ID_615073833" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="System function identification" ID="ID_1910082083" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="Stakeholder requirements" ID="ID_117673052" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="Stakeholder requirements traceability" ID="ID_610011142" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="Initial RVTM" ID="ID_295177101" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="Architecture traceability" ID="ID_280748715" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="Final RVTM" ID="ID_1811464065" CREATED="1713037119282" MODIFIED="1713037119282"/>
<node TEXT="Life cycle constraints" ID="ID_1425688479" CREATED="1713037119282" MODIFIED="1713037119282"/>
</node>
<node TEXT="Process" ID="ID_1410211213" CREATED="1713037119282" MODIFIED="1713037119282">
<node TEXT="Prepare for system requirements definition" ID="ID_981870617" CREATED="1713037119283" MODIFIED="1713037119283"/>
<node TEXT="Define system requirements" ID="ID_1969903707" CREATED="1713037119283" MODIFIED="1713037119283"/>
<node TEXT="Analyze system requirements" ID="ID_1046994781" CREATED="1713037119283" MODIFIED="1713037119283"/>
<node TEXT="Manage system requirements" ID="ID_1882025937" CREATED="1713037119283" MODIFIED="1713037119283"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_418144564" CREATED="1713037119283" MODIFIED="1713037119283">
<node TEXT="System requirements definition strategy" ID="ID_1386316316" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="• System function definition" ID="ID_414683408" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="System requirements" ID="ID_1222373529" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="System functional interface identification" ID="ID_1447607425" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="• Verification criteria" ID="ID_1163127018" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="• MOP needs" ID="ID_231557751" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="• MOP data" ID="ID_1526394315" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="System requirements traceability" ID="ID_96108508" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="• Updated RVTM" ID="ID_693917120" CREATED="1713037119284" MODIFIED="1713037119284"/>
<node TEXT="System requirements definition record" ID="ID_527941281" CREATED="1713037119284" MODIFIED="1713037119284"/>
</node>
<node TEXT="System Requirements" FOLDED="true" ID="ID_553442624" CREATED="1712788319009" MODIFIED="1712876597450">
<font BOLD="true"/>
<node TEXT="definition" FOLDED="true" ID="ID_1275003245" CREATED="1712876601446" MODIFIED="1712876604263">
<node TEXT="System requirements are all of the requirements at the system level that describe the functions which the system as a whole should fulfill to satisfy the stakeholder needs and requirements and is expressed in an appropriate combination of textual statements, views, and non-functional requirements" ID="ID_641510484" CREATED="1712788323045" MODIFIED="1712788323045"/>
</node>
<node TEXT="System requirements are considered in detail during system definition" FOLDED="true" ID="ID_258402018" CREATED="1712788323045" MODIFIED="1712788323045">
<node TEXT="Rationale" FOLDED="true" ID="ID_1011591404" CREATED="1712788340366" MODIFIED="1712788346995">
<node TEXT="What is the rationale behind the system requirements definition process? System Requirements play major roles in systems engineering" FOLDED="true" ID="ID_1411983834" CREATED="1712788323047" MODIFIED="1712788323047">
<node TEXT="They form the basis of system architecture and design activities" ID="ID_912591053" CREATED="1712788385264" MODIFIED="1712788385264"/>
<node TEXT="They also form the basis of system integration and verification activities" ID="ID_951904040" CREATED="1712788385264" MODIFIED="1712788385264"/>
<node TEXT="They can act as reference for validation and stakeholder acceptance and" ID="ID_173054119" CREATED="1712788385265" MODIFIED="1712788407807"/>
<node TEXT="finally, they provide a means of communication between the various technical staff that interact throughout the project." ID="ID_1022120468" CREATED="1712788407808" MODIFIED="1712788407809"/>
</node>
</node>
</node>
<node TEXT="Relationship To Stakeholder Requirements" FOLDED="true" ID="ID_942971702" CREATED="1712877028468" MODIFIED="1712877122639">
<node TEXT="A set of stakeholder requirements are clarified and translated from statements of need into engineering oriented language in order to enable proper architecture definition, design, and verification activities that are needed as the basis for system requirements analysis" ID="ID_1479555238" CREATED="1712877028468" MODIFIED="1712877028468"/>
</node>
<node TEXT="Relationship To Logical Architecture" FOLDED="true" ID="ID_1005033862" CREATED="1712877028469" MODIFIED="1712877120641">
<node TEXT="A set of stakeholder requirements are clarified and translated from statements of need into engineering oriented language in order to enable proper architecture definition, design, and verification activities that are needed as the basis for system requirements analysis" ID="ID_330990885" CREATED="1712877028478" MODIFIED="1712877028478"/>
<node TEXT="The logical architecture define system boundary and functions from which more detailed system requirements can be derived" FOLDED="true" ID="ID_341168697" CREATED="1712877028473" MODIFIED="1712877028473">
<node TEXT="The starting point for this process may be to identify functional requirements from the stakeholder requirements, and to use this to start the architectural definition or to begin with a high level functional architecture view and use this as the basis for structuring system requirements" ID="ID_1443892836" CREATED="1712877028474" MODIFIED="1712877028474"/>
</node>
</node>
<node TEXT="Traceability And Systems Requirements" FOLDED="true" ID="ID_1489513028" CREATED="1712877028476" MODIFIED="1712877117159">
<node TEXT="Requirements traceability provides ability to track information from the origin of the stakeholder requirements to the top level of requirements and other system definition elements at all levels of the system hierarchy" ID="ID_883406763" CREATED="1712877028479" MODIFIED="1712877028479"/>
<node TEXT="Traceability is used to provide an understanding as to the extent of a change as an input when impact analysis is performed in cases of proposed engineering improvements or requests for change" ID="ID_554558699" CREATED="1712877028481" MODIFIED="1712877028481"/>
</node>
<node TEXT="Requirement Management" FOLDED="true" ID="ID_238897413" CREATED="1712877028484" MODIFIED="1712877601234">
<node TEXT="On the one hand, requirements management is performed to ensure alignment of the system and system element requirements with other representations, analysis, and artifacts of the system" FOLDED="true" ID="ID_1928822939" CREATED="1712877028486" MODIFIED="1712877028486">
<node TEXT="It includes providing an understanding of the requirements, obtaining commitment, managing changes, maintaining bidirectional traceability among the requirements and with the rest of the system definition, and alignment with project resources and schedule" ID="ID_1199329167" CREATED="1712877028487" MODIFIED="1712877028487"/>
</node>
<node TEXT="On the other hand, requirements management is tied to configuration management for baseline management and control" FOLDED="true" ID="ID_506152762" CREATED="1712877028490" MODIFIED="1712877028490">
<node TEXT="Whether requirements have been defined and approved, they need to be put under baseline management and control" ID="ID_1209483247" CREATED="1712877028493" MODIFIED="1712877028493"/>
<node TEXT="The baseline allows the project to analyze and understand the impact, technical, cost, and schedule of ongoing proposed changes" ID="ID_1587096192" CREATED="1712877028495" MODIFIED="1712877028495"/>
</node>
</node>
<node TEXT="System Requirements Attributes" ID="ID_271123241" CREATED="1712877674242" MODIFIED="1712877679026">
<node TEXT="Necessary" ID="ID_1811940769" CREATED="1712877679048" MODIFIED="1712877683235"/>
<node TEXT="Verifiable" ID="ID_476751558" CREATED="1712877686438" MODIFIED="1712877689021"/>
<node TEXT="Attainable" ID="ID_616984472" CREATED="1712877689031" MODIFIED="1712877692439"/>
<node TEXT="Keep in mind that it is expected that the requirements exhibit all of the following attributes in the list" ID="ID_1614135588" CREATED="1712877028502" MODIFIED="1712877028502">
<node TEXT="For example, the terms used to define requirements must be consistent" ID="ID_1356162794" CREATED="1712877028505" MODIFIED="1712877028505"/>
<node TEXT="The requirements themselves should be specified only once and should not be redundant, they must be correct or not contain any errors of fact, they must avoid conflicting with other requirements, they must conform to an approved standard template and style for writing requirements when applicable" ID="ID_561078699" CREATED="1712877028507" MODIFIED="1712877028507"/>
<node TEXT="The requirements must be feasible, in other words, they can be satisfied within natural physical laws, state of the art technologies, and other project constraints" ID="ID_1384885718" CREATED="1712877028508" MODIFIED="1712877028508"/>
<node TEXT="These are just a few examples, you&apos;ll want to review the complete list in your reading for the week" ID="ID_56070879" CREATED="1712877028510" MODIFIED="1712877028510"/>
<node TEXT="More specifically, good requirements are characterized by the following attributes" ID="ID_1718018234" CREATED="1712877028511" MODIFIED="1712877028511"/>
<node TEXT="They define what and not how, they are unambiguous, or in other words, the requirements are clear and complete" ID="ID_1400102931" CREATED="1712877028513" MODIFIED="1712877028513"/>
<node TEXT="You can verify them by test or independent analysis" ID="ID_1189332233" CREATED="1712877028516" MODIFIED="1712877028516"/>
<node TEXT="They are necessary and appropriate for the level of system hierarchy, they are feasible, they are consistent, traceable, with requirements above and below in a system hierarchy" ID="ID_1713561990" CREATED="1712877028517" MODIFIED="1712877028517"/>
<node TEXT="On the other hand, it is important to ensure the use of proper semantics when formulating the requirements to distinguish them from statements and goals" FOLDED="true" ID="ID_1372636191" CREATED="1712877028518" MODIFIED="1712877028518">
<node TEXT="In fact, when writing a requirement, one has to use shall" ID="ID_1969191475" CREATED="1712877028522" MODIFIED="1712877028522"/>
<node TEXT="For example, the system shall provide, the system shall be capable of, the system shall weigh" ID="ID_498548324" CREATED="1712877028524" MODIFIED="1712877028524"/>
<node TEXT="On the other hand, statements of fact would use will" FOLDED="true" ID="ID_477370395" CREATED="1712877028525" MODIFIED="1712877028525">
<node TEXT="Statements of fact which use the word will often are part of a leading scenario for facing one or more requirements" ID="ID_198671376" CREATED="1712877028527" MODIFIED="1712877028527"/>
</node>
<node TEXT="Finally, goals would use should" FOLDED="true" ID="ID_1373618128" CREATED="1712877028528" MODIFIED="1712877028528">
<node TEXT="The word should is used for designed goals where quantifiable requirements cannot be applied to a desired attribute" ID="ID_1534716122" CREATED="1712877028530" MODIFIED="1712877028530"/>
<node TEXT="It should be noted that shall is a demand that must be met while should is a wish that should be met if possible" ID="ID_255355473" CREATED="1712877028531" MODIFIED="1712877028531"/>
</node>
</node>
</node>
</node>
<node TEXT="System Requirement Classifications" ID="ID_1819926710" CREATED="1712955776113" MODIFIED="1712956277697">
<node ID="ID_1362836872" CREATED="1712955693190" MODIFIED="1712955693190"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>System requirements are classified into different categories depending on the requirements definition methods and/or the architecture and design methods being applied.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node ID="ID_201041363" CREATED="1712955693191" MODIFIED="1712955693191"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Functional requirements</font></b></strong>&#xa0;describe qualitatively the system functions or tasks to be performed in operation</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_533426003" CREATED="1712955693192" MODIFIED="1712955693192"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Operational requirements</font></b></strong>&#xa0;define the operational conditions or properties that are required for the system to operate or exist</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_331320736" CREATED="1712955693195" MODIFIED="1712955693195"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Design Constraints</font></b></strong>&#xa0;define the limits on the options that are available to a designer of a solution by imposing immovable boundaries and limits</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_599416118" CREATED="1712955693196" MODIFIED="1712955693196"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Cost and Schedule constraints</font></b></strong>&#xa0;define, for example, the cost of a single exemplar of the system, the expected delivery date of the first exemplar, etc.</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_83471017" CREATED="1712955693197" MODIFIED="1712955693197"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Performance requirements</font></b></strong>&#xa0;define quantitatively how well the system needs to perform the functions</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1884429583" CREATED="1712955693198" MODIFIED="1712955693198"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Modes and/or States requirements</font></b></strong>&#xa0;define the various operational modes of the system in use and events conducted to transitions of modes</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1128704797" CREATED="1712955693199" MODIFIED="1712955693199"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Policies and regulations</font></b></strong>&#xa0;define relevant and applicable organizational policies or regulatory requirements that could affect the operation or performance of the system (e.g. labor policies, reports to a regulatory agency, health or safety criteria, etc.).</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_453458177" CREATED="1712955693199" MODIFIED="1712955693199"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Environmental conditions</font></b></strong>&#xa0;define the environmental conditions to be encountered by the system in its operational modes.</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_18992510" CREATED="1712955693200" MODIFIED="1712955693200"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Usability requirements</font></b></strong>&#xa0;define the quality of system use</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1476020830" CREATED="1712955693201" MODIFIED="1712955693201"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Interface requirements</font></b></strong>&#xa0;define how the system is required to interact or to exchange material, energy or information with external systems (external interface) or how system elements within the system interact with each other (internal interface)</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_179278838" CREATED="1712955693202" MODIFIED="1712955693202"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Physical Characteristics</font></b></strong>&#xa0;define constraints on weight, volume, and dimension applicable to the elements of the system that compose the system</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_55822213" CREATED="1712955693203" MODIFIED="1712955693203"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Packaging, Handling, Shipping, and Transportation requirements </font></b></strong>define requirements imposed on the system to ensure that it can be packaged, handled, shipped, and transported within its intended operational context</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_974155311" CREATED="1712955693204" MODIFIED="1712955693204"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul>
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span><strong style="font-weight: 700; font-family: unset"><b><font face="unset">Adaptability requirements</font></b></strong>&#xa0;define potential extension, growth, or scalability during the life of the system.</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node TEXT="System Requirements Tools" FOLDED="true" ID="ID_562824847" CREATED="1712955693205" MODIFIED="1712955841295" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/nhuIm1PfTamzLfX-FYeg6w_f790c994f1714ab383ce5e660e0f9cf1_Yw-JoVs-AEk54Ue_CTe2GTHwIZxpF7mzO8zI6OsWfy7tbqFMK4kBT3zMVBYaOqye46AfaKWbn8u5AsmVgtInhPWPDkvia-v9V4JPxBNpa3GnWSHc0-4bhan69xS6l5r6LmYU7smjc89rb4rcH0rpeB63NSe_SOaYDriyrYoVUrhFA2Fo0CLIEVzje5BTYQ?expiry=1713052800000&amp;hmac=ZoKfbRdKcKBJTJiGtiidfpHgATvkjgb8hXra6O8jIzo">
<node TEXT="png_97397769222300811.png" ID="ID_1361404257" CREATED="1712955845739" MODIFIED="1712955845739">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_97397769222300811.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
</node>
</node>
<node ID="ID_541403912" CREATED="1712955693215" MODIFIED="1712955693215"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>The figure above provides a workflow for requirements generation starting from Top level needs all the way to System level requirements.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node FOLDED="true" ID="ID_46727119" CREATED="1712955693206" MODIFIED="1712955693206"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>As you can see in the figure above, here are many tools and methods that you could use to develop or define system requirements, for example:</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node FOLDED="true" ID="ID_831857491" CREATED="1712955693206" MODIFIED="1712955693206"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>1. QFD (Quality Function Deployment)</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node ID="ID_847152646" CREATED="1712955693212" MODIFIED="1712955693212"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Let us take a closer look at one of these tools, namely, QFD. QFD stands for Quality Function Deployment. QFD is a powerful technique to elicit requirements and compare design characteristics against user needs. The inputs to the QFD application are user needs and operational concepts. In this figure, we can see a typical House of quality that is developed using the QFD tool.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_328152601" CREATED="1712955693213" MODIFIED="1712955693213"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>It should be emphasized that the Users from across the life cycle should be included to ensure that all aspects of user needs are accounted for and prioritized [*].&#xa0;</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="" ID="ID_1233689550" CREATED="1712955693214" MODIFIED="1712955897023" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/w-wRUj43ROO5KsI1IcbezA_a069ade45daa4bdbba106ff56fa228f1_AFTv8QcTNE7mKUYLPix_UQoStKUMtC6DrpMJEMOFShaa6mGtMh_gKB9r_8Oet1xBZ65Fu2wV8rLCFxPSuJribKHgBXtsspJazJaaSWhGMa8EJXbrmxzzf1xrf-Nd_6BtJfwCvt4uTbwbBMYDUCcSv4sHwZoPGd71EEMzMT7tkJZHCEzKsAU0q1ZA_AUSkA?expiry=1713052800000&amp;hmac=jr7inx_cj2lKwXZp8Zb50thrqKQ_RNVTkNqNd4mu9Z8"/>
</node>
</node>
<node ID="ID_1666574797" CREATED="1712955693207" MODIFIED="1712955693207"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>2. Prototyping</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1801751016" CREATED="1712955693208" MODIFIED="1712955693208"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>3. Interviews</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1640469841" CREATED="1712955693210" MODIFIED="1712955693210"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>4. Focus groups</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1954694592" CREATED="1712955693211" MODIFIED="1712955693211"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>5. Delphi Techniques</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
</node>
<node ID="ID_297115433" CREATED="1712955693216" MODIFIED="1712955693216" LINK="https://www.sebokwiki.org/wiki/Guide_to_the_Systems_Engineering_Body_of_Knowledge_(SEBoK)"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>[*] <a target="_blank" rel="noopener nofollow noreferrer" href="https://www.sebokwiki.org/wiki/Guide_to_the_Systems_Engineering_Body_of_Knowledge_(SEBoK)" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>https://www.sebokwiki.org/wiki/Guide_to_the_Systems_Engineering_Body_of_Knowledge_(SEBoK)</u></font></a></span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node FOLDED="true" ID="ID_234395837" CREATED="1712955693220" MODIFIED="1712955693220"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Let’s go back to the Pulse Oximeter example. The pulse oximeter has functional, usability performance, and system interface requirements, as shown in this table.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node TEXT="png_2458389204976064414.png" ID="ID_872423113" CREATED="1712956080344" MODIFIED="1712956080344">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_2458389204976064414.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
<node FOLDED="true" ID="ID_1764600446" CREATED="1712955693222" MODIFIED="1712955693222"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Two examples of functional requirements are:</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node TEXT="The system shall measure pulse rate, FR. This requirement is called FR - 001" ID="ID_499518149" CREATED="1712956154536" MODIFIED="1712956154536"/>
<node TEXT="The system shall measure functional Oxygen saturation of Arterial Hemoglobin, %SpO2. This requirement is called FR - 002)" ID="ID_492675471" CREATED="1712956154538" MODIFIED="1712956154538"/>
</node>
<node TEXT="Note that these can be refined into relevant/originating requirements and needs as:" FOLDED="true" ID="ID_1547913982" CREATED="1712956227512" MODIFIED="1712956227512">
<node TEXT="Measure pulse and blood oxygen named SN-UN-001" ID="ID_82587000" CREATED="1712956227512" MODIFIED="1712956227512"/>
</node>
</node>
<node FOLDED="true" ID="ID_1950392310" CREATED="1712955693229" MODIFIED="1712955693229"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>In addition to functional, usability performance, and system interface requirement, the pulse oximeter also has other requirements. These include: system operations, system modes and states, environmental conditions, packaging, handline, shipping, and transportation, as shown in this table.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node TEXT="png_4090067125134490705.png" ID="ID_1924769912" CREATED="1712956202958" MODIFIED="1712956202958">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_4090067125134490705.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Architecture Definition Process" FOLDED="true" ID="ID_88713204" CREATED="1712277745971" MODIFIED="1712782689589">
<node TEXT="Input" FOLDED="true" ID="ID_851891814" CREATED="1713037119285" MODIFIED="1713037119285">
<node TEXT="Life cycle concepts" ID="ID_772481544" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="System function definition" ID="ID_1437834097" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="System requirements" ID="ID_1009532810" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="System functional interface identification" ID="ID_149661031" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="System requirements traceability" ID="ID_1903581672" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="Updated RVTM" ID="ID_152525917" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="Design traceability" ID="ID_1233688238" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="Interface definition update identification" ID="ID_1695820835" CREATED="1713037119286" MODIFIED="1713037119286"/>
<node TEXT="Life cycle constraints" ID="ID_1877140520" CREATED="1713037119286" MODIFIED="1713037119286"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_754718780" CREATED="1713037119286" MODIFIED="1713037119286">
<node TEXT="Prepare for architecture definition" ID="ID_52275642" CREATED="1713037119287" MODIFIED="1713037119287"/>
<node TEXT="Develop architecture viewpoints" ID="ID_1993921908" CREATED="1713037119287" MODIFIED="1713037119287"/>
<node TEXT="Develop models and views of candidate architectures" ID="ID_1141958590" CREATED="1713037119287" MODIFIED="1713037119287"/>
<node TEXT="Relate the architecture to design" ID="ID_154962671" CREATED="1713037119287" MODIFIED="1713037119287"/>
<node TEXT="Assess architecture candidates" ID="ID_546593885" CREATED="1713037119287" MODIFIED="1713037119287"/>
<node TEXT="Manage the selected architecture" ID="ID_1710372027" CREATED="1713037119287" MODIFIED="1713037119287"/>
</node>
<node TEXT="Output" ID="ID_404616506" CREATED="1713037119287" MODIFIED="1713037119287">
<node TEXT="• Architecture definition strategy" ID="ID_1071566155" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• System architecture description" ID="ID_1872989508" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="System architecture rationale" ID="ID_430756561" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• Documentation tree" ID="ID_1785301827" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• Preliminary interface definition" ID="ID_915085611" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• Preliminary T PM needs" ID="ID_1668979238" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• Preliminary T PM data" ID="ID_52623640" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• Architecture traceability" ID="ID_891521853" CREATED="1713037119288" MODIFIED="1713037119288"/>
<node TEXT="• Architecture definition record" ID="ID_1364958832" CREATED="1713037119288" MODIFIED="1713037119288"/>
</node>
<node TEXT="Architecture Definition Process and the Pulse Oximeter" FOLDED="true" ID="ID_1071588240" CREATED="1712956540903" MODIFIED="1712956540903">
<node ID="ID_1671809897" CREATED="1712956332733" MODIFIED="1712956332733"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Let’s take a closer look at the functional flow decomposition of the pulse oximeter.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node FOLDED="true" ID="ID_1087262270" CREATED="1712956332734" MODIFIED="1712956332734"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>In the figure below, we can see the functional decomposition describing the main functions as well as their sub-function. For example, the function “Measure Pulse” is broken down into three sub-functions, namely</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node ID="ID_122996357" CREATED="1712956332734" MODIFIED="1712956332734"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Measure pulse rate</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1549637886" CREATED="1712956332735" MODIFIED="1712956332735"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Display pulse rate</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1882960915" CREATED="1712956332736" MODIFIED="1712956332736"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Store data</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="png_15628288731952684678.png" FOLDED="true" ID="ID_237537823" CREATED="1712956385576" MODIFIED="1712956385576">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_15628288731952684678.png" SIZE="0.375" NAME="ExternalObject"/>
<node TEXT="" ID="ID_950683963" CREATED="1712956332736" MODIFIED="1712956362610" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/l6UAIKQDQi2bMfto9CwnOQ_fb6e185d46c4439686636b26cf3760f1_fJEJ8whUq2rcZF6lCS92mCzApgkGPqqn48A_-bMzFb7Aol7VUPf43qRqWRu3ONyK5NwHCXM7OQEf2QmQWl4dsbaVUHePH5X0HYeGb74FKk1Geo5BuT1KOlZhgeKWkjWpvllihm67S4HUo8JfNEFdx4uG4HrP-CrtnPJS0X6AB-cD85V6G_L1ZXMiEdOFKw?expiry=1713052800000&amp;hmac=l1i_5uPAW1Bvy1foBABK__dZhTW7MhojPvxyLoa5sls"/>
<node ID="ID_525092733" CREATED="1712956332737" MODIFIED="1712956332737"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Once the functional decomposition is completed, a functional architecture can be created. On the other hand, physical architecture can also be developed by mapping forms or structures or technological solutions to the different functions/sub-functions.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="png_17672306313890752965.png" FOLDED="true" ID="ID_279402577" CREATED="1712956477745" MODIFIED="1712956477745">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_17672306313890752965.png" SIZE="0.375" NAME="ExternalObject"/>
<node ID="ID_949805087" CREATED="1712956332738" MODIFIED="1712956332738"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>For example, the “Display and monitoring sub-system” fulfills the “Monitor subsystems for proper operation” function. Another example is the “User Interface” which fulfills the following sub-functions: “Report BIT results”, “Display Pulse rate”, “Access data”, and “Access User settings”.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node TEXT="" ID="ID_166039381" CREATED="1712956332738" MODIFIED="1712956469434" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/U2FXjodKTkCeYQLjVZDxcQ_7e1e43e68b1946ec8c3fac584e3274f1_Yl2371kbi3UE_98sl85oT7th0hHzSBXiiIVtLAEoNPDV6nn3xTw--E0F-OJ11_QkOMvuPouJz_2AyejHVHwK0aO9mPJNtv9F1Slrj4GL7Zemhtp_YtvDOpNrTd2w2PNHeb9Y-fOD2Pkr92fMLbY3bQczCbQeab0cEEj0HRaqwPQRkhGmNqIRvnrf3v2y_w?expiry=1713052800000&amp;hmac=V_8KHdfUlPZfcTR21EHJdh1AQzyez-EV0bqRjs3D0FU"/>
</node>
<node FOLDED="true" ID="ID_1281335710" CREATED="1712956332739" MODIFIED="1712956332739"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div data-testid="reading-complete-container" class="css-wljx6v" style="margin-top: 0; display: flex">
          <div>
            <span class="cds-button-label" style="text-transform: none; width: 132.025px; display: inherit">Mark as completed</span>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
<node ID="ID_1558381655" CREATED="1712956332740" MODIFIED="1712956332740"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-15drdcr" style="border-top-color: rgb(221, 221, 221); border-top-style: solid; border-top-width: 1px; padding-top: 15px; padding-bottom: 15px; padding-right: 0px; padding-left: 0px; display: flex">
      <div class="rc-ItemFeedback undefined">
        <div class="rc-ItemFeedbackContent horizontal-box css-lfchfm" style="display: flex; margin-left: -8px">
          <div data-testid="like-button" class="css-e40v4" style="margin-right: 0">
            <div class="rc-LikeContent">
              <div>
                <span class="cds-button-label" style="text-transform: none; width: 49.35px; display: inherit">Like</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_1253677296" CREATED="1712956332741" MODIFIED="1712956332741"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-15drdcr" style="border-top-color: rgb(221, 221, 221); border-top-style: solid; border-top-width: 1px; padding-top: 15px; padding-bottom: 15px; padding-right: 0px; padding-left: 0px; display: flex">
      <div class="rc-ItemFeedback undefined">
        <div class="rc-ItemFeedbackContent horizontal-box css-lfchfm" style="display: flex; margin-left: -8px">
          <div data-testid="dislike-button" class="css-e40v4" style="margin-right: 0">
            <div class="rc-LikeContent">
              <div>
                <span class="cds-button-label" style="text-transform: none; width: 64.9875px; display: inherit">Dislike</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
<node ID="ID_838224897" CREATED="1712956332742" MODIFIED="1712956332742"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-15drdcr" style="border-top-color: rgb(221, 221, 221); border-top-style: solid; border-top-width: 1px; padding-top: 15px; padding-bottom: 15px; padding-right: 0px; padding-left: 0px; display: flex">
      <div class="rc-ItemFeedback undefined">
        <div class="rc-ItemFeedbackContent horizontal-box css-lfchfm" style="display: flex; margin-left: -8px">
          <div class="css-8xs46v" style="margin-right: 0">
            <div class="rc-FlagContent css-b0z14z" style="display: inline-block">
              <span class="cds-button-label" style="text-transform: none; width: 118.488px; display: inherit">Report an issue</span><br class="Apple-interchange-newline"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Design Definition Process" FOLDED="true" ID="ID_1455502438" CREATED="1713037119288" MODIFIED="1713037119288">
<node TEXT="Input" FOLDED="true" ID="ID_37718218" CREATED="1713037119289" MODIFIED="1713037119289">
<node TEXT="Life cycle concepts" ID="ID_300132342" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="System function definition" ID="ID_1003336221" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="System requirements" ID="ID_1780334824" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="System functional interface identification" ID="ID_46779842" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="System architecture description" ID="ID_1985988835" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="System architecture rationale" ID="ID_1606575792" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Preliminary interface definition" ID="ID_270514377" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Preliminary TPM needs" ID="ID_1691586360" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Preliminary TPM data" ID="ID_1927898822" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Architecture traceability" ID="ID_1454679252" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Interface definition update identification" ID="ID_756162247" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Implementation traceability" ID="ID_223086159" CREATED="1713037119290" MODIFIED="1713037119290"/>
<node TEXT="Life cycle constraints" ID="ID_1996795924" CREATED="1713037119290" MODIFIED="1713037119290"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_595055831" CREATED="1713037119290" MODIFIED="1713037119290">
<node TEXT="Prepare for design definition" ID="ID_410560748" CREATED="1713037119291" MODIFIED="1713037119291"/>
<node TEXT="Establish design characteristics and design enablers related to each system element" ID="ID_1314473787" CREATED="1713037119291" MODIFIED="1713037119291"/>
<node TEXT="Assess alternatives for obtaining system elements" ID="ID_379164670" CREATED="1713037119291" MODIFIED="1713037119291"/>
<node TEXT="Manage the design" ID="ID_1202623325" CREATED="1713037119291" MODIFIED="1713037119291"/>
</node>
<node TEXT="Output" ID="ID_1955991923" CREATED="1713037119291" MODIFIED="1713037119291">
<node TEXT="• Design definition strategy" ID="ID_462635030" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="• System design description" ID="ID_409824077" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="System design rationale" ID="ID_1095845278" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="• Interface definition" ID="ID_501788909" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="• TPM needs" ID="ID_1329542690" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="• TPM data" ID="ID_1248925786" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="• Design traceability" ID="ID_1014795381" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="System element descriptions" ID="ID_1921483925" CREATED="1713037119292" MODIFIED="1713037119292"/>
<node TEXT="• Design definition record" ID="ID_1452370222" CREATED="1713037119292" MODIFIED="1713037119292"/>
</node>
</node>
<node TEXT="System Analysis Process" FOLDED="true" ID="ID_1287199660" CREATED="1713037119292" MODIFIED="1713037119292">
<node TEXT="Input" ID="ID_862309372" CREATED="1713037119293" MODIFIED="1713037119293">
<node TEXT="Life cycle concepts" ID="ID_1948378257" CREATED="1713037119295" MODIFIED="1713037119295"/>
<node TEXT="Analysis situations" ID="ID_1911124960" CREATED="1713037119295" MODIFIED="1713037119295"/>
<node TEXT="Life cycle constraints" ID="ID_1673144708" CREATED="1713037119295" MODIFIED="1713037119295"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_346014608" CREATED="1713037119295" MODIFIED="1713037119295">
<node TEXT="Prepare for system analysis" ID="ID_1302084831" CREATED="1713037119296" MODIFIED="1713037119296"/>
<node TEXT="Perform system analysis" ID="ID_1156487837" CREATED="1713037119296" MODIFIED="1713037119296"/>
<node TEXT="Manage system analysis" ID="ID_1106580509" CREATED="1713037119296" MODIFIED="1713037119296"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_748300760" CREATED="1713037119296" MODIFIED="1713037119296">
<node TEXT="• System analysis strategy" ID="ID_228014670" CREATED="1713037119297" MODIFIED="1713037119297"/>
<node TEXT="• System analysis report" ID="ID_1283770174" CREATED="1713037119297" MODIFIED="1713037119297"/>
<node TEXT="System analysis record" ID="ID_1195323004" CREATED="1713037119297" MODIFIED="1713037119297"/>
</node>
</node>
</node>
<node TEXT="Implementation Process (bottom)" ID="ID_1082222538" CREATED="1713037119297" MODIFIED="1713040203301">
<node TEXT="Input" FOLDED="true" ID="ID_1894556016" CREATED="1713037119298" MODIFIED="1713037119298">
<node TEXT="Life cycle concepts" ID="ID_884703155" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="System architecture description" ID="ID_552627983" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="System architecture rationale" ID="ID_50835756" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="System design description" ID="ID_908979567" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="System design rationale" ID="ID_1780259198" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="Interface definition" ID="ID_1793506217" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="Design traceability" ID="ID_647062660" CREATED="1713037119299" MODIFIED="1713037119299"/>
<node TEXT="System element descriptions" ID="ID_590773002" CREATED="1713037119299" MODIFIED="1713037119299"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1364427926" CREATED="1713037119299" MODIFIED="1713037119299">
<node TEXT="Prepare for implementation" ID="ID_1161036122" CREATED="1713037119300" MODIFIED="1713037119300"/>
<node TEXT="Perform implementation" ID="ID_777179176" CREATED="1713037119300" MODIFIED="1713037119300"/>
<node TEXT="Manage results of implementation" ID="ID_1030537676" CREATED="1713037119300" MODIFIED="1713037119300"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_768678033" CREATED="1713037119300" MODIFIED="1713037119300">
<node TEXT="• Implementation strategy" ID="ID_1138117995" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="• Implementation enabling system requirements" ID="ID_56287596" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="• Implementation constraints" ID="ID_608515990" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="• System elements" ID="ID_1038318215" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="• System element documentation" ID="ID_489489928" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="Operator/maintainer training materials" ID="ID_67477260" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="• Implementation traceability" ID="ID_200062329" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="Implementation report" ID="ID_1469696160" CREATED="1713037119301" MODIFIED="1713037119301"/>
<node TEXT="• Implementation record" ID="ID_848514958" CREATED="1713037119301" MODIFIED="1713037119301"/>
</node>
</node>
<node TEXT="Integration And Recomposition (upward)" FOLDED="true" ID="ID_1607198065" CREATED="1712768658874" MODIFIED="1712768958967">
<node TEXT="Integration Process" FOLDED="true" ID="ID_1570916958" CREATED="1713037119301" MODIFIED="1713037119301">
<node TEXT="Input" FOLDED="true" ID="ID_1453574957" CREATED="1713037119302" MODIFIED="1713037119302">
<node TEXT="Life cycle concepts" ID="ID_1101239463" CREATED="1713037119303" MODIFIED="1713037119303"/>
<node TEXT="Interface definitions" ID="ID_1395332051" CREATED="1713037119303" MODIFIED="1713037119303"/>
<node TEXT="System element descriptions" ID="ID_248923095" CREATED="1713037119303" MODIFIED="1713037119303"/>
<node TEXT="System elements" ID="ID_1000878123" CREATED="1713037119303" MODIFIED="1713037119303"/>
<node TEXT="System element documentation" ID="ID_1813985997" CREATED="1713037119303" MODIFIED="1713037119303"/>
<node TEXT="Implementation traceability" ID="ID_1868215081" CREATED="1713037119303" MODIFIED="1713037119303"/>
<node TEXT="Accepted system or system element" ID="ID_1515607268" CREATED="1713037119303" MODIFIED="1713037119303"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1157843942" CREATED="1713037119303" MODIFIED="1713037119303">
<node TEXT="Prepare for integration" ID="ID_1479902914" CREATED="1713037119304" MODIFIED="1713037119304"/>
<node TEXT="Perform integration" FOLDED="true" ID="ID_807462046" CREATED="1713037119304" MODIFIED="1713037119304">
<node TEXT="Successively integrate system element configurations until the complete system is synthesized." ID="ID_133361988" CREATED="1713037119304" MODIFIED="1713037119304"/>
</node>
<node TEXT="Manage results of integration" ID="ID_1369396937" CREATED="1713037119304" MODIFIED="1713037119304"/>
</node>
<node TEXT="Output" ID="ID_1212054981" CREATED="1713037119304" MODIFIED="1713037119304">
<node TEXT="• Integration strategy" ID="ID_838066259" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="• Integration enabling system requirements" ID="ID_1544613" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="• Integration constraints" ID="ID_409930576" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="Integration procedure" ID="ID_660307953" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="Integrated system or system elements" ID="ID_802427147" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="• Interface definition update identification" ID="ID_918849963" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="• Integration report" ID="ID_591499268" CREATED="1713037119305" MODIFIED="1713037119305"/>
<node TEXT="• Integration record" ID="ID_1790820995" CREATED="1713037119305" MODIFIED="1713037119305"/>
</node>
</node>
<node TEXT="Verification Process" FOLDED="true" ID="ID_768788030" CREATED="1713037119305" MODIFIED="1713037119305">
<node TEXT="Input" FOLDED="true" ID="ID_51399920" CREATED="1713037119306" MODIFIED="1713037119306">
<node TEXT="Life cycle concepts" ID="ID_251499545" CREATED="1713037119306" MODIFIED="1713037119306"/>
<node TEXT="System requirements" ID="ID_1050630413" CREATED="1713037119306" MODIFIED="1713037119306"/>
<node TEXT="Verification criteria" ID="ID_103385394" CREATED="1713037119306" MODIFIED="1713037119306"/>
<node TEXT="Updated RVTM" ID="ID_915741153" CREATED="1713037119306" MODIFIED="1713037119306"/>
<node TEXT="Interface definition" ID="ID_1971410947" CREATED="1713037119306" MODIFIED="1713037119306"/>
<node TEXT="Integrated system or system elements" ID="ID_445099792" CREATED="1713037119306" MODIFIED="1713037119306"/>
<node TEXT="Integration report" ID="ID_188993709" CREATED="1713037119306" MODIFIED="1713037119306"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_798689936" CREATED="1713037119306" MODIFIED="1713037119306">
<node TEXT="Prepare for verification" ID="ID_1001385546" CREATED="1713037119307" MODIFIED="1713037119307"/>
<node TEXT="Perform verification" ID="ID_1328385881" CREATED="1713037119307" MODIFIED="1713037119307"/>
<node TEXT="Manage results of verification" ID="ID_1475119573" CREATED="1713037119307" MODIFIED="1713037119307"/>
</node>
<node TEXT="Output" ID="ID_1912472709" CREATED="1713037119307" MODIFIED="1713037119307">
<node TEXT="• Verification strategy" ID="ID_1095159967" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="• Verification enabling system requirements" ID="ID_608547522" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="• Verification constraints" ID="ID_183363700" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="Verification procedure" ID="ID_991424579" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="• Final RVTM" ID="ID_1945711952" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="• Verified system" ID="ID_1718665618" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="• Verification report" ID="ID_537794567" CREATED="1713037119308" MODIFIED="1713037119308"/>
<node TEXT="• Verification record" ID="ID_1120980251" CREATED="1713037119308" MODIFIED="1713037119308"/>
</node>
</node>
<node TEXT="Transition Process" FOLDED="true" ID="ID_1515232623" CREATED="1713037119308" MODIFIED="1713037119308">
<node TEXT="Input" FOLDED="true" ID="ID_1453755124" CREATED="1713037119309" MODIFIED="1713037119309">
<node TEXT="Life cycle concepts" ID="ID_363177021" CREATED="1713037119310" MODIFIED="1713037119310"/>
<node TEXT="Operator/maintainer training material" ID="ID_336237098" CREATED="1713037119310" MODIFIED="1713037119310"/>
<node TEXT="Final RTVM" ID="ID_1736034229" CREATED="1713037119310" MODIFIED="1713037119310"/>
<node TEXT="Verified system" ID="ID_381406454" CREATED="1713037119310" MODIFIED="1713037119310"/>
<node TEXT="Verification report" ID="ID_479948722" CREATED="1713037119310" MODIFIED="1713037119310"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_899238163" CREATED="1713037119310" MODIFIED="1713037119310">
<node TEXT="Prepare for the transition" ID="ID_795876257" CREATED="1713037119312" MODIFIED="1713037119312"/>
<node TEXT="Perform the transition" ID="ID_1911509381" CREATED="1713037119312" MODIFIED="1713037119312"/>
<node TEXT="Manage results of transition" ID="ID_753253503" CREATED="1713037119312" MODIFIED="1713037119312"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_1239724094" CREATED="1713037119312" MODIFIED="1713037119312">
<node TEXT="• Transition strategy" ID="ID_791082286" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Transition enabling system requirements" ID="ID_247587968" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Transition constraints" ID="ID_1663999817" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Installation procedure" ID="ID_1397407529" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Installed system" ID="ID_1019263205" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Trained operators and maintainers" ID="ID_1840722117" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Transition report" ID="ID_74964878" CREATED="1713037119313" MODIFIED="1713037119313"/>
<node TEXT="• Transition record" ID="ID_1643209201" CREATED="1713037119313" MODIFIED="1713037119313"/>
</node>
</node>
<node TEXT="Validation Process" ID="ID_1256417723" CREATED="1713037119313" MODIFIED="1713037119313">
<node TEXT="Input" FOLDED="true" ID="ID_1645281072" CREATED="1713037119314" MODIFIED="1713037119314">
<node TEXT="Life cycle concepts" ID="ID_1142292460" CREATED="1713037119314" MODIFIED="1713037119314"/>
<node TEXT="Stakeholder requirements" ID="ID_1547397698" CREATED="1713037119314" MODIFIED="1713037119314"/>
<node TEXT="Final RTVM" ID="ID_188346229" CREATED="1713037119314" MODIFIED="1713037119314"/>
<node TEXT="Installed system" ID="ID_872566729" CREATED="1713037119314" MODIFIED="1713037119314"/>
<node TEXT="Transition report" ID="ID_609036066" CREATED="1713037119314" MODIFIED="1713037119314"/>
<node TEXT="Validation criteria" ID="ID_750577325" CREATED="1713037119314" MODIFIED="1713037119314"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1875743652" CREATED="1713037119314" MODIFIED="1713037119314">
<node TEXT="Prepare for the validation" ID="ID_1448706707" CREATED="1713037119315" MODIFIED="1713037119315"/>
<node TEXT="Perform validation" ID="ID_1453635066" CREATED="1713037119315" MODIFIED="1713037119315"/>
<node TEXT="Manage results of validation" ID="ID_385011481" CREATED="1713037119315" MODIFIED="1713037119315"/>
</node>
<node TEXT="Output" ID="ID_472815596" CREATED="1713037119315" MODIFIED="1713037119315">
<node TEXT="• Validation strategy" ID="ID_904226976" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validation enabling system requirements" ID="ID_1526475052" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validation constraints" ID="ID_467728984" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validation procedure" ID="ID_411053378" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validation requirements" ID="ID_293221527" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validated system" ID="ID_1077066778" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validation report" ID="ID_211659639" CREATED="1713037119316" MODIFIED="1713037119316"/>
<node TEXT="• Validation record" ID="ID_456477163" CREATED="1713037119316" MODIFIED="1713037119316"/>
</node>
</node>
<node TEXT="Operation Process" FOLDED="true" ID="ID_1788789719" CREATED="1713037119316" MODIFIED="1713037119316">
<node TEXT="Input" FOLDED="true" ID="ID_294620006" CREATED="1713037119317" MODIFIED="1713037119317">
<node TEXT="Life cycle concepts" ID="ID_344100934" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Operator/maintainer Training materials" ID="ID_1185288946" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Trained operators and maintainers" ID="ID_1654913559" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Validated system" ID="ID_531323650" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Validation report" ID="ID_978411679" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Maintenance report" ID="ID_561650768" CREATED="1713037119318" MODIFIED="1713037119318"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1275686327" CREATED="1713037119318" MODIFIED="1713037119318">
<node TEXT="Prepare for operation" ID="ID_1116160921" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Perform operation" ID="ID_1028212403" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Manage results of operation" ID="ID_1697574899" CREATED="1713037119318" MODIFIED="1713037119318"/>
<node TEXT="Support the customer" ID="ID_877016607" CREATED="1713037119318" MODIFIED="1713037119318"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_1235091833" CREATED="1713037119318" MODIFIED="1713037119318">
<node TEXT="• Operation strategy" ID="ID_86226103" CREATED="1713037119319" MODIFIED="1713037119319"/>
<node TEXT="Operation enabling system requirements" ID="ID_1107726274" CREATED="1713037119319" MODIFIED="1713037119319"/>
<node TEXT="Operation constraints" ID="ID_932503348" CREATED="1713037119319" MODIFIED="1713037119319"/>
<node TEXT="• Operation report" ID="ID_797640732" CREATED="1713037119319" MODIFIED="1713037119319"/>
<node TEXT="• Operation record" ID="ID_1795011228" CREATED="1713037119319" MODIFIED="1713037119319"/>
</node>
</node>
<node TEXT="Disposal Process" FOLDED="true" ID="ID_1800153671" CREATED="1713037119323" MODIFIED="1713037119323">
<node TEXT="Input" FOLDED="true" ID="ID_362542882" CREATED="1713037119324" MODIFIED="1713037119324">
<node TEXT="Life cycle concepts" ID="ID_716732063" CREATED="1713037119325" MODIFIED="1713037119325"/>
<node TEXT="Validated system" ID="ID_1562176685" CREATED="1713037119325" MODIFIED="1713037119325"/>
<node TEXT="Operation report" ID="ID_1649880840" CREATED="1713037119325" MODIFIED="1713037119325"/>
<node TEXT="Maintenance report" ID="ID_1176142638" CREATED="1713037119325" MODIFIED="1713037119325"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_1241858399" CREATED="1713037119325" MODIFIED="1713037119325">
<node TEXT="Prepare for disposal" ID="ID_577373407" CREATED="1713037119326" MODIFIED="1713037119326"/>
<node TEXT="Perform disposal" ID="ID_1340480696" CREATED="1713037119326" MODIFIED="1713037119326"/>
<node TEXT="Finalize the disposal" ID="ID_1942460239" CREATED="1713037119326" MODIFIED="1713037119326"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_1602729383" CREATED="1713037119326" MODIFIED="1713037119326">
<node TEXT="• Disposal strategy" ID="ID_1019012032" CREATED="1713037119327" MODIFIED="1713037119327"/>
<node TEXT="• Disposal enabling system requirements" ID="ID_204367749" CREATED="1713037119327" MODIFIED="1713037119327"/>
<node TEXT="• Disposal constraints" ID="ID_1006136599" CREATED="1713037119327" MODIFIED="1713037119327"/>
<node TEXT="• Disposal procedure" ID="ID_1246954752" CREATED="1713037119327" MODIFIED="1713037119327"/>
<node TEXT="• Disposed system" ID="ID_543317018" CREATED="1713037119327" MODIFIED="1713037119327"/>
<node TEXT="• Disposal report" ID="ID_385244018" CREATED="1713037119327" MODIFIED="1713037119327"/>
<node TEXT="• Disposal record" ID="ID_710507070" CREATED="1713037119327" MODIFIED="1713037119327"/>
</node>
</node>
<node TEXT="Maintenance Process" FOLDED="true" ID="ID_1896996142" CREATED="1713037119319" MODIFIED="1713037119319">
<node TEXT="Input" FOLDED="true" ID="ID_376300007" CREATED="1713037119320" MODIFIED="1713037119320">
<node TEXT="Life cycle concepts" ID="ID_169542738" CREATED="1713037119321" MODIFIED="1713037119321"/>
<node TEXT="Operator/maintainer Training materials" ID="ID_805897718" CREATED="1713037119321" MODIFIED="1713037119321"/>
<node TEXT="Trained operators and maintainers" ID="ID_667656305" CREATED="1713037119321" MODIFIED="1713037119321"/>
<node TEXT="Validated system" ID="ID_746574823" CREATED="1713037119321" MODIFIED="1713037119321"/>
<node TEXT="Validation report" ID="ID_15341324" CREATED="1713037119321" MODIFIED="1713037119321"/>
<node TEXT="Operation report" ID="ID_99923454" CREATED="1713037119321" MODIFIED="1713037119321"/>
</node>
<node TEXT="Process" FOLDED="true" ID="ID_17467751" CREATED="1713037119321" MODIFIED="1713037119321">
<node TEXT="Prepare for maintenance" ID="ID_1635098743" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="Perform maintenance" ID="ID_1718530759" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="Perform logistics support" ID="ID_87199155" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="Manage results of maintenance and logistics" ID="ID_1054614533" CREATED="1713037119323" MODIFIED="1713037119323"/>
</node>
<node TEXT="Output" FOLDED="true" ID="ID_391003225" CREATED="1713037119323" MODIFIED="1713037119323">
<node TEXT="• Maintenance strategy" ID="ID_1041540498" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="• Maintenance enabling system requirements" ID="ID_633363066" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="• Maintenance constraints" ID="ID_1972266730" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="Maintenance procedure" ID="ID_209353150" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="Maintenance report" ID="ID_1403904679" CREATED="1713037119323" MODIFIED="1713037119323"/>
<node TEXT="• Maintenance record" ID="ID_324845280" CREATED="1713037119323" MODIFIED="1713037119323"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Technical Management Processes" FOLDED="true" ID="ID_1431500688" CREATED="1712277618289" MODIFIED="1712782703780">
<node TEXT="project planning" ID="ID_1190483535" CREATED="1712278430697" MODIFIED="1712278437095"/>
<node TEXT="product assessment and control" ID="ID_475100604" CREATED="1712278437109" MODIFIED="1712278440695"/>
<node TEXT="decision management" ID="ID_995574985" CREATED="1712278440709" MODIFIED="1712278443484"/>
<node TEXT="risk management" ID="ID_667131260" CREATED="1712278443494" MODIFIED="1712278445890"/>
<node TEXT="configuration management" ID="ID_688204052" CREATED="1712278445902" MODIFIED="1712278448490"/>
<node TEXT="information management" ID="ID_1106015576" CREATED="1712278448499" MODIFIED="1712278451690"/>
<node TEXT="measurement" ID="ID_420643175" CREATED="1712278451703" MODIFIED="1712278453690"/>
<node TEXT="quality assurance" ID="ID_702020140" CREATED="1712278453705" MODIFIED="1712278456931"/>
</node>
<node TEXT="Agreement Processes" FOLDED="true" ID="ID_343182774" CREATED="1712277618291" MODIFIED="1712782709792">
<node TEXT="acquisition" ID="ID_1062578429" CREATED="1712278458896" MODIFIED="1712278461891"/>
<node TEXT="supply" ID="ID_1576127231" CREATED="1712278461907" MODIFIED="1712278464322"/>
</node>
<node TEXT="Organizational Project-enabling Processes" ID="ID_455042437" CREATED="1712277618291" MODIFIED="1712782709793">
<node TEXT="Lifecycle Model Management" ID="ID_1707549227" CREATED="1712278466291" MODIFIED="1712782709793"/>
<node TEXT="Infrastructure Management" ID="ID_1825760892" CREATED="1712278470717" MODIFIED="1712782709794"/>
<node TEXT="Portfolio Management" ID="ID_1997533747" CREATED="1712278474305" MODIFIED="1712782709794"/>
<node TEXT="Human Resource Management" ID="ID_779603145" CREATED="1712278477709" MODIFIED="1712782709794"/>
<node TEXT="Quality Management" ID="ID_1276179655" CREATED="1712278480925" MODIFIED="1712782709794"/>
<node TEXT="Knowledge Management" ID="ID_257464779" CREATED="1712278483704" MODIFIED="1712782709794"/>
</node>
</node>
</node>
<node TEXT="" FOLDED="true" ID="ID_1381010968" CREATED="1712768594707" MODIFIED="1712768594707">
<node TEXT="system architecture development activity" FOLDED="true" ID="ID_800038840" CREATED="1712278388488" MODIFIED="1712278393192">
<node TEXT="drives a generic system architecture modeling workflow to facilitate consistent and, at times, agile system modeling" ID="ID_48515516" CREATED="1712286590727" MODIFIED="1712286626945"/>
<node TEXT="generic workflow (shown in this figure) complies with the ISO 15288 standard [*]." FOLDED="true" ID="ID_1379666821" CREATED="1712286648129" MODIFIED="1712286667545">
<node TEXT="png_14272544993232901319.png" ID="ID_1449743133" CREATED="1712286682980" MODIFIED="1712286682980">
<hook URI="LifeMgmt_files/png_14272544993232901319.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
<node TEXT="goes for most abstract at the top to the least abstract at the bottom" ID="ID_76131336" CREATED="1712286899183" MODIFIED="1712286914144"/>
<node TEXT="Operational Analysis" ID="ID_641452437" CREATED="1712286930653" MODIFIED="1712286935303"/>
<node TEXT="System Requirements Analysis" ID="ID_1869428975" CREATED="1712286935313" MODIFIED="1712286939107"/>
<node TEXT="Logical Architecture Definition" ID="ID_1565863691" CREATED="1712286939120" MODIFIED="1712286942707"/>
<node TEXT="Physical Architecture Definition" FOLDED="true" ID="ID_1784018124" CREATED="1712286942721" MODIFIED="1712286947312">
<node TEXT="most straightforward to define" ID="ID_64027355" CREATED="1712286947914" MODIFIED="1712286952959"/>
</node>
</node>
</node>
</node>
<node TEXT="Determined by decisions at several points in the early stages of the development process:" FOLDED="true" ID="ID_775863852" CREATED="1712275320261" MODIFIED="1712275808816">
<node TEXT="Planning: where a platform decision is made" ID="ID_1925527969" CREATED="1712275320264" MODIFIED="1712275812224"/>
<node TEXT="Concept development: where a concept is decided upon" ID="ID_1449745751" CREATED="1712275320265" MODIFIED="1712275812224"/>
<node TEXT="System level design: where decomposition decision is made" ID="ID_340454524" CREATED="1712275320265" MODIFIED="1712275812225"/>
<node TEXT="Detail design" ID="ID_1249781409" CREATED="1712275320266" MODIFIED="1712275812225"/>
<node TEXT="Testing and refinement" ID="ID_1603895141" CREATED="1712275682453" MODIFIED="1712275812225"/>
<node TEXT="Production ramp-up" ID="ID_390705184" CREATED="1712275698655" MODIFIED="1712275812225"/>
</node>
<node TEXT="workflow" FOLDED="true" ID="ID_1609204217" CREATED="1712287487341" MODIFIED="1712287502717">
<node TEXT="Functional analysis" ID="ID_1228120953" CREATED="1712287502719" MODIFIED="1712287664122"/>
<node TEXT="Concept generation" ID="ID_147861266" CREATED="1712287515520" MODIFIED="1712287664123"/>
<node TEXT="System architecture" ID="ID_1457283502" CREATED="1712287515538" MODIFIED="1712287664123"/>
</node>
</node>
<node TEXT="Form" FOLDED="true" ID="ID_802077665" CREATED="1712288006182" MODIFIED="1712288905131">
<font BOLD="true"/>
<node TEXT="describes what the system is" FOLDED="true" ID="ID_1248466532" CREATED="1712288369420" MODIFIED="1712288373722">
<node TEXT="contrasted to the function, which describes what a system does" ID="ID_1793524169" CREATED="1712288375420" MODIFIED="1712288393256"/>
</node>
<node TEXT="The form is the physical embodiment of a design which executes the function, composed of:" FOLDED="true" ID="ID_973042813" CREATED="1712288010955" MODIFIED="1712288410950">
<node TEXT="Objects" ID="ID_1161499083" CREATED="1712288222318" MODIFIED="1712288226375"/>
<node TEXT="Structure" ID="ID_826649566" CREATED="1712288226700" MODIFIED="1712288229392"/>
<node TEXT="For a system, the form can be defined as the composition of all the parts, consisting of both the objects and structure of the parts as shown in this figure" ID="ID_1398439888" CREATED="1712288010956" MODIFIED="1712288010956"/>
</node>
<node TEXT="There are two aspects of form" FOLDED="true" ID="ID_221908461" CREATED="1712288010957" MODIFIED="1712288010957">
<node TEXT="Decomposition" FOLDED="true" ID="ID_1448704012" CREATED="1712288152806" MODIFIED="1712288891725">
<font BOLD="true"/>
<node TEXT="Form decomposition is the breaking of the system into subsystems and components" ID="ID_1383155886" CREATED="1712288010958" MODIFIED="1712288010958"/>
<node TEXT="This figure shows three-level hierarchical decomposition of a system" FOLDED="true" ID="ID_1557031274" CREATED="1712288010958" MODIFIED="1712288010958">
<node TEXT="png_8422022508111454261.png" ID="ID_597576997" CREATED="1712288505387" MODIFIED="1712288505387">
<hook URI="LifeMgmt_files/png_8422022508111454261.png" SIZE="0.5449591" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Example" FOLDED="true" ID="ID_489511827" CREATED="1712289468524" MODIFIED="1712289472146">
<node TEXT="png_968245053361144371.png" ID="ID_1785580002" CREATED="1712289476371" MODIFIED="1712289476371">
<hook URI="LifeMgmt_files/png_968245053361144371.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Structure" FOLDED="true" ID="ID_859439165" CREATED="1712288162317" MODIFIED="1712288886351">
<font BOLD="true"/>
<node TEXT="Form structure is where structure represents the connections between, as well as the spatial arrangement of the different subsystems" ID="ID_1739333350" CREATED="1712288010960" MODIFIED="1712288010960"/>
<node TEXT="More specifically, it models the following aspects, connectivity, sequence, location/proximity, and arrangement" ID="ID_380404064" CREATED="1712288010960" MODIFIED="1712288010960"/>
<node TEXT="This figure shows connections between subsystems in a three-level hierarchical decomposition of a system" FOLDED="true" ID="ID_1310791712" CREATED="1712288010961" MODIFIED="1712288010961">
<node TEXT="png_1737530281302880512.png" ID="ID_407410084" CREATED="1712288554372" MODIFIED="1712288554372">
<hook URI="LifeMgmt_files/png_1737530281302880512.png" SIZE="0.5714286" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Example" FOLDED="true" ID="ID_123343505" CREATED="1712289498349" MODIFIED="1712289500349">
<node TEXT="png_8626799676072898818.png" ID="ID_332811376" CREATED="1712289505768" MODIFIED="1712289505768">
<hook URI="LifeMgmt_files/png_8626799676072898818.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
</node>
</node>
<node TEXT="Example reference" FOLDED="true" ID="ID_820028193" CREATED="1712289316603" MODIFIED="1712289515125">
<node ID="ID_115199909" CREATED="1712289332161" MODIFIED="1712289332161" LINK="https://www.coursera.org/learn/introduction-mbse/supplement/YactA/another-example-of-decomposition-and-structure-the-electric-skateboard"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/supplement/YactA/another-example-of-decomposition-and-structure-the-electric-skateboard">Another Example of Decomposition and Structure: The Electric Skateboard | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Let&apos;s apply decomposition to the case of a coffee machine" FOLDED="true" ID="ID_545870048" CREATED="1712288010963" MODIFIED="1712288010963">
<node TEXT="How many levels does this decomposition of the coffee machine have? Here&apos;s an example of form structure diagram of the coffee machine" FOLDED="true" ID="ID_488642613" CREATED="1712288010964" MODIFIED="1712288010964">
<node TEXT="When considering the structure, we look for connections that define or express" FOLDED="true" ID="ID_1746039672" CREATED="1712288010966" MODIFIED="1712288010966">
<node TEXT="First, the flow of material, energy, and signal or information" FOLDED="true" ID="ID_397880431" CREATED="1712288010971" MODIFIED="1712288010971">
<node TEXT="For example, signal from control board, which is part of the subsystem, to the heating element, which is part of the heating subsystem" ID="ID_1502166643" CREATED="1712288010972" MODIFIED="1712288010972"/>
</node>
<node TEXT="Another example is the material flowing from the filter holder to the coffee pot" ID="ID_1988483703" CREATED="1712288010973" MODIFIED="1712288010973"/>
<node TEXT="Second, connectivity, location, or proximity" FOLDED="true" ID="ID_534505564" CREATED="1712288010974" MODIFIED="1712288010974">
<node TEXT="For example, there is a proximity relationship between the heating element, and which is part of the heating subsystem, and the sensor which is part of the same subsystem" ID="ID_1936109872" CREATED="1712288010974" MODIFIED="1712288010974"/>
</node>
</node>
</node>
<node TEXT="The form structure can also be represented using DSM (Design Structure Matrix)" FOLDED="true" ID="ID_1709254756" CREATED="1712288010975" MODIFIED="1712288768353">
<node TEXT="simple representation of the various system elements and their interrelationships in the form of a square matrix" ID="ID_789401244" CREATED="1712288010976" MODIFIED="1712288790350"/>
<node TEXT="This table shows the DSM for the electric coffee machine" FOLDED="true" ID="ID_204062716" CREATED="1712288010977" MODIFIED="1712288010977">
<node TEXT="png_8032028824984333230.png" ID="ID_746891173" CREATED="1712288721372" MODIFIED="1712288721372">
<hook URI="LifeMgmt_files/png_8032028824984333230.png" SIZE="0.5352364" NAME="ExternalObject"/>
</node>
<node TEXT="Notice the objects on the leftmost column and the parts of the coffee machine on the top row" ID="ID_356999995" CREATED="1712288010979" MODIFIED="1712288010979"/>
<node TEXT="For example, the water tank either connects to or as close to the spray mechanism" ID="ID_714928115" CREATED="1712288010979" MODIFIED="1712288010979"/>
<node TEXT="The heating element is controlled by the control board" ID="ID_1443170014" CREATED="1712288010981" MODIFIED="1712288010981"/>
</node>
</node>
</node>
</node>
<node TEXT="OPM Analytical Representation of a Function" FOLDED="true" ID="ID_21738824" CREATED="1712289638717" MODIFIED="1712289688752">
<node TEXT="elements" FOLDED="true" ID="ID_1970671314" CREATED="1712290695144" MODIFIED="1712290697541">
<node TEXT="process" FOLDED="true" ID="ID_1793910484" CREATED="1712290698725" MODIFIED="1712290701233">
<node TEXT="represented by process name inside of an oval symbol" ID="ID_1526681080" CREATED="1712290734080" MODIFIED="1712290751947"/>
</node>
<node TEXT="Operand" FOLDED="true" ID="ID_1508026761" CREATED="1712290757684" MODIFIED="1712290760792">
<node TEXT="represented as a label indicating the name of the operand inside a rectangular symbol" ID="ID_1320388465" CREATED="1712290762848" MODIFIED="1712290784334"/>
</node>
</node>
<node TEXT="types of relationships between operand and process (3)" FOLDED="true" ID="ID_239307664" CREATED="1712290810079" MODIFIED="1712290876591">
<node TEXT="Namely process creating a new operant process, consuming and existing operant process causing some changes to an existing operant" ID="ID_610121118" CREATED="1712290580767" MODIFIED="1712290580767"/>
</node>
<node TEXT="process for creating a new operand" FOLDED="true" ID="ID_1067970463" CREATED="1712290580768" MODIFIED="1712291041770">
<node TEXT="represented by single-headed arrow pointing from the process to the operand" ID="ID_1433880419" CREATED="1712290992526" MODIFIED="1712291037945"/>
<node TEXT="Using the example of the electric coffee machine, the brew or process creates the operand or coffee, in this case" FOLDED="true" ID="ID_308437818" CREATED="1712290580771" MODIFIED="1712290580771">
<node TEXT="In other words, the process of brewing has created the opera and coffee" ID="ID_1723795888" CREATED="1712290580772" MODIFIED="1712290580772"/>
<node TEXT="In fact, prior to brewing, there was no coffee" ID="ID_255853492" CREATED="1712290580773" MODIFIED="1712290580773"/>
</node>
</node>
<node TEXT="process of consuming an existing operand" FOLDED="true" ID="ID_304875874" CREATED="1712290580774" MODIFIED="1712290919939">
<node TEXT="represented by a single-headed arrow pointing from the operand to the process" ID="ID_754260566" CREATED="1712290580774" MODIFIED="1712291110721"/>
<node TEXT="In this case, the process is to assemble and the operand is auto parts" ID="ID_593904634" CREATED="1712290580775" MODIFIED="1712290580775"/>
<node TEXT="In other words, the process of assembling has consumed the operand auto parts" ID="ID_1756074007" CREATED="1712290580776" MODIFIED="1712290580776"/>
<node TEXT="In fact, after assembling, there are no more auto parts" ID="ID_25426470" CREATED="1712290580776" MODIFIED="1712290580776"/>
<node TEXT="The latter has turned into a new object, namely a vehicle" ID="ID_11356688" CREATED="1712290580777" MODIFIED="1712290580777"/>
</node>
<node TEXT="process affects the operand" FOLDED="true" ID="ID_1081667346" CREATED="1712290952916" MODIFIED="1712290955533">
<node TEXT="When a double-headed arrow is between the operand to the process," ID="ID_324915625" CREATED="1712290580777" MODIFIED="1712290949553"/>
<node TEXT="We&apos;re looking at an example of paint as the process and the car is the operand" FOLDED="true" ID="ID_776908783" CREATED="1712290580779" MODIFIED="1712290580779">
<node TEXT="The process of painting has affected the operand car by changing its color" ID="ID_1073121258" CREATED="1712290580779" MODIFIED="1712290580779"/>
<node TEXT="In fact, the process has changed one of the attributes of the operant, which is color, the original operand still exists, but in a modified way" ID="ID_1535002616" CREATED="1712290580780" MODIFIED="1712290580780"/>
</node>
</node>
<node TEXT="Now let us define primary function and externally delivered function" ID="ID_365078021" CREATED="1712290580780" MODIFIED="1712290580780"/>
<node TEXT="Externally delivered function is function that crosses the boundary of the system and influences something in the context" ID="ID_840028239" CREATED="1712290580781" MODIFIED="1712290580781"/>
<node TEXT="Primary function is the function for which the system is built, for example, the primary function of the coffee maker is brewing" ID="ID_1213208072" CREATED="1712290580781" MODIFIED="1712290580781"/>
<node TEXT="Coffee" ID="ID_73426520" CREATED="1712290580782" MODIFIED="1712290580782"/>
<node TEXT="Brewing is the value related process, and coffee is the value unrelated operand" ID="ID_737983390" CREATED="1712290580783" MODIFIED="1712290580783"/>
<node TEXT="Let&apos;s give you another example using the water heater" ID="ID_1546939169" CREATED="1712290580783" MODIFIED="1712290580783"/>
<node TEXT="The primary function of the water heater is heating water" ID="ID_1607233262" CREATED="1712290580784" MODIFIED="1712290580784"/>
<node TEXT="Heating is the value related process, and water is the value related operand" ID="ID_1789279765" CREATED="1712290580785" MODIFIED="1712290580785"/>
<node TEXT="Relevant to the value related function is the attribute whose change is associated with value" ID="ID_528305694" CREATED="1712290580785" MODIFIED="1712290580785"/>
<node TEXT="In this case, the attribute is temperature" ID="ID_374439845" CREATED="1712290580788" MODIFIED="1712290580788"/>
<node TEXT="In addition to the external function, a system involves internal functions" ID="ID_51304115" CREATED="1712290580790" MODIFIED="1712290580790"/>
<node TEXT="These functions and the relationships amongst them define the functional architecture of the system" ID="ID_1444890244" CREATED="1712290580790" MODIFIED="1712290580790"/>
<node TEXT="The external function emerges as a result of the internal functions and their relationships" ID="ID_1025576953" CREATED="1712290580791" MODIFIED="1712290580791"/>
<node TEXT="Identification of internal functions" ID="ID_1209162740" CREATED="1712290580791" MODIFIED="1712290580791"/>
<node TEXT="There&apos;s a variety of techniques to extract or identify the internal functions of a system, for example, reverse engineering of the form" ID="ID_1663114458" CREATED="1712290580792" MODIFIED="1712290580792"/>
<node TEXT="Reverse engineering of the forum to extract the internal functions" ID="ID_58766475" CREATED="1712290580792" MODIFIED="1712290580792"/>
<node TEXT="The basic idea is to start with the elements of form and reverse engineer that are corresponding functions" ID="ID_1012888988" CREATED="1712290580794" MODIFIED="1712290580794"/>
<node TEXT="reference" FOLDED="true" ID="ID_845000340" CREATED="1712289689951" MODIFIED="1712289691931">
<node ID="ID_164087736" CREATED="1712289695729" MODIFIED="1712289695729" LINK="https://www.coursera.org/learn/introduction-mbse/lecture/1w4eB/opm-analytical-representation-of-a-function"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.coursera.org/learn/introduction-mbse/lecture/1w4eB/opm-analytical-representation-of-a-function">OPM Analytical Representation of a Function | Coursera</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="Systems Engineering" FOLDED="true" ID="ID_1656163348" CREATED="1712616339021" MODIFIED="1712616350033">
<node TEXT="reference" FOLDED="true" ID="ID_1783954272" CREATED="1712956693282" MODIFIED="1712956695707">
<node ID="ID_494664230" CREATED="1712956696693" MODIFIED="1712956745653" LINK="https://www.sebokwiki.org/wiki/Stakeholder_Needs_and_Requirements"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Elm, J. P. (n.d.). Stakeholder Needs and Requirements - SEBoK. SEBoK - Guide to the Systems Engineering Body of Knowledge. Retrieved March 22, 2023, from <a target="_blank" rel="noopener nofollow noreferrer" href="https://www.sebokwiki.org/wiki/Stakeholder_Needs_and_Requirements" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>https://www.sebokwiki.org/wiki/Stakeholder_Needs_and_Requirements</u></font></a></span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_1653174916" CREATED="1712956696694" MODIFIED="1712956745657"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>INCOSE Systems Engineering Handbook Version 4: Updating the Reference for Practitioners. (2015, October). In INCOSE International Symposium (Vol. 25, No. 1, pp. 678-686).</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_1293926043" CREATED="1712956696695" MODIFIED="1712956745659" LINK="https://www.sebokwiki.org/wiki/Guide_to_the_Systems_Engineering_Body_of_Knowledge_(SEBoK)"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Sebokwiki.org. (n.d.). Guide to the Systems Engineering Body of Knowledge (SEBoK). Retrieved March 22, 2023, from <a target="_blank" rel="noopener nofollow noreferrer" href="https://www.sebokwiki.org/wiki/Guide_to_the_Systems_Engineering_Body_of_Knowledge_(SEBoK)" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>https://www.sebokwiki.org/wiki/Guide_to_the_Systems_Engineering_Body_of_Knowledge_(SEBoK)</u></font></a></span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_1285843960" CREATED="1712956696696" MODIFIED="1712956745663" LINK="https://www.sebokwiki.org/wiki/System_Life_Cycle_Process_Models:_Vee"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Sebokwiki.org. (n.d.). System Life Cycle Process Models: Vee. Retrieved March 22, 2023, from <a target="_blank" rel="noopener nofollow noreferrer" href="https://www.sebokwiki.org/wiki/System_Life_Cycle_Process_Models:_Vee" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>https://www.sebokwiki.org/wiki/System_Life_Cycle_Process_Models:_Vee</u></font></a></span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_603399696" CREATED="1712956696697" MODIFIED="1712956745665" LINK="https://new.siemens.com/global/en/company/about.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Siemens AG. (2018). Retrieved from <a target="_blank" rel="noopener nofollow noreferrer" href="https://new.siemens.com/global/en/company/about.html" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>https://new.siemens.com/global/en/company/about.html</u></font></a></span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_1831547725" CREATED="1712956696698" MODIFIED="1712956745666" LINK="https://www.plm.automation.siemens.com/global/en/who-we-are/about-plm.html"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Siemens PLM Software. (2012). Retrieved from <a target="_blank" rel="noopener nofollow noreferrer" href="https://www.plm.automation.siemens.com/global/en/who-we-are/about-plm.html" class="css-gcjbqe" style="background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null; color: black; text-decoration: underline; display: inline-flex"><font color="black"><u>https://www.plm.automation.siemens.com/global/en/who-we-are/about-plm.html</u></font></a></span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_665816444" CREATED="1712956696698" MODIFIED="1712956745668"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Toksoy, J. (n.d.). ME 49700. </span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
<node ID="ID_1275882723" CREATED="1712956696699" MODIFIED="1712956745669"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Walden, D. D., Roedler, G. J., &amp; Forsberg, K. (2015, October). INCOSE Systems Engineering Handbook Version 4: Updating the Reference for Practitioners. In INCOSE International Symposium (Vol. 25, No. 1, pp. 678-686).</span>
        </p>
      </li>
    </ul>
  </body>
</html>

</richcontent>
<font SIZE="12"/>
</node>
</node>
<node TEXT="definition (2)" FOLDED="true" ID="ID_521543872" CREATED="1712616487265" MODIFIED="1712616671861">
<node TEXT="integrates all the disciplines and specialty groups into a team effort forming a structured development process that proceeds from concept to disposal" FOLDED="true" ID="ID_525060277" CREATED="1712616472315" MODIFIED="1712616486261">
<node TEXT="Systems engineering considers both the business and the technical needs of all customers with the goal of providing a quality product that meets the users&apos; needs" ID="ID_1298063982" CREATED="1712616472315" MODIFIED="1712616472315"/>
</node>
<node TEXT="Another definition of systems engineering is illustrated in this figure" FOLDED="true" ID="ID_434955747" CREATED="1712616472319" MODIFIED="1712616472319">
<node TEXT="png_6226286001575151020.png" ID="ID_1990093414" CREATED="1712616590511" MODIFIED="1712616590511">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_6226286001575151020.png" SIZE="0.5714286" NAME="ExternalObject"/>
</node>
<node TEXT="Systems engineering is an approach to the life cycle that considers the complete problem at all times" FOLDED="true" ID="ID_1236316607" CREATED="1712616472321" MODIFIED="1712616472321">
<node TEXT="More specifically, it is an interdisciplinary approach enabling the realization of successful systems" ID="ID_782066826" CREATED="1712616472323" MODIFIED="1712616472323"/>
<node TEXT="It focuses on defining customer needs and required functionality early in the development cycle, documenting requirements, then proceeding with design synthesis and system validation while considering the complete problem" ID="ID_121930924" CREATED="1712616472324" MODIFIED="1712616472324"/>
</node>
</node>
</node>
<node TEXT="Why do we need systems engineering?" ID="ID_389777082" CREATED="1712616472325" MODIFIED="1712616472325">
<node TEXT="to ensure the development of the &quot;right&quot; (complex) system, competitively" ID="ID_1112495332" CREATED="1712616472328" MODIFIED="1712616767452"/>
<node TEXT="Examples of situations we try to avoid by using systems engineering include," ID="ID_20667159" CREATED="1712616472329" MODIFIED="1712616783667">
<node TEXT="Systems Failing FDA Approval which leads to companies losing against competition, missing targets, etc" ID="ID_1861661989" CREATED="1712616783674" MODIFIED="1712616783686"/>
<node TEXT="Systems Failing an Operation, which leads to companies losing their reputation, risking lives, etc" ID="ID_1636257071" CREATED="1712616472330" MODIFIED="1712616795630"/>
<node TEXT="examples" FOLDED="true" ID="ID_1716926874" CREATED="1712616820453" MODIFIED="1712616822656">
<node TEXT="The NASA Space Shuttle challenger exploded in 1986, 90 seconds after takeoff" ID="ID_872885595" CREATED="1712616472333" MODIFIED="1712616472333"/>
<node TEXT="Here, we can see two other examples that provide rationale for the importance of the systems engineering process" ID="ID_1421069520" CREATED="1712616472333" MODIFIED="1712616472333"/>
<node TEXT="On the left, we can see the wreck of the Kursk submarine which represents the greatest disaster experienced by the Russian Navy in 2000 and caused the death of 118 crewmen" ID="ID_1112919722" CREATED="1712616472336" MODIFIED="1712616472336"/>
<node TEXT="A leak of hydrogen peroxide led to the explosion of the ship&apos;s ammunition" ID="ID_1015255230" CREATED="1712616472336" MODIFIED="1712616472336"/>
<node TEXT="You can access this week&apos;s references page with hyperlinked references to find out why the successful implementation of systems engineering could have prevented this tragic event" ID="ID_33391395" CREATED="1712616472337" MODIFIED="1712616472337"/>
<node TEXT="On the right, we can see the wreck of the Tacoma Narrows suspension Bridge constructed in 1938 which collapsed on November 7th, 1940" ID="ID_1764643302" CREATED="1712616472338" MODIFIED="1712616472338"/>
</node>
</node>
</node>
<node TEXT="Purpose Of Systems Engineering" ID="ID_1156646938" CREATED="1712616911422" MODIFIED="1712616917260">
<node TEXT="Managing complexity" ID="ID_1291190923" CREATED="1712616472342" MODIFIED="1712617044274"/>
<node TEXT="Managing uncertainty in an orderly manner" ID="ID_1936072932" CREATED="1712616472343" MODIFIED="1712617044274"/>
<node TEXT="Reducing risk, specifically of not meeting stakeholders needs or program objectives" ID="ID_1803372932" CREATED="1712616472344" MODIFIED="1712617044274"/>
</node>
<node TEXT="Sources Of Complexity" ID="ID_670971533" CREATED="1712616472345" MODIFIED="1712616978648">
<node TEXT="User Needs Change" ID="ID_1654977724" CREATED="1712616988451" MODIFIED="1712616992652"/>
<node TEXT="Political And Economic Changes" ID="ID_1973918075" CREATED="1712617002233" MODIFIED="1712617006023"/>
<node TEXT="Technology And Market Changes" ID="ID_1179520208" CREATED="1712617006037" MODIFIED="1712617010459"/>
</node>
<node TEXT="Systems Engineering Focus" FOLDED="true" ID="ID_1972941562" CREATED="1712617116636" MODIFIED="1712617122262">
<node TEXT="diagram" ID="ID_1814004838" CREATED="1712617197429" MODIFIED="1712617200061">
<node TEXT="png_13820860944144610340.png" ID="ID_55659545" CREATED="1712617209512" MODIFIED="1712617209512">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_13820860944144610340.png" SIZE="0.6734007" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="First, emphasis on the early part of the development cycle" ID="ID_232006265" CREATED="1712616472348" MODIFIED="1712616472348"/>
<node TEXT="Second, the definition of stakeholder needs and required functionality" ID="ID_1116015186" CREATED="1712616472349" MODIFIED="1712616472349"/>
<node TEXT="Third, the documentation of systems requirements and managing traceability to stakeholder needs" ID="ID_1005958972" CREATED="1712616472350" MODIFIED="1712616472350"/>
<node TEXT="Forth, the consideration of the complete problem and life cycle within the context of scope, risk and cost and schedule" ID="ID_423551874" CREATED="1712616472351" MODIFIED="1712616472351"/>
</node>
<node TEXT="System Lifecycle Stages" ID="ID_468356038" CREATED="1712617284255" MODIFIED="1712617524460">
<node TEXT="The system life cycle consists of a series of stages through which something passes during its lifetime" FOLDED="true" ID="ID_571311013" CREATED="1712616472353" MODIFIED="1712616472353">
<node TEXT="It is the process of maturation from conception through death" ID="ID_328828064" CREATED="1712616472355" MODIFIED="1712616472355"/>
</node>
<node TEXT="A life cycle model identifies the major stages that a system or product goes through from its inception to its retirement" ID="ID_755231450" CREATED="1712616472356" MODIFIED="1712616472356">
<node TEXT="diagram" ID="ID_1885999989" CREATED="1712617332433" MODIFIED="1712617335060">
<node TEXT="System Lifecycle Stages.png" ID="ID_57378363" CREATED="1712617407714" MODIFIED="1712617407714">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/System%20Lifecycle%20Stages.png" SIZE="0.47885075" NAME="ExternalObject"/>
</node>
</node>
<node TEXT="Evaluate the progress and effectiveness of evolving system products and processes and measure specification compliance" ID="ID_1413197104" CREATED="1712616472356" MODIFIED="1712617458458"/>
<node TEXT="Deliver, install and operate the system to achieve full operational capability" ID="ID_1832288112" CREATED="1712616472357" MODIFIED="1712617461026"/>
<node TEXT="Then, provide services and training that are required to assist the customer or user in the operation of the system" ID="ID_1637302049" CREATED="1712616472358" MODIFIED="1712616472358"/>
<node TEXT="Next, achieve and maintain skill levels to perform operations" ID="ID_1233738123" CREATED="1712616472358" MODIFIED="1712616472358"/>
<node TEXT="And finally, dispose of decommissioned, destroyed or irreparable system components" ID="ID_1305982379" CREATED="1712616472359" MODIFIED="1712616472359"/>
</node>
<node TEXT="Example Of Systems Engineering Implementation" FOLDED="true" ID="ID_1201814219" CREATED="1712617723380" MODIFIED="1712617737459">
<node TEXT="Lifecycle Stages and an Example of Systems Engineering Implementation" FOLDED="true" ID="ID_83780295" CREATED="1712617738517" MODIFIED="1712767844346">
<node FOLDED="true" ID="ID_540336347" CREATED="1712617738518" MODIFIED="1712617738518"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>In this lesson, we will look at the lifecycle stages and SE implementation, following the V-Model.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="png_2435021187656521943.png" ID="ID_901646854" CREATED="1712620552292" MODIFIED="1712620552292">
<hook URI="MBSE(Model-BasedSystemEngineering)_files/png_2435021187656521943.png" SIZE="0.375" NAME="ExternalObject"/>
</node>
</node>
<node ID="ID_936042723" CREATED="1712617738520" MODIFIED="1712617738520"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>In the figure below, we see the lifecycle stages as well as Systems Engineering process implementation following the V-model for a typical Aircraft industry.</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
<node FOLDED="true" ID="ID_198926482" CREATED="1712617738521" MODIFIED="1712617738521"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>[*] Siemens PLM Software 2012</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1089656784" CREATED="1712617738523" MODIFIED="1712617738523" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/UkcZHkUQQOKsdcDr14_PuA_9ead7e82f97e45feb555630f2985d1f1_0T8xHUj1dWN3O6kF5ZSWG9EyDmjpDem4zJyUP9baOYNqtK4K-FdZXXiaMl7__1KzD5eDPvSUaoDmpeJmqfkvf8-f-xBal6wUxoW3lJKtPqGI09ME6M6kjXhSv_PDhNMrIhHN2eNe5jX9wBmN7Zg1r6ylSx4wMs_KBHjqHVEcdvZdnCtCKep-orzeGnC70g?expiry=1712707200000&amp;hmac=_stOcTkZhlmGjGZ5z1IMcfpsk8ZxyAgwi2n9YvvEFuE"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <div>
                    <img src="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/UkcZHkUQQOKsdcDr14_PuA_9ead7e82f97e45feb555630f2985d1f1_0T8xHUj1dWN3O6kF5ZSWG9EyDmjpDem4zJyUP9baOYNqtK4K-FdZXXiaMl7__1KzD5eDPvSUaoDmpeJmqfkvf8-f-xBal6wUxoW3lJKtPqGI09ME6M6kjXhSv_PDhNMrIhHN2eNe5jX9wBmN7Zg1r6ylSx4wMs_KBHjqHVEcdvZdnCtCKep-orzeGnC70g?expiry=1712707200000&amp;hmac=_stOcTkZhlmGjGZ5z1IMcfpsk8ZxyAgwi2n9YvvEFuE" alt="" data-asset-id="UkcZHkUQQOKsdcDr14_PuA" class="cml-image-default undefined" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px"/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_414144473" CREATED="1712617738524" MODIFIED="1712617738524"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Another example of implementing the SE process following the V-model is shown below. This implementation by Siemens is meant for In-vehicle software development. We can notice the following:</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_41562245" CREATED="1712617738525" MODIFIED="1712617738525"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>First, this implementation is Model-based, i.e. using the MBSE approach</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_1124874534" CREATED="1712617738526" MODIFIED="1712617738526"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <ul style="margin-bottom: 10px; margin-top: 0px; font-size: var(--cds-font-size-body1); list-style-type: disc; letter-spacing: 0px; line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); font-weight: normal; padding-left: 0; margin-left: 0px">
      <li style="margin-bottom: 0; padding-left: 0">
        <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
          <span>Second, the V-diagram emphasizes the multi-domain nature of the models involved in this MBSE approach. The three main domains are Mechanica, Electrical, and Software.</span>
        </p>
      </li>
    </ul>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_395786008" CREATED="1712617738528" MODIFIED="1712617738528" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/wVbLg3h7ShehlSQXAP2FXQ_200d9c417dae403ab04b1871690b0cf1_fHzdVyROJntFyEuXl0Obv8fB8MZKnTOBFWL6BKlobd27vigiKbmGdyR0d4sWQAeeFw36hAmBGXPYrvMCL8HDNp_HYD6go1O0C1ZocEjudwlK-vx76uqmpCFPt64h0FqVuI0qlnFU8NXLq29UOEeDlEZbg91k1C-e98Ot9aYkRqpS0aMeYy1jIM3Z1Tl1tQ?expiry=1712707200000&amp;hmac=7gVIFFFpzGQzPUDdAOu93UteJ50Qi48j5NmcnobF740"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <div>
                    <img src="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/wVbLg3h7ShehlSQXAP2FXQ_200d9c417dae403ab04b1871690b0cf1_fHzdVyROJntFyEuXl0Obv8fB8MZKnTOBFWL6BKlobd27vigiKbmGdyR0d4sWQAeeFw36hAmBGXPYrvMCL8HDNp_HYD6go1O0C1ZocEjudwlK-vx76uqmpCFPt64h0FqVuI0qlnFU8NXLq29UOEeDlEZbg91k1C-e98Ot9aYkRqpS0aMeYy1jIM3Z1Tl1tQ?expiry=1712707200000&amp;hmac=7gVIFFFpzGQzPUDdAOu93UteJ50Qi48j5NmcnobF740" alt="" data-asset-id="wVbLg3h7ShehlSQXAP2FXQ" class="cml-image-default undefined" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px"/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
<node ID="ID_770779121" CREATED="1712617738530" MODIFIED="1712617738530"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <p data-text-variant="body1" style="font-size: var(--cds-font-size-body1); line-height: var(--cds-line-height-body1); font-family: var(--cds-font-family-source-sans-pro); margin-top: 0px; margin-bottom: 0; margin-right: 0px; margin-left: 0px; letter-spacing: 0px; font-weight: normal">
                    <span>Another example of SE process implementation is shown below. The implementation by Volvo company emphasizes the multi-domain nature of the models created and verified as part of MBSE</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node ID="ID_1416462272" CREATED="1712617738532" MODIFIED="1712617738532" LINK="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/WOZnCABRQUihLgTg84tpdg_8f232c37ff9a43b4b6715cbade8061f1_RSthJOjcWbza73n72Ju74oP6w5RpYKCvQW2UWfjGFnZklZ09Zq-7VuO6qoDdDvzA67vKbjApyxtKgnU4tyFQ8tdDizDCz9GSaGhSGNDtvy_j9RNso7gSYV29sOZQlbLrAqf1X1xLChXn4vUSCJ2Qr9sxcGueoDaa1mNv1n0yUCL0Din7JIBa95Z6LcFkng?expiry=1712707200000&amp;hmac=RwjXbYtlTychIvu5sydGTjFU9hhXaMRuOwP7eKH9Tj4"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <div class="css-jgflq0" style="margin-bottom: 0">
      <div>
        <div class="rc-CML" dir="auto">
          <div>
            <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml" role="presentation">
              <div data-track="true" data-track-app="open_course_home" data-track-page="reading_item" data-track-action="click" data-track-component="cml_link">
                <div data-testid="cml-viewer" class="css-1kgqbsw" style="white-space: pre-wrap">
                  <div>
                    <img src="https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/WOZnCABRQUihLgTg84tpdg_8f232c37ff9a43b4b6715cbade8061f1_RSthJOjcWbza73n72Ju74oP6w5RpYKCvQW2UWfjGFnZklZ09Zq-7VuO6qoDdDvzA67vKbjApyxtKgnU4tyFQ8tdDizDCz9GSaGhSGNDtvy_j9RNso7gSYV29sOZQlbLrAqf1X1xLChXn4vUSCJ2Qr9sxcGueoDaa1mNv1n0yUCL0Din7JIBa95Z6LcFkng?expiry=1712707200000&amp;hmac=RwjXbYtlTychIvu5sydGTjFU9hhXaMRuOwP7eKH9Tj4" alt="" data-asset-id="WOZnCABRQUihLgTg84tpdg" class="cml-image-default undefined" style="border-top-style: none; border-top-width: 0px; border-right-style: none; border-right-width: 0px; border-bottom-style: none; border-bottom-width: 0px; border-left-style: none; border-left-width: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0; margin-left: 0px"/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Integrated MBSE" ID="ID_862340231" CREATED="1713074562114" MODIFIED="1713074575765">
<node TEXT="Intro" ID="ID_968659097" CREATED="1713074581354" MODIFIED="1713074583770"/>
<node TEXT="Why" ID="ID_1173053780" CREATED="1713074584120" MODIFIED="1713074586626"/>
</node>
<node TEXT="previous" FOLDED="true" ID="ID_649282383" CREATED="1712275180902" MODIFIED="1712275183295">
<node TEXT="tools" FOLDED="true" ID="ID_1705491405" CREATED="1712242187771" MODIFIED="1712242192207">
<node ID="ID_867807419" CREATED="1712242193385" MODIFIED="1712242193385" LINK="https://en.wikipedia.org/wiki/List_of_SysML_tools"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://en.wikipedia.org/wiki/List_of_SysML_tools">List of SysML tools - Wikipedia</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Freeplane" FOLDED="true" ID="ID_186237347" CREATED="1712242210106" MODIFIED="1712242215906">
<node TEXT="focal point" FOLDED="true" ID="ID_322021011" CREATED="1624857033469" MODIFIED="1624857040390">
<node TEXT="starred" ID="ID_488308481" CREATED="1624857212114" MODIFIED="1624857217078"/>
</node>
<node TEXT="icons" FOLDED="true" ID="ID_1268124699" CREATED="1637733953745" MODIFIED="1637733957786">
<node TEXT="todo" ID="ID_568484476" CREATED="1637733960109" MODIFIED="1637733977527">
<icon BUILTIN="unchecked"/>
</node>
<node TEXT="habit" ID="ID_1646997168" CREATED="1640878910547" MODIFIED="1640878920652">
<icon BUILTIN="hourglass"/>
</node>
</node>
</node>
</node>
<node TEXT="organization" FOLDED="true" ID="ID_1667870043" CREATED="1626035251926" MODIFIED="1626035256378">
<node TEXT="resource flow" ID="ID_1890827744" CREATED="1661144198336" MODIFIED="1661144207374"/>
<node TEXT="at all times, we are working towards the health of some system" FOLDED="true" ID="ID_899195335" CREATED="1628658924497" MODIFIED="1628658935854">
<node TEXT="potential to adversely affect other systems" FOLDED="true" ID="ID_215465817" CREATED="1628658983049" MODIFIED="1628659000306"/>
<node TEXT="health system optimization landscape" ID="ID_170386285" CREATED="1628659077724" MODIFIED="1628659224328"/>
</node>
<node TEXT="top level is largest system" ID="ID_708444912" CREATED="1626035411918" MODIFIED="1626035420145"/>
<node TEXT="elements, children, subsystems" FOLDED="true" ID="ID_1301904935" CREATED="1624861659844" MODIFIED="1624904774023">
<node TEXT="interface, interaction" FOLDED="true" ID="ID_1004316866" CREATED="1624861743835" MODIFIED="1624861786551">
<node TEXT="top child is interface to parent" ID="ID_1542521188" CREATED="1624729122765" MODIFIED="1624729182021"/>
<node TEXT="children at same level" FOLDED="true" ID="ID_1044771027" CREATED="1619890426948" MODIFIED="1624861805240">
<node TEXT="lateral effect" FOLDED="true" ID="ID_11245989" CREATED="1624862759469" MODIFIED="1624862763602">
<node TEXT="between above and below" ID="ID_1513869713" CREATED="1624860185149" MODIFIED="1624860191973"/>
</node>
</node>
<node TEXT="Siblings are components or attributes of parent object" ID="ID_1635515352" CREATED="1619892159036" MODIFIED="1619892168220"/>
</node>
</node>
</node>
<node TEXT="desire to realization" FOLDED="true" ID="ID_1410478506" CREATED="1625951485334" MODIFIED="1625951529990">
<node TEXT="material to abstract" ID="ID_296990943" CREATED="1626035259364" MODIFIED="1626035329735"/>
</node>
<node TEXT="integration" FOLDED="true" ID="ID_1089831510" CREATED="1624861125574" MODIFIED="1624861128968">
<node TEXT="Current" FOLDED="true" ID="ID_1588282651" CREATED="1624861218346" MODIFIED="1624861227372">
<node TEXT="Voice" ID="ID_68380252" CREATED="1624861228623" MODIFIED="1624861254219"/>
</node>
<node TEXT="Why is what you are doing important?" ID="ID_1718965252" CREATED="1624859561341" MODIFIED="1624859566984"/>
<node TEXT="How does this fit into your life values and priorities?" ID="ID_1543109284" CREATED="1624859568191" MODIFIED="1624859603187"/>
</node>
<node TEXT="development" FOLDED="true" ID="ID_530096353" CREATED="1624857313857" MODIFIED="1637730541316">
<node TEXT="time log" ID="ID_1490654681" CREATED="1637730911447" MODIFIED="1637730920154"/>
<node TEXT="process" FOLDED="true" ID="ID_643942585" CREATED="1624859649383" MODIFIED="1624859655208">
<node TEXT="Computer" ID="ID_1174628997" CREATED="1637735418521" MODIFIED="1637735478960"/>
</node>
<node TEXT="Result" FOLDED="true" ID="ID_138783137" CREATED="1624859737418" MODIFIED="1624859740340">
<node TEXT="effect chain" ID="ID_974456122" CREATED="1624862406282" MODIFIED="1624862409826"/>
<node TEXT="natural language tree" FOLDED="true" ID="ID_1622630633" CREATED="1624859742346" MODIFIED="1624859767752">
<node TEXT="branch should read as sentence" ID="ID_1759402710" CREATED="1624862183431" MODIFIED="1624862192441"/>
</node>
</node>
</node>
<node TEXT="operating model" FOLDED="true" ID="ID_236807018" CREATED="1632328521674" MODIFIED="1632328733518">
<font BOLD="true"/>
<node TEXT="goals" FOLDED="true" ID="ID_823506841" CREATED="1624296876633" MODIFIED="1624296879689">
<node TEXT="Focus" FOLDED="true" ID="ID_930072411" CREATED="1624164301505" MODIFIED="1624164305165">
<node TEXT="Constantly Visible Top Priority" FOLDED="true" ID="ID_75499490" CREATED="1624162370391" MODIFIED="1624163129562">
<node TEXT="1 second access" ID="ID_158303133" CREATED="1624162452453" MODIFIED="1624162515111"/>
<node TEXT="Tool" FOLDED="true" ID="ID_1678251723" CREATED="1624162554158" MODIFIED="1624162560390">
<node TEXT="planner schedule" ID="ID_1101709068" CREATED="1624296961433" MODIFIED="1624296965288"/>
</node>
</node>
</node>
<node TEXT="Awareness" FOLDED="true" ID="ID_100634771" CREATED="1624164306148" MODIFIED="1624164308369">
<node TEXT="at what interval should you look at the broader picture?" FOLDED="true" ID="ID_1783806735" CREATED="1624164249102" MODIFIED="1624164272745">
<node TEXT="2 times per day" FOLDED="true" ID="ID_790772056" CREATED="1624296984652" MODIFIED="1624296995052">
<node TEXT="1st thing in morning" ID="ID_941372336" CREATED="1624296996106" MODIFIED="1624297000484"/>
<node TEXT="Last thing and evening" ID="ID_1173792824" CREATED="1624297001495" MODIFIED="1624297012507"/>
</node>
</node>
</node>
<node TEXT="data relating to current task should be most easily accessible" FOLDED="true" ID="ID_1848634455" CREATED="1624163263190" MODIFIED="1624163286964">
<node TEXT="distraction should be avoided" ID="ID_34943924" CREATED="1624163351531" MODIFIED="1624163360761"/>
</node>
</node>
<node TEXT="resources" FOLDED="true" ID="ID_649539439" CREATED="1632346368357" MODIFIED="1632346372281">
<node ID="ID_1779927436" CREATED="1632346374007" MODIFIED="1632346374007" LINK="https://opexsociety.org/body-of-knowledge/operating-model/"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://opexsociety.org/body-of-knowledge/operating-model/">What is an operating model? - Operational Excellence Society</a>
  </body>
</html>
</richcontent>
</node>
<node ID="ID_191528001" CREATED="1635880264058" MODIFIED="1635880264058" LINK="https://obahy.files.wordpress.com/2014/07/modelbasedmanagementstrategicinitiatives.pdf"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://obahy.files.wordpress.com/2014/07/modelbasedmanagementstrategicinitiatives.pdf">modelbasedmanagementstrategicinitiatives.pdf</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="definition" ID="ID_849046502" CREATED="1633196654373" MODIFIED="1633196656883"/>
<node ID="ID_1268222179" CREATED="1634159459047" MODIFIED="1634159459047" LINK="https://www.julian.com/blog/mental-model-examples"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://www.julian.com/blog/mental-model-examples">Mental model examples: How to actually use them | Elon Musk</a>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Self Image" ID="ID_323200485" CREATED="1519760558651" MODIFIED="1519760558651"/>
<node TEXT="Energy or Will Flow Model" FOLDED="true" ID="ID_1464935785" CREATED="1665841537034" MODIFIED="1665841558535">
<node TEXT="energy or will flows down through these levels" ID="ID_1985508793" CREATED="1666889092993" MODIFIED="1666889100047"/>
<node ID="ID_1258920276" CREATED="1666995046977" MODIFIED="1666995046977" LINK="https://app.diagrams.net/#G10x6rk4v0HeZ3Pk1pXVHYAtTI79fOK1DG"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <a href="https://app.diagrams.net/#G10x6rk4v0HeZ3Pk1pXVHYAtTI79fOK1DG">Life Model.drawio - diagrams.net</a>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</map>
